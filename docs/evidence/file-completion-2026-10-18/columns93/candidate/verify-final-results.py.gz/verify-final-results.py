from pathlib import Path
import json,hashlib
root=Path('build/format-gap91')
def read(name):return json.loads((root/name).read_text(encoding='utf8'))
def ok(e):
 c=e['comparison'];return e['guard']['status']=='checked' and e['loss']['count']==0 and c['semantic']['count']==0 and c['geometry']['count']==0 and c['pages']['equal']
def states(row):
 assert row['undo']=={'semantic':0,'geometry':0} and row['redo']=={'semantic':0,'geometry':0}
reports=['unsupported-origin-storage-column-width91.json','source-frame-body-edit-column-width91.json','source-frame-hwpx-tail-edit-column-width91.json','source-frame-cycles-stress-column-width91.json']
all_exports=[]; matrix=read(reports[0]); assert len(matrix['rows'])==22
blocked=[]
for r in matrix['rows']:
 assert r['sourceBytesUnchanged']
 for e in r['exports']:
  all_exports.append(e)
  if ok(e):continue
  assert r['path'].endswith('.hwpx') and e['format']=='hwp' and e['loss']['count']==1 and e['comparison']['semantic']['count']==0 and e['comparison']['geometry']['count']==0 and e['guard']['status']=='blocked'
  blocked.append(r['path'])
assert len(blocked)==8
for name in reports[1:3]:
 j=read(name);assert len(j['rows'])==6
 for r in j['rows']:
  states(r)
  for e in r['exports']:assert ok(e);all_exports.append(e)
j=read(reports[3]);assert len(j['rows'])==6;stress_blocked=0
for r in j['rows']:
 assert r['sourceUnchanged'] and len(r['cycles'])==3
 for e in r['cycles']:assert ok(e);all_exports.append(e)
 for case in r['stress']:
  states(case)
  for e in case['exports']:
   all_exports.append(e)
   if ok(e):continue
   assert e['format']=='hwpx' and e['guard']['status']=='blocked' and (e['comparison']['geometry']['count']>0 or e['comparison']['semantic']['count']>0 or e['loss']['count']>0)
   stress_blocked+=1
assert stress_blocked==12
log=root/'source-owner-regression.log';assert '7 passed; 0 failed' in log.read_text(encoding='utf8',errors='replace')
proof=read('column-width-source-proof91.json')
for f in proof['files']:assert hashlib.sha256((root/'source'/f['path']).read_bytes()).hexdigest()==f['afterSha256']
assert '6 passed; 0 failed' in (root/'column-width-unit.log').read_text(encoding='utf8',errors='replace')
manifest=read('source/pkg/jueony-engine-build.json');assert manifest['sourceId']=='private-proportional-column-width91'
assert manifest['candidatePatchSha256']==proof['patchSha256']
artifacts=[]
for name in reports+['column-width-unit.log','source-owner-regression.log','column-width-wasm.log','column-width-source-proof91.json','proportional-column-persistence91.patch']:
 p=root/name;artifacts.append({'path':name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
out={'status':'PRIVATE_CANDIDATE_VERIFIED_NOT_PRODUCTION_PROMOTED','sourceId':manifest['sourceId'],'wasmSha256':manifest['wasmSha256'],'patchSha256':proof['patchSha256'],'rustOwnershipTests':7,'columnWidthRustTests':6,'exportArtifacts':len(all_exports),'checked':sum(e['guard']['status']=='checked'for e in all_exports),'blocked':sum(e['guard']['status']=='blocked'for e in all_exports),'existingDirectionLossBlocked':8,'prefixReflowSafelyBlocked':12,'semanticOrGeometryDifferencesInAcceptedExports':0,'historyStatesCompared':48,'productionGuardModified':False,'productionEnginePromoted':False,'visibleUiUsed':False,'nativeHancomCompared':False,'artifacts':artifacts,'limits':['Original native Hancom pagination/font parity is separate and unverified here.','Prefix wrap/page reflow HWPX still fails strict preservation and is not claimed supported.','Eight existing pure HWPX to HWP textDir-loss conversions remain blocked.','Official engine100/resource/performance integration and 194 frontend regressions are root follow-up. Nested proportional frames remain explicitly unsupported, and current i16-reader range overflow is loss-reported.']}
(root/'final-column-width-result91.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(out,ensure_ascii=False,indent=2))
