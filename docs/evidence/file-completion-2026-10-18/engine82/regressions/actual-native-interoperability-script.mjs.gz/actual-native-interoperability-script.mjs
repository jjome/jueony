import{readFile,writeFile}from'node:fs/promises';
import{resolve}from'node:path';
import{loadReviewEngine,snapshot,compareSnapshots,hash}from'../apps/editor/scripts/lib/hancom-review.mjs';
const root=resolve('.'),engine=await loadReviewEngine(resolve('build/rhwp-engine/source-65b8886bcdae0760/pkg'));
const paths=['build/hancom-final-file-review-20261017/mcst-bid-2026-hwpx-hancom.hwpx','build/mcst-cross-closure77/mcst-actual-v7-final-native-review.hwp','build/mcst-cross-closure77/mcst-v7-final-native-hancom-resaved.hwpx'];
const bytes=await Promise.all(paths.map(p=>readFile(p))),docs=bytes.map(b=>new engine.HwpDocument(b));
const redact=v=>typeof v==='number'||typeof v==='boolean'||v===null?v:{sha256:hash(JSON.stringify(v)??'undefined')};
try{
 const states=docs.map(snapshot),results=[];
 for(const[a,b]of[[0,1],[1,2],[0,2]]){
  const report=compareSnapshots(states[a],states[b]);
  for(const group of[report.semantic,report.geometry])group.differences=group.differences.map(d=>({...d,...(Object.hasOwn(d,'before')?{before:redact(d.before)}:{}),...(Object.hasOwn(d,'after')?{after:redact(d.after)}:{})}));
  results.push({before:paths[a],after:paths[b],...report});
 }
 const inputs=[];for(let i=0;i<paths.length;i++){const current=await readFile(paths[i]);if(hash(current)!==hash(bytes[i]))throw Error('Input changed');inputs.push({path:paths[i],sha256:hash(current),bytes:current.length});}
 const out={engine:engine.metadata,inputs,results,scope:'Read-only exact production semantic contract and full published layout. String/body values only redacted in diagnostic output, not comparator. No public source or derived document written.'};
 await writeFile(resolve('build/mcst-actual82-native-interop.json'),JSON.stringify(out,null,2));
 console.log(JSON.stringify(results.map(x=>({status:x.status,pages:x.pages,semantic:x.semantic.count,geometry:x.geometry.count}))));
 if(results.some(x=>x.status!=='SAME_WITHIN_PUBLISHED_CONTRACT'))process.exitCode=1;
}finally{docs.forEach(d=>d.free());}
