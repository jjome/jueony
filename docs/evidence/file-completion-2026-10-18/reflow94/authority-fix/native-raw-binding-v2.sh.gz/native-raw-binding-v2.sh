#!/usr/bin/env bash
set -euo pipefail
root=/mnt/c/Users/jjome/Documents/work/jueony
export RUSTUP_HOME="$root/.tools/linux-rustup"
export CARGO_HOME="$root/.tools/linux-cargo"
export PATH="$CARGO_HOME/bin:$PATH"
export CARGO_TARGET_DIR=/tmp/jueony-rhwp-engine/target/negative-closure70
cd "$root/build/format-gap94/runtime-source-v2"


cargo test --offline --locked -p rhwp --lib native_computed -j 2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib raw_directory -j 2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib test_private_cache_utf8_status_distinguishes_replacement_from_damage -j 2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib test_invalid_utf8_entry_lossy_accepted -j 2 -- --nocapture --test-threads=1
