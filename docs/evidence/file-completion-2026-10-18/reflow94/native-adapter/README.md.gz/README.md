# HWP completed-row adapter: isolated Native proof

The five-file runtime patch targets baseline101 source-448ba81d29c9095a and must be combined with the exact parent common contract (RESOURCE c02f5a92…). It does not edit the official package. No UI, servers, apps, user/public document bytes, production source or Git were modified.

Final Native: 10/10, plus exact compiled pipeline RESOURCE unit1/1, ignored0. Six own synthetic inputs × short/long edits form12 cases. HWP→HWP→HWPX36 reopens and HWP→HWPX→HWP→HWPX48 reopens use actual production report APIs. All descriptors are present, report losses empty, and full published layout passes existing measured-coordinate maximum0.2 with every other field/key/array size exact. The retained raw differences are only unequal-column charX positions, maximum0.1; exact0 is not claimed.

The source has no debug branches. The diagnostic-only-v13 log is explicitly not valid release-generation proof. Earlier compile failures, exact failures, 1ULP plan-hash loss, and real XML→HWP descriptor failures are retained independently. The final strict helper explicitly detects missing-vs-null keys and unequal array sizes; an added negative unit protects that boundary.

Reproduce in the original private source with native-controlled-lowering-v14.sh and isolated target. The private harness is not production cargo code: its fixture/env module is omitted from the runtime patch. Own fixture paths and byte hashes are listed in input-fixture-immutability.json. No input binaries or font payloads are copied into this bundle.

Limits: official combined WASM/frontend and actual Hancom UI are not tested here. Password/encrypted/distribution/HWP3 completed-row metadata is refused. The new contract contains only row bases/space-metric/frame origin, never text/table/font/whole-IR shadows. Existing source runtime overflow warnings remain visible; this proves preservation, not global typography correctness.
