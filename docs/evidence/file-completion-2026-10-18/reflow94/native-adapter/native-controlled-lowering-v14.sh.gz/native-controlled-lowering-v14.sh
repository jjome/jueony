#!/usr/bin/env bash
set -euo pipefail
repo=/mnt/c/Users/jjome/Documents/work/jueony
export RUSTUP_HOME="$repo/.tools/linux-rustup"
export CARGO_HOME="$repo/.tools/linux-cargo"
export PATH="$CARGO_HOME/bin:$PATH"
export CARGO_TARGET_DIR=/tmp/jueony-rhwp-engine/target/format-hwp94
export JUEONY_REPOSITORY="$repo"
cd "$repo/build/format-hwp94/source"
touch src/lib.rs
cargo test --offline --locked -p rhwp --lib computed_hwp94 -j 2 -- --nocapture --test-threads=1 2>&1 | tee "$repo/build/format-hwp94/native-controlled-lowering-v14.log"
