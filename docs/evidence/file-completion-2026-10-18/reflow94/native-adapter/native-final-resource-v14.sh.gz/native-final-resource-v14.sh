#!/usr/bin/env bash
set -euo pipefail
repo=/mnt/c/Users/jjome/Documents/work/jueony
export JUEONY_REPOSITORY="$repo"
/tmp/jueony-rhwp-engine/target/format-hwp94/debug/deps/rhwp-c2eed510537935c4 native_computed_resource_matches_the_actual_pipeline_sources --nocapture --test-threads=1 2>&1 | tee "$repo/build/format-hwp94/native-final-resource-v14.log"
