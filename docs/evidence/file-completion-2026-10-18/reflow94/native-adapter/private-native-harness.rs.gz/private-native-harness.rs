use super::*;
use crate::document_core::DocumentCore;
use crate::serializer::{serialize_hwp_with_report, content_loss::SerializedFormat};
use std::{io::{Cursor,Read},path::PathBuf};

fn root()->PathBuf {std::env::var_os("JUEONY_REPOSITORY").map(PathBuf::from).expect("absolute JUEONY_REPOSITORY")}
fn input(name:&str)->Vec<u8>{std::fs::read(root().join(format!("build/file-closure69-public/column2-candidate74/valid-negative-disk/baseline-{name}.hwp"))).unwrap()}
fn edited(name:&str,large:bool)->(DocumentCore,Document){
 let mut core=DocumentCore::from_bytes(&input(name)).unwrap();
 let len=core.document.sections[0].paragraphs[0].text.chars().count();
 let text=if large{"자체 문서의 앞 문단에서 쪽 경계를 바꿉니다. ".repeat(350)}else{"자체 문서의 앞 문단 줄을 바꿉니다. ".repeat(25)};
 core.insert_text_native(0,0,len,&text).unwrap();
 let mut doc=core.document.clone();core.authorize_completed_native_export(&mut doc);
 assert!(doc.sections.iter().flat_map(|s|&s.paragraphs).any(|p|p.exports_completed_native_rows()),"completed authority missing for {name}");
 (core,doc)
}
fn streams(bytes:&[u8])->Vec<(String,Vec<u8>)>{
 let mut cfb=cfb::CompoundFile::open(Cursor::new(bytes.to_vec())).unwrap();
 let paths=cfb.walk().filter(|e|e.is_stream()).map(|e|e.path().to_string_lossy().replace('\\',"/")).collect::<Vec<_>>();
 paths.into_iter().map(|p|{let mut b=Vec::new();cfb.open_stream(&p).unwrap().read_to_end(&mut b).unwrap();(p,b)}).collect()
}
fn rebuild(entries:&[(String,Vec<u8>)])->Vec<u8>{crate::serializer::mini_cfb::build_cfb(&entries.iter().map(|(p,b)|(p.as_str(),b.as_slice())).collect::<Vec<_>>()).unwrap()}
fn contract_bytes(bytes:&[u8])->Vec<u8>{streams(bytes).into_iter().find(|(p,_)|p==STREAM).unwrap().1}
fn changed(bytes:&[u8],edit:impl FnOnce(&mut serde_json::Value))->Vec<u8>{
 let mut entries=streams(bytes);let row=entries.iter_mut().find(|(p,_)|p==STREAM).unwrap();let mut value:serde_json::Value=serde_json::from_slice(&row.1).unwrap();edit(&mut value);row.1=serde_json::to_vec(&value).unwrap();rebuild(&entries)
}
fn layout(core:&DocumentCore)->serde_json::Value{
 serde_json::json!({"pages":(0..core.page_count()).map(|page|serde_json::json!({
 "info":serde_json::from_str::<serde_json::Value>(&core.get_page_info_native(page).unwrap()).unwrap(),
 "text":serde_json::from_str::<serde_json::Value>(&core.get_page_text_layout_native(page).unwrap()).unwrap(),
 "controls":serde_json::from_str::<serde_json::Value>(&core.get_page_control_layout_native(page).unwrap()).unwrap(),
 })).collect::<Vec<_>>()})
}
fn owned(doc:&Document)->usize{doc.sections.iter().flat_map(|s|&s.paragraphs).filter(|p|p.completed_native_rows.is_some()).count()}

#[test] fn computed_hwp94_raw_rows_are_not_offset_twice(){
 let (_,doc)=edited("single_column",true);let artifact=serialize_hwp_with_report(&doc).unwrap();
 assert_eq!(artifact.content_loss().output_format(),SerializedFormat::Hwp);
 assert!(!artifact.content_loss().losses().iter().any(|l|l.path==STREAM),"{:?}",artifact.content_loss());
 let bytes=artifact.bytes();let raw=streams(bytes);let mut expected=Vec::new();
 for (_,data) in raw.iter().filter(|(p,_)|p.starts_with("/BodyText/Section")){
  let body=crate::parser::cfb_reader::decode_stream_limited(data.clone(),doc.header.compressed,64*1024*1024).unwrap();
  expected.push(crate::parser::body_text::parse_body_text_section(&body).unwrap().paragraphs.into_iter().map(|p|p.line_segs).collect::<Vec<_>>());
 }
 let parsed=crate::parser::parse_hwp(bytes).unwrap();assert!(owned(&parsed)>0);
 assert!(!parsed.extra_streams.iter().any(|(p,_)|p==STREAM));
 assert_eq!(expected,parsed.sections.iter().map(|s|s.paragraphs.iter().map(|p|p.line_segs.clone()).collect::<Vec<_>>()).collect::<Vec<_>>());
 let meta:serde_json::Value=serde_json::from_slice(&contract_bytes(bytes)).unwrap();
 assert_eq!(meta["representation"],"hwp-flow-v1");assert!(meta["entries"].as_array().unwrap().iter().flat_map(|e|e["bases"].as_array().unwrap()).any(|b|b["offset"].as_i64().unwrap()>0));
}
fn ownership(doc:&Document)->serde_json::Value {
 let frame=contract::context(doc);
 serde_json::json!({"context":frame,"paragraphs":doc.sections.iter().enumerate().flat_map(|(si,s)|s.paragraphs.iter().enumerate().map(move |(pi,p)|{
 let o=p.completed_native_rows.as_ref();serde_json::json!({"section":si,"paragraph":pi,"rows":p.line_segs,"sourceVpos":p.source_line_seg_vertical_pos,
 "ctrlDataRecords":p.ctrl_data_records,"owner":o.is_some(),"owns":p.owns_completed_native_rows(frame),"exports":p.exports_completed_native_rows(),
 "localEqual":o.is_some_and(|o|o.local==contract::local(p)),"frameEqual":o.is_some_and(|o|o.frame==frame),
 "resourceEqual":o.is_some_and(|o|o.resource==contract::RESOURCE),"authorized":o.map(|o|o.export_authorized),
 "bases":o.map(|o|&o.bases),"nativeFrame":o.and_then(|o|o.native_frame),"dirty":p.stored_text_partition_is_dirty()})})).collect::<Vec<_>>()})
}
fn model_state(doc:&Document)->serde_json::Value {
 let d=&doc.doc_info;
 serde_json::json!({"docProperties":doc.doc_properties,"docInfo":{"binData":d.bin_data_list,"fonts":d.font_faces,"borderFills":d.border_fills,"charShapes":d.char_shapes,"tabDefs":d.tab_defs,"numberings":d.numberings,"bullets":d.bullets,"paraShapes":d.para_shapes,"styles":d.styles,"extraRecords":d.extra_records,"bulletCount":d.bullet_count,"memoCount":d.memo_shape_count,"memoXml":d.memo_properties_xml,"headTail":d.hwpx_head_tail,"hwpmlVersion":d.hwpml_version},"sections":doc.sections.iter().map(|s|serde_json::json!({"sectionDef":s.section_def,"paragraphs":s.paragraphs})).collect::<Vec<_>>()})
}
fn differences(a:&serde_json::Value,b:&serde_json::Value,path:&str,out:&mut Vec<serde_json::Value>){
 if a==b{return;}match(a,b){
 (serde_json::Value::Object(a),serde_json::Value::Object(b))=>{
  let aa=a.keys().cloned().collect::<Vec<_>>();let bb=b.keys().cloned().collect::<Vec<_>>();
  if aa!=bb {out.push(serde_json::json!({"path":format!("{path}/$keys"),"before":aa,"after":bb}));}
  for k in a.keys(){if let Some(b)=b.get(k){differences(&a[k],b,&format!("{path}/{k}"),out);}}
 }
 (serde_json::Value::Array(a),serde_json::Value::Array(b))=>{
  if a.len()!=b.len(){out.push(serde_json::json!({"path":format!("{path}/$length"),"before":a.len(),"after":b.len()}));}
  for (i,(a,b)) in a.iter().zip(b).enumerate(){differences(a,b,&format!("{path}/{i}"),out);}
 }
 _=>out.push(serde_json::json!({"path":path,"before":a,"after":b})),
 }
}
#[test] fn computed_hwp94_layout_helper_rejects_missing_null_or_length(){
 for(a,b)in[(serde_json::json!([]),serde_json::json!([null])),(serde_json::json!({"x":null}),serde_json::json!({}))]{
  let mut differences_out=Vec::new();differences(&a,&b,"",&mut differences_out);assert!(!differences_out.is_empty());assert!(differences_out.iter().all(|d|!production_measured_path(d["path"].as_str().unwrap())));
 }
 assert!(!production_measured_path("/pages/0/text/newPublishedMetadata/x"));
 assert!(production_measured_path("/pages/0/text/runs/0/charX/0"));
}
#[test] fn computed_hwp94_production_adapter_mixed_all12(){
 let mut cases=Vec::new();
 for name in ["single_column","three_columns","rtl","distribute","unequal_columns","asymmetric_margin"]{for large in [false,true]{
  let (core,_)=edited(name,large);let before=layout(&core);let mut live=core;let mut stages=Vec::new();
  for format in ["hwp","hwpx","hwp","hwpx"]{
   let artifact=if format=="hwp"{live.export_hwp_with_adapter_snapshot_with_report().unwrap()}else{live.export_hwpx_native_with_report().unwrap()};
   assert!(artifact.content_loss().losses().is_empty(),"{name} {large}: {format} loss {:?}",artifact.content_loss());
   let bytes=artifact.into_bytes();
   let descriptor=if format=="hwp"{streams(&bytes).iter().any(|(p,_)|p==STREAM)}else{let mut zip=zip::ZipArchive::new(Cursor::new(&bytes)).unwrap();let found=zip.by_name(contract::PATH).is_ok();found};
   let source=ownership(&live.document);let actual=if format=="hwp"{let snapshot=live.prepare_hwp_export_snapshot();let mut ds=Vec::new();differences(&model_state(&live.document),&model_state(snapshot.document()),"",&mut ds);{let mut retry=snapshot.document().clone();live.authorize_completed_native_hwp_lowering(&live.document,&mut retry);serde_json::json!({"sourceFormat":format!("{:?}",live.source_format),"resourcesSupported":live.computed_row_resources_supported(),"ownership":ownership(snapshot.document()),"directRetryOwnership":ownership(&retry),"modelDifferences":ds})}}else{serde_json::Value::Null};
   live=DocumentCore::from_bytes(&bytes).unwrap();let mut diffs=Vec::new();differences(&before,&layout(&live),"",&mut diffs);
   let rejected=diffs.iter().filter(|d|!production_measured_path(d["path"].as_str().unwrap())||d["before"].as_f64().zip(d["after"].as_f64()).is_none_or(|(a,b)|(a-b).abs()>0.2)).cloned().collect::<Vec<_>>();
   stages.push(serde_json::json!({"format":format,"descriptor":descriptor,"exactDifferences":diffs,"rejected":rejected,"sourceOwnership":source,"actualHwpSnapshot":actual,"afterOwnership":ownership(&live.document)}));
   let folder=root().join("build/format-hwp94/mixed-production12-v14");std::fs::create_dir_all(&folder).unwrap();std::fs::write(folder.join(format!("{name}-{large}.json")),serde_json::to_vec_pretty(&stages).unwrap()).unwrap();
   assert!(descriptor,"{name} {large}: {format} descriptor missing");assert!(rejected.is_empty(),"{name} {large}: {format} strict full published layout differs {}",rejected.len());
  }
  cases.push(serde_json::json!({"name":name,"large":large,"stages":stages}));
 }}
 let folder=root().join("build/format-hwp94/mixed-production12-v14");std::fs::write(folder.join("result.json"),serde_json::to_vec_pretty(&serde_json::json!({"cases":cases,"expectedCases":12,"expectedReopens":48,"scope":"production WASM adapter entrypoints; all field strict; measured public coordinates max0.2; exact deltas retained"})).unwrap()).unwrap();
}
fn production_measured_path(path:&str)->bool {
 let p=path.trim_start_matches('/').split('/').collect::<Vec<_>>();
 let num=|i:usize|p.get(i).is_some_and(|v|v.parse::<usize>().is_ok());
 let xy=|i:usize|p.get(i).is_some_and(|v|matches!(*v,"x"|"y"|"w"|"h"));
 p.first()==Some(&"pages") && num(1) && (
  (p.len()==6 && num(4) && xy(5) && ((p[2]=="controls"&&p[3]=="controls")||(p[2]=="text"&&p[3]=="runs")))
  ||(p.len()==8&&p[2]=="controls"&&p[3]=="controls"&&num(4)&&p[5]=="cells"&&num(6)&&xy(7))
  ||(p.len()==7&&p[2]=="text"&&p[3]=="runs"&&num(4)&&p[5]=="charX"&&num(6)))
}
#[test] fn computed_hwp94_hwp_then_xml_all12(){
 let mut cases=Vec::new();
 for name in ["single_column","three_columns","rtl","distribute","unequal_columns","asymmetric_margin"]{for large in [false,true]{
  let (core,_)=edited(name,large);let before=layout(&core);let mut live=core;let mut stages=Vec::new();
  for format in ["hwp","hwp","hwpx"]{
   let bytes=if format=="hwp"{live.export_hwp_with_adapter().unwrap()}else{live.export_hwpx_native().unwrap()};
   let has_contract=if format=="hwp"{streams(&bytes).iter().any(|(p,_)|p==STREAM)}else{let mut zip=zip::ZipArchive::new(Cursor::new(&bytes)).unwrap();let found=zip.by_name(contract::PATH).is_ok();found};
   live=DocumentCore::from_bytes(&bytes).unwrap();let mut diffs=Vec::new();differences(&before,&layout(&live),"",&mut diffs);
   let rejected=diffs.iter().filter(|d|!production_measured_path(d["path"].as_str().unwrap())||d["before"].as_f64().zip(d["after"].as_f64()).is_none_or(|(a,b)|(a-b).abs()>0.2)).cloned().collect::<Vec<_>>();
   stages.push(serde_json::json!({"format":format,"descriptor":has_contract,"exactDifferences":diffs,"rejected":rejected,"owners":owned(&live.document)}));
   let folder=root().join("build/format-hwp94/native-xml12-v14");std::fs::create_dir_all(&folder).unwrap();std::fs::write(folder.join(format!("{name}-{large}.json")),serde_json::to_vec_pretty(&stages).unwrap()).unwrap();
   assert!(has_contract,"{name} {large}: {format} descriptor missing");assert!(rejected.is_empty(),"{name} {large}: {format} strict full layout failures: {}",rejected.len());
  }
  cases.push(serde_json::json!({"name":name,"large":large,"stages":stages}));
 }}
 let folder=root().join("build/format-hwp94/native-xml12-v14");std::fs::write(folder.join("result.json"),serde_json::to_vec_pretty(&serde_json::json!({"cases":cases,"contract":"production all fields; only published geometry max0.2","expectedCases":12,"expectedReopens":36})).unwrap()).unwrap();
}
#[test] fn computed_hwp94_unknown_stale_duplicate_malformed_metadata_is_opaque_and_never_authority(){
 let (_,doc)=edited("single_column",false);let bytes=serialize_hwp_with_report(&doc).unwrap().into_bytes();
 for mode in ["version","representation","pipeline","resource","header","section","duplicate","unknown","frame","metric"]{
  let modified=changed(&bytes,|v|match mode{
   "version"=>v["version"]=99.into(),"representation"=>v["representation"]="hwpx-relative-v1".into(),
   "pipeline"=>v["pipeline"]="untrusted".into(),"resource"=>v["resource"][0]=255.into(),
   "header"=>v["header"][0]=255.into(),"section"=>v["sections"][0][0]=255.into(),
   "duplicate"=>{let first=v["entries"][0].clone();v["entries"].as_array_mut().unwrap().push(first);},
   "unknown"=>v["shadowText"]="forbidden".into(),"frame"=>v["entries"][0]["bases"][0]["column"]=999.into(),
   "metric"=>v["entries"][0]["spaces"]=serde_json::json!([[0,99]]),_=>unreachable!(),});
  let parsed=crate::parser::parse_hwp(&modified).unwrap();assert_eq!(owned(&parsed),0,"{mode}");
  let original=contract_bytes(&modified);assert_eq!(parsed.extra_streams.iter().find(|(p,_)|p==STREAM).unwrap().1,original,"{mode}");
  let after=serialize_hwp_with_report(&parsed).unwrap();assert_eq!(contract_bytes(after.bytes()),original,"opaque preservation {mode}");
 }
}
#[test] fn computed_hwp94_bound_standard_stream_changes_revoke_authority(){
 let (_,doc)=edited("single_column",false);let bytes=serialize_hwp_with_report(&doc).unwrap().into_bytes();
 for target in ["/FileHeader","/DocInfo","/BodyText/Section0"]{
  let mut entries=streams(&bytes);let entry=entries.iter_mut().find(|(p,_)|p==target).unwrap();
  if target=="/FileHeader"{entry.1[100]^=1;}else{
   // Change a known parseable raw field without changing the byte count.
   let compressed=doc.header.compressed;
   let mut raw=crate::parser::cfb_reader::decode_stream_limited(entry.1.clone(),compressed,64*1024*1024).unwrap();
   let mut records=crate::parser::record::Record::read_all(&raw).unwrap();
   if target=="/DocInfo" {
    let record=records.iter_mut().find(|r|r.tag_id==crate::parser::tags::HWPTAG_DOCUMENT_PROPERTIES).unwrap();
    record.data[22]^=1; // Stored caret character offset, not a layout/source authority.
   } else {
    let record=records.iter_mut().find(|r|r.tag_id==crate::parser::tags::HWPTAG_PARA_LINE_SEG).unwrap();
    record.data[24]^=1; // First native LINE_SEG column_start.
   }
   raw=crate::serializer::record_writer::write_records(&records);
   entry.1=if compressed {use flate2::{Compression,write::DeflateEncoder};use std::io::Write;let mut out=DeflateEncoder::new(Vec::new(),Compression::default());out.write_all(&raw).unwrap();out.finish().unwrap()}else{raw};
  }
  let rebuilt=rebuild(&entries);let parsed=crate::parser::parse_hwp(&rebuilt).expect("controlled changed standard field remains parseable");assert_eq!(owned(&parsed),0,"{target}");
 }
}
#[test] fn computed_hwp94_collision_preserved_and_unemittable_contract_reported_exactly_once(){
 for path in [STREAM,"/rhwpcomputednativerowsv1","/RhwpComputedNativeRowsV1/Unrelated","/rhwpcomputednativerowsv1/Unrelated"]{
  let (_,mut doc)=edited("single_column",false);let opaque=b"unrelated raw stream; not authority".to_vec();
  doc.extra_streams.push((path.into(),opaque.clone()));let out=serialize_hwp_with_report(&doc).unwrap();
  assert_eq!(out.content_loss().losses().iter().filter(|l|l.path==STREAM).count(),1);
  assert_eq!(streams(out.bytes()).into_iter().find(|(p,_)|p==path).unwrap().1,opaque);
 }
}
#[test] fn computed_hwp94_missing_revoked_authority_never_mints_or_rewrites_standard_rows(){
 let mut core=DocumentCore::from_bytes(&input("single_column")).unwrap();
 let first=core.export_hwp_native().unwrap();assert!(!streams(&first).iter().any(|(p,_)|conflicting_path(p)));
 let (_,mut doc)=edited("single_column",false);
 for p in doc.sections.iter_mut().flat_map(|s|&mut s.paragraphs){if let Some(owner)=&mut p.completed_native_rows{owner.export_authorized=false;}}
 let out=serialize_hwp_with_report(&doc).unwrap();assert!(!streams(out.bytes()).iter().any(|(p,_)|conflicting_path(p)));
}
#[test] fn computed_hwp94_budget_rejects_before_opaque_materialization(){
 let (_,doc)=edited("single_column",false);let bytes=serialize_hwp_with_report(&doc).unwrap().into_bytes();
 let mut entries=streams(&bytes);entries.iter_mut().find(|(p,_)|p==STREAM).unwrap().1=vec![b' ';contract::MAX_BYTES+1];
 assert!(crate::parser::parse_hwp(&rebuild(&entries)).is_err());
}
#[test] fn computed_hwp94_compiled_source_bytes_match_private_candidate(){
 for (path,compiled) in [
  ("src/parser/native_computed_rows.rs",include_bytes!("native_computed_rows.rs").as_slice()),
  ("src/parser/native_computed_rows_tests.rs",include_bytes!("native_computed_rows_tests.rs").as_slice()),
  ("src/parser/mod.rs",include_bytes!("mod.rs").as_slice()),
  ("src/serializer/native_computed_rows.rs",include_bytes!("../serializer/native_computed_rows.rs").as_slice()),
  ("src/serializer/cfb_writer.rs",include_bytes!("../serializer/cfb_writer.rs").as_slice()),
  ("src/serializer/mod.rs",include_bytes!("../serializer/mod.rs").as_slice()),
  ("src/model/native_computed_resource.rs",include_bytes!("../model/native_computed_resource.rs").as_slice()),
  ("Cargo.toml",include_bytes!("../../Cargo.toml").as_slice()),
  ("src/model/native_computed_rows.rs",include_bytes!("../model/native_computed_rows.rs").as_slice()),
  ("src/document_core/native_computed_rows.rs",include_bytes!("../document_core/native_computed_rows.rs").as_slice()),
  ("src/document_core/commands/document.rs",include_bytes!("../document_core/commands/document.rs").as_slice()),
 ]{
  let actual=std::fs::read(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join(path)).unwrap();
  assert_eq!(contract::sha(compiled),contract::sha(&actual),"compiled byte witness {path}");
 }
}
