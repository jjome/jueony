//! Private candidate: exact plain-root ClickHere leaves in an authored HWT profile.
//! No OS IO, mutable live application document, template generation or general HWT claim.
use std::collections::{BTreeMap,BTreeSet};
use rhwp::{document_core::DocumentCore,model::control::{Control,FieldType}};
use quick_xml::{events::Event,reader::NsReader,name::ResolveResult};
use sha2::{Digest,Sha256};
pub type Result<T> = std::result::Result<T,String>;
pub fn hash(b:&[u8])->String{Sha256::digest(b).iter().map(|v|format!("{v:02x}")).collect()}
fn fail<T>(s:&str)->Result<T>{Err(s.into())}
const XS:&str="http://www.w3.org/2001/XMLSchema";
const HWP:&str="http://www.haansoft.com/HWP";
pub const FIELD_INFO:&str="CreateField:int:1 FieldType:int:0 NextFieldDirection:int:1 ChoiceDefault:int:0 CopyCreateType:int:0 InstID:uint:0 NextGroupDirection:int:1";
#[derive(Debug,Clone)]struct Node{ns:String,name:String,attrs:BTreeMap<String,String>,children:Vec<Node>}
fn tree(xml:&str)->Result<Node>{
 let mut r=NsReader::from_str(xml);let mut stack:Vec<Node>=Vec::new();let mut root=None;let mut count=0;
 loop{let event=r.read_event().map_err(|_|"XML_PARSE")?;let empty=matches!(&event,Event::Empty(_));match event{
  Event::Start(e)|Event::Empty(e)=>{
   count+=1;if count>128||stack.len()>8{return fail("XML_BUDGET");}
   let (ns,local)=r.resolver().resolve_element(e.name());
   let ns=match ns{ResolveResult::Unbound=>String::new(),ResolveResult::Bound(v)=>v.as_ref().to_string(),_=>return fail("XML_NS")};
   let mut node=Node{ns,name:local.as_ref().to_string(),attrs:BTreeMap::new(),children:vec![]};
   for attr in e.attributes(){let a=attr.map_err(|_|"XML_ATTR")?;let key=a.key.as_ref().to_string();let value=a.normalized_value(quick_xml::XmlVersion::Implicit1_0).map_err(|_|"XML_ATTR")?.into_owned();
    if key.starts_with("xmlns"){
     if !stack.is_empty()||!((key=="xmlns:xs"&&value==XS)||(key=="xmlns:h"&&value==HWP)){return fail("XML_NS_PROFILE");}continue;
    }
    if node.attrs.insert(key,value).is_some(){return fail("XML_DUP_ATTR");}
   }
   if empty{if let Some(p)=stack.last_mut(){p.children.push(node);}else if root.replace(node).is_some(){return fail("XML_ROOT");}}
   else{stack.push(node);}
  },Event::End(_)=>{let node=stack.pop().ok_or("XML_END")?;if let Some(p)=stack.last_mut(){p.children.push(node);}else if root.replace(node).is_some(){return fail("XML_ROOT");}},
  Event::Text(e)=>{if !e.as_ref().trim().is_empty(){return fail("XML_VALUE_NOT_MAPPING");}},
  Event::Decl(_)|Event::Comment(_)=>{},Event::Eof=>break,_=>return fail("XML_UNSUPPORTED")
 }}
 if !stack.is_empty(){return fail("XML_END");}root.ok_or("XML_ROOT".into())
}
fn exact(n:&Node,name:&str,ns:&str,attrs:&[&str],children:usize)->Result<()> {
 if n.name!=name||n.ns!=ns||n.attrs.keys().map(String::as_str).collect::<BTreeSet<_>>()!=attrs.iter().copied().collect()||n.children.len()!=children{return fail("SCHEMA_PROFILE");}Ok(())
}
fn simple_name(s:&str)->bool{!s.is_empty()&&s.len()<=32&&s.bytes().enumerate().all(|(i,c)|c==b'_'||c.is_ascii_alphabetic()||(i>0&&c.is_ascii_digit()))}
/// Requires a complete closed schema/mapping profile, never a successful subset.
fn leaves(schema:&str,mapping:&str)->Result<Vec<String>>{
 let s=tree(schema)?;exact(&s,"schema",XS,&[],1)?;
 let root=&s.children[0];exact(root,"element",XS,&["name"],1)?;let name=&root.attrs["name"];if !simple_name(name){return fail("SCHEMA_NAME");}
 let complex=&root.children[0];exact(complex,"complexType",XS,&[],1)?;
 let seq=&complex.children[0];if seq.children.is_empty()||seq.children.len()>32{return fail("SCHEMA_BUDGET");}exact(seq,"sequence",XS,&[],seq.children.len())?;
 let m=tree(mapping)?;exact(&m,"XMLELEMENT","",&["Name","SchemaXPath"],seq.children.len())?;
 if m.attrs["Name"]!=*name||m.attrs["SchemaXPath"]!="/xs:schema/xs:element[position()=1]"{return fail("MAPPING_ROOT");}
 let mut result=Vec::new();let mut seen=BTreeSet::new();
 for(i,(s,m))in seq.children.iter().zip(&m.children).enumerate(){
  exact(s,"element",XS,&["name","type","h:FieldInfo"],0)?;exact(m,"XMLELEMENT","",&["Name","SchemaXPath"],0)?;
  let name=&s.attrs["name"];if !simple_name(name)||s.attrs["type"]!="xs:string"||s.attrs["h:FieldInfo"]!=FIELD_INFO{return fail("SCHEMA_LEAF_PROFILE");}
  let path=format!("/xs:schema/xs:element[position()=1]/xs:complexType[position()=1]/xs:sequence[position()=1]/xs:element[position()={}]",i+1);
  if m.attrs["Name"]!=*name||m.attrs["SchemaXPath"]!=path||!seen.insert(name.clone()){return fail("MAPPING_AMBIGUOUS");}result.push(name.clone());
 }Ok(result)
}
#[derive(Debug,Clone,PartialEq)]pub struct Binding{pub name:String,pub field_id:u32,pub paragraph:usize,pub value:String}
pub fn preflight(bytes:&[u8],doc:&DocumentCore)->Result<Vec<Binding>>{
 let read=rhwp::parser::xml_template::extract_hwt_xml_template(bytes)?;
 let names=leaves(&read.schema,&read.mapping)?;
 let d=doc.document();if d.header.flags!=0x21||d.sections.len()!=1||d.sections[0].paragraphs.len()>64{return fail("HWT_DOCUMENT_PROFILE");}
 if d.is_hwpx_variant||d.is_hwp3_variant||d.provenance.hwpx_lineage||d.provenance.hwp3_lineage||!d.hwpx_aux_entries.is_empty(){return fail("HWT_SOURCE_PROFILE");}
 if !d.sections[0].section_def.master_pages.is_empty()||!d.sections[0].section_def.extra_child_records.is_empty(){return fail("HWT_HIDDEN_STORY_UNSUPPORTED");}
 let mut ids=BTreeSet::new();let mut result=Vec::new();
 for(pi,p)in d.sections[0].paragraphs.iter().enumerate(){
  if !p.orphan_field_ends.is_empty(){return fail("FIELD_CROSS_PARAGRAPH");}
  for(ci,c)in p.controls.iter().enumerate(){match c{
   Control::SectionDef(s)=>{if pi!=0||!s.master_pages.is_empty()||!s.extra_child_records.is_empty(){return fail("UNEXPECTED_SECTION_CONTROL");}},
   Control::ColumnDef(_)=>{if pi!=0{return fail("UNEXPECTED_SECTION_CONTROL");}},
   Control::Field(f)=>{
    if f.field_type!=FieldType::ClickHere||f.field_id==0||!ids.insert(f.field_id)||!f.is_editable_in_form(){return fail("FIELD_TYPE_ID_PERMISSION");}
    let name=f.ctrl_data_name.as_ref().ok_or("FIELD_EXACT_NAME_REQUIRED")?;
    if f.field_name()!=Some(name)||!names.contains(name)||result.iter().any(|b:&Binding|&b.name==name){return fail("FIELD_NAME_AMBIGUOUS");}
    let ranges=p.field_ranges.iter().filter(|r|r.control_idx==ci).collect::<Vec<_>>();
    if ranges.len()!=1||ranges[0].inner_slot_count!=0||ranges[0].start_char_idx>ranges[0].end_char_idx{return fail("FIELD_GROUP_UNSUPPORTED");}
    let value=p.text.chars().skip(ranges[0].start_char_idx).take(ranges[0].end_char_idx-ranges[0].start_char_idx).collect();
    result.push(Binding{name:name.clone(),field_id:f.field_id,paragraph:pi,value});
   },_=>return fail("FORM_OBJECT_OR_OTHER_CONTROL_UNSUPPORTED")
  }}
 }
 if result.len()!=names.len(){return fail("FIELD_MAPPING_INCOMPLETE");}Ok(result)
}
#[derive(Debug,Clone)]pub struct Lease{pub instance:u64,pub revision:u64,pub source_sha:String,pub field_id:u32,pub old_value:String}
pub struct Session{doc:DocumentCore,source:Vec<u8>,instance:u64,revision:u64,undo:Vec<(u32,u32)>,redo:Vec<(u32,u32)>}
fn edit_delta(before:&rhwp::model::document::Document,after:&DocumentCore,source:&[u8],id:u32,value:&str)->Result<()> {
 let mut a=DocumentCore::new_empty();a.set_document(before.clone());let original=preflight(source,&a)?;let mut expected=original.clone();let target=expected.iter_mut().find(|b|b.field_id==id).ok_or("DELTA_TARGET")?;target.value=value.into();
 if preflight(source,after)?!=expected{return fail("EDIT_OTHER_FIELD_CHANGED");}
 let b=after.document();if before.extra_streams!=b.extra_streams||before.header.raw_data!=b.header.raw_data||rhwp::serializer::doc_info::serialize_doc_info(&before.doc_info,&before.doc_properties)!=rhwp::serializer::doc_info::serialize_doc_info(&b.doc_info,&b.doc_properties){return fail("EDIT_RESOURCE_CHANGED");}
 for(old,new)in before.sections[0].paragraphs.iter().zip(&b.sections[0].paragraphs){
  let target=old.controls.iter().enumerate().find_map(|(i,c)|if let Control::Field(f)=c{(f.field_id==id).then_some(i)}else{None});
  let mut controls=old.controls.clone();let mut expected_text=old.text.clone();let mut changed=None;
  if let Some(ci)=target{let range=old.field_ranges.iter().find(|r|r.control_idx==ci).ok_or("DELTA_RANGE")?;let chars=old.text.chars().collect::<Vec<_>>();expected_text=chars[..range.start_char_idx].iter().collect::<String>()+value+&chars[range.end_char_idx..].iter().collect::<String>();changed=Some((range.start_char_idx,range.end_char_idx));if !value.is_empty(){if let Control::Field(f)=&mut controls[ci]{f.properties|=1<<15;}}}
  if expected_text!=new.text||serde_json::to_value(controls).unwrap()!=serde_json::to_value(&new.controls).unwrap()||old.para_shape_id!=new.para_shape_id||old.style_id!=new.style_id{return fail("EDIT_MODEL_DELTA");}
  let oldlen=old.text.chars().count();let inserted=value.chars().count();for i in 0..oldlen{let mapped=match changed{Some((start,end))if i>=start&&i<end=>None,Some((start,end))if i>=end=>Some(i-end+start+inserted),_=>Some(i)};if let Some(j)=mapped{if old.char_shape_id_at(i)!=new.char_shape_id_at(j){return fail("EDIT_EXISTING_STYLE_ID_CHANGED");}}}
  if let Some((start,_))=changed{let style=old.char_shape_id_at(start);for i in start..start+inserted{if new.char_shape_id_at(i)!=style{return fail("EDIT_INSERTED_STYLE_ID_CHANGED");}}}
 }Ok(())
}
impl Session{
 pub fn open(bytes:&[u8],instance:u64)->Result<Self>{let doc=DocumentCore::from_bytes(bytes).map_err(|_|"HWT_OPEN")?;preflight(bytes,&doc)?;Ok(Self{doc,source:bytes.to_vec(),instance,revision:0,undo:vec![],redo:vec![]})}
 pub fn document(&self)->&DocumentCore{&self.doc}
 pub fn undo(&mut self)->Result<()>{let pair=self.undo.pop().ok_or("NO_UNDO")?;self.doc.restore_snapshot_native(pair.0).map_err(|_|"UNDO_FAILED")?;self.redo.push(pair);self.revision+=1;Ok(())}
 pub fn redo(&mut self)->Result<()>{let pair=self.redo.pop().ok_or("NO_REDO")?;self.doc.restore_snapshot_native(pair.1).map_err(|_|"REDO_FAILED")?;self.undo.push(pair);self.revision+=1;Ok(())}
 pub fn lease(&self,name:&str)->Result<Lease>{let b=preflight(&self.source,&self.doc)?.into_iter().find(|b|b.name==name).ok_or("FIELD_NOT_FOUND")?;Ok(Lease{instance:self.instance,revision:self.revision,source_sha:hash(&self.source),field_id:b.field_id,old_value:b.value})}
 pub fn edit(&mut self,lease:&Lease,value:&str)->Result<()> {
  if lease.instance!=self.instance||lease.revision!=self.revision||lease.source_sha!=hash(&self.source){return fail("STALE_DOCUMENT_LEASE");}
  if value.chars().count()>256||value.chars().any(char::is_control){return fail("VALUE_PROFILE");}
  if self.undo.len()+self.redo.len()>=32{return fail("HISTORY_BUDGET");}
  let b=preflight(&self.source,&self.doc)?.into_iter().find(|b|b.field_id==lease.field_id).ok_or("STALE_FIELD")?;
  if b.value!=lease.old_value||b.value==value{return fail("STALE_VALUE_OR_NOOP");}
  let model_before=self.doc.document().clone();let before=self.doc.save_snapshot_native();
  let result=self.doc.set_field_value_by_id(lease.field_id,value).map_err(|_|"FIELD_EDIT_FAILED".to_string()).and_then(|_|edit_delta(&model_before,&self.doc,&self.source,lease.field_id,value));
  if let Err(e)=result{self.doc.restore_snapshot_native(before).map_err(|_|"ROLLBACK_FAILED")?;self.doc.discard_snapshot_native(before);return Err(e.into());}
  let after=self.doc.save_snapshot_native();for(a,b)in self.redo.drain(..){self.doc.discard_snapshot_native(a);self.doc.discard_snapshot_native(b);}self.undo.push((before,after));self.revision+=1;Ok(())
 }
 /// Returns bytes only after same-format and strict post-write evidence checks.
 /// The caller still owns actual safe OS writing; this candidate never writes files.
 pub fn export_checked(&self)->Result<Vec<u8>>{
  let expected=preflight(&self.source,&self.doc)?;
  let output=self.doc.export_hwp_with_adapter_snapshot_with_report().map_err(|_|"HWT_EXPORT")?;
  if !output.content_loss().is_empty(){return fail("HWT_CONTENT_LOSS");}
  let bytes=output.into_bytes();let reopened=DocumentCore::from_bytes(&bytes).map_err(|_|"HWT_REOPEN")?;
  if preflight(&bytes,&reopened)?!=expected{return fail("HWT_FIELD_ROUNDTRIP");}
  let before=self.doc.document();let after=reopened.document();
  if before.header.flags!=after.header.flags||before.header.raw_data!=after.header.raw_data||before.extra_streams!=after.extra_streams{return fail("HWT_RAW_STREAM_PRESERVATION");}
  if rhwp::serializer::doc_info::serialize_doc_info(&before.doc_info,&before.doc_properties)!=rhwp::serializer::doc_info::serialize_doc_info(&after.doc_info,&after.doc_properties){return fail("HWT_RESOURCE_PRESERVATION");}
  if before.sections[0].paragraphs.len()!=after.sections[0].paragraphs.len(){return fail("HWT_PARAGRAPH_COUNT");}
  for(a,b)in before.sections[0].paragraphs.iter().zip(&after.sections[0].paragraphs){
   if a.text!=b.text||a.para_shape_id!=b.para_shape_id||a.style_id!=b.style_id||serde_json::to_value(&a.char_shapes).unwrap()!=serde_json::to_value(&b.char_shapes).unwrap()||serde_json::to_value(&a.controls).unwrap()!=serde_json::to_value(&b.controls).unwrap()||serde_json::to_value(&a.field_ranges).unwrap()!=serde_json::to_value(&b.field_ranges).unwrap(){return fail("HWT_FIELD_AND_STYLE_METADATA");}
  }
  if self.doc.page_count()!=reopened.page_count(){return fail("HWT_PAGES");}
  for page in 0..self.doc.page_count(){for pair in [(self.doc.get_page_text_layout_native(page),reopened.get_page_text_layout_native(page)),(self.doc.get_page_control_layout_native(page),reopened.get_page_control_layout_native(page))]{
   let a:serde_json::Value=serde_json::from_str(&pair.0.map_err(|_|"LAYOUT_READ")?).map_err(|_|"LAYOUT_JSON")?;
   let b:serde_json::Value=serde_json::from_str(&pair.1.map_err(|_|"LAYOUT_READ")?).map_err(|_|"LAYOUT_JSON")?;
   if a!=b{return fail("HWT_LAYOUT_EXACT");}
  }}Ok(bytes)
 }
}

#[cfg(test)]mod tests{
 use super::*;use std::io::{Cursor,Read,Write};
 fn packed(s:&str)->Vec<u8>{let mut v=Vec::new();for c in s.encode_utf16(){v.extend(c.to_le_bytes());}let mut b=(v.len()as u32).to_le_bytes().to_vec();b.extend(v);let mut encoder=flate2::write::DeflateEncoder::new(Vec::new(),flate2::Compression::default());encoder.write_all(&b).unwrap();let mut z=encoder.finish().unwrap();z.extend(crc32fast::hash(&b).to_le_bytes());z.extend((b.len()as u32).to_le_bytes());z}
 fn schema()->String{format!(r#"<xs:schema xmlns:xs="{XS}" xmlns:h="{HWP}"><xs:element name="report"><xs:complexType><xs:sequence><xs:element name="title" type="xs:string" h:FieldInfo="{FIELD_INFO}"/><xs:element name="note" type="xs:string" h:FieldInfo="{FIELD_INFO}"/></xs:sequence></xs:complexType></xs:element></xs:schema>"#)}
 fn mapping()->String{let base="/xs:schema/xs:element[position()=1]";format!(r#"<XMLELEMENT Name="report" SchemaXPath="{base}"><XMLELEMENT Name="title" SchemaXPath="{base}/xs:complexType[position()=1]/xs:sequence[position()=1]/xs:element[position()=1]"/><XMLELEMENT Name="note" SchemaXPath="{base}/xs:complexType[position()=1]/xs:sequence[position()=1]/xs:element[position()=2]"/></XMLELEMENT>"#)}
 fn wrap(body:&[u8],s:&str,m:&str)->Vec<u8>{let mut c=cfb::CompoundFile::open(Cursor::new(body.to_vec())).unwrap();let mut header=vec![];c.open_stream("/FileHeader").unwrap().read_to_end(&mut header).unwrap();let flags=u32::from_le_bytes(header[36..40].try_into().unwrap())|0x20;header[36..40].copy_from_slice(&flags.to_le_bytes());c.create_stream("/FileHeader").unwrap().write_all(&header).unwrap();c.create_storage_all("/XMLTemplate").unwrap();c.create_storage_all("/Opaque").unwrap();let text="own-leaf95";let utf:Vec<u8>=text.encode_utf16().flat_map(u16::to_le_bytes).collect();let mut name=(utf.len()as u32).to_le_bytes().to_vec();name.extend(utf);for(path,data)in [("/XMLTemplate/Schema",packed(s)),("/XMLTemplate/Instance",packed(m)),("/XMLTemplate/_SchemaName",name),("/Opaque/Untouched",vec![0,255,3,5,0,7])]{c.create_stream(path).unwrap().write_all(&data).unwrap();}c.into_inner().into_inner()}
 fn source_names(a:&str,b:&str)->Vec<u8>{let mut core=DocumentCore::new_empty();core.create_blank_document_native().unwrap();core.split_paragraph_native(0,0,0,None).unwrap();core.insert_click_here_field_at(0,0,0,"own guide A","",a,true).unwrap();core.insert_click_here_field_at(0,1,0,"own guide B","",b,true).unwrap();let bytes=core.export_hwp_with_adapter_snapshot_with_report().unwrap();assert!(bytes.content_loss().is_empty());wrap(bytes.bytes(),&schema(),&mapping())}
 fn source()->Vec<u8>{source_names("title","note")}
 fn doc_mutation(f:impl FnOnce(&mut rhwp::model::document::Document))->Vec<u8>{let bytes=source();let mut core=DocumentCore::from_bytes(&bytes).unwrap();let mut doc=core.document().clone();f(&mut doc);for s in &mut doc.sections{s.raw_stream=None;}core.set_document(doc);core.export_hwp_with_adapter_snapshot_with_report().unwrap().into_bytes()}
 #[test]fn own_hwt_leaf_edit_same_hwt_roundtrip_and_other_field_preserved(){let input=source();let before=hash(&input);let mut s=Session::open(&input,7).unwrap();let lease=s.lease("title").unwrap();s.edit(&lease,"자체 값 😀").unwrap();let output=s.export_checked().unwrap();assert_eq!(hash(&input),before);assert_ne!(output,input);let r=Session::open(&output,8).unwrap();assert_eq!(r.lease("title").unwrap().old_value,"자체 값 😀");assert_eq!(r.lease("note").unwrap().old_value,"");assert_eq!(r.document().document().header.flags,0x21);let a=rhwp::parser::xml_template::extract_hwt_xml_template(&input).unwrap();let b=rhwp::parser::xml_template::extract_hwt_xml_template(&output).unwrap();for(x,y)in a.streams.iter().zip(&b.streams){assert_eq!(x.path,y.path);assert_eq!(x.stored_sha256,y.stored_sha256);}println!("own HWT same-format source={} output={} pages={} XMLTemplate3 raw exact",before,hash(&output),r.document().page_count());}
 #[test]fn own_hwt_undo_redo_and_stale_revision(){let bytes=source();let mut s=Session::open(&bytes,7).unwrap();let l=s.lease("title").unwrap();s.edit(&l,"changed").unwrap();assert_eq!(s.edit(&l,"again").unwrap_err(),"STALE_DOCUMENT_LEASE");s.undo().unwrap();assert_eq!(s.lease("title").unwrap().old_value,"");s.redo().unwrap();assert_eq!(s.lease("title").unwrap().old_value,"changed");let a=s.export_checked().unwrap();let recovered=Session::open(&a,9).unwrap();assert_eq!(recovered.lease("title").unwrap().old_value,"changed");assert!(recovered.undo.is_empty());}
 #[test]fn duplicate_name_refuses_before_mutation(){let bytes=source_names("title","title");let core=DocumentCore::from_bytes(&bytes).unwrap();let fields:serde_json::Value=serde_json::from_str(&core.get_field_list_json()).unwrap();assert_eq!(fields[0]["name"],"title");assert_eq!(fields[1]["name"],"title");assert!(Session::open(&bytes,1).is_err());}
 #[test]fn group_or_object_range_refuses(){let bytes=doc_mutation(|d|{d.sections[0].paragraphs[0].field_ranges[0].inner_slot_count=1;d.sections[0].paragraphs[0].controls.push(Control::Form(Box::default()));});let core=DocumentCore::from_bytes(&bytes).unwrap();assert_eq!(core.document().sections[0].paragraphs[0].field_ranges[0].inner_slot_count,1);assert_eq!(preflight(&bytes,&core).unwrap_err(),"FIELD_GROUP_UNSUPPORTED");}
 #[test]fn protected_field_refuses(){let bytes=doc_mutation(|d|{for c in &mut d.sections[0].paragraphs[0].controls{if let Control::Field(f)=c{f.properties&=!1;}}});let core=DocumentCore::from_bytes(&bytes).unwrap();let fields=core.collect_all_fields();assert!(!fields[0].field.is_editable_in_form());assert!(matches!(Session::open(&bytes,1),Err(e)if e=="FIELD_TYPE_ID_PERMISSION"));}
 #[test]fn form_and_unknown_and_duplicate_id_refuse(){let bytes=source();for kind in 0..3{let mut core=DocumentCore::from_bytes(&bytes).unwrap();let d=core.document_mut();if kind==0{d.sections[0].paragraphs[0].controls.push(Control::Form(Box::default()));}else if kind==1{d.sections[0].paragraphs[0].controls.push(Control::Unknown(Default::default()));}else{let id=match &d.sections[0].paragraphs[0].controls.iter().find(|c|matches!(c,Control::Field(_))).unwrap(){Control::Field(f)=>f.field_id,_=>unreachable!()};for c in &mut d.sections[0].paragraphs[1].controls{if let Control::Field(f)=c{f.field_id=id;}}}assert!(preflight(&bytes,&core).is_err());}}
 #[test]fn schema_mismatch_xpath_group_and_duplicate_mapping_refuse(){let bytes=source();for map in [mapping().replace("Name=\"note\"","Name=\"title\""),mapping().replace("position()=2","position()=99"),mapping().replace("Name=\"note\"","Name=\"other\"")]{let source=wrap(&bytes,&schema(),&map);assert!(Session::open(&source,1).is_err());}let group=schema().replace(FIELD_INFO,&FIELD_INFO.replace("FieldType:int:0","FieldType:int:1"));assert!(Session::open(&wrap(&bytes,&group,&mapping()),1).is_err());}
 #[test]fn instance_source_cas_noop_and_controls_refuse_without_changes(){let bytes=source();let mut s=Session::open(&bytes,1).unwrap();let before=serde_json::to_value(&s.doc.document().sections[0].paragraphs).unwrap();for kind in 0..4{let mut l=s.lease("title").unwrap();let text=match kind{0=>{l.instance=2;"safe"},1=>{l.source_sha="0".repeat(64);"safe"},2=>"",_=>"bad\nvalue"};assert!(s.edit(&l,text).is_err());assert_eq!(serde_json::to_value(&s.doc.document().sections[0].paragraphs).unwrap(),before);assert!(s.undo.is_empty());}}
 #[test]fn malformed_hwt_and_missing_body_mapping_refuse(){assert!(Session::open(b"not hwt",1).is_err());let bytes=source();let source=wrap(&bytes,&schema().replace("name=\"note\"","name=\"extra\""),&mapping());assert!(Session::open(&source,1).is_err());}
 #[test]fn hidden_master_and_xml_lineage_refuse(){let bytes=source();for kind in 0..2{let mut core=DocumentCore::from_bytes(&bytes).unwrap();if kind==0{core.document_mut().sections[0].section_def.master_pages.push(Default::default());}else{core.document_mut().provenance.hwpx_lineage=true;}assert!(preflight(&bytes,&core).is_err());}}
 #[test]fn own_artifacts_and_source_witness(){let out=std::path::PathBuf::from(std::env::var("JUEONY_HWT_WRITE_OUTPUT").expect("explicit private output required"));std::fs::create_dir_all(&out).unwrap();let input=source();let mut s=Session::open(&input,1).unwrap();s.edit(&s.lease("title").unwrap(),"Own HWT edited 😀").unwrap();let output=s.export_checked().unwrap();for(n,b)in [("own-laid-out-source.hwt",input),("own-laid-out-edited.hwt",output)]{std::fs::OpenOptions::new().write(true).create_new(true).open(out.join(n)).unwrap().write_all(&b).unwrap();}let source=include_bytes!("lib.rs");assert_eq!(std::fs::read(concat!(env!("CARGO_MANIFEST_DIR"),"/src/lib.rs")).unwrap(),source);println!("compiled-candidate-sha256={}",hash(source));}
}
