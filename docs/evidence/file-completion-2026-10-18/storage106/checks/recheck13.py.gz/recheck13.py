from pathlib import Path
import hashlib,json,shutil
root=Path(__file__).resolve().parents[1]
source=root/'build/file-storage106-workflows'
target=root/'build/file-storage106-reviewed-workflows'
sha=lambda b:hashlib.sha256(b).hexdigest()
raw=(source/'result.json').read_bytes();data=json.loads(raw)
assert data['totalCases']==387 and data['passedCases']==374
assert len(data['suites'])==30 and [r['name']for r in data['failures']]==['owned-native-cell-layout']
assert data['engine']['sourceId']=='fc150ef856868d03'
target.mkdir(exist_ok=True);(target/'logs').mkdir(exist_ok=True)
rerun=root/'build/owned-native-cell106-fixed-reference/result.json'
fixed=json.loads(rerun.read_bytes())
assert len(fixed['results'])==13 and fixed['failures']==[]
assert all(r['status']=='PASS'for r in fixed['results'])
assert fixed['engine']==data['engine']
for row in data['suites']:
 name=row['name'];script=root/'apps/editor/scripts'/f'verify-{name}.mjs'
 fingerprint=sha(script.read_bytes())
 if name=='owned-native-cell-layout':
  old=dict(row);assert old['status']=='FAIL'
  assert fixed['verifierSha256']==fingerprint
  row.update(status='PASS',exitCode=0,passed=13,scriptUnchanged=True,
   verifierSHA256=fingerprint,resultSHA256=sha(rerun.read_bytes()),engineUsed=True,
   previousFailedAttempt=old)
  result=rerun;log=root/'build/owned-native-cell106-fixed-reference.log'
 else:
  assert row['status']=='PASS'and row['scriptUnchanged']
  assert row['verifierSHA256']==fingerprint
  result=source/name/'result.json';log=source/'logs'/(name+'.log')
  assert sha(result.read_bytes())==row['resultSHA256']
  contents=json.loads(result.read_bytes())
  assert len(contents['results'])==row['expectedCases']and not contents['failures']
  assert all(not isinstance(r,dict) or r['status']=='PASS'for r in contents['results'])
 out=target/name;out.mkdir();shutil.copyfile(result,out/'result.json');shutil.copyfile(log,target/'logs'/(name+'.log'))
data['failures']=[];data['passedCases']=387
data['reviewedRerun']={'originalAggregateSha256':sha(raw),'originalPassed':374,
 'recheckedSuite':'owned-native-cell-layout','recheckedPassed':13,
 'reason':'Freeze independent Native reference to original baseline110 and separately require exactly 92 y-only -8.8px corrections. Production/guard/front-end source unchanged; 29 passed suites retained only after exact verifier and result hash checks. No failures discarded or expected counts reduced.'}
(target/'result.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print('PASS 387/387; retained unchanged374 + actual rerun13; original failure preserved separately')
