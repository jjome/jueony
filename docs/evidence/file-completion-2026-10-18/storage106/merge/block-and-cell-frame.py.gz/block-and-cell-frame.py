from pathlib import Path
import difflib,hashlib,json,re,subprocess
root=Path(__file__).resolve().parents[1]
base=root/'build/rhwp-engine/source-e14aa59625fe684f'
stage=root/'build/storage106-logic-stage';stage.mkdir(exist_ok=False)
files=['src/renderer/typeset.rs','src/renderer/typeset/paragraph.rs','src/renderer/typeset/paragraph/format.rs','src/renderer/typeset/paragraph/metrics.rs','src/renderer/typeset/controls/tac_reconcile.rs','src/renderer/typeset/paragraph/mixed_tac_owner.rs','src/renderer/typeset/table/block/entry.rs','src/model/native_computed_resource.rs']
canon=lambda p:p.read_bytes().replace(b'\r\n',b'\n').decode('utf8')
for f in files:
 if not(base/f).is_file():continue
 p=stage/f;p.parent.mkdir(exist_ok=True,parents=True);p.write_text(canon(base/f),encoding='utf8',newline='\n')
for name,digest in [('build/native-mcst-fragment105/handoff-candidate4/current-mixed-block-tac-row-owner105.patch','2a2c05a8e34964a499e86d1edc4325ff3096ab36c08551113bb92f7ee1d55d22'),('build/native-python-storage106/declared-object-cell-frame106.patch','23448db4aa77257dbf519e26c396dc553f5d260caa1b46193a1afe7c14178182')]:
 p=root/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==digest
 cmd=['git','-C',str(root),'apply','--directory=build/storage106-logic-stage','--whitespace=error-all']
 subprocess.run(cmd+['--check',str(p)],check=True);subprocess.run(cmd+[str(p)],check=True)
resource=stage/'src/model/native_computed_resource.rs';s=canon(resource)
line='            ("src/renderer/typeset/paragraph/mixed_tac_owner.rs",include_bytes!("../renderer/typeset/paragraph/mixed_tac_owner.rs").as_slice()),\n'
anchor='            ("src/renderer/typeset/paragraph/metrics.rs",include_bytes!("../renderer/typeset/paragraph/metrics.rs").as_slice()),\n'
assert s.count(anchor)==1;s=s.replace(anchor,anchor+line,1)
paths=re.findall(r'\("([^"]+)",include_bytes!',s);assert len(paths)==225 and len(set(paths))==225
h=hashlib.sha256(b'rhwp-portable-native-text-edit-frame-1;source-text-lf\0');records=[]
for f in paths:
 p=stage/f if(stage/f).is_file()else base/f;raw=p.read_bytes();data=raw.replace(b'\r\n',b'\n');h.update(f.encode());h.update(b'\0');h.update(len(data).to_bytes(8,'little'));h.update(data)
 records.append({'path':f,'canonicalSha256':hashlib.sha256(data).hexdigest(),'canonicalBytes':len(data),'rawSha256':hashlib.sha256(raw).hexdigest()})
s=re.sub(r'const RESOURCE:\[u8;32\]=\[[^;]+;','const RESOURCE:[u8;32]='+str(list(h.digest()))+';',s,count=1);resource.write_text(s,encoding='utf8',newline='\n')
text=''
for f in files:
 old=canon(base/f).splitlines(True)if(base/f).is_file()else[]
 text+=''.join(difflib.unified_diff(old,canon(stage/f).splitlines(True),fromfile='a/'+f if old else '/dev/null',tofile='b/'+f))
p=root/'engine/patches'/('z'*97+'-native-block-and-cell-frame-storage.patch');assert not p.exists();p.write_text(text,encoding='utf8',newline='\n')
(root/'build/storage106-merged-resource.json').write_text(json.dumps({'resourceSha256':h.hexdigest(),'files':records,'patchSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'filesChanged':files},indent=2)+'\n',encoding='utf8')
print(json.dumps({'patch':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'resource':h.hexdigest(),'sourceFiles':len(records)}))
