from pathlib import Path
import hashlib,difflib,re,json,subprocess
root=Path(__file__).resolve().parents[1]
base=root/'build/rhwp-engine/source-625990fd59af9440'
stage=root/'build/storage105-logic-stage'
stage.mkdir(exist_ok=True)
files=['src/renderer/layout.rs','src/renderer/height_cursor.rs','src/renderer/typeset.rs','src/renderer/typeset/paragraph.rs','src/renderer/typeset/paragraph/format.rs','src/renderer/typeset/paragraph/metrics.rs','src/renderer/typeset/section/flow.rs','src/renderer/typeset/section/vpos.rs','src/model/native_computed_resource.rs']
canon=lambda p:p.read_bytes().replace(b'\r\n',b'\n').decode('utf8')
for f in files:
 p=stage/f;p.parent.mkdir(exist_ok=True,parents=True);p.write_text(canon(base/f),encoding='utf8',newline='\n')
def without_resource(raw):
 parts=re.split(r'(?=^--- a/)',raw,flags=re.M)
 return ''.join(x for x in parts if not x.startswith('--- a/src/model/native_computed_resource.rs'))
def apply(text,name):
 p=root/'build'/name;p.write_text(text,encoding='utf8',newline='\n')
 cmd=['git','-C',str(root),'apply','--directory=build/storage105-logic-stage','--whitespace=error-all']
 subprocess.run(cmd+['--check',str(p)],check=True)
 subprocess.run(cmd+[str(p)],check=True)
v7=root/'build/native-mcst-owner103-v7/current-native-column-margin-owner103-v7.patch'
assert hashlib.sha256(v7.read_bytes()).hexdigest()=='ec025b0219909a8e57810a7106103cf653a423646acb60e3c0b0ced9df7bdaae'
old=canon(root/'build/rhwp-engine/source-3f07621d4728accf/src/renderer/layout.rs').splitlines(True)
variant=canon(root/'build/native-mcst-owner103-v7/source/src/renderer/layout.rs').splitlines(True)
target=canon(stage/'src/renderer/layout.rs')
changes=[]
for kind,i,j,a,b in difflib.SequenceMatcher(None,old,variant,autojunk=False).get_opcodes():
 if kind=='equal':continue
 left=max(0,i-32);right=min(len(old),j+32)
 context=''.join(old[left:right]);assert target.count(context)==1,(kind,i,j,'exact independent context required')
 position=target.index(context)+len(''.join(old[left:i]));core=''.join(old[i:j])
 assert target[position:position+len(core)]==core
 changes.append((position,len(core),''.join(variant[a:b])))
for position,length,replacement in sorted(changes,reverse=True):
 target=target[:position]+replacement+target[position+length:]
(stage/'src/renderer/layout.rs').write_text(target,encoding='utf8',newline='\n')
flow=root/'build/native-mcst-page-boundary104/handoff-final/current-native-plain-flow-and-page-boundary104.patch'
assert hashlib.sha256(flow.read_bytes()).hexdigest()=='312e36cba95e23c4bccb235715bd6c4a4d6dc0efd19806bde759caa4f2a72969'
apply(canon(flow),'storage105-page-logic.patch')
v3=root/'build/native-empty-trailing105-v3/source'
text=''
for f in ['src/renderer/layout.rs','src/renderer/height_cursor.rs','src/renderer/typeset.rs']:
 text+=''.join(difflib.unified_diff(canon(base/f).splitlines(True),canon(v3/f).splitlines(True),fromfile='a/'+f,tofile='b/'+f))
apply(text,'storage105-trailing-logic.patch')
assert 'stored_column_top_coanchored_float_box' in canon(stage/'src/renderer/layout.rs')
assert 'current_native_plain_format_matches_saved' in canon(stage/'src/renderer/layout.rs')
assert 'native_stored_plain_trailing' in canon(stage/'src/renderer/height_cursor.rs')
assert 'boundary104_review' not in canon(stage/'src/renderer/typeset.rs')
assert 'formatted.total_height <= st.available_height()' in canon(stage/'src/renderer/typeset/section/vpos.rs')
resource=stage/'src/model/native_computed_resource.rs'
paths=re.findall(r'\("([^"]+)",include_bytes!',canon(resource))
if not paths:
 paths=[r['path']for r in json.loads((root/'build/storage104-official-resource.json').read_bytes())['files']]
assert len(paths)==224
h=hashlib.sha256(b'rhwp-portable-native-text-edit-frame-1;source-text-lf\0');records=[]
for f in paths:
 p=stage/f if (stage/f).is_file()else base/f
 raw=p.read_bytes();data=raw.replace(b'\r\n',b'\n');h.update(f.encode());h.update(b'\0');h.update(len(data).to_bytes(8,'little'));h.update(data)
 records.append({'path':f,'canonicalSha256':hashlib.sha256(data).hexdigest(),'canonicalBytes':len(data),'rawSha256':hashlib.sha256(raw).hexdigest()})
resource.write_text(re.sub(r'const RESOURCE:\[u8;32\]=\[[^;]+;','const RESOURCE:[u8;32]='+str(list(h.digest()))+';',canon(resource),count=1),encoding='utf8',newline='\n')
text=''
for f in files:
 text+=''.join(difflib.unified_diff(canon(base/f).splitlines(True),canon(stage/f).splitlines(True),fromfile='a/'+f,tofile='b/'+f))
p=root/'engine/patches'/('z'*96+'-native-current-flow-storage.patch')
assert not p.exists();p.write_text(text,encoding='utf8',newline='\n')
old=root/'engine/patches'/('z'*96+'-native-owned-empty-trailing.patch')
assert hashlib.sha256(old.read_bytes()).hexdigest()=='8925467be62c1e968778732f9f1eee615379aa8eaf2ec1750fea12e64cb14524'
old.unlink()
(root/'build/storage105-merged-resource.json').write_text(json.dumps({'resourceSha256':h.hexdigest(),'files':records,'patchSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'filesChanged':files},indent=2)+'\n',encoding='utf8')
print(json.dumps({'patch':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'resource':h.hexdigest()}))
