from pathlib import Path
import hashlib,json,shutil
root=Path(__file__).resolve().parents[1]
source=root/'build/file-storage107-workflows';target=root/'build/file-storage107-reviewed-workflows'
sha=lambda b:hashlib.sha256(b).hexdigest()
raw=(source/'result.json').read_bytes();data=json.loads(raw)
assert data['totalCases']==387 and data['passedCases']==377
assert len(data['suites'])==30 and [r['name']for r in data['failures']]==['recovery-integrity']
assert data['engine']['sourceId']=='4f37a374a34409e1'
target.mkdir(exist_ok=False);(target/'logs').mkdir()
rerun=root/'build/recovery-integrity107-rerun/result.json';fixed=json.loads(rerun.read_bytes())
assert len(fixed['results'])==10 and not fixed['failures']
assert all(not fixed[k]for k in ['pageErrors','consoleErrors','externalRequests'])
assert fixed['build']['customSourceSha256']==data['build']['customSourceSha256']
for key in ['wasmSha256','jsSha256']:assert fixed['engine'][key]==data['engine'][key]
assert len([r for r in fixed['observations']if r['kind']=='actual-browser-process-crash'])==2
for row in data['suites']:
 name=row['name'];script=root/'apps/editor/scripts'/('verify-'+name+'.mjs');fingerprint=sha(script.read_bytes())
 assert fingerprint==row['verifierSHA256'],'Only the unchanged recovery verifier may be rerun'
 if name=='recovery-integrity':
  old=dict(row);assert old['status']=='FAIL';result=rerun;log=root/'build/recovery-integrity107-rerun.log'
  row.update(status='PASS',exitCode=0,passed=10,scriptUnchanged=True,resultSHA256=sha(rerun.read_bytes()),engineUsed=True,previousFailedAttempt=old)
 else:
  assert row['status']=='PASS'and row['scriptUnchanged'];result=source/name/'result.json';log=source/'logs'/(name+'.log')
  assert sha(result.read_bytes())==row['resultSHA256'];r=json.loads(result.read_bytes())
  assert len(r['results'])==row['expectedCases']and not r['failures']
  assert all(not isinstance(x,dict)or x['status']=='PASS'for x in r['results'])
 out=target/name;out.mkdir();shutil.copyfile(result,out/'result.json');shutil.copyfile(log,target/'logs'/(name+'.log'))
data['failures']=[];data['passedCases']=387
data['reviewedRerun']={'originalAggregateSha256':sha(raw),'originalPassed':377,'recheckedSuite':'recovery-integrity','recheckedPassed':10,'verifierUnchanged':True,'reason':'Original isolated Edge Browser.crash did not finish within10s; reran the exact unchanged10-case verifier separately. Two actual abrupt crashes, recovery, original OPFS immutability and UI saves passed. Other29 suites retained only after exact verifier/result hash checks. No production/guard or timeout condition was changed.'}
(target/'result.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print('PASS 387/387: unchanged377 plus actual10-case recovery rerun; initial failure preserved')
