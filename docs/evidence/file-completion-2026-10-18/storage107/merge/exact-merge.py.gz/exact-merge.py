from pathlib import Path
import difflib,hashlib,json,re,subprocess,os
root=Path(__file__).resolve().parents[1]
base=root/'build/rhwp-engine/source-fc150ef856868d03'
stage=root/'build/storage107-logic-stage';stage.mkdir(exist_ok=False)
reset=root/'build/native-empty-trailing105-v7/observed-local-reset-inputs105-v7-runtime.patch'
assert hashlib.sha256(reset.read_bytes()).hexdigest()=='9e3dd07450c189851ae740c09bcd6eb28ec16ba52dc5ca699bd427af286408c6'
flow=root/'build/python-first-tac106/owned-body-ink-floor-excludes-table-cell106.patch'
assert hashlib.sha256(flow.read_bytes()).hexdigest()=='d0aaa13e95d6a3d8873c63e93ce6c71453a1ce7d625afccb1552042b73055e48'
tests=root/os.environ['JUEONY_FLOW_TEST_PATCH']
assert hashlib.sha256(tests.read_bytes()).hexdigest()==os.environ['JUEONY_FLOW_TEST_SHA256']
canon=lambda p:p.read_bytes().replace(b'\r\n',b'\n').decode('utf8')
changed=sorted(set(re.findall(r'^\+\+\+ b/(.+)$',canon(reset)+canon(flow)+canon(tests),re.M)))
resource_path='src/model/native_computed_resource.rs'
for f in changed+[resource_path]:
 p=stage/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(canon(base/f),encoding='utf8',newline='\n')
for p in [reset,flow,tests]:
 cmd=['git','-C',str(root),'apply','--directory=build/storage107-logic-stage','--whitespace=error-all']
 subprocess.run(cmd+['--check',str(p)],check=True);subprocess.run(cmd+[str(p)],check=True)
resource=stage/resource_path;s=canon(resource)
existing=re.findall(r'\("([^"]+)",include_bytes!',s);assert len(existing)==225
added=[]
for f in changed:
 if f in existing or f.endswith('/tests.rs')or f.endswith('/integration_tests.rs')or '/issue_2439_lineseg_indent_tests.rs'in f:continue
 assert f.startswith('src/')
 line=f'            ("{f}",include_bytes!("../{f[4:]}").as_slice()),\n'
 marker='        ];\n';assert s.count(marker)==1;s=s.replace(marker,line+marker,1);added.append(f)
paths=re.findall(r'\("([^"]+)",include_bytes!',s);assert len(paths)==len(set(paths))==225+len(added)
runtime=[f for f in changed if not(f.endswith('/tests.rs')or f.endswith('/integration_tests.rs')or '/issue_2439_lineseg_indent_tests.rs'in f)]
assert set(runtime).issubset(paths)
h=hashlib.sha256(b'rhwp-portable-native-text-edit-frame-1;source-text-lf\0');records=[]
for f in paths:
 p=stage/f if(stage/f).is_file()else base/f;raw=p.read_bytes();data=raw.replace(b'\r\n',b'\n')
 h.update(f.encode());h.update(b'\0');h.update(len(data).to_bytes(8,'little'));h.update(data)
 records.append({'path':f,'canonicalBytes':len(data),'canonicalSha256':hashlib.sha256(data).hexdigest(),'rawSha256':hashlib.sha256(raw).hexdigest()})
s=re.sub(r'const RESOURCE:\[u8;32\]=\[[^;]+;', 'const RESOURCE:[u8;32]='+str(list(h.digest()))+';',s,count=1)
resource.write_text(s,encoding='utf8',newline='\n')
text=''
for f in changed+[resource_path]:
 text+=''.join(difflib.unified_diff(canon(base/f).splitlines(True),canon(stage/f).splitlines(True),fromfile='a/'+f,tofile='b/'+f))
p=root/'engine/patches'/('z'*98+'-local-reset-and-body-flow-storage.patch');assert not p.exists();p.write_text(text,encoding='utf8',newline='\n')
(root/'build/storage107-merged-resource.json').write_text(json.dumps({'resourceSha256':h.hexdigest(),'files':records,'addedInventoryPaths':added,'runtimeChangedPaths':runtime,'allChangedPaths':changed,'patchSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'baseSource':'fc150ef856868d03'},indent=2)+'\n',encoding='utf8')
print(json.dumps({'patch':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'resource':h.hexdigest(),'sourceFiles':len(paths),'added':added}))
