from pathlib import Path
import hashlib,json,re
root=Path(__file__).resolve().parents[1]
base=root/'build/rhwp-engine/source-fc150ef856868d03'
current=root/'build/rhwp-engine/source-4f37a374a34409e1'
stage=root/'build/storage107-logic-stage'
data=json.loads((root/'build/storage107-merged-resource.json').read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()
canonical=lambda p:p.read_bytes().replace(b'\r\n',b'\n')
diff=[]
for a in (base/'src').rglob('*.rs'):
 rel=a.relative_to(base);b=current/rel;assert b.is_file()
 if canonical(a)!=canonical(b):diff.append(rel.as_posix())
assert set(diff)==set(data['allChangedPaths'])|{'src/model/native_computed_resource.rs'}
assert all(canonical(stage/p)==canonical(current/p)for p in diff)
resource=current/'src/model/native_computed_resource.rs';text=resource.read_text(encoding='utf8')
paths=re.findall(r'\("([^"]+)",include_bytes!',text)
assert paths==[r['path']for r in data['files']]and len(set(paths))==230
h=hashlib.sha256(b'rhwp-portable-native-text-edit-frame-1;source-text-lf\0')
for r in data['files']:
 raw=canonical(current/r['path']);assert sha(raw)==r['canonicalSha256']
 h.update(r['path'].encode());h.update(b'\0');h.update(len(raw).to_bytes(8,'little'));h.update(raw)
assert h.hexdigest()==data['resourceSha256']
assert bytes(json.loads(re.search(r'const RESOURCE:\[u8;32\]=(\[[^;]+\]);',text)[1]))==h.digest()
(root/'build/storage107-official-source.json').write_text(json.dumps({'sourceId':'4f37a374a34409e1','canonicalRuntimeMatchesMergedStage':True,'changedFiles':diff,'canonicalUnchangedOtherRustFiles':len(list((base/'src').rglob('*.rs')))-len(diff),'sourceFiles':230,'resourceSha256':h.hexdigest(),'stage':data},indent=2)+'\n',encoding='utf8')
print('PASS actual prepared source: exact merged delta, no other Rust changes, 230 pipeline files bound')
