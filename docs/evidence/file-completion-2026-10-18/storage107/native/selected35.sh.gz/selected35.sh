#!/usr/bin/env bash
set -euo pipefail
root=/mnt/c/Users/jjome/Documents/work/jueony
export RUSTUP_HOME="$root/.tools/linux-rustup"
export CARGO_HOME="$root/.tools/linux-cargo"
export PATH="$CARGO_HOME/bin:$PATH"
export CARGO_TARGET_DIR=/tmp/jueony-rhwp-engine/target/storage105-root-only
if [ ! -d "$CARGO_TARGET_DIR" ]; then
  mkdir "$CARGO_TARGET_DIR"
  tar -C /tmp/jueony-rhwp-engine/target/negative-closure70 --exclude='*rhwp*' --exclude='incremental' -cf - . | tar -C "$CARGO_TARGET_DIR" -xf -
fi
cd "$root/build/rhwp-engine/source-4f37a374a34409e1"
cargo test --offline --locked -p rhwp --lib current_stored_margin_frame -j2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib native_empty_trailing105 -j2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib declared_object_cell_frame_106 -j2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib painted_flow_text_bottom_owner106_tests -j2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib native_computed_resource -j2 -- --nocapture --test-threads=1
