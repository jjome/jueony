# 본문 ink floor의 표·셀 소유 경계 cfg8

최종 `painted-flow-table-owner106-tests-v3.patch`는 `layout.rs` 내부 `cfg(test)` 모듈만 추가합니다. private `painted_flow_text_bottom`를 직접 호출하며 공개 API, 진단 wrapper, 로그 분기를 추가하지 않습니다. 기존 runtime two-arm patch 다음에 적용합니다. 공식111 및 공식113의 각 private 복사본에 strict 적용을 확인했습니다.

최종 Native는 실제로 8개 실행되어 8 PASS, 실패·무시 0입니다. 표/셀/중첩표 하위 글자 제외, 본문 음수 줄간격 ink 하한, 기존 TextBox 제외, 표 전후 본문 ink 유지, overflow cell의 별도 소유를 검사합니다.

이전 pure8의 caption 검사는 Table 아래 TextLine을 만든 합성 subtree 검사였습니다. 실제 `table_layout.rs`는 Table과 caption TextLine을 Column의 형제로 방출합니다. 따라서 이전 결과는 실제 모든 caption 제외의 근거가 아닙니다. 최종 검사는 실제 형제 구조와 `caption_owner` 및 cell path sentinel 65534를 구성하여 기존 Some(220) 동작이 유지됨을 명시합니다. caption 동작 변경은 없습니다. 일반 문서 caption 저장·지면 검증 완료를 주장하지 않습니다.

첫 private 준비에서 누락된 실제 baseline 테스트 모듈과 caption test import 오류를 별도 로그로 보존했습니다. 누락 자산은 기존 실제 fixture에서 private fork에만 복사했으며 이 묶음에는 상용/공개 문서나 폰트·전체 snapshot·binary를 포함하지 않습니다.

재현: runtime two-arm patch와 이 test-only patch를 공식 소스의 별도 복사본에 순서대로 적용한 뒤 `cargo test --offline --locked -p rhwp --lib painted_flow_text_bottom_owner106_tests -j2 -- --nocapture --test-threads=1`. 기존 실제 libtest assets가 필요하며 dummy fixture나 test skip을 사용하지 않았습니다. 전용 target `fragment105-conversion`에서 src/lib.rs를 갱신하여 실제 재컴파일했습니다.
