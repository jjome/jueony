from pathlib import Path
import os,subprocess
r=Path(__file__).resolve().parents[1]
args=[
'--engine','build/rhwp-engine/source-b20b9eb0ed097b92/pkg',
'--dist','apps/editor/evidence/dist-file-storage110',
'--output','build/file-storage110-workflows',
'--node','C:/Users/jjome/AppData/Local/Volta/tools/image/node/22.22.2/node.exe',
'--baseline-engine','build/rhwp-engine/source-7c10dba04ed65742/pkg',
'--frame-baseline-engine','build/rhwp-engine/source-3f07621d4728accf/pkg',
'--native-cell-source','build/hancom-final-file-review-20261017/source-python-hwpx-3.hwpx',
'--native-cell-oracle','build/hancom-final-file-review-20261017/python-hwpx-3-hwp-hancom.hwp',
'--floating-host-baseline','build/rhwp-engine/source-2feb978b45e2964e/pkg',
'--floating-host-source','build/hancom-final-file-review-20261017/source-mcst-bid-2026.hwp',
'--floating-host-oracle','build/hancom-final-file-review-20261017/mcst-bid-2026-hwpx-hancom.hwpx',
'--native-prefix-baseline','build/rhwp-engine/source-625990fd59af9440/pkg',
'--native-prefix-source','build/hancom-final-file-review-20261017/source-mcst-bid-2026.hwp',
'--python-edit-baseline','build/rhwp-engine/source-fc150ef856868d03/pkg',
'--python-edit-source','build/hancom-final-file-review-20261017/source-python-hwpx-3.hwpx',
'--python-edit-oracle','build/hancom-final-file-review-20261017/python-hwpx-3-hwp-hancom.hwp',
'--hwt-leaf',
]
env=dict(os.environ,JUEONY_PREVIEW_RAW_AUDITOR='/tmp/jueony-rhwp-engine/target/hwt-leaf115-rawaudit/debug/preview-raw-audit117')
with (r/'build/file-storage110-workflows.log').open('w',encoding='utf8')as f:
 p=subprocess.run(['C:/Python314/python.exe','-X','utf8','scripts/verify_file_workflows.py',*args],cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
raise SystemExit(p.returncode)
