from pathlib import Path
import difflib,hashlib,json,re,subprocess
r=Path(__file__).resolve().parents[1];base=r/'build/rhwp-engine/source-2a1d408f1d0d7ea5';baseline=r/'build/rhwp-engine/source-4f37a374a34409e1'
stage=r/'build/storage110-final-stage';stage.mkdir(exist_ok=False)
canon=lambda p:p.read_bytes().replace(b'\r\n',b'\n').decode('utf8')
sha=lambda b:hashlib.sha256(b).hexdigest()
legacy=r/'build/cross-standard-rows115/handoff-final/current-fresh-standard-rows115-final.patch'
preview=r/'build/hwt-leaf115/hwt-preview-utf16-and-repeat117.patch'
assert sha(legacy.read_bytes())=='ec59b498d64e44c317ceb3c7cd2ee7ec7b50e5e673edbadf0f2cb98950e17a05'
assert sha(preview.read_bytes())=='f0a0f45382147d183ded62ea18a815fb4dfb7680a866dc47b9786d70d6c932d9'
lp=json.loads((legacy.parent/'source-proof.json').read_bytes());pp=json.loads((preview.parent/'source-proof-preview117.json').read_bytes())
frame=lp['resourceScopeAllPaths'];assert len(frame)==8
metadata=[x['path']for x in pp['files']];assert len(metadata)==5
paths=sorted(set(frame+metadata));resource='src/model/native_computed_resource.rs';assert len(paths)==12
for f in paths+[resource]:
 if(base/f).is_file():
  p=stage/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(canon(base/f),encoding='utf8',newline='\n')
def apply(p):
 c=['git','-C',str(r),'apply','--directory='+stage.relative_to(r).as_posix(),'--whitespace=error-all']
 subprocess.run(c+['--check',str(p)],check=True);subprocess.run(c+[str(p)],check=True)
apply(legacy)
for x in lp['files']:assert sha(canon(stage/x['path']).encode())==x['canonicalSha256'],x['path']
# Keep all four non-overlapping preview changes exact. The sole overlapping
# serializer function receives the same metadata guard at its actual shared entry.
chunks=re.split(r'(?=^--- a/)',canon(preview),flags=re.M);assert len([c for c in chunks if c])==5
mod='src/serializer/hwpx/mod.rs';filtered=''.join(c for c in chunks if not c.startswith('--- a/'+mod+'\n'))
subset=r/'build/storage110-preview-nonoverlap.patch';subset.write_text(filtered,encoding='utf8',newline='\n');apply(subset)
for x in pp['files']:
 if x['path']!=mod:assert sha(canon(stage/x['path']).encode())==x['candidateCanonicalLfSha256'],x['path']
guard='''    // Malformed native preview bytes have an opaque HWP owner, not XML text.
    if doc.extra_streams.iter().any(|(path,raw)|path=="/PrvText"&&crate::parser::cfb_reader::decode_preview_utf16(raw).is_none()) {
        return Err(SerializeError::CfbError("HWPX_UNREPRESENTABLE_OPAQUE_PRVTEXT".into()));
    }

'''
old='        doc.hwpx_aux_entry("Preview/PrvText.txt")\n'
new=old+'            .or_else(||doc.preview.as_ref().and_then(|p|p.text.as_deref()).map(str::as_bytes))\n'
orig=canon(base/mod);assert orig.count('    use static_assets::*;\n')==1 and orig.count(old)==1
standalone=orig.replace('    use static_assets::*;\n','    use static_assets::*;\n'+guard).replace(old,new)
assert sha(standalone.encode())==next(x['candidateCanonicalLfSha256']for x in pp['files']if x['path']==mod)
s=canon(stage/mod);entry='pub(crate) fn serialize_hwpx_with_current_rows(doc:&Document,projection:Option<&standard_rows::CurrentStandardRowsProjection>)->Result<SerializedDocument,SerializeError>{\n    use static_assets::*;\n'
assert s.count(entry)==1 and s.count(old)==1;s=s.replace(entry,entry+guard).replace(old,new)
assert s.count('HWPX_UNREPRESENTABLE_OPAQUE_PRVTEXT')==1
(stage/mod).write_text(s,encoding='utf8',newline='\n')
# HWT/free byte APIs and preview-only metadata are outside the physical-row
# dependency cohort. Restore the original230 and add actual new planner inputs,
# including the canonical Native CommonObjAttr packing function it calls.
s=canon(baseline/resource);existing=re.findall(r'\("([^"]+)",include_bytes!',s);assert len(existing)==230
for f in existing:assert canon(base/f)==canon(baseline/f),f
additional=frame+['src/serializer/control.rs'];added=[]
for f in additional:
 if f not in existing:
  line=f'            ("{f}",include_bytes!("../{f[4:]}").as_slice()),\n'
  assert s.count('        ];\n')==1;s=s.replace('        ];\n',line+'        ];\n');existing.append(f);added.append(f)
inputs=re.findall(r'\("([^"]+)",include_bytes!',s);assert len(inputs)==len(set(inputs))==len(existing)
assert 'src/lib.rs'not in inputs and'src/hwt_leaf115.rs'not in inputs
h=hashlib.sha256(b'rhwp-portable-native-text-edit-frame-1;source-text-lf\0');records=[]
for f in inputs:
 p=stage/f if(stage/f).is_file()else base/f;b=canon(p).encode();h.update(f.encode());h.update(b'\0');h.update(len(b).to_bytes(8,'little'));h.update(b)
 records.append({'path':f,'canonicalBytes':len(b),'canonicalSha256':sha(b)})
s=re.sub(r'const RESOURCE:\[u8;32\]=\[[^;]+;','const RESOURCE:[u8;32]='+str(list(h.digest()))+';',s,count=1)
(stage/resource).write_text(s,encoding='utf8',newline='\n')
out=''
for f in paths+[resource]:
 before=canon(base/f)if(base/f).is_file()else''
 out+=''.join(difflib.unified_diff(before.splitlines(True),canon(stage/f).splitlines(True),fromfile='a/'+f if before else'/dev/null',tofile='b/'+f))
p=r/'engine/patches'/('z'*101+'-current-standard-rows-and-preview-storage.patch');assert not p.exists();p.write_text(out,encoding='utf8',newline='\n')
proof={'baseSource':'2a1d408f1d0d7ea5','patchSha256':sha(p.read_bytes()),'resourceSha256':h.hexdigest(),'resourceFiles':records,'addedFrameInputs':added,'allChangedPaths':paths+[resource],'runtimeChanges':[{'path':f,'canonicalSha256':sha(canon(stage/f).encode())}for f in paths], 'overlapResolution':'Exact preview delta relocated once to actual serialize_hwpx_with_current_rows entry; auxiliary preview precedence unchanged; no other source edits.'}
(r/'build/storage110-merged-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8');print(json.dumps({'patch':str(p),'sha256':proof['patchSha256'],'resource':h.hexdigest(),'inputs':len(inputs),'added':added}))
