from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parents[1]; base=r/'build/rhwp-engine/source-2a1d408f1d0d7ea5'; actual=r/'build/rhwp-engine/source-b20b9eb0ed097b92'; stage=r/'build/storage110-final-stage'
canon=lambda p:p.read_bytes().replace(b'\r\n',b'\n')
m=json.loads((r/'build/storage110-merged-proof.json').read_bytes()); expected=set(m['allChangedPaths']); unchanged=0
source_paths=set(p.relative_to(base).as_posix() for p in(base/'src').rglob('*.rs'))
assert set(p.relative_to(actual).as_posix() for p in(actual/'src').rglob('*.rs'))==source_paths|expected
records=[]
for f in sorted(source_paths|expected):
 if f in expected:
  assert canon(actual/f)==canon(stage/f),f
  records.append({'path':f,'canonicalSha256':hashlib.sha256(canon(actual/f)).hexdigest()})
 else:
  assert canon(actual/f)==canon(base/f),f
  unchanged+=1
h=hashlib.sha256(b'rhwp-portable-native-text-edit-frame-1;source-text-lf\0')
for f in m['resourceFiles']:
 b=canon(actual/f['path']);assert hashlib.sha256(b).hexdigest()==f['canonicalSha256'],f['path']
 h.update(f['path'].encode());h.update(b'\0');h.update(len(b).to_bytes(8,'little'));h.update(b)
assert h.hexdigest()==m['resourceSha256']
out={'baseSource':m['baseSource'],'sourceId':actual.name.removeprefix('source-'),'changedFiles':records,'unchangedOtherRust':unchanged,'resourceSha256':h.hexdigest(),'resourceFiles':len(m['resourceFiles']),'unexpectedChanges':[]}
(r/'build/storage110-official-source.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf8');print(json.dumps(out))
