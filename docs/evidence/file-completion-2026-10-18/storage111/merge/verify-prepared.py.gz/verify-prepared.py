from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parents[1];base=r/'build/rhwp-engine/source-b20b9eb0ed097b92';actual=r/'build/rhwp-engine/source-b443fe8f896f3e7b'
canon=lambda p:p.read_bytes().replace(b'\r\n',b'\n')
m=json.loads((r/'build/stored-time-transaction111/handoff-final/source-proof.json').read_bytes());expected={x['path']:x['canonicalSha256']for x in m['files']}
basepaths={p.relative_to(base).as_posix()for p in(base/'src').rglob('*.rs')}
assert {p.relative_to(actual).as_posix()for p in(actual/'src').rglob('*.rs')}==basepaths|set(expected)
unchanged=0
for f in sorted(basepaths|set(expected)):
 if f in expected:assert hashlib.sha256(canon(actual/f)).hexdigest()==expected[f],f
 else:assert canon(actual/f)==canon(base/f),f;unchanged+=1
old=json.loads((r/'build/storage110-merged-proof.json').read_bytes());h=hashlib.sha256(b'rhwp-portable-native-text-edit-frame-1;source-text-lf\0')
for f in old['resourceFiles']:
 b=canon(actual/f['path']);assert hashlib.sha256(b).hexdigest()==f['canonicalSha256'],f['path']
 h.update(f['path'].encode());h.update(b'\0');h.update(len(b).to_bytes(8,'little'));h.update(b)
assert h.hexdigest()==old['resourceSha256'];assert not set(expected)&{f['path']for f in old['resourceFiles']}
out={'baseSource':'b20b9eb0ed097b92','sourceId':'b443fe8f896f3e7b','changedFiles':expected,'unchangedOtherRust':unchanged,'resourceFiles':len(old['resourceFiles']),'resourceSha256':h.hexdigest(),'unexpectedChanges':[],'scope':'Typed stored-time metadata and its explicit WASM API only; all physical row inputs and resource bytes unchanged. Full patch/WASM identity remains separately attested.'}
(r/'build/storage111-official-source.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf8');print(json.dumps(out))
