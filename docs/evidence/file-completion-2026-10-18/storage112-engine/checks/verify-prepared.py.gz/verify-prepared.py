from pathlib import Path
import hashlib,json,re
r=Path(__file__).resolve().parents[1]
base=r/'build/rhwp-engine/source-b443fe8f896f3e7b';actual=r/'build/rhwp-engine/source-704c7d510eb58bc2'
m=json.loads((r/'build/storage112-merged-proof.json').read_bytes());expected=m['changedFiles']
canon=lambda p:p.read_bytes().replace(b'\r\n',b'\n')
sha=lambda b:hashlib.sha256(b).hexdigest()
oldpaths={p.relative_to(base).as_posix()for p in(base/'src').rglob('*.rs')}
newpaths={p.relative_to(actual).as_posix()for p in(actual/'src').rglob('*.rs')}
assert newpaths==oldpaths|set(expected)
unchanged=0
for p in sorted(newpaths):
 if p in expected:assert sha(canon(actual/p))==expected[p],p
 else:assert canon(actual/p)==canon(base/p),p;unchanged+=1
h=hashlib.sha256(b'rhwp-portable-native-text-edit-frame-1;source-text-lf\0')
for f in m['resourceFiles']:
 p=f['path'];b=canon(actual/p);assert sha(b)==f['canonicalSha256'],p
 h.update(p.encode());h.update(b'\0');h.update(len(b).to_bytes(8,'little'));h.update(b)
assert h.hexdigest()==m['resourceSha256']
resource=canon(actual/'src/model/native_computed_resource.rs').decode()
assert re.findall(r'\("([^"]+)",include_bytes!',resource)==[f['path']for f in m['resourceFiles']]
assert bytes(map(int,re.search(r'const RESOURCE:\[u8;32\]=\[([^]]+)\]',resource)[1].split(',')))==h.digest()
out={'baseSourceId':m['baseSourceId'],'sourceId':'704c7d510eb58bc2','changedFiles':expected,'unchangedOtherRust':unchanged,'unexpectedChanges':[],'resourceCount':len(m['resourceFiles']),'resourceSha256':h.hexdigest(),'compiledRawHashes':{p:sha((actual/p).read_bytes())for p in expected}}
(r/'build/storage112-official-source.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf8')
print(json.dumps(out))
