use rhwp::DocumentCore;
use serde_json::{json,Value};
use sha2::{Digest,Sha256};
use std::path::PathBuf;

fn root()->PathBuf {PathBuf::from(std::env::var("ST112_ROOT").unwrap())}
fn out()->PathBuf {let p=PathBuf::from(std::env::var("ST112_OUT").unwrap());std::fs::create_dir_all(&p).unwrap();p}
fn hash(b:&[u8])->String {Sha256::digest(b).iter().map(|b|format!("{b:02x}")).collect()}
fn layout(d:&DocumentCore)->Value {Value::Array((0..d.page_count()).map(|p|json!({"text":serde_json::from_str::<Value>(&d.get_page_text_layout_native(p).unwrap()).unwrap(),"controls":serde_json::from_str::<Value>(&d.get_page_control_layout_native(p).unwrap()).unwrap()})).collect())}
fn state(d:&DocumentCore)->Value {json!({"metadata":serde_json::from_str::<Value>(&d.get_document_metadata_native()).unwrap(),"stored":serde_json::from_str::<Value>(&d.get_document_stored_information_native()).unwrap(),"cursor":serde_json::from_str::<Value>(&d.get_cursor_model_json()).unwrap(),"events":d.serialize_event_log(),"layout":layout(d),"rawDocument":format!("{:?}",d.document())})}
fn story(d:&DocumentCore)->Value {serde_json::from_str(&d.get_document_story_information_native().unwrap()).unwrap()}
fn times(d:&DocumentCore)->Value {let v:Value=serde_json::from_str(&d.get_document_stored_information_native()).unwrap();json!({"created":v["created"],"modified":v["modified"],"lastPrinted":v["lastPrinted"],"editingDuration":v["editingDuration"],"issues":v["issues"]})}
fn metadata(d:&DocumentCore)->Value {serde_json::from_str::<Value>(&d.get_document_metadata_native()).unwrap()["values"].clone()}
fn geometry_diff(a:&Value,b:&Value,p:&str,out:&mut Vec<Value>){match(a,b){
    (Value::Object(a),Value::Object(b))=>for key in a.keys().chain(b.keys()).collect::<std::collections::BTreeSet<_>>(){match(a.get(key),b.get(key)){(Some(a),Some(b))=>geometry_diff(a,b,&format!("{p}/{key}"),out),_=>out.push(json!({"path":p,"kind":"missing"}))}},
    (Value::Array(a),Value::Array(b))=>{if a.len()!=b.len(){out.push(json!({"path":p,"before":a.len(),"after":b.len()}));}for(i,(a,b))in a.iter().zip(b).enumerate(){geometry_diff(a,b,&format!("{p}/{i}"),out)}},
    (Value::Number(a),Value::Number(b))=>if (a.as_f64().unwrap()-b.as_f64().unwrap()).abs()>0.2{out.push(json!({"path":p,"before":a,"after":b}));},
    _=>if a!=b{out.push(json!({"path":p,"before":a,"after":b}));}
}}
fn assert_layout(a:&Value,b:&Value){let mut diff=vec![];geometry_diff(a,b,"$",&mut diff);assert!(diff.is_empty(),"published geometry: {} {:?}",diff.len(),diff.first());}
fn fixture(name:&str)->DocumentCore {
    let mut d=if name.starts_with("blank") {let mut d=DocumentCore::new_empty();d.create_blank_document_native().unwrap();d.insert_text_native(0,0,0,"Own stamped-export immutable source.").unwrap();d}
    else if name.starts_with("prefix") {let p=root().join("docs/evidence/file-completion-2026-10-18/engine76/columns-native/fixtures/build/file-closure69-public/column2-candidate74/valid-negative-disk/baseline-single_column.hwp");let b=std::fs::read(p).unwrap();assert_eq!(hash(&b),"9778d66926e3138ce4bb51fadfd16173ee3d439aeec0a02a8f0af34b7fac0f3b");let mut d=DocumentCore::from_bytes(&b).unwrap();let end=d.document().sections[0].paragraphs[0].text.chars().count();d.insert_text_native(0,0,end,&"앞 문단 줄바꿈을 유발하는 본문입니다. ".repeat(25)).unwrap();d}
    else {DocumentCore::from_bytes(&std::fs::read(root().join("build/cross-standard-rows115/actual-mixed-old113-with-descriptor-removed.hwpx-1.hwp")).unwrap()).unwrap()};
    if name.ends_with("xml"){let a=d.export_hwpx_native_with_report().unwrap();assert_eq!(a.content_loss().len(),0);d=DocumentCore::from_bytes(a.bytes()).unwrap();}d
}
const FIXTURES:[&str;5]=["blank-native","blank-xml","prefix-native","prefix-xml","mixed-native"];
fn write_report(name:&str,value:Value){std::fs::write(out().join(format!("{name}.json")),serde_json::to_vec_pretty(&value).unwrap()).unwrap();}

#[test]
fn ordinary_none_export_observations_are_unchanged(){
    let mut observations=vec![];
    for name in FIXTURES {let d=fixture(name);let before=state(&d);let source_story=story(&d);let source_times=times(&d);let source_metadata=metadata(&d);
        for format in ["hwp","hwpx"] {let a=if format=="hwp"{d.export_hwp_with_adapter_snapshot_with_report().unwrap()}else{d.export_hwpx_native_with_report().unwrap()};assert_eq!(a.content_loss().len(),0);let p=out().join(format!("ordinary-{name}.{format}"));std::fs::write(&p,a.bytes()).unwrap();let b=std::fs::read(&p).unwrap();assert_eq!(b,a.bytes());let n=DocumentCore::from_bytes(&b).unwrap();assert_layout(&before["layout"],&layout(&n));assert_eq!(source_story,story(&n));assert_eq!(source_times,times(&n));assert_eq!(source_metadata,metadata(&n));assert_eq!(before,state(&d));observations.push(json!({"fixture":name,"format":format,"sha256":hash(&b),"bytes":b.len(),"sourceUnchanged":true,"information":times(&n),"metadata":metadata(&n),"stories":story(&n),"layout":layout(&n)}));}
    }
    write_report("ordinary",json!({"observations":observations}));
}

#[cfg(feature="candidate")]
fn request()->String {json!({"schemaVersion":1,"values":{"modified":"133536420007654321","editingDuration":"123456789012345"}}).to_string()}
#[cfg(feature="candidate")]
fn token(d:&DocumentCore)->String {serde_json::from_str::<Value>(&d.get_document_stored_information_edit_state_native()).unwrap()["fingerprint"].as_str().unwrap().to_owned()}

#[cfg(feature="candidate")]
#[test]
fn stamped_exports_keep_original_and_expected_geometry_for_all_four_report_paths(){
    let mut results=vec![];let mut failures=vec![];
    for name in FIXTURES {let d=fixture(name);let before=state(&d);let expected_story=story(&d);let expected_metadata=metadata(&d);
        for format in ["hwp","hwpx"] {for password in [None,Some(b"own112-password".as_slice())] {
            let ordinary=match(format,password){("hwp",None)=>d.export_hwp_with_adapter_snapshot_with_report(),("hwp",Some(p))=>d.export_hwp_with_adapter_snapshot_with_password_and_report(p),("hwpx",None)=>d.export_hwpx_native_with_report(),("hwpx",Some(p))=>d.export_hwpx_native_with_password_and_report(p),_=>unreachable!()}.unwrap();
            let ordinary_loss:Value=serde_json::from_str(&ordinary.content_loss().to_json()).unwrap();
            let mut case=json!({"fixture":name,"format":format,"password":password.is_some(),"ordinaryLoss":ordinary_loss});
            let attempt=std::panic::catch_unwind(std::panic::AssertUnwindSafe(||{
                let (a,intent)=d.export_stamped_stored_information_native(format,&token(&d),&request(),password).unwrap();let intent:Value=serde_json::from_str(&intent).unwrap();case["loss"]=serde_json::from_str(&a.content_loss().to_json()).unwrap();
                assert_eq!(case["loss"],ordinary_loss,"new stamped path changed ordinary loss report");
                assert_eq!(intent["originalFingerprint"],token(&d));assert_eq!(intent["requestedValues"]["modified"],"133536420007654321");assert_eq!(intent["requestedValues"]["editingDuration"],"123456789012345");assert_eq!(intent["before"],before["stored"]);if a.content_loss().len()!=0 {
                    assert!(name.starts_with("prefix") && format=="hwp" && password.is_some(),"unexpected blocked path");
                    assert_eq!(a.content_loss().len(),1);
                    assert_eq!(case["loss"]["losses"][0]["path"],"/RhwpComputedNativeRowsV1");
                    assert_eq!(case["loss"]["losses"][0]["reason"],"serializerNotImplemented");
                    case["status"]=json!("BLOCKED");return;
                }assert_eq!(before,state(&d));
                let p=out().join(format!("stamped-{name}-{}.{format}",if password.is_some(){"password"}else{"plain"}));std::fs::write(&p,a.bytes()).unwrap();let b=std::fs::read(&p).unwrap();assert_eq!(b,a.bytes());let n=if let Some(password)=password {DocumentCore::from_bytes_with_password(&b,password).unwrap()}else{DocumentCore::from_bytes(&b).unwrap()};assert_layout(&before["layout"],&layout(&n));assert_eq!(expected_story,story(&n));assert_eq!(expected_metadata,metadata(&n));let actual=times(&n);for key in ["created","modified","lastPrinted","editingDuration","issues"]{assert_eq!(intent["after"][key],actual[key],"{name}/{format}/{key}");}assert_eq!(before,state(&d));case["sha256"]=json!(hash(&b));case["intent"]=intent;case["layout"]=layout(&n);
            }));
            assert_eq!(before,state(&d),"source changed after test or error");case["sourceUnchanged"]=json!(true);
            if attempt.is_ok(){if case["status"]!="BLOCKED"{case["status"]=json!("PASS");}}else{case["status"]=json!("FAIL");failures.push(json!({"fixture":name,"format":format,"password":password.is_some(),"loss":case["loss"],"ordinaryLoss":ordinary_loss}));}
            results.push(case);
        }}
    }let supported=results.iter().filter(|v|v["status"]=="PASS").count();let blocked=results.iter().filter(|v|v["status"]=="BLOCKED").count();write_report("stamped",json!({"cases":results,"failures":failures,"successfulDiskExports":supported,"blockedBeforeWrite":blocked}));assert!(failures.is_empty(),"stamped matrix failures {}",failures.len());assert_eq!(supported,18);assert_eq!(blocked,2);
}

#[cfg(feature="candidate")]
#[test]
fn malformed_stale_format_and_actual_serializer_failures_leave_original_unchanged(){
    let mut d=fixture("blank-native");let before=state(&d);for(format,owner,source)in [("hwp",token(&d),"{}".to_owned()),("hwpx","0".repeat(64),request()),("txt",token(&d),request())]{assert!(d.export_stamped_stored_information_native(format,&owner,&source,None).is_err());assert_eq!(before,state(&d));}
    // A real optional-preview ownership failure occurs inside both ordinary
    // serializers after the valid time intent is prepared. The source is never
    // swapped, so even that late failure cannot leave stamped metadata behind.
    d.document_mut().extra_streams.push(("/PrvText".into(),vec![0xff]));let before=state(&d);
    for format in ["hwp","hwpx"] {let error=d.export_stamped_stored_information_native(format,&token(&d),&request(),None).err().unwrap().to_string();assert!(error.contains("PRVTEXT"),"{error}");assert_eq!(before,state(&d));}
}

#[cfg(feature="candidate")]
#[test]
fn source_snapshot_history_and_queries_are_not_stamped(){
    let mut d=fixture("blank-native");let first=d.save_snapshot_native();let original=times(&d);d.insert_text_native(0,0,0,"history retained ").unwrap();let second=d.save_snapshot_native();let current=state(&d);
    for format in ["hwp","hwpx"]{let(_a,_)=d.export_stamped_stored_information_native(format,&token(&d),&request(),None).unwrap();assert_eq!(state(&d),current);}
    d.restore_snapshot_native(first).unwrap();assert_eq!(times(&d),original);d.restore_snapshot_native(second).unwrap();assert_eq!(times(&d),original);assert_eq!(state(&d)["metadata"],current["metadata"]);assert_eq!(state(&d)["stored"],current["stored"]);assert_layout(&state(&d)["layout"],&current["layout"]);
}

#[test]
fn compiled_official119_source_witnesses() {
 use sha2::{Digest,Sha256};
 assert_eq!(format!("{}",Sha256::digest(include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"),"/../../rhwp-engine/source-704c7d510eb58bc2/src/document_core/document_metadata_stamped_export.rs"))).iter().map(|b|format!("{b:02x}")).collect::<String>()),"418833f6ed6b78cb5f3982d1b8c7c9fdf8550d91bd436043dcd54b2ae659e9d5");
 assert_eq!(format!("{}",Sha256::digest(include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"),"/../../rhwp-engine/source-704c7d510eb58bc2/src/document_core/document_metadata_stored_transaction.rs"))).iter().map(|b|format!("{b:02x}")).collect::<String>()),"04ecfef25027e572bd6520c9a5e07207816290d04033b26e6ac87dcd0c768795");
 assert_eq!(format!("{}",Sha256::digest(include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"),"/../../rhwp-engine/source-704c7d510eb58bc2/src/document_core/document_metadata_stored.rs"))).iter().map(|b|format!("{b:02x}")).collect::<String>()),"d8e61325d707b46a6eceb9a19c26347c21706d83c4056c7309e90294f3600f5f");
 assert_eq!(format!("{}",Sha256::digest(include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"),"/../../rhwp-engine/source-704c7d510eb58bc2/src/document_core/document_metadata.rs"))).iter().map(|b|format!("{b:02x}")).collect::<String>()),"06a80c6e061953f7b3a25329bea5d80b002a58cd833a20ac297d9d879e13057f");
 assert_eq!(format!("{}",Sha256::digest(include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"),"/../../rhwp-engine/source-704c7d510eb58bc2/src/document_core/commands/document.rs"))).iter().map(|b|format!("{b:02x}")).collect::<String>()),"6c2e6962b26474b11b1d66ad3a260c2fb37856161e46152adb9742a909efdd2b");
 assert_eq!(format!("{}",Sha256::digest(include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"),"/../../rhwp-engine/source-704c7d510eb58bc2/src/wasm_api.rs"))).iter().map(|b|format!("{b:02x}")).collect::<String>()),"3cd052e6301944487216675804ff0ca867dae683eb536ecf3e47ae9564116ea3");
 assert_eq!(format!("{}",Sha256::digest(include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"),"/../../rhwp-engine/source-704c7d510eb58bc2/src/model/native_computed_resource.rs"))).iter().map(|b|format!("{b:02x}")).collect::<String>()),"ab086f6e75f250fa41589e84c74dc71a2598f368785623cedce2785bfc024d10");
}
