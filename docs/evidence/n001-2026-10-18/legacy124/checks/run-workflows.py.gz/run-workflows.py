from pathlib import Path
import ast,os,subprocess
r=Path(__file__).resolve().parents[1];mirror=r/'build/n001-clean-review123'
tree=ast.parse((r/'build/run-storage111-workflows.py').read_text(encoding='utf8'))
args=next(ast.literal_eval(n.value)for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='args'for t in n.targets))
values={'--engine':'build/rhwp-engine/source-587008f751f4f6dc/pkg','--dist':'build/n001-clean-review123/apps/editor/evidence/dist-n001-engine124','--output':'build/n001-final124-workflows'}
for i,v in enumerate(args):
 if v in values:args[i+1]=values[v]
 if v.startswith('--')and i+1<len(args)and not args[i+1].startswith('--')and v!='--node':args[i+1]=str(r/args[i+1])
args+=['--encrypted-native-rows','--legacy-native-row-archive']
env=dict(os.environ,JUEONY_PREVIEW_RAW_AUDITOR='/tmp/jueony-rhwp-engine/target/hwt-leaf115-rawaudit/debug/preview-raw-audit117')
with(r/'build/n001-final124-workflows.log').open('w',encoding='utf8')as f:
 p=subprocess.run(['C:/Python314/python.exe','-X','utf8',str(mirror/'scripts/verify_file_workflows.py'),*args],cwd=mirror,env=env,stdout=f,stderr=subprocess.STDOUT)
raise SystemExit(p.returncode)
