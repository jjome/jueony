use rhwp::DocumentCore;
use serde_json::{json,Value};
use sha2::{Digest,Sha256};
use std::{path::PathBuf,io::{Cursor,Read}};
const ACTIVE:&str="/RhwpComputedNativeRowsV1";
const ARCHIVE:&str="/RhwpArchivedNativeRowsV1";
const ZIP:&str="META-INF/rhwp-opaque-native-row-stream-v1.bin";
fn hash(b:&[u8])->String{Sha256::digest(b).iter().map(|b|format!("{b:02x}")).collect()}
fn stream(b:&[u8],path:&str)->Vec<u8>{let mut c=cfb::CompoundFile::open(Cursor::new(b.to_vec())).unwrap();let mut v=vec![];c.open_stream(path).unwrap().read_to_end(&mut v).unwrap();v}
fn payload(b:&[u8],format:&str,pwd:Option<&[u8]>)->Vec<u8>{
 if format=="hwpx"{let bytes=if let Some(p)=pwd{rhwp::password_crypto::decrypt_hwpx_package(b,p).unwrap().expect("encrypted HWPX package")}else{b.to_vec()};let mut z=zip::ZipArchive::new(Cursor::new(bytes)).unwrap();let mut raw=vec![];z.by_name(ZIP).unwrap().read_to_end(&mut raw).unwrap();raw}
 else{
 let mut c=cfb::CompoundFile::open(Cursor::new(b.to_vec())).unwrap();
 if c.is_stream(ACTIVE){return stream(b,ACTIVE);}
 let raw=stream(b,ARCHIVE);let plain=if let Some(p)=pwd{rhwp::password_crypto::decrypt_hwp5_stream(&raw,p)}else{raw};assert_eq!(&plain[..16],b"RHWP-OPAQUE-ROW\0");assert_eq!(u32::from_le_bytes(plain[16..20].try_into().unwrap()),1);let n=u64::from_le_bytes(plain[20..28].try_into().unwrap())as usize;assert_eq!(plain.len(),60+n);assert_eq!(&plain[28..60],Sha256::digest(&plain[60..]).as_slice());plain[60..].to_vec()}
}
fn layout(d:&DocumentCore)->Value{Value::Array((0..d.page_count()).map(|p|json!({"text":serde_json::from_str::<Value>(&d.get_page_text_layout_native(p).unwrap()).unwrap(),"controls":serde_json::from_str::<Value>(&d.get_page_control_layout_native(p).unwrap()).unwrap()})).collect())}
fn diff(a:&Value,b:&Value,p:&str,out:&mut Vec<Value>){match(a,b){(Value::Object(a),Value::Object(b))=>for k in a.keys().chain(b.keys()).collect::<std::collections::BTreeSet<_>>(){match(a.get(k),b.get(k)){(Some(a),Some(b))=>diff(a,b,&format!("{p}/{k}"),out),_=>out.push(json!({"path":p,"kind":"missing"}))}},(Value::Array(a),Value::Array(b))=>{if a.len()!=b.len(){out.push(json!({"path":p,"before":a.len(),"after":b.len()}));}for(i,(a,b))in a.iter().zip(b).enumerate(){diff(a,b,&format!("{p}/{i}"),out)}},(Value::Number(a),Value::Number(b))=>if(a.as_f64().unwrap()-b.as_f64().unwrap()).abs()>0.2{out.push(json!({"path":p,"before":a,"after":b}));},_=>if a!=b{out.push(json!({"path":p,"before":a,"after":b}));}}}
#[test]fn legacy119_edit_then_both_plain_and_encrypted_formats_keep_geometry_and_passive_inner_bytes(){
 let root=PathBuf::from(std::env::var("ST112_ROOT").unwrap());let out=root.join("build/opaque-native-archive122/native-first");std::fs::create_dir_all(&out).unwrap();let mut cases=vec![];let mut failures=vec![];
 for name in ["ordinary-prefix-native.hwp","stamped-prefix-native-plain.hwp"]{
  let input=std::fs::read(root.join("build/stamped-export112/official119-native-dedicated").join(name)).unwrap();let original=stream(&input,ACTIVE);let mut d=DocumentCore::from_bytes(&input).unwrap();let end=d.document().sections[0].paragraphs[0].text.chars().count();d.insert_text_native(0,0,end," Compatibility retained body edit.").unwrap();let before=layout(&d);let source=format!("{:?}",d.document());
  for format in ["hwp","hwpx"]{for pwd in [None,Some(b"own122-password".as_slice())]{
   let a=match(format,pwd){("hwp",None)=>d.export_hwp_with_adapter_snapshot_with_report().unwrap(),("hwp",Some(p))=>d.export_hwp_with_adapter_snapshot_with_password_and_report(p).unwrap(),("hwpx",None)=>d.export_hwpx_native_with_report().unwrap(),("hwpx",Some(p))=>d.export_hwpx_native_with_password_and_report(p).unwrap(),_=>unreachable!()};assert_eq!(a.content_loss().len(),0);assert_eq!(payload(a.bytes(),format,pwd),original);assert_eq!(source,format!("{:?}",d.document()));
   let path=out.join(format!("{name}-{}.{format}",if pwd.is_some(){"encrypted"}else{"plain"}));std::fs::write(&path,a.bytes()).unwrap();let disk=std::fs::read(path).unwrap();assert_eq!(disk,a.bytes());let n=if let Some(p)=pwd{DocumentCore::from_bytes_with_password(&disk,p).unwrap()}else{DocumentCore::from_bytes(&disk).unwrap()};let mut differences=vec![];diff(&before,&layout(&n),"$",&mut differences);let passive=if format=="hwp"{
    let active=n.document().extra_streams.iter().find(|(p,_)|p==ACTIVE).expect("original Native active opaque owner remains at same path");active.1.clone()
   }else{assert!(!n.document().extra_streams.iter().any(|(p,_)|p==ACTIVE));n.document().hwpx_aux_entries.iter().find(|(p,_)|p==ZIP).unwrap().1.clone()};assert_eq!(passive,original);
   let ok=differences.is_empty();if !ok{failures.push(json!({"input":name,"format":format,"password":pwd.is_some(),"geometry":differences}));}cases.push(json!({"input":name,"format":format,"password":pwd.is_some(),"geometryDifferences":differences,"opaqueSha256":hash(&passive),"sourceUnchanged":true,"status":if ok{"PASS"}else{"FAIL"}}));
  }}
 }
 std::fs::write(out.join("result.json"),serde_json::to_vec_pretty(&json!({"cases":cases,"failures":failures})).unwrap()).unwrap();assert!(failures.is_empty());
}
