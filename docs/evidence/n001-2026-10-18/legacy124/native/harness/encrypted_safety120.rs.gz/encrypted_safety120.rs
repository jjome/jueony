use rhwp::DocumentCore;
use serde_json::{json,Value};
use std::io::{Cursor,Read,Write};
const STREAM:&str="/RhwpComputedNativeRowsV1";
const PASSWORD:&[u8]=b"own120-password";
fn stream(b:&[u8],path:&str)->Vec<u8>{let mut c=cfb::CompoundFile::open(Cursor::new(b.to_vec())).unwrap();let mut v=vec![];c.open_stream(path).unwrap().read_to_end(&mut v).unwrap();v}
fn replace(b:&[u8],path:&str,value:&[u8])->Vec<u8>{let mut c=cfb::CompoundFile::open(Cursor::new(b.to_vec())).unwrap();{let mut s=c.create_stream(path).unwrap();s.write_all(value).unwrap();}c.into_inner().into_inner()}
fn fixture(extra:&str)->DocumentCore{
 let mut d=DocumentCore::new_empty();d.create_blank_document_native().unwrap();d.insert_text_native(0,0,0,"Own authored completed-row fixture. ").unwrap();
 let a=d.export_hwp_with_adapter_snapshot_with_report().unwrap();assert_eq!(a.content_loss().len(),0);let mut d=DocumentCore::from_bytes(a.bytes()).unwrap();
 // This fixture explicitly authors current source LINE_SEG implementation tags;
 // parse/reopen supplies source ownership. It cannot set private CompletedRows.
 for r in &mut d.document_mut().sections[0].paragraphs[0].line_segs{r.tag=0x80060000;}
 let a=d.export_hwp_with_adapter_snapshot_with_report().unwrap();assert_eq!(a.content_loss().len(),0);let mut d=DocumentCore::from_bytes(a.bytes()).unwrap();
 let end=d.document().sections[0].paragraphs[0].text.chars().count();d.insert_text_native(0,0,end,&format!("{}{}", "Own long prefix causing current recomposition. ".repeat(25),extra)).unwrap();d
}
fn encrypted(d:&DocumentCore,pwd:&[u8])->Vec<u8>{let a=d.export_hwp_with_adapter_snapshot_with_password_and_report(pwd).unwrap();assert_eq!(a.content_loss().len(),0,"{}",a.content_loss().to_json());a.bytes().to_vec()}
fn layout(d:&DocumentCore)->Value{Value::Array((0..d.page_count()).map(|p|json!({"text":serde_json::from_str::<Value>(&d.get_page_text_layout_native(p).unwrap()).unwrap(),"controls":serde_json::from_str::<Value>(&d.get_page_control_layout_native(p).unwrap()).unwrap()})).collect())}
fn state(d:&DocumentCore)->Value{json!({"raw":format!("{:?}",d.document()),"events":d.serialize_event_log(),"layout":layout(d),"metadata":d.get_document_metadata_native(),"stored":d.get_document_stored_information_native(),"cursor":d.get_cursor_model_json()})}
fn semantics(d:&DocumentCore)->Value{let info:Value=serde_json::from_str(&d.get_document_stored_information_native()).unwrap();json!({"story":serde_json::from_str::<Value>(&d.get_document_story_information_native().unwrap()).unwrap(),"meta":serde_json::from_str::<Value>(&d.get_document_metadata_native()).unwrap()["values"],"time":{ "created":info["created"],"modified":info["modified"],"lastPrinted":info["lastPrinted"],"editingDuration":info["editingDuration"]}})}
fn report(name:&str,v:Value){let out=std::path::PathBuf::from(std::env::var("ENC120_DIR").unwrap());std::fs::create_dir_all(&out).unwrap();std::fs::write(out.join(format!("{name}.json")),serde_json::to_vec_pretty(&v).unwrap()).unwrap();}
#[test]fn own_encrypted_descriptor_is_ciphertext_and_roundtrips_current_rows(){
 let d=fixture("");let before=state(&d);let sem=semantics(&d);let l=layout(&d);let mut bytes=encrypted(&d,PASSWORD);let raw=stream(&bytes,STREAM);assert!(serde_json::from_slice::<Value>(&raw).is_err());let decoded=rhwp::password_crypto::decrypt_hwp5_stream(&raw,PASSWORD);let package:Value=serde_json::from_slice(&decoded).unwrap();assert_eq!(package["representation"],"hwp-flow-v1");assert!(!package["entries"].as_array().unwrap().is_empty());
 let mut observations=vec![];
 for cycle in 0..3{let n=DocumentCore::from_bytes_with_password(&bytes,PASSWORD).unwrap();assert!(!n.document().extra_streams.iter().any(|(p,_)|p==STREAM));assert_eq!(sem,semantics(&n));assert_eq!(l,layout(&n));let next=encrypted(&n,PASSWORD);observations.push(json!({"cycle":cycle,"bytes":next.len(),"consumedDescriptor":true}));bytes=next;}
 let n=DocumentCore::from_bytes_with_password(&bytes,PASSWORD).unwrap();for format in ["hwp","hwpx"]{let a=if format=="hwp"{n.export_hwp_with_adapter_snapshot_with_report().unwrap()}else{n.export_hwpx_native_with_report().unwrap()};assert_eq!(a.content_loss().len(),0);let t=DocumentCore::from_bytes(a.bytes()).unwrap();assert_eq!(sem,semantics(&t));assert_eq!(l,layout(&t));}
 assert_eq!(before,state(&d));report("own-roundtrip",json!({"cycles":observations,"sourceUnchanged":true,"exactPublishedLayout":true,"plaintextDescriptorVisible":false}));
}
#[test]fn encrypted_untrusted_descriptors_never_restore_partial_authority(){
 let d=fixture("");let bytes=encrypted(&d,PASSWORD);let raw=stream(&bytes,STREAM);let plain=rhwp::password_crypto::decrypt_hwp5_stream(&raw,PASSWORD);let pkg:Value=serde_json::from_slice(&plain).unwrap();let mut cases=vec![];
 let mut corrupt=raw.clone();corrupt[0]^=1;cases.push(("cipher-bit-flip",corrupt));cases.push(("plaintext-in-encrypted-container",plain));
 for (name,change)in ["resource","future-version","section-hash","invalid-entry-after-valid"].iter().enumerate(){let mut p=pkg.clone();match name{0=>p["resource"]=json!(vec![0;32]),1=>p["version"]=json!(99),2=>p["sections"][0]=json!(vec![0;32]),_=>{let mut bad=p["entries"][0].clone();bad["paragraph"]=json!(999999);p["entries"].as_array_mut().unwrap().push(bad);}}cases.push((*change,rhwp::password_crypto::encrypt_hwp5_stream(&serde_json::to_vec(&p).unwrap(),PASSWORD)));}
 let other=encrypted(&fixture("Independent changed body"),PASSWORD);cases.push(("different-body-transplant",stream(&other,STREAM)));
 let mut observed=vec![];
 for(name,opaque)in cases{let altered=replace(&bytes,STREAM,&opaque);let n=DocumentCore::from_bytes_with_password(&altered,PASSWORD).unwrap();assert_eq!(n.document().extra_streams.iter().find(|(p,_)|p==STREAM).unwrap().1,opaque,"{name}");let rewritten=encrypted(&n,b"own120-changed-password");assert_eq!(stream(&rewritten,STREAM),opaque,"opaque cipher was re-encrypted or overwritten: {name}");let q=DocumentCore::from_bytes_with_password(&rewritten,b"own120-changed-password").unwrap();assert_eq!(q.document().extra_streams.iter().find(|(p,_)|p==STREAM).unwrap().1,opaque);observed.push(json!({"case":name,"opaqueExact":true,"notConsumed":true,"newPasswordDidNotMintOwner":true}));}
 let oversized=replace(&bytes,STREAM,&vec![0;2*1024*1024+1]);assert!(DocumentCore::from_bytes_with_password(&oversized,PASSWORD).is_err());assert!(DocumentCore::from_bytes(&bytes).is_err());assert!(DocumentCore::from_bytes_with_password(&bytes,b"wrong").is_err());report("untrusted",json!({"cases":observed,"oversizedRejected":true,"missingPasswordRejected":true,"wrongPasswordRejected":true}));
}
#[test]fn encrypted_reserved_collision_preserves_opaque_and_reports_loss(){
 let mut d=fixture("");let opaque=b"opaque unknown original payload".to_vec();d.document_mut().extra_streams.push((STREAM.into(),opaque.clone()));let before=state(&d);let a=d.export_hwp_with_adapter_snapshot_with_password_and_report(PASSWORD).unwrap();assert_eq!(a.content_loss().len(),1);assert_eq!(stream(a.bytes(),STREAM),opaque);assert_eq!(before,state(&d));report("collision",json!({"contentLoss":serde_json::from_str::<Value>(&a.content_loss().to_json()).unwrap(),"opaqueExact":true,"sourceUnchanged":true}));
}

#[test]fn actual_uncompressed_encrypted_headers_keep_existing_crypto_boundaries(){
 let mut d=fixture("");
 // Controlled fixture output options only: use the existing uncompressed HWP5
 // path, patch both modeled flags and their literal preserved header owner.
 let h=&mut d.document_mut().header;h.compressed=false;h.flags&=!1;
 if let Some(raw)=&mut h.raw_data{raw[36..40].copy_from_slice(&h.flags.to_le_bytes());}
 let original=state(&d);let sem=semantics(&d);let l=layout(&d);let bytes=encrypted(&d,PASSWORD);let header=stream(&bytes,"/FileHeader");assert_eq!(u32::from_le_bytes(header[36..40].try_into().unwrap())&3,2);assert_eq!(u32::from_le_bytes(header[44..48].try_into().unwrap()),4);
 let n=DocumentCore::from_bytes_with_password(&bytes,PASSWORD).unwrap();assert_eq!(sem,semantics(&n));assert_eq!(l,layout(&n));assert!(!n.document().extra_streams.iter().any(|(p,_)|p==STREAM));assert!(DocumentCore::from_bytes_with_password(&bytes,b"wrong").is_err());
 let mut bad=header.clone();bad[44..48].copy_from_slice(&3u32.to_le_bytes());let changed=replace(&bytes,"/FileHeader",&bad);assert!(DocumentCore::from_bytes_with_password(&changed,PASSWORD).is_err());
 assert_eq!(original,state(&d));report("uncompressed",json!({"compressed":false,"encryptVersion":4,"strictBodySemanticsAndLayout":true,"descriptorConsumed":true,"wrongPasswordRejected":true,"unsupportedEncryptVersionRejected":true,"sourceUnchanged":true}));
}
