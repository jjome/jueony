from pathlib import Path
import json,hashlib,re,difflib
r=Path(__file__).resolve().parents[1]
base=r/'build/rhwp-engine/source-8f1e77fb0bcdf310'
reg=r/'build/n001-regression128/handoff-final'
tac=r/'build/n001-native-tac126/handoff-final'
stage=r/'build/n001-general127-merged'
stage.mkdir(exist_ok=True)
assert not any(stage.iterdir())
def sha(b):return hashlib.sha256(b).hexdigest()
def lf(b):return b.replace(b'\r\n',b'\n')
rp=json.loads((reg/'source-proof.json').read_bytes());tp=json.loads((tac/'source-proof.json').read_bytes())
changes={}
for entry in rp['files']:
 p=entry['path'];raw=(reg/'runtime'/p).read_bytes();assert sha(raw)==entry['sourceRawSha256'];assert sha(lf((base/p).read_bytes()))==entry['baseCanonicalSha256'];changes[p]=lf(raw)
for entry in tp['runtimeFiles']:
 p=entry['path'];raw=(tac/'source'/p).read_bytes();assert sha(lf(raw))==entry['canonicalSha256']
 if p.endswith('native_computed_resource.rs'):resource=lf(raw);continue
 assert p not in changes
 if entry['baseCanonicalSha256']:assert sha(lf((base/p).read_bytes()))==entry['baseCanonicalSha256'],p
 else:assert not (base/p).exists(),p
 changes[p]=lf(raw)
paths=re.findall(r'\("([^"]+)",include_bytes!',resource.decode())
oldpaths=re.findall(r'\("([^"]+)",include_bytes!',(base/'src/model/native_computed_resource.rs').read_text())
assert len(paths)==250 and len(oldpaths)==248
assert [p for p in paths if p in oldpaths]==oldpaths
h=hashlib.sha256(b'rhwp-portable-native-text-edit-frame-1;source-text-lf\0');inputs=[]
for p in paths:
 b=changes.get(p,lf((base/p).read_bytes()) if (base/p).exists() else None);assert b is not None,p
 h.update(p.encode());h.update(b'\0');h.update(len(b).to_bytes(8,'little'));h.update(b)
 inputs.append({'path':p,'canonicalSha256':sha(b)})
digest=h.digest();resource=re.sub(rb'pub\(crate\) const RESOURCE:\[u8;32\]=\[[^\]]+\];',('pub(crate) const RESOURCE:[u8;32]=['+', '.join(map(str,digest))+'];').encode(),resource)
changes['src/model/native_computed_resource.rs']=resource
patch=''
for p,b in sorted(changes.items()):
 original=lf((base/p).read_bytes()) if (base/p).exists() else b''
 dest=stage/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 patch+=''.join(difflib.unified_diff(original.decode().splitlines(True),b.decode().splitlines(True),fromfile='a/'+p if original else '/dev/null',tofile='b/'+p))
dest=r/'engine/patches'/('z'*110+'-native-tail-and-tac-spacing.patch');assert not dest.exists();dest.write_bytes(patch.encode())
proof={'base':str(base.relative_to(r)),'regressionPatch':rp['patchSha256'],'tacPatch':tp['patchSha256'],'runtimeFiles':[{'path':p,'canonicalSha256':sha(b)}for p,b in sorted(changes.items())],'resourceCount':len(paths),'retained248ExactOrder':True,'resourceSha256':digest.hex(),'resourceInputs':inputs,'patch':str(dest.relative_to(r)),'patchSha256':sha(dest.read_bytes())}
(stage/'merge-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in proof.items()if k not in ('resourceInputs','runtimeFiles')},indent=2))
