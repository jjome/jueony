from pathlib import Path
import subprocess,tarfile,shutil,json,hashlib
r=Path(__file__).resolve().parents[1];dest=r/'build/n001-review127-clean';dest.mkdir(exist_ok=False)
archive=r/'build/n001-review127-clean.tar';commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();assert commit=='bc0b6c3c10a58399aa8bdfeae6e0029a7ba1f6c9'
subprocess.run(['git','archive','--format=tar','-o',str(archive),commit,'apps','engine','scripts','LICENSE.txt','README.md','THIRD_PARTY_NOTICES.md','.gitattributes','.gitignore'],cwd=r,check=True)
with tarfile.open(archive)as t:t.extractall(dest,filter='data')
for f in (r/'engine/patches').glob('*.patch'):shutil.copy2(f,dest/f.relative_to(r))
for name in ['verify-general-layout-corpus125.mjs','verify-general-native-layout125.mjs','verify-general-native-layout-ui125.mjs','verify-native-tac-spacing-ui126.mjs']:
 shutil.copy2(r/'apps/editor/scripts'/name,dest/'apps/editor/scripts'/name)
shutil.copytree(r/'apps/editor/tests/fixtures/n001-general125-own',dest/'apps/editor/tests/fixtures/n001-general125-own')
shutil.copy2(r/'scripts/verify_file_workflows.py',dest/'scripts/verify_file_workflows.py')
proof={'applicationSourceCommit':commit,'applicationChanges':[],'excludedUncommittedFeatures':['stored-time save lifecycle','Agent recent documents'],'files':[{'path':f.relative_to(dest).as_posix(),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}for f in sorted((dest/'apps/editor/src').rglob('*'))if f.is_file()]}
assert len(proof['files'])==354
(r/'build/n001-general127-clean-source-proof.json').write_text(json.dumps(proof,indent=2),encoding='utf8')
print(str(dest))
