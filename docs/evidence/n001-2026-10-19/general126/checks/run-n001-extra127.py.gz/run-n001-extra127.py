from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import os,subprocess,json,hashlib
r=Path(__file__).resolve().parents[1];mirror=r/'build/n001-review127-clean';out=r/'build/n001-extra127';out.mkdir(exist_ok=False)
engine=r/'build/rhwp-engine/source-04cb5482deee38fb/pkg';dist=mirror/'apps/editor/evidence/dist-n001-general127';node='C:/Users/jjome/AppData/Local/Volta/tools/image/node/22.22.2/node.exe'
jobs=[('legacy14','verify-legacy-stack-storage115.mjs',14,{'JUEONY_LEGACY_STACK_FIXTURES':str(r/'build/cross-standard-rows115/generated-fixtures-final')}),('typed-time14','verify-stored-time111.mjs',14,{}),('created12','verify-document-created-information111.mjs',12,{}),('columns24','verify-generated-column-storage.mjs',24,{'JUEONY_BASELINE_ENGINE_PACKAGE':str(r/'build/rhwp-engine/source-7c10dba04ed65742/pkg'),'JUEONY_COLUMN_EVIDENCE':str(r/'docs/evidence/file-completion-2026-10-18/engine76/columns-native')}),('windows11','verify-native-file-storage.mjs',11,{})]
def run(job):
 name,script,count,additional=job;app=r/'apps/editor'if name=='windows11'else mirror/'apps/editor';env=dict(os.environ,JUEONY_ENGINE_PACKAGE=str(engine),JUEONY_TEST_DIST=str(dist),JUEONY_TEST_OUTPUT=str(out/name));env.update(additional)
 with(out/(name+'.log')).open('w',encoding='utf8')as f:p=subprocess.run([node,'--experimental-strip-types',str(app/'scripts'/script)],cwd=app,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'name':name,'expected':count,'exitCode':p.returncode,'scriptSha256':hashlib.sha256((app/'scripts'/script).read_bytes()).hexdigest()}
 try:
  v=json.loads((out/name/'result.json').read_bytes());assert p.returncode==0
  if name=='windows11':assert v['passed']==count and v['failed']==0
  else:assert len(v['results'])==count and not v['failures']and all(not isinstance(x,dict)or x['status']=='PASS'for x in v['results'])
  row['status']='PASS'
 except Exception as e:row.update(status='FAIL',error=str(e))
 print(json.dumps(row),flush=True);return row
with ThreadPoolExecutor(max_workers=2)as pool:rows=list(pool.map(run,jobs))
(out/'summary.json').write_text(json.dumps({'results':rows,'failures':[x for x in rows if x['status']!='PASS'],'engine':json.loads((engine/'jueony-engine-build.json').read_bytes()),'scope':'Separate legacy14, typed-time14, actual app creation12, fixed column24 and actual Windows native storage11 invocations. Own fixtures; no Hancom GUI/OS picker or user files.'},indent=2)+'\n',encoding='utf8')
raise SystemExit(int(any(x['status']!='PASS'for x in rows)))
