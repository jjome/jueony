from pathlib import Path
import os,sys,subprocess,ast,shutil
r=Path(__file__).resolve().parents[1];mirror=r/'build/n001-review127-clean';engine=r/'build/rhwp-engine/source-04cb5482deee38fb/pkg';dist=mirror/'apps/editor/evidence/dist-n001-general127';node='C:/Users/jjome/AppData/Local/Volta/tools/image/node/22.22.2/node.exe'
assert (engine/'jueony-engine-build.json').is_file()
mode=sys.argv[1];env=dict(os.environ,JUEONY_ENGINE_PACKAGE=str(engine),JUEONY_BUILD_PROFILE='n001-general127',JUEONY_TEST_DIST=str(dist));cwd=mirror/'apps/editor'
if mode=='build':args=[node,str(cwd/'scripts/build.mjs')]
elif mode=='unit':args=[node,'--experimental-strip-types','--test',*[str(f)for f in sorted((cwd/'tests').glob('*.test.ts'))]]
elif mode=='typecheck':args=[node,str(cwd/'node_modules/typescript/bin/tsc'),'--project','.build/studio-n001-general127/tsconfig.json','--pretty','false']
elif mode=='boundaries':args=[node,str(mirror/'scripts/check-module-boundaries.mjs')]
elif mode=='established':
 tree=ast.parse((r/'build/run-storage111-workflows.py').read_text(encoding='utf8'));args=next(ast.literal_eval(n.value)for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='args'for t in n.targets))
 values={'--engine':str(engine),'--dist':str(dist),'--output':str(r/'build/n001-general127-established-workflows')}
 for i,v in enumerate(args):
  if v in values:args[i+1]=values[v]
  if v.startswith('--')and i+1<len(args)and not args[i+1].startswith('--')and v!='--node':args[i+1]=str(r/args[i+1])if not Path(args[i+1]).is_absolute()else args[i+1]
 args=['C:/Python314/python.exe','-X','utf8',str(mirror/'scripts/verify_file_workflows.py'),*args,'--encrypted-native-rows','--legacy-native-row-archive','--native-tac-spacing'];env['JUEONY_PREVIEW_RAW_AUDITOR']='/tmp/jueony-n001-preview-raw-audit124/debug/preview-raw-audit117';cwd=mirror
else:
 names={'public':'verify-general-native-layout125.mjs','corpus':'verify-general-layout-corpus125.mjs','tac-ui':'verify-native-tac-spacing-ui126.mjs','general-ui':'verify-general-native-layout-ui125.mjs'}
 args=[node,'--experimental-strip-types',str(cwd/'scripts'/names[mode])];env['JUEONY_TEST_OUTPUT']=str(r/('build/n001-general127-'+mode))
with(r/('build/n001-general127-'+mode+'.log')).open('w',encoding='utf8')as log:p=subprocess.run(args,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
raise SystemExit(p.returncode)
