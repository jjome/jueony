//! Current-format proof for a single-column, whole, full-width logical stack.
//! No imported completed-row descriptor, source seal, resource generation or
//! observation's selected-inset label grants this plan. Current text is freshly
//! composed without source rows and the actual allocation closes independently.
use super::*;

#[derive(Clone,Copy)]
pub(super) struct CurrentTableTop { pub table_top:f64 }

/// Current composition and physical allocation only; this is not an imported
/// row owner, a descriptor permission, or a request to change document rows.
pub(crate) struct CurrentWholeStackPlan {
    pub fresh_prefix: ComposedParagraph,
    pub prefix_end_hu: i32,
    pub column_width_hu: i32,
    pub body_height_hu: i32,
    pub hosts: Vec<CurrentStackHost>,
    pub prefixes: Vec<CurrentStackPrefix>,
}

impl CurrentWholeStackPlan {
    /// Full current row/run identity, including the selected space policy.
    /// This comparison does not authorize a source flag or imported lease.
    pub(crate) fn matches_fresh_prefix(&self,candidate:&ComposedParagraph)->bool {
        same_composition(&self.fresh_prefix,candidate)
    }
}

pub(crate) struct CurrentStackPrefix {
    pub para_index: usize,
    pub logical_start_hu: i32,
    pub logical_end_hu: i32,
    pub fresh: ComposedParagraph,
}
impl CurrentStackPrefix {
    pub(crate) fn matches(&self, candidate:&ComposedParagraph)->bool {same_composition(&self.fresh,candidate)}
}

pub(crate) struct CurrentStackHost {
    pub para_index: usize,
    pub control_index: usize,
    pub logical_anchor_hu: i32,
    pub physical_top_hu: i32,
    pub before_hu: i32,
    pub body_hu: i32,
    pub after_hu: i32,
    pub reserved_bottom_hu: i32,
}

fn plain(p:&Paragraph)->bool {
    p.text.len()<=64*1024 && p.line_segs.len()<=4096 && p.char_shapes.len()<=128
        && p.ctrl_data_records.len()<=2 && p.raw_header_extra.len()<=128
        && !p.stored_text_partition_is_dirty() && !p.cell_format_vpos_dirty
        && p.hwpx_axis_shift==0 && p.source_line_seg_vertical_pos.is_none()
        && p.layout_only_fill_lines==0 && p.field_ranges.is_empty()
        && p.orphan_field_ends.is_empty() && p.range_tags.is_empty()
        && p.title_marks.is_empty() && p.markpen_marks.is_empty()
        && p.tab_extended.is_empty() && p.numbering_restart.is_none()
        && p.ctrl_data_records.iter().all(Option::is_none)
}

// This is a typed HU comparison, never a rounding of published coordinates.
// All operands below originate in integer source metrics or integer table
// declarations. Reject a fractional metric rather than fitting it to the source.
fn hu(px:f64,dpi:f64)->Option<i32> {
    if !px.is_finite() || px<0.0 || !dpi.is_finite() || dpi<=0.0{return None;}
    let value=px*7200.0/dpi;
    if value>i32::MAX as f64{return None;}
    let integer=value.round();
    // Bound only floating-point arithmetic roundoff (far less than one HU).
    ((value-integer).abs()<=f64::EPSILON*value.abs().max(1.0)*8.0).then_some(integer as i32)
}

fn same_composition(a:&ComposedParagraph,b:&ComposedParagraph)->bool {
    a.para_style_id==b.para_style_id && a.lines.len()==b.lines.len()
        && a.numbering_text.is_none() && b.numbering_text.is_none()
        && a.inline_controls.len()==b.inline_controls.len() && a.inline_controls.len()<=2
        && a.inline_controls.iter().zip(&b.inline_controls).enumerate().all(|(i,(a,b))|
            a.control_index==i && b.control_index==i
                && a.control_type==crate::renderer::composer::InlineControlType::Other
                && a.control_type==b.control_type && a.line_index==b.line_index)
        && a.tac_controls.is_empty() && b.tac_controls.is_empty()
        && a.footnote_positions.is_empty() && b.footnote_positions.is_empty()
        && a.tab_extended.is_empty() && b.tab_extended.is_empty()
        && a.horizontal_shaping.is_none() && b.horizontal_shaping.is_none()
        && a.lines.iter().zip(&b.lines).all(|(a,b)|
            a.char_start==b.char_start && a.line_height==b.line_height
                && a.baseline_distance==b.baseline_distance && a.line_spacing==b.line_spacing
                && a.column_start==b.column_start && a.segment_width==b.segment_width
                && !a.has_line_break && !b.has_line_break && a.runs.len()==b.runs.len()
                && a.runs.iter().zip(&b.runs).all(|(a,b)| a.text==b.text
                    && a.char_style_id==b.char_style_id && a.lang_index==b.lang_index
                    && a.supplemental_metrics_blocked==b.supplemental_metrics_blocked
                    && a.space_metric==b.space_metric && a.char_overlap.is_none() && b.char_overlap.is_none()
                    && a.footnote_marker.is_none() && b.footnote_marker.is_none()
                    && !a.inserted_control_text && !b.inserted_control_text
                    && a.display_text.is_none() && b.display_text.is_none()))
}

pub(super) fn current_table_top(ctx:&ColumnItemCtx<'_>, index:usize, control:usize,
    current_flow:f64,dpi:f64)->Option<CurrentTableTop> {
    let plan=current_whole_stack(ctx,dpi)?;
    let host=plan.hosts.iter().find(|p|p.para_index==index && p.control_index==control)?;
    if hu(current_flow-ctx.col_area.y,dpi)?!=host.physical_top_hu {return None;}
    Some(CurrentTableTop{table_top:current_flow})
}

#[derive(Clone,Copy)]
enum ColumnSource { XmlModel, NativePacked }

pub(super) fn current_whole_stack(ctx:&ColumnItemCtx<'_>,dpi:f64)->Option<CurrentWholeStackPlan> {
    current_whole_stack_with_column_source(ctx,dpi,ColumnSource::XmlModel)
}
pub(super) fn current_native_whole_stack(ctx:&ColumnItemCtx<'_>,dpi:f64)->Option<CurrentWholeStackPlan> {
    current_whole_stack_with_column_source(ctx,dpi,ColumnSource::NativePacked)
}
// Native CTRL_HEADER has two exact empty-description CommonObjAttr forms:
// 36 known bytes + empty u16 string, optionally preceded by prevent-page-break
// i32. The native reader defaults that optional field only when exactly absent.
// Match every known current field, not an imported raw seal or opaque payload.
fn native_common_matches(table:&crate::model::table::Table)->bool {
    let c=&table.common;
    if !matches!(table.raw_ctrl_data.len(),38|42) || !c.description.is_empty() || !c.raw_extra.is_empty()
        || c.attr!=crate::serializer::control::pack_common_attr_bits(c)
        || c.ctrl_id!=0 || c.z_order!=0 || c.prevent_page_break!=0
        || !matches!(c.numbering_type,crate::model::shape::ObjectNumberingType::None)
        || !matches!(c.drop_cap_style,crate::model::shape::DropCapStyle::None)
        || c.margin.left!=table.outer_margin_left || c.margin.right!=table.outer_margin_right
        || c.margin.top!=table.outer_margin_top || c.margin.bottom!=table.outer_margin_bottom {return false;}
    let mut bytes=Vec::with_capacity(42);
    for value in [c.attr,c.vertical_offset,c.horizontal_offset,c.width,c.height] {bytes.extend(value.to_le_bytes());}
    bytes.extend(c.z_order.to_le_bytes());
    for value in [c.margin.left,c.margin.right,c.margin.top,c.margin.bottom] {bytes.extend(value.to_le_bytes());}
    bytes.extend(c.instance_id.to_le_bytes());
    if table.raw_ctrl_data.len()==42 {bytes.extend(c.prevent_page_break.to_le_bytes());}
    bytes.extend(0u16.to_le_bytes());
    bytes==table.raw_ctrl_data
}

fn current_whole_stack_with_column_source(ctx:&ColumnItemCtx<'_>,dpi:f64,column_source:ColumnSource)->Option<CurrentWholeStackPlan> {
    use crate::renderer::composer::{compose_paragraph_in_context,recompose_stored_lines_in_frame,ParagraphBox};
    use crate::model::{paragraph::ColumnBreakType,style::HeadType};
    if ctx.paragraphs.len()<2 || ctx.paragraphs.len()>128
        || ctx.zone_column_count!=1 || ctx.layout.column_areas.len()!=1
        || ctx.page_content.page_index!=0 || ctx.page_content.section_index!=0
        || ctx.page_content.column_contents.len()!=1 || !ctx.page_content.footnotes.is_empty()
        || ctx.page_content.active_header.is_some() || ctx.page_content.active_footer.is_some()
        || ctx.page_content.active_master_page.is_some() || !ctx.page_content.extra_master_pages.is_empty()
        || !ctx.wrap_anchors.is_empty() || !ctx.wrap_around_paras.is_empty()
        || !ctx.inline_placements.is_empty() || !ctx.inline_flow_plans.is_empty()
        || !ctx.paragraph_float_placements.is_empty()
        || ctx.styles.supplemental_metrics.is_some() || ctx.styles.kerning_measurement_context.is_some()
        || ctx.styles.horizontal_shaping_context.is_some() {return None;}
    let col=&ctx.page_content.column_contents[0];
    if col.column_index!=0 || col.start_height!=0.0 || col.endnote_flow
        || col.zone_layout.is_some() || col.zone_y_offset!=0.0
        || !col.overlay_continuations.is_empty() || !col.overlay_cuts.is_empty()

    {return None;}
    // Read the actual frame allocation, not a template's paragraph ordinals.
    // Every admitted item must own one whole, ordered paragraph in this frame.
    let prefix_count=col.items.iter().take_while(|item|matches!(item,PageItem::FullParagraph{..})).count();
    let host_count=col.items.iter().skip(prefix_count).take_while(|item|matches!(item,PageItem::Table{..})).count();
    if prefix_count==0 || host_count==0 || prefix_count.checked_add(host_count)?>ctx.paragraphs.len()
        || col.items.len()!=ctx.paragraphs.len() {return None;}
    for (index,item) in col.items.iter().enumerate() {
        let valid=if (prefix_count..prefix_count+host_count).contains(&index) {
            matches!(item,PageItem::Table{para_index,control_index:0} if *para_index==index)
        }else{matches!(item,PageItem::FullParagraph{para_index} if *para_index==index)};
        if !valid{return None;}
    }
    let width=hu(ctx.col_area.width,dpi)?;let body=hu(ctx.col_area.height,dpi)?;
    if width<=0 || body<=0 || ctx.col_area.x!=ctx.layout.body_area.x
        || ctx.col_area.width!=ctx.layout.body_area.width {return None;}

    let first=ctx.paragraphs.first()?;
    if !plain(first) || first.text.is_empty() || first.text.chars().count()>4096
        || first.text.chars().any(|c|c<' ' || c=='\u{fffc}')
        || first.line_segs.is_empty() || first.line_segs.len()>256
        || first.char_shapes.is_empty() || first.char_shapes.len()>128
        || first.char_shapes.windows(2).any(|p|p[0].start_pos>=p[1].start_pos)
        || first.char_shapes.iter().any(|s|s.char_shape_id as usize>=ctx.styles.char_styles.len())
        || !matches!(first.column_type,ColumnBreakType::Section)
        || !matches!(first.controls.as_slice(),[Control::SectionDef(_),Control::ColumnDef(c)]
            if c.column_count==1 && c.same_width && c.widths.is_empty() && c.gaps.is_empty()
                && c.direction==crate::model::page::ColumnDirection::LeftToRight
                && c.column_type==crate::model::page::ColumnType::Normal
                && match column_source {
                    ColumnSource::XmlModel=>c.raw_attr==0,
                    // Native parser::body_text reads count from bits2..9 and
                    // same-width from bit12. serializer::control emits these
                    // exact bits for the already-required one-column LTR Normal
                    // model. No reserved/other raw attribute bits are admitted.
                    ColumnSource::NativePacked=>c.raw_attr==((1u16<<2)|(1u16<<12)),
                })
    {return None;}
    let Control::SectionDef(section)=&first.controls[0] else{return None;};
    if !section.master_pages.is_empty() || !section.extra_child_records.is_empty()
        || section.extra_page_border_fills.len()>3 || section.raw_ctrl_extra.len()>64
        || section.raw_ctrl_extra.iter().any(|b|*b!=0) || section.text_direction!=0 {return None;}
    let style=ctx.styles.para_styles.get(first.para_shape_id as usize)?;
    if [style.margin_left,style.margin_right,style.indent,style.spacing_before,style.spacing_after]
        .iter().any(|v|*v!=0.0) || !matches!(style.head_type,HeadType::None)
        || style.border_spacing.iter().any(|v|*v!=0.0) || style.border_connect || style.page_break_before || style.keep_with_next || style.keep_lines
    {return None;}
    if style.border_fill_id!=0 {
        let border=ctx.styles.border_styles.get(usize::from(style.border_fill_id.checked_sub(1)?))?;
        if border.borders.iter().any(|b|!matches!(b.line_type,crate::model::style::BorderLineType::None))
            || border.fill_color.is_some() || border.pattern.is_some() || border.gradient.is_some()
            || border.image_fill.is_some() || border.diagonal_attr!=0
            || !matches!(border.center_line,crate::model::style::CenterLine::None) {return None;}
    }
    // Exactly two known eight-unit leading structural controls. A hidden gap
    // elsewhere cannot become a fresh text-position witness.
    let chars:Vec<char>=first.text.chars().collect();let mut offset=16u32;
    if first.char_offsets.len()!=chars.len(){return None;}
    for (i,c) in chars.iter().enumerate(){if first.char_offsets[i]!=offset{return None;}
        offset=offset.checked_add(c.len_utf16() as u32)?;}
    if first.char_count!=offset.checked_add(1)? {return None;}
    let actual=ctx.composed.first()?;
    let mut input=first.clone();input.line_segs.clear();
    input.layout_space_metrics.clear();input.completed_native_rows=None;
    input.native_source_synthetic_seal=None;input.native_source_synthetic_context=None;
    input.native_frame_observation.set(None);
    let initial=compose_paragraph_in_context(&input,ctx.styles);
    let fresh=recompose_stored_lines_in_frame(&initial,&input,ParagraphBox::content_for_style(ctx.col_area.width,
        Some(style),dpi),ctx.col_area.width,ctx.styles,dpi,false,
        crate::renderer::composer::StoredRowMissPolicy::Reflow,&[])?;
    if actual.inline_controls.len()!=2 || fresh.inline_controls.len()!=2
        || !same_composition(actual,&fresh) || actual.lines.len()!=first.line_segs.len(){return None;}
    let mut end=0i32;
    for (i,(line,row)) in actual.lines.iter().zip(&first.line_segs).enumerate(){
        let start=if i==0 {0} else {*first.char_offsets.get(line.char_start)?};
        if row.tag!=0x80060000 || row.text_start!=start || row.vertical_pos!=end
            || row.line_height<=0 || row.text_height!=row.line_height
            || row.line_height!=line.line_height || row.line_spacing!=line.line_spacing
            || row.baseline_distance!=line.baseline_distance || row.column_start!=line.column_start
            || row.column_start!=0 || row.segment_width!=line.segment_width || row.segment_width!=width
            || row.line_spacing<0 {return None;}
        end=end.checked_add(row.line_height)?.checked_add(row.line_spacing)?;
    }
    if end<=0 || end>body{return None;}

    let mut prefixes=vec![CurrentStackPrefix{para_index:0,logical_start_hu:0,logical_end_hu:end,fresh:fresh.clone()}];
    for pi in 1..prefix_count {
        let p=ctx.paragraphs.get(pi)?;
        if !plain(p) || !p.controls.is_empty() || p.column_type!=ColumnBreakType::None
            || p.para_shape_id!=first.para_shape_id || p.style_id!=first.style_id
            || p.text.chars().count()>4096 || p.text.chars().any(|c|c<' ' || c=='\u{fffc}')
            || p.char_shapes.is_empty() || p.char_shapes.windows(2).any(|s|s[0].start_pos>=s[1].start_pos)
            || p.char_shapes.iter().any(|s|s.char_shape_id as usize>=ctx.styles.char_styles.len()) {return None;}
        let mut offset=0u32;
        if p.char_offsets.len()!=p.text.chars().count(){return None;}
        for (c,at) in p.text.chars().zip(&p.char_offsets){if *at!=offset{return None;}offset=offset.checked_add(c.len_utf16() as u32)?;}
        if p.char_count!=offset.checked_add(1)?{return None;}
        let mut input=p.clone();input.line_segs.clear();input.layout_space_metrics.clear();
        input.completed_native_rows=None;input.native_source_synthetic_seal=None;input.native_source_synthetic_context=None;
        input.native_frame_observation.set(None);
        let initial=compose_paragraph_in_context(&input,ctx.styles);
        let current=ctx.composed.get(pi)?;
        let fresh=recompose_stored_lines_in_frame(&initial,&input,ParagraphBox::content_for_style(ctx.col_area.width,
            Some(style),dpi),ctx.col_area.width,ctx.styles,dpi,false,
            crate::renderer::composer::StoredRowMissPolicy::Reflow,&[])?;
        if !current.inline_controls.is_empty() || !fresh.inline_controls.is_empty()
            || !same_composition(current,&fresh) || current.lines.len()!=p.line_segs.len(){return None;}
        let start=end;
        for (i,(line,row)) in current.lines.iter().zip(&p.line_segs).enumerate(){
            let text_start=if i==0{0}else{*p.char_offsets.get(line.char_start)?};
            if row.tag!=0x80060000 || row.text_start!=text_start || row.vertical_pos!=end
                || row.line_height<=0 || row.text_height!=row.line_height || row.line_height!=line.line_height
                || row.line_spacing!=line.line_spacing || row.line_spacing<0 || row.baseline_distance!=line.baseline_distance
                || row.column_start!=0 || row.column_start!=line.column_start || row.segment_width!=width
                || row.segment_width!=line.segment_width{return None;}
            end=end.checked_add(row.line_height)?.checked_add(row.line_spacing)?;
        }
        if end<=start || end>body{return None;}
        prefixes.push(CurrentStackPrefix{para_index:pi,logical_start_hu:start,logical_end_hu:end,fresh});
    }
    let mut reserved=end;let mut consumed_before=0i32;let mut hosts=Vec::with_capacity(host_count);
    for pi in prefix_count..prefix_count+host_count {
        let p=&ctx.paragraphs[pi];let [Control::Table(table)]=p.controls.as_slice() else{return None;};
        let [row]=p.line_segs.as_slice() else{return None;};
        if !plain(p) || !p.text.is_empty() || p.char_count!=9 || !p.char_offsets.is_empty()
            || p.para_shape_id!=first.para_shape_id || p.style_id!=first.style_id
            || p.column_type!=ColumnBreakType::None || row.tag!=0x80060000
            || row.text_start!=0 || row.vertical_pos!=end || row.column_start!=0
            || row.line_height<=0 || row.text_height!=row.line_height || row.line_spacing<0
            || table.raw_table_record_extra.iter().any(|b|*b!=0)
            || !match column_source {
                ColumnSource::XmlModel=>table.raw_ctrl_data.is_empty(),
                ColumnSource::NativePacked=>native_common_matches(table),
            }
            || table.cells.iter().map(|c|c.paragraphs.len()).sum::<usize>()>1024
            || !crate::renderer::generated_column_stack::plain_table(table,plain)
            || i32::try_from(table.common.width).ok()?.checked_add(i32::from(table.outer_margin_left))?
                .checked_add(i32::from(table.outer_margin_right))?!=width
        {return None;}
        let mut measured=ctx.measured_tables.iter().filter(|m|m.para_index==pi && m.control_index==0);
        let m=measured.next()?;if measured.next().is_some() || m.caption_height!=0.0
            || m.row_heights.len()!=usize::from(table.row_count) || m.row_heights.iter().any(|v|!v.is_finite() || *v<=0.0)
            || hu(m.total_height,dpi)?!=i32::try_from(table.common.height).ok()? {return None;}
        for row_index in 0..usize::from(table.row_count) {
            let row_height=hu(*m.row_heights.get(row_index)?,dpi)?;
            let row_cells=table.cells.get(row_index*usize::from(table.col_count)..(row_index+1)*usize::from(table.col_count))?;
            let mut row_width=0i32;
            for (col_index,cell) in row_cells.iter().enumerate() {
                row_width=row_width.checked_add(i32::try_from(cell.width).ok()?)?;
                if i32::try_from(cell.height).ok()?>row_height
                    || cell.width!=table.cells.get(col_index)?.width {return None;}
            }
            if row_width!=i32::try_from(table.common.width).ok()? {return None;}
        }
        let f=p.native_frame_observation.get()?;
        let before=hu(f.before,dpi)?;let height=hu(f.body_height,dpi)?;let after=hu(f.after,dpi)?;
        if f.page!=0 || f.column!=0 || f.control!=0 || f.source_row_vpos!=end
            || f.outer_top!=table.outer_margin_top || before!=i32::from(table.outer_margin_top)
            || height!=hu(m.total_height,dpi)? || hu(f.raw_top,dpi)?!=reserved
            || after!=if pi+1<prefix_count+host_count {row.line_spacing} else {0}
        {return None;}
        let bottom=reserved.checked_add(before)?.checked_add(height)?.checked_add(after)?;
        if bottom!=hu(f.reserved_bottom,dpi)? || bottom>body{return None;}
        let top=reserved.checked_sub(consumed_before)?;
        hosts.push(CurrentStackHost{para_index:pi,control_index:0,logical_anchor_hu:end,
            physical_top_hu:top,before_hu:before,body_hu:height,after_hu:after,reserved_bottom_hu:bottom});
        reserved=bottom;consumed_before=consumed_before.checked_add(before)?;
    }
    if ctx.paragraphs.iter().skip(prefix_count+host_count).any(|p|!p.controls.is_empty() || !plain(p)){return None;}

    Some(CurrentWholeStackPlan{fresh_prefix:fresh,prefix_end_hu:end,column_width_hu:width,body_height_hu:body,hosts,prefixes})
}

#[cfg(test)]mod native_common_optional_absent121_tests{
 use super::*;
 fn table(len:usize)->crate::model::table::Table{
  let mut t=crate::model::table::Table::default();
  t.common.ctrl_id=0;t.common.z_order=0;t.common.prevent_page_break=0;
  t.common.numbering_type=crate::model::shape::ObjectNumberingType::None;
  t.common.drop_cap_style=crate::model::shape::DropCapStyle::None;
  t.outer_margin_left=t.common.margin.left;t.outer_margin_right=t.common.margin.right;
  t.outer_margin_top=t.common.margin.top;t.outer_margin_bottom=t.common.margin.bottom;
  t.common.attr=crate::serializer::control::pack_common_attr_bits(&t.common);
  let c=&t.common;let mut bytes=Vec::new();
  for v in [c.attr,c.vertical_offset,c.horizontal_offset,c.width,c.height]{bytes.extend(v.to_le_bytes());}
  bytes.extend(c.z_order.to_le_bytes());for v in [c.margin.left,c.margin.right,c.margin.top,c.margin.bottom]{bytes.extend(v.to_le_bytes());}
  bytes.extend(c.instance_id.to_le_bytes());if len==42{bytes.extend(0i32.to_le_bytes());}bytes.extend(0u16.to_le_bytes());t.raw_ctrl_data=bytes;t
 }
 #[test]fn exact38_and42_common_match_but_optional_absent_never_admits_unknown_bytes(){
  for len in [38,42]{let t=table(len);assert!(native_common_matches(&t));
   for off in [0,4,8,12,16,20,24,26,28,30,32,35,36,37]{let mut c=t.clone();c.raw_ctrl_data[off]^=1;assert!(!native_common_matches(&c),"len{len} byte{off}");}
   let mut c=t.clone();c.common.prevent_page_break=1;assert!(!native_common_matches(&c));
   let mut c=t.clone();c.common.description="X".into();assert!(!native_common_matches(&c));
   let mut c=t.clone();c.common.raw_extra=vec![0];assert!(!native_common_matches(&c));
   let mut c=t.clone();c.common.attr|=1u32<<31;c.raw_ctrl_data[0..4].copy_from_slice(&c.common.attr.to_le_bytes());assert!(!native_common_matches(&c));
   let mut c=t.clone();c.common.locked=!c.common.locked;assert!(!native_common_matches(&c));
  }
  for len in [0,36,37,39,40,41,43,44]{let mut t=table(42);t.raw_ctrl_data.resize(len,0);assert!(!native_common_matches(&t),"unexpected length {len}");}
 }
}
