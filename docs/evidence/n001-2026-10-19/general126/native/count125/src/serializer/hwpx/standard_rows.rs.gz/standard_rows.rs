//! Ephemeral fresh composition rows for one readonly export, never an imported
//! row/cache lease. The producer must own a current independently closed stack.
//! Nothing here is persisted in Document or the computed-row descriptor.
use crate::model::{document::Document,paragraph::{Paragraph,LineSeg}};
use serde::Serialize;
use std::collections::HashMap;

#[derive(Debug)]
pub(crate) struct CurrentStandardRowsProjection {
    definitions:[u8;32],
    dependent_paragraphs:[u8;32],
    inputs:Vec<[u8;32]>,
    rows:Vec<Vec<LineSeg>>,
}

// A serialization byte/depth bound, not a claim of a total CPU-time bound.
struct Digest { hash:blake3::Hasher, bytes:usize, depth:usize, quoted:bool, escaped:bool }
impl std::io::Write for Digest {
 fn write(&mut self,b:&[u8])->std::io::Result<usize>{
  if b.len()>16*1024*1024-self.bytes{return Err(std::io::ErrorKind::InvalidData.into());}
  for &c in b {if self.quoted {if self.escaped{self.escaped=false;}else if c==b'\\'{self.escaped=true;}else if c==b'"'{self.quoted=false;}}
   else {match c {b'"'=>self.quoted=true,b'{'|b'['=>{self.depth+=1;if self.depth>64{return Err(std::io::ErrorKind::InvalidData.into());}},b'}'|b']'=>self.depth=self.depth.checked_sub(1).ok_or(std::io::ErrorKind::InvalidData)?,_=>{}}}}
  self.bytes+=b.len();self.hash.update(b);Ok(b.len())
 }
 fn flush(&mut self)->std::io::Result<()>{Ok(())}
}
fn digest<T:Serialize>(v:&T)->Option<[u8;32]>{let mut w=Digest{hash:blake3::Hasher::new(),bytes:0,depth:0,quoted:false,escaped:false};
 serde_json::to_writer(&mut w,v).ok()?;(w.depth==0&&!w.quoted).then(||*w.hash.finalize().as_bytes())}
fn definitions(doc:&Document)->Option<[u8;32]>{
 use crate::model::document::DocInfo;
 let DocInfo{bin_data_list,font_faces,border_fills,char_shapes,tab_defs,numberings,bullets,
  para_shapes,styles,extra_records,print_method,raw_stream,bullet_count,memo_shape_count,
  memo_properties_xml,distribute_doc_data_removed,raw_stream_dirty:_,hwpx_head_tail,hwpml_version,
  raw_provenance:_}=&doc.doc_info;
 // Exhaustive definition binding, including unknown input bytes. Only derived
 // cache-validity/seal fields are excluded; this does not mint either seal.
 digest(&((bin_data_list,font_faces,border_fills,char_shapes,tab_defs,numberings,bullets,
  para_shapes,styles,extra_records),(print_method,raw_stream,bullet_count,memo_shape_count,
  memo_properties_xml,distribute_doc_data_removed,hwpx_head_tail,hwpml_version,&doc.doc_properties,&doc.sections.first()?.section_def)))
}
impl CurrentStandardRowsProjection {
 pub(crate) fn from_current_stack(doc:&Document,plan:&crate::renderer::layout::CurrentWholeStackPlan,
   styles:&crate::renderer::style_resolver::ResolvedStyleSet,width:f64,dpi:f64)->Option<Self>{
  use crate::renderer::composer::{reflow_line_segs,compose_paragraph_in_context,ParagraphBox};
  if doc.sections.len()!=1 || !dpi.is_finite() || dpi<=0.0 || !width.is_finite() || width<=0.0
    || doc.sections.iter().any(|s|s.paragraphs.iter().any(|p|p.completed_native_rows.is_some())) {return None;}
  let definitions=definitions(doc)?;
  let dependent_paragraphs=digest(&doc.sections[0].paragraphs)?;
  let paragraphs=&doc.sections[0].paragraphs;
  let count=plan.prefixes.len().checked_add(plan.hosts.len())?;
  if count==0 || count>128{return None;}
  let mut inputs=Vec::with_capacity(count);let mut rows=Vec::with_capacity(count);
  for index in 0..count {
   let p=paragraphs.get(index)?;let input=digest(&(index,p))?;let mut fresh=p.clone();
   fresh.line_segs.clear();fresh.layout_space_metrics.clear();
   fresh.source_line_seg_vertical_pos=None;fresh.layout_only_fill_lines=0;fresh.hwpx_axis_shift=0;
   fresh.native_source_synthetic_seal=None;fresh.native_source_synthetic_context=None;
   fresh.completed_native_rows=None;fresh.native_frame_observation.set(None);
   let shape=usize::from(fresh.para_shape_id);
   let frame=ParagraphBox::content_for_style(width,styles.para_styles.get(shape),dpi);
   reflow_line_segs(&mut fresh,frame,styles,dpi);
   if fresh.line_segs.is_empty() || fresh.line_segs.len()>256{return None;}
   let mut end=0i32;
   for row in &fresh.line_segs {
    if row.vertical_pos!=end || row.line_height<=0 || row.text_height!=row.line_height
      || row.line_spacing<0 || row.column_start!=0 || row.segment_width!=plan.column_width_hu
      || row.baseline_distance<0 || row.baseline_distance>row.line_height{return None;}
    end=end.checked_add(row.line_height)?.checked_add(row.line_spacing)?;
    if end>plan.body_height_hu{return None;}
   }
   if let Some(prefix)=plan.prefixes.get(index) {
    if prefix.para_index!=index || prefix.logical_end_hu.checked_sub(prefix.logical_start_hu)?!=end
      || !prefix.matches(&compose_paragraph_in_context(&fresh,styles)){return None;}
    for row in &mut fresh.line_segs {row.vertical_pos=row.vertical_pos.checked_add(prefix.logical_start_hu)?;}
   } else {
    let host_index=index.checked_sub(plan.prefixes.len())?;
    let host=plan.hosts.get(host_index)?;
    if host.para_index!=index || host.control_index!=0 || fresh.line_segs.len()!=1
      || host.logical_anchor_hu!=plan.prefix_end_hu || host.physical_top_hu<0
      || host.reserved_bottom_hu>plan.body_height_hu
      || host.after_hu!=if host_index+1<plan.hosts.len() {fresh.line_segs[0].line_spacing} else {0}{return None;}
    // Logical generated-row anchor and physical object reservation are distinct
    // quantities in this proven current stack. No imported row supplies either.
    let row=fresh.line_segs.first_mut()?;
    row.vertical_pos=row.vertical_pos.checked_add(host.logical_anchor_hu)?;
    if row.vertical_pos.checked_add(end)?>plan.body_height_hu{return None;}
   }
   inputs.push(input);rows.push(fresh.line_segs);
  }
  Some(Self{definitions,dependent_paragraphs,inputs,rows})
 }
 // Rebind only an unchanged export clone. Byte packages cannot construct this
 // ephemeral projection or acquire a new CompletedRows lease.
 pub(crate) fn bind_for_export(&self,doc:&Document)->Option<HashMap<usize,Vec<LineSeg>>>{
  if doc.sections.len()!=1 || self.inputs.is_empty() || self.inputs.len()>128 || self.rows.len()!=self.inputs.len()
    || definitions(doc)?!=self.definitions || digest(&doc.sections[0].paragraphs)?!=self.dependent_paragraphs{return None;}
  let paragraphs=&doc.sections[0].paragraphs;
  let mut bound=HashMap::new();
  for index in 0..self.inputs.len() {let p=paragraphs.get(index)?;
   if p.stored_text_partition_is_dirty() || p.cell_format_vpos_dirty || p.source_line_seg_vertical_pos.is_some(){return None;}
   if digest(&(index,p))?!=self.inputs[index]{return None;}
   bound.insert(p as *const Paragraph as usize,self.rows[index].clone());
  }
  Some(bound)
 }
}

#[cfg(test)]
mod tests {
 use super::*;
 fn sample()->(Document,CurrentStandardRowsProjection){
  let mut d=Document::default();d.sections.push(Default::default());
  d.sections[0].paragraphs=(0..3).map(|index|{let mut p=Paragraph::default();p.text=format!("paragraph {index}");p}).collect();
  let p=CurrentStandardRowsProjection{definitions:definitions(&d).unwrap(),dependent_paragraphs:digest(&d.sections[0].paragraphs).unwrap(),
   inputs:d.sections[0].paragraphs.iter().enumerate().map(|(i,p)|digest(&(i,p)).unwrap()).collect(),
   rows:vec![vec![LineSeg::default()];3]};(d,p)
 }
 #[test] fn fresh_standard_rows_bind_only_exact_export_input_and_top_level_pointers(){
  let(d,p)=sample();let clone=d.clone();let map=p.bind_for_export(&clone).unwrap();
  assert_eq!(map.len(),3);
  for row in &clone.sections[0].paragraphs{assert!(map.contains_key(&(row as *const Paragraph as usize)));}
  for row in &d.sections[0].paragraphs{assert!(!map.contains_key(&(row as *const Paragraph as usize)));}
  let mut changed=d.clone();changed.sections[0].paragraphs.swap(0,1);assert!(p.bind_for_export(&changed).is_none());
  let mut changed=d.clone();changed.sections[0].paragraphs[1].raw_header_extra.push(0x51);assert!(p.bind_for_export(&changed).is_none());
  let mut changed=d.clone();changed.doc_info.font_faces.push(Default::default());assert!(p.bind_for_export(&changed).is_none());
 }
 #[test] fn fresh_standard_rows_hash_budget_and_json_depth_are_conservative(){
  assert!(digest(&"\"[{}]\\").is_some());
  assert!(digest(&"a".repeat(16*1024*1024)).is_none());
  let mut v=serde_json::Value::Null;for _ in 0..65{v=serde_json::json!([v]);}assert!(digest(&v).is_none());
 }

 #[test] fn dynamic_projection_bounds_and_exact_source_binding(){
  for count in [1usize,2,4,16,128] {
   let(mut d,mut p)=sample();d.sections[0].paragraphs=(0..count).map(|index|{let mut para=Paragraph::default();para.text=format!("fresh input {index}");para}).collect();
   p.definitions=definitions(&d).unwrap();p.dependent_paragraphs=digest(&d.sections[0].paragraphs).unwrap();
   p.inputs=d.sections[0].paragraphs.iter().enumerate().map(|(index,para)|digest(&(index,para)).unwrap()).collect();p.rows=vec![vec![LineSeg::default()];count];
   let clone=d.clone();assert_eq!(p.bind_for_export(&clone).unwrap().len(),count);
   let mut changed=d.clone();changed.sections[0].paragraphs[count-1].raw_header_extra.push(0xe1);assert!(p.bind_for_export(&changed).is_none());
   let mut changed=d.clone();changed.sections[0].paragraphs[count-1].text.push('x');assert!(p.bind_for_export(&changed).is_none());
   p.rows.pop();assert!(p.bind_for_export(&d).is_none());
  }
  let(d,mut p)=sample();p.inputs.clear();p.rows.clear();assert!(p.bind_for_export(&d).is_none());
  p.inputs=vec![[0;32];129];p.rows=vec![vec![];129];assert!(p.bind_for_export(&d).is_none());
 }
 #[test] fn unprojected_tail_control_or_order_change_cannot_rebind_partial_plan(){
  let(mut d,mut p)=sample();d.sections[0].paragraphs.push(Paragraph::default());
  p.dependent_paragraphs=digest(&d.sections[0].paragraphs).unwrap();assert_eq!(p.bind_for_export(&d).unwrap().len(),3);
  for change in 0..4 {let mut changed=d.clone();match change {
   0=>changed.sections[0].paragraphs[3].controls.push(crate::model::control::Control::Table(Box::default())),
   1=>changed.sections[0].paragraphs[3].raw_header_extra.push(0x51),
   2=>changed.sections[0].paragraphs[3].text.push('x'),
   3=>changed.sections[0].paragraphs.swap(2,3),_=>unreachable!()}
   assert!(p.bind_for_export(&changed).is_none(),"tail case {change}");}
 }
 #[test] fn multi_section_or_unknown_definition_never_binds(){
  let(d,p)=sample();let mut changed=d.clone();changed.sections.push(Default::default());assert!(p.bind_for_export(&changed).is_none());
  let mut changed=d.clone();changed.sections[0].section_def.raw_ctrl_extra.push(0x71);assert!(p.bind_for_export(&changed).is_none());
  let mut changed=d.clone();changed.sections[0].paragraphs[0].source_line_seg_vertical_pos=Some(vec![0]);assert!(p.bind_for_export(&changed).is_none());
 }
}
