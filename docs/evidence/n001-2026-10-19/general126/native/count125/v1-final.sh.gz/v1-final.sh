#!/usr/bin/env bash
set -euo pipefail
repo=/mnt/c/Users/jjome/Documents/work/jueony
export RUSTUP_HOME="$repo/.tools/linux-rustup"
export CARGO_HOME="$repo/.tools/linux-cargo"
export PATH="$CARGO_HOME/bin:$PATH"
export CARGO_TARGET_DIR=/tmp/jueony-n001-general125-private-target
export N001_ROOT="$repo"
cd "$repo/build/n001-general125/source"
cargo test --offline --locked -p rhwp --lib serializer::hwpx::standard_rows::tests -j2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib native_common_optional_absent121_tests -j2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib native_computed_resource_matches_the_actual_pipeline_sources -j2 -- --nocapture --test-threads=1
cd "$repo/build/n001-general125/harness"
cargo test --offline --test one_delete125 -j2 -- --nocapture --test-threads=1
