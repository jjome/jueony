#!/usr/bin/env bash
set -euo pipefail
repo=/mnt/c/Users/jjome/Documents/work/jueony
export RUSTUP_HOME="$repo/.tools/linux-rustup"
export CARGO_HOME="$repo/.tools/linux-cargo"
export PATH="$CARGO_HOME/bin:$PATH"
export CARGO_TARGET_DIR=/tmp/jueony-n001-regression128-private-target
export N001_ROOT="$repo"
cd "$repo/build/n001-regression128/source"
cargo test --offline --locked -p rhwp --lib serializer::hwpx::standard_rows::tests -j2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib exact_current_rows_tail_lowering128_tests -j2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib native_computed_resource_matches_the_actual_pipeline_sources -j2 -- --nocapture --test-threads=1
cd "$repo/build/n001-regression128/harness"
cargo test --offline --test regression128 -j2 -- --nocapture --test-threads=1
