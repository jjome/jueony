use rhwp::{DocumentCore,model::control::Control};
use serde_json::{json,Value};
use std::path::PathBuf;
fn root()->PathBuf{std::env::var("N001_ROOT").unwrap().into()}
fn original()->DocumentCore{DocumentCore::from_bytes(&std::fs::read(root().join("apps/editor/tests/fixtures/n001-general125-own/one-tac.hwp")).unwrap()).unwrap()}
fn prefix(d:&mut DocumentCore){let n=d.document().sections[0].paragraphs[0].text.chars().count();d.insert_text_native(0,0,n,&"Retained current prefix editing causes line reflow. ".repeat(7)).unwrap();}
fn proof(d:&DocumentCore,i:usize,variant:&str)->Value{rhwp::private_native_tac126_review(d,i,variant)}
#[test]fn actual_parsed_tokens_refuse_changed_inputs_and_preserve_old_reset_authority(){
 let mut rows=vec![];
 let mut d=original();assert_eq!(proof(&d,1,"")["oldFullResetInput"],true);prefix(&mut d);let positive=proof(&d,1,"");assert_eq!(positive["token"],true);assert_eq!(positive["acceptedHalfPolicy"],true);assert_eq!(positive["oldFullResetInput"],false);rows.push(json!({"case":"unrelated-prefix","proof":positive}));
 for name in ["host","cell","style","font","table-geometry","section","column","raw-control","budget","root-height","root-spacing","root-tag","next-tag","child-vpos","index"]{
  let mut d=original();match name{
   "host"=>{d.insert_text_native(0,1,0,"X").unwrap();},
   "cell"=>{d.insert_text_in_cell_native(0,1,0,0,0,0,"X").unwrap();},
   "style"=>{let di=&mut d.document_mut().doc_info;di.para_shapes[0].line_spacing=170;di.raw_stream_dirty=true;},
   "font"=>{let di=&mut d.document_mut().doc_info;di.char_shapes[0].ratios[0]+=1;di.raw_stream_dirty=true;},
   "table-geometry"=>if let Control::Table(t)=&mut d.document_mut().sections[0].paragraphs[1].controls[0]{t.common.width+=1;},
   "section"=>d.document_mut().sections[0].section_def.page_def.margin_top+=1,
   "column"=>{for c in &mut d.document_mut().sections[0].paragraphs[0].controls{if let Control::ColumnDef(cd)=c{cd.spacing+=1;}}},
   "raw-control"=>if let Control::Table(t)=&mut d.document_mut().sections[0].paragraphs[1].controls[0]{t.raw_ctrl_data.push(0);},
   "index"=>{d.insert_paragraph_native(0,1).unwrap();},_=>{}}
  prefix(&mut d);let idx=if name=="index"{2}else{1};match name{
   "budget"=>d.document_mut().sections[0].paragraphs[idx].raw_header_extra=vec![0;2*1024*1024+1],
   "root-height"=>d.document_mut().sections[0].paragraphs[idx].line_segs[0].line_height+=1,
   "root-spacing"=>d.document_mut().sections[0].paragraphs[idx].line_segs[0].line_spacing+=1,
   "root-tag"=>d.document_mut().sections[0].paragraphs[idx].line_segs[0].tag|=1<<31,
   "next-tag"=>d.document_mut().sections[0].paragraphs[idx+1].line_segs[0].tag&=!(1<<31),
   "child-vpos"=>if let Control::Table(t)=&mut d.document_mut().sections[0].paragraphs[idx].controls[0]{t.cells[0].paragraphs[0].line_segs[0].vertical_pos+=1;},_=>{}}
  let state=format!("{:?}",d.document());let p=proof(&d,idx,"");assert_eq!(p["token"],false,"{name}: {p}");assert_eq!(p["acceptedHalfPolicy"],false,"{name}: {p}");assert_eq!(state,format!("{:?}",d.document()));rows.push(json!({"case":name,"proof":p,"sourceUnchanged":true}));
 }
 for name in ["duplicate","cumulative-zero","cumulative-step","measure-nan","measure-height","cell-spacing"]{let mut d=original();prefix(&mut d);let p=proof(&d,1,name);assert_eq!(p["token"],true);assert_eq!(p["acceptedHalfPolicy"],false,"{name}: {p}");rows.push(json!({"case":name,"proof":p}));}
 // A free current root translation is deliberately not a reset/origin owner.
 let mut d=original();prefix(&mut d);d.document_mut().sections[0].paragraphs[1].line_segs[0].vertical_pos+=1;let p=proof(&d,1,"");assert_eq!(p["token"],true);assert_eq!(p["oldFullResetInput"],false);rows.push(json!({"case":"vpos-excluded-only-from-spacing","proof":p}));
 for field in ["negative","overflow"]{let mut d=original();prefix(&mut d);d.document_mut().sections[0].paragraphs[1].line_segs[0].vertical_pos=if field=="negative"{-1}else{i32::MAX};let p=proof(&d,1,"");assert_eq!(p["token"],false);assert_eq!(p["acceptedHalfPolicy"],false);rows.push(json!({"case":field,"proof":p}));}
 // Actual source full-spacing true path must never receive the new token.
 let mut d=original();d.document_mut().sections[0].paragraphs[2].line_segs[0].tag&=!(1<<31);let a=rhwp::serializer::serialize_hwp_with_report(d.document()).unwrap();assert_eq!(a.content_loss().len(),0);let mut n=DocumentCore::from_bytes(a.bytes()).unwrap();let before=proof(&n,1,"");assert_eq!(before["sourceFormFullSpacingPredicate"],true);assert_eq!(before["token"],false);prefix(&mut n);let after=proof(&n,1,"");assert_eq!(after["sourceFormFullSpacingPredicate"],true);assert_eq!(after["token"],false);assert_eq!(after["acceptedHalfPolicy"],false);rows.push(json!({"case":"source-full-remains-full","before":before,"after":after}));
 n.document_mut().sections[0].paragraphs[1].line_segs[0].vertical_pos+=1;let changed=proof(&n,1,"");assert_eq!(changed["sourceFormFullSpacingPredicate"],false);assert_eq!(changed["token"],false);assert_eq!(changed["acceptedHalfPolicy"],false);rows.push(json!({"case":"source-full-adjacency-broken-must-not-mint-half","proof":changed}));

 // XML→Native ordinary export omits synthetic carrier rows. Absence of the
 // first next row is a separate source/current full=false fact, not a row grant.
 let absent_source=std::fs::read(root().join("build/n001-native-tac126/followup/one-tac.hwpx-saved.hwp")).unwrap();
 let mut a=DocumentCore::from_bytes(&absent_source).unwrap();let tail=a.document().sections[0].paragraphs.len()-1;let end=a.document().sections[0].paragraphs[tail].text.chars().count();a.insert_text_native(0,tail,end," Follow-up own edit.").unwrap();let p=proof(&a,1,"");assert_eq!(p["token"],true);assert_eq!(p["acceptedHalfPolicy"],true);assert_eq!(p["sourceFormFullSpacingPredicate"],false);rows.push(json!({"case":"present-next-without-first-row-full-false","proof":p}));
 for tag in [0x60000u32,0x80060000]{let mut a=DocumentCore::from_bytes(&absent_source).unwrap();a.document_mut().sections[0].paragraphs[2].line_segs.push(rhwp::model::paragraph::LineSeg{tag,..Default::default()});let p=proof(&a,1,"");let expected=tag&(1<<31)!=0;assert_eq!(p["token"],expected);assert_eq!(p["acceptedHalfPolicy"],expected);assert_eq!(p["sourceFormFullSpacingPredicate"],false);rows.push(json!({"case":format!("next-row-absent-to-present-{tag:x}"),"policyEquivalent":expected,"proof":p}));}
 let mut a=original();a.document_mut().sections[0].paragraphs[2].line_segs.clear();let p=proof(&a,1,"");assert_eq!(p["token"],true);assert_eq!(p["acceptedHalfPolicy"],true);assert_eq!(p["sourceFormFullSpacingPredicate"],false);rows.push(json!({"case":"next-row-impl-present-to-absent-policy-equivalent","proof":p}));
 let mut a=DocumentCore::from_bytes(&absent_source).unwrap();a.document_mut().sections[0].paragraphs.truncate(2);let p=proof(&a,1,"");assert_eq!(p["token"],false);assert_eq!(p["acceptedHalfPolicy"],false);rows.push(json!({"case":"absent-next-paragraph-is-not-present-empty-rows","proof":p}));
 let mut a=original();a.document_mut().sections[0].paragraphs[2].text="Different immediate-slot body".into();let p=proof(&a,1,"");assert_eq!(p["token"],true);assert_eq!(p["acceptedHalfPolicy"],true);assert_eq!(p["sourceFormFullSpacingPredicate"],false);rows.push(json!({"case":"same-slot-body-not-a-policy-dependency","claim":"No next identity/row authority is issued","proof":p}));
 let out=root().join("build/n001-native-tac126/negative-results.json");std::fs::write(out,serde_json::to_vec_pretty(&json!({"scope":"actual parsed input observation and actual measurement spacing-only policy proof; wrapper is private Native only and excluded from production patch","cases":rows,"status":"PASS"})).unwrap()).unwrap();
}
