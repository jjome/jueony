//! [#4493] DocInfo raw 캐시 출처 봉인(provenance seal).
//!
//! ## 문제
//!
//! 공개 저수준 API 는 `parse_document → model::Document 직접 변경 →
//! serialize_document` 를 허용하는데, HWP 파싱은 `DocInfo.raw_stream` 과 레코드별
//! `raw_data` 를 채우고 `raw_stream_dirty=false` 로 남긴다. 공개 모델 필드를 직접
//! 바꾸면 dirty 표식이 서지 않으므로, 저장 시 원본 바이트 통과(스트림·레코드
//! 양쪽)가 그대로 발동해 **메모리에서 보이던 변경이 저장·재로드 뒤 조용히
//! 사라진다.**
//!
//! ## 처방 — 봉인과 검증
//!
//! 파싱과 모든 load fixup 이 끝난 시점(`parse_document_inner` 말미)에 봉인한다.
//!
//! - **스트림 봉인** — 원본 DocInfo 바이트와 모델 상태의 다이제스트 쌍. 저장 시
//!   둘 다 일치할 때만 `raw_stream` 전체 통과를 허용한다. 공개 `raw_stream` 을
//!   다른 바이트로 교체해도(raw digest 불일치) 봉인으로 승인되지 않는다.
//! - **레코드 봉인** — DocInfo 의 레코드별 `raw_data` 지름길(BIN_DATA·FACE_NAME·
//!   BORDER_FILL·CHAR_SHAPE·TAB_DEF·NUMBERING·BULLET·PARA_SHAPE·STYLE·
//!   DOCUMENT_PROPERTIES)에 대응하는 레코드 단위 다이제스트. 스트림이 재생성될
//!   때 **변경되지 않은 레코드만** 원본 바이트를 재사용하고, 변경된 레코드는
//!   모델 writer 로 다시 쓴다 — 하위 raw 를 무조건 폐기해 미모델링 바이트를
//!   잃는 방식은 쓰지 않는다(#4495 와 같은 원칙).
//!
//! 봉인은 모델 타입에 필드를 넣지 않고 이 모듈의 컨테이너(인덱스 정렬)로
//! 중앙 보관한다 — 목록 삽입·삭제로 인덱스가 어긋나면 다이제스트가 어긋나
//! 재생성으로 떨어지므로 안전한 방향으로 실패한다.
//!
//! ## 다이제스트 규약
//!
//! serde 직렬화(JSON 인코딩)를 blake3 로 해시한다 — `Debug`/`DefaultHasher`/
//! 재귀 `Clone` 스냅샷에 의존하지 않는다. serde_json 은 구조체 필드를 선언
//! 순서로, 숫자·float 를 결정적 표기(ryu/itoa)로 방출하므로 같은 프로세스에서
//! 항상 같은 바이트를 낸다. DocInfo 트리에는 순회 순서가 비결정적인 맵 타입이
//! 없다(생기면 이 모듈에서 정렬 직렬화로 감싸야 한다). 봉인 대상 필드는
//! [`doc_info_model_digest`] 가 **전수 구조분해**로 나열한다 — 필드 추가 시
//! 컴파일 오류로 목록 갱신을 강제한다.
//!
//! Section(`raw_stream`)·본문 컨트롤 raw 레코드의 같은 계약은 #4488·#4495 가
//! 별도로 다룬다 — 스트림·소유자가 다르다.

use serde::Serialize;

use super::document::{DocInfo, DocProperties};

/// 파싱 완료 시점의 DocInfo 봉인.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DocInfoSeal {
    /// 봉인 시점 모델 상태의 다이제스트 ([`doc_info_model_digest`]).
    pub model_digest: [u8; 32],
    /// 봉인 시점 `raw_stream` 바이트의 다이제스트.
    pub raw_digest: [u8; 32],
    /// 레코드별 봉인 — 인덱스는 봉인 시점 목록 순서.
    pub record_seals: DocInfoRecordSeals,
}

/// 레코드별 `raw_data` 지름길에 대응하는 다이제스트 묶음.
#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub struct DocInfoRecordSeals {
    pub props: [u8; 32],
    pub bin_data: Vec<[u8; 32]>,
    /// 언어 축(바깥)×글꼴(안) — `DocInfo.font_faces` 와 같은 모양.
    pub fonts: Vec<Vec<[u8; 32]>>,
    pub border_fills: Vec<[u8; 32]>,
    pub char_shapes: Vec<[u8; 32]>,
    pub tab_defs: Vec<[u8; 32]>,
    pub numberings: Vec<[u8; 32]>,
    pub bullets: Vec<[u8; 32]>,
    pub para_shapes: Vec<[u8; 32]>,
    pub styles: Vec<[u8; 32]>,
}

/// 바이트 열의 다이제스트.
pub fn bytes_digest(bytes: &[u8]) -> [u8; 32] {
    *blake3::hash(bytes).as_bytes()
}

/// 레코드(직렬화 가능한 모델 값) 하나의 다이제스트.
///
/// 레코드의 `raw_data` 필드도 다이제스트에 포함된다 — 모델 필드가 변하지 않는 한
/// `raw_data` 는 파싱 시점 그대로이므로 판정에 영향이 없고, `raw_data` 만 바꿔치기
/// 하는 변경도 불일치로 떨어져 승인되지 않는다.
pub fn record_digest<T: Serialize>(record: &T) -> [u8; 32] {
    let mut hasher = blake3::Hasher::new();
    serde_json::to_writer(&mut hasher, record)
        .expect("레코드 다이제스트 직렬화는 실패할 수 없다 (순수 인메모리 인코딩)");
    *hasher.finalize().as_bytes()
}

/// 봉인 컨테이너에서 `idx` 레코드의 raw 재사용 허용 여부.
///
/// - 봉인 자체가 없으면(`seals=None`, 파서를 거치지 않은 합성 IR) 종전 계약대로
///   허용한다.
/// - 봉인이 있으면 인덱스가 범위 안이고 다이제스트가 일치할 때만 허용한다 —
///   목록 삽입·삭제로 인덱스가 밀리면 불일치로 떨어져 모델 writer 로 재생성된다.
pub fn record_raw_permitted<T: Serialize>(
    seals: Option<&[[u8; 32]]>,
    idx: usize,
    record: &T,
) -> bool {
    match seals {
        None => true,
        Some(seals) => seals
            .get(idx)
            .is_some_and(|sealed| *sealed == record_digest(record)),
    }
}

/// DocInfo(+DocProperties) 모델 상태의 다이제스트.
///
/// 저장 산출물에 실리는 모델 필드 전부를 선언 순서로 직렬화해 해시한다.
/// 구조분해에 `..` 를 쓰지 않는 것이 계약이다 — 새 필드가 생기면 여기가
/// 컴파일 오류를 내서 "봉인 대상인가"의 판단을 강제한다. raw 캐시 자신
/// (`raw_stream`)과 그 관리 표식(`raw_stream_dirty`, `raw_provenance`), 통과
/// 경로가 스스로 처리하는 `distribute_doc_data_removed`(surgical remove)는 뺀다.
pub fn doc_info_model_digest(doc_info: &DocInfo, doc_props: &DocProperties) -> [u8; 32] {
    let DocInfo {
        bin_data_list,
        font_faces,
        border_fills,
        char_shapes,
        tab_defs,
        numberings,
        bullets,
        para_shapes,
        styles,
        extra_records,
        // [Issue #6208] `print_method` 는 `extra_records` 의 `HWPTAG_DOC_DATA`
        // (HWPX 는 aux `settings.xml`)에서 **읽어 낸 파생값**이라 저장 산출물에
        // 스스로 실리지 않는다 — 권위 바이트는 이미 `extra_records` 로 봉인된다.
        // 여기에 넣으면 같은 정보를 두 번 세어 raw 재사용을 근거 없이 깬다.
        print_method: _,
        raw_stream: _,
        bullet_count,
        memo_shape_count,
        memo_properties_xml,
        distribute_doc_data_removed: _,
        raw_stream_dirty: _,
        hwpx_head_tail,
        hwpml_version,
        raw_provenance: _,
    } = doc_info;

    #[derive(Serialize)]
    struct Fingerprint<'a> {
        bin_data_list: &'a [crate::model::bin_data::BinData],
        font_faces: &'a [Vec<crate::model::style::Font>],
        border_fills: &'a [crate::model::style::BorderFill],
        char_shapes: &'a [crate::model::style::CharShape],
        tab_defs: &'a [crate::model::style::TabDef],
        numberings: &'a [crate::model::style::Numbering],
        bullets: &'a [crate::model::style::Bullet],
        para_shapes: &'a [crate::model::style::ParaShape],
        styles: &'a [crate::model::style::Style],
        extra_records: &'a [crate::model::document::RawRecord],
        bullet_count: u32,
        memo_shape_count: u32,
        memo_properties_xml: &'a Option<String>,
        hwpx_head_tail: &'a Option<String>,
        hwpml_version: &'a Option<String>,
        props: &'a DocProperties,
    }

    let fp = Fingerprint {
        bin_data_list,
        font_faces,
        border_fills,
        char_shapes,
        tab_defs,
        numberings,
        bullets,
        para_shapes,
        styles,
        extra_records,
        bullet_count: *bullet_count,
        memo_shape_count: *memo_shape_count,
        memo_properties_xml,
        hwpx_head_tail,
        hwpml_version,
        props: doc_props,
    };

    let mut hasher = blake3::Hasher::new();
    serde_json::to_writer(&mut hasher, &fp)
        .expect("모델 다이제스트 직렬화는 실패할 수 없다 (순수 인메모리 인코딩)");
    *hasher.finalize().as_bytes()
}

/// 레코드 봉인 묶음 계산 — 봉인 시점의 목록 순서 그대로.
fn compute_record_seals(doc_info: &DocInfo, doc_props: &DocProperties) -> DocInfoRecordSeals {
    DocInfoRecordSeals {
        props: record_digest(doc_props),
        bin_data: doc_info.bin_data_list.iter().map(record_digest).collect(),
        fonts: doc_info
            .font_faces
            .iter()
            .map(|lang| lang.iter().map(record_digest).collect())
            .collect(),
        border_fills: doc_info.border_fills.iter().map(record_digest).collect(),
        char_shapes: doc_info.char_shapes.iter().map(record_digest).collect(),
        tab_defs: doc_info.tab_defs.iter().map(record_digest).collect(),
        numberings: doc_info.numberings.iter().map(record_digest).collect(),
        bullets: doc_info.bullets.iter().map(record_digest).collect(),
        para_shapes: doc_info.para_shapes.iter().map(record_digest).collect(),
        styles: doc_info.styles.iter().map(record_digest).collect(),
    }
}

impl DocInfo {
    /// 파싱(+로드 픽스업) 완료 시점에 호출 — raw 캐시가 있으면 현재 모델 상태와
    /// 함께 봉인한다. raw 가 없으면(HWPX/HWP3/합성 IR) 봉인도 없다.
    pub fn seal_raw_provenance(&mut self, doc_props: &DocProperties) {
        self.raw_provenance = self.raw_stream.as_ref().map(|raw| DocInfoSeal {
            model_digest: doc_info_model_digest(self, doc_props),
            raw_digest: bytes_digest(raw),
            record_seals: compute_record_seals(self, doc_props),
        });
    }

    /// 저장 시점 스트림 통과 검증 — raw 바이트와 모델 상태가 둘 다 봉인과 같은가.
    ///
    /// 봉인이 없는 raw(`raw_provenance=None`, 파서를 거치지 않은 합성 IR 등)는
    /// 종전 계약대로 통과를 허용한다 — 봉인은 공개 parse→mutate→serialize
    /// 경로의 손실을 막기 위한 것이고, 파서가 만든 문서에는 항상 봉인이 있다.
    pub fn raw_provenance_permits_reuse(&self, doc_props: &DocProperties) -> bool {
        let Some(raw) = self.raw_stream.as_ref() else {
            return false;
        };
        match &self.raw_provenance {
            None => true,
            Some(seal) => {
                seal.raw_digest == bytes_digest(raw)
                    && seal.model_digest == doc_info_model_digest(self, doc_props)
            }
        }
    }
}

// ===========================================================================
// [#4488] Section raw_stream 봉인 + [#4495] 본문 컨트롤 하위 raw 봉인
// ===========================================================================

/// 파싱 완료 시점의 Section 봉인 — DocInfo 와 같은 계약, 다른 스트림·소유자.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SectionSeal {
    /// 봉인 시점 모델 상태(section_def + paragraphs)의 다이제스트.
    pub model_digest: [u8; 32],
    /// 봉인 시점 `raw_stream` 바이트의 다이제스트.
    pub raw_digest: [u8; 32],
}

/// Section 모델 상태의 다이제스트 — raw 캐시 필드는 전수 구조분해로 뺀다.
pub fn section_model_digest(section: &crate::model::document::Section) -> [u8; 32] {
    let crate::model::document::Section {
        section_def,
        paragraphs,
        raw_stream: _,
        raw_provenance: _,
    } = section;

    #[derive(Serialize)]
    struct Fingerprint<'a> {
        section_def: &'a crate::model::document::SectionDef,
        paragraphs: &'a [crate::model::paragraph::Paragraph],
    }

    let mut hasher = blake3::Hasher::new();
    serde_json::to_writer(
        &mut hasher,
        &Fingerprint {
            section_def,
            paragraphs,
        },
    )
    .expect("모델 다이제스트 직렬화는 실패할 수 없다 (순수 인메모리 인코딩)");
    *hasher.finalize().as_bytes()
}

impl crate::model::document::Section {
    /// 파싱(+로드 픽스업) 완료 시점에 호출 — raw 캐시가 있으면 봉인한다.
    pub fn seal_raw_provenance(&mut self) {
        self.raw_provenance = self.raw_stream.as_ref().map(|raw| SectionSeal {
            model_digest: section_model_digest(self),
            raw_digest: bytes_digest(raw),
        });
    }

    /// 저장 시점 검증 — DocInfo 쪽과 동일 계약(봉인 없는 raw 는 종전대로 허용).
    pub fn raw_provenance_permits_reuse(&self) -> bool {
        let Some(raw) = self.raw_stream.as_ref() else {
            return false;
        };
        match &self.raw_provenance {
            None => true,
            Some(seal) => {
                seal.raw_digest == bytes_digest(raw)
                    && seal.model_digest == section_model_digest(self)
            }
        }
    }
}

/// [#4495] OLE payload(raw_tag_data)가 대표하는 모델 필드의 다이제스트.
///
/// `serialize_ole_data` 의 모델 경로가 소비하는 필드가 판정 범위다 — 그 밖의
/// 필드 변경은 이 레코드의 바이트에 영향을 주지 않으므로 raw 를 유지한다.
pub fn ole_payload_digest(ole: &crate::model::shape::OleShape) -> [u8; 32] {
    record_digest(&(ole.extent_x, ole.extent_y, ole.bin_data_id))
}

/// [#4495] 하위 raw 레코드를 가진 컨트롤 전부를 깊이 우선으로 봉인한다.
///
/// - Table/Equation CTRL_HEADER raw ↔ `common`(CommonObjAttr) — 저장기가 raw
///   부재 시 합성하는 원천이 `common` 이므로 판정 범위도 `common` 이다.
///   (`raw_ctrl_data` 자체는 판정 밖 — 셀 폭 조절처럼 raw 를 직접 갱신하는
///   기존 명령(dual-write, table.rs `refresh_raw_ctrl_size` 참조)과 충돌하지
///   않기 위함이다.)
/// - OLE raw_tag_data ↔ payload 모델 필드([`ole_payload_digest`]).
///
/// 순회는 `for_each_ole_mut`(hwpx_to_hwp.rs)와 같은 소유자 집합을 밟는다 —
/// 저장소에 정본 순회기가 아직 없어(#4422) 여기 사본을 둔다. 누락되면 그
/// 컨트롤은 봉인 없이 남아 **종전 계약(raw 우선)** 으로 동작한다 — 새 검증이
/// 빠지는 것이지 새 손실이 생기는 방향이 아니다.
fn seal_raw_bearing_controls(paragraphs: &mut [crate::model::paragraph::Paragraph]) {
    seal_raw_bearing_controls_with_source_owner(paragraphs, None);
}

fn seal_raw_bearing_controls_with_source_owner(paragraphs: &mut [crate::model::paragraph::Paragraph], synthetic_context: Option<[u8; 32]>) {
    use crate::model::control::Control;
    use crate::model::shape::ShapeObject;

    fn walk_caption(caption: &mut crate::model::shape::Caption, synthetic_context: Option<[u8; 32]>) {
        seal_raw_bearing_controls_with_source_owner(&mut caption.paragraphs, synthetic_context);
    }

    fn walk_drawing(drawing: &mut crate::model::shape::DrawingObjAttr, synthetic_context: Option<[u8; 32]>) {
        if let Some(text_box) = &mut drawing.text_box {
            seal_raw_bearing_controls_with_source_owner(&mut text_box.paragraphs, synthetic_context);
        }
        if let Some(caption) = &mut drawing.caption {
            walk_caption(caption, synthetic_context);
        }
    }

    fn walk_shape(shape: &mut ShapeObject, synthetic_context: Option<[u8; 32]>) {
        match shape {
            ShapeObject::Picture(pic) => {
                if let Some(caption) = &mut pic.caption {
                    walk_caption(caption, synthetic_context);
                }
            }
            ShapeObject::Group(group) => {
                for child in &mut group.children {
                    walk_shape(child, synthetic_context);
                }
                if let Some(caption) = &mut group.caption {
                    walk_caption(caption, synthetic_context);
                }
            }
            ShapeObject::Chart(chart) => {
                walk_drawing(&mut chart.drawing, synthetic_context);
                if let Some(caption) = &mut chart.caption {
                    walk_caption(caption, synthetic_context);
                }
            }
            ShapeObject::Ole(ole) => {
                walk_drawing(&mut ole.drawing, synthetic_context);
                if let Some(caption) = &mut ole.caption {
                    walk_caption(caption, synthetic_context);
                }
                if !ole.raw_tag_data.is_empty() {
                    ole.raw_tag_seal = Some(ole_payload_digest(ole));
                }
            }
            _ => {
                if let Some(drawing) = shape.drawing_mut() {
                    walk_drawing(drawing, synthetic_context);
                }
            }
        }
    }

    for para in paragraphs {
        if let Some(context) = synthetic_context { para.bind_native_source_synthetic_context(context); }
        for control in &mut para.controls {
            match control {
                Control::Table(table) => {
                    for cell in &mut table.cells {
                        seal_raw_bearing_controls_with_source_owner(&mut cell.paragraphs, synthetic_context);
                    }
                    if let Some(caption) = &mut table.caption {
                        walk_caption(caption, synthetic_context);
                    }
                    if !table.raw_ctrl_data.is_empty() {
                        table.raw_ctrl_seal = Some(record_digest(&table.common));
                    }
                }
                Control::Equation(eq) => {
                    if !eq.raw_ctrl_data.is_empty() {
                        eq.raw_ctrl_seal = Some(record_digest(&eq.common));
                    }
                }
                Control::Picture(pic) => {
                    if let Some(caption) = &mut pic.caption {
                        walk_caption(caption, synthetic_context);
                    }
                }
                Control::Shape(shape) => walk_shape(shape, synthetic_context),
                Control::Header(header) => seal_raw_bearing_controls_with_source_owner(&mut header.paragraphs, synthetic_context),
                Control::Footer(footer) => seal_raw_bearing_controls_with_source_owner(&mut footer.paragraphs, synthetic_context),
                Control::Footnote(fnote) => seal_raw_bearing_controls_with_source_owner(&mut fnote.paragraphs, synthetic_context),
                Control::Endnote(enote) => seal_raw_bearing_controls_with_source_owner(&mut enote.paragraphs, synthetic_context),
                Control::HiddenComment(comment) => {
                    seal_raw_bearing_controls_with_source_owner(&mut comment.paragraphs, synthetic_context)
                }
                Control::Field(field) => seal_raw_bearing_controls_with_source_owner(&mut field.memo_paragraphs, synthetic_context),
                Control::SectionDef(section_def) => {
                    for master_page in &mut section_def.master_pages {
                        seal_raw_bearing_controls_with_source_owner(&mut master_page.paragraphs, synthetic_context);
                    }
                }
                _ => {}
            }
        }
    }
}

impl crate::model::document::Document {
    /// Shared font definitions, section geometry, whole content/order and every
    /// nested object frame participate. A cloned paragraph cannot import this
    /// authority into a different document/frame or after a shared style edit.
    pub(crate) fn native_source_synthetic_context_digest(&self) -> [u8; 32] {
        #[derive(Serialize)]
        struct ParagraphFrame<'a> {
            identity: Option<[u8; 4]>,
            para_shape: u16,
            style: u8,
            break_type: crate::model::paragraph::ColumnBreakType,
            raw_break_type: u8,
            shape_ids: Vec<u32>,
            controls: &'a [crate::model::control::Control],
        }
        #[derive(Serialize)]
        struct SectionFrame<'a> {
            section: &'a crate::model::document::SectionDef,
            paragraphs: Vec<ParagraphFrame<'a>>,
        }
        let sections: Vec<_> = self.sections.iter().map(|s| SectionFrame {
            section: &s.section_def,
            paragraphs: s.paragraphs.iter().map(|p| {
                let mut shape_ids: Vec<_> = p.char_shapes.iter().map(|r| r.char_shape_id).collect();
                shape_ids.sort_unstable(); shape_ids.dedup();
                ParagraphFrame {
                    identity: p.raw_header_extra.get(6..10).and_then(|id| id.try_into().ok()),
                    para_shape: p.para_shape_id, style: p.style_id, break_type: p.column_type,
                    raw_break_type: p.raw_break_type, shape_ids, controls: &p.controls,
                }
            }).collect(),
        }).collect();
        // Plain body text and derived LINE_SEGs are checked by each local seal,
        // not a global source revocation: typing in a later plain paragraph
        // cannot erase a preceding table's frame authority. All object trees,
        // cell content, paragraph order/identity, page/column declarations and
        // referenced font/style definitions remain part of this owner context.
        // A stored caret is session state, not a page/frame input. The
        // DOCUMENT_PROPERTIES parser/writer puts exactly three u32 caret
        // fields after seven u16 values (payload 14..26). Keep every other
        // raw byte, raw length and unknown extension bound to this owner.
        let mut frame_properties = self.doc_properties.clone();
        if let Some(raw) = &mut frame_properties.raw_data {
            if let Some(caret) = raw.get_mut(14..26) { caret.fill(0); }
        }
        frame_properties.caret_list_id = 0;
        frame_properties.caret_para_id = 0;
        frame_properties.caret_char_pos = 0;
        record_digest(&(doc_info_model_digest(&self.doc_info, &frame_properties), sections))
    }

    /// Called once after initial load materialization; never by edit or export.
    pub(crate) fn bind_native_source_synthetic_context(&mut self) {
        let context = self.native_source_synthetic_context_digest();
        for section in &mut self.sections {
            seal_raw_bearing_controls_with_source_owner(&mut section.paragraphs, Some(context));
            for page in &mut section.section_def.master_pages {
                seal_raw_bearing_controls_with_source_owner(&mut page.paragraphs, Some(context));
            }
        }
    }

    /// [#4488/#4495] 본문 raw 캐시 전부를 봉인한다 — 파싱(+로드 픽스업) 완료
    /// 시점에 호출. 컨트롤 봉인을 먼저 세우고(봉인 필드는 `#[serde(skip)]` 이라
    /// Section 다이제스트에 실리지 않는다) Section 봉인을 계산한다.
    pub fn seal_body_raw_provenance(&mut self) {
        let reset_contexts = self.reset_flow_contexts();
        let native_plain_spacing=self.layout_profile().native_hwp5_layout();
        for (index, section) in self.sections.iter_mut().enumerate() {
            seal_raw_bearing_controls(&mut section.paragraphs);
            for master_page in &mut section.section_def.master_pages {
                seal_raw_bearing_controls(&mut master_page.paragraphs);
            }
            // These are only the two actual parser/load call sites. The Some
            // synthetic-owner walker above never observes reset inputs.
            observe_loaded_reset_inputs(&mut section.paragraphs,
                reset_contexts.get(index).copied().flatten(),native_plain_spacing);
            section.seal_raw_provenance();
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn digest_changes_when_model_changes() {
        let mut di = DocInfo::default();
        let props = DocProperties::default();
        let before = doc_info_model_digest(&di, &props);
        di.char_shapes
            .push(crate::model::style::CharShape::default());
        let after = doc_info_model_digest(&di, &props);
        assert_ne!(before, after, "char_shapes 변경이 다이제스트에 실려야 한다");
    }

    #[test]
    fn digest_ignores_raw_cache_fields() {
        let mut di = DocInfo::default();
        let props = DocProperties::default();
        let before = doc_info_model_digest(&di, &props);
        di.raw_stream = Some(vec![1, 2, 3]);
        di.raw_stream_dirty = true;
        di.distribute_doc_data_removed = true;
        let after = doc_info_model_digest(&di, &props);
        assert_eq!(before, after, "raw 캐시 표식은 모델 다이제스트 밖이다");
    }

    #[test]
    fn sealed_raw_reuse_denied_after_model_mutation() {
        let mut di = DocInfo::default();
        let props = DocProperties::default();
        di.raw_stream = Some(vec![9, 9, 9]);
        di.seal_raw_provenance(&props);
        assert!(di.raw_provenance_permits_reuse(&props), "무변경이면 재사용");

        di.para_shapes
            .push(crate::model::style::ParaShape::default());
        assert!(
            !di.raw_provenance_permits_reuse(&props),
            "공개 모델 직접 변경 뒤에는 raw 재사용이 거부돼야 한다 (#4493)"
        );
    }

    #[test]
    fn sealed_raw_reuse_denied_after_raw_swap() {
        let mut di = DocInfo::default();
        let props = DocProperties::default();
        di.raw_stream = Some(vec![9, 9, 9]);
        di.seal_raw_provenance(&props);

        di.raw_stream = Some(vec![8, 8, 8]);
        assert!(
            !di.raw_provenance_permits_reuse(&props),
            "raw 바이트 교체는 기존 봉인으로 승인되지 않는다 (#4493)"
        );
    }

    #[test]
    fn unsealed_raw_keeps_legacy_passthrough() {
        let mut di = DocInfo::default();
        let props = DocProperties::default();
        di.raw_stream = Some(vec![7]);
        assert!(
            di.raw_provenance_permits_reuse(&props),
            "봉인 이전(합성 IR) 경로는 종전 계약 유지"
        );
    }

    #[test]
    fn record_raw_permission_follows_seal() {
        let cs = crate::model::style::CharShape::default();
        let sealed = [record_digest(&cs)];
        assert!(record_raw_permitted(Some(&sealed), 0, &cs), "무변경 허용");
        assert!(
            !record_raw_permitted(Some(&sealed), 1, &cs),
            "범위 밖(새 레코드)은 모델 writer"
        );
        let mut changed = cs;
        changed.base_size = 2000;
        assert!(
            !record_raw_permitted(Some(&sealed), 0, &changed),
            "변경 레코드는 raw 재사용 거부"
        );
        assert!(
            record_raw_permitted(None, 0, &changed),
            "봉인 없는 합성 IR 은 종전 계약"
        );
    }
}

#[cfg(test)]
mod native_synthetic_source_owner_tests {
    use crate::model::{document::{Document, Section}, paragraph::{Paragraph, LineSeg}, style::CharShape};

    fn source() -> Document {
        let mut para = Paragraph::new_empty();
        para.text = "OWN".into(); para.char_count = 4;
        para.char_offsets = vec![0, 1, 2];
        para.line_segs[0].tag = 0x8006_0000;
        para.line_segs[0].segment_width = 40000;
        para.char_shapes = vec![crate::model::paragraph::CharShapeRef { start_pos: 0, char_shape_id: 0 }];
        para.controls.push(crate::model::control::Control::ColumnDef(crate::model::page::ColumnDef::default()));
        para.controls.push(crate::model::control::Control::Table(Box::new(crate::model::table::Table::default())));
        para.seal_native_source_synthetic_rows();
        let mut doc = Document::default();
        doc.doc_info.char_shapes.push(CharShape::default());
        doc.sections.push(Section { paragraphs: vec![para], ..Section::default() });
        doc.bind_native_source_synthetic_context();
        doc
    }
    fn owns(doc: &Document) -> bool {
        doc.sections[0].paragraphs[0].owns_native_source_synthetic_rows(
            doc.native_source_synthetic_context_digest())
    }
    #[test]
    fn exact_clone_and_restored_state_keep_source_authority() {
        let doc = source(); assert!(owns(&doc)); assert!(owns(&doc.clone()));
        let mut changed = doc.clone(); changed.sections[0].section_def.page_def.width += 7200;
        assert!(!owns(&changed)); changed = doc.clone(); assert!(owns(&changed));
    }
    #[test]
    fn shared_font_and_page_frame_changes_cannot_reuse_source_rows() {
        for mutation in 0..9 {
            let mut doc = source();
            match mutation {
                0 => doc.sections[0].section_def.page_def.width += 1,
                1 => doc.sections[0].section_def.page_def.margin_left += 1,
                2 => doc.doc_info.char_shapes[0].base_size += 1,
                3 => doc.doc_info.char_shapes[0].font_ids[0] += 1,
                4 => if let crate::model::control::Control::ColumnDef(c) = &mut doc.sections[0].paragraphs[0].controls[0] { c.column_count += 1; },
                5 => if let crate::model::control::Control::Table(t) = &mut doc.sections[0].paragraphs[0].controls[1] { t.common.width += 1; },
                6 => if let crate::model::control::Control::Table(t) = &mut doc.sections[0].paragraphs[0].controls[1] { t.common.height += 1; },
                7 => doc.sections[0].paragraphs[0].char_shapes[0].char_shape_id += 1,
                _ => doc.sections[0].paragraphs.push(Paragraph::new_empty()),
            }
            assert!(!owns(&doc));
            doc.bind_native_source_synthetic_context();
            assert!(!owns(&doc), "rebinding must not bless a changed frame");
        }
    }
    #[test]
    fn unrelated_plain_body_text_does_not_revoke_a_preceding_frame() {
        let mut doc = source();
        doc.sections[0].paragraphs.push(Paragraph::new_empty());
        // This is the initial source frame, not a post-edit rebind.
        doc.sections[0].paragraphs[0].native_source_synthetic_context = None;
        doc.bind_native_source_synthetic_context();
        assert!(owns(&doc));
        doc.sections[0].paragraphs[1].text = "later text grows".into();
        doc.sections[0].paragraphs[1].char_count = 17;
        doc.sections[0].paragraphs[1].invalidate_layout_inputs();
        assert!(owns(&doc));
    }

    #[test]
    fn row_edit_and_reflow_clear_original_source_authority() {
        let mut doc = source(); doc.sections[0].paragraphs[0].invalidate_layout_inputs();
        assert!(!owns(&doc));
        let mut doc = source();
        let rows = doc.sections[0].paragraphs[0].line_segs.clone();
        doc.sections[0].paragraphs[0].replace_line_segs(rows);
        assert!(!owns(&doc));
        doc.bind_native_source_synthetic_context(); assert!(!owns(&doc));
    }
    #[test]
    fn source_row_transplant_into_a_changed_owner_is_rejected() {
        let mut doc = source();
        let mut foreign = source(); foreign.sections[0].section_def.page_def.height += 1;
        doc.sections[0].paragraphs[0] = foreign.sections[0].paragraphs[0].clone();
        // The foreign source was bound before its frame changed; no new authority
        // appears merely because source paragraph bytes happen to match.
        foreign.bind_native_source_synthetic_context(); assert!(!owns(&foreign));
        doc.sections[0].section_def.page_def.height += 1;
        assert!(!owns(&doc));
    }
    #[test]
    fn unowned_runtime_rows_never_gain_authority_by_binding() {
        let mut doc = source();
        doc.sections[0].paragraphs[0].native_source_synthetic_seal = None;
        doc.sections[0].paragraphs[0].native_source_synthetic_context = None;
        doc.bind_native_source_synthetic_context(); assert!(!owns(&doc));
    }


    #[test]
    fn saved_caret_is_not_a_frame_input_but_unknown_raw_suffix_is() {
        let mut doc = source();
        doc.doc_properties.raw_data = Some(vec![0; 30]);
        doc.sections[0].paragraphs[0].native_source_synthetic_context = None;
        doc.bind_native_source_synthetic_context();
        doc.doc_properties.caret_list_id = 7;
        doc.doc_properties.caret_para_id = 5;
        doc.doc_properties.caret_char_pos = 12;
        doc.doc_properties.raw_data.as_mut().unwrap()[14..26].fill(9);
        assert!(owns(&doc));
        let mut changed = doc.clone();
        changed.doc_properties.raw_data.as_mut().unwrap()[29] = 1;
        assert!(!owns(&changed), "unknown suffix remains bound");
        let mut changed = doc.clone();
        changed.doc_properties.raw_data.as_mut().unwrap()[13] = 1;
        assert!(!owns(&changed), "non-caret prefix remains bound");
        doc.doc_properties.page_start_num += 1;
        assert!(!owns(&doc), "numbering remains a layout input");
    }
}


/// An observation of input equality, not permission to reuse raw bytes or rows.
/// Never serialized. Only the actual read/load boundary records it, and only
/// the stale-reset override consumes it. In particular raw_ctrl_seal is unchanged.
#[derive(Debug, Clone, Copy)]
pub(crate) struct ResetFlowObservation {
    input: [u8; 32],
    context: [u8; 32],
    native_tac_spacing_input: Option<[u8;32]>,
}

#[path="native_tac_spacing_input126.rs"]
mod native_tac_spacing_input;
const RESET_INPUT_MAX_BYTES: usize = 2 * 1024 * 1024;
const RESET_INPUT_PASS_BYTES: usize = 16 * 1024 * 1024;
const RESET_INPUT_MAX_DEPTH: usize = 64;

/// Streaming and bounded: no whole JSON allocation or recursive Value walk.
/// JSON delimiters inside quoted/escaped text do not count toward the depth.
struct ResetInputDigest {
    hash: blake3::Hasher,
    remaining: usize,
    bytes: usize,
    depth: usize,
    quoted: bool,
    escaped: bool,
}
impl std::io::Write for ResetInputDigest {
    fn write(&mut self, bytes: &[u8]) -> std::io::Result<usize> {
        if bytes.len() > self.remaining {
            return Err(std::io::Error::new(std::io::ErrorKind::InvalidData, "reset observation byte budget"));
        }
        for &byte in bytes {
            if self.quoted {
                if self.escaped { self.escaped = false; }
                else if byte == b'\\' { self.escaped = true; }
                else if byte == b'"' { self.quoted = false; }
            } else {
                match byte {
                    b'"' => self.quoted = true,
                    b'{' | b'[' => {
                        self.depth += 1;
                        if self.depth > RESET_INPUT_MAX_DEPTH {
                            return Err(std::io::Error::new(std::io::ErrorKind::InvalidData, "reset observation depth budget"));
                        }
                    }
                    b'}' | b']' => self.depth = self.depth.checked_sub(1).ok_or_else(||
                        std::io::Error::new(std::io::ErrorKind::InvalidData, "reset observation delimiter"))?,
                    _ => {}
                }
            }
        }
        self.remaining -= bytes.len(); self.bytes += bytes.len();
        self.hash.update(bytes);
        Ok(bytes.len())
    }
    fn flush(&mut self) -> std::io::Result<()> { Ok(()) }
}
fn bounded_reset_digest<T: Serialize>(value: &T, budget: &mut usize) -> Option<[u8; 32]> {
    let mut writer = ResetInputDigest { hash: blake3::Hasher::new(),
        remaining: (*budget).min(RESET_INPUT_MAX_BYTES), bytes: 0,
        depth: 0, quoted: false, escaped: false };
    let success = serde_json::to_writer(&mut writer, value).is_ok();
    *budget = budget.saturating_sub(writer.bytes);
    (success && writer.depth == 0 && !writer.quoted)
        .then(|| *writer.hash.finalize().as_bytes())
}

impl crate::model::document::Document {
    /// One current context calculation per pass. No body/cell text participates:
    /// editing a later paragraph is not evidence that a preceding reset is stale.
    /// Bind actual definitions (not just IDs), unknown DocInfo records, the whole
    /// SectionDef and the positions/definitions of structural ColumnDef controls.
    /// A newly appended unused definition conservatively invalidates equality.
    pub(crate) fn reset_flow_contexts(&self) -> Vec<Option<[u8; 32]>> {
        // This projection intentionally excludes body content, raw stream
        // caches, seals and the derived print_method. Unknown definition bytes
        // remain bound. Exhaustive destructuring makes additions reviewable.
        let DocInfo { bin_data_list, font_faces, border_fills, char_shapes,
            tab_defs, numberings, bullets, para_shapes, styles, extra_records,
            print_method: _, raw_stream: _, bullet_count, memo_shape_count,
            memo_properties_xml, distribute_doc_data_removed: _, raw_stream_dirty: _,
            hwpx_head_tail, hwpml_version, raw_provenance: _ } = &self.doc_info;
        let mut budget = RESET_INPUT_PASS_BYTES;
        let Some(definitions) = bounded_reset_digest(&(
            bin_data_list, font_faces, border_fills, char_shapes, tab_defs,
            numberings, bullets, para_shapes, styles, extra_records, bullet_count,
            memo_shape_count, memo_properties_xml, hwpx_head_tail, hwpml_version,
        ), &mut budget) else { return vec![None; self.sections.len()]; };
        self.sections.iter().enumerate().map(|(section_index, section)| {
            let mut columns = Vec::new();
            for (pi, paragraph) in section.paragraphs.iter().enumerate() {
                for (ci, control) in paragraph.controls.iter().enumerate() {
                    if let crate::model::control::Control::ColumnDef(column) = control {
                        if columns.len() >= 4096 { return None; }
                        columns.push((pi, ci, column));
                    }
                }
            }
            bounded_reset_digest(&(
                "rhwp-reset-input-observation-1", super::native_computed_resource::RESOURCE,
                definitions, section_index, &section.section_def, columns,
            ), &mut budget)
        }).collect()
    }
}

fn observe_loaded_reset_inputs(paragraphs: &mut [crate::model::paragraph::Paragraph], context: Option<[u8; 32]>,native_plain:bool) {
    let mut budget = RESET_INPUT_PASS_BYTES;
    // This independent lane must not consume or change the existing reset
    // observation's byte budget, input digest, lifetime or interpretation.
    let mut spacing_budget=RESET_INPUT_PASS_BYTES;
    for index in 0..paragraphs.len() {
        let spacing=context.filter(|_|native_plain).and_then(|context|
            native_tac_spacing_input::input(index,&paragraphs[index],paragraphs.get(index+1),context,&mut spacing_budget));
        let original=context.and_then(|context|
            bounded_reset_digest(&(index,&paragraphs[index]),&mut budget)
                .map(|input|ResetFlowObservation{input,context,native_tac_spacing_input:spacing}));
        paragraphs[index].reset_flow_observation=original;
    }
}
pub(crate) fn unchanged_native_tac_spacing_input(index:usize,paragraph:&crate::model::paragraph::Paragraph,
    next:Option<&crate::model::paragraph::Paragraph>,context:Option<[u8;32]>,portable_resources:bool)->bool{
    if !portable_resources{return false;}
    let (Some(context),Some(observed))=(context,paragraph.reset_flow_observation)else{return false;};
    let Some(expected)=observed.native_tac_spacing_input else{return false;};
    let mut budget=RESET_INPUT_MAX_BYTES;
    observed.context==context && native_tac_spacing_input::input(index,paragraph,next,context,&mut budget)==Some(expected)
}

/// Compute once at section entry, not once per reset or nested paragraph. The
/// existing dirty/raw/physical checks remain separate requirements. Dynamically
/// supplied measurement resources are outside this portable observation scope.
pub(crate) fn unchanged_reset_input(index:usize, paragraph:&crate::model::paragraph::Paragraph,
    context:Option<[u8;32]>, portable_resources:bool)->bool {
    if !portable_resources{return false;}
    let (Some(context),Some(observed))=(context,paragraph.reset_flow_observation)else{return false;};
    let mut budget=RESET_INPUT_MAX_BYTES;
    observed.context==context && bounded_reset_digest(&(index,paragraph),&mut budget)==Some(observed.input)
}

pub(crate) fn unchanged_reset_inputs(
    paragraphs: &[crate::model::paragraph::Paragraph], context: Option<[u8; 32]>,
    portable_resources: bool,
) -> Vec<bool> {
    let mut budget = RESET_INPUT_PASS_BYTES;
    paragraphs.iter().enumerate().map(|(index, paragraph)| {
        if !portable_resources { return false; }
        let (Some(context), Some(observed)) = (context, paragraph.reset_flow_observation) else { return false; };
        observed.context == context && bounded_reset_digest(&(index, paragraph), &mut budget) == Some(observed.input)
    }).collect()
}


#[cfg(test)]
mod reset_flow_observation105_tests {
    use super::*;
    use crate::model::{document::{Document, Section}, paragraph::{Paragraph, LineSeg},
        control::Control, table::{Table, Cell}, page::ColumnDef, style::CharShape};
    fn fixture() -> Document {
        let mut document=Document::default();
        let child=Paragraph{text:"source".into(),line_segs:vec![LineSeg{line_height:100,..Default::default()}],..Default::default()};
        let table=Table{cells:vec![Cell{paragraphs:vec![child],..Default::default()}],..Default::default()};
        let host=Paragraph{controls:vec![Control::ColumnDef(ColumnDef::default()),Control::Table(Box::new(table))],..Default::default()};
        document.sections.push(Section{paragraphs:vec![host,Paragraph{text:"tail".into(),..Default::default()}],..Default::default()});
        document.doc_info.char_shapes.push(CharShape::default());
        document.seal_body_raw_provenance(); document
    }
    fn current(document:&Document)->Vec<bool> {
        unchanged_reset_inputs(&document.sections[0].paragraphs,
            document.reset_flow_contexts()[0],true)
    }
    #[test] fn native_empty_trailing105_observation_is_local_and_catches_retained_clean_host_text(){
        let mut doc=fixture(); assert_eq!(current(&doc),vec![true,true]);
        doc.sections[0].paragraphs[1].text.push('X');
        assert_eq!(current(&doc),vec![true,false]);
        let Control::Table(t)=&mut doc.sections[0].paragraphs[0].controls[1] else{panic!()};
        t.cells[0].paragraphs[0].text.push('X');
        t.cells[0].paragraphs[0].stored_text_partition_dirty=false;t.cells[0].dirty_flag=false;
        assert_eq!(current(&doc),vec![false,false]);
    }
    #[test] fn native_empty_trailing105_shared_definition_frame_unknown_raw_and_move_changes_deny_equality(){
        for case in 0..7 {
            let mut doc=fixture();match case {
                0=>doc.doc_info.char_shapes[0].base_size+=1,
                1=>doc.sections[0].section_def.page_def.width+=1,
                2=>if let Control::ColumnDef(c)=&mut doc.sections[0].paragraphs[0].controls[0]{c.spacing+=1;},
                3=>if let Control::Table(t)=&mut doc.sections[0].paragraphs[0].controls[1]{t.raw_table_record_extra.push(123);},
                4=>doc.sections[0].paragraphs.swap(0,1),
                5=>doc.sections[0].paragraphs[0].reset_flow_observation=None,
                _=>doc.doc_info.extra_records.push(Default::default()),
            }
            assert!(!current(&doc)[0],"case {case}");
        }
    }
    #[test] fn native_empty_trailing105_observation_never_creates_raw_rows_or_synthetic_owner(){
        let mut doc=fixture();let input=serde_json::to_vec(&doc.sections[0].paragraphs[0]).unwrap();
        let observation=doc.sections[0].paragraphs[0].reset_flow_observation.unwrap();
        let Control::Table(t)=&doc.sections[0].paragraphs[0].controls[1] else{panic!()};
        assert!(t.raw_ctrl_seal.is_none());
        assert!(doc.sections[0].paragraphs[0].native_source_synthetic_seal.is_none());
        doc.sections[0].paragraphs[0].reset_flow_observation=None;
        doc.bind_native_source_synthetic_context();
        assert!(doc.sections[0].paragraphs[0].reset_flow_observation.is_none());
        assert_eq!(input,serde_json::to_vec(&doc.sections[0].paragraphs[0]).unwrap());
        doc.sections[0].paragraphs[0].reset_flow_observation=Some(observation);
        let new=Paragraph::new_empty_like(&doc.sections[0].paragraphs[0]);
        assert!(new.reset_flow_observation.is_none());
        assert_eq!(unchanged_reset_inputs(&doc.sections[0].paragraphs,doc.reset_flow_contexts()[0],false),vec![false,false]);
    }
    #[test] fn native_empty_trailing105_columnless_move_and_context_budget_are_not_certified(){
        let mut doc=fixture();doc.sections[0].paragraphs[0].controls.remove(0);
        doc.seal_body_raw_provenance();assert_eq!(current(&doc),vec![true,true]);
        doc.sections[0].paragraphs.swap(0,1);assert_eq!(current(&doc),vec![false,false]);
        let mut doc=fixture();doc.doc_info.extra_records.push(crate::model::document::RawRecord{
            data:vec![0;RESET_INPUT_MAX_BYTES],..Default::default()});
        assert_eq!(doc.reset_flow_contexts(),vec![None]);
        let mut doc=fixture();doc.sections[0].paragraphs[0].controls.extend(
            (0..4096).map(|_|Control::ColumnDef(ColumnDef::default())));
        assert_eq!(doc.reset_flow_contexts(),vec![None]);
    }
    #[test] fn native_empty_trailing105_observation_depth_bytes_and_quoted_delimiters_are_bounded(){
        let mut budget=1024;assert!(bounded_reset_digest(&"\"[{}]\\",&mut budget).is_some());
        let mut budget=5;assert!(bounded_reset_digest(&"123456",&mut budget).is_none());
        let oversized="x".repeat(RESET_INPUT_MAX_BYTES+1);let mut budget=RESET_INPUT_PASS_BYTES;
        assert!(bounded_reset_digest(&oversized,&mut budget).is_none());
        let mut value=serde_json::Value::Null;
        for _ in 0..RESET_INPUT_MAX_DEPTH+1 {value=serde_json::Value::Array(vec![value]);}
        let mut budget=RESET_INPUT_MAX_BYTES;assert!(bounded_reset_digest(&value,&mut budget).is_none());
        let mut doc=fixture();let p=doc.sections[0].paragraphs[0].clone();
        doc.sections[0].paragraphs[0]=Paragraph{reset_flow_observation:p.reset_flow_observation,text:oversized,..p};
        assert!(!current(&doc)[0]);
    }
}
