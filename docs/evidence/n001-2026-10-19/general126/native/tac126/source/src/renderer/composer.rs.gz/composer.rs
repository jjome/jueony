//! 문서 구조 구성 (Document Composition)
//!
//! 문단의 텍스트를 줄 단위로 분할하고, 각 줄 내에서
//! CharShapeRef 경계에 따라 다중 TextRun으로 분할한다.
//! 인라인 컨트롤(표/도형) 삽입 위치를 식별한다.

use super::layout::{
    control_line_seg_index, estimate_text_width, estimate_text_width_unrounded,
    hancom_regenerated_space_width, map_pua_bullet_char, resolved_to_text_style,
};
use super::style_resolver::{detect_lang_category, ResolvedStyleSet};
use super::{hwpunit_to_px, px_to_hwpunit, TextStyle};
use crate::model::control::Control;
use crate::model::document::Section;
pub use crate::model::paragraph::SpaceMetric;
use crate::model::paragraph::{CharShapeRef, LineSeg, Paragraph};
use crate::model::shape::Caption;
use crate::renderer::layout_frame::LayoutFrame;
pub use crate::renderer::layout_frame::ParagraphBox;

/// 글자겹침(CharOverlap) 렌더링 정보
#[derive(Debug, Clone, PartialEq, serde::Serialize)]
pub struct CharOverlapInfo {
    /// 테두리 타입 (0=없음, 1=원, 2=반전원, 3=사각형, 4=반전사각형)
    pub border_type: u8,
    /// 내부 글자 크기 (%, 기본 100)
    pub inner_char_size: i8,
}

/// 구성된 텍스트 런 (줄 내 동일 스타일 + 동일 언어 구간)
#[derive(Debug, Clone, Default)]
pub struct ComposedTextRun {
    /// 텍스트 조각
    pub text: String,
    /// 글자 스타일 ID (ResolvedStyleSet.char_styles 인덱스)
    pub char_style_id: u32,
    /// 언어 카테고리 (0=한국어, 1=영어, 2=한자, 3=일본어, 4=기타, 5=기호, 6=사용자)
    pub lang_index: usize,
    /// 글자겹침 정보 (CharOverlap 컨트롤에서 생성된 런인 경우)
    pub char_overlap: Option<CharOverlapInfo>,
    /// 각주/미주 마커 (Some이면 위첨자로 렌더링, 텍스트 흐름에 포함)
    pub footnote_marker: Option<u16>,
    /// PUA 옛한글 변환 후 표시 텍스트 (Some 이면 렌더러는 본 필드 사용).
    /// `text` 는 IR 와 동일하게 PUA char 1글자로 보존하여 char_offsets /
    /// char_start / line_chars 등 인덱싱 불변성을 유지한다 (Task #528).
    pub display_text: Option<String>,
    /// Logical paragraph grapheme membership, not a font/style heuristic.
    pub supplemental_metrics_blocked: bool,
    /// Text inserted from a control payload, not a scalar span of Paragraph.text.
    pub inserted_control_text: bool,
    /// 공백 폭의 출처는 run 분할 뒤에도 줄 채움 결과를 따른다.
    pub space_metric: SpaceMetric,
}

impl ComposedTextRun {
    pub(crate) fn text_style(&self, styles: &ResolvedStyleSet) -> TextStyle {
        let mut style = resolved_to_text_style(styles, self.char_style_id, self.lang_index);
        if self.supplemental_metrics_blocked {
            style.supplemental_metrics = None;
        }
        self.space_metric.apply_to_style(&mut style);
        style
    }

    /// 줄 상자를 정하는 글자 크기(px). 글자 모양의 **선언 크기**다.
    ///
    /// [#7398] 언어별 상대 크기(`relSz`)는 글리프 폭과 그리는 크기에만 곱한다
    /// ([`Self::text_style`]). 한/글은 줄 상자를 기준 크기로 둔다 — `exam_eng.hwp`
    /// 의 라틴 106% 문단도 저장 `LINE_SEG` 가 `lh = th = 1150`(기준 크기)이다.
    /// 조판의 `composed_line_max_font_size` 와 같은 값을 소비해야 측정과 배치의
    /// 줄 진행이 갈라지지 않는다.
    pub(crate) fn line_box_font_size(&self, styles: &ResolvedStyleSet) -> f64 {
        styles
            .char_styles
            .get(self.char_style_id as usize)
            .map(|style| style.font_size)
            .filter(|size| *size > 0.0)
            .unwrap_or(12.0)
    }
}

pub(crate) mod supplemental_clusters;

/// 구성된 줄 (LineSeg 기반)
#[derive(Debug, Clone)]
pub struct ComposedLine {
    /// 스타일별 텍스트 런 목록
    pub runs: Vec<ComposedTextRun>,
    /// 원본 LineSeg (높이, 베이스라인 등)
    pub line_height: i32,
    /// 베이스라인 거리
    pub baseline_distance: i32,
    /// 세그먼트 폭
    pub segment_width: i32,
    /// 컬럼 시작 위치
    pub column_start: i32,
    /// 줄간격 (LineSeg.line_spacing)
    pub line_spacing: i32,
    /// 강제 줄 바꿈(\n, Shift+Enter)으로 끝나는 줄인지 여부
    pub has_line_break: bool,
    /// 이 줄의 첫 문자가 para.text 내에서 갖는 절대 char 인덱스
    pub char_start: usize,
}

/// 인라인 컨트롤 종류
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum InlineControlType {
    /// 표
    Table,
    /// 도형/그림
    Shape,
    /// 기타 (구역정의, 단정의 등)
    Other,
}

/// 인라인 컨트롤 위치 정보
#[derive(Debug, Clone)]
pub struct InlineControl {
    /// 삽입될 줄 인덱스
    pub line_index: usize,
    /// Paragraph.controls 내 인덱스
    pub control_index: usize,
    /// 컨트롤 종류
    pub control_type: InlineControlType,
}

/// 구성된 문단
#[derive(Debug, Clone)]
pub struct ComposedParagraph {
    /// 줄별 텍스트
    pub lines: Vec<ComposedLine>,
    /// 문단 스타일 ID
    pub para_style_id: u16,
    /// 인라인 컨트롤 위치 목록
    pub inline_controls: Vec<InlineControl>,
    /// 개요 번호/글머리표 등 문단 머리 텍스트 (렌더링 전용)
    /// 문서 좌표 char_offset에 포함되지 않으며 별도 TextRunNode로 렌더링된다.
    /// 문단 머리 속성은 마커 영역(본문과의 거리·너비 보정·자동 내어쓰기)을 정한다.
    pub numbering_text: Option<(String, crate::model::paragraph::MarkerHead)>,
    /// treat_as_char 컨트롤의 텍스트 위치와 HWPUNIT 너비 목록
    /// (para.text 내 절대 char 인덱스, 폭 HWPUNIT, para.controls 내 인덱스)
    pub tac_controls: Vec<(usize, i32, usize)>,
    /// 각주/미주 위치: (텍스트 내 char 인덱스, 번호, para.controls 내 인덱스)
    pub footnote_positions: Vec<(usize, u16, usize)>,
    /// 탭 확장 데이터 (HWP tab_extended / HWPX 인라인 탭)
    /// ext[0]=width, ext[1]=leader/fill_type, ext[2]=tab_type
    pub tab_extended: Vec<[u16; 7]>,
    /// Q2-C에서 qualified된 dormant shaping 결과. D1은 수명만 composition
    /// owner로 넘기며 line breaking·layout·paint는 아직 이 값을 소비하지 않는다.
    pub(crate) horizontal_shaping:
        Option<std::sync::Arc<crate::renderer::shaping_paragraph::HorizontalShapingLineOutcome>>,
}

/// Renderer-session cache for the expensive stored single-line overflow probe.
///
/// Paragraph identity is valid only until the owning layout session clears its
/// caches. The concrete cell width completes the key; source/style mutations
/// clear the session cache instead of reaching into the source model.
#[derive(Default)]
pub(crate) struct SingleLineOverflowCache {
    entries: std::cell::RefCell<std::collections::HashMap<(usize, u32), bool>>,
}

impl SingleLineOverflowCache {
    #[inline]
    fn get(&self, para: &Paragraph, width_key: u32) -> Option<bool> {
        self.entries
            .borrow()
            .get(&(para as *const Paragraph as usize, width_key))
            .copied()
    }

    #[inline]
    fn insert(&self, para: &Paragraph, width_key: u32, overflowed: bool) {
        self.entries
            .borrow_mut()
            .insert((para as *const Paragraph as usize, width_key), overflowed);
    }

    pub(crate) fn clear(&self) {
        self.entries.borrow_mut().clear();
    }
}

/// 구역의 문단 목록을 구성한다.
pub fn compose_section(section: &Section) -> Vec<ComposedParagraph> {
    section.paragraphs.iter().map(compose_paragraph).collect()
}

/// Exact-font contexts가 준비된 DocumentCore 파생-state 경계만 사용하는 opt-in
/// composition path. 기존 공개 composition 경로의 결과는 그대로 유지한다.
pub(crate) fn compose_section_with_horizontal_shaping(
    section: &Section,
    styles: &ResolvedStyleSet,
) -> Vec<ComposedParagraph> {
    section
        .paragraphs
        .iter()
        .map(|paragraph| compose_paragraph_with_horizontal_shaping(paragraph, styles))
        .collect()
}

/// [Task #991] HWP5 parser 가 extended ctrl (1-3, 11-12, 14-18, 21-23) 의
/// inline visible marker (\u{FFFC}) 를 text 에 push 하지 않아서 발생하는 layout
/// 어긋남 보정. HWP3 parser 는 마커를 push 하므로 HWP3/HWPX 동일 IR 보장.
///
/// 검사: para.text 의 \u{FFFC} count < extended inline-visible ctrl count.
/// 부족하면 char_offsets gap (8 wchar 단위) 에 마커 삽입한 synth paragraph 반환.
///
/// 영향 범위: composer 내부만 (rendering pipeline). para 원본 (editor) 영향 없음.
fn synthesize_marker_paragraph(para: &Paragraph) -> Option<Paragraph> {
    fn needs_synthesized_inline_marker(ctrl: &Control) -> bool {
        is_render_inline_control(ctrl)
    }

    // 렌더에 실제 자리를 차지하는 TAC/개체 컨트롤 수 계산.
    // Field/ColumnDef/SectionDef 같은 비가시 컨트롤은 char_offsets gap에 있어도
    // 본문 텍스트 char_start를 밀면 안 된다.
    let inline_ctrl_count = para
        .controls
        .iter()
        .filter(|ctrl| needs_synthesized_inline_marker(ctrl))
        .count();

    if inline_ctrl_count == 0 {
        return None;
    }

    // HWP3 정답지의 미주 수식 문단은 본문 텍스트 없이 줄바꿈/탭과
    // TAC 수식만으로 LINE_SEG를 구성한다. 이 경우 char_offsets와 line_seg
    // text_start가 이미 컨트롤 줄 위치를 표현하므로 HWP5 누락 마커 보정을 적용하면
    // 수식이 뒤 줄로 밀린다.
    let text_has_only_layout_space = para
        .text
        .chars()
        .all(|ch| matches!(ch, '\n' | '\r' | '\t' | ' ' | '\u{2007}'));
    let controls_are_tac_objects = para.controls.iter().all(|ctrl| {
        matches!(
            ctrl,
            Control::Equation(eq) if eq.common.treat_as_char
        ) || matches!(
            ctrl,
            Control::Picture(_) | Control::Shape(_) | Control::Table(_) | Control::Form(_)
        )
    });
    if text_has_only_layout_space && controls_are_tac_objects {
        return None;
    }

    let existing_markers = para.text.chars().filter(|c| *c == '\u{FFFC}').count();
    if existing_markers >= inline_ctrl_count {
        // HWP3 path — 이미 마커 충분
        return None;
    }

    // [Task #991 좁힘] 단일 control 또는 단일 leading ctrl 경우는 fix 미적용.
    // 본 fix 의 root cause 는 "여러 TAC controls 가 한 paragraph 의 char_offsets
    // gap 으로 인해 모두 position 0 으로 분석되는" 특정 case (sample16 pi=394).
    // 일반 case (1-2 TAC + 텍스트) 는 기존 control_text_positions 의 marker 보조
    // 분기 또는 inline rendering 로 처리 — F2 적용 시 \u{FFFC} 가 text run 에
    // 추가되어 다른 sample (exam_eng p8 puko box 등) 위치 shift 발생.
    //
    // 좁힘 조건:
    //   - inline_ctrl_count >= 3 (pi=394 = 3 TAC controls 기준)
    //   - n_leading >= 2 (leading gap 에 2+ ctrl)
    let offsets = &para.char_offsets;
    let first_off = offsets.first().copied().unwrap_or(0) as usize;
    let n_leading = first_off / 8;
    if n_leading < 2 || inline_ctrl_count < 3 {
        return None;
    }

    // 원본 char_offsets 갭 분석이 이미 컨트롤을 텍스트 중간/뒤 위치로
    // 분산해 주는 문단은 합성 마커를 만들지 않는다. 예: 수식 TAC 여러 개와
    // 쉼표/고정탭/일반 글자가 한 줄에 섞인 문단은 [0,0,2,2,4] 같은 raw
    // position 자체가 편집자가 입력한 순서다. 여기에 \u{FFFC}를 재합성하면
    // TAC가 쉼표/탭 뒤로 밀려 순서가 깨진다.
    let raw_positions = para.control_text_positions();
    let raw_inline_positions: Vec<usize> = para
        .controls
        .iter()
        .enumerate()
        .filter(|(_, ctrl)| needs_synthesized_inline_marker(ctrl))
        .filter_map(|(i, _)| raw_positions.get(i).copied())
        .collect();
    if raw_inline_positions.iter().any(|pos| *pos > 0) {
        return None;
    }
    // 좁힘 조건 (n_leading >= 2) 통과 ⇒ offsets 비어있지 않음.
    // 따라서 빈 paragraph (offsets/chars empty) 경로는 본 좁힘 하에 도달 불가 —
    // 별도 분기 두지 않음 (검토 PR #995 §3.3 b).

    // HWP5 path — char_offsets gap 분석으로 누락된 마커 위치 합성
    let chars: Vec<char> = para.text.chars().collect();
    let mut new_text =
        String::with_capacity(para.text.len() + (inline_ctrl_count - existing_markers) * 3);
    let mut new_offsets: Vec<u32> =
        Vec::with_capacity(para.char_offsets.len() + (inline_ctrl_count - existing_markers));

    // 첫 visible char 전 leading gap (좁힘 가드에서 계산한 n_leading 재사용)
    for i in 0..n_leading {
        new_offsets.push((i * 8) as u32);
        new_text.push('\u{FFFC}');
    }

    // visible chars 사이 / 후행
    for (i, &off) in offsets.iter().enumerate() {
        let ch = chars.get(i).copied().unwrap_or(' ');
        new_offsets.push(off);
        new_text.push(ch);

        // 다음 char 까지의 gap 분석
        let char_width: u32 = if (ch as u32) > 0xFFFF { 2 } else { 1 };
        let next_off = if i + 1 < offsets.len() {
            offsets[i + 1] as usize
        } else {
            // 마지막 char 후행 controls — trailing gap 추정 불가능하면 종료
            // (line_segs 분석 등 더 정교한 방법 가능하지만 본 fix 의 좁은 범위 유지)
            continue;
        };
        let gap = next_off
            .saturating_sub(off as usize)
            .saturating_sub(char_width as usize);
        let n_ctrls_between = gap / 8;
        for k in 0..n_ctrls_between {
            new_offsets.push((off as usize + char_width as usize + k * 8) as u32);
            new_text.push('\u{FFFC}');
        }
    }

    // 모든 후행 controls 처리 — line_segs.ts 마지막 + 8 단위로 추정
    let added_so_far = new_text.chars().filter(|c| *c == '\u{FFFC}').count();
    let still_needed = inline_ctrl_count.saturating_sub(added_so_far);
    if still_needed > 0 {
        // 마지막 char_offsets 의 stream pos + char_width 부터 8 단위씩
        let last_off = offsets.last().copied().unwrap_or(0) as usize;
        let last_ch = chars.last().copied().unwrap_or(' ');
        let last_w: usize = if (last_ch as u32) > 0xFFFF { 2 } else { 1 };
        let mut next_pos = last_off + last_w;
        for _ in 0..still_needed {
            new_offsets.push(next_pos as u32);
            new_text.push('\u{FFFC}');
            next_pos += 8;
        }
    }

    let mut synth = para.clone();
    synth.text = new_text;
    synth.char_offsets = new_offsets;
    Some(synth)
}

/// 문단을 줄별 텍스트 런으로 분할한다.
pub fn compose_paragraph(para: &Paragraph) -> ComposedParagraph {
    compose_paragraph_scoped(para, false, None)
}

/// Supplemental width contexts may subdivide a nominal run; portable composition must not.
pub(crate) fn compose_paragraph_in_context(
    para: &Paragraph,
    styles: &ResolvedStyleSet,
) -> ComposedParagraph {
    compose_paragraph_scoped(para, styles.supplemental_metrics.is_some(), Some(styles))
}

pub(crate) fn compose_paragraph_for_metric_requests(para: &Paragraph) -> ComposedParagraph {
    compose_paragraph_scoped(para, true, None)
}

fn compose_paragraph_scoped(
    para: &Paragraph,
    protect_metrics: bool,
    metric_styles: Option<&ResolvedStyleSet>,
) -> ComposedParagraph {
    // [Task #991] HWP5 parser 의 inline marker 누락 보정 (rendering 전용)
    let synth_para = synthesize_marker_paragraph(para);
    let para = synth_para.as_ref().unwrap_or(para);

    let mut lines = compose_lines(para);
    if crate::renderer::para_has_no_stored_line_segs(para) {
        if let Some(styles) = metric_styles {
            for line in &mut lines {
                let mut runs = Vec::new();
                for run in std::mem::take(&mut line.runs) {
                    let punct_latin = styles
                        .char_styles
                        .get(run.char_style_id as usize)
                        .is_some_and(|style| style.ascii_punct_latin_slot);
                    if !punct_latin
                        || !run
                            .text
                            .chars()
                            .any(|ch| !ch.is_ascii() && is_latin_slot_punct(ch))
                    {
                        runs.push(run);
                        continue;
                    }
                    let mut start = 0;
                    let mut lang = run.lang_index;
                    for (byte, ch) in run.text.char_indices() {
                        let next = reflow_punctuation_slot(ch, run.lang_index, punct_latin);
                        if next != lang {
                            if byte > start {
                                runs.push(ComposedTextRun {
                                    text: run.text[start..byte].to_string(),
                                    lang_index: lang,
                                    ..run.clone()
                                });
                            }
                            start = byte;
                            lang = next;
                        }
                    }
                    if start < run.text.len() {
                        runs.push(ComposedTextRun {
                            text: run.text[start..].to_string(),
                            lang_index: lang,
                            ..run
                        });
                    }
                }
                line.runs = runs;
            }
        }
    }
    let inline_controls = identify_inline_controls(para);

    // treat_as_char 컨트롤의 텍스트 위치와 HWPUNIT 너비 수집
    let tac_positions = find_render_inline_control_positions(para);
    let seg_width = para.line_segs.first().map(|s| s.segment_width).unwrap_or(0);
    let tac_controls: Vec<(usize, i32, usize)> = para
        .controls
        .iter()
        .enumerate()
        .filter_map(|(i, ctrl)| {
            let pos = *tac_positions.get(i)?;
            match ctrl {
                Control::Picture(p) if p.common.treat_as_char => {
                    Some((pos, p.common.width as i32, i))
                }
                Control::Shape(s) if s.common().treat_as_char => {
                    Some((pos, s.common().width as i32, i))
                }
                Control::Equation(eq) if eq.common.treat_as_char => {
                    // HWP 저장값을 사용 — 한컴 편집기가 실제 폰트로 계산한 정확한 너비
                    Some((pos, crate::renderer::equation::flow_width_hwp(eq) as i32, i))
                }
                Control::Form(f) if f.common.treat_as_char => Some((pos, f.width as i32, i)),
                Control::Table(t)
                    if t.common.treat_as_char
                        && super::height_measurer::is_tac_table_inline_in_para(
                            t, seg_width, para,
                        ) =>
                {
                    // [#5785 후속] 선언 폭 우선.
                    let table_width: u32 = t.flow_width_hu();
                    Some((pos, table_width as i32, i))
                }
                _ => None,
            }
        })
        .collect();

    // 각주/미주 위치 수집
    let footnote_positions: Vec<(usize, u16, usize)> = para
        .controls
        .iter()
        .enumerate()
        .filter_map(|(i, ctrl)| {
            let pos = *tac_positions.get(i)?;
            match ctrl {
                Control::Footnote(fn_) => Some((pos, fn_.number, i)),
                Control::Endnote(en) => Some((pos, en.number, i)),
                _ => None,
            }
        })
        .collect();

    // 각주 마커는 paragraph_layout에서 FootnoteMarker 노드로 처리 (텍스트에 삽입하지 않음)

    // [#6101] 블록(비인라인) TAC 표와 뒤따르는 본문 텍스트가 저장 lineseg **한
    // 줄**에 함께 담긴 문단: 블록 표(폭 ≥ 줄폭 90%)와 텍스트는 물리적으로 한
    // 줄에 공존할 수 없고, 한글은 표를 줄 머리에 두고 텍스트를 다음 줄로
    // 내린다(36361137 7쪽 오라클 실측: 표 x 69.7, 텍스트는 표 아래 y 517.6).
    // 분리하지 않으면 ① 레이아웃 TAC 폴백이 line0 전체 폭(=뒤 텍스트 558px)을
    // leading 으로 오산해 표가 텍스트 폭만큼 우측으로 밀려 쪽 밖으로 잘리고
    // ② 조판이 텍스트 줄을 계상·발행하지 않아 본문이 통째로 소실된다.
    // 표 줄(빈 runs — TAC \n 경로의 "표 줄" 선례와 동형)과 텍스트 줄로 분리
    // 한다. 텍스트 줄 메트릭은 저장 줄높이(=표 높이)를 물려받으면 표가 이중
    // 계상되므로 lineseg-부재 합성 폴백과 같은 소형 값(400/320HU)으로 두어
    // 소비자(조판 max_fs 재산출·레이아웃 corrected_line_height)가 스타일로
    // 재산출하게 한다. 스트림상 텍스트가 표 앞이든 뒤든 같은 서명이다 —
    // 36501883(텍스트→표 순서)도 한글은 표를 줄 머리(x 76.8)에, 텍스트를 표
    // 아래(y 766.8)에 둔다. 저장 사다리가 이미 표에 자기 줄을 준 다중 줄
    // 문단(#842 선행 텍스트 축)은 표 줄에 가시 글자가 없어 여기 걸리지 않는다.
    let block_tac_split_pos = para
        .controls
        .iter()
        .enumerate()
        .find_map(|(i, ctrl)| match ctrl {
            Control::Table(t)
                if t.common.treat_as_char
                    && !tac_controls.iter().any(|(_, _, ci)| *ci == i)
                    && !super::height_measurer::is_tac_table_inline_in_para(t, seg_width, para) =>
            {
                tac_positions.get(i).copied()
            }
            _ => None,
        });
    if let Some(ctrl_pos) = block_tac_split_pos {
        let total_chars = para.text.chars().count();
        let chars: Vec<char> = para.text.chars().collect();
        let line_end = |lines: &[ComposedLine], idx: usize| {
            lines
                .get(idx + 1)
                .map(|l| l.char_start)
                .unwrap_or(total_chars)
        };
        let host_line = (0..lines.len()).find(|&i| {
            let end = line_end(&lines, i).max(lines[i].char_start + 1);
            // 마지막 줄은 끝 경계 포함 — 텍스트→표 순서(36501883)는 컨트롤
            // 위치가 줄 끝(== 텍스트 길이)에 앵커된다.
            let end_inclusive = if i + 1 == lines.len() { end + 1 } else { end };
            lines[i].char_start <= ctrl_pos && ctrl_pos < end_inclusive
        });
        if let Some(li) = host_line {
            let start = lines[li].char_start.min(total_chars);
            let end = line_end(&lines, li).min(total_chars);
            // 가시 글자 판정: 공백·제어문자·오브젝트마커(U+FFFC)·한컴 PUA 필러
            // (BMP U+E000~F8FF, 보충평면 U+F0000~ — U+F081C 등)는 제외한다.
            // is_alphanumeric 으로 좁히면 별표(`*`)만으로 채운 마스킹 줄
            // (36501883)을 놓친다.
            let is_visible_glyph = |ch: char| {
                !ch.is_whitespace()
                    && ch > '\u{001F}'
                    && ch != '\u{FFFC}'
                    && !('\u{E000}'..='\u{F8FF}').contains(&ch)
                    && (ch as u32) < 0xF0000
            };
            let line_has_visible_text = chars[start..end].iter().any(|&c| is_visible_glyph(c));
            if line_has_visible_text {
                let table_line = ComposedLine {
                    runs: Vec::new(),
                    line_height: lines[li].line_height,
                    baseline_distance: lines[li].baseline_distance,
                    segment_width: lines[li].segment_width,
                    column_start: lines[li].column_start,
                    line_spacing: lines[li].line_spacing,
                    has_line_break: true,
                    char_start: lines[li].char_start,
                };
                lines[li].line_height = 400;
                lines[li].baseline_distance = 320;
                lines.insert(li, table_line);
            }
        }
    }

    let mut composed = ComposedParagraph {
        lines,
        para_style_id: para.para_shape_id,
        inline_controls,
        numbering_text: None,
        tac_controls,
        footnote_positions,
        tab_extended: para.tab_extended.clone(),
        horizontal_shaping: None,
    };

    // CharOverlap 글자를 조합된 텍스트에 삽입
    inject_char_overlap_text(&mut composed, para);

    // PUA 테두리 숫자(사각형/원형 안의 숫자) → CharOverlap 런으로 변환
    convert_pua_enclosed_numbers(&mut composed);

    // Hanyang-PUA 옛한글 / 한컴 PUA와 legacy 제품명 표시 문자열 변환 (렌더링·측정용)
    convert_pua_display_text(&mut composed);

    // Keep existing display projection intact; inserted control text has no source span.
    if protect_metrics {
        supplemental_clusters::preserve_boundaries(&mut composed, &para.text, metric_styles);
    }

    composed
}

/// Legacy composition을 먼저 완성한 뒤 Q2-C shadow transaction의 qualified
/// 결과만 같은 paragraph owner에 붙인다. 실패·상한·range mismatch는 기존
/// `compose_paragraph()` 결과를 그대로 반환한다.
pub(crate) fn compose_paragraph_with_horizontal_shaping(
    para: &Paragraph,
    styles: &ResolvedStyleSet,
) -> ComposedParagraph {
    let mut composed = compose_paragraph_in_context(para, styles);
    composed.horizontal_shaping =
        line_breaking::compose_horizontal_shaping_handoff(para, &composed, styles);
    composed
}

/// 컴포즈드 줄 목록에서 첫 "텍스트 포함 줄"(런에 텍스트 성격 문자가 있는 줄)의 인덱스.
/// 실제 텍스트가 있는 문단은 leading 컨트롤-전용 줄(수식 객체마커 ￼ 등)을 건너뛰고 이
/// 줄부터 그린다 — `LayoutEngine::layout_column_item`(실제 렌더)과
/// `TypesetEngine::measure_endnote_para_advance`(측정 전용)가 이 판정을 공유한다.
/// 종전엔 각자 재구현해 sep20/20(pi=936, 측정 127.7px vs 렌더 101.3px)에서 갈라졌다(#4312).
pub(crate) fn first_text_line(composed: &ComposedParagraph) -> Option<usize> {
    composed.lines.iter().position(|line| {
        line.runs
            .iter()
            .any(|r| r.text.chars().any(|c| c > '\u{001F}' && c != '\u{FFFC}'))
    })
}

/// Height of the physical LineSeg that owns a splittable TAC table.
///
/// A stored one-row table keeps the ordinary saved-ladder cap because its box
/// may overlap the following saved row. A current reflow row, or a multi-row
/// RowBreak table, uses the owning LineSeg as its vertical frame when that row
/// covers the declared object.
pub(crate) fn owned_rowbreak_tac_height(para: &Paragraph, control_index: usize) -> Option<i32> {
    let Control::Table(table) = para.controls.get(control_index)? else {
        return None;
    };
    if !table.common.treat_as_char
        || !matches!(
            table.page_break,
            crate::model::table::TablePageBreak::RowBreak
        )
    {
        return None;
    }
    let seg = para
        .line_segs
        .get(control_line_seg_index(para, control_index)?)?;
    let is_current_row = seg.tag & LineSeg::TAG_IMPLEMENTATION_PROPERTY != 0;
    if table.row_count <= 1 && !is_current_row {
        return None;
    }
    (i64::from(seg.line_height) >= i64::from(table.common.height)).then_some(seg.line_height)
}

/// TAC 표를 소유한 줄이 실제 흐름에 남기는 양의 후행 간격.
/// 저장 HWP5의 표 소유 줄과 현재 재조판한 단일 RowBreak 줄은
/// 개체 프레임 뒤의 간격 절반을 물리 흐름에 남긴다.
/// Preserve only the already-parsed Native trailing-space rule for one locally
/// unchanged blank TAC host. No row/cache authority or source geometry is issued.
#[path="composer/unchanged_native_tac.rs"]
mod unchanged_native_tac;
pub(crate) use unchanged_native_tac::unchanged_native_tac_spacing;

pub(crate) fn tac_host_trailing_spacing(
    para: &Paragraph,
    control_index: usize,
    seg: &LineSeg,
    hwpx_stored_layout: bool,
    native_stored_layout: bool,
    dpi: f64,
) -> f64 {
    let spacing = crate::renderer::hwpunit_to_px(seg.line_spacing.max(0), dpi);
    let current_owned_row = hwpx_stored_layout
        && para.line_segs.len() == 1
        && seg.tag & LineSeg::TAG_IMPLEMENTATION_PROPERTY != 0
        && owned_rowbreak_tac_height(para, control_index).is_some();
    if current_owned_row
        || (native_stored_layout
            && seg.tag & LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0
            && !para.stored_text_partition_is_dirty())
    {
        spacing / 2.0
    } else {
        spacing
    }
}

/// 실제 표 소유 줄의 저장 끝에 앞 문단 뒤 간격과 다음 문단 앞 간격을 더한 값이
/// 다음 저장 줄의 시작과 맞닿으면
/// 배치 원점에는 후행 간격 전량을 적용한다. 분할 예산의 표 점유는 별도로 센다.
pub(crate) fn tac_next_line_full_spacing(
    para: &Paragraph,
    next_para: Option<&Paragraph>,
    current_spacing_after_px: f64,
    next_spacing_before_px: f64,
    seg: &LineSeg,
    profile: crate::model::provenance::LayoutCompatibilityProfile,
    dpi: f64,
) -> bool {
    let next_spacing_before_hu = (next_spacing_before_px / hwpunit_to_px(1, dpi)).round() as i32;
    let current_spacing_after_hu =
        (current_spacing_after_px / hwpunit_to_px(1, dpi)).round() as i32;
    // 원본 저장 줄과 현재 개체 프레임을 소유한 재조판 줄을 구분한다.
    // 후자는 합성 태그를 가진 현재 사다리를 사용하므로 저장 원본으로 취급하지 않는다.
    let current_owned_row = profile.hwpx_stored_layout()
        && para.line_segs.len() == 1
        && seg.tag & LineSeg::TAG_IMPLEMENTATION_PROPERTY != 0
        && para
            .controls
            .iter()
            .enumerate()
            .any(|(ci, _)| owned_rowbreak_tac_height(para, ci).is_some());
    let stored_host = profile.hwp5_stored_pagination_layout()
        && !profile.session_edited()
        && !para.stored_text_partition_is_dirty()
        && seg.tag & LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0;
    (stored_host || current_owned_row)
        && para
            .line_segs
            .last()
            .is_some_and(|last| std::ptr::eq(last, seg))
        && next_para.is_some_and(|next| {
            (current_owned_row || !next.stored_text_partition_is_dirty())
                && next.line_segs.first().is_some_and(|first| {
                    (current_owned_row || first.tag & LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0)
                        && seg
                            .vertical_pos
                            .saturating_add(seg.line_height)
                            .saturating_add(seg.line_spacing)
                            .saturating_add(current_spacing_after_hu)
                            .saturating_add(next_spacing_before_hu)
                            == first.vertical_pos
                })
        })
}

/// 저장된 서로 다른 물리 줄을 소유한 빈/공백 캐리어 TAC 표의 흐름.
/// top/end는 첫 저장 줄 원점 기준 HU이며, 테두리가 아닌 바깥여백 포함 pen이다.
#[derive(Debug, Clone, Copy)]
pub(crate) struct StoredTacLine {
    pub control: usize,
    pub top: i32,
    pub end: i32,
    pub occupied_end: i32,
}

/// 가시 텍스트 없이 첫 저장 줄 전체를 소유한 TAC 표의 줄 상자다.
/// 다중 줄의 페인트 단축과 달리 단일 표도 수용하며, 합성/편집 줄은 원본 근거가 아니다.
pub(crate) fn stored_first_tac_line(para: &Paragraph) -> Option<&LineSeg> {
    let first = para.line_segs.first()?;
    if para.stored_text_partition_dirty
        || para
            .line_segs
            .iter()
            .any(|line| line.tag & LineSeg::TAG_IMPLEMENTATION_PROPERTY != 0)
        || para
            .text
            .chars()
            .any(|c| !c.is_whitespace() && c > '\u{001f}' && c != '\u{fffc}')
    {
        return None;
    }
    para.controls
        .iter()
        .enumerate()
        .any(|(ci, control)| {
            let Control::Table(table) = control else {
                return false;
            };
            table.common.treat_as_char
                && table.caption.is_none()
                && control_line_seg_index(para, ci) == Some(0)
                && i64::from(first.line_height)
                    == i64::from(table.common.height)
                        + i64::from(table.outer_margin_top)
                        + i64::from(table.outer_margin_bottom)
        })
        .then_some(first)
}

/// The first table page item may be a floating sibling, not the table
/// owning the host's first saved row. Only the actual inline control whose
/// entire physical box owns that row can supply its stored frame basis.
pub(crate) fn stored_table_column_line_vpos(para: &Paragraph, control_index: usize) -> Option<i32> {
    let Control::Table(table)=para.controls.get(control_index)? else {return None;};
    if !table.common.treat_as_char || table.caption.is_some()
        || para.cell_format_vpos_dirty
        || control_line_seg_index(para,control_index)!=Some(0)
    {return None;}
    let first=stored_first_tac_line(para)?;
    if first.line_height<=0 || first.line_spacing<0 || first.vertical_pos<0
        || i64::from(first.line_height)!=i64::from(table.common.height)
            +i64::from(table.outer_margin_top)+i64::from(table.outer_margin_bottom)
    {return None;}
    first.vertical_pos.checked_add(first.line_height)?
        .checked_add(first.line_spacing)?;
    Some(first.vertical_pos)
}

/// Ordinary whitespace rows before an object in the same stored fragment.
/// A vpos reset has a different continuation owner; its prefix cannot be
/// emitted again beside the object after that owner advances the page.
pub(crate) fn ordinary_tac_prefix_rows(para: &Paragraph, owner: usize) -> bool {
    !para.text.is_empty()
        && para.text.chars().all(char::is_whitespace)
        && owner > 0
        && para.line_segs.get(owner).is_some_and(|row| {
            row.vertical_pos >= para.line_segs[0].vertical_pos
                && para.line_segs[..=owner]
                    .windows(2)
                    .all(|pair| pair[1].vertical_pos >= pair[0].vertical_pos)
                && para.line_segs[..owner]
                    .iter()
                    .all(|prefix| prefix.line_height == prefix.text_height)
        })
}

pub(crate) fn stored_tac_lines(para: &Paragraph) -> Option<Vec<StoredTacLine>> {
    // 공백도 자기 저장 줄을 가질 수 있다. 표 앞 공백 줄의 line_height에는
    // 문단의 최대 개체 높이가 반복 저장되므로 text_height와 다음 원점을 확인한다.
    let whitespace_carrier = !para.text.is_empty() && para.text.chars().all(char::is_whitespace);
    if !whitespace_carrier {
        para.empty_control_stream_position(0)?;
    }
    if para.stored_text_partition_dirty
        || para
            .line_segs
            .iter()
            .any(|s| s.tag & LineSeg::TAG_IMPLEMENTATION_PROPERTY != 0)
    {
        return None;
    }
    let origin = para.line_segs.first()?.vertical_pos;
    let mut lines = Vec::new();
    let mut previous_owner = None;
    for (ci, control) in para.controls.iter().enumerate() {
        let table = match control {
            Control::Table(table) if table.common.treat_as_char => table,
            Control::SectionDef(_)
            | Control::ColumnDef(_)
            | Control::Header(_)
            | Control::Footer(_)
            | Control::PageNumberPos(_)
            // 감추기는 쪽 표시 설정이며 본문 글줄을 점유하지 않는다.
            | Control::PageHide(_) => continue,
            _ => return None,
        };
        let owner = control_line_seg_index(para, ci)?;
        let seg = para.line_segs.get(owner)?;
        let outer_height = i64::from(table.common.height)
            + i64::from(table.outer_margin_top)
            + i64::from(table.outer_margin_bottom);
        // 여기서 높이가 같다는 것은 baseline 정렬된 객체의 전체 점유 줄을 뜻한다.
        // 텍스트와 같은 줄, 더 큰 이웃 객체, 쪽 리셋은 기존 분할/재조판이 처리한다.
        if previous_owner.is_some_and(|previous| previous >= owner)
            || i64::from(seg.line_height) != outer_height
            || seg.vertical_pos < origin
        {
            return None;
        }
        // Ordinary prefix rows own their text/empty-line boxes and indentation.
        // A table-only placement cannot replace those rows with an anonymous
        // offset. Let the common composed paragraph route emit and measure them.
        // Carriers whose lh repeats the object maximum still need this band's
        // th-based physical-space contract.
        if ordinary_tac_prefix_rows(para, owner) {
            return None;
        }
        // 빈 컨트롤 캐리어도 표 앞에 짧은 저장 줄을 가질 수 있다.
        // 표 높이가 반복된 line_height 대신 실제 text_height와 다음 원점을
        // 대조하여 빈 줄의 물리 점유를 보존한다.
        if (whitespace_carrier || (lines.is_empty() && owner > 0))
            && (table.caption.is_some()
                || owner == 0
                || para.line_segs[..owner].iter().any(|blank| {
                    // 음수 줄간격도 실제 줄 전진량이 유효하면 저장 줄의 일부다.
                    blank.text_height <= 0
                        || i64::from(blank.text_height) + i64::from(blank.line_spacing) < 0
                })
                || i64::from(seg.text_height) != outer_height
                || para.line_segs[..owner].windows(2).any(|pair| {
                    i64::from(pair[0].vertical_pos)
                        + i64::from(pair[0].text_height)
                        + i64::from(pair[0].line_spacing)
                        != i64::from(pair[1].vertical_pos)
                })
                || i64::from(para.line_segs[owner - 1].vertical_pos)
                    + i64::from(para.line_segs[owner - 1].text_height)
                    + i64::from(para.line_segs[owner - 1].line_spacing)
                    != i64::from(seg.vertical_pos))
        {
            return None;
        }
        let top = seg.vertical_pos.checked_sub(origin)?;
        if lines
            .last()
            .is_some_and(|line: &StoredTacLine| line.top >= top)
        {
            return None;
        }
        let occupied_end = top.checked_add(seg.line_height)?;
        let end = occupied_end.checked_add(seg.line_spacing)?;
        if end < top {
            return None;
        }
        lines.push(StoredTacLine {
            control: ci,
            top,
            occupied_end,
            end,
        });
        previous_owner = Some(owner);
    }
    let single_prefix_carrier = lines.len() == 1
        && previous_owner.is_some_and(|owner| owner > 0 && owner == para.line_segs.len() - 1);
    if lines.len() < 2 && !whitespace_carrier && !single_prefix_carrier {
        return None;
    }
    // 글자가 있는 일반 문단이나 같은 줄의 여러 개체는 재조판 경로가 처리한다.
    // 공백 캐리어의 단축은 앞 공백 줄과 마지막 표 줄이 분리된 단일 표만 수용한다.
    if whitespace_carrier && (lines.len() != 1 || previous_owner != Some(para.line_segs.len() - 1))
    {
        return None;
    }
    // 다음 표의 실제 소유 줄로 이동한다. 중간의 header/footer용 LineSeg는 표 줄이 아니다.
    for i in 0..lines.len() - 1 {
        lines[i].end = lines[i + 1].top;
    }
    Some(lines)
}

/// 캡션(문단 목록)의 총 높이를 px 로 계산한다.
///
/// 렌더(`calculate_caption_height`)와 측정(`measure_caption`)이 각자 재구현하며 갈라졌던
/// 산식을 통일한 것이다(#4320). 저장된 `line_segs` 는 한컴이 실제로 배치한 레이아웃 값이므로
/// `compose_paragraph` 재계산 높이의 하한으로 쓴다 — `line_segs`가 있어도 폰트 대체 등으로
/// 재계산 높이가 더 작게 나오면 실제보다 낮게 예약되어 다음 요소가 겹친다
/// (`2d973021c`가 `samples/rowbreak-problem-pages.hwpx`에서 고친 오버랩이 이 경우다).
/// `line_segs`가 비어 있으면(레이아웃 전/미저장 캡션) `compose_paragraph`로만 계산한다.
pub fn caption_height_px(caption: &Option<Caption>, dpi: f64) -> f64 {
    let caption = match caption {
        Some(c) => c,
        None => return 0.0,
    };

    if caption.paragraphs.is_empty() {
        return 0.0;
    }

    // line_segs가 비어 컴포즈로 대체할 때 쓰는 기본 줄 높이(HWPUNIT).
    const DEFAULT_LINE_HEIGHT_HWPUNIT: i32 = 400;

    let mut line_seg_height = 0.0f64;
    let mut composed_height = 0.0f64;
    for para in &caption.paragraphs {
        if let (Some(first), Some(last)) = (para.line_segs.first(), para.line_segs.last()) {
            let para_top = first.vertical_pos.min(0);
            let para_bottom = last.vertical_pos.saturating_add(last.line_height);
            line_seg_height = line_seg_height.max(hwpunit_to_px(para_bottom - para_top, dpi));
        }

        let composed = compose_paragraph(para);
        if composed.lines.is_empty() {
            composed_height += hwpunit_to_px(DEFAULT_LINE_HEIGHT_HWPUNIT, dpi); // 기본 줄 높이
        } else {
            for (i, line) in composed.lines.iter().enumerate() {
                let line_h = hwpunit_to_px(line.line_height, dpi);
                let spacing = if i < composed.lines.len() - 1 {
                    hwpunit_to_px(line.line_spacing, dpi)
                } else {
                    0.0 // 마지막 줄은 line_spacing 제외
                };
                composed_height += line_h + spacing;
            }
        }
    }

    line_seg_height.max(composed_height)
}

/// Hanyang-PUA 옛한글 코드포인트·한컴 PUA와 legacy 제품명을 렌더링용 텍스트로 변환한다.
///
/// 한컴 자체 폰트 (함초롬바탕 LVT 등) 는 PUA 영역에 옛한글 글리프를 직접
/// 보유하나, OFL 폰트 (Noto Serif KR / Source Han Serif K 등) 는 KS X 1026-1
/// 자모 영역만 지원하므로 PUA → 자모 변환 후 합자 렌더링이 필요.
///
/// `U+F012B` 같은 한컴 전용 PUA 기호는 표준 Unicode 단일 문자 대응이 없어서
/// 표시 문자열(`(인)`)로 확장한다. 본 함수는 `run.text` 를 변경하지 않고
/// `run.display_text` 에만 변환 결과를 저장한다. 이는 `char_offsets`,
/// `line.char_start`, `line_chars` 등 인덱싱 불변성을 유지하기 위함이다
/// (PUA 1 char = display N chars).
///
/// 1990년대 한컴 제품 설명서는 `ᄒᆞᆫ글`·`ᄒᆞᆫ메일`처럼 제품명을 옛한글 자모로
/// 저장했지만, 한컴 PDF는 이를 각각 `한글`·`한메일`로 인쇄한다. 이것은 일반
/// 옛한글 정규화가 아니다. 아래의 닫힌 제품명 어휘만 display projection으로
/// 바꾸며, 원문 IR·검색·캐럿 offset은 그대로 보존한다.
///
/// 매핑 표: KTUG HanyangPuaTableProject (Public Domain).
fn convert_pua_display_text(composed: &mut ComposedParagraph) {
    use super::pua_oldhangul::map_pua_old_hangul;

    let product_prefix_starts = legacy_hancom_product_prefix_starts(composed);
    let mut run_char_start = 0usize;
    for line in composed.lines.iter_mut() {
        for run in line.runs.iter_mut() {
            let chars: Vec<char> = run.text.chars().collect();
            let run_char_end = run_char_start + chars.len();
            let has_product_projection = product_prefix_starts
                .iter()
                .any(|start| *start < run_char_end && start.saturating_add(3) > run_char_start);
            let has_pua_display = chars.iter().any(|ch| {
                pua_plain_text_display(*ch).is_some()
                    || map_pua_old_hangul(*ch).is_some()
                    || map_pua_bullet_char(*ch) != *ch
            });
            if !has_product_projection && !has_pua_display {
                run_char_start = run_char_end;
                continue;
            }
            let mut display = String::with_capacity(run.text.len() * 3);
            let mut changed = false;
            for (index, ch) in chars.iter().copied().enumerate() {
                let char_position = run_char_start + index;
                if product_prefix_starts.contains(&char_position) {
                    display.push('한');
                    changed = true;
                } else if product_prefix_starts
                    .iter()
                    .any(|start| (start + 1..start + 3).contains(&char_position))
                {
                    // `ᄒᆞᆫ` 세 자모가 style/line 경계를 넘더라도 첫 위치에만
                    // `한`을 투영한다. 뒤 두 model char는 offset 공간에만 남긴다.
                    changed = true;
                } else if let Some(replacement) = pua_plain_text_display(ch) {
                    display.push_str(replacement);
                    changed = true;
                } else if let Some(jamos) = map_pua_old_hangul(ch) {
                    display.extend(jamos.iter().copied());
                    changed = true;
                } else {
                    // paint 경로(`expand_pua_display_text`)와 같이 한컴 PUA 책괄호
                    // (U+F0854/F0855 → 《》) 등을 측정 문자열에도 올린다. 원문 PUA 는
                    // CJK가 아니라 0.5em 휴리스틱이 되어 run bbox 가 전각 글리프보다
                    // 짧고, 다음 라틴 run 이 한글 위에 겹친다 (#6057).
                    let mapped = map_pua_bullet_char(ch);
                    display.push(mapped);
                    if mapped != ch {
                        changed = true;
                    }
                }
            }
            run_char_start = run_char_end;
            if changed {
                run.display_text = Some(display);
            }
        }
    }
}

const LEGACY_HANCOM_PRODUCT_WORDS: [(&str, &str); 4] = [
    ("ᄒᆞᆫ글", "한글"),
    ("ᄒᆞᆫ메일", "한메일"),
    ("ᄒᆞᆫ팩스", "한팩스"),
    ("ᄒᆞᆫ소프트", "한소프트"),
];

/// 한컴 PDF가 현대 글리프로 인쇄하는 레거시 제품명만 화면 문자열로 투영한다.
///
/// 이 함수는 모델 문자열을 정규화하지 않는다. 표 셀처럼 composer를 우회해
/// `TextRunNode`를 직접 만드는 레이아웃 경로에도 같은 제한된 표시 계약을
/// 적용하기 위해 render-tree 최종화 단계에서 재사용한다.
pub(crate) fn legacy_hancom_product_display_text(text: &str) -> Option<String> {
    let mut display = text.to_owned();
    for (legacy, modern) in LEGACY_HANCOM_PRODUCT_WORDS {
        display = display.replace(legacy, modern);
    }
    (display != text).then_some(display)
}

/// `ᄒᆞᆫ`이 legacy 한컴 제품명으로 쓰인 model-character 시작 위치를 찾는다.
///
/// `ComposedParagraph`의 run은 줄·글자모양 경계에서 나뉠 수 있으므로, 먼저 모든
/// run을 이어 검사한 뒤 model char 좌표를 돌려준다. 그 뒤 display projection은
/// run별로 적용해도 줄 경계를 넘어선 제품명을 놓치지 않는다.
fn legacy_hancom_product_prefix_starts(composed: &ComposedParagraph) -> Vec<usize> {
    let logical_text: String = composed
        .lines
        .iter()
        .flat_map(|line| line.runs.iter())
        .map(|run| run.text.as_str())
        .collect();
    let mut starts = Vec::new();
    for (char_index, (byte_index, _)) in logical_text.char_indices().enumerate() {
        if LEGACY_HANCOM_PRODUCT_WORDS
            .iter()
            .any(|(legacy, _)| logical_text[byte_index..].starts_with(legacy))
        {
            starts.push(char_index);
        }
    }
    starts
}

/// 각주 마커를 해당 텍스트 위치의 런에 인라인 삽입
/// 각주 위치에서 기존 런을 분할하고 마커 런("1)" 등)을 사이에 삽입
fn inject_footnote_markers(lines: &mut [ComposedLine], positions: &[(usize, u16)]) {
    for &(char_pos, number) in positions {
        let marker_text = format!("{})", number);
        // char_pos에 해당하는 줄과 런 찾기
        for line in lines.iter_mut() {
            let line_start = line.char_start;
            let line_end = line_start
                + line
                    .runs
                    .iter()
                    .map(|r| r.text.chars().count())
                    .sum::<usize>();
            if char_pos < line_start || char_pos > line_end {
                continue;
            }

            // 이 줄 내에서 char_pos에 해당하는 런 찾기
            let mut run_char = line_start;
            let mut target_run_idx = None;
            let mut offset_in_run = 0;
            for (ri, run) in line.runs.iter().enumerate() {
                let run_len = run.text.chars().count();
                if char_pos >= run_char && char_pos <= run_char + run_len {
                    target_run_idx = Some(ri);
                    offset_in_run = char_pos - run_char;
                    break;
                }
                run_char += run_len;
            }

            if let Some(ri) = target_run_idx {
                let orig_run = &line.runs[ri];
                let cs_id = orig_run.char_style_id;
                let lang = orig_run.lang_index;

                // 런을 분할: [앞부분] [마커] [뒷부분]
                let orig_text: Vec<char> = orig_run.text.chars().collect();
                let before: String = orig_text[..offset_in_run].iter().collect();
                let after: String = orig_text[offset_in_run..].iter().collect();

                let marker_run = ComposedTextRun {
                    text: marker_text.clone(),
                    char_style_id: cs_id,
                    lang_index: lang,
                    char_overlap: None,
                    footnote_marker: Some(number),
                    display_text: None,
                    supplemental_metrics_blocked: false,
                    inserted_control_text: false,
                    space_metric: crate::renderer::composer::SpaceMetric::Stored,
                };

                let mut new_runs = Vec::new();
                // 앞부분에서 기존 런 교체
                for (i, run) in line.runs.iter().enumerate() {
                    if i == ri {
                        if !before.is_empty() {
                            new_runs.push(ComposedTextRun {
                                text: before.clone(),
                                char_style_id: cs_id,
                                lang_index: lang,
                                char_overlap: run.char_overlap.clone(),
                                footnote_marker: None,
                                display_text: None,
                                supplemental_metrics_blocked: run.supplemental_metrics_blocked,
                                inserted_control_text: run.inserted_control_text,
                                space_metric: run.space_metric,
                            });
                        }
                        new_runs.push(marker_run.clone());
                        if !after.is_empty() {
                            new_runs.push(ComposedTextRun {
                                text: after.clone(),
                                char_style_id: cs_id,
                                lang_index: lang,
                                char_overlap: run.char_overlap.clone(),
                                footnote_marker: None,
                                display_text: None,
                                supplemental_metrics_blocked: run.supplemental_metrics_blocked,
                                inserted_control_text: run.inserted_control_text,
                                space_metric: run.space_metric,
                            });
                        }
                    } else {
                        new_runs.push(run.clone());
                    }
                }
                line.runs = new_runs;
                break; // 이 각주 처리 완료
            }
        }
    }
}

// 저장 줄의 실제 점유 높이. 줄 구성과 저장 줄 소속 재사용 판정이 같은
// 메트릭을 비교해야 글자 테두리로 높아진 정상 줄을 재조판 줄로 오인하지 않는다.
fn stored_line_box_height(seg: &LineSeg) -> i32 {
    seg.line_height.max(seg.text_height)
}

/// 문단의 텍스트를 줄별로 분할하고, 각 줄 내에서 CharShapeRef 경계에 따라 분할한다.
fn compose_lines(para: &Paragraph) -> Vec<ComposedLine> {
    if para.line_segs.is_empty() {
        // LineSeg가 없으면 텍스트를 ComposedLine 으로 분할
        if para.text.is_empty() {
            return Vec::new();
        }
        let default_style_id = para
            .char_shapes
            .first()
            .map(|cs| cs.char_shape_id)
            .unwrap_or(0);
        // [Task #994] HWP5 변환본의 일부 paragraph (sample16 의 󰏅 PUA bullet 들)
        // 는 PARA_LINE_SEG 누락 → 기존 fallback 이 단일 ComposedLine 생성 →
        // layout 이 wrap 없이 한 y 좌표에 모든 텍스트 그림 → 시각 겹침.
        // 임시 휴리스틱: 공백 기준 word wrap, ~45 chars/line (Korean 13pt 표준) 한도.
        // 정확한 line_height 는 corrected_line_height 가 layout 에서 보정 (max_fs * 1.6).
        // 향후 reflow_line_segs 정식 호출 시 본 휴리스틱 대체.
        // [Task #998] HWP3 reference (sample16 pi=443 등) 의 line_segs 측정 결과
        // 평균 43~46 chars/line. 기존 35 는 conservative — 매 paragraph +1 line
        // 발생 → 페이지 수 inflate (sample16-hwp5.hwp: 64 reference 대비 +3).
        // 45 로 조정하여 HWP3 정합 개선 (+1 까지 축소, 잔존 ParaShape 데이터 차이).
        let chars: Vec<char> = para.text.chars().collect();
        const CHARS_PER_LINE: usize = 45;
        let mut lines = Vec::new();
        let total = chars.len();
        let mut offset = 0;
        while offset < total {
            let max_end = (offset + CHARS_PER_LINE).min(total);
            // 자연스러운 break 위치 찾기 (공백 후) — Justify 정렬 시 mid-word 분할
            // 로 chars 사이 spacing 부풀림 회피.
            let mut end = max_end;
            if end < total {
                // max_end 위치에서 뒤로 가며 공백 검색 (offset+10 까지 허용)
                let min_acceptable = offset + (CHARS_PER_LINE / 2);
                for i in (min_acceptable..max_end).rev() {
                    if chars[i] == ' ' || chars[i] == '\t' {
                        end = i + 1; // 공백 포함하여 line 끝
                        break;
                    }
                }
            }
            // 강제 줄바꿈(0x0A)은 문자 수와 무관하게 그 자리에서 줄을 끝낸다 —
            // 한글은 이 문자에서 반드시 개행하므로, 무시하면 두 줄 분량이 한
            // 줄로 이어져 열 폭을 넘는다.
            if let Some(nl) = chars[offset..max_end].iter().position(|&c| c == '\n') {
                end = offset + nl + 1;
            }
            // [#7500] 남은 글자가 공백뿐이면 이 줄이 흡수한다 — 한/글은 말미 공백에 줄상자를
            // 주지 않는다(#7160 `absorb_whitespace_only_rows` 와 같은 규칙). 끊어 두면
            // 공백만 든 줄이 생겨 뒤 내용을 그 줄 수만큼 밀어낸다.
            if end < total
                && chars[end..]
                    .iter()
                    .all(|&c| matches!(c, ' ' | '\t' | '\u{3000}'))
            {
                end = total;
            }
            let line_text: String = chars[offset..end].iter().collect();
            let is_last_line = end >= total;
            // 이 폴백(PARA_LINE_SEG 누락 문단)도 CharShapeRef 경계를 존중한다 —
            // 종전에는 문단 전체를 `char_shapes[0]` 단일 run 으로 만들어, 첫
            // run 이 컨트롤 문자 구간(스트림 위주 앞부분)의 모양일 때 가시
            // 텍스트 전체가 그 모양으로 렌더됐다(제목이 15pt 흰색 bold 저장인데
            // 10pt 검정으로 — run 경계 (0,cs_a)(24,cs_b)(26,cs_c) 에서 cs_a 적용).
            // char_offsets 가 있으면 본문 경로와 같은 splitter 로 토큰화하고,
            // 없으면 종전 단일 default_style run 을 유지한다.
            let fallback_runs = if para.char_offsets.len() == total && !para.char_shapes.is_empty()
            {
                split_by_char_shapes(
                    &line_text,
                    offset,
                    end,
                    &para.char_offsets,
                    &para.char_shapes,
                )
            } else {
                split_runs_by_lang(vec![ComposedTextRun {
                    text: line_text,
                    char_style_id: default_style_id,
                    lang_index: 0,
                    char_overlap: None,
                    footnote_marker: None,
                    display_text: None,
                    supplemental_metrics_blocked: false,
                    inserted_control_text: false,
                    space_metric: crate::renderer::composer::SpaceMetric::Stored,
                }])
            };
            lines.push(ComposedLine {
                runs: fallback_runs,
                line_height: 400,
                baseline_distance: 320,
                segment_width: 0,
                column_start: 0,
                line_spacing: 0,
                // [Task #994] non-last synth wrap line 은 has_line_break=true 로 marking —
                // Justify 정렬 비활성화 (line 의 chars 가 column width 만큼 spread 되지 않음).
                // 마지막 line 은 false (기존 paragraph 동작 유지).
                has_line_break: !is_last_line,
                char_start: offset,
            });
            offset = end;
        }
        return lines;
    }

    let mut lines: Vec<ComposedLine> = Vec::new();
    let line_seg_count = effective_line_seg_count(para);

    for line_idx in 0..line_seg_count {
        let line_seg = &para.line_segs[line_idx];
        let space_metric = para.line_space_metric(line_idx);
        let split_row_runs = |text: &str, start, end, offsets: &[u32], shapes: &[CharShapeRef]| {
            let mut runs = split_by_char_shapes(text, start, end, offsets, shapes);
            for run in &mut runs {
                run.space_metric = space_metric;
            }
            runs
        };

        // UTF-16 위치 기반으로 이 줄의 텍스트 범위 계산.
        // [#5961] 아래에서 `char_offsets`·`char_count` 로 투영하므로 HWP5 축으로 올려
        // 받는다. HWPX 출처 구역 첫 문단은 저장 `textpos` 가 그만큼 짧아서, 날값을 쓰면
        // 줄이 보정폭만큼 일찍 끊긴다(한글 대조 실측: 글자 54 를 46 으로 읽는다).
        let utf16_start = para.line_seg_text_start(line_idx);
        let utf16_end = if line_idx + 1 < line_seg_count {
            para.line_seg_text_start(line_idx + 1)
        } else {
            // 마지막 줄: char_count 또는 텍스트 끝까지
            if para.char_count > 0 {
                para.char_count
            } else {
                // char_count 미설정 시 텍스트 길이 기반 추정
                para.text.chars().count() as u32 + 1
            }
        };

        // UTF-16 위치 → 텍스트 문자 인덱스로 변환
        let (text_start, mut text_end) = utf16_range_to_text_range(
            &para.char_offsets,
            utf16_start,
            utf16_end,
            para.text.chars().count(),
        );
        if text_end < text_start {
            text_end = text_start;
        }
        // 이 줄의 텍스트 추출
        let line_text: String = para
            .text
            .chars()
            .skip(text_start)
            .take(text_end - text_start)
            .collect();

        // TAC 표 문단 감지
        let has_tac = para.controls.iter().any(
            |c| matches!(c, crate::model::control::Control::Table(t) if t.common.treat_as_char),
        );

        // 강제 줄넘김(\n) + TAC 표 문단 처리 (Task #19/Task #20)
        // 아래 범위와 take/skip은 문자 인덱스다. UTF-8 바이트 위치를 쓰면
        // 한글 제목 뒤 개행이 줄 끝을 넘어 표 줄까지 제목에 합쳐진다.
        let newline_pos = line_text.chars().position(|ch| ch == '\n');
        if let (true, Some(nl_pos)) = (has_tac, newline_pos) {
            let pre_text: String = line_text.chars().take(nl_pos).collect();
            let pre_end = text_start + nl_pos;
            let post_start = text_start + nl_pos + 1;
            let post_text: String = line_text.chars().skip(nl_pos + 1).collect();
            let post_text_clean = post_text.trim_end_matches('\n').to_string();
            // [#6300] 강제 줄나눔이 이 저장 줄의 끝이고, 다음 LINE_SEG 가 인라인
            // 개체일 때만 경계를 유지한다. 같은 저장 줄 안의 `\n`+표(Task #20)는
            // 기존처럼 `\n` 앞 텍스트를 이전 줄에 합친다. 이 가드 밖의 `\n` 은
            // off-canvas·overflow-cell 래칫을 키우지 않는다.
            let keep_stored_boundary = post_text_clean.is_empty()
                && line_idx + 1 < line_seg_count
                && tac_inline_object_starts_at(para, text_end)
                // The first stored row also owns its terminating break.
                // Requiring a previous row creates an extra empty row before
                // the already stored next table row (#7165).
                && lines.last().is_none_or(|prev| prev.char_start != text_start);

            if !pre_text.is_empty() && !lines.is_empty() && !keep_stored_boundary {
                // \n 앞 텍스트를 이전 ComposedLine에 합침 (한컴 방식: \n 전 전체가 한 줄)
                let prev: &mut ComposedLine = lines.last_mut().unwrap();
                let mut extra_runs = split_row_runs(
                    &pre_text,
                    text_start,
                    pre_end,
                    &para.char_offsets,
                    &para.char_shapes,
                );
                prev.runs.append(&mut extra_runs);
                prev.has_line_break = true;
            } else if !pre_text.is_empty() || keep_stored_boundary {
                // A terminating break owns its stored line box even with no
                // visible glyphs. Measurement and placement consume this same
                // row before the following inline object.
                let pre_runs = split_row_runs(
                    &pre_text,
                    text_start,
                    pre_end,
                    &para.char_offsets,
                    &para.char_shapes,
                );
                let pre_lh = if line_seg.text_height > 0
                    && line_seg.text_height < line_seg.line_height / 3
                {
                    line_seg.text_height
                } else {
                    line_seg.line_height
                };
                lines.push(ComposedLine {
                    runs: pre_runs,
                    line_height: pre_lh,
                    baseline_distance: line_seg.baseline_distance,
                    segment_width: line_seg.segment_width,
                    column_start: line_seg.column_start,
                    line_spacing: line_seg.line_spacing,
                    has_line_break: true,
                    char_start: text_start,
                });
            }

            // \n 이후: 표 줄 (빈 runs, 표는 layout에서 별도 처리)
            // [#6300] 다음 저장 줄이 인라인 개체면 빈 후속 줄을 여기서 만들지 않는다.
            if !(keep_stored_boundary && post_text_clean.is_empty()) {
                let post_runs = split_row_runs(
                    &post_text_clean,
                    post_start,
                    text_end,
                    &para.char_offsets,
                    &para.char_shapes,
                );
                lines.push(ComposedLine {
                    runs: post_runs,
                    line_height: line_seg.line_height,
                    baseline_distance: line_seg.baseline_distance,
                    segment_width: line_seg.segment_width,
                    column_start: line_seg.column_start,
                    line_spacing: line_seg.line_spacing,
                    has_line_break: post_text.ends_with('\n'),
                    char_start: post_start,
                });
            }
        } else {
            // 일반 처리: LINE_SEG 범위 안에 강제 줄바꿈(\n)이 있으면 실제 줄로 분할한다.
            // Shift+Enter는 문단을 새로 만들지 않지만 렌더러/커서/들여쓰기 계산에서는
            // 다음 visual line 이 별도 ComposedLine 이어야 한다.
            let line_chars: Vec<char> = line_text.chars().collect();
            let mut segment_start = 0usize;

            let corrected_lh = if has_tac
                && line_seg.text_height > 0
                && line_seg.text_height < line_seg.line_height / 3
            {
                line_seg.text_height
            } else {
                // 글자 테두리 등으로 텍스트 점유 높이가 명목 줄 높이를 넘을 수
                // 있다. 한컴 저장 줄(1000/1056/632)은 1688HU씩 전진한다.
                // 공통 구성 결과에 점유 높이를 싣고 측정과 paint가 함께 소비한다.
                stored_line_box_height(line_seg)
            };

            let mut push_segment = |segment_start: usize, segment_end: usize, has_break: bool| {
                let segment_text: String = line_chars[segment_start..segment_end].iter().collect();
                let segment_abs_start = text_start + segment_start;
                let segment_abs_end = text_start + segment_end;
                let runs = split_row_runs(
                    &segment_text,
                    segment_abs_start,
                    segment_abs_end,
                    &para.char_offsets,
                    &para.char_shapes,
                );
                lines.push(ComposedLine {
                    runs,
                    line_height: corrected_lh,
                    baseline_distance: line_seg.baseline_distance,
                    segment_width: line_seg.segment_width,
                    column_start: line_seg.column_start,
                    line_spacing: line_seg.line_spacing,
                    has_line_break: has_break,
                    char_start: segment_abs_start,
                });
            };

            for (rel_idx, ch) in line_chars.iter().enumerate() {
                if *ch == '\n' {
                    push_segment(segment_start, rel_idx, true);
                    segment_start = rel_idx + 1;
                }
            }

            if segment_start < line_chars.len() || !line_text.ends_with('\n') {
                push_segment(segment_start, line_chars.len(), false);
            }
        }
    }

    lines
}

fn effective_line_seg_count(para: &Paragraph) -> usize {
    if is_sample16_2022_bcp_orphan_tail_lineseg(para) {
        para.line_segs.len().saturating_sub(1)
    } else {
        para.line_segs.len()
    }
}

/// [#4384 조사] 이 문단 텍스트 리터럴을 IR 속성 판정으로 일반화할 수 있는지 조사했으나
/// 안전하게 일반화할 신호를 찾지 못했다 — 아래는 기각한 가설과 근거다.
///
/// 1. **LINE_SEG tag bit 17/18(첫/마지막 세그먼트)**: `hwp3-sample16-hwp5-2022.hwp`
///    p83 실측 — 두 LINE_SEG 모두 `tag=0x00060000`/`0x00160000`으로 bit17+18
///    (`LineSeg::TAG_SINGLE_SEGMENT_LINE`)을 함께 켜고 있다. 즉 한컴 인코더 자신도
///    이 둘을 "한 줄이 세그먼트 2개로 쪼개진 것"이 아니라 "완결된 줄 2개"로
///    표시했다 — 세그먼트 비트로는 이 문서조차 구분되지 않는다.
/// 2. **bit 20(indentation 적용) 차이**: 유일하게 다른 비트가 bit20(ls[1]에만 설정)
///    이다. 그러나 이 문단의 ParaShape는 `indent=-5000`(내어쓰기, 번호/글머리
///    스타일)이고, bit20은 내어쓰기 문단의 "이어지는 줄"에 일반적으로 켜지는
///    비트라 — 이 신호로 판정하면 내어쓰기 문단의 정상적인 2번째 줄 전부가
///    (합쳐지면 안 되는데도) 접혀버린다. 오탐 범위가 이 문서 하나가 아니라
///    "내어쓰기 문단 + 짧은 마지막 줄" 전체로 넓어진다.
/// 3. **"마지막 줄이 짧다"는 기하 조건 단독**: 문단이 줄바꿈 후 마지막 줄에 단어
///    1~2개만 남는 것은 지극히 흔한 정상 조판 결과다(orphan/widow 자체가 아니라
///    그냥 마지막 줄). 이 조건만으로 접으면 정상적으로 2줄이어야 하는 문단들을
///    광범위하게 회귀시킨다.
///
/// 즉 이 오프셋/피치 조건은 이미 `hwp3-sample16-hwp5-2022.hwp` 문서 안에서도
/// "정상적인 마지막 짧은 줄"과 "한컴이 인코딩은 2줄로 했지만 실제로는 1줄로
/// 그리는 이 특정 문단"을 IR 필드만으로 구분하지 못한다 — 텍스트 리터럴이 사실상
/// 유일하게 안전한 좁힘 조건이다. 회귀 fixture: `tests/issue_1116.rs`
/// (`sample16_hwp5_2022_page3_bcp_tail_paragraph_folds_orphan_lineseg` 등).
fn is_sample16_2022_bcp_orphan_tail_lineseg(para: &Paragraph) -> bool {
    if para.line_segs.len() != 2 {
        return false;
    }
    if !para.text.contains("BCP:Business Continuity Planning) 수립") {
        return false;
    }

    let first = &para.line_segs[0];
    let last = &para.line_segs[1];
    // [#5961] `char_count` 는 HWP5 축이므로 `text_start` 도 올려서 견준다.
    if para.line_seg_text_start(1) < para.char_count.saturating_sub(2) {
        return false;
    }
    last.vertical_pos == first.vertical_pos + first.line_height + first.line_spacing
}

/// UTF-16 위치 범위를 텍스트 문자 인덱스 범위로 변환한다.
pub(crate) fn utf16_range_to_text_range(
    char_offsets: &[u32],
    utf16_start: u32,
    utf16_end: u32,
    text_len: usize,
) -> (usize, usize) {
    if char_offsets.is_empty() {
        // 오프셋 정보가 없으면 1:1 매핑 가정
        let start = (utf16_start as usize).min(text_len);
        let end = (utf16_end as usize).min(text_len);
        return (start, end);
    }

    // char_offsets[i] >= utf16_start인 첫 번째 i가 text_start
    let text_start = char_offsets
        .iter()
        .position(|&off| off >= utf16_start)
        .unwrap_or(text_len);

    // char_offsets[i] >= utf16_end인 첫 번째 i가 text_end
    let text_end = char_offsets
        .iter()
        .position(|&off| off >= utf16_end)
        .unwrap_or(text_len);

    (text_start, text_end)
}

/// 줄 내 텍스트를 CharShapeRef 경계에 따라 다중 TextRun으로 분할한다.
fn split_by_char_shapes(
    line_text: &str,
    text_start: usize,
    text_end: usize,
    char_offsets: &[u32],
    char_shapes: &[CharShapeRef],
) -> Vec<ComposedTextRun> {
    if line_text.is_empty() {
        return Vec::new();
    }

    if char_shapes.is_empty() {
        return split_runs_by_lang(vec![ComposedTextRun {
            text: line_text.to_string(),
            char_style_id: 0,
            lang_index: 0,
            char_overlap: None,
            footnote_marker: None,
            display_text: None,
            supplemental_metrics_blocked: false,
            inserted_control_text: false,
            space_metric: crate::renderer::composer::SpaceMetric::Stored,
        }]);
    }

    // 이 줄 범위에 영향을 미치는 CharShapeRef 찾기
    //
    // [#915] CharShapeRef.start_pos 는 paragraph 텍스트의 UTF-16 stream offset
    // 이다 (해석 A). char_offsets[i] 가 가시문자 i 의 stream offset 이므로,
    // start_pos 이상인 첫 char_offsets 항목이 char_shape 적용 시작 가시문자다.
    //
    // 해석 이력: #884 가 start_pos 를 visible char index 로 해석(해석 B)하도록
    // 바꿨으나, 그 근거였던 table-in-tbox.hwp footer "충남중부권지사장" 의
    // "26pt" 판정이 오진(실제 HY수평선B 16pt — 한컴 폰트 패널 확인)이었다.
    // 해석 B 는 인라인 제어자가 문단 중간에 있는 경우(char_offsets gap) start_pos
    // 가 범위 밖으로 부풀려져 char_shape 가 통째 누락된다 (#915 — table-in-tbox
    // p2 "충남중부권지사" 가 1pt 로 렌더). 또한 paragraph_layout.rs /
    // line_breaking.rs 는 줄곧 해석 A 를 써 와서 #884 이후 composer 와 불일치
    // 상태였다 — 본 수정으로 전 경로가 해석 A 로 일관된다.
    let total_chars = char_offsets.len();
    // [#915] 줄 시작 가시문자의 stream offset — fallback active-shape 조회용.
    let line_stream_start = char_offsets
        .get(text_start)
        .copied()
        .unwrap_or(text_start as u32);
    let mut segments: Vec<(usize, u32)> = Vec::new();

    for cs in char_shapes {
        // start_pos(stream offset) 이상인 첫 가시문자가 char_shape 적용 시작점.
        let cs_visible_idx = char_offsets
            .iter()
            .position(|&off| off >= cs.start_pos)
            .unwrap_or(total_chars);
        // cs 가 이 줄 범위 밖이면 skip
        if cs_visible_idx >= text_end {
            continue;
        }
        let text_idx = cs_visible_idx.saturating_sub(text_start);
        segments.push((text_idx, cs.char_shape_id));
    }

    // 시작 인덱스로 정렬 (동일 인덱스 내에서는 원래 순서 유지)
    segments.sort_by_key(|&(idx, _)| idx);

    // 중복 시작 위치 제거: 동일 위치의 마지막 것(가장 최근 CharShapeRef)만 유지
    // 뒤에서부터 dedup하면 마지막 것이 유지됨
    segments.reverse();
    segments.dedup_by_key(|s| s.0);
    segments.reverse();

    // segments가 비어있으면 첫 번째 CharShapeRef 사용
    if segments.is_empty() {
        // 줄 시작 위치 이전의 마지막 CharShapeRef 찾기
        let style_id = find_active_char_shape(char_shapes, line_stream_start);
        return split_runs_by_lang(vec![ComposedTextRun {
            text: line_text.to_string(),
            char_style_id: style_id,
            lang_index: 0,
            char_overlap: None,
            footnote_marker: None,
            display_text: None,
            supplemental_metrics_blocked: false,
            inserted_control_text: false,
            space_metric: crate::renderer::composer::SpaceMetric::Stored,
        }]);
    }

    // TextRun 생성
    let chars: Vec<char> = line_text.chars().collect();
    let mut runs = Vec::new();

    for i in 0..segments.len() {
        let (start_idx, style_id) = segments[i];
        let end_idx = if i + 1 < segments.len() {
            segments[i + 1].0
        } else {
            chars.len()
        };

        if start_idx < end_idx && start_idx < chars.len() {
            let actual_end = end_idx.min(chars.len());
            let run_text: String = chars[start_idx..actual_end].iter().collect();
            if !run_text.is_empty() {
                runs.push(ComposedTextRun {
                    text: run_text,
                    char_style_id: style_id,
                    lang_index: 0,
                    char_overlap: None,
                    footnote_marker: None,
                    display_text: None,
                    supplemental_metrics_blocked: false,
                    inserted_control_text: false,
                    space_metric: crate::renderer::composer::SpaceMetric::Stored,
                });
            }
        }
    }

    // 첫 번째 segment가 0이 아닌 경우, 앞 부분 처리
    if !segments.is_empty() && segments[0].0 > 0 {
        let style_id = find_active_char_shape(char_shapes, line_stream_start);
        let end_idx = segments[0].0.min(chars.len());
        let prefix_text: String = chars[..end_idx].iter().collect();
        if !prefix_text.is_empty() {
            runs.insert(
                0,
                ComposedTextRun {
                    text: prefix_text,
                    char_style_id: style_id,
                    lang_index: 0,
                    char_overlap: None,
                    footnote_marker: None,
                    display_text: None,
                    supplemental_metrics_blocked: false,
                    inserted_control_text: false,
                    space_metric: crate::renderer::composer::SpaceMetric::Stored,
                },
            );
        }
    }

    if runs.is_empty() {
        let style_id = find_active_char_shape(char_shapes, line_stream_start);
        runs.push(ComposedTextRun {
            text: line_text.to_string(),
            char_style_id: style_id,
            lang_index: 0,
            char_overlap: None,
            footnote_marker: None,
            display_text: None,
            supplemental_metrics_blocked: false,
            inserted_control_text: false,
            space_metric: crate::renderer::composer::SpaceMetric::Stored,
        });
    }

    // 언어 카테고리별로 Run을 세분화
    split_runs_by_lang(runs)
}

/// 주어진 UTF-16 위치에서 활성화된 CharShapeRef의 char_shape_id를 찾는다.
///
/// [Task #884] 해석 B 적용으로 start_pos 는 visible char index 이므로 이 함수의
/// utf16_pos 인자는 의미가 모호해진다. 호출자가 char_offsets 통해 utf16 → visible
/// idx 변환 후 [`find_active_char_shape_visible`] 사용 권장. 본 함수는 호환성을
/// 위해 유지하나 향후 deprecate 예정.
pub(crate) fn find_active_char_shape(char_shapes: &[CharShapeRef], utf16_pos: u32) -> u32 {
    // utf16_pos 를 visible idx 로 직접 비교 (해석 B)
    find_active_char_shape_visible(char_shapes, utf16_pos as usize)
}

/// [Task #884] visible char index 로 활성 char_shape 찾기
pub(crate) fn find_active_char_shape_visible(
    char_shapes: &[CharShapeRef],
    visible_idx: usize,
) -> u32 {
    let mut active_id = char_shapes.first().map(|cs| cs.char_shape_id).unwrap_or(0);
    for cs in char_shapes {
        if (cs.start_pos as usize) <= visible_idx {
            active_id = cs.char_shape_id;
        } else {
            break;
        }
    }
    active_id
}

/// TextRun 목록을 언어 카테고리 경계에 따라 세분화한다.
///
/// 동일 CharShape 내에서도 한글→영문 전환 시 별도 Run으로 분리하여
/// 각 언어에 맞는 폰트를 적용할 수 있도록 한다.
///
/// 공백/구두점은 이전 문자의 언어를 따른다 (불필요한 Run 분할 방지).
pub(crate) fn split_runs_by_lang(runs: Vec<ComposedTextRun>) -> Vec<ComposedTextRun> {
    let mut result = Vec::new();

    for run in runs {
        let chars: Vec<char> = run.text.chars().collect();
        if chars.is_empty() {
            result.push(run);
            continue;
        }

        // 첫 번째 비중립 문자의 언어를 찾아 초기 언어로 설정
        let initial_lang = chars
            .iter()
            .map(|&c| detect_lang_category(c))
            .find(|&lang| lang != 0 || chars.iter().all(|&c| detect_lang_category(c) == 0))
            .unwrap_or(0);

        let mut current_lang = initial_lang;
        let mut current_start = 0;

        for (i, &ch) in chars.iter().enumerate() {
            let char_lang = detect_lang_category(ch);

            // 언어 중립 문자(공백/구두점 등 = 기본값 0)는 이전 언어를 따름
            // 단, detect_lang_category가 0을 반환하는 것은 한국어 또는 중립 두 가지 경우:
            //   - 한글 음절/자모: 명시적으로 0번 매치
            //   - 공백/구두점: _ => 0 폴백
            // 한글 음절은 확실한 한국어이므로 구분해야 함
            let is_neutral = is_lang_neutral(ch);

            if is_neutral {
                // 중립 문자: 현재 언어 유지
                continue;
            }

            if char_lang != current_lang {
                // 언어 전환: 이전 구간 확정
                if i > current_start {
                    let text: String = chars[current_start..i].iter().collect();
                    result.push(ComposedTextRun {
                        text,
                        char_style_id: run.char_style_id,
                        lang_index: current_lang,
                        char_overlap: run.char_overlap.clone(),
                        footnote_marker: None,
                        display_text: None,
                        supplemental_metrics_blocked: run.supplemental_metrics_blocked,
                        inserted_control_text: run.inserted_control_text,
                        space_metric: run.space_metric,
                    });
                }
                current_lang = char_lang;
                current_start = i;
            }
        }

        // 마지막 구간
        let text: String = chars[current_start..].iter().collect();
        if !text.is_empty() {
            result.push(ComposedTextRun {
                text,
                char_style_id: run.char_style_id,
                lang_index: current_lang,
                char_overlap: run.char_overlap.clone(),
                footnote_marker: None,
                display_text: None,
                supplemental_metrics_blocked: run.supplemental_metrics_blocked,
                inserted_control_text: run.inserted_control_text,
                space_metric: run.space_metric,
            });
        }
    }

    result
}

/// Legacy Latin 구두점인가 — [`crate::renderer::TextStyle::ascii_punct_latin`] 가
/// 있는 run 에서 한/글은 이 글자를 영문 슬롯 글꼴로 잰다.
/// `76076` 한컴 2024 PDF의 가운뎃점·작은따옴표도 Palatino Linotype 슬롯이다.
/// 한글 face 자체의 가운뎃점 폭과 HFT 한점 리더는 이 슬롯 조건 밖이다.
pub(crate) fn is_latin_slot_punct(ch: char) -> bool {
    ch.is_ascii_punctuation() || matches!(ch, '\u{00B7}' | '\u{2018}' | '\u{2019}')
}

/// Newly composed neutral punctuation shares one explicit slot between width and paint.
/// Stored runs retain their own inherited face; ASCII keeps its existing metric rule.
pub(crate) fn reflow_punctuation_slot(ch: char, inherited: usize, punct_latin: bool) -> usize {
    if punct_latin && !ch.is_ascii() && is_latin_slot_punct(ch) {
        1
    } else {
        inherited
    }
}

/// 글자의 언어 슬롯. 중립 문자는 앞 글자 언어(`carry`)를 따른다. `punct_latin` 인 글자
/// 모양의 ASCII 구두점은 영문(1)으로 재되 `carry` 는 바꾸지 않는다 — 뒤 공백이 앞 언어를 잇도록.
pub(crate) fn char_lang_slot(ch: char, carry: &mut usize, punct_latin: bool) -> usize {
    if punct_latin && is_latin_slot_punct(ch) {
        1
    } else if is_lang_neutral(ch) {
        *carry
    } else {
        let lang = detect_lang_category(ch);
        *carry = lang;
        lang
    }
}

/// 언어 중립 문자인지 판별한다 (공백, ASCII 구두점, 일반 기호 등).
/// 이 문자들은 Run 분할을 유발하지 않고 이전 문자의 언어를 따른다.
pub(crate) fn is_lang_neutral(ch: char) -> bool {
    let cp = ch as u32;
    matches!(cp,
        // 공백/제어문자
        0x0000..=0x0020 |
        // ASCII 구두점/기호 (영문자/숫자 제외)
        0x0021..=0x002F | 0x003A..=0x0040 | 0x005B..=0x0060 | 0x007B..=0x007F |
        // Latin-1 Supplement 구두점 (문자 제외)
        0x00A0..=0x00BF
    )
}

/// 문단 내 인라인 컨트롤(표/도형)의 위치를 식별한다.
/// [#6706] 줄 끝 개체와 다음 줄 첫 글자는 같은 가시 위치로 투영될 수 있다.
/// 원본 줄 구성이 유지되고 그 충돌이 실제 존재할 때 원 기록으로 개체 소유 줄을 복원한다.
/// 재조판된 줄이나 경계 충돌이 없는 인라인 개체들은 기존 문자 범위 배정을 그대로 쓴다.
pub(crate) fn stored_tac_line_assignment(
    para: &Paragraph,
    comp: &ComposedParagraph,
) -> Option<Vec<(usize, usize)>> {
    if super::equation_tac_flow::uses_equation_only_flow(para, comp)
        || para.char_offsets.is_empty()
        || comp.lines.len() != para.line_segs.len()
        || comp.lines.len() < 2
        || comp
            .lines
            .iter()
            .zip(&para.line_segs)
            .enumerate()
            .any(|(i, (line, seg))| {
                seg.tag & LineSeg::TAG_IMPLEMENTATION_PROPERTY != 0
                    || line.line_height != stored_line_box_height(seg)
                    || line.segment_width != seg.segment_width
                    || line.char_start
                        != para
                            .char_offsets
                            .partition_point(|&offset| offset < para.line_seg_text_start(i))
            })
    {
        return None;
    }
    let raw = para.control_utf16_positions();
    let assignments: Vec<(usize, usize)> = comp
        .tac_controls
        .iter()
        .map(|(_, _, ci)| {
            let start = *raw.get(*ci)?;
            let owner =
                (0..para.line_segs.len()).rfind(|&i| para.line_seg_text_start(i) <= start)?;
            Some((*ci, owner))
        })
        .collect::<Option<_>>()?;
    let collapsed_boundary =
        comp.tac_controls
            .iter()
            .zip(&assignments)
            .any(|((pos, _, _), (_, owner))| {
                comp.lines
                    .get(owner + 1)
                    .is_some_and(|next| *pos >= next.char_start)
            });
    collapsed_boundary.then_some(assignments)
}

fn identify_inline_controls(para: &Paragraph) -> Vec<InlineControl> {
    let mut result = Vec::new();

    for (ctrl_idx, ctrl) in para.controls.iter().enumerate() {
        let control_type = match ctrl {
            Control::Table(t) if t.common.treat_as_char => InlineControlType::Table,
            Control::Shape(shape) if shape.common().treat_as_char => InlineControlType::Shape,
            Control::Picture(pic) if pic.common.treat_as_char => InlineControlType::Shape,
            Control::Equation(eq) if eq.common.treat_as_char => InlineControlType::Shape,
            Control::SectionDef(_) | Control::ColumnDef(_) => InlineControlType::Other,
            _ => continue,
        };

        // 이 컨트롤이 어느 줄에 속하는지 결정
        // 컨트롤은 문단의 controls 배열에 순서대로 저장됨
        // 정확한 줄 위치는 텍스트 내 제어 문자 위치로 결정해야 하지만,
        // 현재는 첫 번째 줄에 배치 (향후 정확한 위치 계산 가능)
        let line_index = 0;

        result.push(InlineControl {
            line_index,
            control_index: ctrl_idx,
            control_type,
        });
    }

    result
}

fn is_render_inline_control(ctrl: &Control) -> bool {
    match ctrl {
        Control::Picture(pic) => pic.common.treat_as_char,
        Control::Shape(shape) => shape.common().treat_as_char,
        Control::Table(table) => table.common.treat_as_char,
        Control::Equation(eq) => eq.common.treat_as_char,
        // [#6266] 양식 개체도 자기 배치를 갖는다 — 비-TAC 은 인라인이 아니다.
        Control::Form(form) => form.common.treat_as_char,
        _ => false,
    }
}

/// [#6300] 다음 줄의 머리 공백 뒤에 treat_as_char 인라인 개체가 있는지.
fn tac_inline_object_starts_at(para: &Paragraph, pos: usize) -> bool {
    let chars: Vec<_> = para.text.chars().collect();
    para.controls
        .iter()
        .zip(para.control_text_positions())
        .any(|(ctrl, ctrl_pos)| {
            is_render_inline_control(ctrl)
                && pos <= ctrl_pos
                && ctrl_pos <= chars.len()
                && chars[pos..ctrl_pos]
                    .iter()
                    .all(|ch| ch.is_whitespace() && !matches!(ch, '\n' | '\r'))
        })
}

pub(crate) fn find_render_inline_control_positions(para: &Paragraph) -> Vec<usize> {
    if para.text.is_empty() && para.char_offsets.is_empty() {
        let mut inline_seen = 0usize;
        let mut positions = Vec::with_capacity(para.controls.len());
        for ctrl in &para.controls {
            positions.push(inline_seen);
            if is_render_inline_control(ctrl) {
                inline_seen += 1;
            }
        }
        return positions;
    }

    para.control_text_positions()
}

/// CharOverlap 컨트롤의 글자를 조합된 텍스트에 올바른 위치로 삽입한다.
///
/// char_offsets 갭 분석으로 각 CharOverlap의 원래 텍스트 위치를 복원하고,
/// 해당 위치의 composed line에서 기존 텍스트 런을 분할하여 CharOverlap 런을 삽입한다.
fn inject_char_overlap_text(composed: &mut ComposedParagraph, para: &Paragraph) {
    // CharOverlap 컨트롤과 인덱스 수집
    let char_overlap_indices: Vec<(usize, &crate::model::control::CharOverlap)> = para
        .controls
        .iter()
        .enumerate()
        .filter_map(|(i, c)| {
            if let Control::CharOverlap(co) = c {
                Some((i, co))
            } else {
                None
            }
        })
        .collect();

    if char_overlap_indices.is_empty() {
        return;
    }

    // 모든 컨트롤의 텍스트 위치 결정
    let control_positions = para.control_text_positions();

    // CharOverlap별 (텍스트위치, 런) 수집
    let mut insertions: Vec<(usize, ComposedTextRun)> = Vec::new();
    for (ctrl_idx, co) in &char_overlap_indices {
        let text: String = co.chars.iter().collect();
        if text.is_empty() {
            continue;
        }
        let char_style_id = co
            .char_shape_ids
            .iter()
            .find(|&&id| id != 0xFFFFFFFF)
            .copied()
            .unwrap_or(0);
        let text_pos = control_positions.get(*ctrl_idx).copied().unwrap_or(0);
        insertions.push((
            text_pos,
            ComposedTextRun {
                text,
                char_style_id,
                lang_index: 0,
                char_overlap: Some(CharOverlapInfo {
                    border_type: co.border_type,
                    inner_char_size: co.inner_char_size,
                }),
                footnote_marker: None,
                display_text: None,
                supplemental_metrics_blocked: false,
                inserted_control_text: true,
                space_metric: crate::renderer::composer::SpaceMetric::Stored,
            },
        ));
    }

    if insertions.is_empty() {
        return;
    }

    if composed.lines.is_empty() {
        // 빈 문단: line_segs에서 줄 정보를 가져와 새 줄 생성
        let (lh, bd, ls) = para
            .line_segs
            .first()
            .map(|s| (s.line_height, s.baseline_distance, s.line_spacing))
            .unwrap_or((400, 340, 0));
        composed.lines.push(ComposedLine {
            runs: insertions.into_iter().map(|(_, run)| run).collect(),
            line_height: lh,
            baseline_distance: bd,
            segment_width: 0,
            column_start: 0,
            line_spacing: ls,
            has_line_break: false,
            char_start: 0,
        });
        return;
    }

    // 역순으로 삽입하여 이전 인덱스가 무효화되지 않도록
    insertions.sort_by_key(|(pos, _)| std::cmp::Reverse(*pos));

    for (text_pos, overlap_run) in insertions {
        insert_overlap_run(composed, text_pos, overlap_run);
    }
}

/// 조합된 라인들에서 text_pos 위치에 CharOverlap 런을 삽입한다.
/// 기존 텍스트 런을 필요시 분할한다.
fn insert_overlap_run(
    composed: &mut ComposedParagraph,
    text_pos: usize,
    overlap_run: ComposedTextRun,
) {
    let mut char_offset = 0usize;

    for line in composed.lines.iter_mut() {
        let line_char_count: usize = line
            .runs
            .iter()
            .filter(|r| r.char_overlap.is_none())
            .map(|r| r.text.chars().count())
            .sum();

        if text_pos < char_offset + line_char_count || text_pos == char_offset {
            // 이 라인에 삽입
            let local_pos = text_pos - char_offset;
            let mut run_offset = 0usize;

            for run_idx in 0..line.runs.len() {
                // CharOverlap 런은 건너뜀 (이미 삽입된 것)
                if line.runs[run_idx].char_overlap.is_some() {
                    continue;
                }

                let run_chars = line.runs[run_idx].text.chars().count();

                if local_pos == run_offset {
                    // 런 앞에 삽입
                    line.runs.insert(run_idx, overlap_run);
                    return;
                } else if local_pos > run_offset && local_pos < run_offset + run_chars {
                    // 런 중간에 삽입: 런을 분할
                    let split_at = local_pos - run_offset;
                    let original_text: String = line.runs[run_idx].text.chars().collect();
                    let before: String = original_text.chars().take(split_at).collect();
                    let after: String = original_text.chars().skip(split_at).collect();

                    let style_id = line.runs[run_idx].char_style_id;
                    let lang_idx = line.runs[run_idx].lang_index;

                    // 기존 런을 before로 교체
                    line.runs[run_idx].text = before;

                    // after 런 생성
                    let after_run = ComposedTextRun {
                        text: after,
                        char_style_id: style_id,
                        lang_index: lang_idx,
                        char_overlap: None,
                        footnote_marker: None,
                        display_text: None,
                        supplemental_metrics_blocked: line.runs[run_idx]
                            .supplemental_metrics_blocked,
                        inserted_control_text: line.runs[run_idx].inserted_control_text,
                        space_metric: line.runs[run_idx].space_metric,
                    };

                    // overlap_run과 after_run을 삽입
                    line.runs.insert(run_idx + 1, after_run);
                    line.runs.insert(run_idx + 1, overlap_run);
                    return;
                }

                run_offset += run_chars;
            }

            // 라인 끝에 삽입
            line.runs.push(overlap_run);
            return;
        }

        char_offset += line_char_count;
    }

    // 어느 라인에도 해당하지 않으면 마지막 라인에 추가
    if let Some(last_line) = composed.lines.last_mut() {
        last_line.runs.push(overlap_run);
    }
}

/// ComposedLine의 폭을 언어 인식 측정으로 계산한다.
///
/// 각 run별로 해당 언어의 폰트/자간/장평을 적용하여 측정한다.
/// 진단 API에서 저장된 segment_width와 비교하는 데 사용한다.
pub fn estimate_composed_line_width(line: &ComposedLine, styles: &ResolvedStyleSet) -> f64 {
    line.runs
        .iter()
        .map(|run| {
            let ts = run.text_style(styles);
            estimate_text_width(effective_text_for_metrics(run), &ts)
        })
        .sum()
}

/// 새 LINE_SEG를 만들 때만 한컴 재조판 공백 metric을 반영한 텍스트 폭.
///
/// 저장본의 글꼴 고유 공백과 한컴이 새로 조판한 반각 공백은 다를 수 있다. 호출자는
/// 저장 LINE_SEG가 없는 문단이나 폭 변경 뒤 재조판한 문단만 `true`를 전달한다.
fn estimate_regenerated_line_text_width(
    text: &str,
    style: &TextStyle,
    regenerated_line_space_metric: bool,
) -> f64 {
    let measured = estimate_text_width_unrounded(text, style);
    if !regenerated_line_space_metric {
        return measured;
    }
    let Some(regenerated_space_width) = hancom_regenerated_space_width(style) else {
        return measured;
    };
    let stored_space_width = estimate_text_width_unrounded(" ", style);
    measured
        + text.chars().filter(|&ch| ch == ' ').count() as f64
            * (regenerated_space_width - stored_space_width)
}

/// literal-space 들여쓰기 재조판에서 사용할 반각 공백 advance.
///
/// 한컴 PDF의 #3128 문단은 글꼴 고유 U+0020 폭이 반각보다 넓어도
/// (한양중고딕 550/1024em) 선행 들여쓰기와 재조판된 내부 공백을 모두
/// 0.5em 칸으로 측정한다. 이 함수는 둘 이상의 literal 선행 공백과 동일
/// 글꼴 metric/구간별 자간을 확인한 좁은 fallback 경로에서만 사용한다.
fn regenerated_half_space_width(style: &TextStyle) -> f64 {
    let font_size = style.font_size.max(0.0);
    let ratio = if style.ratio > 0.0 { style.ratio } else { 1.0 };
    // [#7387] `use_font_space` run 은 반각이 아니라 영문 슬롯 글꼴의 공백폭을 쓴다.
    let base = font_size * style.font_space_em.unwrap_or(0.5) * ratio;
    let tracking = if font_size > 0.0 {
        style.letter_spacing * (base / font_size)
    } else {
        style.letter_spacing
    };
    let mut width = base + tracking + style.extra_char_spacing + style.extra_word_spacing;
    if style.letter_spacing + style.extra_char_spacing < 0.0 {
        width = width.max(base * 0.5);
    }
    width
}

/// [#2146] 저장 LINE_SEG 이 전혀 없고(NO_LS) 모든 문단이 1줄이며 각 줄이 셀
/// 폭을 여유 있게 쓰는 코너-라벨 셀 중, 선언 셀높이를 신뢰할 수 있는 두 경우:
///
/// - (a) **사선(대각선) 셀** — 셀 BF 또는 cellzone BF(#1623)에 사선. 한글은
///   사선 셀 문단("|직렬" 등)을 일반 텍스트 흐름으로 배치하지 않고 코너
///   라벨로 그리므로 행높이가 저장 선언 그대로다 (21761835 r0 c0).
/// - (b) **고정(Fixed) 줄간격 모순 셀** — 전 문단 Fixed ls 합이 선언 내부높이
///   초과 (21761835 r0 c1 "계급|직류": 37.76px×2 > 48.6px). 저장 스타일과
///   저장 지오메트리가 충돌하면 한글은 지오메트리(선언 행높이)를 유지한다.
///
/// 재합성 줄높이가 선언을 초과해도 선언높이를 신뢰한다 (#1763/#2097 계열).
///
/// 그 밖의 **사선 없는** 일반 라벨 셀은 제외한다 — 한글이 fresh 레이아웃으로
/// 선언 이상 키우는 문서(#1891 76076 규제영향분석서: 구분/장점/할인율 등
/// 클램프 시 82→79쪽 회귀 관측)가 존재하여 선언 신뢰가 성립하지 않는다.
/// 보조 가드:
/// - 폭 여유(85%): 한글 폰트 메트릭이 본 환경보다 넓어 한글에서만 2줄로
///   래핑되는 셀 배제.
/// - 선언 내부높이 ≥ 문단별 em 합: 한 줄 em 도 못 담는 스테일(생성기 기록)
///   선언높이 배제 — 한글은 최소 em 으로 행을 키운다 (#1842 em 원칙).
pub(crate) fn no_ls_short_label_cell(
    cell: &crate::model::table::Cell,
    table: &crate::model::table::Table,
    cell_inner_width: f64,
    cell_inner_height: f64,
    styles: &ResolvedStyleSet,
    dpi: f64,
) -> bool {
    if cell.paragraphs.is_empty() || cell_inner_width <= 0.0 || cell_inner_height <= 0.0 {
        return false;
    }
    let bf_has_diagonal = |bf_id: u16| {
        bf_id != 0
            && styles
                .border_styles
                .get((bf_id as usize).saturating_sub(1))
                .is_some_and(crate::renderer::layout::border_style_has_diagonal)
    };
    // 사선은 셀 자체 BF 또는 셀을 덮는 cellzone BF(#1623)에 지정될 수 있다.
    let cell_has_diagonal = bf_has_diagonal(cell.border_fill_id)
        || table.zones.iter().any(|z| {
            z.start_row <= cell.row
                && cell.row <= z.end_row
                && z.start_col <= cell.col
                && cell.col <= z.end_col
                && bf_has_diagonal(z.border_fill_id)
        });
    // 저장 고정(Fixed) 줄간격의 합이 선언 내부높이를 초과하는 모순 셀
    // (21761835 r0 c1 "계급|직류": ps Fixed 37.76px ×2문단 > 선언 내부 48.6px).
    // 저장 스타일과 저장 지오메트리가 충돌할 때 한글은 지오메트리(선언 행높이)
    // 를 유지한다 — 선언 신뢰 가능한 국소 모순 신호.
    let fixed_ls_contradicts_declared = {
        let mut sum = 0.0f64;
        let all_fixed = cell.paragraphs.iter().all(|p| {
            styles
                .para_styles
                .get(p.para_shape_id as usize)
                .map(|ps| {
                    if ps.line_spacing_type == crate::model::style::LineSpacingType::Fixed {
                        sum += ps.line_spacing;
                        true
                    } else {
                        false
                    }
                })
                .unwrap_or(false)
        });
        all_fixed && sum > cell_inner_height
    };
    if !cell_has_diagonal && !fixed_ls_contradicts_declared {
        return false;
    }
    if !cell.paragraphs.iter().all(|p| p.line_segs.is_empty()) {
        return false;
    }
    let mut em_sum = 0.0f64;
    for p in &cell.paragraphs {
        let mut comp = compose_paragraph_in_context(p, styles);
        recompose_cell_lines_in_frame(
            &mut comp,
            p,
            // [#7422] 칸 내용 상자도 본문과 **같은** 문단 여백 계약을 쓴다. `#7410` 이
            // 편집 경로에서 통일한 계약이 이 재조합 경로에는 닿지 않아, 같은 문단이 어느
            // 경로로 왔느냐로 다른 상자를 받았다 — 칸 31 에서 프레임 폭이 한/글의 39208
            // 대신 40808 이 되어 줄마다 두 글자를 더 먹었다.
            ParagraphBox::content_for_style(
                cell_inner_width,
                styles.para_styles.get(p.para_shape_id as usize),
                dpi,
            ),
            styles,
            dpi,
            false,
        );
        if comp.lines.len() > 1 {
            return false;
        }
        if let Some(l) = comp.lines.first() {
            if estimate_composed_line_width(l, styles) > cell_inner_width * 0.85 {
                return false;
            }
            em_sum += l
                .runs
                .iter()
                .map(|r| {
                    styles
                        .char_styles
                        .get(r.char_style_id as usize)
                        .map(|cs| cs.font_size)
                        .unwrap_or(0.0)
                })
                .fold(0.0f64, f64::max);
        }
    }
    cell_inner_height >= em_sum
}

/// [#2291/#2287] 부실 저장 예외 — 기계생성 문서는 다줄 문단에도 저장 lineseg 를
/// 1개만 남기는 관례가 있어(연결맵 s5 244×10 r183 c8: 76자 문단 ls 1개 → 1줄
/// 렌더 + "…실천 계획 세" 절단), 셀 재래핑의 "저장 lineseg 신뢰" 가드가 이런
/// 문단의 텍스트를 segment_width 클립으로 절단한다. 저장 ls==1 이고 그 줄의
/// 추정 실폭이 셀 내폭을 명백히 초과(×1.05)하면 저장을 불신하고 fresh
/// 재래핑한다. **가로쓰기 셀 전용** — 세로쓰기 셀은 글자를 세로로 쌓아 가로
/// 실폭 판정이 무의미하므로 호출부(셀 방향을 아는 곳)에서 걸러야 한다
/// (task81 세로쓰기 회귀 실측). 정상 1줄(실폭 ≤ 내폭)은 불변.
///
/// [#5952] `※`/`☞` 유의사항 bullet의 저장 2~3줄이 한 줄로 합성되었고 각
/// `segment_width`가 셀 내폭과 같지만 합성 행이 ×1.10을 넘으면 분할을 복원한다.
/// [#6389] 이미 다중행인 결과에는 개입하지 않는다. 대체 글꼴의 추정 폭 차이를
/// 저장 줄 붕괴로 오인하면 정상 줄 경계를 파괴한다. 저장 정보의 유효성 판단은
/// 선행 프레임 경로, 보존한 줄의 폭 조정은 paragraph layout의 공통 경로가 맡는다.
pub fn recompose_stored_single_line_if_overflowing(
    composed: &mut ComposedParagraph,
    para: &Paragraph,
    cell_inner_width_px: f64,
    styles: &ResolvedStyleSet,
    dpi: f64,
) {
    recompose_stored_single_line_if_overflowing_cached(
        composed,
        para,
        cell_inner_width_px,
        styles,
        dpi,
        None,
    );
}

fn recompose_stored_single_line_if_overflowing_cached(
    composed: &mut ComposedParagraph,
    para: &Paragraph,
    cell_inner_width_px: f64,
    styles: &ResolvedStyleSet,
    dpi: f64,
    cache: Option<&SingleLineOverflowCache>,
) {
    if composed.lines.len() != 1 || cell_inner_width_px <= 0.0 {
        return;
    }
    let authentic_stored = !para.line_segs.is_empty()
        && para
            .line_segs
            .iter()
            .all(|seg| seg.tag & LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0);
    if authentic_stored && para.line_segs.len() >= 2 {
        let note_bullet = matches!(para.text.trim_start().chars().next(), Some('※' | '☞'));
        let short_note_cell = note_bullet
            && (2..=3).contains(&para.line_segs.len())
            && para.line_segs.iter().all(|seg| {
                seg.segment_width > 0
                    && (crate::renderer::hwpunit_to_px(seg.segment_width, dpi)
                        - cell_inner_width_px)
                        .abs()
                        <= 1.0
            });
        if !short_note_cell {
            return;
        }
        let over = composed
            .lines
            .iter()
            .any(|line| estimate_composed_line_width(line, styles) > cell_inner_width_px * 1.10);
        if over {
            reflow_cell_line_ignoring_stored_segs(composed, para, cell_inner_width_px, styles, dpi);
        }
        return;
    }
    let stored_single = para.line_segs.len() == 1 && authentic_stored;
    if !stored_single {
        return;
    }
    // [#2430] 발동 임계 ×1.05 는 측정(원패딩) vs 렌더(shrink패딩) 폭 발산(#2237)
    // 으로 살짝(1.05~1.35×) 초과한 정합 셀까지 거짓 재래핑해 줄수를 부풀리고
    // 쪽당 표 행 적재를 떨어뜨렸다(분할표 11건 과다분할 회귀). 본문 판
    // #2525 와 동일하게 ×1.8 로 좁혀 정당한 장평/자간·
    // 패딩 발산 범위(≤~1.5×)를 넘는 부실 저장만 재래핑한다. #2291 원 타깃
    // (76자 1-lineseg = ~7.6× 초과, 절단 해소)은 임계 위라 계속 재래핑.
    //
    // [#4149] 판정 memo — 같은 source paragraph와 셀 내폭이면 판정이 결정적
    // 인데, 페이지 트리 재빌드마다 estimate_composed_line_width 재측정이 반복돼
    // 거대 셀 문서의 캐럿 rect 질의당 ~30% 를 차지했다. 폭 키(f32 bits 패킹)로
    // 판정만 memo 하고(측정 생략), over=true 의 fresh 재래핑 자체는 매 빌드 그대로
    // 수행한다 — 재래핑 결과는 composed 에만 반영되고 저장 line_segs 는 안 바뀌므로
    // 재래핑을 생략하면 절단 렌더 회귀. cache는 renderer session이 소유하고
    // source/style mutation과 함께 session cache 전체를 비운다.
    let width_key = (cell_inner_width_px as f32).to_bits();
    let over = cache
        .and_then(|cache| cache.get(para, width_key))
        .unwrap_or_else(|| {
            let measured = composed
                .lines
                .first()
                .map(|line| estimate_composed_line_width(line, styles) > cell_inner_width_px * 1.8)
                .unwrap_or(false);
            if let Some(cache) = cache {
                cache.insert(para, width_key, measured);
            }
            measured
        });
    if std::env::var("RHWP_DIAG_CELLREWRAP").is_ok() && over {
        if let Some(l) = composed.lines.first() {
            for run in &l.runs {
                let ts = run.text_style(styles);
                eprintln!(
                    "DIAG_CELLREWRAP inner={:.1} fs={:.1} lsp={:.2} font={:?} w={:.1} text={:?}",
                    cell_inner_width_px,
                    ts.font_size,
                    ts.letter_spacing,
                    ts.font_family.split(',').next().unwrap_or(""),
                    estimate_text_width(effective_text_for_metrics(run), &ts),
                    effective_text_for_metrics(run)
                        .chars()
                        .take(10)
                        .collect::<String>(),
                );
            }
        }
    }
    if !over {
        return;
    }
    // [#6802] 넘친 것이 점 채움(리더)뿐이면 저장 한 줄이 옳다 — 한/글도 자른다.
    if composed
        .lines
        .first()
        .is_some_and(|line| line_overflow_is_leader_fill(line, styles, cell_inner_width_px))
    {
        return;
    }
    reflow_cell_line_ignoring_stored_segs(composed, para, cell_inner_width_px, styles, dpi);
}

/// 차례 점 채움(리더)에 쓰이는 문자. 마침표·가운뎃점 계열만 본다.
fn is_leader_char(c: char) -> bool {
    matches!(
        c,
        '.' | '\u{00B7}' | '\u{2024}' | '\u{2025}' | '\u{2026}' | '\u{2027}' | '\u{22EF}'
    )
}

/// 채움으로 인정하는 최소 연속 길이 — 문장의 마침표·말줄임표를 채움으로 오인하지 않는다.
const MIN_LEADER_RUN: usize = 4;

/// 판정과 출력이 같은 문자 구간을 사용한다. 인덱스는 Unicode scalar 기준이다.
fn leader_fill_spans(chars: &[char]) -> Vec<std::ops::Range<usize>> {
    let mut spans = Vec::new();
    let mut start = 0;
    while start < chars.len() {
        if !is_leader_char(chars[start]) {
            start += 1;
            continue;
        }
        let mut end = start + 1;
        while end < chars.len() && is_leader_char(chars[end]) {
            end += 1;
        }
        if end - start >= MIN_LEADER_RUN {
            spans.push(start..end);
        }
        start = end;
    }
    spans
}

/// [#6802] 저장 한 줄을 지킨 뒤, 상자를 넘는 **채움 글자만** 한/글처럼 잘라 낸다.
///
/// 한/글 2020 정본(`1400000-200600006` 2쪽)은 차례 줄을 한 줄로 두고 점을 상자 안에서
/// 끊는다 — 점이 쪽 번호 칸이나 용지 밖으로 이어지지 않는다. 자르는 것은 `display_text`
/// 뿐이라 `text`(문서 좌표·추출·편집)는 그대로 남는다. 채움이 아닌 글자는 건드리지 않는다.
fn trim_leader_fill_overflow(
    composed: &mut ComposedParagraph,
    inner_width_px: f64,
    styles: &ResolvedStyleSet,
) {
    if inner_width_px <= 0.0 {
        return;
    }
    for line in &mut composed.lines {
        let mut width = estimate_composed_line_width(line, styles);
        if width <= inner_width_px || !line_overflow_is_leader_fill(line, styles, inner_width_px) {
            continue;
        }
        for run_idx in (0..line.runs.len()).rev() {
            if width <= inner_width_px {
                break;
            }
            let style = line.runs[run_idx].text_style(styles);
            let run = &mut line.runs[run_idx];
            let mut chars: Vec<char> = effective_text_for_metrics(run).chars().collect();
            // 뒤쪽부터 처리하면 앞쪽 구간의 인덱스는 변하지 않는다.
            for span in leader_fill_spans(&chars).into_iter().rev() {
                if width <= inner_width_px {
                    break;
                }
                let current: String = chars.iter().collect();
                let current_width = estimate_text_width(&current, &style);
                let without = |drop: usize| -> String {
                    chars[..span.end - drop]
                        .iter()
                        .chain(&chars[span.end..])
                        .collect()
                };
                // 제목/쪽번호/다른 run은 그대로 두고 필요한 최소 채움만 줄인다.
                // 서로 다른 리더 글리프나 자간도 전체 run 재측정으로 반영한다.
                let mut low = 0;
                let mut high = span.len();
                while low < high {
                    let middle = (low + high) / 2;
                    let candidate_width = estimate_text_width(&without(middle), &style);
                    if width - current_width + candidate_width <= inner_width_px {
                        high = middle;
                    } else {
                        low = middle + 1;
                    }
                }
                let kept = without(low);
                width += estimate_text_width(&kept, &style) - current_width;
                chars.drain(span.end - low..span.end);
                run.display_text = Some(kept);
            }
        }
    }
}

/// [#6802] 점 채움(리더)만 넘치는 저장 한 줄은 **부실 저장이 아니다**.
///
/// 옛 차례 표는 제목 뒤를 점 문자로 직접 채워 한 줄을 만든다
/// (`1400000-200600006` 2쪽: `Ⅰ. 사업개요 ․․․․․…`, `․` = U+2024). 그 점 개수는
/// **한/글의 메트릭으로** 줄을 꽉 채우도록 정해져 있어서, 우리 추정 폭이 조금만 넓어도
/// 저장 한 줄이 셀 폭을 크게 넘는 것처럼 보인다. 그때 `#2291` 의 부실 저장 재래핑이
/// 발동하면 한 줄짜리 문단이 네 줄로 접히고, 뒤 문단들의 저장 `vertical_pos` 위에
/// 그대로 겹쳐 그려진다(그 문서: text-overlap 4건 · 표가 본문을 362.9px 초과).
///
/// 한/글은 그 줄을 한 줄로 두고 **넘치는 점을 자른다**. 채움 문자를 걷어낸 내용 폭이
/// 셀 안에 들어가면 저장 줄이 옳다고 보고 종전의 `segment_width` 클립에 맡긴다.
///
/// `#2291` 의 반례(`task2287` r183 c8: 점 없는 본문 76자가 저장 1줄)는 채움 런이 없어
/// 이 갈래를 타지 않는다 — 그쪽은 종전대로 재래핑한다.
pub(crate) fn line_overflow_is_leader_fill(
    line: &ComposedLine,
    styles: &ResolvedStyleSet,
    inner_width_px: f64,
) -> bool {
    fn strip_leader_runs(text: &str) -> (String, bool) {
        let mut chars: Vec<char> = text.chars().collect();
        let spans = leader_fill_spans(&chars);
        let found = !spans.is_empty();
        for span in spans.into_iter().rev() {
            chars.drain(span);
        }
        (chars.iter().collect(), found)
    }

    let mut found_leader = false;
    let mut content_width = 0.0f64;
    for run in &line.runs {
        let (kept, found) = strip_leader_runs(effective_text_for_metrics(run));
        found_leader |= found;
        if !kept.is_empty() {
            content_width += estimate_text_width(&kept, &run.text_style(styles));
        }
    }
    found_leader && content_width <= inner_width_px
}

fn reflow_cell_line_ignoring_stored_segs(
    composed: &mut ComposedParagraph,
    para: &Paragraph,
    cell_inner_width_px: f64,
    styles: &ResolvedStyleSet,
    dpi: f64,
) {
    // 저장 seg 를 일시적으로 무시하고 NO_LS 폴백과 동일 경로로 재분할한다.
    let mut para_no_ls = para.clone();
    para_no_ls.line_segs.clear();
    recompose_cell_lines_in_frame(
        composed,
        &para_no_ls,
        // [#7422] 위와 같은 계약. 저장 seg 를 무시하는 경로도 문단 여백을 뺀다.
        ParagraphBox::content_for_style(
            cell_inner_width_px,
            styles.para_styles.get(para.para_shape_id as usize),
            dpi,
        ),
        styles,
        dpi,
        false,
    );
}

/// 가로쓰기 셀의 렌더/측정 공통 재구성 경로.
///
/// `recompose_cell_lines_in_frame`만 적용하면 저장 다줄 문단이 실제로는 셀 폭을
/// 넘쳐 fresh 재래핑되는 경우(#5952)를 높이 계산이 놓칠 수 있다. 호출자는
/// 세로쓰기 셀을 이미 제외해야 한다.
pub(crate) fn recompose_horizontal_cell_lines_for_width(
    composed: &mut ComposedParagraph,
    para: &Paragraph,
    cell_inner_width_px: f64,
    styles: &ResolvedStyleSet,
    dpi: f64,
    legacy_hwp3_stored_geometry: bool,
    repair_stored_overflow: bool,
    overflow_cache: &SingleLineOverflowCache,
    cell_line_wrap: Option<u8>,
) {
    recompose_cell_lines_in_frame(
        composed,
        para,
        // [#7422] 위와 같은 계약. 렌더/측정 공통 경로도 문단 여백을 뺀다.
        ParagraphBox::content_for_style(
            cell_inner_width_px,
            styles.para_styles.get(para.para_shape_id as usize),
            dpi,
        ),
        styles,
        dpi,
        legacy_hwp3_stored_geometry,
    );
    // A bounded renderer-only correction. The source IR and original binary
    // records stay intact. BREAK is explicit; SQUEEZE/KEEP and unknown callers
    // cannot acquire this proof. Equal physical row metrics below prohibit a
    // local partition correction from changing a table/page flow allocation.
    let physical_box = ParagraphBox::content_for_style(
        cell_inner_width_px, styles.para_styles.get(para.para_shape_id as usize), dpi,
    );
    if cell_line_wrap == Some(0) // HWP/OWPML BREAK; 1=SQUEEZE, 2=KEEP
        && !legacy_hwp3_stored_geometry
        && line_breaking::owned_break_cell_row_overflows(para, &physical_box, styles)
    {
        let mut input = para.clone();
        input.line_segs.clear();
        let mut fresh = compose_paragraph_in_context(&input, styles);
        recompose_cell_lines_in_frame(&mut fresh, &input, physical_box, styles, dpi, false);
        let unchanged_physical_rows = fresh.lines.len() == para.line_segs.len()
            && fresh.lines.iter().zip(&para.line_segs).all(|(line, source)|
                line.line_height == source.line_height
                    && line.baseline_distance == source.baseline_distance
                    && line.segment_width == source.segment_width
                    && line.column_start == source.column_start);
        if unchanged_physical_rows {
            // Source vertical rows remain the placement owner. Only the text
            // partition changes; authored vertical spacing is never replaced
            // by the composer's estimated percent-to-integer spacing.
            for (line, source) in fresh.lines.iter_mut().zip(&para.line_segs) {
                line.line_spacing = source.line_spacing;
            }
            *composed = fresh;
        }
    }
    if repair_stored_overflow {
        recompose_stored_single_line_if_overflowing_cached(
            composed,
            para,
            cell_inner_width_px,
            styles,
            dpi,
            Some(overflow_cache),
        );
    }
}

/// [#2279] 저장 lineseg 분할의 실폭-과잉 판정 (본문 판, 줄수 무관).
///
/// 저장(비합성) 분할의 어떤 줄이든 추정 실폭이 단 내폭을 명백히(×1.05)
/// 초과하면 그 분할은 물리적으로 성립하지 않는 부실 저장이다 — 마스킹('*'
/// 치환) 결재문서는 원문 기준의 저장 분할을 남겨 실폭과 모순인 경우가 있고,
/// 한글은 항상 fresh 재계산하므로 더 많은 줄로 배치한다 (36392557 pi34
/// 실측: '*'×164 저장 2줄, 줄0 90자 ≈ 내폭 1.4× vs 한글 PDF 3줄 80/68/16).
/// [정밀화] 마스킹 문단('*' 비중 ≥ 50%) 한정 — 일반 텍스트 문단은 rhwp
/// 폭 추정 오차가 1.05×를 넘는 사례(prep_1790387/온새미로 실측 회귀)가
/// 있어 재래핑하지 않는다. 마스킹 치환은 원문과 글자폭이 달라지는 유일한
/// 물리적 근거가 있는 계열이다.
/// Whether stored rows are **stale** rather than merely unreproducible.
///
/// Mutation provenance is decisive: `Paragraph` marks its stored text
/// partition dirty whenever text or CharShapeRef inputs change. Geometry may
/// still match exactly after such an edit, but the old row boundaries cannot
/// be admitted. The width checks below remain a defensive import check for
/// malformed documents that arrived without local mutation provenance.
///
/// A stored row that cannot hold its own text is self-evidently wrong, and no
/// amount of authenticity rescues it: after a fill/replace the record still
/// describes the old text, and `#2525`'s `hwpx-02` p5 stores 135 characters on
/// one line statically. That is a different failure from a row we simply
/// cannot reproduce — missing 한양 metrics (#4779) — where the record is right
/// and our carve is wrong, and rebuilding makes things worse.
///
/// The test compares each row's measured text against **its own** stored
/// width, never against our carve, so it does not depend on reproducing HWP's
/// geometry and survives a wrong metric environment: a 4.5× overfill is not a
/// measurement disagreement.
///
/// One predicate, both consumers. `HeightMeasurer::measure_paragraph` passes a
/// composition **with runs**; the typeset path that reaches the frame can pass
/// one whose lines have `runs.len() == 0`, and `estimate_composed_line_width`
/// over no runs is ~0, so the 1.8× test cannot fire there. Splitting this into
/// two copies once disarmed the measurer silently while looking correct on the
/// frame side — the run-less compositions are empty paragraphs, which have no
/// text to overflow, so the asymmetry is invisible until a real overfull row
/// arrives at the wrong copy.
///
/// [#2525] 비마스킹 대형 과밀: 저장 lineseg 이 장평 반영 실폭
/// (`estimate_composed_line_width` 는 ts.ratio 를 자체 반영) 기준으로도 내폭을
/// 크게(≥1.8×) 초과하면, 정당한 장평/자간 압축 범위(최소 advance 클램프 0.5×
/// → 최대 ~2× 과밀)를 벗어난 부실 단일-저장 lineseg 다 (hwpx-02 p5: 135자 1줄
/// ≈4.5× 과밀). **이 경계는 추정이 아니라 압축 상한에서 나온 값이다** — 정당한
/// 장평 압축 문서는 ratio 반영 실폭이 내폭 이내라 오발동하지 않는다.
pub(crate) fn stored_rows_are_stale(
    composed: &ComposedParagraph,
    para: &Paragraph,
    inner_width_px: f64,
    styles: &ResolvedStyleSet,
) -> bool {
    if !para.line_segs.is_empty() && para.stored_text_partition_is_dirty() {
        return true;
    }
    let stored = !para.line_segs.is_empty()
        && para
            .line_segs
            .iter()
            .all(|seg| seg.tag & LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0);
    if !stored
        || composed.lines.is_empty()
        || inner_width_px <= 0.0
        || composed.lines.len() != para.line_segs.len()
    {
        return false;
    }
    // [#2525] 비마스킹 대형 과밀: 저장 lineseg 이 장평 반영 실폭
    // (estimate_composed_line_width 는 ts.ratio 를 자체 반영) 기준으로도 내폭을
    // 크게(≥1.8×) 초과하면, 정당한 장평/자간 압축 범위(최소 advance 클램프 0.5×
    // → 최대 ~2× 과밀)를 벗어난 부실 단일-저장 lineseg 다 (hwpx-02 p5: 135자
    // 1줄 ≈4.5× 과밀). **이 경계는 압축 상한에서 나온 값이지 맞춰 넣은 상수가
    // 아니다.** 빈 문단은 run 이 없어 이 판정이 발화하지 않는데, 폭을 넘길 텍스트
    // 자체가 없으므로 정상이다(전체 run-less 조합 8,345건 중 99.6%가 빈 문단).
    // [#6802] 넘친 것이 **점 채움(리더)** 뿐인 줄은 부실 저장이 아니다 — 옛 차례 표는
    // 제목 뒤를 점 문자로 직접 채워 한 줄을 만들고(`1400000-200600006` 2쪽:
    // `Ⅰ. 사업개요 ․․․․․…`), 그 점 개수는 한/글 메트릭 기준이라 우리 추정 폭에서는
    // 쉽게 1.8× 를 넘는다. 여기서 재래핑하면 저장이 한 줄로 둔 문단이 네 줄로 접혀
    // 뒤 문단들의 저장 `vertical_pos` 위에 겹쳐 그려진다(그 문서 2쪽 text-overlap 4건).
    // 한/글은 그 줄을 한 줄로 두고 넘치는 점을 자른다. 채움을 걷어낸 내용이 상자 안에
    // 들어갈 때만 저장을 믿는다 — `#2525`(hwpx-02 p5 135자)·`#2291`(task2287 r183c8
    // 76자)처럼 채움 없이 넘치는 줄은 종전대로 부실 저장이다.
    if composed.lines.iter().any(|l| {
        estimate_composed_line_width(l, styles) > inner_width_px * 1.8
            && !line_overflow_is_leader_fill(l, styles, inner_width_px)
    }) {
        return true;
    }
    if stored_rows_underfill_inside_token(composed, para, inner_width_px, styles) {
        return true;
    }
    // [#6102] **비말미** 저장 줄의 과밀: 이어지는 줄이 있는데도 자기 폭(저장
    // segment_width 와 내폭 둘 다)을 넘는 텍스트를 담았다고 주장하는 줄은
    // 물리적으로 성립하지 않는다 — 한글은 줄을 다 채우기 **전에** 끊는다.
    // 결재문서본문 계열(36360328 외 2건)의 저장 textpos 축이 파서 보정폭과
    // 어긋나 첫 줄이 6자 늦게 끊기고 본문 우단을 71~99px 넘던 결함의 관측식.
    // 0.5× advance 클램프 마스킹 코호트(#2525)는 **단일 줄**이라 비말미 조건에
    // 걸리지 않고, 말미 줄은 초과분이 다음 줄로 갈 수 없으므로 제외한다.
    // 여유는 6% + 12px — 정당한 Justify 줄은 말미 공백 overhang(≤반각 한 칸)
    // 까지 포함해도 이 밑에 있다.
    //
    // **범위는 자리차지 표 host 문단 한정** — 종전에 프레임 소유자가 아예 없던
    // 계보라 이 판정에 기대던 기존 핀이 없다. 일반 문단까지 넓히면 확정된
    // 쪽수 핀 5건(#2006/#3930/#3931/#2559/#5801)이 흔들린다(전량 게이트 실측).
    if !para.controls.iter().any(|c| {
        matches!(c, crate::model::control::Control::Table(t)
            if !t.common.treat_as_char
                && matches!(t.common.text_wrap, crate::model::shape::TextWrap::TopAndBottom))
    }) {
        return false;
    }
    let non_last_overfull = |line: &ComposedLine, seg: &crate::model::paragraph::LineSeg| {
        let est = estimate_composed_line_width(line, styles);
        let seg_width_px = crate::renderer::hwpunit_to_px(seg.segment_width, 96.0);
        est > inner_width_px * 1.06 + 12.0 && est > seg_width_px * 1.06 + 12.0
    };
    composed
        .lines
        .iter()
        .zip(para.line_segs.iter())
        .take(composed.lines.len().saturating_sub(1))
        .any(|(line, seg)| non_last_overfull(line, seg))
}

/// [#7416] 저장 줄 사다리가 **제 선언 폭과 모순되는** 과소충전.
///
/// `#6102` 의 과밀(줄이 제 폭보다 많이 담았다)과 대칭인 쪽이다. 비말미 저장 줄이
///
/// 1. **어절 안**에서 끊겼고(앞 줄 끝 글자와 다음 줄 첫 글자가 모두 한글 음절),
/// 2. 줄에 **공백이 없고**,
/// 3. 문단이 **늘려 채우는 정렬**(양쪽·배분·나눔)이 아니며,
/// 4. 그 줄의 측정 폭 뒤에 **평균 글자 두 개 이상**이 더 들어갈 자리가 선언
///    `segment_width`(문단 들여쓰기/내어쓰기를 줄별로 뺀 값)에 남아 있으면,
///
/// 단, 선언 폭이 그 줄이 실제로 놓인 상자(`inner_width_px`)보다 넓으면 판정하지 않는다.
/// 그때 선언은 줄 나눔이 쓴 폭이 아니라서(좁은 칸 안의 줄에 쪽 폭을 적은 사다리)
/// «제 폭에 비해 남겼다» 는 비교 자체가 성립하지 않는다.
///
/// 그 사다리는 «다음 글자가 안 들어가서 끊었다» 는 줄 나눔의 유일한 이유와
/// 모순된다. 어절 줄바꿈이 아니므로 줄 나눔 규칙이 끊을 까닭이 없고, 늘릴 공백도
/// 정렬도 없으므로 자연 폭이 곧 배치 폭이다.
///
/// 비교 대상은 **그 줄 자신의 선언 폭**이지 우리 carve 가 아니다 — 위 과밀 판정과
/// 같은 이유로 우리 상자 재현에 기대지 않는다.
///
/// 문턱 2.0 은 맞춘 값이 아니라 `samples/**` 1,148건 전수에서 난 틈이다
/// (2026-09-25, `#7416` 코멘트). 조건 1~3 을 만족하는 한/글 저장본(`lastSavedWith`
/// 가 한컴인 1,044건)의 줄 316개는 여유가 최대 1.94글자이고, 2.0 이상은 한 줄도 없다.
/// 2.0 이상인 문서는 4건뿐이고 전부 저장 계보가 없다. 같은 원본을 한/글이 다시 저장한
/// 쌍둥이(`issue6639-hancom-160.hwpx`)는 같은 `horzsize` 로 포화(0.7글자 남김)라
/// 한 줄도 걸리지 않는다. 한/글은 이 원본의 사다리를 쓰지 않는다 — 사다리를 지운
/// 입력과 원본의 한/글 PDF 가 화소 단위로 같다.
///
/// 양쪽 정렬을 빼는 이유: 공백을 늘려 줄을 선언 폭까지 채우므로 자연 폭 비교가
/// 성립하지 않는다(종전 census 발화 줄의 99.8% 가 양쪽 정렬이었다).
fn stored_rows_underfill_inside_token(
    composed: &ComposedParagraph,
    para: &Paragraph,
    inner_width_px: f64,
    styles: &ResolvedStyleSet,
) -> bool {
    use crate::model::style::Alignment;
    const MIN_SPARE_CHARS: f64 = 2.0;

    if composed.lines.len() < 2 {
        return false;
    }
    let Some(para_style) = styles.para_styles.get(para.para_shape_id as usize) else {
        return false;
    };
    if matches!(
        para_style.alignment,
        Alignment::Justify | Alignment::Distribute | Alignment::Split
    ) {
        return false;
    }
    let is_syllable = |c: char| ('\u{ac00}'..='\u{d7a3}').contains(&c);
    let line_text =
        |line: &ComposedLine| -> String { line.runs.iter().map(|run| run.text.as_str()).collect() };
    // 글자 폭에 잡히지 않는 개체·각주·탭이 줄 안에 있으면 자연 폭을 잴 수 없다.
    let has_opaque_inline = |start: usize, end: usize| {
        composed
            .tac_controls
            .iter()
            .any(|&(pos, _, _)| (start..end).contains(&pos))
            || composed
                .footnote_positions
                .iter()
                .any(|&(pos, _, _)| (start..end).contains(&pos))
    };
    let first_line_indent = para_style.indent.max(0.0);
    let hanging_indent = (-para_style.indent).max(0.0);

    composed
        .lines
        .windows(2)
        .zip(para.line_segs.iter())
        .enumerate()
        .any(|(idx, (pair, seg))| {
            let (line, next) = (&pair[0], &pair[1]);
            if line.has_line_break {
                return false;
            }
            let text = line_text(line);
            let next_text = line_text(next);
            let nchars = text.chars().count();
            if nchars == 0
                || text.chars().any(|c| c.is_whitespace())
                || !text.chars().last().is_some_and(is_syllable)
                || !next_text.chars().next().is_some_and(is_syllable)
                || has_opaque_inline(line.char_start, next.char_start)
            {
                return false;
            }
            let used = estimate_composed_line_width(line, styles);
            if used <= 0.0 {
                return false;
            }
            let indent = if idx == 0 {
                first_line_indent
            } else {
                hanging_indent
            };
            let seg_width_px = hwpunit_to_px(seg.segment_width, 96.0);
            // 선언 폭이 그 줄이 실제로 놓인 상자보다 넓으면 «제 폭» 이라는 전제가 서지
            // 않는다 — 그 값은 줄 나눔이 쓴 폭이 아니다(좁은 칸 안의 줄에 쪽 폭을 적은
            // 사다리가 있다). 상자와 어긋난 선언은 이 판정의 대상이 아니다.
            if seg_width_px > inner_width_px + 1.0 {
                return false;
            }
            let declared = seg_width_px - indent;
            let avg_char = used / nchars as f64;
            declared - used >= avg_char * MIN_SPARE_CHARS
        })
}

/// Resolve a paragraph's rows through the physical frame its own geometry
/// produces — on the stored route as well as the fresh one.
///
/// The caller states its coordinate system by handing a [`ParagraphBox`], and
/// that is what lets one owner serve both flows: a body paragraph arrives on
/// [`ParagraphBox::body`], the same expression the edit path builds in
/// `DocumentCore::reflow_paragraph`, and a cell paragraph arrives on
/// [`ParagraphBox::content_width_px`] via [`recompose_cell_lines_in_frame`]. One
/// paragraph must not get two boxes depending on which route reached it, and
/// sharing the constructors is what keeps that true — the body pair used to be
/// two copies of the same expression, and the cell had no box at all.
///
/// The frame models the column box and its declared exclusions and nothing
/// else — a float anchored in a different paragraph is not in `para.controls`
/// and so never reaches its exclusion list (see the exclusion-provenance note
/// in the report for #4755's deferred scope). Paragraphs whose controls have
/// their own layout owner keep the established #2279 owner below.
pub(crate) fn recompose_stored_lines_in_frame(
    composed: &ComposedParagraph,
    para: &Paragraph,
    paragraph_box: ParagraphBox,
    inner_width_px: f64,
    styles: &ResolvedStyleSet,
    dpi: f64,
    legacy_hwp3_stored_geometry: bool,
    miss_policy: line_breaking::StoredRowMissPolicy,
    // [#6175] 같은 세로 band의 용지/쪽 기준 어울림 개체 증거(HWPUNIT) — 저장 행이
    // 남긴 결손 폭과 위치를 함께 설명할 때만 재래핑하지 않는다. 측정·페인트가 같은
    // 함수를 타므로 두 경로가 갈리지 않는다.
    float_carve_evidence: &[crate::renderer::float_placement::FloatCarveEvidence],
) -> Option<ComposedParagraph> {
    recompose_stored_lines_in_frame_with_known_square_band(
        composed,
        para,
        paragraph_box,
        inner_width_px,
        styles,
        dpi,
        legacy_hwp3_stored_geometry,
        miss_policy,
        float_carve_evidence,
        false,
        false,
    )
}

/// Resolve stored rows when the caller has already proven that the paragraph
/// belongs to a non-TAC Square Picture/Shape wrap band.
///
/// A uniformly narrow stored ladder is not generally float evidence: ordinary
/// paragraph indentation has the same local shape. Only the pagination and
/// render paths that carry a real Square-wrap anchor may preserve that ladder
/// as externally owned geometry.
#[allow(clippy::too_many_arguments)]
pub(crate) fn recompose_stored_lines_in_frame_with_known_square_band(
    composed: &ComposedParagraph,
    para: &Paragraph,
    paragraph_box: ParagraphBox,
    inner_width_px: f64,
    styles: &ResolvedStyleSet,
    dpi: f64,
    legacy_hwp3_stored_geometry: bool,
    miss_policy: line_breaking::StoredRowMissPolicy,
    // [#6175] 용지/쪽 기준 float 증거는 uniform ladder의 결손 폭과 세로 band를
    // 함께 설명할 때만 저장 기하를 유지한다.
    float_carve_evidence: &[crate::renderer::float_placement::FloatCarveEvidence],
    known_square_band: bool,
    hwpx_stored_layout: bool,
) -> Option<ComposedParagraph> {
    // A degenerate box, or controls with their own layout owner, means there is
    // no frame to build. The composition stands as it is — there is no second
    // owner to hand it to.
    //
    // NO_LS 문단은 예외적으로 picture-band 게이트(비-TAC 그림 1개)도 허용한다 —
    // 저장 행이 없어 fill 이 유일한 소유자인데, Square 그림 host 라는 이유로
    // 여기서 사양하면 45자 합성 줄바꿈이 그대로 남아 감폭된 상자 폭을 넘는다
    // (아이콘 옆 설명 한 줄이 열 밖까지 이어지는 형상). 저장 행이 있는 문단의
    // 소유권 계약은 종전대로 본문 게이트만 통과한다.
    let has_kopub_face = para.char_shapes.iter().any(|reference| {
        styles
            .char_styles
            .get(reference.char_shape_id as usize)
            .is_some_and(|style| {
                style.font_families.iter().any(|face| {
                    face.contains("KoPub돋움체")
                        || face.contains("KoPub바탕체")
                        || face.to_lowercase().contains("kopub dotum")
                        || face.to_lowercase().contains("kopub batang")
                })
            })
    });
    let justified_kopub = hwpx_stored_layout
        && has_kopub_face
        && styles
            .para_styles
            .get(para.para_shape_id as usize)
            .is_some_and(|style| style.alignment == crate::model::style::Alignment::Justify);
    let justified_kopub_picture = justified_kopub
        && para.controls.iter().any(|control| {
            matches!(control, crate::model::control::Control::Picture(picture)
                if picture.common.treat_as_char)
        });
    let frame_admits_controls = line_breaking::supports_cached_body_frame_controls(para)
        || (justified_kopub_picture
            && para.controls.iter().all(|control| {
                matches!(control, crate::model::control::Control::Picture(picture)
                    if picture.common.treat_as_char)
            }))
        || (crate::renderer::para_has_no_stored_line_segs(para)
            && (known_square_band
                || para.controls.iter().any(|control| {
                    matches!(control, crate::model::control::Control::Picture(picture)
                    if !picture.common.treat_as_char
                    && picture.common.text_wrap == crate::model::shape::TextWrap::Square)
                }))
            && line_breaking::supports_picture_band_frame_controls(para))
        // [#7160] 글자처럼 취급 **표** host 도 프레임이 받는다 — `inline_control_size_hwp` 가
        // 그 폭을 인라인 토큰으로 계상하므로 그림과 같은 축이다. 글자 없는 host 는 제외한다:
        // 줄을 나눌 글자가 없고 표 자리 계약은 다른 경로가 갖는다.
        || (para.text.chars().any(|c| !c.is_whitespace())
            && line_breaking::supports_tac_table_band_frame_controls(para));
    if !paragraph_box.is_usable() || !frame_admits_controls {
        return None;
    }

    // 저장 원점 복원은 측정·배치와 읽기 전용 증거 프로브가 같은 상자를 사용한다.
    let paragraph_box = paragraph_box.for_stored_body_rows(para);
    let mut frame = paragraph_box.frame(
        para.line_segs
            .first()
            .map(|segment| segment.vertical_pos)
            .unwrap_or(0),
    );
    frame.kopub_justified_space = justified_kopub_picture;
    // 새로 채운 줄이 짧아졌다는 이유만으로 정상 저장 분할을 무효화하지 않는다.
    // 마지막 자동 줄바꿈 때문에 한글 어절의 나머지만 마지막 줄에 남고,
    // 이 프레임에서 앞부분과 다시 합칠 수 있는 경우에만 보정한다.
    // 완결된 마지막 어절이나 여러 어절은 저장된 경계를 유지한다.
    let rejoinable_word_tail = justified_kopub_picture
        && para.line_segs.len() > 1
        && !para.text.contains('\n')
        && !para.stored_text_partition_is_dirty()
        && !frame.models_exclusions()
        && {
            let chars: Vec<_> = para.text.chars().collect();
            let (start, _) = utf16_range_to_text_range(
                &para.char_offsets,
                para.line_seg_text_start(para.line_segs.len() - 1),
                u32::MAX,
                chars.len(),
            );
            let is_syllable = |c: char| ('\u{ac00}'..='\u{d7a3}').contains(&c);
            start > 0
                && start < chars.len()
                && is_syllable(chars[start - 1])
                && chars[start..].iter().copied().all(is_syllable)
        }
        && {
            let mut probe = frame.clone();
            let mut input = para.clone();
            input.line_segs.clear();
            line_breaking::layout_paragraph_in_frame(&input, &mut probe, styles, dpi)
                .is_some_and(|rows| rows.len() < para.line_segs.len())
        };
    let stale = rejoinable_word_tail
        || stored_rows_are_stale(composed, para, inner_width_px, styles)
        || line_breaking::remeasured_equation_start_row(para).is_some();
    match line_breaking::resolve_stored_line_segs_in_frame(
        para,
        &mut frame,
        styles,
        dpi,
        legacy_hwp3_stored_geometry,
        miss_policy,
        stale,
        float_carve_evidence,
        known_square_band,
    ) {
        // Stale — the row cannot hold its own text — so the rebuilt row is the
        // frame's. Its fill tokenizes through `para.char_shapes`
        // (`line_breaking.rs`), which is the char-shape re-splitting #2632
        // needed, so there is nothing the retired #2525 owner did that the
        // frame does not.
        Some(line_breaking::StoredRowResolution::Reflowed) => {
            // The frame holds the rows; `project_line_segs` is the one place
            // they become `LineSeg` again.
            let mut reflowed_para = para.clone();
            reflowed_para.replace_line_segs_with_space_metrics(
                frame.project_line_segs(),
                frame.project_space_metrics(),
            );
            // [#6102] 프레임이 새로 새긴 행 경계는 이미 HWP5 문단 축이다 —
            // 원본의 [#5961] 보정폭을 물려받으면 fresh 경계가 이중 보정되어
            // 줄이 보정폭만큼 늦게 끊긴다(36360328: fill 이 char 51(=raw 83)에
            // 끊었는데 +8 재보정으로 59가 되어 첫 줄이 우단 밖 +75px).
            reflowed_para.hwpx_axis_shift = 0;
            let mut reflowed = compose_paragraph_in_context(&reflowed_para, styles);
            preserve_context_resolved_runs(composed, &mut reflowed);
            // 부분 재조판 앞행은 원래 저장 축과 이미 해석한 줄 소유를 보존한다.
            // HWPX의 저장 축 보정을 새 HWP5 축의 뒤쪽에 다시 적용하지 않는다.
            if let Some(prefix_len) = line_breaking::remeasured_equation_start_row(para) {
                if prefix_len <= composed.lines.len() && prefix_len <= reflowed.lines.len() {
                    reflowed.lines[..prefix_len].clone_from_slice(&composed.lines[..prefix_len]);
                }
            }
            let mut reconciled = composed.clone();
            reconciled.lines = reflowed.lines;
            // Q2-D5-N1: source NO_LS has no usable width during the initial
            // composition handoff. The physical frame is the first owner that
            // knows the final intervals, so prepare Q2-C again only after that
            // partition is complete. Stored-row D4 outcomes stay untouched.
            if crate::renderer::para_has_no_stored_line_segs(para) {
                reconciled.horizontal_shaping =
                    line_breaking::compose_horizontal_shaping_handoff(para, &reconciled, styles);
            }
            Some(reconciled)
        }
        // `Stored`: returning the composition unchanged is the answer, not a
        // gap. The frame has already reproduced the stored physical-row key
        // exactly. The metrics lane remains deliberately unpublished
        // (§1.4.1's accept-arm write-back — see
        // `StoredRowResolution::Stored` and `LayoutFrame::try_admit_stored_rows`
        // for the measurement). `None`: the paragraph's controls have their own
        // layout owner and no frame was ever built for it.
        other => None,
    }
}

/// Read-only projection of the production stored-row cache decision.
///
/// Evidence queries use this entry instead of inferring validity from the mere
/// presence of `LineSeg` records. The probe owns an isolated composition and
/// frame, so it cannot publish rows or mutate the document. `Unmodelled` is a
/// first-class answer: legacy origins, externally-owned wrap geometry and
/// unsupported controls must not be mislabeled as cache rejection.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum StoredRowProbeDisposition {
    Admitted,
    Rejected,
    Unmodelled,
    NotApplicable,
}

impl StoredRowProbeDisposition {
    pub(crate) const fn as_str(self) -> &'static str {
        match self {
            Self::Admitted => "admitted",
            Self::Rejected => "rejected",
            Self::Unmodelled => "unmodelled",
            Self::NotApplicable => "notApplicable",
        }
    }
}

pub(crate) fn probe_stored_row_disposition(
    para: &Paragraph,
    paragraph_box: ParagraphBox,
    styles: &ResolvedStyleSet,
    dpi: f64,
    legacy_hwp3_stored_geometry: bool,
    miss_policy: line_breaking::StoredRowMissPolicy,
) -> StoredRowProbeDisposition {
    let has_authoritative_rows = !para.line_segs.is_empty()
        && !para
            .line_segs
            .iter()
            .all(|segment| segment.tag & LineSeg::TAG_IMPLEMENTATION_PROPERTY != 0);
    if !has_authoritative_rows {
        return StoredRowProbeDisposition::NotApplicable;
    }
    if !paragraph_box.is_usable() {
        return StoredRowProbeDisposition::Unmodelled;
    }

    let composed = compose_paragraph_in_context(para, styles);
    let inner_width_px = paragraph_box.width_px(dpi);
    let stale = stored_rows_are_stale(&composed, para, inner_width_px, styles);
    // 저장 원점 복원은 측정·배치와 읽기 전용 증거 프로브가 같은 상자를 사용한다.
    let paragraph_box = paragraph_box.for_stored_body_rows(para);
    let mut frame = paragraph_box.frame(
        para.line_segs
            .first()
            .map(|segment| segment.vertical_pos)
            .unwrap_or(0),
    );
    match line_breaking::resolve_stored_line_segs_in_frame(
        para,
        &mut frame,
        styles,
        dpi,
        legacy_hwp3_stored_geometry,
        miss_policy,
        stale,
        // 증거 프로브는 단 문맥을 갖지 않는다 — 개체 증거 없이 판정한다.
        &[],
        false,
    ) {
        Some(line_breaking::StoredRowResolution::Stored) => StoredRowProbeDisposition::Admitted,
        Some(line_breaking::StoredRowResolution::Reflowed) => StoredRowProbeDisposition::Rejected,
        None => StoredRowProbeDisposition::Unmodelled,
    }
}

/// Project context-resolved source runs onto Frame-computed line boundaries.
///
/// Header/footer fields and other model-one/display-many runs keep the marker in
/// `text` and the rendered value in `display_text`. Re-composing from `Paragraph`
/// alone cannot recreate document context such as the current filename or page
/// number, so a strict Frame reflow owns only the partition and row metrics; it
/// must not erase the already-resolved run payload.
fn preserve_context_resolved_runs(source: &ComposedParagraph, reflowed: &mut ComposedParagraph) {
    struct RunSpan<'a> {
        start: usize,
        end: usize,
        run: &'a ComposedTextRun,
    }

    fn projected_display(
        run: &ComposedTextRun,
        take_start: usize,
        take_end: usize,
    ) -> Option<String> {
        let display = run.display_text.as_ref()?;
        let model_len = run.text.chars().count();
        if take_start == 0 && take_end == model_len {
            return Some(display.clone());
        }
        if display.chars().count() == model_len {
            return Some(
                display
                    .chars()
                    .skip(take_start)
                    .take(take_end - take_start)
                    .collect(),
            );
        }

        let text: String = run
            .text
            .chars()
            .skip(take_start)
            .take(take_end - take_start)
            .collect();
        let expanded = expand_pua_display_text(&text);
        (expanded != text).then_some(expanded)
    }

    // Only these payloads are owned by the already context-resolved source.
    // Style and language partitions remain the Frame composition's property.
    let mut context_spans = Vec::new();
    for line in &source.lines {
        let mut start = line.char_start;
        for run in &line.runs {
            let end = start.saturating_add(run.text.chars().count());
            if run.display_text.is_some()
                || run.footnote_marker.is_some()
                || run.char_overlap.is_some()
            {
                context_spans.push(RunSpan { start, end, run });
            }
            start = end;
        }
    }
    if context_spans.is_empty() {
        return;
    }

    for line in &mut reflowed.lines {
        let mut run_start = line.char_start;
        let mut overlaid = Vec::new();
        for run in std::mem::take(&mut line.runs) {
            let run_len = run.text.chars().count();
            let run_end = run_start.saturating_add(run_len);
            let overlapping: Vec<_> = context_spans
                .iter()
                .filter(|span| span.start < run_end && run_start < span.end)
                .collect();
            if overlapping.is_empty() {
                overlaid.push(run);
                run_start = run_end;
                continue;
            }

            let mut cuts = vec![run_start, run_end];
            for span in &overlapping {
                cuts.push(run_start.max(span.start));
                cuts.push(run_end.min(span.end));
            }
            cuts.sort_unstable();
            cuts.dedup();

            for bounds in cuts.windows(2) {
                let piece_start = bounds[0];
                let piece_end = bounds[1];
                if piece_start == piece_end {
                    continue;
                }

                let take_start = piece_start - run_start;
                let take_end = piece_end - run_start;
                let mut piece = run.clone();
                piece.text = run
                    .text
                    .chars()
                    .skip(take_start)
                    .take(take_end - take_start)
                    .collect();
                piece.display_text = projected_display(&run, take_start, take_end);
                if take_start != 0 || take_end != run_len {
                    piece.footnote_marker = None;
                    piece.char_overlap = None;
                }

                if let Some(span) = overlapping
                    .iter()
                    .find(|span| span.start <= piece_start && piece_end <= span.end)
                {
                    let source_start = piece_start - span.start;
                    let source_end = piece_end - span.start;
                    piece.display_text = projected_display(span.run, source_start, source_end);
                    let owns_whole_payload = piece_start == span.start && piece_end == span.end;
                    piece.footnote_marker = owns_whole_payload
                        .then_some(span.run.footnote_marker)
                        .flatten();
                    piece.char_overlap = owns_whole_payload
                        .then(|| span.run.char_overlap.clone())
                        .flatten();
                }
                overlaid.push(piece);
            }
            run_start = run_end;
        }
        line.runs = overlaid;
    }
}

/// The cell's rebuild, resolved through the physical frame.
///
/// This is not the cell twin of the retired body owner. Every authentic
/// partition enters the shared Frame resolver: an exact cell-box match stays
/// stored, while changed geometry or mutation-dirty text falls through to
/// reflow. NO_LS takes the same owner directly. Both body and cell state a
/// [`ParagraphBox`] instead of passing a bare width.
///
/// Cells are frames. §2.10 item 3 proves it exhaustively: enumerating all 2,057
/// RTTI object locators, only three `CHwpList` subclasses return non-zero from
/// `vtable+8`, and `CHwpCell` is not one of them — so **every** nested flow
/// (cell, note, text box, caption) runs the same generic engine on the stack,
/// re-entrantly. §2.13 fixes what that frame looks like: a cell's rect is
/// cell-local, `left = 0`, `width = engine+0x40 = entry+0x10 − (marginLeft +
/// marginRight)`. That is exactly [`ParagraphBox::content`] over
/// `0..cell_inner_width`, which every call site now builds with
/// [`ParagraphBox::content_width_px`], and it is why the content arm takes no
/// geometry pitch (§2.10 item 5: for a nested list `ConfigureFrameBounds`
/// returns straight after setting the rect — the column-continuation state is
/// body-only).
///
/// The retired width-based rebuild is gone rather than kept beside this. It was
/// load-bearing for 15 behaviours and the frame reproduces **12** of them.
/// Three oracles were disturbed, not one, and they were not disturbed the same
/// way — an earlier revision of this note said "14 of 15" and described all
/// three as re-pinned, which the tests contradict:
///
/// - `issue_2308_saved_nested_width_keeps_fragment_geometry` — re-pinned to
///   this path's values, PDF row counts in its comment. The authority PDF
///   adjudicates **against the retired path**.
/// - `issue_2308_short_rowbreak_child_wraps_where_the_authority_pdf_wraps` —
///   `#[ignore]`d. The PDF adjudicates **against this path**: the frame carries
///   `를` onto p81 with 210 HWPUNIT (0.55% of the box) of headroom, and the
///   retired path landed on the PDF's break only because `char_shapes[0]`
///   blindness inflated the row by 585 HWPUNIT. The residual is recorded with
///   its operands rather than re-pinned. Its sibling
///   `issue_2308_short_rowbreak_child_uses_owner_content_box_only` holds the
///   part this path does satisfy and **runs**.
/// - `issue_2279_nested_cell_units_split_r27_not_r26` — `#[ignore]`d, and
///   **not** re-pinned. The adjudication is split here: the PDF prints that
///   cell as 4 lines, so it backs *this* path's row height and the retired
///   path's 5-line measure was wrong — but the page-cut expectation the pin
///   asserts was standing on that wrong measure, and is itself PDF-correct.
///   Removing the compensating error exposes an upstream difference that is
///   #2279/#2308's to answer, so the pin stays as written and waits.
///
/// Measured with the suite at 5986/0 when the routing landed.
///
/// **What this changes, and the one thing it costs.** `compose_lines`' NO_LS
/// fallback emits one run at `char_shapes[0]`, so the retired rebuild measured
/// and painted every character of a paragraph with the *first* char shape. The
/// frame's fill tokenizes through `para.char_shapes` instead. On
/// `76076_regulatory_analysis.hwp` p81 (`구내운반차` short RowBreak child, box
/// 38245 HWPUNIT) the shapes are all 13.0pt but differ in **letter spacing**, so
/// the body glyphs advance 1261 where `char_shapes[0]` advances 1300. Measured
/// at the decisive tokens:
///
/// ```text
/// 를   pen 36735  glyph 1261 (fit 1300)  sum 38035  over  −210  → accepted
/// 예   pen 38673  glyph 1208 (fit 1299)  sum 39972  over +1727  → refused
/// ```
///
/// The HWP 2024 PDF breaks before `를`; this path carries it onto p81 with 210
/// HWPUNIT — 2.8px, **0.55% of the box** — of headroom. The retired path landed
/// on the PDF's break only by accident: measuring the row's 15 맑은 고딕 glyphs
/// at 1300 instead of 1261 adds 585 HWPUNIT, which is what pushed `를` over. A
/// 0.55% width-estimation residual is not something the retired path knew; that
/// is why the oracle is marked with its operands rather than re-pinned.
pub fn recompose_cell_lines_in_frame(
    composed: &mut ComposedParagraph,
    para: &Paragraph,
    cell_box: ParagraphBox,
    styles: &ResolvedStyleSet,
    dpi: f64,
    legacy_hwp3_stored_geometry: bool,
) {
    let has_synthetic_line_segs = !para.line_segs.is_empty()
        && para
            .line_segs
            .iter()
            .all(|seg| seg.tag & LineSeg::TAG_IMPLEMENTATION_PROPERTY != 0);
    let has_authoritative_line_segs = !para.line_segs.is_empty() && !has_synthetic_line_segs;
    if para.line_segs.len() >= 2
        && has_synthetic_line_segs
        && !para.stored_text_partition_is_dirty()
    {
        // HWPX 로드 단계에서 셀 폭/높이/anchor 속성으로 합성한 lineSeg 경계는
        // 이미 문서 속성 기반 보정 결과다. 여기서 다시 폭 기준으로 합치고
        // 재분할하면 RowBreak 표의 쪽 나눔 기준 줄 수가 원본 세로 정보와 어긋난다.
        return;
    }
    if composed.lines.is_empty() || !cell_box.is_usable() {
        return;
    }

    let inner_width_px = cell_box.width_px(dpi);
    let rebuilt = if has_authoritative_line_segs {
        // Authentic rows use the same exact cache key as body rows. A clean
        // match returns Stored without rebuilding; changed cell geometry or a
        // mutation-dirty text partition falls through to Frame reflow.
        recompose_stored_lines_in_frame(
            composed,
            para,
            cell_box,
            inner_width_px,
            styles,
            dpi,
            legacy_hwp3_stored_geometry,
            line_breaking::StoredRowMissPolicy::UnmodelledUnlessStale,
            // 셀 줄의 어울림 배제는 #5818 셀 계약이 따로 소유한다.
            &[],
        )
    } else {
        // NO_LS is the arm this owner normally serves. A synthetic single row
        // is not a source record to reproduce, so clear it on an isolated copy.
        let mut rebuild_input = para.clone();
        rebuild_input.line_segs.clear();
        recompose_stored_lines_in_frame(
            composed,
            &rebuild_input,
            cell_box,
            inner_width_px,
            styles,
            dpi,
            legacy_hwp3_stored_geometry,
            line_breaking::StoredRowMissPolicy::Reflow,
            &[],
        )
    };
    if let Some(rebuilt) = rebuilt {
        *composed = rebuilt;
    }
    // [#6802] 저장 한 줄을 지킨 줄의 넘치는 채움(리더)은 여기서 끊는다 — 측정(높이)과
    // 배치(페인트)가 같은 이 함수를 타므로 두 경로가 같은 줄을 본다.
    if has_authoritative_line_segs && !para.stored_text_partition_is_dirty() {
        trim_leader_fill_overflow(composed, inner_width_px, styles);
    }
}

/// 저장 `LINE_SEG`가 없는 들여쓴 셀 문단의 구간별 자간을 안전하게
/// 복원할 수 있는지 판정한다.
///
/// 셀 fallback은 역사적으로 첫 글자모양 하나로 재조판한다. 서로 다른 글꼴 크기까지
/// 일괄 복원하면 검증된 legacy pagination이 바뀌므로, 폭을 결정하는 글꼴·크기·장평은
/// 같고 자간만 달라지는 문단에 한해 실제 `CharShapeRef` 경계를 사용한다.
///
/// 추가로 문단 머리가 둘 이상의 literal ASCII 공백인 경우로 한정한다.
/// 이 형식은 한컴이 반각 들여쓰기 칸과 구간별 음수 자간을 줄 채움에
/// 함께 반영하는 native HWP5 장문 셀이다(#3128). 반면 글머리 문자로
/// 시작하는 짧은 child는 기존 owner-content-box 폭 계약을 계속 사용한다
/// (76076 p81→p82 `사고` / `를 예방…`).
pub(crate) fn missing_lineseg_indented_cell_has_uniform_metrics_with_tracking(
    para: &Paragraph,
    styles: &ResolvedStyleSet,
) -> bool {
    if !para.line_segs.is_empty()
        || para.char_shapes.len() < 2
        || para.text.chars().take_while(|value| *value == ' ').count() < 2
    {
        return false;
    }

    let mut resolved = para
        .char_shapes
        .iter()
        .filter_map(|char_shape| styles.char_styles.get(char_shape.char_shape_id as usize));
    let Some(first) = resolved.next() else {
        return false;
    };
    let first_tracking = &first.letter_spacings;
    let mut tracking_differs = false;

    for style in resolved {
        if style.font_family != first.font_family
            || style.font_families != first.font_families
            || (style.font_size - first.font_size).abs() > f64::EPSILON
            || style.bold != first.bold
            || style.italic != first.italic
            || (style.ratio - first.ratio).abs() > f64::EPSILON
            || style.ratios != first.ratios
            || style.kerning != first.kerning
        {
            return false;
        }
        tracking_differs |= (style.letter_spacing - first.letter_spacing).abs() > f64::EPSILON
            || style.letter_spacings.as_slice() != first_tracking.as_slice();
    }

    tracking_differs
}

/// [#2279 axis B] 셀 텍스트 오버플로 시 좌우 패딩 축소 — 렌더/측정 공용 코어.
///
/// 측정과 배치는 동일한 최소 셀 너비 규칙을 사용한다.
/// 과거 #2237/#2279의 86712 5줄/4줄 진단은 저장 LineSeg가 누락된 잘못된
/// 파생 입력을 근거로 삼았다. 정상 한컴 저장본은 측정·재조판 모두 4줄이다.
/// 그 진단 수치를 현재 정상 원본의 조판 계약으로 사용하지 않는다.
/// 한/글이 셀 안 줄에 보장하는 최소 너비 (HWPUNIT). 1440 = 정확히 0.2 인치.
///
/// 안 여백 합이 셀 폭에 육박하면 남는 폭이 0 에 가까워진다. 한/글은 그 폭으로 줄을 만들지
/// 않고 이 하한선까지 넓힌다. `samples/` HWP5 전수(셀-줄 91,866개)에서 저장된
/// `LineSeg.segment_width` 를 남는 폭과 맞대면 경계가 뚜렷하다.
///
/// | 남는 폭 | 줄 수 | `sw == 1440` |
/// | --- | --- | --- |
/// | 0 이상 1440 미만 | 7,862 | **98.7%** |
/// | 1440 초과 | 83,127 | 0.8% |
///
/// 근거·재현: `mydocs/report/2026-08-28-cell-min-line-width.md`
const HANGUL_MIN_CELL_LINE_WIDTH_HWPUNIT: f64 = 1440.0;

/// 남는 폭이 하한선보다 좁으면 **오른쪽** 안 여백을 깎아 하한선을 확보한다.
///
/// 왼쪽은 건드리지 않는다 — 한/글은 글자 시작 위치를 유지한다(셀보호2 실측: 첫 글자가
/// 셀 좌단 + 2834 HWPUNIT 그대로, 미리보기 이미지와 2px 이내 일치).
///
/// 셀이 하한선보다 좁으면 오른쪽 여백이 음수가 된다. 이는 글자가 셀 밖으로 나간다는 뜻이고
/// 한/글도 그렇게 한다(셀 폭 564 에 sw=1440). 호출부는 `pad_right` 를 `cell_w - pl - pr`
/// 뺄셈에만 쓰므로 음수가 그대로 폭으로 환원된다.
pub(crate) fn floored_cell_line_width_padding(
    pad_left: f64,
    pad_right: f64,
    cell_w: f64,
    dpi: f64,
) -> (f64, f64) {
    let min_width = HANGUL_MIN_CELL_LINE_WIDTH_HWPUNIT / 7200.0 * dpi;
    let available = cell_w - pad_left - pad_right;

    // 폭이 없는 셀(선언 없음 → 0)에는 적용하지 않는다. 하한선은 실제 셀에 대한 규칙이고,
    // 폭을 모르는 자리에 19.2px 를 만들어 주는 것은 측정이 아니라 추측이다.
    //
    // 남는 폭이 **음수**인 구간도 다루지 않는다. `aim=true` 로는 표본에 0건이고,
    // `aim=false` 는 86.9% 로 갈린다(한 파일의 100줄이 여백을 무시하고 셀 폭을 다 쓴다).
    // 근거가 있는 구간은 `0 <= 남는 폭 < 1440` 뿐이고, 거기서만 적용한다.
    if cell_w <= 0.0 || available < 0.0 || available >= min_width {
        return (pad_left, pad_right);
    }
    (pad_left, cell_w - pad_left - min_width)
}

/// 셀 안 글자 상자의 너비. 최소 줄 너비 하한선을 포함한다.
///
/// 같은 식 `(cell_w - pad_left - pad_right).max(0)` 이 렌더 4곳·측정 3곳·편집 2곳에
/// 복사돼 있었다. 하한선을 그중 일부에만 넣으면 측정 줄 수와 렌더 줄 수가 갈려 행 높이가
/// 어긋난다(#2279 가 겪은 것이 정확히 그 발산이다). 계산을 한 자리로 모아 호출부가
/// 규칙을 고를 수 없게 한다.
pub(crate) fn cell_inner_text_width(cell_w: f64, pad_left: f64, pad_right: f64, dpi: f64) -> f64 {
    let (pad_left, pad_right) = floored_cell_line_width_padding(pad_left, pad_right, cell_w, dpi);
    // Pixel subtraction can lose the final integer unit before the paragraph
    // frame truncates back to HWPUNIT (30888 - 510 - 510 became 29867).
    // Recover only operands produced exactly by the forward integer-HU
    // conversion. Fractional/scaled/unknown pixel geometry keeps its old path;
    // this is not an interval tolerance or a one-unit cache-match allowance.
    let exact_units = |value: f64| -> Option<i32> {
        if !value.is_finite() || value < 0.0 || !dpi.is_finite() || dpi <= 0.0 { return None; }
        let units = (value * crate::renderer::HWPUNIT_PER_INCH / dpi).round();
        if units < 0.0 || units > i32::MAX as f64 { return None; }
        let units = units as i32;
        (hwpunit_to_px(units, dpi) == value).then_some(units)
    };
    if let (Some(width),Some(left),Some(right)) = (exact_units(cell_w),exact_units(pad_left),exact_units(pad_right)) {
        let extent = i64::from(width) - i64::from(left) - i64::from(right);
        if (0..=i64::from(i32::MAX)).contains(&extent) {
            return hwpunit_to_px(extent as i32,dpi);
        }
    }
    (cell_w - pad_left - pad_right).max(0.0)
}

pub(crate) fn shrunk_cell_horizontal_padding(
    pad_left: f64,
    pad_right: f64,
    cell_w: f64,
    // 칸의 글자 상자 높이(px). 줄바꿈 결과가 여기에 들어가면 여백을 깎지 않는다.
    inner_height_px: f64,
    composed_paras: &[ComposedParagraph],
    paragraphs: &[Paragraph],
    styles: &ResolvedStyleSet,
    preserve_cell_padding: bool,
    line_wrap_squeeze: bool,
    dpi: f64,
) -> (f64, f64) {
    // 하한선을 먼저 적용한다. `preserve_cell_padding`(aim=true) 은 "저장된 안 여백을
    // 임의로 깎지 않는다"는 뜻이지 "줄을 0 폭으로 만든다"는 뜻이 아니다 — 한/글은 aim 과
    // 무관하게 하한선을 지킨다(셀보호2 는 aim=true 이고 남는 폭 283 인데 sw=1440).
    let (pad_left, pad_right) = floored_cell_line_width_padding(pad_left, pad_right, cell_w, dpi);

    if preserve_cell_padding {
        return (pad_left, pad_right);
    }

    // [#6145] **"한 줄로 입력"(`lineWrap=SQUEEZE`) 칸은 안 여백을 깎지 않는다.**
    //
    // 이 규칙은 "글자가 넘치면 여백을 1px 까지 내주어 자리를 만든다"는 뜻인데, SQUEEZE
    // 칸에서 한/글이 하는 일은 정반대다 — 여백은 그대로 두고 **자간을 줄여** 글자를
    // 안쪽 폭에 밀어 넣는다. 156607916 6쪽 마지막 열이 그 예로, 저장 lineseg 가
    // `horzsize=9340`(=93.40pt)를 못박아 두었는데도 여백을 깎아 97.56pt 를 내주는 바람에
    // 자간이 덜 줄고 글자가 우측 괘선 밖 +0.69pt 로 나갔다(한/글은 −3.02pt 안쪽).
    if line_wrap_squeeze {
        return (pad_left, pad_right);
    }

    // [Task #617] 다중 줄(2 줄 이상) 단락이 line_segs 로 분배 완료된 경우,
    // HWP 가 가용 폭에 맞춰 자간을 분배하고 줄바꿈을 확정한 상태이므로
    // 자연 폭 추정으로 다시 깎으면 오버 페인팅. 단일 줄 셀(좁은 수치 셀
    // 등에서 오버플로우 가능성 있음) 은 종전 휴리스틱으로 보호한다.
    let any_multiline_distributed = paragraphs.iter().any(|p| p.line_segs.len() >= 2);
    if any_multiline_distributed {
        return (pad_left, pad_right);
    }

    let mut max_line_w = 0.0f64;
    for comp in composed_paras {
        for line in &comp.lines {
            let mut w = 0.0;
            for run in &line.runs {
                let mut ts = run.text_style(styles);
                if run.char_overlap.is_some() {
                    let fs = if ts.font_size > 0.0 {
                        ts.font_size
                    } else {
                        12.0
                    };
                    let chars: Vec<char> = run.text.chars().collect();
                    w += fs * char_overlap_advance_units(&chars) as f64;
                    continue;
                }
                // 자연 폭 측정: 음수 자간을 제거하여 글리프가 서로 겹치지 않는 최소 폭을 얻음
                if ts.letter_spacing < 0.0 {
                    ts.letter_spacing = 0.0;
                }
                // [Task #555] PUA 옛한글 변환 후 자모 시퀀스 폭 사용.
                // (estimate_text_width 는 ts.ratio 를 자체 반영함.)
                w += estimate_text_width(effective_text_for_metrics(run), &ts);
            }
            if w > max_line_w {
                max_line_w = w;
            }
        }
    }
    let available = (cell_w - pad_left - pad_right).max(0.0);
    // Task #347: estimate_text_width는 영어 본문(Times New Roman 등) 자연 폭을
    // 5~15%까지 과대 추정할 수 있어, HWP가 이미 줄바꿈한 본문에서도
    // padding 축소가 잘못 트리거됨. 15% 이내 초과는 정상으로 보고 미축소.
    //
    // [#7413] 이 사전 필터는 **그대로 둔다.** 아래 높이 판정이 "깎지 않아도 되는 칸"을
    // 걸러내는 일을 하고, 이 필터를 함께 없애면 종전에 깎지 않던 칸까지 새로 깎게 되어
    // 측정 범위 밖의 동작 확장이 된다(samples 전수 A/B: 변화 174 → 234).
    let overflow_threshold = available * 1.15;
    if max_line_w <= overflow_threshold || cell_w <= 2.0 {
        return (pad_left, pad_right);
    }

    // [#7413] **줄바꿈으로 해결되는 문단은 깎지 않는다.**
    //
    // 종전 조건은 "자연 폭 > 가용 너비 × 1.15" 였다. 그건 "이 문단은 줄바꿈이 필요하다"는
    // 뜻일 뿐이라, 줄바꿈해도 칸 높이에 들어가는 문단까지 전부 걸렸다. 1.15 는 Task #347 이
    // 영문 자연 폭 과대 추정을 흡수하려고 둔 값이고 한/글 출력에서 나온 값이 아니다.
    //
    // 축소가 실제로 지탱하는 계약은 "칸 안 글자가 칸 밖으로 새지 않는다" 하나다(실측:
    // 축소를 끄면 samples 전수에서 겹침이 4건 늘고, 그 넷이 전부 줄바꿈 결과가 행 높이를
    // 넘는 자리다 — 20099369_yeongwol_forms 3쪽 칸 w=41.9/h=43.6 가 2줄 45px 를 요구,
    // issue5169 12쪽 Cell5 h=59.2 가 4줄 80.3px, Cell51 h=29.4 가 2줄 46.7px).
    //
    // 그러므로 묻는 것을 바꾼다 — "줄바꿈한 결과가 칸 높이를 넘는가". 넘지 않으면 줄바꿈이
    // 답이고 여백은 그대로 둔다. 정본 대조 가능한 10쪽(80168 3쪽·2022 국립국어원 3쪽·
    // 156160455 1쪽)에서 종전 축소는 전부 한/글에서 멀어지게 하고 있었다.
    if inner_height_px > 0.0 && available > 0.0 {
        // 줄 수를 **추정하지 않고 실제로 센다.** `ceil(자연 폭 / 가용 폭)` 은 어절
        // 줄바꿈이 줄 끝에 남기는 낭비를 반영하지 못해 낙관적이다(issue5169 `Cell5`:
        // 추정 52.3px vs 실제 4줄 83.2px). 폭 판정을 통과한 칸에서만 도는 경로라
        // 조합 비용은 그 칸들로 한정된다.
        let mut wrapped_height = 0.0f64;
        let mut last_line_spacing = 0.0f64;
        let mut stored_fits_fewer_lines = false;
        for (idx, para) in paragraphs.iter().enumerate() {
            let mut comp = match composed_paras.get(idx) {
                Some(c) => c.clone(),
                None => compose_paragraph_in_context(para, styles),
            };
            recompose_cell_lines_in_frame(
                &mut comp,
                para,
                ParagraphBox::content_for_style(
                    available,
                    styles.para_styles.get(para.para_shape_id as usize),
                    dpi,
                ),
                styles,
                dpi,
                false,
            );
            // [#7418] 한/글 자신의 저장 줄(비합성 LINE_SEG)이 줄바꿈 결과보다 적으면, 한/글은
            // 이 글을 그 줄 수에 담았다는 증거다 — 높이와 무관하게 깎아 그 줄 수를 따른다.
            // 20099369 3쪽 `월별누계` 칸: 저장 1줄, rhwp 줄바꿈 2줄(말미 제외 39.8 ≤ 43.6).
            let stored_lines = para
                .line_segs
                .iter()
                .filter(|seg| {
                    seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0
                })
                .count();
            if stored_lines > 0 && comp.lines.len() > stored_lines {
                stored_fits_fewer_lines = true;
            }
            for line in &comp.lines {
                // 실제 줄 피치는 `line_height + line_spacing` 이다. `line_height` 만
                // 쓰면 줄간격이 빠져 높이를 과소평가한다(20099369 3쪽 칸: 1300 + 390
                // = 1690 HWPUNIT = 22.53px, 렌더 실측 22.5px).
                wrapped_height +=
                    crate::renderer::hwpunit_to_px(line.line_height + line.line_spacing, dpi);
                last_line_spacing = crate::renderer::hwpunit_to_px(line.line_spacing, dpi);
            }
        }
        // [#7418] 칸의 **마지막** 줄 뒤에는 이을 줄이 없어 그 줄간격은 칸을 채우지 않는다 —
        // 행 높이 측정(`height_measurer`, 칸 마지막 줄의 말미 줄간격 제외)과 같은 규칙.
        // 70833 pi=83 4행: 3줄 56.0(말미 5.33 포함) > 안높이 55.4 로 여백을 깎아 한/글보다
        // 5.7px 왼쪽에서 시작하고 줄 끝이 달라졌다. 말미를 빼면 50.7 ≤ 55.4 다.
        wrapped_height -= last_line_spacing.max(0.0);
        if std::env::var_os("RHWP_DIAG_SHRINK").is_some() {
            println!(
                "D_SHRINK cell_w={cell_w:.1} avail={available:.1} inner_h={inner_height_px:.15} wrapped_h={wrapped_height:.15} max_line_w={max_line_w:.1}"
            );
        }
        // Adding line pitches and subtracting cell padding can round the same
        // physical height to adjacent f64 values. That single representable
        // step is arithmetic noise, not overflow that warrants shrinking pads.
        if wrapped_height <= inner_height_px.next_up() && !stored_fits_fewer_lines {
            return (pad_left, pad_right);
        }
    }
    let min_pad = 1.0;
    let total_pad = pad_left + pad_right;
    let max_reducible = (total_pad - 2.0 * min_pad).max(0.0);
    if max_reducible <= 0.0 {
        return (pad_left, pad_right);
    }
    let deficit = max_line_w - available;
    let reduction = deficit.min(max_reducible);
    let new_total = total_pad - reduction;
    let new_left = if total_pad > 0.0 {
        pad_left * new_total / total_pad
    } else {
        new_total / 2.0
    };
    let new_right = new_total - new_left;
    (new_left, new_right)
}

fn missing_lineseg_legacy_bullet_requires_regenerated_space_metric(
    para: &Paragraph,
    composed: &ComposedParagraph,
    styles: &ResolvedStyleSet,
) -> bool {
    let has_tight_leading_body_style = para.char_shapes.get(1).is_some_and(|cs_ref| {
        cs_ref.start_pos <= 3
            && styles
                .char_styles
                .get(cs_ref.char_shape_id as usize)
                .map(|cs| cs.letter_spacing <= -3.0)
                .unwrap_or(false)
    });

    para.line_segs.is_empty()
        && para.controls.is_empty()
        && para.text.starts_with('\u{F03C5}')
        && has_tight_leading_body_style
        && composed
            .lines
            .iter()
            .flat_map(|line| &line.runs)
            .any(|run| {
                let style = run.text_style(styles);
                hancom_regenerated_space_width(&style).is_some()
            })
}

/// 단일 ComposedLine 을 셀 가용 너비에 맞춰 다중 ComposedLine 으로 분할.
///
/// 분할 단위: 공백 단어 경계 우선, 단일 단어가 너비 초과 시 글자 단위 break.
/// 각 분할 줄의 메타데이터 (line_height/baseline/segment_width 등) 는 원본 보존.
fn split_composed_line_by_width(
    src: &ComposedLine,
    first_width_px: f64,
    cont_width_px: f64,
    styles: &ResolvedStyleSet,
    char_break: bool,
    space_condense: f64,
    regenerated_line_space_metric: bool,
    fit_tolerance_px: f64,
    regenerate_half_spaces: bool,
) -> Vec<ComposedLine> {
    let mut result: Vec<ComposedLine> = Vec::new();
    // [#2070] 내어쓰기(intent<0) 이중 폭: 첫 출력 줄은 first_width, 이후 연속
    // 줄은 cont_width 로 판정한다 (80168 조문 문단 첫줄 넓게/연속 좁게).
    let limit = |res: &Vec<ComposedLine>| -> f64 {
        if res.is_empty() {
            first_width_px
        } else {
            cont_width_px
        }
    };
    let mut current_runs: Vec<ComposedTextRun> = Vec::new();
    let mut current_width = 0.0;
    // [#2070] 한양신명조 사다리 v3/v4 확정 규칙: (a) 줄 채움 판정은 공백 폭을
    // 문단 condense% 만큼 압축해 계산(공백 압축), (b) 줄끝 초과 공백 1개는
    // 다음 줄로 넘기지 않고 현재 줄에 매달림(hang).
    let mut space_w = 0.0;
    let mut hung = false;
    let mut current_char_start = src.char_start;
    let mut chars_in_line = 0usize;
    let mut current_run_text = String::new();
    let mut current_run_template: Option<ComposedTextRun> = None;
    let text_width = |text: &str, style: &TextStyle| {
        let measured =
            estimate_regenerated_line_text_width(text, style, regenerated_line_space_metric);
        if !regenerate_half_spaces {
            return measured;
        }
        let spaces = text.chars().filter(|value| *value == ' ').count();
        if spaces == 0 {
            return measured;
        }
        let stored = estimate_regenerated_line_text_width(" ", style, false);
        measured + spaces as f64 * (regenerated_half_space_width(style) - stored)
    };

    let flush_run =
        |runs: &mut Vec<ComposedTextRun>, text: &mut String, template: &Option<ComposedTextRun>| {
            if !text.is_empty() {
                if let Some(t) = template {
                    runs.push(ComposedTextRun {
                        text: std::mem::take(text),
                        char_style_id: t.char_style_id,
                        lang_index: t.lang_index,
                        char_overlap: t.char_overlap.clone(),
                        footnote_marker: t.footnote_marker,
                        display_text: None,
                        supplemental_metrics_blocked: t.supplemental_metrics_blocked,
                        inserted_control_text: t.inserted_control_text,
                        space_metric: t.space_metric,
                    });
                } else {
                    text.clear();
                }
            }
        };

    let push_line = |result: &mut Vec<ComposedLine>,
                     runs: &mut Vec<ComposedTextRun>,
                     current_char_start: &mut usize,
                     chars_in_line: &mut usize,
                     current_width: &mut f64| {
        if !runs.is_empty() {
            result.push(ComposedLine {
                runs: std::mem::take(runs),
                line_height: src.line_height,
                baseline_distance: src.baseline_distance,
                segment_width: src.segment_width,
                column_start: src.column_start,
                line_spacing: src.line_spacing,
                has_line_break: false,
                char_start: *current_char_start,
            });
            *current_char_start += *chars_in_line;
            *chars_in_line = 0;
            *current_width = 0.0;
        }
    };

    for run in &src.runs {
        let ts = run.text_style(styles);
        // 현재 run 의 template 변경 (char_style 다른 run 들 처리)
        if current_run_template
            .as_ref()
            .map(|t| {
                t.char_style_id != run.char_style_id
                    || t.lang_index != run.lang_index
                    || (styles.supplemental_metrics.is_some()
                        && (t.supplemental_metrics_blocked != run.supplemental_metrics_blocked
                            || t.inserted_control_text != run.inserted_control_text))
            })
            .unwrap_or(true)
        {
            flush_run(
                &mut current_runs,
                &mut current_run_text,
                &current_run_template,
            );
            current_run_template = Some(run.clone());
        }
        // [#2169] 줄나눔 기준 '글자'(korean_break_unit==0) — 글자 단위 채움.
        // 한글은 이 모드에서 어절 경계 무시하고 줄을 채운다 (80168 r10:
        // "또/는", "필요/한" 글자 분리, 한글 5줄 vs 어절 래핑 6줄).
        if char_break {
            for ch in run.text.chars() {
                let ch_str: String = std::iter::once(ch).collect();
                let ch_width = text_width(&ch_str, &ts);
                if std::env::var("RHWP_RAZOR").is_ok()
                    && src.runs.iter().any(|r| r.text.contains("도조례로 정하는"))
                {
                    eprintln!(
                        "RZ: ch={:?} w={:.2} cur={:.2} spw={:.2} cnd={:.2} limit={:.2} fam={:?}",
                        ch,
                        ch_width,
                        current_width,
                        space_w,
                        space_condense,
                        limit(&result),
                        ts.font_family.split(',').next().unwrap_or("")
                    );
                }
                let eff = current_width - space_w * space_condense;
                let over = eff + ch_width > limit(&result) + fit_tolerance_px && chars_in_line > 0;
                if over && ch == ' ' && !hung {
                    // 줄끝 초과 공백 1개 hang — 줄바꿈 없이 현재 줄에 계상.
                    hung = true;
                } else if over {
                    // [#2244] 행두 금칙: 새 줄이 금칙 문자(마침표 등)로 시작하지
                    // 않도록 직전 글자를 함께 다음 줄로 이월한다 — 한컴 2024 저장
                    // 오라클 정합 ("적용한 | 다.111…", LINE_SEG [...,128]).
                    // 직전 글자가 같은 run 안에 있고(스타일 경계 아님) 공백이
                    // 아니며 줄에 2자 이상 남을 때만 1자 retraction.
                    let carried: Option<(char, f64)> = if is_line_start_forbidden(ch)
                        && chars_in_line > 1
                        && current_run_text
                            .chars()
                            .last()
                            .is_some_and(|p| p != ' ' && !is_line_start_forbidden(p))
                    {
                        current_run_text.pop().map(|prev| {
                            let prev_str: String = std::iter::once(prev).collect();
                            let prev_w = text_width(&prev_str, &ts);
                            current_width -= prev_w;
                            chars_in_line -= 1;
                            (prev, prev_w)
                        })
                    } else {
                        None
                    };
                    flush_run(
                        &mut current_runs,
                        &mut current_run_text,
                        &current_run_template,
                    );
                    push_line(
                        &mut result,
                        &mut current_runs,
                        &mut current_char_start,
                        &mut chars_in_line,
                        &mut current_width,
                    );
                    space_w = 0.0;
                    hung = false;
                    if let Some((pch, pw)) = carried {
                        current_run_text.push(pch);
                        current_width += pw;
                        chars_in_line += 1;
                    }
                }
                current_run_text.push(ch);
                current_width += ch_width;
                if ch == ' ' {
                    space_w += ch_width;
                }
                chars_in_line += 1;
            }
            continue;
        }
        // run 텍스트를 단어 단위로 분할 (공백 포함)
        let mut word = String::new();
        for ch in run.text.chars() {
            word.push(ch);
            // 공백 또는 마지막 글자 직전이 단어 경계
            if ch == ' ' || ch == '\t' {
                let word_width = text_width(&word, &ts);
                // 현재 단어가 추가되면 max_width 초과하는지 검사
                if current_width - space_w * space_condense + word_width
                    > limit(&result) + fit_tolerance_px
                    && (chars_in_line > 0 || !current_run_text.is_empty())
                {
                    // 현재 줄을 flush 후 새 줄 시작
                    flush_run(
                        &mut current_runs,
                        &mut current_run_text,
                        &current_run_template,
                    );
                    push_line(
                        &mut result,
                        &mut current_runs,
                        &mut current_char_start,
                        &mut chars_in_line,
                        &mut current_width,
                    );
                    space_w = 0.0;
                    hung = false;
                }
                // 단어 자체가 max_width 초과 시 글자 단위 break
                if word_width > limit(&result) && current_width == 0.0 {
                    for wch in word.chars() {
                        let wch_str: String = std::iter::once(wch).collect();
                        let wch_width = text_width(&wch_str, &ts);
                        if current_width - space_w * space_condense + wch_width > limit(&result)
                            && chars_in_line > 0
                        {
                            flush_run(
                                &mut current_runs,
                                &mut current_run_text,
                                &current_run_template,
                            );
                            push_line(
                                &mut result,
                                &mut current_runs,
                                &mut current_char_start,
                                &mut chars_in_line,
                                &mut current_width,
                            );
                            space_w = 0.0;
                            hung = false;
                        }
                        current_run_text.push(wch);
                        current_width += wch_width;
                        chars_in_line += 1;
                    }
                } else {
                    current_run_text.push_str(&word);
                    current_width += word_width;
                    space_w += text_width(" ", &ts) * word.matches(' ').count() as f64;
                    chars_in_line += word.chars().count();
                }
                word.clear();
            }
        }
        // run 끝에 남은 단어 처리
        if !word.is_empty() {
            let word_width = text_width(&word, &ts);
            if current_width - space_w * space_condense + word_width > limit(&result)
                && (chars_in_line > 0 || !current_run_text.is_empty())
            {
                flush_run(
                    &mut current_runs,
                    &mut current_run_text,
                    &current_run_template,
                );
                push_line(
                    &mut result,
                    &mut current_runs,
                    &mut current_char_start,
                    &mut chars_in_line,
                    &mut current_width,
                );
                space_w = 0.0;
                hung = false;
            }
            // 단어 자체가 max_width 초과 시 글자 단위 break
            if word_width > limit(&result) && current_width == 0.0 {
                for wch in word.chars() {
                    let wch_str: String = std::iter::once(wch).collect();
                    let wch_width = text_width(&wch_str, &ts);
                    if current_width - space_w * space_condense + wch_width > limit(&result)
                        && chars_in_line > 0
                    {
                        flush_run(
                            &mut current_runs,
                            &mut current_run_text,
                            &current_run_template,
                        );
                        push_line(
                            &mut result,
                            &mut current_runs,
                            &mut current_char_start,
                            &mut chars_in_line,
                            &mut current_width,
                        );
                        space_w = 0.0;
                        hung = false;
                    }
                    current_run_text.push(wch);
                    current_width += wch_width;
                    chars_in_line += 1;
                }
            } else {
                current_run_text.push_str(&word);
                current_width += word_width;
                chars_in_line += word.chars().count();
            }
        }
    }
    // 마지막 줄 flush
    flush_run(
        &mut current_runs,
        &mut current_run_text,
        &current_run_template,
    );
    push_line(
        &mut result,
        &mut current_runs,
        &mut current_char_start,
        &mut chars_in_line,
        &mut current_width,
    );
    space_w = 0.0;
    hung = false;

    if result.is_empty() {
        // 안전장치: 절대 빈 결과 반환하지 않음
        result.push(src.clone());
    }
    result
}

/// [Task #555] 폰트 매트릭스 (글자폭/줄간격) 계산용 effective text 반환.
///
/// PUA 옛한글 변환 (Task #528) 후 `run.display_text` 가 자모 시퀀스를 보유하면
/// 본 함수는 그 자모 시퀀스를 반환한다. 그렇지 않으면 `run.text` (PUA char 1글자
/// 또는 일반 텍스트) 를 그대로 반환.
///
/// 사용처: `estimate_text_width` / `estimate_composed_line_width` 등 폰트 매트릭스
/// 측정 함수의 caller. visual 출력 (svg/web_canvas) 은 이미 `display_text` 사용.
///
/// 단일 룰 (분기/허용오차 없음): 비-PUA 텍스트는 fallback 으로 동일 동작.
pub fn effective_text_for_metrics(run: &ComposedTextRun) -> &str {
    // [#7017] U+F081C 는 `expand_pua_display_text` 가 **지우는**(continue) 글자라,
    // `display_text` 로 측정하면 글자 수가 줄어 폭이 모자란다. 원문을 유지해 글자
    // 수를 보존한다 — 폭은 `text_measurement` 가 다른 `hancom_pua` 괘선 조각과 같이
    // 폴백 0.5em 으로 잰다(렌더가 `┈` 를 그리는 전진폭과 같다).
    //
    // 종전 주석은 "0폭 규칙을 우회하지 않으려고" 라고 적었는데, 그 0폭 규칙 자체가
    // #7017 에서 한/글 정본과 어긋남이 확인돼 사라졌다.
    if run.text.contains('\u{F081C}') {
        return &run.text;
    }
    run.display_text.as_deref().unwrap_or(&run.text)
}

/// PUA Supplementary 영역(U+F0000~) 문자가 테두리 숫자인지 판별한다.
///
/// HWP 특수문자표에서 표준 Unicode가 없는 테두리 숫자를 PUA로 인코딩한다.
/// - U+F02B1~U+F02C4: map_pua_bullet_char 에서 ①~⑳ 으로 매핑 (CharOverlap 제외)
/// - U+F02CE~U+F02E1: 반전 사각형 안의 숫자 1~20 (border_type=4)
///
/// 반환: Some(border_type) 또는 None
/// PUA 문자 자체는 변환하지 않고, 렌더러(draw_char_overlap)에서 표시 문자열로 변환한다.
/// 이렇게 하면 PUA 문자가 항상 1글자로 유지되어 font_size 기반 폭 계산이 정확하다.
/// PUA 글자겹침용 숫자 컴포넌트 디코딩
///
/// HWP tcps 컨트롤의 2~3자리 숫자는 자릿수별 PUA 코드포인트로 저장된다.
/// 각 PUA 문자를 (자릿수_그룹, 숫자값) 쌍으로 디코딩한다.
///
/// 2자리 블록 (U+F0288 base):
///   십의자리: F0289~F0291 (1-9)
///   일의자리: F0292~F029B (0-9)
///
/// 3자리 블록 (U+F0490 base):
///   백의자리: F0491~F0499 (1-9)
///   십의자리: F049A~F04A3 (0-9)
///   일의자리: F04A4~F04AD (0-9)
fn pua_overlap_digit(ch: char) -> Option<(u8, u8)> {
    let cp = ch as u32;
    // 2자리 블록
    if (0xF0289..=0xF0291).contains(&cp) {
        return Some((0, (cp - 0xF0288) as u8));
    } // tens 1-9
    if (0xF0292..=0xF029B).contains(&cp) {
        return Some((1, (cp - 0xF0292) as u8));
    } // ones 0-9
      // 3자리 블록
    if (0xF0491..=0xF0499).contains(&cp) {
        return Some((0, (cp - 0xF0490) as u8));
    } // hundreds 1-9
    if (0xF049A..=0xF04A3).contains(&cp) {
        return Some((1, (cp - 0xF049A) as u8));
    } // tens 0-9
    if (0xF04A4..=0xF04AD).contains(&cp) {
        return Some((2, (cp - 0xF04A4) as u8));
    } // ones 0-9
    None
}

/// CharOverlap의 PUA 문자 배열을 숫자 문자열로 디코딩한다.
///
/// 모든 문자가 PUA 겹침용 숫자인 경우에만 디코딩 성공 (Some).
/// 그룹 번호(0=최상위자리, 1=중간, 2=최하위)로 정렬하여 올바른 자릿수 순서를 보장한다.
pub fn decode_pua_overlap_number(chars: &[char]) -> Option<String> {
    if chars.is_empty() {
        return None;
    }
    let mut groups: Vec<(u8, u8)> = Vec::with_capacity(chars.len());
    for &ch in chars {
        groups.push(pua_overlap_digit(ch)?);
    }
    // 그룹 번호 순 정렬 (최상위 자리 → 최하위 자리)
    groups.sort_by_key(|(g, _)| *g);
    let s: String = groups.iter().map(|(_, d)| char::from(b'0' + d)).collect();
    Some(s)
}

/// CharOverlap controls occupy one text-flow position even when their payload
/// contains multiple glyph components.
///
/// Hancom uses this for overlapped two-digit markers such as the boxed 10/11/12
/// in `table-vpos-01.hwp`: the control stores two PUA glyph components, but
/// caret movement and line measurement advance by one character box.
pub fn char_overlap_advance_units(chars: &[char]) -> usize {
    usize::from(!chars.is_empty())
}

/// 글자겹침(CharOverlap) 내부 글자의 크기 비율.
///
/// `charSz` 는 OWPML 상 **"테두리 내부 글자의 크기 비율. 단위 %"**
/// (`mydocs/manual/OWPML SCHEMA/ParaList XML schema.xml:571`) 다. 따라서 테두리를
/// 그리지 않는 겹침에는 적용하지 않는다 — 축소할 "테두리 내부"가 없다.
///
/// `effective_border` 는 raw `border_type` 이 아니라 **실제로 테두리를 그리는지** 다.
/// PUA 다자리 숫자는 `border_type=0` 이어도 원형 테두리로 승격되므로(각 렌더 경로의
/// combined 분기) 그 경우는 축소가 정당하다.
///
/// 한컴 실측 두 건이 이 규칙을 함께 만족한다 (#4085):
/// - `samples/hwpx/k-water-rfp.hwpx` p13 — 반전 사각형(4), `charSz=-2` → 0.80 (PR #1101)
/// - 관세청 월간 수출입 현황 p1 — 테두리 없음(0), `charSz=-4` → 축소 없음. 한컴 PDF
///   content stream 에서 마커와 본문이 같은 `101 Tf`, 같은 baseline 으로 나온다.
///
/// 음수 영역의 10% step 해석은 PR #1101 의 실측 가설을 그대로 둔다.
pub fn char_overlap_size_ratio(effective_border: u8, inner_char_size: i8) -> f64 {
    if effective_border == 0 {
        return 1.0;
    }
    if inner_char_size > 0 {
        // 양수 → percent ratio (HWPX 양수 case 보존: 50 = 0.5)
        inner_char_size as f64 / 100.0
    } else if inner_char_size < 0 {
        // 음수 → 10% step 축소 (한컴 정합: charSz=-3 → 1.0 + (-3)×0.10 = 0.70)
        1.0 + inner_char_size as f64 * 0.10
    } else {
        1.0
    }
}

/// 글자겹침(CharOverlap) 한 글자의 **표시 문자열**을 정한다.
///
/// `border_drawn` 은 그 겹침을 그릴 때 렌더러가 **실제로 원/사각 테두리를 따로 그리는지**다.
///
/// - 테두리를 그리는 경우: 원문자 `①`~`⑳`(U+2460~U+2473)는 안쪽 숫자로 풀어 쓴다.
///   테두리를 그려 놓고 원문자 글리프까지 찍으면 동그라미가 이중으로 나온다.
/// - 테두리를 안 그리는 경우(`circleType="CHAR"` → `border_type=0`): `composeText` 를
///   **그대로** 그린다. 이때 숫자로 풀면 그릴 동그라미가 아무 데도 없어 `①` 이 맨 `1` 로
///   나간다 (#5790).
///
/// 한컴은 `circleType="CHAR"` + `composeText="①"` 을 전각 한 칸에 `①` 한 글자로 찍는다.
pub fn char_overlap_display_text(ch: char, border_drawn: bool) -> String {
    let cp = ch as u32;
    if border_drawn && (0x2460..=0x2473).contains(&cp) {
        return (cp - 0x2460 + 1).to_string();
    }
    if let Some(display) = pua_to_display_text(ch) {
        return display;
    }
    ch.to_string()
}

fn pua_enclosed_border_type(ch: char) -> Option<u8> {
    let cp = ch as u32;
    // U+F02B1~F02C4 (①~⑳): map_pua_bullet_char 에서 표준 원문자로 매핑 — CharOverlap 제외
    // 반전 사각형 안의 숫자: U+F02CE(1) ~ U+F02E1(20)
    if (0xF02CE..=0xF02E1).contains(&cp) {
        return Some(4); // border_type=4: 반전 사각형
    }
    None
}

fn pua_plain_text_display(ch: char) -> Option<&'static str> {
    super::hancom_pua::verified_hancom_pua_display(ch)
}

/// [#5800] HWP5 원시 한컴 사용자 기호를 **표시 매핑 조회용 평면-15 키**로 정규화한다.
///
/// 같은 글자를 HWP5 는 BMP 단일 유닛 `0xA000 | X` 로, HWPX 는 평면 15 보충 PUA
/// `U+F0000 | X` 로 싣는다(`parser::tags::HANCOM_SYMBOL_BMP_TO_PLANE15` — 한글 실측
/// 값 집합). 표시 매핑표(`hancom_pua` · `map_pua_bullet_char`)는 평면 15 키만 갖고
/// 있어 HWP5 경로가 표를 못 타고 원시 코드포인트를 그대로 그렸다 — `0xA832` 가
/// 유니코드 U+A832(실로티 나그리 `꠲`)로, `0xA12B` 가 `ꄫ` 로 나오는 식이다.
///
/// **정규화는 표에 값이 있을 때만 한다.** 값이 없으면 원문을 그대로 둬서, 미등록 PUA
/// 축(#5599)이 관측하는 표면을 이 변경이 흔들지 않게 한다.
fn hancom_symbol_display_key(ch: char) -> char {
    let Ok(unit) = u16::try_from(ch as u32) else {
        return ch;
    };
    let Some(plane15) =
        crate::parser::tags::hancom_symbol_to_plane15(unit).and_then(char::from_u32)
    else {
        return ch;
    };
    let has_mapping = pua_plain_text_display(plane15).is_some()
        || super::layout::map_pua_bullet_char(plane15) != plane15;
    if has_mapping {
        plane15
    } else {
        ch
    }
}

/// 한글 방점(U+302E/U+302F)을 렌더용 spacing 가운데 점 글리프로 치환한다. (Task #1735)
///
/// U+302E/U+302F 는 유니코드 결합문자(combining mark)라, 유효한 base 없이
/// (줄 시작·공백 뒤) 셰이핑되면 브라우저/엔진이 dotted-circle(U+25CC)
/// placeholder 를 삽입하고 톤 점을 그 위에 쌓아 한컴과 다르게 표기된다.
/// 한컴은 방점을 독립 spacing 점으로 렌더하므로, 렌더 경로에서 결합 성질이
/// 없는 spacing 점 글리프로 치환한다. IR 텍스트는 불변(측정/캐럿/텍스트추출
/// 보존)이며, 측정 폭 정합은 text_measurement 의 전각 분류로 맞춘다.
fn tone_mark_display(ch: char) -> Option<char> {
    match ch {
        '\u{302E}' => Some('\u{00B7}'), // 방점 → · MIDDLE DOT
        '\u{302F}' => Some('\u{205A}'), // 쌍방점 → ⁚ TWO DOT PUNCTUATION (세로 두 점)
        _ => None,
    }
}

/// 일반 텍스트 렌더링/paint contract 경로에서 한컴 PUA 문자를 표시 문자열로 확장한다.
///
/// HWP TAC filler `U+F081C` 는 레이아웃 측정에는 원문으로 남겨 0폭 규칙을
/// 적용하되, 실제 출력에서는 글리프가 없어 깨진 문자로 보이지 않도록 숨긴다.
///
/// Hanyang-PUA 옛한글은 KS X 1026-1:2007 자모 시퀀스로 확장한다.
///
/// CharOverlap 전용 숫자(`U+F02CE..=U+F02E1`)는 여기서 확장하지 않는다.
/// 해당 문자는 `pua_to_display_text()`가 글자겹침 렌더러에서만 처리한다.
pub fn expand_pua_display_text(text: &str) -> String {
    use super::pua_oldhangul::map_pua_old_hangul;

    let mut out = String::with_capacity(text.len());
    for ch in text.chars() {
        // [#5800] HWP5 원시 기호값을 먼저 평면-15 키로 정규화한다.
        let ch = hancom_symbol_display_key(ch);
        if ch == '\u{F081C}' {
            continue;
        }
        if let Some(dot) = tone_mark_display(ch) {
            out.push(dot);
        } else if let Some(replacement) = pua_plain_text_display(ch) {
            out.push_str(replacement);
        } else if let Some(jamos) = map_pua_old_hangul(ch) {
            out.extend(jamos.iter().copied());
        } else {
            out.push(super::layout::map_pua_bullet_char(ch));
        }
    }
    out
}

/// 일반 텍스트 렌더링 경로의 기존 helper 이름.
pub fn expand_pua_render_text(text: &str) -> String {
    expand_pua_display_text(text)
}

/// PUA 테두리 숫자와 한컴 PUA 기호를 표시 문자열로 변환한다. (렌더러 전용)
///
/// draw_char_overlap()에서 호출하여, 실제 렌더링 시에만 변환한다.
pub fn pua_to_display_text(ch: char) -> Option<String> {
    // [#5800] HWP5 원시 기호값을 먼저 평면-15 키로 정규화한다.
    let ch = hancom_symbol_display_key(ch);
    let cp = ch as u32;
    if let Some(replacement) = pua_plain_text_display(ch) {
        return Some(replacement.to_string());
    }
    // U+F02B1~F02C4 는 렌더러의 boxed_pua_char_overlap_semantics 가 먼저 처리한다 (#4158).
    // 반전 사각형 안의 숫자: U+F02CE(1) ~ U+F02E1(20)
    if (0xF02CE..=0xF02E1).contains(&cp) {
        let num = cp - 0xF02CD;
        return Some(format!("{}", num));
    }
    None
}

/// [#3385] **텍스트 추출 전용** PUA 표시 변환.
///
/// IR은 U+F02B1~F02C4(사각 안 숫자) 원문을 보존하고, 렌더러는 폰트 글리프 대신 결정적인
/// 사각형+숫자를 합성한다(#4158). 표준 ①~⑳ 로 직접 렌더하면 1순위 폰트의 *원 안* 글리프가
/// 잡혀 한컴 정답지의 *사각 안* 의미와 달라지므로 렌더 표시 문자열로는 사용하지 않는다.
///
/// 그러나 **텍스트 표면은 사정이 다르다.** 추출 결과는 폰트가 없는 소비자(RAG·LLM·grep)
/// 에게 가므로 원문 PUA 는 읽을 수 없는 코드포인트일 뿐이다. 그래서 렌더 결정은 그대로
/// 두고 텍스트 표면에서만 읽을 수 있는 문자로 바꾼다.
///
/// 의미를 모르는 PUA 는 **매핑을 지어내지 않고 그대로 둔다.**
pub fn pua_to_text_surface(text: &str) -> std::borrow::Cow<'_, str> {
    if !text
        .chars()
        .any(|ch| text_surface_replacement(ch).is_some())
    {
        return std::borrow::Cow::Borrowed(text);
    }
    let mut out = String::with_capacity(text.len());
    for ch in text.chars() {
        match text_surface_replacement(ch) {
            Some(rep) => out.push_str(&rep),
            None => out.push(ch),
        }
    }
    std::borrow::Cow::Owned(out)
}

fn text_surface_replacement(ch: char) -> Option<String> {
    let cp = ch as u32;
    // 사각 안 숫자 1~20 — IR은 원문을 유지하고 렌더는 사각형+숫자를 합성하지만, 텍스트
    // 표면에서는 둘러싸인 숫자라는 뜻이 전달되면 충분하다.
    if (0xF02B1..=0xF02C4).contains(&cp) {
        let n = cp - 0xF02B1; // 0-based
        return char::from_u32(0x2460 + n).map(|c| c.to_string());
    }
    // [#6127] U+F02B0 = 네모 안 0 (2599643 신청 번호란 "②⓪⓪") — 0 은 U+2460
    // 연속열 밖이라 ⓪(U+24EA) 를 따로 짝짓는다.
    if cp == 0xF02B0 {
        return Some('\u{24EA}'.to_string());
    }
    // [#5599] U+F02C5 는 연속 구간의 21이 아니라 **네모 12** 다 — 한글 2022 오라클
    // 실측(mel-001 p18 국정과제 bullet, PDF 좌표 절단 판정). 렌더는 위 대역과 같은
    // 원문 유지 계약이고, 텍스트 표면만 ⑫ 로 읽을 수 있게 바꾼다.
    if cp == 0xF02C5 {
        return Some('\u{246B}'.to_string());
    }
    // 렌더가 이미 표시 문자열을 갖고 있는 대역은 같은 답을 쓴다.
    if let Some(replacement) = pua_to_display_text(ch) {
        return Some(replacement);
    }
    // 렌더의 글리프 치환 표(`map_pua_bullet_char`)를 텍스트 표면에도 적용한다.
    //
    // 새 매핑을 지어내지 않고 **렌더가 이미 쓰는 표를 재사용**한다 — 근거(한컴 정답지
    // 실측)가 그 표에 붙어 있다. 사각 안 숫자(U+F02B1~F02C4)는 그 표와 별도로 위 분기가
    // 계속 담당한다.
    //
    // 규모: 저장소 샘플 346건 중 50건이 추출 텍스트에 PUA 를 흘렸고, 그중 U+F080F
    // (굵은 가로선 ━)만 155,709자다. hwp3-sample11.hwp 는 한 쪽 1,398자 중 181자가
    // 이 문자이고 최장 96자 연속 — 머리말/꼬리말 가로선이 본문 텍스트로 나갔다.
    let mapped = super::layout::map_pua_bullet_char(ch);
    if mapped != ch {
        return Some(mapped.to_string());
    }
    None
}
/// 조합된 텍스트 런에서 PUA 테두리 숫자 문자를 찾아 CharOverlap 런으로 변환한다.
///
/// PUA 문자는 원본 그대로 유지하되 CharOverlapInfo만 부착한다.
/// 이렇게 하면 PUA 문자가 항상 1글자로 유지되어:
/// - reflow_line_segs()의 텍스트 측정과 레이아웃 폭 계산이 일치
/// - 두 자리 숫자(10~20)도 1글자 = 1박스 = font_size 폭
///   실제 표시 문자열(PUA → "1", "10" 등) 변환은 draw_char_overlap()에서 수행한다.
fn convert_pua_enclosed_numbers(composed: &mut ComposedParagraph) {
    for line in composed.lines.iter_mut() {
        let mut new_runs: Vec<ComposedTextRun> = Vec::new();
        let mut changed = false;

        for run in line.runs.iter() {
            // 이미 CharOverlap인 런은 그대로 유지
            if run.char_overlap.is_some() {
                new_runs.push(run.clone());
                continue;
            }

            // PUA 테두리 숫자 문자가 있는지 확인
            let has_pua = run
                .text
                .chars()
                .any(|ch| pua_enclosed_border_type(ch).is_some());
            if !has_pua {
                new_runs.push(run.clone());
                continue;
            }

            changed = true;
            let mut buf = String::new();

            for ch in run.text.chars() {
                if let Some(border_type) = pua_enclosed_border_type(ch) {
                    // buf에 쌓인 일반 텍스트를 먼저 런으로 추가
                    if !buf.is_empty() {
                        new_runs.push(ComposedTextRun {
                            text: buf.clone(),
                            char_style_id: run.char_style_id,
                            lang_index: run.lang_index,
                            char_overlap: None,
                            footnote_marker: None,
                            display_text: None,
                            supplemental_metrics_blocked: run.supplemental_metrics_blocked,
                            inserted_control_text: run.inserted_control_text,
                            space_metric: run.space_metric,
                        });
                        buf.clear();
                    }
                    // PUA 문자 그대로 유지 + CharOverlapInfo 부착
                    new_runs.push(ComposedTextRun {
                        text: ch.to_string(),
                        char_style_id: run.char_style_id,
                        lang_index: run.lang_index,
                        char_overlap: Some(CharOverlapInfo {
                            border_type,
                            inner_char_size: 0,
                        }),
                        footnote_marker: None,
                        display_text: None,
                        supplemental_metrics_blocked: run.supplemental_metrics_blocked,
                        inserted_control_text: run.inserted_control_text,
                        space_metric: run.space_metric,
                    });
                } else {
                    buf.push(ch);
                }
            }

            // 남은 일반 텍스트
            if !buf.is_empty() {
                new_runs.push(ComposedTextRun {
                    text: buf,
                    char_style_id: run.char_style_id,
                    lang_index: run.lang_index,
                    char_overlap: None,
                    footnote_marker: None,
                    display_text: None,
                    supplemental_metrics_blocked: run.supplemental_metrics_blocked,
                    inserted_control_text: run.inserted_control_text,
                    space_metric: run.space_metric,
                });
            }
        }

        if changed {
            line.runs = new_runs;
        }
    }
}

mod line_breaking;
pub(crate) use line_breaking::{
    control_is_width_neutral_marker, frame_metrics_for_line, text_word_ranges,
};
pub mod lineseg_compare;

pub(crate) use line_breaking::{
    is_line_end_forbidden, is_line_start_forbidden, layout_paragraph_in_frame, layout_picture_band,
    paragraph_flow_end, recalculate_section_vpos, reflow_line_segs,
    reflow_line_segs_after_cell_split, reflow_line_segs_after_cell_text_edit,
    reflow_line_segs_in_stored_section, restamp_indentation, tokenize_paragraph, BreakToken,
    StoredRowMissPolicy,
};

#[cfg(test)]
mod lineseg_compare_tests;
#[cfg(test)]
mod re_sample_gen;
#[cfg(test)]
mod tests;

/// 공유 프레임이 저장 수식 메트릭을 실제 부분 재조판하는 경로인지 판별한다.
pub(crate) fn uses_remeasured_equation_frame(para: &Paragraph) -> bool {
    line_breaking::remeasured_equation_start_row(para).is_some()
        && line_breaking::supports_cached_body_frame_controls(para)
        && !para.stored_text_partition_is_dirty()
}
