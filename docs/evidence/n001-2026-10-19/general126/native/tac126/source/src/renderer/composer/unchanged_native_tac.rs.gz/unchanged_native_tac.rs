//! Source input identity plus consistent current table measurement.
//! Only selects Native's existing half-spacing policy. This proves neither
//! physical fit nor a source-row, reset, origin, or serialization authority.
use super::*;
use crate::renderer::height_measurer::MeasuredTable;
use crate::model::table::TablePageBreak;
fn exact(a:f64,b:f64)->bool{a.is_finite()&&b.is_finite()&&(a-b).abs()<=f64::EPSILON*a.abs().max(b.abs()).max(1.0)*8.0}
#[allow(clippy::too_many_arguments)]
pub(crate) fn unchanged_native_tac_spacing(index:usize,para:&Paragraph,next:Option<&Paragraph>,ci:usize,seg:&LineSeg,
    measurements:&[MeasuredTable],styles:&ResolvedStyleSet,dpi:f64)->bool{
    if ci!=0 || para.controls.len()!=1 || !para.text.is_empty() || para.char_count!=9
      || !para.char_offsets.is_empty() || para.line_segs.len()!=1
      || !std::ptr::eq(seg,&para.line_segs[0]) || seg.text_start!=0
      || seg.tag&LineSeg::TAG_IMPLEMENTATION_PROPERTY!=0 || seg.line_spacing<=0
      || seg.line_height<=0 || seg.text_height<=0 || seg.text_height>seg.line_height
      || seg.baseline_distance<0 || seg.baseline_distance>seg.line_height
      || para.stored_text_partition_is_dirty() || para.hwpx_axis_shift!=0
      || para.source_line_seg_vertical_pos.is_some() || para.cell_format_vpos_dirty
      || !para.field_ranges.is_empty() || !para.range_tags.is_empty()
      || !para.orphan_field_ends.is_empty() || !para.tab_extended.is_empty()
      || !dpi.is_finite() || dpi<=0.0 {return false;}
    if seg.vertical_pos<0 || seg.vertical_pos.checked_add(seg.line_height).and_then(|v|v.checked_add(seg.line_spacing)).is_none(){return false;}
    let Control::Table(table)=&para.controls[0]else{return false;};
    let mut owners=measurements.iter().filter(|m|m.para_index==index&&m.control_index==ci);
    let Some(measured)=owners.next()else{return false;};if owners.next().is_some(){return false;}
    if measured.para_index!=index || measured.control_index!=ci
      || !table.common.treat_as_char || table.page_break!=TablePageBreak::None
      || table.caption.is_some() || table.repeat_header || table.common.allow_overlap
      || table.common.horizontal_offset!=0 || table.common.vertical_offset!=0
      || table.common.width==0 || table.common.height==0 || table.common.height>=0x80000000
      || table.row_count==0 || table.row_count>128 || table.col_count==0 || table.col_count>32
      || measured.caption_height!=0.0 || measured.row_heights.len()!=table.row_count as usize
      || measured.row_heights.iter().any(|h|!h.is_finite()||*h<=0.0)
      || measured.cumulative_heights.len()!=measured.row_heights.len()+1
      || !exact(measured.total_height,hwpunit_to_px(table.common.height as i32,dpi))
      || !exact(*measured.cumulative_heights.last().unwrap_or(&f64::NAN),measured.total_height)
      || table.cells.iter().any(|c|c.dirty_flag||c.paragraphs.iter().any(|p|!p.controls.is_empty()||!p.field_ranges.is_empty())) {return false;}
    if !measured.cell_spacing.is_finite() || measured.cell_spacing<0.0 || measured.cumulative_heights.first()!=Some(&0.0){return false;}
    let mut cursor=0.0;
    for (i,height) in measured.row_heights.iter().enumerate(){
        cursor+=*height;if i>0{cursor+=measured.cell_spacing;}
        if !cursor.is_finite() || !exact(measured.cumulative_heights[i+1],cursor){return false;}
    }
    if !exact(cursor,measured.total_height){return false;}
    let margins=[table.outer_margin_left,table.outer_margin_right,table.outer_margin_top,table.outer_margin_bottom];
    if margins.iter().any(|v|*v<0) || table.common.margin.left!=margins[0]
      || table.common.margin.right!=margins[1] || table.common.margin.top!=margins[2]
      || table.common.margin.bottom!=margins[3] {return false;}
    // The half-spacing formula reads no frame top, width, or available height.
    // Allocation/overflow checks remain with the existing layout pipeline.
    crate::model::raw_provenance::unchanged_native_tac_spacing_input(index,para,next,styles.reset_flow_context,
      styles.supplemental_metrics.is_none()&&styles.kerning_measurement_context.is_none()&&styles.horizontal_shaping_context.is_none())
}
