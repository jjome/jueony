from pathlib import Path
import json,hashlib,re,difflib
r=Path(__file__).resolve().parents[1];base=r/'build/rhwp-engine/source-0e3889eb2b6d0102';stage=r/'build/n001-standard140-merged';stage.mkdir(exist_ok=True);changes={}
p='src/renderer/current_frame_rows_plan.rs';s=(base/p).read_text(encoding='utf8')
helper='''
/// An already exact ordinary standard cache keeps its existing serialization.
/// This is an omission from the new projection, never a source-row capability:
/// full fresh allocation and physical closure still run for this paragraph.
/// Generated implementation-property rows are never retagged or masked.
fn retains_ordinary_standard_body(p:&crate::model::paragraph::Paragraph,rows:&[LineSeg])->bool{
 if p.text.is_empty()||p.stored_text_partition_is_dirty()||p.layout_only_fill_lines!=0
  ||p.cell_format_vpos_dirty||p.completed_native_rows.is_some()||p.line_segs.len()!=rows.len()||rows.is_empty(){return false;}
 if let Some(v)=p.source_line_seg_vertical_pos.as_ref(){
  if v.len()==rows.len()&&!v.iter().zip(rows).all(|(y,r)|*y==r.vertical_pos){return false;}}
 p.line_segs.iter().zip(rows).all(|(a,b)|a.tag==LineSeg::TAG_SINGLE_SEGMENT_LINE
  &&b.tag==(LineSeg::TAG_SINGLE_SEGMENT_LINE|LineSeg::TAG_IMPLEMENTATION_PROPERTY)
  &&a.text_start==b.text_start&&a.vertical_pos==b.vertical_pos&&a.line_height==b.line_height
  &&a.text_height==b.text_height&&a.baseline_distance==b.baseline_distance&&a.line_spacing==b.line_spacing
  &&a.column_start==b.column_start&&a.segment_width==b.segment_width)
}
'''
s=s.replace('fn same_selected_line(',helper+'fn same_selected_line(',1)
old='rows.push(CurrentFrameParagraphRows{kind:CurrentFrameRowKind::FreshBody,section:0,paragraph:*pi,rows:projected});'
assert s.count(old)==1;s=s.replace(old,'if !retains_ordinary_standard_body(p,&projected){'+old+'}')
s=s.replace('let rows=fresh.to_vec();Some(CurrentFrameRowsPlan{','if retains_ordinary_standard_body(&self.prefix.source().sections[0].paragraphs[0],fresh){return None;}\n  let rows=fresh.to_vec();Some(CurrentFrameRowsPlan{',1);changes[p]=s.encode()
p='src/renderer/current_page_frames135.rs';s=(base/p).read_text(encoding='utf8');old='rows.push(CurrentFrameParagraphRows{kind:CurrentFrameRowKind::FreshBody,section:section_index,paragraph:*pi,rows:projected});';assert s.count(old)==1;s=s.replace(old,'if !retains_ordinary_standard_body(p,&projected){'+old+'}');changes[p]=s.encode()
p='src/renderer/current_frame_rows_plan_tests.rs';s=(base/p).read_text(encoding='utf8');s+='''
 #[test]fn existing_exact_standard_body_is_left_with_ordinary_writer_without_retagging(){
  let mut input=vec![];flate2::read::GzDecoder::new(OWN_FIXTURE_GZIP).read_to_end(&mut input).unwrap();
  let core=crate::DocumentCore::from_bytes(&input).unwrap();let mut p=core.document().sections[0].paragraphs[0].clone();
  assert!(!p.text.is_empty());p.stored_text_partition_dirty=false;p.completed_native_rows=None;p.cell_format_vpos_dirty=false;p.layout_only_fill_lines=0;
  let styles=core.resolve_render_styles_for_section(0);let fresh=fresh_body_rows(&p,&styles,core.pagination[0].pages[0].layout.body_area.width,core.dpi).unwrap().rows;
  p.line_segs=fresh.clone();for r in &mut p.line_segs{r.tag=LineSeg::TAG_SINGLE_SEGMENT_LINE;}
  p.source_line_seg_vertical_pos=None;assert!(retains_ordinary_standard_body(&p,&fresh));
  assert!(fresh.iter().all(|r|r.tag==(LineSeg::TAG_SINGLE_SEGMENT_LINE|LineSeg::TAG_IMPLEMENTATION_PROPERTY)));
  for field in 0..14{let mut bad=p.clone();match field{
   0=>bad.line_segs[0].text_start+=1,1=>bad.line_segs[0].vertical_pos+=1,2=>bad.line_segs[0].line_height+=1,
   3=>bad.line_segs[0].text_height+=1,4=>bad.line_segs[0].baseline_distance+=1,5=>bad.line_segs[0].line_spacing+=1,
   6=>bad.line_segs[0].column_start+=1,7=>bad.line_segs[0].segment_width+=1,8=>bad.line_segs[0].tag|=1,
   9=>bad.line_segs[0].tag|=LineSeg::TAG_IMPLEMENTATION_PROPERTY,10=>bad.cell_format_vpos_dirty=true,
   11=>bad.layout_only_fill_lines=1,12=>bad.invalidate_layout_inputs(),_=>bad.source_line_seg_vertical_pos=Some(fresh.iter().map(|r|r.vertical_pos+1).collect())}
   assert!(!retains_ordinary_standard_body(&bad,&fresh),"field {field}");}
 }
''';changes[p]=s.encode()
# Recompute the existing complete source-resource identity without dropping inputs.
p='src/model/native_computed_resource.rs';resource=(base/p).read_bytes().replace(b'\r\n',b'\n');paths=re.findall(rb'\("([^"]+)",include_bytes!',resource);h=hashlib.sha256(b'rhwp-portable-native-text-edit-frame-1;source-text-lf\0')
for raw in paths:
 name=raw.decode();b=changes.get(name,(base/name).read_bytes().replace(b'\r\n',b'\n'));h.update(raw);h.update(b'\0');h.update(len(b).to_bytes(8,'little'));h.update(b)
resource=re.sub(rb'pub\(crate\) const RESOURCE:\[u8;32\]=\[[^\]]+\];',('pub(crate) const RESOURCE:[u8;32]=['+', '.join(map(str,h.digest()))+'];').encode(),resource);changes[p]=resource
patch=''
for p,b in sorted(changes.items()):
 before=(base/p).read_bytes().replace(b'\r\n',b'\n');dest=stage/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 patch+=''.join(difflib.unified_diff(before.decode().splitlines(True),b.decode().splitlines(True),fromfile='a/'+p,tofile='b/'+p))
target=r/'engine/patches'/('z'*119+'-retain-exact-ordinary-body-rows.patch');assert not target.exists() or hashlib.sha256(target.read_bytes()).hexdigest()=='41335a99b867e869aed1694ef25ae1684d55e2dd08770192cf627d87d4ce3fce';target.write_bytes(patch.encode())
(stage/'merge-proof.json').write_text(json.dumps({'base':str(base.relative_to(r)),'resourceCount':len(paths),'retainedAllExistingInOrder':True,'resourceSha256':h.hexdigest(),'patch':str(target.relative_to(r)),'patchSha256':hashlib.sha256(target.read_bytes()).hexdigest()},indent=2)+'\n',encoding='utf8')
print((stage/'merge-proof.json').read_text())
