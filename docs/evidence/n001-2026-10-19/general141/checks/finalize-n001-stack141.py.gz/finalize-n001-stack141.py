from pathlib import Path
import json
r=Path(__file__).resolve().parents[1];stage=r/'build/n001-stack141-merged';name='src/renderer/current_page_frames135.rs';p=stage/name;s=p.read_text(encoding='utf8')
assert s.count('INCOMING_FLOW_PLACEHOLDER')==1;s=s.replace('INCOMING_FLOW_PLACEHOLDER','rect.y+t.flow_before-unpainted')
assert s.count('tables:tables.clone()')==1;s=s.replace('tables:tables.clone()','tables:tables.iter().filter(|t|arithmetic_equal(t.incoming,t.top)).cloned().collect()')
s=s.replace('for v in[t.top,t.before,t.body,t.after]','for v in[t.incoming,t.top,t.before,t.body,t.after]');p.write_text(s,encoding='utf8',newline='\n')
(stage/'extra-files.json').write_text(json.dumps([name])+'\n',encoding='utf8')
