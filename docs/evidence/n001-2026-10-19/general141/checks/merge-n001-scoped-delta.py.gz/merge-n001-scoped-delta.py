from pathlib import Path
import sys,json,re,hashlib,subprocess,posixpath,difflib
r=Path(__file__).resolve().parents[1];mode=sys.argv[1]
configs={
 'scope138':('af95242fa3d7c125','af95242fa3d7c125','build/n001-prefix-scope138/handoff','source-proof.json','changed',117,'-current-frame-source-admission.patch'),
 'frames139':(sys.argv[2]if len(sys.argv)>2 else '', '673d48cdf729e05c','build/n001-frames135/handoff-final','root-merge-input.json','files',118,'-current-page-section-frames.patch'),
 'stack141':(sys.argv[2]if len(sys.argv)>2 else '', '475fccf2d4087217','build/n001-equal-stack137/handoff-equal-final','source-proof.json','files',120,'-current-bodywide-column-stack.patch'),
 'suffix142':(sys.argv[2]if len(sys.argv)>2 else '', '673d48cdf729e05c','build/n001-suffix135-ledger3/handoff-final','root-logic-input.json','files',121,'-current-suffix-required-paint.patch')}
curid,baseid,area,manifest,field,count,suffix=configs[mode];assert re.fullmatch('[0-9a-f]{16}',curid)
current=r/('build/rhwp-engine/source-'+curid);base=r/('build/rhwp-engine/source-'+baseid);incoming=r/area
assert current.is_dir(),current
assert base.is_dir(),base
stage=r/('build/n001-'+mode+'-merged');stage.mkdir(exist_ok=True)
def lf(b):return b.replace(b'\r\n',b'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
records=[];conflicts=[];changes={}
for e in json.loads((r/'build/n001-suffix142-input/root-logic-input.json'if mode=='suffix142'else incoming/manifest).read_bytes())[field]:
 p=e['path'];assert p.startswith('src/')and '..'not in Path(p).parts
 if p=='src/model/native_computed_resource.rs':continue
 raw=(incoming/'runtime'/p).read_bytes();new=lf(raw)
 assert sha(new)==e.get('canonicalSha256',sha(new))and sha(raw)==e.get('rawSha256',sha(raw)),p
 original=lf((base/p).read_bytes())if(base/p).is_file()else b''
 if 'baseCanonicalSha256'in e:assert(sha(original)if original else None)==e['baseCanonicalSha256'],p
 before=lf((current/p).read_bytes())if(current/p).is_file()else b''
 if before==original:merged=new;method='direct'
 elif before==new:merged=before;method='identical'
 else:
  work=stage/'merge-work'/str(len(records));work.mkdir(parents=True,exist_ok=True)
  for name,b in [('current',before),('base',original),('incoming',new)]:(work/name).write_bytes(b)
  q=subprocess.run(['git','merge-file','-p','--diff3',str(work/'current'),str(work/'base'),str(work/'incoming')],cwd=r,stdout=subprocess.PIPE,stderr=subprocess.PIPE);merged=q.stdout;method='three-way'
  if q.returncode:conflicts.append(p)
 dest=stage/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(merged)
 records.append({'path':p,'base':sha(original)if original else None,'current':sha(before)if before else None,'incoming':sha(new),'merged':sha(merged),'method':method})
 if merged!=before:changes[p]=merged
(stage/'initial-merge-proof.json').write_text(json.dumps({'records':records,'conflicts':conflicts},indent=2)+'\n',encoding='utf8')
if conflicts:print(json.dumps({'conflicts':conflicts}));raise SystemExit(1)
resource=lf((current/'src/model/native_computed_resource.rs').read_bytes());paths=re.findall(rb'\("([^"]+)",include_bytes!',resource);old=paths[:]
for raw in re.findall(rb'\("([^"]+)",include_bytes!',lf((incoming/'runtime/src/model/native_computed_resource.rs').read_bytes())):
 if raw in paths:continue
 path=raw.decode();line=f'            ("{path}",include_bytes!("{posixpath.relpath(path,"src/model")}").as_slice()),\n'.encode()
 resource=resource.replace(b'        ];\n        let mut h=Sha256::new();',line+b'        ];\n        let mut h=Sha256::new();');paths.append(raw)
assert paths[:len(old)]==old and re.findall(rb'\("([^"]+)",include_bytes!',resource)==paths
h=hashlib.sha256(b'rhwp-portable-native-text-edit-frame-1;source-text-lf\0');inputs=[]
for raw in paths:
 path=raw.decode();b=changes.get(path,lf((current/path).read_bytes())if(current/path).is_file()else None);assert b is not None,path
 h.update(raw);h.update(b'\0');h.update(len(b).to_bytes(8,'little'));h.update(b);inputs.append({'path':path,'sha256':sha(b)})
resource=re.sub(rb'pub\(crate\) const RESOURCE:\[u8;32\]=\[[^\]]+\];',('pub(crate) const RESOURCE:[u8;32]=['+', '.join(map(str,h.digest()))+'];').encode(),resource);changes['src/model/native_computed_resource.rs']=resource
patch=''
for p,b in sorted(changes.items()):
 before=lf((current/p).read_bytes())if(current/p).is_file()else b'';dest=stage/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 patch+=''.join(line if line.endswith('\n')else line+'\n\\ No newline at end of file\n'for line in difflib.unified_diff(before.decode().splitlines(True),b.decode().splitlines(True),fromfile='a/'+p if before else '/dev/null',tofile='b/'+p))
target=r/'engine/patches'/('z'*count+suffix);assert not target.exists()or(mode=='stack141'and sha(target.read_bytes())=='518d54b0c680ea3fb26f0ba50088b5781acf93024ea8eb2733b7d35a7e61d01c');target.write_bytes(patch.encode())
proof={'base':'source-'+curid,'incomingBase':'source-'+baseid,'records':records,'resourceCount':len(paths),'retainedAllExistingInOrder':True,'resourceSha256':h.hexdigest(),'resourceInputs':inputs,'patch':str(target.relative_to(r)),'patchSha256':sha(target.read_bytes()),'conflicts':[]}
(stage/'merge-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8');print(json.dumps({k:v for k,v in proof.items()if k not in('records','resourceInputs')},indent=2))
