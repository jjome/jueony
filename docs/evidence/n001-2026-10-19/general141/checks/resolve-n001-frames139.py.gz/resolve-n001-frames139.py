from pathlib import Path
import re
r=Path(__file__).resolve().parents[1];stage=r/'build/n001-frames139-merged'
for name in ['src/document_core/commands/document.rs','src/document_core/queries/rendering.rs','src/renderer/current_frame_rows_plan.rs','src/renderer/current_frame_rows_plan_tests.rs']:
 p=stage/name;s=p.read_text(encoding='utf8')
 def resolve(m):
  a,b,c=m.group(1,2,3)
  if name.endswith('commands/document.rs'):
   needle='          }else{return Ok(None);};'
   # Keep the document-frame lane before the existing independently proved prefix lane.
   assert needle.strip() in c
   c=c.replace('}else{return Ok(None);};','}else{'+a.split('}else{',1)[1])
   return c
  if name.endswith('queries/rendering.rs'):
   return '            prefix_capture_plan.or_else(||current_frame_candidate.as_ref().map(|p|p.paint_plan())).or(page_frames_paint),\n'
  assert not b.strip();return a+c
 s,n=re.subn(r'^<<<<<<<[^\n]*\n(.*?)^\|\|\|\|\|\|\|[^\n]*\n(.*?)^=======\n(.*?)^>>>>>>>[^\n]*\n',resolve,s,flags=re.M|re.S)
 assert n==1,(name,n);assert '<<<<<<<'not in s;p.write_text(s,encoding='utf8',newline='\n')
# Finish using the already validated merge inputs and explicit conflict resolutions.
script=(r/'build/merge-n001-scoped-delta.py').read_text(encoding='utf8')
tail=script[script.index('resource=lf('):]
prefix=script[:script.index('records=[];')]
resume='''
records=json.loads((stage/'initial-merge-proof.json').read_bytes())['records'];changes={}
for record in records:
 p=record['path'];b=lf((stage/p).read_bytes());assert b'<<<<<<<'not in b
 record['merged']=sha(b);record['explicitResolution']=record['path']in json.loads((stage/'initial-merge-proof.json').read_bytes())['conflicts']
 before=lf((current/p).read_bytes())if(current/p).is_file()else b''
 if b!=before:changes[p]=b
'''
exec(compile(prefix+resume+tail,str(r/'build/merge-n001-scoped-delta.py'),'exec'))
