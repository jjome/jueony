from pathlib import Path
import re
r=Path(__file__).resolve().parents[1];stage=r/'build/n001-stack141-merged'
names=['src/document_core/commands/document.rs','src/document_core/queries/rendering.rs','src/renderer/current_frame_rows_plan.rs','src/renderer/current_physical_selections.rs','src/renderer/layout.rs']
for name in names:
 p=stage/name;s=p.read_text(encoding='utf8')
 def resolve(m):
  a,b,c=m.group(1,2,3)
  if name.endswith('queries/rendering.rs'):
   assert '.or(page_frames_paint)'in a
   return c.replace('prefix_capture_plan.or_else(||current_frame_candidate.as_ref().map(|p|p.paint_plan())).or_else', 'prefix_capture_plan.or_else(||current_frame_candidate.as_ref().map(|p|p.paint_plan())).or(page_frames_paint).or_else')
  assert not b.strip(),name;return a+c
 s,n=re.subn(r'^<<<<<<<[^\n]*\n(.*?)^\|\|\|\|\|\|\|[^\n]*\n(.*?)^=======\n(.*?)^>>>>>>>[^\n]*\n',resolve,s,flags=re.M|re.S)
 assert n>=1,(name,n);assert '<<<<<<<'not in s;p.write_text(s,encoding='utf8',newline='\n')
# Existing multi-page schema keeps its own actual allocator input and no standard-anchor override.
name='src/renderer/current_page_frames135.rs';p=stage/name;p.parent.mkdir(parents=True,exist_ok=True)
s=(r/'build/rhwp-engine/source-38a6c6b20a6182f3'/name).read_text(encoding='utf8')
old='CandidateTable{paragraph:*pi,control:0,top,before:'
assert s.count(old)==1
s=s.replace(old,'CandidateTable{paragraph:*pi,control:0,incoming:INCOMING_FLOW_PLACEHOLDER,standard_anchor:None,top,before:')
p.write_text(s,encoding='utf8',newline='\n')
