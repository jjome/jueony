from pathlib import Path
import json,hashlib,gzip,re,shutil
r=Path(__file__).resolve().parents[1];out=r/'docs/evidence/n001-2026-10-19/general141';area=r/'build';profile='n001-stack141';pkg=area/'rhwp-engine/source-393f7940079a511f/pkg';mirror=area/'n001-review132-clean'
read=lambda p:json.loads(p.read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest()
engine=read(pkg/'jueony-engine-build.json');assert engine['sourceId']=='393f7940079a511f'and len(engine['patches'])==136
w=read(area/(profile+'-established-workflows/result.json'));assert w['passedCases']==w['totalCases']==501 and not w['failures']and len(w['suites'])==41
assert w['engine']['sourceId']==engine['sourceId']
p=read(area/(profile+'-public/result.json'));c=read(area/(profile+'-corpus/result.json'));u=read(area/(profile+'-general-ui/result.json'))
assert len(p['results'])==56 and len(p['failures'])==4;assert len(c['results'])==88 and len(c['failures'])==9
assert len(u['results'])==29 and sum(x['status']=='PASS'for x in u['results'])==26 and u['fullMatrix'];assert not u['pageErrors']and not u['externalRequests']and len(u['consoleErrors'])==2
coverage=read(area/(profile+'-composition/result.json'));assert coverage['pass']==14 and coverage['fail']==0
audit=read(area/(profile+'-live-audit/result.json'));assert len(audit['observations'])==93 and not audit['failures'];assert sum(x['stableGeometryRequired']for x in audit['observations'])==37
unit=(area/(profile+'-unit.log')).read_text(encoding='utf8');assert '# pass 1036'in unit and '# fail 0'in unit and '# skipped 0'in unit
assert not(area/(profile+'-typecheck.log')).read_text().strip();assert read(area/(profile+'-boundaries.log'))['diagnostics']==[]
native=(area/(profile+'-native.log')).read_text(encoding='utf8');assert re.findall(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored',native)==['25','2','1']
app=read(area/'n001-general132-clean-source-proof.json')
for e in app['files']:assert sha((mirror/e['path']).read_bytes())==e['sha256']
unrelated=read(area/'n001-general125-unrelated-initial.json');preserved=[]
for name,expected in unrelated.items():
 if name=='README.md':continue
 assert sha((r/name).read_bytes())==expected,name;preserved.append({'path':name,'sha256':expected})
extras=read(area/'n001-extra141/summary.json');assert not extras['failures']and all(x['status']=='PASS'for x in extras['results'])and len(extras['results'])==5
bundle=read(area/'n001-stack141-bundle-check/result.json');assert bundle['passed']==7 and bundle['failed']==0 and bundle['build']['engineWasmSha256']==engine['wasmSha256']
assert len(preserved)==45;assert not out.exists();out.mkdir(parents=True)
def copy(src,dst,compressed=True):
 src=Path(src);src=src if src.is_absolute()else r/src;b=src.read_bytes();dest=out/(dst+'.gz'if compressed else dst);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(b,mtime=0)if compressed else b)
copy(area/(profile+'-established-workflows/result.json'),'workflows/result.json',False)
for suite in w['suites']:
 name=suite['name'];script=mirror/'apps/editor/scripts'/('verify-'+name+'.mjs');assert sha(script.read_bytes())==suite['verifierSHA256']
 copy(area/(profile+'-established-workflows')/name/'result.json','workflows/'+name+'/result.json');copy(area/(profile+'-established-workflows/logs')/(name+'.log'),'workflows/logs/'+name+'.log');copy(script,'verifiers/'+script.name)
for mode in ['public','corpus','general-ui','composition','live-audit']:
 copy(area/(profile+'-'+mode+'/result.json'),'general/'+mode+'/result.json',mode in ['public','corpus','general-ui']);copy(area/(profile+'-'+mode+'.log'),'general/'+mode+'/run.log')
for src in(area/(profile+'-live-audit')).rglob('*.json'):
 if src.name!='result.json':copy(src,'general/live-audit/'+src.relative_to(area/(profile+'-live-audit')).as_posix())
for mode in ['build','unit','typecheck','boundaries','official-build','native','established']:
 copy(area/(profile+'-'+mode+'.log'),'checks/'+mode+'.log')
copy(area/'n001-extra141/summary.json','extras/summary.json',False)
for row in extras['results']:
 copy(area/'n001-extra141'/row['name']/'result.json','extras/'+row['name']+'/result.json');copy(area/'n001-extra141'/(row['name']+'.log'),'extras/'+row['name']+'/run.log')
copy(area/'n001-stack141-bundle-check/result.json','bundle/result.json',False)
for name in ['bundle-build','bundle-check']:copy(area/('n001-stack141-'+name+'.log'),'checks/'+name+'.log')
for name in ['audit-general-live-layout132.mjs','verify-current-composition133.mjs']:copy(r/'apps/editor/scripts'/name,'verifiers/'+name)
for ordinal,e in enumerate(engine['patches'],1):
 src=r/'engine/patches'/e['name'];assert sha(src.read_bytes())==e['sha256'],e['name']
 if ordinal>126:copy(src,f'patches/{ordinal:03}.patch')
for folder in ['n001-frame132-merged','n001-accepted133-merged','n001-object134-merged','n001-offset135-merged','n001-prefix136-merged','n001-issuer137-merged','n001-scope138-merged','n001-frames139-merged','n001-standard140-merged','n001-stack141-merged']:
 for name in ['merge-proof.json','formatter-merge-proof.json','initial-merge-proof.json']:
  if(area/folder/name).is_file():copy(area/folder/name,'source/'+folder+'/'+name)
for src,name in [(pkg/'jueony-engine-build.json','source/engine-build.json'),(area/'n001-general132-clean-source-proof.json','source/application-archive.json'),(mirror/'apps/editor/evidence/dist-n001-stack141/build-evidence.json','source/application-build.json'),(area/'n001-stack141-native/preparation.json','source/native-identical-source.json'),(area/'n001-unequal-prefix139/ordinary-standard-body140-static-review.json','source/ordinary-standard-body-static-review.json')]:copy(src,name)
for folder in ['n001-frame132-public','n001-object134-public','n001-object134-corpus','n001-prefix136-corpus','n001-issuer137-established-workflows','n001-object134-old-reader']:
 if(area/folder/'result.json').exists():copy(area/folder/'result.json','before/'+folder+'/result.json')
for name in ['n001-standard140-native.log','n001-standard140-official-build-retry.log','n001-stack141-prepare.log','n001-stack141-prepare-retry.log','n001-frames139-wrong-id-attempt.json','n001-stack141-invalid-eof-patch-proof.json']:
 if(area/name).exists():copy(area/name,'before/'+name)
for folder in ['n001-frames135/handoff-final','n001-equal-stack137/handoff-equal-final','n001-prefix-scope138/handoff','n001-issuer135/handoff-final']:
 for src in(area/folder).rglob('*'):
  if src.is_file():copy(src,'native/'+folder+'/'+src.relative_to(area/folder).as_posix())
for name in ['run-n001-stack141-checks.py','run-n001-stack141-pipeline.py','prepare-n001-stack141-native.py','n001-stack141-native.sh','merge-n001-scoped-delta.py','resolve-n001-frames139.py','resolve-n001-stack141.py','finish-n001-scoped-merge.py','finalize-n001-stack141.py','create-n001-standard-body140.py','seal-n001-checkpoint141.py']:copy(area/name,'checks/'+name)
summary={'engine':engine,'workflowCases':501,'workflowSuites':41,'unitTests':1036,'unitSkipped':0,'nativeTests':28,'resourceInputs':261,'extras':extras['results'],'bundleChecks':7,'public':{'passed':52,'total':56,'failed':4},'corpus':{'passed':79,'total':88,'failed':9},'app':{'passed':26,'total':29,'failed':3,'browserExceptions':0,'externalRequests':0,'refusalConsoleErrors':2},'prefixCoverage':{'passed':14,'total':14,'paragraphScope':'first body paragraph only'},'independentReaders':{'observations':93,'requiredStable':37,'requiredStableDifferences':0,'otherDeltasRetained':True},'unchangedWorkingFiles':preserved,'scope':'N001 only; Native runtime Rust; ordinary/report/password/disk/history; Hancom deferred; unrelated45 excluded','complete':False,'remainingPublic':p['failures'],'remainingCorpus':[{'name':x['name'],'error':x['error']}for x in c['failures']]}
(out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(out/'README.md').write_text('''# N001 checkpoint141: actual composition and frames

Runtime changes are Rust. Exact official source393f7940079a511f,136patches,
261resource inputs. The existing41-suite501 workflow cases and1036 TypeScript
unit tests pass, with28 merged Native tests; no skipped tests. Full production
semantic and geometry guards were unchanged. No GUI/Hancom, provider calls,
credentials or user documents/windows were used.45 unrelated changes stayed exact.

Public editing:52/56. Fixed own Native22/XML22:79/88. Actual isolated headless
application:26/29 (2 refused saves plus error aggregate). Remaining failures are
retained in summary.json and original compressed results. This is not completion.

Sources are mandatory fresh/allocator/physical proofs, never old-row permission.
Known offsets, interleaved/new tables, equal configured columns, explicit page
and section frames are separately admitted; valid plans fail closed at output.
The exact existing ordinary body rows are omitted from new projections without
retagging. Full fresh/physical checks still run. All original source-resource
inputs remain. Intermediate merge/compile errors and fixed regressions are kept.

Independent old126/new141 observations:93, with37 required stable Native layouts
unchanged. Other multi-column changes and earlier-reader interop limits are
recorded; this is not Hancom compatibility proof. Prefix coverage checks onlyp0.

Run `python verify.py` to verify evidence bytes. Larger originals are deterministic
gzip files. The original44 fixed input files were never regenerated.
''',encoding='utf8')
shutil.copy2(r/'docs/evidence/n001-2026-10-19/general126/verify.py',out/'verify.py')
files=[{'path':p.relative_to(out).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}for p in sorted(out.rglob('*'))if p.is_file()]
(out/'SHA256-MANIFEST.json').write_text(json.dumps({'files':files},indent=2)+'\n',encoding='utf8');print('sealed',len(files),'files')
