//! rhwp — Rust HWP 뷰어/에디터
//!
//! 본 제품은 한글과컴퓨터의 한글 문서 파일(.hwp) 공개 문서를 참고하여 개발하였습니다.

use wasm_bindgen::prelude::*;

pub mod hwt_leaf115;
pub mod agent;
pub mod agent_seal;
pub mod capabilities_schema;
pub mod diagnostics;
pub mod docdiff;
pub mod doclang;
pub mod document_core;
pub mod emf;
pub mod eps;
pub mod error;
pub use rhwp_contracts::ir_schema;
pub mod model;
pub mod ole_chart;
pub use rhwp_contracts::ontology;
pub use rhwp_ooxml_chart as ooxml_chart;
pub mod paint;
pub mod parser;
pub use rhwp_password_crypto as password_crypto;
pub mod plan_schema;
pub mod pq_sign;
pub use rhwp_contracts::provenance;
pub mod rag;
pub mod render_backend;
pub mod renderer;
pub mod scaffold;
pub mod schema_registry;
pub mod security_trailer;
pub mod serializer;
pub mod service;
/// 핫패치 벤더(Dioxus subsecond) 어댑터. **rhwp 의 API 가 아니다** (#4580).
///
/// `pub` 인 이유는 `tools/rhwp-subsecond` 가 `link_wasm_exports()` 를 불러 wasm export 를 살려
/// 둬야 하기 때문이지, 이 안의 함수들을 밖에서 쓰라는 뜻이 아니다. 격리 자체는 feature 가 이미
/// 지킨다 — `subsecond-dev` 없이는 모듈이 존재하지 않으므로 릴리스 표면에는 처음부터 나오지
/// 않는다. `#[doc(hidden)]` 은 그 사실을 문서에도 적는 것이다.
#[doc(hidden)]
#[cfg(feature = "subsecond-dev")]
pub mod subsecond_dev;
pub mod wasm_api;
pub mod wmf;

pub use document_core::DocumentCore;
pub use error::HwpError;
pub use model::event::DocumentEvent;
pub use parser::{parse_document, parse_document_with_password, DocumentParser};
pub use serializer::{serialize_document, DocumentSerializer};

/// WASM panic hook 초기화 (한 번만 실행)
#[wasm_bindgen(start)]
pub fn init_panic_hook() {
    #[cfg(feature = "console_error_panic_hook")]
    console_error_panic_hook::set_once();
}

#[wasm_bindgen]
pub fn version() -> String {
    env!("CARGO_PKG_VERSION").to_string()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_version() {
        assert_eq!(version(), env!("CARGO_PKG_VERSION"));
    }
}

/// Own private diagnostic only; excluded from production delta.
pub fn private_equal_stack137(core:&DocumentCore)->serde_json::Value{
 let styles=core.resolve_render_styles_for_section(0);let Some(result)=core.pagination.first()else{return serde_json::json!(null)};
 let page=&result.pages[0];let tree=core.build_page_tree_with_current_selections(0).unwrap();let ph=&tree.frame.current_physical_selections;
 let tables=ph.tables().unwrap().iter().map(|t|serde_json::json!({"paragraph":t.paragraph,"control":t.control,"incoming":t.incoming_y,"paraY":t.paragraph_y,"top":t.selected_y,"inset":t.selected_outer_inset,"height":t.visual_height,"end":t.visual_end,"flowEnd":t.flow_end,"lane":t.lane_input,"typed":t.typed_float})).collect::<Vec<_>>();
 let c=renderer::current_frame_rows_plan::CurrentEqualColumnStackCandidate::from_current(&core.document,core.source_format,result,&styles,&core.measured_tables[0],core.effective_layout_profile(),core.dpi);
 let candidate=c.is_some();let finalized=if let Some(c)=c{let own=core.build_page_tree_with_equal_stack_capture(0,&c).unwrap();c.finalize(&own.frame.current_physical_selections).is_some()}else{false};
 let tr=result.selected_composition_trace.as_ref().unwrap();core.layout_engine.prime_column_layout_env(&page.layout);
 let reserved=core.layout_engine.calculate_body_wide_shape_reserved(&core.document.sections[0].paragraphs,&page.column_contents,&page.layout.body_area);
 serde_json::json!({"candidate":candidate,"finalized":finalized,"sourceMatch":tr.matches_source(&core.document.sections[0].paragraphs,styles.reset_flow_context,core.effective_layout_profile(),core.dpi),"frameMatch":tr.matches_finalized_result(result),"wholeTables":tr.whole_tables(),"commits":tr.commits(),"pageDebug":format!("{:?}",page),"bodyArea":[page.layout.body_area.x,page.layout.body_area.y,page.layout.body_area.width,page.layout.body_area.height],"columnAreas":page.layout.column_areas.iter().map(|r|[r.x,r.y,r.width,r.height]).collect::<Vec<_>>(),"columns":page.column_contents.iter().map(|c|serde_json::json!({"column":c.column_index,"start":c.start_height,"used":c.used_height,"items":format!("{:?}",c.items),"floats":format!("{:?}",c.paragraph_float_placements)})).collect::<Vec<_>>(),"tables":tables,"reserved":reserved})
}

/// Stale-input counterexamples on the actual same paragraph allocation, restored
/// in place so the paragraph-pointer check cannot hide another binding failure.
pub fn private_equal_stack_negatives137(core:&mut DocumentCore)->serde_json::Value{
 use renderer::current_frame_rows_plan::CurrentEqualColumnStackCandidate as C;
 let original=core.document.clone();let mut cases=vec![];
 for case in 0..13{
  let p=&mut core.document.sections[0].paragraphs[1];
  match case{
   0=>p.text.push('x'),1=>p.line_segs[0].line_spacing+=1,2=>p.line_segs[0].tag^=1,
   3=>p.raw_header_extra.push(7),4=>{if let model::control::Control::Table(t)=&mut p.controls[0]{t.common.width+=1;}},
   5=>{if let model::control::Control::Table(t)=&mut p.controls[0]{t.cells[0].paragraphs[0].text.push('x');}},
   6=>{if let model::control::Control::Table(t)=&mut p.controls[0]{t.outer_margin_top+=1;}},
   7=>{if let model::control::Control::Table(t)=&mut p.controls[0]{t.raw_ctrl_data.push(0);}},
   8=>core.document.sections[0].section_def.page_def.width+=1,
   9=>{if let model::control::Control::ColumnDef(c)=&mut core.document.sections[0].paragraphs[0].controls[1]{c.spacing+=1;}},
   10=>core.document.doc_info.char_shapes[0].base_size+=1,
   11=>core.document.sections[0].paragraphs[0].text.push_str(&"x".repeat(65537)),
   12=>core.document.sections[0].paragraphs[0].source_line_seg_vertical_pos=Some(vec![i32::MAX]),_=>unreachable!()}
  let styles=core.resolve_render_styles_for_section(0);let result=&core.pagination[0];let rejected=C::from_current(&core.document,core.source_format,result,&styles,&core.measured_tables[0],core.effective_layout_profile(),core.dpi).is_none();
  cases.push(serde_json::json!({"case":case,"rejected":rejected}));
  core.document.doc_info=original.doc_info.clone();core.document.sections[0].section_def=original.sections[0].section_def.clone();
  for(i,p)in original.sections[0].paragraphs.iter().enumerate(){core.document.sections[0].paragraphs[i]=p.clone();}
 }
 let styles=core.resolve_render_styles_for_section(0);let c=C::from_current(&core.document,core.source_format,&core.pagination[0],&styles,&core.measured_tables[0],core.effective_layout_profile(),core.dpi).unwrap();
 let empty_refused=c.finalize(&Default::default()).is_none();
 let fallback=core.fallback_font.clone();core.fallback_font="unsupported-private-audit-family".into();
 assert!(!core.computed_row_resources_supported());
 let resource_gate_refused=core.build_page_tree_with_current_selections(0).unwrap().frame.current_frame_paint_plan.is_none();
 core.fallback_font=fallback;

 serde_json::json!({"staleInputCases":cases,"unfinishedCaptureRefused":empty_refused,"unsupportedResourcesRefused":resource_gate_refused,"restoredCandidate":true,"sourceExactRestored":format!("{:?}",original)==format!("{:?}",core.document)})
}
