//! Separate equal-column, body-wide table stack proof. Configured columns and
//! actual used frames are distinct. This first contract accepts one used col0
//! frame only; no later-column reservation propagation is inferred.
use super::*;
pub(crate) struct CurrentEqualColumnStackCandidate<'doc>{source:&'doc Document,paint:CurrentFramePaintPlan,bodies:Vec<CandidateBody>,tables:Vec<CandidateTable>,rows:Vec<CurrentFrameParagraphRows>,generation:[u8;32],trace:std::sync::Arc<super::super::selected_composition_observer127::FinalizedSelectedCompositionTrace>}
fn fresh_equal_body_rows(p:&crate::model::paragraph::Paragraph,styles:&super::super::style_resolver::ResolvedStyleSet,width:f64,dpi:f64)->Option<FreshBodyRows>{
 // Bound every text story before either generic breaker's i32 accumulation.
 let ps=styles.para_styles.get(usize::from(p.para_shape_id))?;
 if !ps.line_spacing.is_finite()||ps.line_spacing<0.0{return None;}
 for shape in &p.char_shapes{let cs=styles.char_styles.get(shape.char_shape_id as usize)?;let hu=cs.font_size*7200.0/dpi;
  let upper=hu*(2.0+ps.line_spacing.abs())+ps.line_spacing.abs()*7200.0/dpi;
  if !hu.is_finite()||hu<=0.0||!upper.is_finite()||upper*f64::from(p.char_count.max(1))>f64::from(i32::MAX)/4.0{return None;}}
 let _validated=fresh_body_rows(p,styles,width,dpi)?;let mut q=p.clone();clear_fresh_input(&mut q);
 super::super::composer::reflow_line_segs(&mut q,super::super::composer::ParagraphBox::body_for_style(width,styles.para_styles.get(usize::from(p.para_shape_id)),dpi),styles,dpi);
 if q.line_segs.is_empty()||q.line_segs.len()>4096{return None;}let mut end=0i32;
 for row in &q.line_segs{if row.vertical_pos!=end||row.line_height<=0||row.text_height!=row.line_height||row.line_spacing<0||row.baseline_distance<0||row.baseline_distance>row.line_height||row.column_start!=0||row.tag!=0x80060000{return None;}end=end.checked_add(row.line_height)?.checked_add(row.line_spacing)?;}
 let composition=super::super::composer::compose_paragraph_in_context(&q,styles);Some(FreshBodyRows{rows:q.line_segs,composition})
}
impl<'doc> CurrentEqualColumnStackCandidate<'doc>{
 pub(crate) fn from_current(source:&'doc Document,format:crate::parser::FileFormat,result:&super::super::pagination::PaginationResult,
 styles:&super::super::style_resolver::ResolvedStyleSet,measured:&[super::super::height_measurer::MeasuredTable],
 profile:crate::model::provenance::LayoutCompatibilityProfile,dpi:f64)->Option<Self>{
 use super::super::pagination::PageItem;use crate::model::{control::Control,paragraph::ColumnBreakType};
 if source.sections.len()!=1||source.provenance.hwp3_lineage||!source.bin_data_content.is_empty()||result.pages.len()!=1
 ||!result.hidden_empty_paras.is_empty()||!result.pre_emitted_host_paras.is_empty()||!result.wrap_around_paras.is_empty()
 ||!result.endnotes.is_empty()||!result.endnote_paragraphs.is_empty()||dpi!=super::super::DEFAULT_DPI{return None;}
 match format{crate::parser::FileFormat::Hwp if profile.native_hwp5_layout()=>{},crate::parser::FileFormat::Hwpx if profile.hwp5_origin_hwpx()=>{},_=>return None}
 let prefix=super::super::current_equal_column_prefix::CurrentEqualColumnPrefixCandidate::from_current(source,result,styles,profile,dpi)?;
 let section=&source.sections[0].section_def;
 if section.line_grid!=0||section.char_grid!=0||section.text_direction!=0||!section.master_pages.is_empty()||!section.extra_child_records.is_empty(){return None;}
 let ps=&source.sections[0].paragraphs;if ps.is_empty()||ps.len()>128||ps.iter().any(|p|p.completed_native_rows.is_some()){return None;}
 let [Control::SectionDef(_),Control::ColumnDef(columns)]=ps.first()?.controls.as_slice()else{return None;};
 if !matches!(columns.column_count,2|3)||!columns.same_width||!columns.widths.is_empty()||!columns.gaps.is_empty()
 ||columns.column_type!=crate::model::page::ColumnType::Normal||columns.direction!=crate::model::page::ColumnDirection::LeftToRight{return None;}
 match format{crate::parser::FileFormat::Hwp=>if !matches!(columns.raw_attr,0) && columns.raw_attr!=(0x1000|(columns.column_count<<2)){return None;},crate::parser::FileFormat::Hwpx=>if columns.raw_attr!=0{return None;},_=>return None}
 let definition_context=source.reset_flow_contexts().first().copied().flatten()?;
 if styles.reset_flow_contexts.first().copied().flatten()!=Some(definition_context){return None;}
 let trace=result.selected_composition_trace.as_ref()?;
 if trace.section()!=0||trace.resource()!=crate::model::native_computed_resource::RESOURCE
 ||!trace.matches_source(ps,Some(definition_context),profile,dpi)||!trace.matches_finalized_result(result){return None;}
 let page=&result.pages[0];if page.page_index!=0||page.section_index!=0||page.column_contents.len()!=1||page.layout.column_areas.len()!=usize::from(columns.column_count)
 ||!page.footnotes.is_empty()||page.active_header.is_some()||page.active_footer.is_some()||page.active_master_page.is_some()||!page.extra_master_pages.is_empty(){return None;}
 let col=&page.column_contents[0];let rect=page.layout.column_areas[0];
 if rect.width>=page.layout.body_area.width||rect.x!=page.layout.body_area.x||rect.y!=page.layout.body_area.y||rect.height!=page.layout.body_area.height
 ||page.layout.column_areas.iter().any(|a|a.width!=rect.width||a.height!=rect.height||a.y!=rect.y||!a.x.is_finite())||col.column_index!=0||col.start_height!=0.0||col.endnote_flow||col.zone_layout.is_some()||col.zone_y_offset!=0.0
 ||!col.wrap_anchors.is_empty()||!col.wrap_around_paras.is_empty()||!col.inline_placements.is_empty()||!col.inline_flow_plans.is_empty()
 ||!col.overlay_continuations.is_empty()||!col.overlay_cuts.is_empty()||col.items.len()!=ps.len()
 ||trace.commits().len()+trace.whole_tables().len()!=col.items.len()||!trace.tables().is_empty(){return None;}
 let mut flow=0.0;let mut unpainted=0.0;let mut bodies=vec![];let mut tables=vec![];let mut rows=vec![];
 for (slot,item) in col.items.iter().enumerate(){match item{
 PageItem::FullParagraph{para_index:pi}=>{
  if *pi!=slot{return None;}let p=ps.get(*pi)?;let fresh=fresh_equal_body_rows(p,styles,rect.width,dpi)?;
  if *pi==0 {if p.column_type!=ColumnBreakType::Section{return None;}}else if p.column_type!=ColumnBreakType::None||!p.controls.is_empty(){return None;}
  let mut cs=trace.commits().iter().filter(|c|c.paragraph==*pi);let c=cs.next()?;if cs.next().is_some(){return None;}
  let f=trace.format(c.format_id)?;let empty=p.text.is_empty()&&p.controls.is_empty()&&fresh.composition.lines.len()==1;
  if c.page!=Some(0)||c.column!=0||c.committed_item_index!=Some(slot)||c.final_membership!=Some(true)||c.row_start!=0||c.row_end!=fresh.rows.len()
  ||c.reused_multicolumn_format||c.same_format_reused_after_slot_change||c.trimmed_before!=0.0||c.actual_column_width_px!=rect.width
  ||!arithmetic_equal(c.flow_before,flow)||!c.metrics_still_match_selected_format||!c.range_inside_selected_composition
  ||f.source_text!=p.text||f.source_char_offsets!=p.char_offsets||f.paragraph_style!=fresh.composition.para_style_id
  ||(!empty&&f.actual_input_width_px!=Some(rect.width))||f.known_square_band||f.has_numbering||f.has_horizontal_shaping
  ||!f.tac_controls.is_empty()||!f.footnote_positions.is_empty()||!f.tab_extended.is_empty()
  ||f.inline_controls.len()!=fresh.composition.inline_controls.len()
  ||!f.inline_controls.iter().zip(&fresh.composition.inline_controls).all(|((line,index,kind),c)|*line==c.line_index&&*index==c.control_index&&*kind==format!("{:?}",c.control_type))
  ||f.before!=0.0||f.after!=0.0||f.lines.len()!=fresh.composition.lines.len()
  ||!f.lines.iter().zip(&fresh.composition.lines).all(|(a,b)|fact_line_matches(a,b,empty)){return None;}
  let total:f64=fresh.rows.iter().map(|r|super::super::hwpunit_to_px(r.line_height+r.line_spacing,dpi)).sum();
  if !arithmetic_equal(c.advance,total)||!arithmetic_equal(c.flow_after,c.flow_before+total)||c.flow_after>rect.height{return None;}
  let y=rect.y+c.flow_before-unpainted;let mut projected=fresh.rows.clone();let mut offset=0.0;
  for row in &mut projected{row.vertical_pos=integer_hu(y-rect.y+offset,dpi)?;offset+=super::super::hwpunit_to_px(row.line_height+row.line_spacing,dpi);}
  rows.push(CurrentFrameParagraphRows{kind:CurrentFrameRowKind::FreshBody,section:0,paragraph:*pi,rows:projected});bodies.push(CandidateBody{paragraph:*pi,physical_y:y,fresh,allow_empty_unused_width:empty});flow=c.flow_after;
 },PageItem::Table{para_index:pi,control_index:ci}=>{
  if *pi!=slot||*ci!=0{return None;}let p=ps.get(*pi)?;let [Control::Table(table)]=p.controls.as_slice()else{return None;};
  if !p.text.is_empty()||p.char_count!=9||!p.char_offsets.is_empty()||p.column_type!=ColumnBreakType::None
  ||p.completed_native_rows.is_some()||p.stored_text_partition_is_dirty()||p.cell_format_vpos_dirty||!p.field_ranges.is_empty()||!p.range_tags.is_empty()
  ||!p.tab_extended.is_empty()||p.layout_only_fill_lines!=0
  ||!table.common.raw_extra.is_empty()||table.raw_table_record_extra.iter().any(|b|*b!=0)
 ||i32::try_from(table.common.width).ok()?.checked_add(i32::from(table.outer_margin_left))?.checked_add(i32::from(table.outer_margin_right))?!=integer_hu(page.layout.body_area.width,dpi)?
 ||super::super::hwpunit_to_px(i32::try_from(table.common.width).ok()?,dpi)<=rect.width{return None;}
  let plain_cell=|q:&crate::model::paragraph::Paragraph|q.controls.is_empty()&&q.field_ranges.is_empty()&&q.range_tags.is_empty()&&q.tab_extended.is_empty();
  if table.common.vertical_offset!=0||!crate::renderer::generated_column_stack::plain_table(table,plain_cell){return None;}
  match format{crate::parser::FileFormat::Hwp=>if !native_table_common_exact(table){return None;},crate::parser::FileFormat::Hwpx=>if !table.raw_ctrl_data.is_empty(){return None;},_=>return None}
  let mut ms=measured.iter().filter(|m|m.para_index==*pi&&m.control_index==0);let m=ms.next()?;if ms.next().is_some()||m.caption_height!=0.0||m.total_height<=0.0||!m.total_height.is_finite()
  ||integer_hu(m.total_height,dpi)?!=i32::try_from(table.common.height).ok()?{return None;}
  let mut ts=trace.whole_tables().iter().filter(|t|t.paragraph==*pi&&t.control==0);let t=ts.next()?;if ts.next().is_some(){return None;}
  if t.page!=Some(0)||t.column!=0||t.post_page!=Some(0)||t.post_column!=0||t.committed_item_index!=slot||t.final_membership!=Some(true)
  ||t.pre_text_height!=0.0||t.pre_text_end!=0||!arithmetic_equal(t.flow_before,flow)||t.before<0.0||t.after_for_fit<0.0
  ||t.body_height!=m.total_height||!arithmetic_equal(t.table_total_height,t.before+t.body_height+t.after_for_fit)
  ||t.flow_after>rect.height
  ||integer_hu(t.before,dpi)?!=i32::from(table.outer_margin_top){return None;}
  if t.resolved.is_some()||col.paragraph_float_placements.contains_key(&(*pi,0))||!arithmetic_equal(t.flow_after,t.flow_before+t.table_total_height){return None;}
  let object_anchor=None;
  let incoming=rect.y+t.flow_before-unpainted;
  let top=incoming;
  if top<rect.y||top+t.body_height>rect.y+rect.height{return None;}
  // The structural object row owns no text ink, but its paragraph/font style
  // context must remain within the same explicit plain frame contract.
  let mut style_probe=p.clone();style_probe.controls.clear();style_probe.char_count=1;
  fresh_equal_body_rows(&style_probe,styles,rect.width,dpi)?;
  let mut host=p.clone();clear_fresh_input(&mut host);
  super::super::composer::reflow_line_segs(&mut host,super::super::composer::ParagraphBox::body_for_style(rect.width,styles.para_styles.get(usize::from(p.para_shape_id)),dpi),styles,dpi);
  if host.line_segs.len()!=1{return None;}
  let selected=trace.format(t.selected_format_id?)?;let fresh_host=super::super::composer::compose_paragraph_in_context(&host,styles);
  if selected.source_text!=p.text||selected.source_char_offsets!=p.char_offsets||selected.paragraph_style!=fresh_host.para_style_id
   ||selected.has_numbering||selected.has_horizontal_shaping||selected.known_square_band
   ||!selected.tac_controls.is_empty()||!selected.footnote_positions.is_empty()||!selected.tab_extended.is_empty()
   ||selected.lines.len()!=1||fresh_host.lines.len()!=1||t.selected_line_count!=1
   ||!fact_line_matches(&selected.lines[0],&fresh_host.lines[0],true)
   ||selected.inline_controls.len()!=fresh_host.inline_controls.len()
   ||!selected.inline_controls.iter().zip(&fresh_host.inline_controls).all(|((line,index,kind),c)|*line==c.line_index&&*index==c.control_index&&*kind==format!("{:?}",c.control_type)){return None;}
  let generated=&host.line_segs[0];if generated.tag!=0x80060000||generated.vertical_pos!=0||generated.text_start!=0
   ||generated.line_height<=0||generated.text_height!=generated.line_height||generated.line_spacing<0
   ||generated.baseline_distance<0||generated.baseline_distance>generated.line_height||generated.column_start!=0
   ||generated.segment_width!=prefix.fresh_rows().first()?.segment_width{return None;}
  host.line_segs[0].vertical_pos=integer_hu(incoming-rect.y-t.before,dpi)?;
  if host.line_segs[0].vertical_pos<0{return None;}
  // HWPX uses a standard outer-box anchor below the current paragraph pen.
  // Its exact freshly derived full row must already express this recipe before
  // it can select this renderer branch. A flag or imported lease is insufficient.
  let standard_anchor=if matches!(format,crate::parser::FileFormat::Hwpx){
   if p.hwpx_axis_shift!=0||p.line_segs!=host.line_segs
    ||p.source_line_seg_vertical_pos.as_ref().is_some_and(|v|v.as_slice()!=[host.line_segs[0].vertical_pos]){return None;}
   Some(rect.y+super::super::hwpunit_to_px(host.line_segs[0].vertical_pos,dpi))
  }else{None};

  rows.push(CurrentFrameParagraphRows{kind:CurrentFrameRowKind::FreshBody,section:0,paragraph:*pi,rows:host.line_segs});tables.push(CandidateTable{paragraph:*pi,control:0,incoming,top,before:t.before,body:t.body_height,after:t.after_for_fit,object_anchor,standard_anchor});
  unpainted+=t.before;flow=t.flow_after;
 },_=>return None}}
 if tables.is_empty()||measured.len()!=tables.len()||col.paragraph_float_placements.len()!=tables.iter().filter(|t|t.object_anchor.is_some()).count()||!arithmetic_equal(flow,col.used_height){return None;}
 let mut h=blake3::Hasher::new();h.update(b"current-equal-bodywide-stack-proof-1\0");h.update(&trace.resource());h.update(&trace.generation().to_le_bytes());
 for t in &tables{h.update(&(t.paragraph as u64).to_le_bytes());for v in[t.incoming,t.top,t.before,t.body,t.after,t.standard_anchor.unwrap_or(t.incoming)]{h.update(&v.to_bits().to_le_bytes());}match t.object_anchor{Some((a,b,c))=>{h.update(&[1]);h.update(&a.to_bits().to_le_bytes());h.update(&b.to_bits().to_le_bytes());h.update(&c.to_bits().to_le_bytes());},None=>{h.update(&[0]);}}}
 let generation=*h.finalize().as_bytes();let paint=CurrentFramePaintPlan{source_paragraphs:ps.as_ptr()as usize,generation,section:0,page:0,column:0,rect,tables:tables.clone()};
 let candidate=Self{source,paint,bodies,tables,rows,generation,trace:std::sync::Arc::clone(trace)};
 Some(candidate)
 }
 pub(crate) fn paint_plan(&self)->CurrentFramePaintPlan{self.paint.clone()}
 fn closes_physical(&self,physical:&super::super::current_physical_selections::CurrentPhysicalSelections,bound:bool)->Option<()>{
  if bound&&!physical.matches_current_plan(&self.paint){return None;}
  let frames=physical.frames()?;let [frame]=frames else{return None;};if frame.section!=0||frame.page!=0||frame.column!=0||frame.column_ordinal!=0||frame.has_zone||frame.zone_y!=0.0
  ||frame.rect.x!=self.paint.rect.x||frame.rect.y!=self.paint.rect.y||frame.rect.width!=self.paint.rect.width||frame.rect.height!=self.paint.rect.height{return None;}
  let painted=physical.rows()?;let actual_tables=physical.tables()?;if actual_tables.len()!=self.tables.len(){return None;}
  let expected_count:usize=self.bodies.iter().map(|b|b.fresh.rows.len()).sum();if painted.len()!=expected_count{return None;}
  for body in &self.bodies{let selected=painted.iter().filter(|r|r.frame.paragraph==body.paragraph).collect::<Vec<_>>();if selected.len()!=body.fresh.rows.len(){return None;}
   let mut offset=0.0;for (i,(fresh,row))in body.fresh.composition.lines.iter().zip(selected).enumerate(){
    let f=&row.frame;let effective=if f.stored_horizontal_span_used{super::super::hwpunit_to_px(fresh.segment_width,super::super::DEFAULT_DPI)}else{frame.rect.width};
    if f.node!=frame.node||f.line!=i||f.equation_adjusted||f.has_wrap_anchor
    ||f.effective_column_x!=frame.rect.x||f.effective_column_width!=effective||f.available_width!=effective
    ||f.margin_left!=0.0||f.margin_right!=0.0||f.inline_offset!=0.0||f.numbering_offset!=0.0
    ||!arithmetic_equal(f.physical_text_y,body.physical_y+offset)||f.final_line_box_height!=super::super::hwpunit_to_px(fresh.line_height,super::super::DEFAULT_DPI)
    ||(!same_selected_line(fresh,&row.selected)&&!(body.allow_empty_unused_width&&same_empty_line_ignoring_unused_width(fresh,&row.selected))){return None;}
    offset+=super::super::hwpunit_to_px(fresh.line_height+fresh.line_spacing,super::super::DEFAULT_DPI);
   }}
  for table in &self.tables{let mut actual=actual_tables.iter().filter(|t|t.paragraph==table.paragraph&&t.control==table.control);let t=actual.next()?;
   let bbox=t.selected_border_box?;
   let model=match &self.source.sections[0].paragraphs[table.paragraph].controls[table.control]{crate::model::control::Control::Table(v)=>v,_=>return None};
   if !arithmetic_equal(bbox[0],frame.rect.x+super::super::hwpunit_to_px(i32::from(model.outer_margin_left),super::super::DEFAULT_DPI))
    ||!arithmetic_equal(bbox[1],table.top)||!arithmetic_equal(bbox[2],super::super::hwpunit_to_px(i32::try_from(model.common.width).ok()?,super::super::DEFAULT_DPI))
    ||!arithmetic_equal(bbox[3],table.body){return None;}
   if actual.next().is_some()||t.node!=frame.node||t.typed_float!=table.object_anchor.is_some()||t.inline||t.treat_as_char||t.selected_outer_inset!=0.0
   ||!arithmetic_equal(t.incoming_y,table.incoming)||!arithmetic_equal(t.selected_y,table.top)||t.visual_height!=table.body||!arithmetic_equal(t.visual_end,table.top+table.body)
   ||!arithmetic_equal(t.flow_end,table.top+table.body){return None;}
   if table.object_anchor.is_none()&&!arithmetic_equal(t.paragraph_y,table.standard_anchor.unwrap_or(table.incoming)){return None;}
   if let Some((anchor,_,incoming))=table.object_anchor{
    if !arithmetic_equal(t.incoming_y,incoming)||!arithmetic_equal(t.paragraph_y,frame.rect.y+anchor){return None;}}}
  Some(())
 }
 pub(crate) fn matches_current(&self,source:&Document,result:&super::super::pagination::PaginationResult,styles:&super::super::style_resolver::ResolvedStyleSet,profile:crate::model::provenance::LayoutCompatibilityProfile,dpi:f64)->bool{
  std::ptr::eq(source,self.source)&&dpi==super::super::DEFAULT_DPI&&result.selected_composition_trace.as_ref().is_some_and(|t|std::sync::Arc::ptr_eq(t,&self.trace))
   &&self.trace.resource()==crate::model::native_computed_resource::RESOURCE&&self.trace.matches_source(&source.sections[0].paragraphs,styles.reset_flow_context,profile,dpi)&&self.trace.matches_finalized_result(result)
 }
 pub(crate) fn finalize(self,physical:&super::super::current_physical_selections::CurrentPhysicalSelections)->Option<CurrentFrameRowsPlan<'doc>>{self.closes_physical(physical,true)?;Some(CurrentFrameRowsPlan{source:self.source,resource:crate::model::native_computed_resource::RESOURCE,allocation_generation:self.generation,paragraphs:self.rows})}

}