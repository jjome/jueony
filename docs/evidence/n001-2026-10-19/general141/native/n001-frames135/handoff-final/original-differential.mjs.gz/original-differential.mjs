import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {loadReviewEngine,differences,hash} from '../../apps/editor/scripts/lib/hancom-review.mjs';
const r=process.cwd(),e=await loadReviewEngine(r+'/build/rhwp-engine/source-673d48cdf729e05c/pkg');
const input=await readFile(r+'/docs/evidence/file-completion-2026-10-18/engine76/columns-native/fixtures/build/file-closure69-public/column2-candidate74/valid-negative-disk/baseline-single_column.hwp');
assert.equal(hash(input),'9778d66926e3138ce4bb51fadfd16173ee3d439aeec0a02a8f0af34b7fac0f3b');const results=[];
for(const name of ['page','sections','three-pages']){const d=new e.HwpDocument(input);
 if(name==='sections')d.insertSectionBreak(0,3,0);else{d.insertPageBreak(0,2,0);if(name==='three-pages')d.insertPageBreak(0,4,0);}
 d.insertText(0,0,d.getParagraphLength(0,0),'현재 문맥으로 복합 배치를 다시 조판하는 자체 시험 문장입니다. '.repeat(8));
 const old={pages:d.pageCount(),layout:Array.from({length:d.pageCount()},(_,p)=>({text:JSON.parse(d.getPageTextLayout(p)),controls:JSON.parse(d.getPageControlLayout(p))}))};d.free();
 const current=JSON.parse(await readFile(r+`/build/n001-frames135/${name}-public/original-current-layout.json`,'utf8'));const diff=differences(old,current,0);results.push({name,differences:diff,geometryDifferences:diff.length});await writeFile(r+`/build/n001-frames135/${name}-original134.json`,JSON.stringify(old,null,2));
}
const report={baseline:e.metadata,fixtureSha256:hash(input),results,failures:results.filter(r=>r.geometryDifferences!==0),scope:'Exact published before-export source geometry from official134 WASM versus current135 Native, same public edits; no export/reopen normalization'};await writeFile(r+'/build/n001-frames135/original-134-differential.json',JSON.stringify(report,null,2));assert.deepEqual(report.failures,[]);
