//! Completion boundary for portable, ordinary native body edits.
use super::DocumentCore;
use crate::model::native_computed_rows::{self as contract,CompletedRows,RowBasis};
use crate::renderer::pagination::PageItem;
impl DocumentCore {
    pub(crate) fn computed_row_resources_supported(&self)->bool {
        let (slots,sources,_,_)=self.layout_engine.exact_font_source_registry_counts();
        !self.canvas_metrics_active() && self.font_environment.is_none() && slots==0 && sources==0
            && self.dpi==crate::renderer::DEFAULT_DPI && !self.hangul2024_compat
            && self.fallback_font==super::DEFAULT_FALLBACK_FONT
    }
    pub(crate) fn begin_completed_native_edit(&self,section:usize,paragraph:usize)->Option<Vec<bool>> {
        if !self.computed_row_resources_supported() || self.batch_mode
            || self.pending_pagination_job.is_some() || self.deferred_pagination_descriptor.is_some()
            || !matches!(self.source_format,crate::parser::FileFormat::Hwp|crate::parser::FileFormat::Hwpx)
            || self.document.provenance.hwp3_lineage {return None;}
        let s=self.document.sections.get(section)?;
        if s.paragraphs.len()>4096 || s.paragraphs.iter().map(|p|p.line_segs.len()).sum::<usize>()>contract::MAX_ROWS {return None;}
        let p=s.paragraphs.get(paragraph)?;
        if !p.tab_extended.is_empty() || p.text.contains(['\t','\n','\r'])
            || p.controls.iter().any(|c| !matches!(c,crate::model::control::Control::SectionDef(_)|crate::model::control::Control::ColumnDef(_)))
            || !p.field_ranges.is_empty() || !p.range_tags.is_empty() {return None;}
        let source=self.document.native_source_synthetic_context_digest();
        let frame=contract::context(&self.document);
        let owned=s.paragraphs.iter().map(|p|p.owns_native_source_synthetic_rows(source)
            || p.owns_completed_native_rows(frame)).collect::<Vec<_>>();
        if !owned.get(paragraph).copied().unwrap_or(false) {return None;}
        for p in &s.paragraphs {p.native_frame_observation.set(None);}
        Some(owned)
    }
    pub(crate) fn finish_completed_native_edit(&mut self,section:usize,eligible:Option<Vec<bool>>) {
        let Some(eligible)=eligible else{return;};
        if !self.computed_row_resources_supported() || self.batch_mode
            || self.pending_pagination_job.is_some() || self.deferred_pagination_descriptor.is_some()
            || self.dirty_sections.iter().any(|dirty|*dirty) {return;}
        // An edit completion owns a fresh full allocation pass. Incremental
        // convergence must not carry an unobserved table origin from a former
        // revision merely because this edit happened after that table.
        self.mark_section_dirty(section);
        if let Some(dirty)=self.dirty_paragraphs.get_mut(section) {*dirty=None;}
        self.paginate_if_needed();
        if self.dirty_sections.iter().any(|dirty|*dirty) {return;}
        let Some(pagination)=self.pagination.get(section) else{return;};
        let Some(s)=self.document.sections.get(section) else{return;};
        if s.paragraphs.len()!=eligible.len() {return;}
        let mut bases=s.paragraphs.iter().map(|p|vec![None;p.line_segs.len()]).collect::<Vec<Vec<Option<RowBasis>>>>();
        for page in &pagination.pages { for column in &page.column_contents {
            if column.zone_layout.is_some() || column.zone_y_offset!=0.0 {return;}
            let first=column.items.iter().find_map(|item| match item {
                PageItem::FullParagraph{para_index}|PageItem::Table{para_index,..}=>s.paragraphs.get(*para_index)?.line_segs.first(),
                PageItem::PartialParagraph{para_index,start_line,..}=>s.paragraphs.get(*para_index)?.line_segs.get(*start_line),_=>None});
            let Some(first)=first else{continue;};
            let physical_start=crate::renderer::px_to_hwpunit(column.start_height,self.dpi);
            let Some(offset)=first.vertical_pos.checked_sub(physical_start) else{return;};
            for item in &column.items {
                let (pi,start,end)=match item {
                    PageItem::FullParagraph{para_index}|PageItem::Table{para_index,..}=>
                        (*para_index,0,s.paragraphs.get(*para_index).map_or(0,|p|p.line_segs.len())),
                    PageItem::PartialParagraph{para_index,start_line,end_line}=>(*para_index,*start_line,*end_line),
                    _=>continue,
                };
                let Some(p)=s.paragraphs.get(pi) else{return;};
                if !eligible[pi] {continue;}
                for i in start..end {
                    let Some(r)=p.line_segs.get(i) else{return;};
                    let Some(v)=r.vertical_pos.checked_sub(offset) else{return;};
                    // Standard XML cache coordinates never carry a section-cumulative ladder.
                    if v<0 || crate::renderer::hwpunit_to_px(v,self.dpi)>page.layout.body_area.height+1.0
                        || r.tag!=0x80060000 || r.line_height<=0 || r.text_height<=0 || r.line_spacing<0
                        || bases[pi][i].is_some() {return;}
                    bases[pi][i]=Some(RowBasis{page:page.page_index,column:column.column_index,offset});
                }
            }
        }}
        // Share the renderer's existing body-wide reservation query. This is a
        // native allocation-to-physical-frame transform, not a sampled paint box.
        let mut native_frames=vec![None;s.paragraphs.len()];
        for page in &pagination.pages {
            self.layout_engine.prime_column_layout_env(&page.layout);
            let reserved=if page.column_contents.len()>1 {
                self.layout_engine.calculate_body_wide_shape_reserved(&s.paragraphs,&page.column_contents,&page.layout.body_area)
                    .iter().map(|(_,bottom)|(bottom-page.layout.body_area.y).max(0.0)).fold(0.0,f64::max)
            } else {0.0};
            for column in &page.column_contents {
                let shift=(reserved-column.start_height.max(0.0)).max(0.0);
                let mut unpainted_before=0.0;
                for item in &column.items {
                    let PageItem::Table{para_index:pi,control_index:ci}=item else{continue;};
                    let p=&s.paragraphs[*pi];
                    if let Some(mut f)=p.native_frame_observation.get().filter(|f|f.page==page.page_index && f.column==column.column_index && f.control==*ci) {
                        // Native reservations include host before; the empty float
                        // paint frame selected inset0. Carry that named difference
                        // to the next native host in the same physical column.
                        f.raw_top+=shift-unpainted_before;
                        f.reserved_bottom+=shift-unpainted_before-f.before;
                        if (f.reserved_bottom-f.raw_top-f.body_height-f.after).abs()<=self.dpi/7200.0 {
                            native_frames[*pi]=Some(f);
                        }
                        unpainted_before+=f.before;
                    } else {break;}
                }
            }
        }
        let frame=contract::context(&self.document);
        let s=&mut self.document.sections[section];
        let mut issued=false;
        for (pi,p) in s.paragraphs.iter_mut().enumerate() {
            if !eligible[pi] || bases[pi].is_empty() || bases[pi].iter().any(Option::is_none)
                || p.stored_text_partition_is_dirty() || p.layout_only_fill_lines!=0 || p.cell_format_vpos_dirty {continue;}
            let native_frame=native_frames[pi].filter(|f|
                bases[pi][0].as_ref().is_some_and(|b|b.page==f.page && b.column==f.column)
                    && contract::valid_native_empty_host(p,f.control,f.outer_top));
            // A table origin needs the actual successful native allocation observation.
            if p.controls.iter().any(|c|matches!(c,crate::model::control::Control::Table(_))) && native_frame.is_none() {continue;}
            p.completed_native_rows=Some(CompletedRows {local:contract::local(p),plan:contract::plan(&bases[pi].iter().map(|b|b.clone().unwrap()).collect::<Vec<_>>(),native_frame),frame,resource:contract::RESOURCE,
                bases:bases[pi].iter().map(|b|b.clone().unwrap()).collect(),native_frame,export_authorized:false});
            issued=true;
        }
        if issued {
            // CompletedRows is an exact input to current formatter/paint source
            // binding. Its issuance changes that input after the allocation
            // above; make a real current pass before publishing the result.
            // No trace hash is projected, ignored or rebound to the new source.
            // This does not recurse into edit completion or issue another lease.
            self.mark_section_dirty(section);
            if let Some(dirty)=self.dirty_paragraphs.get_mut(section) {*dirty=None;}
            self.paginate_if_needed();
        }
    }
    pub(crate) fn authorize_completed_native_export(&self,doc:&mut crate::model::document::Document) {
        let frame=contract::context(&self.document);
        let supported=self.computed_row_resources_supported() && frame==contract::context(doc);
        for s in &mut doc.sections {for p in &mut s.paragraphs {
            let ok=supported && p.owns_completed_native_rows(frame);
            if let Some(o)=&mut p.completed_native_rows {o.export_authorized=ok;}
        }}
    }
}


// A serialization-only inverse projection. It cannot grant a new runtime row
// lease: every accepted byte must be produced by the current HWP lowerer from
// the same input, and the projected complete frame must still equal that input.
fn inverse_known_hwp_storage(source:&serde_json::Value,target:&serde_json::Value,expected:&serde_json::Value,path:&str)->Option<serde_json::Value> {
    use serde_json::Value;
    if source==target {return Some(source.clone());}
    if target==expected {
        let empty=source.is_null() || source.as_array().is_some_and(Vec::is_empty);
        let generated_bytes=target.as_array().is_some_and(|a|!a.is_empty() && a.iter().all(|v|v.as_u64().is_some_and(|n|n<=255)));
        let known_empty_field=(path.ends_with("/SectionDef/raw_ctrl_extra") || path=="sectionDef/raw_ctrl_extra"
            || path.ends_with("/Table/raw_ctrl_data")
            || (path.contains("/Table/cells/") && path.ends_with("/raw_list_extra"))) && empty && generated_bytes;
        let known_header=path.ends_with("/raw_header_extra") && source.as_array().zip(target.as_array()).is_some_and(|(a,b)|
            a.len()==10 && b.len()==12 && b[..10]==a[..] && b[10..].iter().all(|v|v.as_u64()==Some(0)));
        let known_table_attr=path.ends_with("/Table/attr") && source.as_u64()==Some(0) && target.as_u64().is_some_and(|n|n!=0);
        // The lowerer aligns absent optional CTRL_DATA slots with controls.
        // None padding contains no raw record; any Some/unknown byte is denied.
        let known_empty_slots=path.ends_with("/ctrl_data_records") && source.as_array().is_some_and(Vec::is_empty)
            && target.as_array().is_some_and(|v|!v.is_empty() && v.iter().all(serde_json::Value::is_null));
        if known_empty_field || known_header || known_table_attr || known_empty_slots {return Some(source.clone());}
    }
    match(source,target,expected) {
        (Value::Array(a),Value::Array(b),Value::Array(e)) if a.len()==b.len() && a.len()==e.len()=>
            Some(Value::Array(a.iter().zip(b).zip(e).enumerate().map(|(i,((a,b),e))|
                inverse_known_hwp_storage(a,b,e,&format!("{path}/{i}"))).collect::<Option<Vec<_>>>()?)),
        (Value::Object(a),Value::Object(b),Value::Object(e)) if a.len()==b.len() && a.len()==e.len()=> {
            let mut out=serde_json::Map::new();for(k,a)in a {
                out.insert(k.clone(),inverse_known_hwp_storage(a,b.get(k)?,e.get(k)?,&format!("{path}/{k}"))?);
            }Some(Value::Object(out))
        }
        _=>None,
    }
}

fn reverse_known_hwp_paragraph_storage(a:&crate::model::paragraph::Paragraph,b:&mut crate::model::paragraph::Paragraph)->bool {
    use crate::model::control::Control;
    // Render-state omitted from JSON is compared directly. Neither this state
    // nor any unknown raw/model field is copied from the source to the output.
    if a.layout_space_metrics!=b.layout_space_metrics || a.source_line_seg_vertical_pos!=b.source_line_seg_vertical_pos
        || a.stored_text_partition_dirty!=b.stored_text_partition_dirty || a.cell_format_vpos_dirty!=b.cell_format_vpos_dirty
        || a.cell_vpos_reset!=b.cell_vpos_reset || a.numbering_marker!=b.numbering_marker || a.controls.len()!=b.controls.len() {return false;}
    b.raw_header_extra=a.raw_header_extra.clone();
    b.ctrl_data_records=a.ctrl_data_records.clone();
    for (a,b) in a.controls.iter().zip(&mut b.controls) {match(a,b) {
        (Control::ColumnDef(_),Control::ColumnDef(_))=>{},
        (Control::SectionDef(a),Control::SectionDef(b)) if a.master_pages.is_empty() && b.master_pages.is_empty()=>b.raw_ctrl_extra=a.raw_ctrl_extra.clone(),
        (Control::Table(a),Control::Table(b)) if a.caption.is_none() && b.caption.is_none() && a.cells.len()==b.cells.len()=> {
            b.attr=a.attr;b.raw_ctrl_data=a.raw_ctrl_data.clone();
            for (a,b) in a.cells.iter().zip(&mut b.cells) {
                if a.paragraphs.len()!=b.paragraphs.len() {return false;}
                b.raw_list_extra=a.raw_list_extra.clone();
                for (a,b) in a.paragraphs.iter().zip(&mut b.paragraphs) {
                    if !reverse_known_hwp_paragraph_storage(a,b) {return false;}
                }
            }
        },
        _=>return false, // Other trees have no approved storage projection.
    }}true
}

impl super::DocumentCore {
    pub(crate) fn authorize_completed_native_hwp_lowering(&self,before:&crate::model::document::Document,target:&mut crate::model::document::Document) {
        use crate::document_core::converters::hwpx_to_hwp::convert_if_hwpx_source;
        if !matches!(self.source_format,crate::parser::FileFormat::Hwpx) || !self.computed_row_resources_supported() {return;}
        let frame=contract::context(&self.document);
        if contract::context(before)!=frame || before.sections.len()!=target.sections.len() {return;}
        let mut expected=before.clone();convert_if_hwpx_source(&mut expected,self.source_format);
        let mut projected=target.clone();
        for ((a,b),e) in before.sections.iter().zip(&mut projected.sections).zip(&expected.sections) {
            let values=serde_json::to_value(&a.section_def).ok().zip(serde_json::to_value(&b.section_def).ok()).zip(serde_json::to_value(&e.section_def).ok());
            let Some(((a_value,b_value),e_value))=values else{return;};
            let Some(value)=inverse_known_hwp_storage(&a_value,&b_value,&e_value,"sectionDef") else{return;};
            if value!=a_value || !a.section_def.master_pages.is_empty() || !b.section_def.master_pages.is_empty() {return;}
            b.section_def.raw_ctrl_extra=a.section_def.raw_ctrl_extra.clone();
            if a.paragraphs.len()!=b.paragraphs.len() || a.paragraphs.len()!=e.paragraphs.len() {return;}
            for ((a,b),e) in a.paragraphs.iter().zip(&mut b.paragraphs).zip(&e.paragraphs) {
                let values=serde_json::to_value(a).ok().zip(serde_json::to_value(&*b).ok()).zip(serde_json::to_value(e).ok());
                let Some(((a_value,b_value),e_value))=values else{return;};
                let Some(value)=inverse_known_hwp_storage(&a_value,&b_value,&e_value,"paragraph") else{return;};
                if value!=a_value || !reverse_known_hwp_paragraph_storage(a,b) {return;}
            }
        }
        if contract::context(&projected)!=frame {return;}
        for (source,output) in self.document.sections.iter().zip(&mut target.sections) {
            for (source,output) in source.paragraphs.iter().zip(&mut output.paragraphs) {
                // The global inverse projection is proved above. The local rows,
                // plan, metric choices and resource must remain the original lease.
                let ok=source.owns_completed_native_rows(frame) && output.owns_completed_native_rows(frame);
                if let Some(owner)=&mut output.completed_native_rows {owner.export_authorized=ok;}
            }
        }
    }
}

#[cfg(test)]
mod export_lowering_tests {
    use super::inverse_known_hwp_storage as inverse;
    use serde_json::json;
    #[test] fn native_computed_export_lowering_accepts_only_exact_current_generated_storage() {
        let a=json!({"Table":{"attr":0,"raw_ctrl_data":null,"cells":[{"raw_list_extra":null}]}});
        let b=json!({"Table":{"attr":2753296,"raw_ctrl_data":[1,2],"cells":[{"raw_list_extra":[3,4]}]}});
        assert_eq!(inverse(&a,&b,&b,"paragraph/controls/0"),Some(a.clone()));
        let mut changed=b.clone();changed["Table"]["raw_ctrl_data"]=json!([1,3]);assert!(inverse(&a,&changed,&b,"paragraph/controls/0").is_none());
        let mut known=a.clone();known["Table"]["attr"]=json!(8);assert!(inverse(&known,&b,&b,"paragraph/controls/0").is_none());
        let mut opaque=a.clone();opaque["Table"]["raw_ctrl_data"]=json!([9]);assert!(inverse(&opaque,&b,&b,"paragraph/controls/0").is_none());
        let mut geometry=a.clone();geometry["Table"]["width"]=json!(100);let mut moved=b.clone();moved["Table"]["width"]=json!(101);
        assert!(inverse(&geometry,&moved,&moved,"paragraph/controls/0").is_none());
    }
    #[test] fn native_computed_export_lowering_preserves_header_prefix_unknown_bytes_and_order() {
        let a=json!({"raw_header_extra":[1,2,3,4,5,6,7,8,9,10]});let b=json!({"raw_header_extra":[1,2,3,4,5,6,7,8,9,10,0,0]});
        assert_eq!(inverse(&a,&b,&b,"paragraph"),Some(a.clone()));
        let mut bad=b.clone();bad["raw_header_extra"][9]=json!(11);assert!(inverse(&a,&bad,&bad,"paragraph").is_none());
        let a=json!({"SectionDef":{"raw_ctrl_extra":[]}});let b=json!({"SectionDef":{"raw_ctrl_extra":[0,0]}});
        assert_eq!(inverse(&a,&b,&b,"paragraph/controls/0"),Some(a.clone()));
        assert!(inverse(&json!({"SectionDef":{"raw_ctrl_extra":[1]}}),&b,&b,"paragraph/controls/0").is_none());
        assert!(inverse(&json!([1,2]),&json!([2,1]),&json!([2,1]),"paragraph/controls").is_none());
        let a=json!({"ctrl_data_records":[]});let b=json!({"ctrl_data_records":[null,null]});
        assert_eq!(inverse(&a,&b,&b,"paragraph"),Some(a));
        assert!(inverse(&json!({"ctrl_data_records":[]}),&json!({"ctrl_data_records":[{"data":[1]}]}),&json!({"ctrl_data_records":[{"data":[1]}]}),"paragraph").is_none());
        assert!(inverse(&json!({"ctrl_data_records":[null]}),&b,&b,"paragraph").is_none());
    }
}
