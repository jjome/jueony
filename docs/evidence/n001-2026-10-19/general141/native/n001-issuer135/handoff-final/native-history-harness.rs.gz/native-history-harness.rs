use rhwp::DocumentCore;
use serde_json::{Value,json};
use sha2::{Sha256,Digest};
use std::path::PathBuf;
fn hash(b:&[u8])->String{Sha256::digest(b).iter().map(|v|format!("{v:02x}")).collect()}
fn layout(d:&DocumentCore)->Value{json!({"pages":d.page_count(),"layout":(0..d.page_count()).map(|p|json!({"text":serde_json::from_str::<Value>(&d.get_page_text_layout_native(p).unwrap()).unwrap(),"controls":serde_json::from_str::<Value>(&d.get_page_control_layout_native(p).unwrap()).unwrap()})).collect::<Vec<_>>()})}
fn coverage(d:&DocumentCore)->Value{
 let mut all=vec![];
 for(si,s)in d.document().sections.iter().enumerate(){for(pi,p)in s.paragraphs.iter().enumerate(){let chars=p.text.chars().collect::<Vec<_>>();let mut counts=vec![0usize;chars.len()];let mut cursor=0usize;let mut errors=vec![];
  for page in 0..d.page_count(){let v:Value=serde_json::from_str(&d.get_page_text_layout_native(page).unwrap()).unwrap();for run in v["runs"].as_array().unwrap(){
   if run.get("cellPath").is_some()||run.get("parentParaIdx").is_some(){continue;}if run["secIdx"]!=si||run["paraIdx"]!=pi{continue;}
   let text=run["text"].as_str().unwrap().chars().collect::<Vec<_>>();let start=run["charStart"].as_u64().unwrap()as usize;let end=start+text.len();
   if start!=cursor||end>chars.len()||chars.get(start..end)!=Some(text.as_slice()){errors.push(json!({"kind":"partition","page":page,"expected":cursor,"start":start,"end":end}));}
   if run["charX"].as_array().map(|x|x.len())!=Some(text.len()+1){errors.push(json!({"kind":"charX"}));}
   for n in counts.iter_mut().take(end).skip(start){*n+=1;}cursor=end;
  }}
  let missing=counts.iter().filter(|&&v|v==0).count();let duplicate=counts.iter().filter(|&&v|v>1).count();if missing>0||duplicate>0||cursor!=chars.len(){errors.push(json!({"kind":"coverage","missing":missing,"duplicate":duplicate,"end":cursor,"source":chars.len()}));}
  if !errors.is_empty(){all.push(json!({"section":si,"paragraph":pi,"errors":errors}));}
 }}json!({"passed":all.is_empty(),"errors":all})
}
fn diff(a:&Value,b:&Value,n:&mut usize){match(a,b){(Value::Object(a),Value::Object(b))=>for k in a.keys().chain(b.keys()).collect::<std::collections::BTreeSet<_>>(){match(a.get(k),b.get(k)){(Some(a),Some(b))=>diff(a,b,n),_=>*n+=1}},(Value::Array(a),Value::Array(b))=>{if a.len()!=b.len(){*n+=1;}for(a,b)in a.iter().zip(b){diff(a,b,n)}},(Value::Number(a),Value::Number(b))=>if(a.as_f64().unwrap()-b.as_f64().unwrap()).abs()>0.2{*n+=1},_=>if a!=b{*n+=1}}}
fn compact(d:&DocumentCore)->Value{let mut t=rhwp::private_selected_trace135(d);for section in t.as_array_mut().unwrap(){if section.is_null(){continue;}for f in section["formats"].as_array_mut().unwrap(){f.as_object_mut().unwrap().remove("source_text");f.as_object_mut().unwrap().remove("source_char_offsets");for l in f["lines"].as_array_mut().unwrap(){l.as_object_mut().unwrap().remove("runs");}}}t}
fn main(){let r=PathBuf::from(std::env::var("N001_ROOT").unwrap());let out=PathBuf::from(std::env::var("N001_OUT").unwrap());std::fs::create_dir_all(&out).unwrap();let f=r.join("docs/evidence/file-completion-2026-10-18/engine76/columns-native/fixtures/build/file-closure69-public/column2-candidate74/valid-negative-disk/baseline-unequal_columns.hwp");let bytes=std::fs::read(f).unwrap();assert_eq!(hash(&bytes),"2ee00d6ef1ea96b9c5fb7fd4f2a4a278b0d676dcb964afdae2dcb49b0ab4016e");let mut cases=vec![];
for(reps,name)in [(25,"wrap"),(500,"page")]{let mut d=DocumentCore::from_bytes(&bytes).unwrap();let before=layout(&d);let u=d.save_snapshot_native();let n=d.document().sections[0].paragraphs[0].text.chars().count();d.insert_text_native(0,0,n,&"쪽 경계까지 다시 조판하는 앞 문단입니다. ".repeat(reps)).unwrap();let edited=layout(&d);let model=hash(format!("{:?}",d.document()).as_bytes());let trace=compact(&d);let admission_before=rhwp::private_accept_diagnostic135(&d);let redo=d.save_snapshot_native();
let mut ex=vec![];for fmt in ["hwp","hwpx"]{let a=if fmt=="hwp"{d.export_hwp_with_adapter_snapshot_with_report()}else{d.export_hwpx_native_with_report()}.unwrap();let x=DocumentCore::from_bytes(a.bytes()).unwrap();let mut delta=0;diff(&edited,&layout(&x),&mut delta);ex.push(json!({"format":fmt,"diff":delta,"loss":a.content_loss().len()}));}
d.restore_snapshot_native(u).unwrap();let undo_exact=layout(&d)==before;d.restore_snapshot_native(redo).unwrap();let after=layout(&d);let mut changes=0;diff(&edited,&after,&mut changes);std::fs::write(out.join(format!("{name}-trace-before.json")),serde_json::to_vec_pretty(&trace).unwrap()).unwrap();std::fs::write(out.join(format!("{name}-trace-restored.json")),serde_json::to_vec_pretty(&compact(&d)).unwrap()).unwrap();std::fs::write(out.join(format!("{name}-edited-layout.json")),serde_json::to_vec(&edited).unwrap()).unwrap();std::fs::write(out.join(format!("{name}-restored-layout.json")),serde_json::to_vec(&after).unwrap()).unwrap();cases.push(json!({"case":name,"undoExact":undo_exact,"redoExact":after==edited,"redoGeometryDifferences":changes,"admissionBefore":admission_before,"admissionRestored":rhwp::private_accept_diagnostic135(&d),"documentDebugEqual":model==hash(format!("{:?}",d.document()).as_bytes()),"exports":ex,"coverage":coverage(&d)}));}
std::fs::write(out.join("history-result.json"),serde_json::to_vec_pretty(&json!({"cases":cases})).unwrap()).unwrap();}
