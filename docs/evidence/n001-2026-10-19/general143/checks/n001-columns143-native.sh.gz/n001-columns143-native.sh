#!/usr/bin/env bash
set -euo pipefail
repo=/mnt/c/Users/jjome/Documents/work/jueony
export RUSTUP_HOME="$repo/.tools/linux-rustup"
export CARGO_HOME="$repo/.tools/linux-cargo"
export PATH="$CARGO_HOME/bin:$PATH"
export CARGO_TARGET_DIR=/tmp/jueony-n001-output130-target
export N001_ROOT="$repo/build/n001-columns143-native/evidence"
cd "$repo/build/n001-columns143-native/source"
cargo test --offline --locked -p rhwp --lib current_frame_rows -j2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib current_physical_selections -j2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib native_computed_resource_matches_the_actual_pipeline_sources -j2 -- --nocapture --test-threads=1
