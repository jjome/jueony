from pathlib import Path
r=Path(__file__).resolve().parents[1]
s=(r/'build/seal-n001-checkpoint141.py').read_text(encoding='utf8')
s=s.replace('general141','general143').replace('n001-stack141','n001-columns143').replace('source-393f7940079a511f','source-aee538b35ed7649d').replace("=='393f7940079a511f'","=='aee538b35ed7649d'").replace("==136","==138")
s=s.replace("len(p['failures'])==4","len(p['failures'])==2").replace("==26 and u['fullMatrix']","==27 and u['fullMatrix']").replace("len(u['consoleErrors'])==2","len(u['consoleErrors'])==1").replace("['25','2','1']","['27','2','1']")
s=s.replace("area/'n001-extra141'","area/'n001-extra143'").replace("area/'n001-extra141/summary.json'","area/'n001-extra143/summary.json'")
s=s.replace("'nativeTests':28,'resourceInputs':261","'nativeTests':30,'resourceInputs':263").replace("'passed':52,'total':56,'failed':4","'passed':54,'total':56,'failed':2").replace("'passed':26,'total':29,'failed':3","'passed':27,'total':29,'failed':2").replace("'refusalConsoleErrors':2","'refusalConsoleErrors':1")
s=s.replace("'audit-general-live-layout132.mjs','verify-current-composition133.mjs'","'audit-general-live-layout132.mjs','verify-current-composition133.mjs','verify-whole-body-composition142.mjs','verify-current-suffix-budget142.mjs'")
s=s.replace("'n001-stack141-merged']","'n001-stack141-merged','n001-suffix142-merged','n001-columns143-merged']")
s=s.replace("'n001-issuer135/handoff-final']","'n001-issuer135/handoff-final','n001-suffix135-ledger3/handoff-final','n001-explicit-column138/handoff-final']")
s=s.replace("'resolve-n001-stack141.py'","'resolve-n001-stack141.py','resolve-n001-suffix142.py','resolve-n001-columns143.py'").replace("'seal-n001-checkpoint141.py'","'seal-n001-checkpoint143.py','prepare-n001-checkpoint143.py'")
s=s.replace("'finalize-n001-columns143.py'","'finalize-n001-stack141.py','resolve-n001-suffix142.py'")
s=s.replace("'n001-columns143-merged']","'n001-columns143-merged','n001-suffix142-merged']")
needle="(out/'summary.json').write_text"
extra="""whole=read(area/'n001-columns143-whole-body/result.json');assert whole['pass']==14 and whole['fail']==0
budget=read(area/'n001-columns143-budget/result.json');assert budget['status']=='PASS'and budget['sourceAndEventsUnchanged']and budget['pages']==128
prior=read(area/'n001-whole-body142-baseline141-final/result.json');assert prior['pass']==12 and prior['fail']==2
assert whole['metadata']['sourceId']==engine['sourceId']and budget['metadata']['sourceId']==engine['sourceId']
assert whole['verifierSha256']==prior['verifierSha256']
for folder in ['n001-columns143-whole-body','n001-columns143-budget','n001-whole-body142-baseline141-final']:
 copy(area/folder/'result.json','additional/'+folder+'/result.json')
for mode in ['whole-body','budget']:copy(area/('n001-columns143-'+mode+'.log'),'checks/'+mode+'.log')
summary['wholeBodyCoverage']={'passed':14,'total':14,'previous141Passed':12,'previous141Failed':2,'sameVerifier':True,'bothFormatDiskReopens':28}
summary['actualBudgetRefusal']={'pages':128,'explicitRenderError':True,'sourceAndEventsUnchanged':True,'largeDocumentSupport':False}
summary['parentEvidence']='../general141/SHA256-MANIFEST.json'
"""
s=s.replace(needle,extra+needle)
start=s.index("(out/'README.md').write_text(")
end=s.index("shutil.copy2",start)
s=s[:start]+'''(out/'README.md').write_text("""# N001 checkpoint143: complete suffix paint and explicit columns

Rust runtime, exact official source aee538b35ed7649d, 138 patches, 263 resource
inputs. Prior checkpoint141 remains immutable. Existing41 suites501/501,
TypeScript1036/1036, Native30/30, extras75 and bundle7 all pass; no skipped tests.
Public54/56, fixed79/88, isolated full headless app27/29. Remaining failures are
retained, so neither N001 nor the entire file preservation part is complete.

All body paragraphs in14 fixed public-input cases pass exact Unicode scalar and
UTF16 coverage/order/charX checks, plus28 both-format disk reopens. The identical
verifier detects2 astral late-body omissions in the previous141 engine (12/14).
Required-paint proofs cannot authorize source cache or complete export traces.
The original full-trace budget is unchanged; actual128-page suffix input fails
with an explicit RenderError and unchanged source/events. This is a rejection
test, not large-document support. Explicit columns bind actual selected immutable
formatters, accepted allocation, per-column table placement and physical frames.

No Hancom/GUI, credentials, providers, user documents or user windows were used.
45 unrelated working files stayed exact and were excluded from the review app.
Earlier-reader interoperability limits and all known failures remain recorded.
Original44 fixed inputs were not regenerated. Run python verify.py for hashes.
""",encoding='utf8')
''' +s[end:]
(r/'build/seal-n001-checkpoint143.py').write_text(s,encoding='utf8',newline='\n')
print('Prepared143 sealer; assertions run before evidence is created.')
