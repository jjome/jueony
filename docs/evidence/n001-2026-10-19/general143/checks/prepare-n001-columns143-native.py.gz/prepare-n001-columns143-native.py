from pathlib import Path
import shutil,re,hashlib,json
r=Path(__file__).resolve().parents[1];base=r/'build/rhwp-engine/source-aee538b35ed7649d';dest=r/'build/n001-columns143-native/source';assert not dest.exists()
shutil.copytree(base,dest,ignore=shutil.ignore_patterns('pkg','.git','target'))
assets=[];warm=r/'build/n001-output130/compile-source'
for f in (dest/'src').rglob('*.rs'):
 for rel in re.findall(r'include_(?:bytes|str)!\(\s*"([^"\n]+)"',f.read_text(encoding='utf8')):
  p=(f.parent/rel).resolve()
  if p.is_file():continue
  rp=p.relative_to(dest);src=warm/rp;assert src.is_file(),str(rp)
  p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,p);assets.append({'path':rp.as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
proof=[]
for f in sorted((base/'src').rglob('*')):
 if f.is_file():
  relative=f.relative_to(base);a=f.read_bytes();b=(dest/relative).read_bytes();assert a==b,str(relative)
  proof.append({'path':relative.as_posix(),'sha256':hashlib.sha256(a).hexdigest()})
(dest.parent/'preparation.json').write_text(json.dumps({'officialSource':str(base.relative_to(r)),'sourceFilesIdentical':proof,'extraNativeTestAssets':assets,'sourceCodeChanges':0},indent=2)+'\n',encoding='utf8')
print(json.dumps({'sourceFilesIdentical':len(proof),'extraNativeAssets':len(assets)}))
