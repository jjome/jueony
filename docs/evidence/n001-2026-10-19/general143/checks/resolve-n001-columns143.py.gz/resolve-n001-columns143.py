from pathlib import Path
import re,json
r=Path(__file__).resolve().parents[1];stage=r/'build/n001-columns143-merged'
names=['src/document_core/commands/document.rs','src/document_core/queries/rendering.rs','src/renderer/current_frame_rows_plan.rs','src/renderer/current_page_frames135.rs','src/renderer/layout.rs']
for name in names:
 p=stage/name;s=p.read_text(encoding='utf8')
 def resolve(m):
  a,b,c=m.group(1,2,3)
  if name.endswith('commands/document.rs'):
   assert c.endswith('        }else{return Ok(None);};\n')
   return c.removesuffix('        }else{return Ok(None);};\n')+a
  if name.endswith('queries/rendering.rs'):
   assert '.or(page_frames_paint)'in a and '.or(explicit_column_paint)'in c
   return a.replace('.or(page_frames_paint)','.or(page_frames_paint).or(explicit_column_paint)')
  if name.endswith('layout.rs'):
   return a.replace('page_content.column_contents.first()?.column_index','ctx.current_column_index()?')
  if not b.strip():return a+c
  assert 'tables:'in a and 'additional_frames:Vec::new()'in c
  return a.replace('tables:tables.clone()','tables:tables.clone(),additional_frames:Vec::new()').replace('tables:tables.iter().filter(|t|arithmetic_equal(t.incoming,t.top)).cloned().collect()','tables:tables.iter().filter(|t|arithmetic_equal(t.incoming,t.top)).cloned().collect(),additional_frames:Vec::new()')
 s,n=re.subn(r'^<<<<<<<[^\n]*\n(.*?)^\|\|\|\|\|\|\|[^\n]*\n(.*?)^=======\n(.*?)^>>>>>>>[^\n]*\n',resolve,s,flags=re.M|re.S);assert n>=1,(name,n);assert '<<<<<<<'not in s
 if name.endswith('current_frame_rows_plan.rs'):
  s=s.replace('rect,tables:Vec::new()};','rect,tables:Vec::new(),additional_frames:Vec::new()};')
 p.write_text(s,encoding='utf8',newline='\n')
# Adapt companion constructors without changing the old lane's decision logic.
name='src/renderer/current_equal_column_stack137.rs';p=stage/name;p.parent.mkdir(parents=True,exist_ok=True);s=(r/'build/rhwp-engine/source-f98aac5d3bc70283'/name).read_text(encoding='utf8');assert s.count('tables:tables.clone()};')==1;s=s.replace('tables:tables.clone()};','tables:tables.clone(),additional_frames:Vec::new()};');p.write_text(s,encoding='utf8',newline='\n')
(stage/'extra-files.json').write_text(json.dumps([name])+'\n',encoding='utf8')
name='src/renderer/current_explicit_column138.rs';p=stage/name;s=p.read_text(encoding='utf8');old='CandidateTable{paragraph:*pi,control:0,top,before:';assert s.count(old)==1;s=s.replace(old,'CandidateTable{paragraph:*pi,control:0,incoming:top,standard_anchor:None,top,before:')
old='rows.push(CurrentFrameParagraphRows{kind:CurrentFrameRowKind::FreshBody,section:0,paragraph:*pi,rows:projected});';assert s.count(old)==1;s=s.replace(old,'if !retains_ordinary_standard_body(p,&projected){'+old+'}');p.write_text(s,encoding='utf8',newline='\n')
