from pathlib import Path
import re
r=Path(__file__).resolve().parents[1];stage=r/'build/n001-suffix142-merged'
for name in ['src/document_core/queries/rendering.rs','src/renderer/selected_composition_observer127.rs']:
 p=stage/name;s=p.read_text(encoding='utf8')
 def resolve(m):
  a,b,c=m.group(1,2,3)
  if name.endswith('queries/rendering.rs'):
   marker='            self.pagination.get(sec_idx).and_then'
   assert a.count(marker)==1
   return a.split(marker)[0]+c.split('            if let Some(result)',1)[1].join(['            if let Some(result)',''])
  assert 'pages:_'in a and 'required_plain_paint:_'in c
  return a.replace('selected_composition_trace:_,','selected_composition_trace:_,required_plain_paint:_,')
 s,n=re.subn(r'^<<<<<<<[^\n]*\n(.*?)^\|\|\|\|\|\|\|[^\n]*\n(.*?)^=======\n(.*?)^>>>>>>>[^\n]*\n',resolve,s,flags=re.M|re.S)
 assert n==1,(name,n);assert '<<<<<<<'not in s;p.write_text(s,encoding='utf8',newline='\n')
