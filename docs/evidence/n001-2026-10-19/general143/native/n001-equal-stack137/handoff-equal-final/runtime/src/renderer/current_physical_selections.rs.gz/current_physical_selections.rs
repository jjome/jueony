//! Current renderer-selected inputs, owned by one nonserialized page frame.
//! This is not a source-row lease, descriptor or export permission. A consumer
//! must separately prove fresh composition, final allocator ownership, immutable
//! dependent input, current resources, and the actual output representation.
use crate::renderer::{composer::ComposedLine, page_layout::LayoutRect, pagination::{PageContent,ColumnContent,PageItem},render_tree::NodeId};
#[derive(Debug,Clone)]
pub(crate) struct BodyFrameSelection {
 pub(crate) node:NodeId,pub(crate) section:usize,pub(crate) page:u32,pub(crate) column_ordinal:usize,
 pub(crate) column:u16,pub(crate) rect:LayoutRect,pub(crate) zone_y:f64,pub(crate) has_zone:bool,
 pub(crate) items:Vec<PageItem>,pub(crate) complete:bool,
}
#[derive(Debug,Clone)]
pub(crate) struct BodyRowFrame {
 pub(crate) node:NodeId,pub(crate) paragraph:usize,pub(crate) line:usize,
 pub(crate) effective_column_x:f64,pub(crate) effective_column_width:f64,
 pub(crate) available_width:f64,pub(crate) margin_left:f64,pub(crate) margin_right:f64,
 pub(crate) inline_offset:f64,pub(crate) numbering_offset:f64,pub(crate) physical_text_y:f64,
 pub(crate) final_line_box_height:f64,pub(crate) baseline:f64,pub(crate) physical_frame_rows:bool,
 pub(crate) stored_horizontal_span_used:bool,pub(crate) has_wrap_anchor:bool,pub(crate) equation_adjusted:bool,
}
#[derive(Debug,Clone)]
pub(crate) struct BodyRowSelection {pub(crate) frame:BodyRowFrame,pub(crate) selected:ComposedLine}
#[derive(Debug,Clone)]
pub(crate) struct WholeTableSelection {
 pub(crate) node:NodeId,pub(crate) paragraph:usize,pub(crate) control:usize,
 pub(crate) incoming_y:f64,pub(crate) paragraph_y:f64,pub(crate) selected_y:f64,
 pub(crate) selected_outer_inset:f64,pub(crate) visual_height:f64,pub(crate) visual_end:f64,
 pub(crate) flow_end:f64,pub(crate) lane_input:Option<[f64;6]>,pub(crate) typed_float:bool,
 pub(crate) inline:bool,pub(crate) treat_as_char:bool,
 pub(crate) selected_border_box:Option<[f64;4]>,
}
#[derive(Debug,Clone,Default)]
pub(crate) struct CurrentPhysicalSelections {
 frames:Vec<BodyFrameSelection>,rows:Vec<BodyRowSelection>,tables:Vec<WholeTableSelection>,
 text_bytes:usize,item_count:usize,invalid:bool,enabled:bool,
 source_frame_binding:Option<(usize,[u8;32])>,
}
impl CurrentPhysicalSelections {
 pub(crate) fn enable_new_page_capture(&mut self){if self.frames.is_empty() && self.rows.is_empty() && self.tables.is_empty() && !self.invalid {self.enabled=true;}}
 pub(crate) fn bind_current_plan(&mut self,plan:&super::current_frame_rows_plan::CurrentFramePaintPlan){
  if !self.enabled || self.invalid || self.source_frame_binding.is_some() || !self.frames.is_empty() {self.invalid=true;return;}
  self.source_frame_binding=Some(plan.receipt_binding());
 }
 pub(crate) fn matches_current_plan(&self,plan:&super::current_frame_rows_plan::CurrentFramePaintPlan)->bool{
  self.enabled && !self.invalid && self.source_frame_binding==Some(plan.receipt_binding())
 }
 pub(crate) fn frames(&self)->Option<&[BodyFrameSelection]>{(self.enabled && !self.invalid && self.frames.iter().all(|f|f.complete)).then_some(&self.frames)}
 pub(crate) fn rows(&self)->Option<&[BodyRowSelection]>{self.frames()?;Some(&self.rows)}
 pub(crate) fn tables(&self)->Option<&[WholeTableSelection]>{self.frames()?;Some(&self.tables)}
 pub(crate) fn register_frame(&mut self,node:NodeId,page:&PageContent,column:&ColumnContent,rect:&LayoutRect){
  if !self.enabled || self.invalid{return;}let Some(ordinal)=page.column_contents.iter().position(|c|std::ptr::eq(c,column))else{self.invalid=true;return;};
  if self.frames.len()>=128 || column.items.len()>4096-self.item_count || self.frames.iter().any(|f|f.node==node)
   || [rect.x,rect.y,rect.width,rect.height,column.zone_y_offset].iter().any(|v|!v.is_finite())
   || rect.width<=0.0 || rect.height<=0.0 || column.items.iter().any(|i|matches!(i,PageItem::PartialTable{start_cut,end_cut,..} if start_cut.len()>64 || end_cut.len()>64)){
   self.invalid=true;return;
  }
  self.item_count+=column.items.len();
  self.frames.push(BodyFrameSelection{node,section:page.section_index,page:page.page_index,column_ordinal:ordinal,column:column.column_index,
   rect:*rect,zone_y:column.zone_y_offset,has_zone:column.zone_layout.is_some(),items:column.items.clone(),complete:false});
 }
 pub(crate) fn finish_frame(&mut self,node:NodeId){if let Some(frame)=self.frames.iter_mut().find(|f|f.node==node){frame.complete=true;}}
 pub(crate) fn record_row(&mut self,row:BodyRowFrame,selected:&ComposedLine){
  if !self.enabled || self.invalid || !self.frames.iter().any(|f|f.node==row.node){return;}
  let Some(bytes)=selected.runs.iter().try_fold(0usize,|sum,r|sum.checked_add(r.text.len())?.checked_add(r.display_text.as_ref().map_or(0,String::len)))else{self.invalid=true;return;};
  if self.rows.len()>=4096 || selected.runs.len()>256 || bytes>2*1024*1024-self.text_bytes
   || [row.effective_column_x,row.effective_column_width,row.available_width,row.margin_left,row.margin_right,row.inline_offset,row.numbering_offset,row.physical_text_y,row.final_line_box_height,row.baseline].iter().any(|v|!v.is_finite()){
   self.invalid=true;return;
  }
  self.text_bytes+=bytes;self.rows.push(BodyRowSelection{frame:row,selected:selected.clone()});
 }
 pub(crate) fn record_table(&mut self,table:WholeTableSelection){
  if !self.enabled || self.invalid || !self.frames.iter().any(|f|f.node==table.node){return;}
  if self.tables.len()>=1024 || [table.incoming_y,table.paragraph_y,table.selected_y,table.selected_outer_inset,table.visual_height,table.visual_end,table.flow_end].iter().any(|v|!v.is_finite())
   || table.selected_border_box.as_ref().is_some_and(|v|v.iter().any(|v|!v.is_finite()))
   || table.lane_input.as_ref().is_some_and(|v|v.iter().any(|v|!v.is_finite())){self.invalid=true;return;}
  self.tables.push(table);
 }
}

#[cfg(test)] mod tests {
 use super::*;
 #[test] fn explicit_page_capture_preserves_tree_source_events_and_keeps_disabled_empty(){
  let mut core=crate::DocumentCore::new_empty();core.create_blank_document_native().unwrap();
  core.insert_text_native(0,0,0,&"Current physical body frame. ".repeat(20)).unwrap();
  for _ in 0..3 {let tail=core.document().sections[0].paragraphs.len()-1;
   core.create_table_ex_native(0,tail,0,2,2,false,None,None).unwrap();}
  let source=format!("{:?}",core.document());let events=core.serialize_event_log();
  for page in 0..core.page_count(){let normal=core.build_page_tree(page).unwrap();
   assert!(normal.frame.current_physical_selections.frames().is_none());
   let captured=core.build_page_tree_with_current_selections(page).unwrap();
   assert_eq!(serde_json::to_value(&normal).unwrap(),serde_json::to_value(&captured).unwrap());
   let facts=&captured.frame.current_physical_selections;
   let frames=facts.frames().expect("all current body frames completed");assert!(!frames.is_empty());
   let rows=facts.rows().unwrap();assert!(!rows.is_empty());
   for row in rows {let frame=frames.iter().find(|f|f.node==row.frame.node).unwrap();
    assert_eq!(frame.page,page);assert_eq!(frame.section,0);assert!(row.frame.available_width.is_finite());
    assert!(row.frame.physical_text_y.is_finite());assert!(row.selected.runs.len()<=256);}
   for table in facts.tables().unwrap(){assert!(frames.iter().any(|f|f.node==table.node));assert!(table.selected_y.is_finite());}
  }
  assert_eq!(source,format!("{:?}",core.document()));assert_eq!(events,core.serialize_event_log());
 }
 #[test] fn observations_are_never_usable_before_completed_frame(){
  let mut data=CurrentPhysicalSelections::default();assert!(data.frames().is_none());
  data.enable_new_page_capture();data.frames.push(BodyFrameSelection{node:1,section:0,page:0,column_ordinal:0,column:0,
   rect:LayoutRect{x:0.0,y:0.0,width:100.0,height:100.0},zone_y:0.0,has_zone:false,items:vec![],complete:false});
  assert!(data.rows().is_none());data.finish_frame(1);assert_eq!(data.frames().unwrap().len(),1);
  data.invalid=true;assert!(data.frames().is_none());assert!(data.rows().is_none());assert!(data.tables().is_none());
 }
}
