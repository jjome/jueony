from pathlib import Path
import hashlib,json,difflib,shutil,re
stage=Path('build/n001-explicit-column138');s=stage/'source';b=Path('build/n001-frames135/source');out=stage/'handoff-final'
assert not out.exists();out.mkdir()
sha=lambda x:hashlib.sha256(x).hexdigest()
canon=lambda p:p.read_bytes().replace(b'\r\n',b'\n')
files=[];patch=[];basefiles=[]
for p in sorted((b/'src').rglob('*.rs')):basefiles.append({'path':p.relative_to(b).as_posix(),'canonicalSha256':sha(canon(p))})
for p in sorted((s/'src').rglob('*.rs')):
 rel=p.relative_to(s).as_posix();old=b/rel;c=canon(p);bc=canon(old)if old.exists()else None
 if c==bc:continue
 assert not c.endswith(b'\n\n'),rel
 for line in difflib.unified_diff((bc or b'').decode().splitlines(),c.decode().splitlines()):
  assert not(line.startswith('+')and not line.startswith('+++')and line[1:]!=line[1:].rstrip()),(rel,line)
 dst=out/'runtime'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(p.read_bytes())
 files.append({'path':rel,'canonicalSha256':sha(c),'baseCanonicalSha256':sha(bc)if bc is not None else None,'rawSha256':sha(p.read_bytes()),'baseRawSha256':sha(old.read_bytes())if old.exists()else None})
 patch.append(f'diff --git a/{rel} b/{rel}\n');patch.extend(difflib.unified_diff((bc or b'').decode().splitlines(True),c.decode().splitlines(True),fromfile=f'a/{rel}'if old.exists()else'/dev/null',tofile=f'b/{rel}'))
assert len(files)==9,[f['path']for f in files]
pp=out/'current-explicit-column-frames138-after135.patch';pp.write_bytes(''.join(patch).encode())
base='frozen-explicit-page-section-frames135';(out/'root-merge-input.json').write_text(json.dumps({'base':base,'basePath':str(b),'files':files},indent=2)+'\n')
guards=['src/renderer/generated_column_stack.rs','src/renderer/composer.rs','src/renderer/composer/line_breaking.rs','src/model/raw_provenance.rs','src/model/native_computed_rows.rs','src/document_core/native_computed_rows.rs','src/serializer/hwpx/mod.rs','src/serializer/hwpx/current_frame_rows.rs','src/renderer/layout/current_body_stack.rs','src/renderer/current_physical_selections.rs','src/renderer/selected_composition_observer127.rs','src/renderer/layout/paragraph_layout.rs','src/lib.rs']
guardproof=[]
for rel in guards:
 assert (b/rel).read_bytes()==(s/rel).read_bytes(),rel
 guardproof.append({'path':rel,'byteExact':True,'rawSha256':sha((s/rel).read_bytes())})
old=canon(b/'src/renderer/current_frame_rows_plan.rs').decode();new=canon(s/'src/renderer/current_frame_rows_plan.rs').decode()
old=old[old.index("impl<'doc> CurrentFrameCandidate"):old.index('#[cfg(test)]')]
new=new[new.index("impl<'doc> CurrentFrameCandidate"):new.index('#[cfg(test)]')].replace(',additional_frames:Vec::new()','')
assert old==new,'existing singleframe constructor/finalizer remains exact apart from inert empty list'
log=(stage/'native-final-portable259.log').read_text(encoding='utf8');assert 'test result: FAILED'not in log and 'error['not in log
assert sum(map(int,re.findall(r'test result: ok\. (\d+) passed',log)))==14
assert len(re.findall(r'0 failed; 0 ignored;',log))==3
j=json.loads((stage/'column-results.json').read_text());assert j['observations']==36 and not j['failures']and len(j['reports'])==3
assert all(len(r['results'])==12 and not r['failures']and all(x['geometry']==0 for x in r['results'])for r in j['reports'])
j=json.loads((stage/'original134-differential.json').read_text());assert not j['failures']and len(j['results'])==3 and all(x['geometry']==0 for x in j['results'])
cases=['column2','column3','column2-astral'];zips=sum(json.loads((stage/f'{c}-public/independent-xml-coordinates.json').read_text())['assertions']for c in cases);assert zips==63
paths=lambda p:re.findall(r'\("([^"]+)",include_bytes!',p.read_text(encoding='utf8'))
x=paths(b/'src/model/native_computed_resource.rs');y=paths(s/'src/model/native_computed_resource.rs');assert len(x)==258 and len(y)==259 and y[:258]==x
proof={'base':base,'basePath':str(b),'files':files,'guardFiles':guardproof,'oldSingleFrameConstructorFinalizerExactExceptInertEmptyFrameList':True,'patchSha256':sha(pp.read_bytes()),'incomingFullSourceFiles':len(basefiles)}
(out/'source-proof.json').write_text(json.dumps(proof,indent=2)+'\n');(out/'incoming-full-source-canonical.json').write_text(json.dumps(basefiles,indent=2)+'\n')
for name in ['native-final-portable259.log','native-final-exact259.log','native-final.sh','resource259-proof.json','update-resource.py','original-differential.mjs','original134-differential.json','base.json','column-results.json','freeze-handoff.py']:
 shutil.copyfile(stage/name,out/name)
for c in cases:shutil.copytree(stage/f'{c}-public',out/f'{c}-public');shutil.copyfile(stage/f'{c}-official134-original.json',out/f'{c}-official134-original.json')
info={'status':'FROZEN_NATIVE14_PASS_EXPLICIT_EQUAL_COLUMN_WHOLE_FRAMES_PARENT_WASM_PENDING','base':base,'basePath':str(b),'files':9,'patchSha256':sha(pp.read_bytes()),'resource':json.loads((stage/'resource259-proof.json').read_text())['resource'],'resourceInputs':259,'allIncoming258RetainedExactOrder':True,'native':{'plan':11,'physical':2,'resource':1,'passed':14,'failed':0,'ignored':0},'actualPublic':{'scenarios':cases,'fourExportApis':12,'retainedTailUndoRedo':6,'mixedDiskReopens':18,'observations':36,'geometryDifferences':0,'contentLoss':0,'sourceAndEventMutation':False,'independentRawZipCoordinateAssertions':63,'privateDescriptorPresent':False},'originalNativeDifferential':{'baseline':'official134 exact WASM','scenarios':3,'everyPublishedGeometryFieldExactDifferences':0},'contract':['Actual equal2/3 configured columns and every used column, exact explicit ColumnBreak first owner; no partial row owners or reused-width formatter.','Current bodywide reservation uses the unchanged production current CommonObjAttr geometry query; no source LINE_SEG origin is authority.','Flow origin and physical origin are separate: bodyY+actual bodywide reservation+(flowBefore-columnStart)-unpaintedBefore; all actual body and newly emitted Table border receipts must match.','Actual per-column identity comes from exact three map-owner pointers in the current ColumnItemCtx, never the first column or rectangle guessing.','Source-free actual body_for_style formatter has exact selected rows/runs/UTF16/space/style; all final allocator/source/trace/resource and whole-source target binder remain mandatory.','Existing singleframe constructor/finalizer unchanged except an inert empty additional_frames list; old raw, composer, serializer/binder and source guards are byte-exact.','Only exact live Core source ptr; no copied source/lease/cache or old resource gains authority.','All tests now use optional evidence root with temporary directory fallback; no environment-required test.' ],'parentMerge':['Incoming root CandidateTable has new incoming/standard_anchor fields: for this column factory incoming=top and standard_anchor=None; keep parent typed table-top return.','Every preexisting CurrentFramePaintPlan constructor must initialize additional_frames empty; only this column factory fills the exact finite list.','This patch is against frozen135, not official134 or root141. Keep parent offset/137 typed query semantics while adding exact-column owner dispatch.'],'limitations':['Whole paragraphs/tables only; partial/unequal/Some/wrap/notes/HF/master/CompletedRows remain refused.','Visible nonempty floating table-host follow-up in root multiple-sections public case remains separate unresolved scope; initial multi-section output is exact0.','Literal metadata-clone/stamped-export source ptr remains unsupported by this new path; no rebind to old trace.','No new Hancom/UI/COM. Parent exact official WASM+production guard+frontend full matrices still required.','This finite tranche is not full N001 completion.'],'preservedFailedStages':['native-final.log resource259 mismatch before correct resource regeneration (runtime source then unchanged); final exact259/portable259 logs all14 pass.','Earlier first-column identity diagnostics left34 then14 differences; current actual-column owner yields0.']}
(out/'HANDOFF.json').write_text(json.dumps(info,ensure_ascii=False,indent=2)+'\n');print(json.dumps(info,ensure_ascii=False,indent=2))
