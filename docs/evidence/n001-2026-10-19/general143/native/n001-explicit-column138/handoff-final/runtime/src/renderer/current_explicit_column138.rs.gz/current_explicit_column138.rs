//! Current explicit equal-column whole frames; separate from legacy source/cache authority.
use super::*;
pub(crate) struct CurrentExplicitColumnCandidate<'doc>{frames:Vec<CurrentFrameCandidate<'doc>>,paint:CurrentFramePaintPlan}
impl<'doc> CurrentExplicitColumnCandidate<'doc>{
 pub(crate) fn from_core(core:&crate::DocumentCore,source:&'doc Document)->Option<Self>{
  if !std::ptr::eq(source,core.document())||source.sections.len()!=1||core.pagination.len()!=1||core.measured_tables.len()!=1{return None;}
  let result=&core.pagination[0];let [page]=result.pages.as_slice()else{return None;};if !matches!(page.column_contents.len(),2|3){return None;}
  let mut paragraphs=0usize;let mut cells=0usize;let mut cell_paras=0usize;let mut bytes=0usize;
  for section in &source.sections{for p in &section.paragraphs{paragraphs=paragraphs.checked_add(1)?;bytes=bytes.checked_add(p.text.len())?;if paragraphs>128||bytes>2*1024*1024{return None;}
   for c in &p.controls{if let crate::model::control::Control::Table(t)=c{cells=cells.checked_add(t.cells.len())?;if cells>4096{return None;}
    for cell in &t.cells{cell_paras=cell_paras.checked_add(cell.paragraphs.len())?;if cell_paras>4096{return None;}
     for p in &cell.paragraphs{bytes=bytes.checked_add(p.text.len())?;if bytes>2*1024*1024{return None;}}
    }
   }}
  }}
  let ps=&source.sections[0].paragraphs;let styles=core.resolve_render_styles_for_section(0);let context=source.reset_flow_contexts().first().copied().flatten()?;
  let reserved=core.layout_engine.calculate_body_wide_shape_reserved(ps,&page.column_contents,&page.layout.body_area);if reserved.is_empty(){return None;}
  let mut maximum=page.layout.body_area.y;
  for(pi,bottom)in reserved{let p=ps.get(pi)?;let [crate::model::control::Control::Table(table)]=p.controls.as_slice()else{return None;};
   let mut measured=core.measured_tables[0].iter().filter(|m|m.para_index==pi&&m.control_index==0);let m=measured.next()?;if measured.next().is_some(){return None;}
   if !arithmetic_equal(bottom,page.layout.body_area.y+m.total_height+super::super::hwpunit_to_px(i32::from(table.outer_margin_bottom),core.dpi)){return None;}
   maximum=maximum.max(bottom);
  }
  let reservation=maximum-page.layout.body_area.y;if reservation<=0.0||reservation>=page.layout.body_area.height{return None;}
  let mut frames=vec![];let mut start=0;for column in 0..page.column_contents.len(){let frame=Self::column(source,core.source_format,result,&styles,&core.measured_tables[0],core.effective_layout_profile(),core.dpi,column,start,reservation,context)?;start+=page.column_contents[column].items.len();frames.push(frame);}
  if start!=ps.len()||frames.iter().flat_map(|f|&f.rows).map(|p|p.rows.len()).sum::<usize>()>4096{return None;}
  let mut h=blake3::Hasher::new();h.update(b"current-explicit-columns138-receipt-only-1\0");for frame in &frames{h.update(&frame.generation);}let generation=*h.finalize().as_bytes();
  let paint=CurrentFramePaintPlan{source_paragraphs:ps.as_ptr()as usize,generation,section:0,page:0,column:0,rect:page.layout.column_areas[0],tables:Vec::new(),additional_frames:Vec::new()};
  let mut paint=paint;for frame in &mut frames{frame.paint.generation=generation;frame.paint.tables=frame.tables.clone();}
  paint.tables=frames[0].tables.clone();paint.additional_frames=frames.iter().skip(1).map(|f|f.paint.clone()).collect();Some(Self{frames,paint})
 }
 pub(crate) fn paint_plan(&self)->CurrentFramePaintPlan{self.paint.clone()}
 pub(crate) fn finalize(self,physical:&super::super::current_physical_selections::CurrentPhysicalSelections)->Option<CurrentFrameRowsPlan<'doc>>{
  if !physical.matches_current_plan(&self.paint){return None;}
  let frames=physical.frames()?;if frames.len()!=self.frames.len(){return None;}
  let source=self.frames.first()?.source;
  if physical.rows()?.len()!=self.frames.iter().flat_map(|f|&f.bodies).map(|b|b.fresh.rows.len()).sum::<usize>()||physical.tables()?.len()!=self.frames.iter().map(|f|f.tables.len()).sum::<usize>(){return None;}
  let mut rows=vec![];
  for(candidate,frame)in self.frames.into_iter().zip(frames){
   if frame.section!=0||frame.page!=0||frame.column!=candidate.paint.column||frame.column_ordinal!=usize::from(candidate.paint.column)||frame.has_zone||frame.zone_y!=0.0||frame.rect.x!=candidate.paint.rect.x||frame.rect.y!=candidate.paint.rect.y||frame.rect.width!=candidate.paint.rect.width||frame.rect.height!=candidate.paint.rect.height{return None;}
   let painted=physical.rows()?;for body in &candidate.bodies{let actual=painted.iter().filter(|r|r.frame.node==frame.node&&r.frame.paragraph==body.paragraph).collect::<Vec<_>>();if actual.len()!=body.fresh.rows.len(){return None;}
    let mut offset=0.0;for(i,(fresh,row))in body.fresh.composition.lines.iter().zip(actual).enumerate(){let f=&row.frame;
     let width=if f.stored_horizontal_span_used{super::super::hwpunit_to_px(fresh.segment_width,super::super::DEFAULT_DPI)}else{frame.rect.width};
     if f.line!=i||f.equation_adjusted||f.has_wrap_anchor||f.physical_frame_rows||f.effective_column_x!=frame.rect.x||f.effective_column_width!=width||f.available_width!=width||f.margin_left!=0.0||f.margin_right!=0.0||f.inline_offset!=0.0||f.numbering_offset!=0.0||!arithmetic_equal(f.physical_text_y,body.physical_y+offset)||(!same_selected_line(fresh,&row.selected)&&!(body.allow_empty_unused_width&&same_empty_line_ignoring_unused_width(fresh,&row.selected))){return None;}
     offset+=super::super::hwpunit_to_px(fresh.line_height.checked_add(fresh.line_spacing)?,super::super::DEFAULT_DPI);
    }
   }
   for table in &candidate.tables{let mut actual=physical.tables()?.iter().filter(|t|t.node==frame.node&&t.paragraph==table.paragraph&&t.control==table.control);let t=actual.next()?;let border=t.emitted_border?;
    if actual.next().is_some()||t.inline||t.treat_as_char||t.typed_float||t.selected_outer_inset!=0.0||!arithmetic_equal(t.incoming_y,table.top)||!arithmetic_equal(t.paragraph_y,table.top)||!arithmetic_equal(t.selected_y,table.top)||!arithmetic_equal(border[1],table.top)||!arithmetic_equal(t.visual_height,table.body)||!arithmetic_equal(border[3],table.body)||!arithmetic_equal(t.visual_end,table.top+table.body)||!arithmetic_equal(t.flow_end,table.top+table.body){return None;}
   }
   rows.extend(candidate.rows);
  }
  Some(CurrentFrameRowsPlan{source,resource:crate::model::native_computed_resource::RESOURCE,allocation_generation:self.paint.generation,paragraphs:rows})
 }
 fn column(source:&'doc Document,format:crate::parser::FileFormat,result:&super::super::pagination::PaginationResult,
 styles:&super::super::style_resolver::ResolvedStyleSet,measured:&[super::super::height_measurer::MeasuredTable],
 profile:crate::model::provenance::LayoutCompatibilityProfile,dpi:f64,column_index:usize,start:usize,reservation:f64,definition_context:[u8;32])->Option<CurrentFrameCandidate<'doc>>{
 use super::super::pagination::PageItem;use crate::model::{control::Control,paragraph::ColumnBreakType};
 if source.sections.len()!=1||source.provenance.hwp3_lineage||!source.bin_data_content.is_empty()||result.pages.len()!=1
 ||!result.hidden_empty_paras.is_empty()||!result.pre_emitted_host_paras.is_empty()||!result.wrap_around_paras.is_empty()
 ||!result.endnotes.is_empty()||!result.endnote_paragraphs.is_empty()||dpi!=super::super::DEFAULT_DPI{return None;}
 match format{crate::parser::FileFormat::Hwp if profile.native_hwp5_layout()=>{},crate::parser::FileFormat::Hwpx if profile.hwp5_origin_hwpx()=>{},_=>return None}
 let section=&source.sections.first()?.section_def;
 if section.line_grid!=0||section.char_grid!=0||section.text_direction!=0||!section.master_pages.is_empty()||!section.extra_child_records.is_empty(){return None;}
 let ps=&source.sections.first()?.paragraphs;if ps.is_empty()||ps.len()>128||ps.iter().any(|p|p.completed_native_rows.is_some()){return None;}
 let [Control::SectionDef(_),Control::ColumnDef(columns)]=ps.first()?.controls.as_slice()else{return None;};
 if !matches!(columns.column_count,2|3)||!columns.same_width||columns.proportional_widths||columns.separator_type!=0||columns.separator_width!=0||columns.separator_color!=0||!columns.widths.is_empty()||!columns.gaps.is_empty()
 ||columns.column_type!=crate::model::page::ColumnType::Normal||columns.direction!=crate::model::page::ColumnDirection::LeftToRight{return None;}
 match format{crate::parser::FileFormat::Hwp=>if columns.raw_attr!=0&&columns.raw_attr!=0x1000|(u16::from(columns.column_count)<<2){return None;},crate::parser::FileFormat::Hwpx=>if columns.raw_attr!=0{return None;},_=>return None}
 if styles.reset_flow_contexts.first().copied().flatten()!=Some(definition_context){return None;}
 let trace=result.selected_composition_trace.as_ref()?;
 if trace.section()!=0||trace.resource()!=crate::model::native_computed_resource::RESOURCE
 ||!trace.matches_source(ps,Some(definition_context),profile,dpi)
 ||!trace.matches_finalized_result(result){return None;}
 let page=&result.pages[0];if page.page_index!=0||page.section_index!=0||page.column_contents.len()!=usize::from(columns.column_count)||page.layout.column_areas.len()!=usize::from(columns.column_count)
 ||!page.footnotes.is_empty()||page.active_header.is_some()||page.active_footer.is_some()||page.active_master_page.is_some()||!page.extra_master_pages.is_empty(){return None;}
 let col=page.column_contents.get(column_index)?;let rect=*page.layout.column_areas.get(column_index)?;
 if rect.y!=page.layout.body_area.y||rect.height!=page.layout.body_area.height||col.column_index as usize!=column_index||!arithmetic_equal(col.start_height,if column_index==0{0.0}else{reservation})||col.endnote_flow||col.zone_layout.is_some()||col.zone_y_offset!=0.0
 ||!col.wrap_anchors.is_empty()||!col.wrap_around_paras.is_empty()||!col.inline_placements.is_empty()||!col.inline_flow_plans.is_empty()
 ||!col.overlay_continuations.is_empty()||!col.overlay_cuts.is_empty()||col.items.is_empty()
 ||trace.commits().len()+trace.whole_tables().len()!=result.pages.iter().map(|p|p.column_contents.iter().map(|c|c.items.len()).sum::<usize>()).sum::<usize>()||!trace.tables().is_empty(){return None;}
 let mut flow=col.start_height;let mut unpainted=0.0;let mut bodies=vec![];let mut tables=vec![];let mut rows=vec![];
 for (slot,item) in col.items.iter().enumerate(){match item{
 PageItem::FullParagraph{para_index:pi}=>{
  if *pi!=start.checked_add(slot)?{return None;}let p=ps.get(*pi)?;let fresh=fresh_column_body_rows(p,styles,rect.width,dpi)?;
  if *pi==0 {if p.column_type!=ColumnBreakType::Section{return None;}}else if (if slot==0&&column_index>0{p.column_type!=ColumnBreakType::Column}else{p.column_type!=ColumnBreakType::None})||!p.controls.is_empty(){return None;}
  let mut cs=trace.commits().iter().filter(|c|c.paragraph==*pi);let c=cs.next()?;if cs.next().is_some(){return None;}
  let f=trace.format(c.format_id)?;let empty=p.text.is_empty()&&p.controls.is_empty()&&fresh.composition.lines.len()==1;
  if c.page!=Some(0)||c.column as usize!=column_index||c.committed_item_index!=Some(slot)||c.final_membership!=Some(true)||c.row_start!=0||c.row_end!=fresh.rows.len()
  ||c.reused_multicolumn_format||c.same_format_reused_after_slot_change||c.trimmed_before!=0.0||c.actual_column_width_px!=rect.width
  ||!arithmetic_equal(c.flow_before,flow)||!c.metrics_still_match_selected_format||!c.range_inside_selected_composition
  ||f.source_text!=p.text||f.source_char_offsets!=p.char_offsets||f.paragraph_style!=fresh.composition.para_style_id
  ||(!empty&&f.actual_input_width_px!=Some(rect.width))||f.known_square_band||f.has_numbering||f.has_horizontal_shaping
  ||!f.tac_controls.is_empty()||!f.footnote_positions.is_empty()||!f.tab_extended.is_empty()
  ||f.inline_controls.len()!=fresh.composition.inline_controls.len()
  ||!f.inline_controls.iter().zip(&fresh.composition.inline_controls).all(|((line,index,kind),c)|*line==c.line_index&&*index==c.control_index&&*kind==format!("{:?}",c.control_type))
  ||f.before!=0.0||f.after!=0.0||f.lines.len()!=fresh.composition.lines.len()
  ||!f.lines.iter().zip(&fresh.composition.lines).all(|(a,b)|fact_line_matches(a,b,empty)){return None;}
  let total:f64=fresh.rows.iter().map(|r|super::super::hwpunit_to_px(r.line_height+r.line_spacing,dpi)).sum();
  if !arithmetic_equal(c.advance,total)||!arithmetic_equal(c.flow_after,c.flow_before+total)||c.flow_after>rect.height{return None;}
  let y=rect.y+reservation+c.flow_before-col.start_height-unpainted;let mut projected=fresh.rows.clone();let mut offset=0.0;
  for row in &mut projected{row.vertical_pos=integer_hu(y-rect.y+offset,dpi)?;offset+=super::super::hwpunit_to_px(row.line_height+row.line_spacing,dpi);}
  rows.push(CurrentFrameParagraphRows{kind:CurrentFrameRowKind::FreshBody,section:0,paragraph:*pi,rows:projected});bodies.push(CandidateBody{paragraph:*pi,physical_y:y,fresh,allow_empty_unused_width:empty});flow=c.flow_after;
 },PageItem::Table{para_index:pi,control_index:ci}=>{
  if *pi!=start.checked_add(slot)?||*ci!=0{return None;}let p=ps.get(*pi)?;let [Control::Table(table)]=p.controls.as_slice()else{return None;};
  if !p.text.is_empty()||p.char_count!=9||!p.char_offsets.is_empty()||(if slot==0&&column_index>0 {p.column_type!=ColumnBreakType::Column}else{p.column_type!=ColumnBreakType::None})
  ||p.completed_native_rows.is_some()||p.stored_text_partition_is_dirty()||p.cell_format_vpos_dirty||!p.field_ranges.is_empty()||!p.range_tags.is_empty()
  ||!p.tab_extended.is_empty()||p.layout_only_fill_lines!=0||!crate::renderer::generated_column_stack::plain_table(table,|q|q.controls.is_empty()&&q.field_ranges.is_empty()&&q.range_tags.is_empty()&&q.tab_extended.is_empty())
  ||!table.common.raw_extra.is_empty()||table.raw_table_record_extra.iter().any(|b|*b!=0)
 ||i32::try_from(table.common.width).ok()?.checked_add(i32::from(table.outer_margin_left))?.checked_add(i32::from(table.outer_margin_right))?!=integer_hu(page.layout.body_area.width,dpi)?{return None;}
  match format{crate::parser::FileFormat::Hwp=>if !native_table_common_exact(table){return None;},crate::parser::FileFormat::Hwpx=>if !table.raw_ctrl_data.is_empty(){return None;},_=>return None}
  let mut ms=measured.iter().filter(|m|m.para_index==*pi&&m.control_index==0);let m=ms.next()?;if ms.next().is_some()||m.caption_height!=0.0||m.total_height<=0.0||!m.total_height.is_finite()
  ||integer_hu(m.total_height,dpi)?!=i32::try_from(table.common.height).ok()?{return None;}
  let mut ts=trace.whole_tables().iter().filter(|t|t.paragraph==*pi&&t.control==0);let t=ts.next()?;if ts.next().is_some(){return None;}
  if t.page!=Some(0)||t.column as usize!=column_index||t.post_page!=Some(0)||t.post_column as usize!=column_index||t.committed_item_index!=slot||t.final_membership!=Some(true)
  ||t.pre_text_height!=0.0||t.pre_text_end!=0||!arithmetic_equal(t.flow_before,flow)||t.before<0.0||t.after_for_fit<0.0
  ||t.body_height!=m.total_height||!arithmetic_equal(t.table_total_height,t.before+t.body_height+t.after_for_fit)
  ||t.flow_after>rect.height||t.full_after<0.0
  ||integer_hu(t.full_after-t.after_for_fit,dpi)?!=i32::from(table.outer_margin_bottom)
  ||integer_hu(t.before,dpi)?!=i32::from(table.outer_margin_top)||table.common.vertical_offset!=0{return None;}
  if t.resolved.is_some()||!col.paragraph_float_placements.is_empty()||!arithmetic_equal(t.flow_after,t.flow_before+t.table_total_height){return None;}
  let object_anchor=None;
  let top=rect.y+reservation+t.flow_before-col.start_height-unpainted;
  if top<rect.y||top+t.body_height>rect.y+rect.height{return None;}
  // The structural object row owns no text ink, but its paragraph/font style
  // context must remain within the same explicit plain frame contract.
  let mut style_probe=p.clone();style_probe.controls.clear();style_probe.char_count=1;
  fresh_column_body_rows(&style_probe,styles,rect.width,dpi)?;
  let mut host=p.clone();clear_fresh_input(&mut host);
  if object_anchor.is_some(){host.line_segs=vec![crate::model::object_anchor::structural_table_anchor_row()];}else{super::super::composer::reflow_line_segs(&mut host,super::super::composer::ParagraphBox::body_for_style(rect.width,styles.para_styles.get(usize::from(p.para_shape_id)),dpi),styles,dpi);}
  if host.line_segs.len()!=1{return None;}
  let selected=trace.format(t.selected_format_id?)?;let fresh_host=super::super::composer::compose_paragraph_in_context(&host,styles);
  if selected.source_text!=p.text||selected.source_char_offsets!=p.char_offsets||selected.paragraph_style!=fresh_host.para_style_id
   ||selected.has_numbering||selected.has_horizontal_shaping||selected.known_square_band
   ||!selected.tac_controls.is_empty()||!selected.footnote_positions.is_empty()||!selected.tab_extended.is_empty()
   ||selected.lines.len()!=1||fresh_host.lines.len()!=1||t.selected_line_count!=1
   ||!fact_line_matches(&selected.lines[0],&fresh_host.lines[0],true)
   ||selected.inline_controls.len()!=fresh_host.inline_controls.len()
   ||!selected.inline_controls.iter().zip(&fresh_host.inline_controls).all(|((line,index,kind),c)|*line==c.line_index&&*index==c.control_index&&*kind==format!("{:?}",c.control_type)){return None;}
  let generated=&host.line_segs[0];if (object_anchor.is_none()&&generated.tag!=0x80060000)||(object_anchor.is_some()&&!crate::model::object_anchor::is_canonical_structural_table_anchor(generated))||generated.vertical_pos!=0||generated.text_start!=0
   ||generated.line_height<=0||generated.text_height!=generated.line_height||generated.line_spacing<0
   ||generated.baseline_distance<0||generated.baseline_distance>generated.line_height||generated.column_start!=0
   ||generated.segment_width<=0||f64::from(generated.segment_width)>rect.width*7200.0/dpi{return None;}
  host.line_segs[0].vertical_pos=integer_hu(top-rect.y-t.before,dpi)?;
  if host.line_segs[0].vertical_pos<0{return None;}
  rows.push(CurrentFrameParagraphRows{kind:if object_anchor.is_some(){CurrentFrameRowKind::StructuralObjectAnchor}else{CurrentFrameRowKind::FreshBody},section:0,paragraph:*pi,rows:host.line_segs});tables.push(CandidateTable{paragraph:*pi,control:0,top,before:t.before,body:t.body_height,after:t.after_for_fit,object_anchor});
  if object_anchor.is_some(){unpainted=0.0;}else{unpainted+=t.before;}flow=t.flow_after;
 },_=>return None}}
 if measured.iter().filter(|m|col.items.iter().any(|i|matches!(i,PageItem::Table{para_index,control_index}if *para_index==m.para_index&&*control_index==m.control_index))).count()!=tables.len()||col.paragraph_float_placements.len()!=tables.iter().filter(|t|t.object_anchor.is_some()).count()||!arithmetic_equal(flow,col.used_height){return None;}
 let mut h=blake3::Hasher::new();h.update(b"current-whole-frame-proof-1\0");h.update(&trace.resource());h.update(&trace.generation().to_le_bytes());h.update(&(column_index as u64).to_le_bytes());h.update(&reservation.to_bits().to_le_bytes());
 for t in &tables{h.update(&(t.paragraph as u64).to_le_bytes());for v in[t.top,t.before,t.body,t.after]{h.update(&v.to_bits().to_le_bytes());}match t.object_anchor{Some((a,b,c))=>{h.update(&[1]);h.update(&a.to_bits().to_le_bytes());h.update(&b.to_bits().to_le_bytes());h.update(&c.to_bits().to_le_bytes());},None=>{h.update(&[0]);}}}
 let generation=*h.finalize().as_bytes();let paint=CurrentFramePaintPlan{source_paragraphs:ps.as_ptr()as usize,generation,section:0,page:0,column:u16::try_from(column_index).ok()?,rect,tables:Vec::new(),additional_frames:Vec::new()};
 Some(CurrentFrameCandidate{source,paint,bodies,tables,rows,generation})
 }

}
fn fresh_column_body_rows(p:&crate::model::paragraph::Paragraph,styles:&super::super::style_resolver::ResolvedStyleSet,
 width:f64,dpi:f64)->Option<FreshBodyRows>{
 use crate::model::control::Control;
 use super::super::composer::{compose_paragraph_in_context,reflow_line_segs,ParagraphBox};
 if p.text.len()>64*1024 || p.char_shapes.is_empty() || p.char_shapes.len()>128
  || p.char_shapes.windows(2).any(|s|s[0].start_pos>=s[1].start_pos)
  || p.char_shapes.iter().any(|s|s.char_shape_id as usize>=styles.char_styles.len()) || p.char_offsets.len()>64*1024
  || p.text.contains(['\t','\n','\r','\u{fffc}']) || !width.is_finite() || width<=0.0
  || dpi!=super::super::DEFAULT_DPI || !p.field_ranges.is_empty() || !p.range_tags.is_empty()
  || !p.orphan_field_ends.is_empty() || !p.tab_extended.is_empty() || p.numbering_restart.is_some()
  || p.layout_only_fill_lines!=0 || p.cell_format_vpos_dirty
  || !p.markpen_marks.is_empty() || !p.title_marks.is_empty()
  || p.controls.iter().any(|c|!matches!(c,Control::SectionDef(_)|Control::ColumnDef(_)))
  || p.ctrl_data_records.iter().any(Option::is_some) {return None;}
 let start=match p.controls.as_slice(){[]=>0u32,[Control::SectionDef(_),Control::ColumnDef(_)]=>16u32,_=>return None};
 let mut offset=start;
 if p.char_offsets.len()!=p.text.chars().count(){return None;}
 for (ch,at) in p.text.chars().zip(&p.char_offsets){if *at!=offset{return None;}offset=offset.checked_add(ch.len_utf16() as u32)?;}
 if p.char_count!=offset.checked_add(1)? {return None;}
 let style=styles.para_styles.get(usize::from(p.para_shape_id))?;
 if style.margin_left!=0.0 || style.margin_right!=0.0 || style.indent!=0.0 || style.spacing_before!=0.0
  || style.spacing_after!=0.0 || style.keep_lines || style.keep_with_next || style.page_break_before
  || !matches!(style.head_type,crate::model::style::HeadType::None)
  || style.border_connect || style.border_spacing.iter().any(|v|*v!=0.0) {return None;}
 if style.border_fill_id!=0 {let border=styles.border_styles.get(usize::from(style.border_fill_id.checked_sub(1)?))?;
  if border.borders.iter().any(|b|!matches!(b.line_type,crate::model::style::BorderLineType::None))
   || border.fill_color.is_some() || border.pattern.is_some() || border.gradient.is_some() || border.image_fill.is_some()
   || border.diagonal_attr!=0 || !matches!(border.center_line,crate::model::style::CenterLine::None){return None;}}
 if styles.supplemental_metrics.is_some() || styles.kerning_measurement_context.is_some()
  || styles.horizontal_shaping_context.is_some(){return None;}
 // Prove the existing generic breaker's i32 metric arithmetic cannot overflow
 // before invoking it; this is not a layout tolerance or a font substitution.
 if !style.line_spacing.is_finite()||style.line_spacing<0.0{return None;}
 for shape in &p.char_shapes {let cs=styles.char_styles.get(shape.char_shape_id as usize)?;
  let hu=cs.font_size*7200.0/dpi;
  let upper=hu*(2.0+style.line_spacing.abs())+style.line_spacing.abs()*7200.0/dpi;
  if !hu.is_finite()||hu<=0.0||!upper.is_finite()||upper>f64::from(i32::MAX)/8.0{return None;}}
 let mut fresh=p.clone();fresh.line_segs.clear();fresh.layout_space_metrics.clear();
 fresh.source_line_seg_vertical_pos=None;fresh.hwpx_axis_shift=0;
 fresh.native_source_synthetic_seal=None;fresh.native_source_synthetic_context=None;
 fresh.completed_native_rows=None;fresh.native_frame_observation.set(None);
 let frame=ParagraphBox::body_for_style(width,Some(style),dpi);
 reflow_line_segs(&mut fresh,frame,styles,dpi);
 if fresh.line_segs.is_empty() || fresh.line_segs.len()>4096{return None;}
 let mut end=0i32;
 for row in &fresh.line_segs {if row.vertical_pos!=end || row.line_height<=0 || row.text_height!=row.line_height
  || row.line_spacing<0 || row.baseline_distance<0 || row.baseline_distance>row.line_height
  || row.column_start!=0 || row.tag!=(LineSeg::TAG_SINGLE_SEGMENT_LINE|LineSeg::TAG_IMPLEMENTATION_PROPERTY) {return None;}
  end=end.checked_add(row.line_height)?.checked_add(row.line_spacing)?;}
 let composition=compose_paragraph_in_context(&fresh,styles);
 if composition.numbering_text.is_some() || !composition.tac_controls.is_empty() || !composition.footnote_positions.is_empty()
  || !composition.tab_extended.is_empty() || composition.horizontal_shaping.is_some(){return None;}
 Some(FreshBodyRows{rows:fresh.line_segs,composition})
}
