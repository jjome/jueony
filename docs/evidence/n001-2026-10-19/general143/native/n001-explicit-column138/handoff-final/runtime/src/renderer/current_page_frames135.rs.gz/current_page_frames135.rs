//! Additive explicit-page whole-frame proof. No existing single-frame guard is changed.
use super::*;
pub(crate) struct CurrentPageFramesCandidate<'doc>{frames:Vec<CurrentFrameCandidate<'doc>>}
impl<'doc> CurrentPageFramesCandidate<'doc>{
 pub(crate) fn from_current(source:&'doc Document,format:crate::parser::FileFormat,result:&super::super::pagination::PaginationResult,
 styles:&super::super::style_resolver::ResolvedStyleSet,measured:&[super::super::height_measurer::MeasuredTable],
 profile:crate::model::provenance::LayoutCompatibilityProfile,dpi:f64)->Option<Self>{
  if source.sections.len()!=1{return None;}
  let definition_context=source.reset_flow_contexts().first().copied().flatten()?;
  Self::from_section(source,format,result,styles,measured,profile,dpi,0,0,definition_context)
 }
 fn from_section(source:&'doc Document,format:crate::parser::FileFormat,result:&super::super::pagination::PaginationResult,
 styles:&super::super::style_resolver::ResolvedStyleSet,measured:&[super::super::height_measurer::MeasuredTable],
 profile:crate::model::provenance::LayoutCompatibilityProfile,dpi:f64,section:usize,number_carry:u32,definition_context:[u8;32])->Option<Self>{
  if source.sections.is_empty()||source.sections.len()>16||result.pages.is_empty()||result.pages.len()>16
   ||(source.sections.len()==1&&result.pages.len()==1){return None;}
  let mut frames=vec![];let mut start=0usize;
  for page in 0..result.pages.len(){let frame=match Self::frame(source,format,result,styles,measured,profile,dpi,page,start,section,number_carry,definition_context){Some(f)=>f,None=>return None};
   let items=result.pages[page].column_contents.first()?.items.len();start=start.checked_add(items)?;frames.push(frame);}
  if start!=source.sections.get(section)?.paragraphs.len(){return None;}
  Some(Self{frames})
 }
 pub(crate) fn paint_plan(&self,page:usize)->Option<CurrentFramePaintPlan>{Some(self.frames.get(page)?.paint_plan())}
 pub(crate) fn finalize(self,physical:&[super::super::current_physical_selections::CurrentPhysicalSelections])->Option<CurrentFrameRowsPlan<'doc>>{
  if self.frames.len()!=physical.len(){return None;}
  let source=self.frames.first()?.source;let mut rows=vec![];let mut h=blake3::Hasher::new();h.update(b"current-explicit-page-frames135-1\0");
  for (candidate,physical)in self.frames.into_iter().zip(physical){
   Self::check_physical(&candidate,physical)?;h.update(&candidate.generation);rows.extend(candidate.rows);}
  Some(CurrentFrameRowsPlan{source,resource:crate::model::native_computed_resource::RESOURCE,allocation_generation:*h.finalize().as_bytes(),paragraphs:rows})
 }
 fn frame(source:&'doc Document,format:crate::parser::FileFormat,result:&super::super::pagination::PaginationResult,
 styles:&super::super::style_resolver::ResolvedStyleSet,measured:&[super::super::height_measurer::MeasuredTable],
 profile:crate::model::provenance::LayoutCompatibilityProfile,dpi:f64,page_index:usize,start:usize,section_index:usize,number_carry:u32,definition_context:[u8;32])->Option<CurrentFrameCandidate<'doc>>{
 use super::super::pagination::PageItem;use crate::model::{control::Control,paragraph::ColumnBreakType};
 if source.sections.is_empty()||source.sections.len()>16||source.provenance.hwp3_lineage||!source.bin_data_content.is_empty()||result.pages.is_empty()||result.pages.len()>16
 ||!result.hidden_empty_paras.is_empty()||!result.pre_emitted_host_paras.is_empty()||!result.wrap_around_paras.is_empty()
 ||!result.endnotes.is_empty()||!result.endnote_paragraphs.is_empty()||dpi!=super::super::DEFAULT_DPI{return None;}
 match format{crate::parser::FileFormat::Hwp if profile.native_hwp5_layout()=>{},crate::parser::FileFormat::Hwpx if profile.hwp5_origin_hwpx()=>{},_=>return None}
 let section=&source.sections.get(section_index)?.section_def;
 if section.line_grid!=0||section.char_grid!=0||section.text_direction!=0||!section.master_pages.is_empty()||!section.extra_child_records.is_empty(){return None;}
 let ps=&source.sections.get(section_index)?.paragraphs;if ps.is_empty()||ps.len()>128||ps.iter().any(|p|p.completed_native_rows.is_some()){return None;}
 let [Control::SectionDef(_),Control::ColumnDef(columns)]=ps.first()?.controls.as_slice()else{return None;};
 if columns.column_count!=1||!columns.same_width||!columns.widths.is_empty()||!columns.gaps.is_empty()
 ||columns.column_type!=crate::model::page::ColumnType::Normal||columns.direction!=crate::model::page::ColumnDirection::LeftToRight{return None;}
 match format{crate::parser::FileFormat::Hwp=>if columns.raw_attr!=0x1004{return None;},crate::parser::FileFormat::Hwpx=>if columns.raw_attr!=0{return None;},_=>return None}
 if styles.reset_flow_contexts.get(section_index).copied().flatten()!=Some(definition_context){return None;}
 let trace=result.selected_composition_trace.as_ref()?;
 if trace.section()!=section_index||trace.resource()!=crate::model::native_computed_resource::RESOURCE
 ||!trace.matches_source(ps,Some(definition_context),profile,dpi)
 ||!(trace.matches_finalized_result(result)||(number_carry>0&&trace.matches_finalized_after_page_number_carry(result,number_carry))){return None;}
 let page=result.pages.get(page_index)?;if page.page_index!=u32::try_from(page_index).ok()?||page.section_index!=section_index||page.column_contents.len()!=1||page.layout.column_areas.len()!=1
 ||!page.footnotes.is_empty()||page.active_header.is_some()||page.active_footer.is_some()||page.active_master_page.is_some()||!page.extra_master_pages.is_empty(){return None;}
 let col=&page.column_contents[0];let rect=page.layout.column_areas[0];
 if rect.width!=page.layout.body_area.width||col.column_index!=0||col.start_height!=0.0||col.endnote_flow||col.zone_layout.is_some()||col.zone_y_offset!=0.0
 ||!col.wrap_anchors.is_empty()||!col.wrap_around_paras.is_empty()||!col.inline_placements.is_empty()||!col.inline_flow_plans.is_empty()
 ||!col.overlay_continuations.is_empty()||!col.overlay_cuts.is_empty()||col.items.is_empty()
 ||trace.commits().len()+trace.whole_tables().len()!=result.pages.iter().map(|p|p.column_contents.iter().map(|c|c.items.len()).sum::<usize>()).sum::<usize>()||!trace.tables().is_empty(){return None;}
 let mut flow=0.0;let mut unpainted=0.0;let mut bodies=vec![];let mut tables=vec![];let mut rows=vec![];
 for (slot,item) in col.items.iter().enumerate(){match item{
 PageItem::FullParagraph{para_index:pi}=>{
  if *pi!=start.checked_add(slot)?{return None;}let p=ps.get(*pi)?;let fresh=fresh_body_rows(p,styles,rect.width,dpi)?;
  if *pi==0 {if p.column_type!=ColumnBreakType::Section{return None;}}else if (if slot==0&&page_index>0{p.column_type!=ColumnBreakType::Page}else{p.column_type!=ColumnBreakType::None})||!p.controls.is_empty(){return None;}
  let mut cs=trace.commits().iter().filter(|c|c.paragraph==*pi);let c=cs.next()?;if cs.next().is_some(){return None;}
  let f=trace.format(c.format_id)?;let empty=p.text.is_empty()&&p.controls.is_empty()&&fresh.composition.lines.len()==1;
  if c.page!=Some(u32::try_from(page_index).ok()?)||c.column!=0||c.committed_item_index!=Some(slot)||c.final_membership!=Some(true)||c.row_start!=0||c.row_end!=fresh.rows.len()
  ||c.reused_multicolumn_format||c.same_format_reused_after_slot_change||c.trimmed_before!=0.0||c.actual_column_width_px!=rect.width
  ||!arithmetic_equal(c.flow_before,flow)||!c.metrics_still_match_selected_format||!c.range_inside_selected_composition
  ||f.source_text!=p.text||f.source_char_offsets!=p.char_offsets||f.paragraph_style!=fresh.composition.para_style_id
  ||(!empty&&f.actual_input_width_px!=Some(rect.width))||f.known_square_band||f.has_numbering||f.has_horizontal_shaping
  ||!f.tac_controls.is_empty()||!f.footnote_positions.is_empty()||!f.tab_extended.is_empty()
  ||f.inline_controls.len()!=fresh.composition.inline_controls.len()
  ||!f.inline_controls.iter().zip(&fresh.composition.inline_controls).all(|((line,index,kind),c)|*line==c.line_index&&*index==c.control_index&&*kind==format!("{:?}",c.control_type))
  ||f.before!=0.0||f.after!=0.0||f.lines.len()!=fresh.composition.lines.len()
  ||!f.lines.iter().zip(&fresh.composition.lines).all(|(a,b)|fact_line_matches(a,b,empty)){return None;}
  let total:f64=fresh.rows.iter().map(|r|super::super::hwpunit_to_px(r.line_height+r.line_spacing,dpi)).sum();
  if !arithmetic_equal(c.advance,total)||!arithmetic_equal(c.flow_after,c.flow_before+total)||c.flow_after>rect.height{return None;}
  let y=rect.y+c.flow_before-unpainted;let mut projected=fresh.rows.clone();let mut offset=0.0;
  for row in &mut projected{row.vertical_pos=integer_hu(y-rect.y+offset,dpi)?;offset+=super::super::hwpunit_to_px(row.line_height+row.line_spacing,dpi);}
  rows.push(CurrentFrameParagraphRows{kind:CurrentFrameRowKind::FreshBody,section:section_index,paragraph:*pi,rows:projected});bodies.push(CandidateBody{paragraph:*pi,physical_y:y,fresh,allow_empty_unused_width:empty});flow=c.flow_after;
 },PageItem::Table{para_index:pi,control_index:ci}=>{
  if *pi!=start.checked_add(slot)?||*ci!=0{return None;}let p=ps.get(*pi)?;let [Control::Table(table)]=p.controls.as_slice()else{return None;};
  if !p.text.is_empty()||p.char_count!=9||!p.char_offsets.is_empty()||(if slot==0&&page_index>0 {p.column_type!=ColumnBreakType::Page}else{p.column_type!=ColumnBreakType::None})
  ||p.completed_native_rows.is_some()||p.stored_text_partition_is_dirty()||p.cell_format_vpos_dirty||!p.field_ranges.is_empty()||!p.range_tags.is_empty()
  ||!p.tab_extended.is_empty()||p.layout_only_fill_lines!=0||!crate::renderer::generated_column_stack::plain_table(table,|q|q.controls.is_empty()&&q.field_ranges.is_empty()&&q.range_tags.is_empty()&&q.tab_extended.is_empty())
  ||!table.common.raw_extra.is_empty()||table.raw_table_record_extra.iter().any(|b|*b!=0)
 ||i32::try_from(table.common.width).ok()?.checked_add(i32::from(table.outer_margin_left))?.checked_add(i32::from(table.outer_margin_right))?!=integer_hu(rect.width,dpi)?{return None;}
  match format{crate::parser::FileFormat::Hwp=>if !native_table_common_exact(table){return None;},crate::parser::FileFormat::Hwpx=>if !table.raw_ctrl_data.is_empty(){return None;},_=>return None}
  let mut ms=measured.iter().filter(|m|m.para_index==*pi&&m.control_index==0);let m=ms.next()?;if ms.next().is_some()||m.caption_height!=0.0||m.total_height<=0.0||!m.total_height.is_finite()
  ||integer_hu(m.total_height,dpi)?!=i32::try_from(table.common.height).ok()?{return None;}
  let mut ts=trace.whole_tables().iter().filter(|t|t.paragraph==*pi&&t.control==0);let t=ts.next()?;if ts.next().is_some(){return None;}
  if t.page!=Some(u32::try_from(page_index).ok()?)||t.column!=0||t.post_page!=Some(u32::try_from(page_index).ok()?)||t.post_column!=0||t.committed_item_index!=slot||t.final_membership!=Some(true)
  ||t.pre_text_height!=0.0||t.pre_text_end!=0||!arithmetic_equal(t.flow_before,flow)||t.before<0.0||t.after_for_fit<0.0
  ||t.body_height!=m.total_height||!arithmetic_equal(t.table_total_height,t.before+t.body_height+t.after_for_fit)
  ||t.flow_after>rect.height||t.full_after<0.0
  ||integer_hu(t.full_after-t.after_for_fit,dpi)?!=i32::from(table.outer_margin_bottom)
  ||integer_hu(t.before,dpi)?!=i32::from(table.outer_margin_top)||table.common.vertical_offset!=0{return None;}
  let object_anchor=if let Some(placement)=t.resolved.as_ref(){
   let current=col.paragraph_float_placements.get(&(*pi,0))?;
   if placement.flow!="Exclusion"||placement.next_flow_y.is_some()||placement.stored_host_origin.is_some()
    ||placement.stored_successor_origin.is_some()||placement.table_left.is_some()
    ||current.flow!=crate::renderer::float_placement::ParagraphFloatFlow::Exclusion
    ||current.anchor_y!=placement.anchor_y||current.table_top!=placement.table_top||current.occupied_bottom!=placement.occupied_bottom
    ||current.stored_host_origin.is_some()||current.stored_successor_line_origin.is_some()||current.table_left.is_some()
    ||!arithmetic_equal(placement.anchor_y,t.flow_before)||!arithmetic_equal(placement.table_top,t.flow_before+t.before)
    ||t.full_after<0.0||integer_hu(t.full_after-t.after_for_fit,dpi)?!=i32::from(table.outer_margin_bottom)
    ||!arithmetic_equal(placement.occupied_bottom,placement.table_top+t.body_height+t.full_after)
    ||!arithmetic_equal(t.flow_after,placement.occupied_bottom){return None;}
   Some((placement.anchor_y,placement.occupied_bottom,rect.y+t.flow_before-unpainted))
  }else{if col.paragraph_float_placements.contains_key(&(*pi,0))||!arithmetic_equal(t.flow_after,t.flow_before+t.table_total_height){return None;}None};
  let top=if object_anchor.is_some()||(slot==0&&page_index>0){rect.y+t.flow_before+t.before}else{rect.y+t.flow_before-unpainted};
  if top<rect.y||top+t.body_height>rect.y+rect.height{return None;}
  // The structural object row owns no text ink, but its paragraph/font style
  // context must remain within the same explicit plain frame contract.
  let mut style_probe=p.clone();style_probe.controls.clear();style_probe.char_count=1;
  fresh_body_rows(&style_probe,styles,rect.width,dpi)?;
  let mut host=p.clone();clear_fresh_input(&mut host);
  if object_anchor.is_some(){host.line_segs=vec![crate::model::object_anchor::structural_table_anchor_row()];}else{super::super::composer::reflow_line_segs(&mut host,super::super::composer::ParagraphBox::content_for_style(rect.width,styles.para_styles.get(usize::from(p.para_shape_id)),dpi),styles,dpi);}
  if host.line_segs.len()!=1{return None;}
  let selected=trace.format(t.selected_format_id?)?;let fresh_host=super::super::composer::compose_paragraph_in_context(&host,styles);
  if selected.source_text!=p.text||selected.source_char_offsets!=p.char_offsets||selected.paragraph_style!=fresh_host.para_style_id
   ||selected.has_numbering||selected.has_horizontal_shaping||selected.known_square_band
   ||!selected.tac_controls.is_empty()||!selected.footnote_positions.is_empty()||!selected.tab_extended.is_empty()
   ||selected.lines.len()!=1||fresh_host.lines.len()!=1||t.selected_line_count!=1
   ||!fact_line_matches(&selected.lines[0],&fresh_host.lines[0],true)
   ||selected.inline_controls.len()!=fresh_host.inline_controls.len()
   ||!selected.inline_controls.iter().zip(&fresh_host.inline_controls).all(|((line,index,kind),c)|*line==c.line_index&&*index==c.control_index&&*kind==format!("{:?}",c.control_type)){return None;}
  let generated=&host.line_segs[0];if (object_anchor.is_none()&&generated.tag!=0x80060000)||(object_anchor.is_some()&&!crate::model::object_anchor::is_canonical_structural_table_anchor(generated))||generated.vertical_pos!=0||generated.text_start!=0
   ||generated.line_height<=0||generated.text_height!=generated.line_height||generated.line_spacing<0
   ||generated.baseline_distance<0||generated.baseline_distance>generated.line_height||generated.column_start!=0
   ||generated.segment_width!=if object_anchor.is_some(){0}else{integer_hu(rect.width,dpi)?}{return None;}
  host.line_segs[0].vertical_pos=integer_hu(object_anchor.map_or_else(||if slot==0&&page_index>0 {t.flow_before}else{top-rect.y-t.before},|v|v.0),dpi)?;
  if host.line_segs[0].vertical_pos<0{return None;}
  rows.push(CurrentFrameParagraphRows{kind:if object_anchor.is_some(){CurrentFrameRowKind::StructuralObjectAnchor}else{CurrentFrameRowKind::FreshBody},section:section_index,paragraph:*pi,rows:host.line_segs});tables.push(CandidateTable{paragraph:*pi,control:0,top,before:t.before,body:t.body_height,after:t.after_for_fit,object_anchor});
  if object_anchor.is_some(){unpainted=0.0;}else{unpainted+=t.before;}flow=t.flow_after;
 },_=>return None}}
 if measured.iter().filter(|m|col.items.iter().any(|i|matches!(i,PageItem::Table{para_index,control_index}if *para_index==m.para_index&&*control_index==m.control_index))).count()!=tables.len()||col.paragraph_float_placements.len()!=tables.iter().filter(|t|t.object_anchor.is_some()).count()||!arithmetic_equal(flow,col.used_height){return None;}
 let mut h=blake3::Hasher::new();h.update(b"current-whole-frame-proof-1\0");h.update(&trace.resource());h.update(&trace.generation().to_le_bytes());h.update(&(page_index as u64).to_le_bytes());
 for t in &tables{h.update(&(t.paragraph as u64).to_le_bytes());for v in[t.top,t.before,t.body,t.after]{h.update(&v.to_bits().to_le_bytes());}match t.object_anchor{Some((a,b,c))=>{h.update(&[1]);h.update(&a.to_bits().to_le_bytes());h.update(&b.to_bits().to_le_bytes());h.update(&c.to_bits().to_le_bytes());},None=>{h.update(&[0]);}}}
 let generation=*h.finalize().as_bytes();let paint=CurrentFramePaintPlan{source_paragraphs:ps.as_ptr()as usize,generation,section:section_index,page:u32::try_from(page_index).ok()?,column:0,rect,tables:tables.clone(),additional_frames:Vec::new()};
 Some(CurrentFrameCandidate{source,paint,bodies,tables,rows,generation})
 }
 fn check_physical(candidate:&CurrentFrameCandidate<'doc>,physical:&super::super::current_physical_selections::CurrentPhysicalSelections)->Option<()>{
  if !physical.matches_current_plan(&candidate.paint){return None;}
  let frames=physical.frames()?;let [frame]=frames else{return None;};if frame.section!=candidate.paint.section||frame.page!=candidate.paint.page||frame.column!=0||frame.column_ordinal!=0||frame.has_zone||frame.zone_y!=0.0
  ||frame.rect.x!=candidate.paint.rect.x||frame.rect.y!=candidate.paint.rect.y||frame.rect.width!=candidate.paint.rect.width||frame.rect.height!=candidate.paint.rect.height{return None;}
  let painted=physical.rows()?;let actual_tables=physical.tables()?;if actual_tables.len()!=candidate.tables.len(){return None;}
  let expected_count:usize=candidate.bodies.iter().map(|b|b.fresh.rows.len()).sum();if painted.len()!=expected_count{return None;}
  for body in &candidate.bodies{let selected=painted.iter().filter(|r|r.frame.paragraph==body.paragraph).collect::<Vec<_>>();if selected.len()!=body.fresh.rows.len(){return None;}
   let mut offset=0.0;for (i,(fresh,row))in body.fresh.composition.lines.iter().zip(selected).enumerate(){
    let f=&row.frame;if f.node!=frame.node||f.line!=i||f.equation_adjusted||f.has_wrap_anchor||f.physical_frame_rows||f.stored_horizontal_span_used
    ||f.effective_column_x!=frame.rect.x||f.effective_column_width!=frame.rect.width||f.available_width!=frame.rect.width
    ||f.margin_left!=0.0||f.margin_right!=0.0||f.inline_offset!=0.0||f.numbering_offset!=0.0
    ||!arithmetic_equal(f.physical_text_y,body.physical_y+offset)||f.final_line_box_height!=super::super::hwpunit_to_px(fresh.line_height,super::super::DEFAULT_DPI)
    ||(!same_selected_line(fresh,&row.selected)&&!(body.allow_empty_unused_width&&same_empty_line_ignoring_unused_width(fresh,&row.selected))){return None;}
    offset+=super::super::hwpunit_to_px(fresh.line_height+fresh.line_spacing,super::super::DEFAULT_DPI);
   }}
  for table in &candidate.tables{let mut actual=actual_tables.iter().filter(|t|t.paragraph==table.paragraph&&t.control==table.control);let t=actual.next()?;
   if actual.next().is_some()||t.node!=frame.node||t.typed_float!=table.object_anchor.is_some()||t.inline||t.treat_as_char
   ||t.visual_height!=table.body||!arithmetic_equal(t.visual_end,table.top+table.body){return None;}
   let inset=if candidate.paint.page>0&&frame.items.first().is_some_and(|i|matches!(i,super::super::pagination::PageItem::Table{para_index,..}if *para_index==table.paragraph)){table.before}else{0.0};
   let border=t.emitted_border?;
   if !arithmetic_equal(t.selected_outer_inset,inset)||!arithmetic_equal(t.selected_y+inset,table.top)
    ||!arithmetic_equal(border[1],table.top)||!arithmetic_equal(border[3],table.body)
    ||!arithmetic_equal(t.flow_end,table.top+table.body-inset){return None;}
   if table.object_anchor.is_none()&&(!arithmetic_equal(t.incoming_y,table.top-inset)||!arithmetic_equal(t.paragraph_y,table.top-inset)){return None;}
   if let Some((anchor,_,incoming))=table.object_anchor{
    if !arithmetic_equal(t.incoming_y,incoming)||!arithmetic_equal(t.paragraph_y,frame.rect.y+anchor){return None;}}}
  Some(())
 }
}

/// Whole-document assembly over independently proven final section/page frames.
/// No trace is renewed; the only permitted finalization adjustment is the exact
/// existing cross-section page-number carry, with its full inverse-hash proof.
pub(crate) struct CurrentDocumentFramesCandidate<'doc>{sections:Vec<CurrentPageFramesCandidate<'doc>>}
impl<'doc> CurrentDocumentFramesCandidate<'doc>{
 pub(crate) fn from_core(core:&crate::DocumentCore,source:&'doc Document)->Option<Self>{
  if !std::ptr::eq(source,core.document()){return None;}if source.sections.len()!=core.pagination.len()||source.sections.len()!=core.measured_tables.len(){return None;}
  let mut body_count=0usize;let mut cell_count=0usize;let mut paragraph_count=0usize;let mut text_bytes=0usize;let mut page_count=0usize;
  for result in &core.pagination{page_count=page_count.checked_add(result.pages.len())?;if page_count>16{return None;}}
  for section in &source.sections{for p in &section.paragraphs{body_count=body_count.checked_add(1)?;text_bytes=text_bytes.checked_add(p.text.len())?;
   if body_count>128||text_bytes>2*1024*1024{return None;}
   for control in &p.controls{if let crate::model::control::Control::Table(table)=control{
    cell_count=cell_count.checked_add(table.cells.len())?;if cell_count>4096{return None;}
    for cell in &table.cells{paragraph_count=paragraph_count.checked_add(cell.paragraphs.len())?;if paragraph_count>4096{return None;}
     for p in &cell.paragraphs{text_bytes=text_bytes.checked_add(p.text.len())?;if text_bytes>2*1024*1024{return None;}}
    }
   }}
  }}
  let contexts=source.reset_flow_contexts();let mut sections=vec![];let mut carry=0u32;
  for (index,section)in source.sections.iter().enumerate(){
   // The actual DocCore carry policy must be unambiguous. Page-number fields,
   // restart commands and all other controls are outside this plain proof.
   if section.paragraphs.iter().any(|p|p.controls.iter().any(|c|matches!(c,crate::model::control::Control::NewNumber(_)))){return None;}
   let styles=core.resolve_render_styles_for_section(index);
   let candidate=CurrentPageFramesCandidate::from_section(source,core.source_format,&core.pagination[index],&styles,&core.measured_tables[index],
     core.effective_layout_profile(),core.dpi,index,carry,*contexts.get(index)?.as_ref()?)?;
   carry=core.pagination[index].pages.last()?.page_number;sections.push(candidate);
  }
  if sections.iter().flat_map(|s|&s.frames).flat_map(|f|&f.rows).map(|p|p.rows.len()).sum::<usize>()>4096{return None;}
  Some(Self{sections})
 }
 pub(crate) fn paint_plan(&self,section:usize,page:usize)->Option<CurrentFramePaintPlan>{self.sections.get(section)?.paint_plan(page)}
 pub(crate) fn finalize(self,physical:&[super::super::current_physical_selections::CurrentPhysicalSelections])->Option<CurrentFrameRowsPlan<'doc>>{
  let source=self.sections.first()?.frames.first()?.source;let count=self.sections.iter().map(|s|s.frames.len()).sum::<usize>();if count!=physical.len(){return None;}
  let mut offset=0;let mut rows=vec![];let mut h=blake3::Hasher::new();h.update(b"current-explicit-document-frames135-1\0");
  for section in self.sections{let n=section.frames.len();let plan=section.finalize(&physical[offset..offset+n])?;h.update(&plan.allocation_generation);rows.extend(plan.paragraphs);offset+=n;}
  Some(CurrentFrameRowsPlan{source,resource:crate::model::native_computed_resource::RESOURCE,allocation_generation:*h.finalize().as_bytes(),paragraphs:rows})
 }
}
