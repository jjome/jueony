use super::*;
fn actual_boundary_core(case:&str)->crate::DocumentCore{
 let mut bytes=vec![];flate2::read::GzDecoder::new(OWN_FIXTURE_GZIP).read_to_end(&mut bytes).unwrap();
 let mut core=crate::DocumentCore::from_bytes(&bytes).unwrap();if case=="sections"{core.insert_section_break_native(0,3,0).unwrap();}else{core.insert_page_break_native(0,2,0).unwrap();if case=="three-pages"{core.insert_page_break_native(0,4,0).unwrap();}}
 let n=core.document().sections[0].paragraphs[0].text.chars().count();core.insert_text_native(0,0,n,&"현재 문맥으로 복합 배치를 다시 조판하는 자체 시험 문장입니다. ".repeat(8)).unwrap();core
}
fn assert_actual_storage(case:&str)->Value{
 let out=std::env::var("N001_ROOT").map(std::path::PathBuf::from).map(|p|p.join(format!("build/n001-frames135/{case}-public")))
  .unwrap_or_else(|_|std::env::temp_dir().join(format!("jueony-page135-{}",std::process::id())));std::fs::create_dir_all(&out).unwrap();
 let mut core=actual_boundary_core(case);let before=snapshot(&core);let story=core.text_file_unicode_json();let mut results=vec![];
 std::fs::write(out.join("original-current-layout.json"),serde_json::to_vec_pretty(&before).unwrap()).unwrap();
 for api in 0..4{let source=format!("{:?}",core.document());let events=core.serialize_event_log();let bytes=match api{
  0=>core.export_hwpx_native().unwrap(),1=>{let a=core.export_hwpx_native_with_report().unwrap();assert!(a.content_loss().is_empty());a.into_bytes()},
  2=>core.export_hwpx_native_with_password(b"Frame135!Own").unwrap(),_=>{let a=core.export_hwpx_native_with_password_and_report(b"Frame135!Own").unwrap();assert!(a.content_loss().is_empty());a.into_bytes()}};
  if api==0{let coordinates=assert_xml_all_frame_coordinates(&core,&bytes);std::fs::write(out.join("independent-xml-coordinates.json"),serde_json::to_vec_pretty(&coordinates).unwrap()).unwrap();}
  let path=out.join(format!("api{api}.hwpx"));std::fs::write(&path,&bytes).unwrap();let disk=std::fs::read(path).unwrap();assert_eq!(disk,bytes);
  let next=if api<2{crate::DocumentCore::from_bytes(&disk)}else{crate::DocumentCore::from_bytes_with_password(&disk,b"Frame135!Own")}.unwrap();
  let mut diffs=vec![];differences(&before,&snapshot(&next),"$",&mut diffs);assert_eq!(story,next.text_file_unicode_json());
  assert_eq!(source,format!("{:?}",core.document()));assert_eq!(events,core.serialize_event_log());results.push(json!({"api":api,"geometry":diffs.len(),"differences":diffs,"sourceUnchanged":true,"diskExact":true}));
 }
 let original=core.save_snapshot_native();let section=core.document().sections.len()-1;let tail=core.document().sections[section].paragraphs.len()-1;core.insert_text_native(section,tail,0,"계속 남는 후속 본문 ").unwrap();
 let retained=snapshot(&core);let retained_story=core.text_file_unicode_json();let edited=core.save_snapshot_native();
 for(name,id,expected)in[("undo",original,&before),("redo",edited,&retained)]{core.restore_snapshot_native(id).unwrap();let mut diffs=vec![];differences(expected,&snapshot(&core),"$",&mut diffs);results.push(json!({"history":name,"geometry":diffs.len(),"differences":diffs}));}
 assert_eq!(retained_story,core.text_file_unicode_json());
 for cycle in 0..3{let source=format!("{:?}",core.document());let before=snapshot(&core);let a=core.export_hwpx_native_with_report().unwrap();assert!(a.content_loss().is_empty());
  let path=out.join(format!("cycle{cycle}.hwpx"));std::fs::write(&path,a.bytes()).unwrap();let disk=std::fs::read(path).unwrap();assert_eq!(disk,a.bytes());let next=crate::DocumentCore::from_bytes(&disk).unwrap();
  let mut diffs=vec![];differences(&before,&snapshot(&next),"$",&mut diffs);assert_eq!(retained_story,next.text_file_unicode_json());assert_eq!(source,format!("{:?}",core.document()));results.push(json!({"cycle":cycle,"format":"hwpx","geometry":diffs.len(),"differences":diffs}));
  let before=snapshot(&next);let a=next.export_hwp_with_adapter_snapshot_with_report().unwrap();assert!(a.content_loss().is_empty());let path=out.join(format!("cycle{cycle}.hwp"));std::fs::write(&path,a.bytes()).unwrap();let disk=std::fs::read(path).unwrap();assert_eq!(disk,a.bytes());let after=crate::DocumentCore::from_bytes(&disk).unwrap();let mut diffs=vec![];differences(&before,&snapshot(&after),"$",&mut diffs);assert_eq!(retained_story,after.text_file_unicode_json());results.push(json!({"cycle":cycle,"format":"hwp-followup","geometry":diffs.len(),"differences":diffs}));core=after;
 }
 let failures=results.iter().filter(|r|r["geometry"]!=0).cloned().collect::<Vec<_>>();assert_eq!(results.len(),12);std::fs::write(out.join("result.json"),serde_json::to_vec_pretty(&json!({"results":results,"failures":failures})).unwrap()).unwrap();assert!(failures.is_empty(),"failures preserved in actual result");json!({"case":case,"results":results,"failures":failures})
}
#[test]fn actual_section_number_carry_proves_only_checked_known_number_delta(){
 let mut bytes=vec![];flate2::read::GzDecoder::new(OWN_FIXTURE_GZIP).read_to_end(&mut bytes).unwrap();let mut core=crate::DocumentCore::from_bytes(&bytes).unwrap();core.insert_section_break_native(0,3,0).unwrap();
 assert!(core.document().sections.len()>1);let result=&core.pagination[1];let trace=result.selected_composition_trace.as_ref().unwrap();
 let carry=core.pagination[0].pages.last().unwrap().page_number;
 assert!(!trace.matches_finalized_result(result));assert!(trace.matches_finalized_after_page_number_carry(result,carry));
 assert!(!trace.matches_finalized_after_page_number_carry(result,carry+1));
 let old=core.pagination[1].pages[0].layout.body_area.y;core.pagination[1].pages[0].layout.body_area.y+=1.0;
 assert!(!core.pagination[1].selected_composition_trace.as_ref().unwrap().matches_finalized_after_page_number_carry(&core.pagination[1],carry));core.pagination[1].pages[0].layout.body_area.y=old;
 let old=core.pagination[1].pages[0].page_number_restarted;core.pagination[1].pages[0].page_number_restarted=true;
 assert!(!core.pagination[1].selected_composition_trace.as_ref().unwrap().matches_finalized_after_page_number_carry(&core.pagination[1],carry));core.pagination[1].pages[0].page_number_restarted=old;
}

#[test]fn actual_boundary_frames_storage_four_apis_disk_history_and_repeated_mixed(){
 let mut reports=vec![];for case in ["page","sections","three-pages"]{reports.push(assert_actual_storage(case));}
 assert_eq!(reports.iter().map(|r|r["results"].as_array().unwrap().len()).sum::<usize>(),36);
 assert!(reports.iter().all(|r|r["failures"].as_array().unwrap().is_empty()));
 let out=std::env::var("N001_ROOT").map(std::path::PathBuf::from).map(|p|p.join("build/n001-frames135"))
  .unwrap_or_else(|_|std::env::temp_dir().join(format!("jueony-page135-{}",std::process::id())));std::fs::create_dir_all(&out).unwrap();
 std::fs::write(out.join("actual-storage-results.json"),serde_json::to_vec_pretty(&json!({"reports":reports,"observations":36,"failures":[]})).unwrap()).unwrap();
}
#[test]fn actual_boundary_plan_rejects_stale_source_frames_measurement_and_receipts(){
 let mut core=actual_boundary_core("page");assert!(CurrentDocumentFramesCandidate::from_core(&core,core.document()).is_some());
 let clone=core.document().clone();assert!(CurrentDocumentFramesCandidate::from_core(&core,&clone).is_none());
 let old=core.document.sections[0].paragraphs[0].text.clone();core.document.sections[0].paragraphs[0].text.push('x');assert!(CurrentDocumentFramesCandidate::from_core(&core,core.document()).is_none());core.document.sections[0].paragraphs[0].text=old;
 let old=core.document.sections[0].paragraphs[1].line_segs[0].vertical_pos;core.document.sections[0].paragraphs[1].line_segs[0].vertical_pos+=1;assert!(CurrentDocumentFramesCandidate::from_core(&core,core.document()).is_none());core.document.sections[0].paragraphs[1].line_segs[0].vertical_pos=old;
 let old=core.document.sections[0].paragraphs[3].column_type;core.document.sections[0].paragraphs[3].column_type=crate::model::paragraph::ColumnBreakType::None;assert!(CurrentDocumentFramesCandidate::from_core(&core,core.document()).is_none());core.document.sections[0].paragraphs[3].column_type=old;
 let old=core.measured_tables[0][0].total_height;core.measured_tables[0][0].total_height+=1.0;assert!(CurrentDocumentFramesCandidate::from_core(&core,core.document()).is_none());core.measured_tables[0][0].total_height=old;
 core.pagination[0].pages[0].column_contents[0].items.swap(0,1);assert!(CurrentDocumentFramesCandidate::from_core(&core,core.document()).is_none());core.pagination[0].pages[0].column_contents[0].items.swap(0,1);
 let old=core.pagination[0].pages[1].page_index;core.pagination[0].pages[1].page_index=0;assert!(CurrentDocumentFramesCandidate::from_core(&core,core.document()).is_none());core.pagination[0].pages[1].page_index=old;
 let old=core.dpi;core.dpi=0.0;assert!(CurrentDocumentFramesCandidate::from_core(&core,core.document()).is_none());core.dpi=old;
 let capture=|| (0..core.page_count()).map(|p|core.build_page_tree_with_current_selections(p).unwrap().frame.current_physical_selections.clone()).collect::<Vec<_>>();
 let physical=capture();assert!(CurrentDocumentFramesCandidate::from_core(&core,core.document()).unwrap().finalize(&physical).is_some());
 let mut wrong=physical.clone();wrong.swap(0,1);assert!(CurrentDocumentFramesCandidate::from_core(&core,core.document()).unwrap().finalize(&wrong).is_none());
 let mut wrong=physical.clone();let row=wrong[0].rows().unwrap()[0].clone();wrong[0].record_row(row.frame,&row.selected);assert!(CurrentDocumentFramesCandidate::from_core(&core,core.document()).unwrap().finalize(&wrong).is_none());
 for field in 0..8{let candidate=CurrentDocumentFramesCandidate::from_core(&core,core.document()).unwrap();let original=&physical[1];let frame=&original.frames().unwrap()[0];
  let mut poisoned=crate::renderer::current_physical_selections::CurrentPhysicalSelections::default();poisoned.enable_new_page_capture();poisoned.bind_current_plan(&candidate.paint_plan(0,1).unwrap());
  let page=&core.pagination[0].pages[1];poisoned.register_frame(frame.node,page,&page.column_contents[0],&frame.rect);
  for row in original.rows().unwrap(){poisoned.record_row(row.frame.clone(),&row.selected);}
  for table in original.tables().unwrap(){let mut table=table.clone();match field{0=>table.selected_y+=1.0,1=>table.selected_outer_inset+=1.0,2=>table.emitted_border.as_mut().unwrap()[1]+=1.0,3=>table.visual_height+=1.0,4=>table.visual_end+=1.0,5=>table.flow_end+=1.0,6=>table.incoming_y+=1.0,_=>table.paragraph_y+=1.0};poisoned.record_table(table);}
  poisoned.finish_frame(frame.node);let wrong=vec![physical[0].clone(),poisoned];assert!(candidate.finalize(&wrong).is_none(),"exact physical receipt field {field}");
 }
 assert!(CurrentDocumentFramesCandidate::from_core(&core,core.document()).unwrap().finalize(&physical[..1]).is_none());
}

fn assert_xml_all_frame_coordinates(core:&crate::DocumentCore,bytes:&[u8])->Value{
 let mut zip=zip::ZipArchive::new(std::io::Cursor::new(bytes)).unwrap();assert!(zip.by_name(crate::model::native_computed_rows::PATH).is_err());
 let physical=(0..core.page_count()).map(|p|core.build_page_tree_with_current_selections(p).unwrap().frame.current_physical_selections.clone()).collect::<Vec<_>>();let mut checks=vec![];
 for(section,source)in core.document().sections.iter().enumerate(){let mut xml=String::new();zip.by_name(&format!("Contents/section{section}.xml")).unwrap().read_to_string(&mut xml).unwrap();let doc=roxmltree::Document::parse(&xml).unwrap();let ns="http://www.hancom.co.kr/hwpml/2011/paragraph";
  let paragraphs=doc.root_element().children().filter(|n|n.has_tag_name((ns,"p"))).collect::<Vec<_>>();assert_eq!(paragraphs.len(),source.paragraphs.len());
  for(pi,p)in paragraphs.iter().enumerate(){let mut owners=physical.iter().flat_map(|capture|capture.frames().unwrap().iter().map(move|frame|(capture,frame))).filter(|(_,frame)|frame.section==section&&frame.items.iter().any(|item|matches!(item,crate::renderer::pagination::PageItem::FullParagraph{para_index}|crate::renderer::pagination::PageItem::Table{para_index,..}if *para_index==pi)));
   let(capture,frame)=owners.next().unwrap();assert!(owners.next().is_none());let array=p.children().find(|n|n.has_tag_name((ns,"linesegarray"))).unwrap();let rows=array.children().filter(|n|n.has_tag_name((ns,"lineseg"))).collect::<Vec<_>>();
   if let [crate::model::control::Control::Table(table)]=source.paragraphs[pi].controls.as_slice(){assert_eq!(rows.len(),1);let actual=capture.tables().unwrap().iter().find(|t|t.node==frame.node&&t.paragraph==pi&&t.control==0).unwrap();let border=actual.emitted_border.unwrap();let v:i32=rows[0].attribute("vertpos").unwrap().parse().unwrap();
    let y=frame.rect.y+f64::from(v+i32::from(table.outer_margin_top))/75.0;assert!(arithmetic_equal(y,border[1]));checks.push(json!({"section":section,"page":frame.page,"paragraph":pi,"kind":"table-border","xmlVerticalHu":v,"declaredOuterTopHu":table.outer_margin_top,"actualBodyY":frame.rect.y,"physicalBorderY":border[1]}));
   }else{let painted=capture.rows().unwrap().iter().filter(|r|r.frame.node==frame.node&&r.frame.paragraph==pi).collect::<Vec<_>>();assert_eq!(rows.len(),painted.len());for(row,paint)in rows.iter().zip(painted){let v:i32=row.attribute("vertpos").unwrap().parse().unwrap();let y=frame.rect.y+f64::from(v)/75.0;assert!(arithmetic_equal(y,paint.frame.physical_text_y));checks.push(json!({"section":section,"page":frame.page,"paragraph":pi,"kind":"body","xmlVerticalHu":v,"actualBodyY":frame.rect.y,"physicalY":paint.frame.physical_text_y}));}}
  }
 }
 json!({"assertions":checks.len(),"checks":checks,"descriptorPresent":false,"basis":"actual ZIP standard linesegarray integer coordinates + actual frame origin + declared outerTop equal actual emitted border/text; no reopened-reader inference"})
}
