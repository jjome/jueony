//! 레이아웃 엔진 (Layout Engine)
//!
//! 페이지 분할 결과를 받아 각 요소의 정확한 위치와 크기를 계산하고
//! 렌더 트리(PageRenderTree)를 생성한다.

use super::composer::{
    compose_paragraph, effective_text_for_metrics, first_text_line, ComposedParagraph,
};
use super::float_placement::{
    empty_host_physical_ladder_extras_hu, empty_offset_float_deferred_text_ladder_hu,
    horizontal_range, is_para_topbottom_float, native_empty_host_physical_outer_box_paint_inset,
    native_empty_host_rowbreak_line_advance_hu,
    original_hwpx_column_rowbreak_equal_outer_margin_hu,
    para_relative_left_aligned_outer_margin_left_hu, signed_hwpunit,
    square_float_outer_margin_top_hu, stored_empty_anchor_band_host_line_advance_hu,
    stored_visible_anchor_band_host_line_advance_hu, FloatLaneSet, FloatPlacementContext,
};
use super::font_metrics_data;
use super::height_cursor::HeightCursor;
use super::height_measurer::{fit_measured_table_to_declared_height, MeasuredTable};
use super::page_layout::{LayoutRect, PageLayoutInfo};
use super::pagination::{
    ColumnContent, EndnoteParaSource, FootnoteRef, FootnoteSource, PageContent, PageItem,
};
use super::render_tree::*;
use super::style_resolver::ResolvedStyleSet;
use super::{
    format_number, hwpunit_to_px, px_to_hwpunit, ArrowStyle, AutoNumberCounter, LineStyle,
    NumberFormat as NumFmt, PathCommand, ShapeStyle, StrokeDash, TextStyle, DEFAULT_DPI,
};
use crate::model::bin_data::BinDataContent;
use crate::model::control::Control;
use crate::model::footnote::{FootnoteShape, NumberFormat};
use crate::model::header_footer::MasterPage;
use crate::model::page::{PageBorderBasis, PageBorderFill};
use crate::model::paragraph::Paragraph;
use crate::model::shape::{
    Caption, CaptionDirection, CommonObjAttr, HorzAlign, HorzRelTo, ShapeObject, TextWrap,
    VertAlign, VertRelTo,
};
use crate::model::style::{
    Alignment, BorderLine, BorderLineType, HeadType, Numbering, UnderlineType,
};
use crate::model::table::{TablePageBreak, VerticalAlign};

/// A column-top floating row-break box and a later, separately owned inline
/// row have distinct flow extents. The stored inline row cannot absorb the
/// floating box's explicit outer-bottom margin.
fn stored_column_top_coanchored_float_box(
    para: &Paragraph, control_index: usize, paint_top: f64, column_top: f64,
    visual_height: f64, dpi: f64,
) -> bool {
    if !dpi.is_finite() || dpi<=0.0 || !paint_top.is_finite() || !column_top.is_finite()
        || !visual_height.is_finite() || (paint_top-column_top).abs()>dpi/7200.0
        || para.cell_format_vpos_dirty || para.line_segs.len()!=1
    {return false;}
    let Some(line)=crate::renderer::composer::stored_first_tac_line(para) else{return false;};
    if line.line_height<=0 || line.line_spacing<0 || line.vertical_pos<0
        || line.vertical_pos.checked_add(line.line_height)
            .and_then(|end|end.checked_add(line.line_spacing)).is_none()
    {return false;}
    // Page-band definitions have their own frame; their known table descendants
    // do not become body boxes. Field memo text remains in the body context.
    // Unknown controls, notes and body nested objects retain the general path.
    fn known_paragraphs(paragraphs:&[Paragraph], page_band:bool, depth:usize,
        budget:&mut usize)->bool {
        if depth>32{return false;}
        for p in paragraphs {
            let Some(left)=budget.checked_sub(1) else{return false;};*budget=left;
            for control in &p.controls {
                let Some(left)=budget.checked_sub(1) else{return false;};*budget=left;
                let known=match control {
                    Control::AutoNumber(_)=>true,
                    Control::Field(field)=>known_paragraphs(&field.memo_paragraphs,false,depth+1,budget),
                    Control::Header(header)=>known_paragraphs(&header.paragraphs,true,depth+1,budget),
                    Control::Footer(footer)=>known_paragraphs(&footer.paragraphs,true,depth+1,budget),
                    Control::Table(table) if page_band=>table.cells.iter().all(|cell|
                        known_paragraphs(&cell.paragraphs,true,depth+1,budget)),
                    _=>false,
                };
                if !known{return false;}
            }
        }
        true
    }
    let known_cell_controls = |table:&crate::model::table::Table| {
        // This is an optimization eligibility budget, never a parser limit.
        let mut budget=4096;
        table.cells.iter().all(|cell|known_paragraphs(&cell.paragraphs,false,0,&mut budget))
    };
    let Some(Control::Table(table))=para.controls.get(control_index) else{return false;};
    if !is_para_topbottom_float(&table.common) || table.common.allow_overlap
        || table.common.vertical_offset!=0 || table.common.height>i32::MAX as u32
        || table.common.height==0 || table.caption.is_some()
        || !matches!(table.page_break,TablePageBreak::RowBreak)
        || table.row_count!=1 || table.col_count!=1 || table.cells.len()!=1
        || table.outer_margin_top!=0 || table.outer_margin_bottom<=0
        || (visual_height-hwpunit_to_px(table.common.height as i32,dpi)).abs()>dpi/7200.0
        || !known_cell_controls(table)
    {return false;}
    let mut inline_owner=None;
    for (index,control) in para.controls.iter().enumerate() {
        if index==control_index {continue;}
        match control {
            Control::SectionDef(_) | Control::ColumnDef(_) => {},
            Control::Table(sibling) if index>control_index && sibling.common.treat_as_char
                && sibling.caption.is_none() && !sibling.common.allow_overlap
                && sibling.outer_margin_top>=0 && sibling.outer_margin_bottom>=0
                && crate::renderer::layout::control_line_seg_index(para,index)==Some(0)
                && i64::from(line.line_height)==i64::from(sibling.common.height)
                    +i64::from(sibling.outer_margin_top)+i64::from(sibling.outer_margin_bottom)
                && known_cell_controls(sibling) => {
                    if inline_owner.replace(index).is_some(){return false;}
                },
            Control::Table(sibling) if index<control_index && !sibling.common.treat_as_char
                && sibling.common.text_wrap==TextWrap::Square
                && sibling.common.vert_rel_to==VertRelTo::Paper
                && sibling.common.horz_rel_to==HorzRelTo::Paper
                && !sibling.common.allow_overlap => {},
            _=>return false,
        }
    }
    inline_owner.is_some()
}

/// 실제 부분 문단 컷이 원본 어울림 호스트의 물리 재시작을 소유한다.
/// 통째 호스트나 일반 표 앞 텍스트는 어울림 렌더 경로가 계속 소유한다.
fn explicitly_split_stored_square_host(
    para: &Paragraph,
    start_line: usize,
    end_line: usize,
) -> bool {
    matches!(para.controls.as_slice(), [Control::Table(table)]
        if !table.common.treat_as_char && table.common.allow_overlap
            && matches!(table.common.text_wrap, TextWrap::Square))
        && !para.stored_text_partition_is_dirty()
        && para.line_segs.windows(2).enumerate().any(|(index, lines)| {
            (start_line == index + 1 || end_line == index + 1)
                && lines.iter().all(|line| {
                    line.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0
                })
                && lines[1].vertical_pos > 0
                && lines[1].vertical_pos < lines[0].vertical_pos
        })
}

/// 부분 본문과 표가 같은 저장 재시작 원점을 공유하는 확정 계획인지 확인한다.
fn resolved_stored_square_fragment_in_column(
    para: &Paragraph,
    para_index: usize,
    column: &ColumnContent,
    dpi: f64,
) -> bool {
    column.items.iter().any(|item| {
        let PageItem::PartialParagraph {
            para_index: owner,
            start_line,
            end_line,
        } = item
        else {
            return false;
        };
        *owner == para_index
            && *start_line > 0
            && explicitly_split_stored_square_host(para, *start_line, *end_line)
            && para.line_segs.get(*start_line).is_some_and(|line| {
                column
                    .paragraph_float_placements
                    .iter()
                    .any(|(&(owner, _), placement)| {
                        owner == para_index
                            && placement.flow
                                == super::float_placement::ParagraphFloatFlow::Exclusion
                            && (hwpunit_to_px(line.vertical_pos, dpi) - placement.anchor_y).abs()
                                <= dpi / 7200.0
                    })
            })
    })
}

/// layout_column_item의 읽기 전용 컨텍스트 (파라미터 묶음)
struct ColumnItemCtx<'a> {
    page_content: &'a PageContent,
    paragraphs: &'a [Paragraph],
    composed: &'a [ComposedParagraph],
    styles: &'a ResolvedStyleSet,
    bin_data_content: &'a [BinDataContent],
    measured_tables: &'a [MeasuredTable],
    layout: &'a PageLayoutInfo,
    col_area: &'a LayoutRect,
    /// 현재 PageItem이 속한 활성 구역의 실제 단 수.
    ///
    /// `PageContent::column_contents`는 비어 있는 단을 flush하지 않으므로 다단
    /// 구역에서도 길이가 1일 수 있다. 단일 단 전용 보정은 구역 레이아웃의
    /// 권위값을 사용해야 한다.
    zone_column_count: usize,
    outline_numbering_id: u16,
    multi_col_width: Option<i32>,
    prev_tac_seg_applied: bool,
    wrap_around_paras: &'a [super::pagination::WrapAroundPara],
    /// [Task #604 R3] anchor ↔ wrap text 매칭 메타데이터 (typeset 출력 → layout 소비)
    wrap_anchors: &'a std::collections::HashMap<usize, super::pagination::WrapAnchorRef>,
    inline_placements:
        &'a std::collections::HashMap<(usize, usize), super::float_placement::InlineBoxPlacement>,
    inline_flow_plans: &'a std::collections::HashMap<usize, super::inline_flow::InlineFlowPlan>,
    paragraph_float_placements: &'a std::collections::HashMap<
        (usize, usize),
        super::float_placement::ParagraphFloatPlacement,
    >,
}

impl ColumnItemCtx<'_> {
    /// A block TAC table and its visible text tail share one paragraph ending.
    /// Use the emitted items, including other columns, rather than control order.
    fn tac_text_tail_spacing_after(&self, para_index: usize) -> Option<f64> {
        let para = self.paragraphs.get(para_index)?;
        let comp = self.composed.get(para_index)?;
        let spacing = self
            .styles
            .para_styles
            .get(comp.para_style_id as usize)?
            .spacing_after;
        if spacing <= 0.0 {
            return None;
        }
        let items = || {
            self.page_content
                .column_contents
                .iter()
                .flat_map(|column| &column.items)
        };
        items().any(|item| {
            let PageItem::Table { para_index: owner, control_index } = item else {
                return false;
            };
            if *owner != para_index
                || !matches!(para.controls.get(*control_index), Some(Control::Table(t)) if t.common.treat_as_char)
            {
                return false;
            }
            let Some(table_line) = control_line_seg_index(para, *control_index) else {
                return false;
            };
            items().any(|item| {
                let PageItem::PartialParagraph { para_index: owner, start_line, end_line } = item else {
                    return false;
                };
                *owner == para_index && *start_line > table_line
                    && comp.lines.get(*start_line..*end_line).is_some_and(|lines| {
                        lines.iter().any(|line| line.runs.iter().any(|run| {
                            run.text.chars().any(|c| !c.is_whitespace() && c > '\u{001F}' && c != '\u{FFFC}')
                        }))
                    })
            })
        }).then_some(spacing)
    }
}

pub(crate) const ENDNOTE_BETWEEN_NOTES_BASE_FLOW_HU: i32 = 1984;
const SINGLE_ROW_DECLARED_TRUST_MAX_RATIO: f64 = 1.5;

/// A non-flow paper ellipse and a TAC table can share a duplicated outer-band
/// carrier in generated HWPX/HWP. Hancom removes the font-only prefix row when
/// re-saving it. Accept only its exact two-control/two-row ownership proof;
/// neither source LINE_SEG values nor declared table dimensions are rewritten.
fn duplicated_nonflow_prefix_band_origin(
    para: &Paragraph,
    control_index: usize,
    table: &crate::model::table::Table,
) -> Option<i32> {
    use crate::model::paragraph::{ColumnBreakType, LineSeg};
    let [Control::Shape(shape), Control::Table(owned)] = para.controls.as_slice() else {
        return None;
    };
    let ShapeObject::Ellipse(ellipse) = shape.as_ref() else { return None; };
    let decoration = &ellipse.common;
    if control_index != 1 || !std::ptr::eq(owned.as_ref(), table)
        || para.stored_text_partition_dirty
        || !matches!(para.column_type, ColumnBreakType::None)
        || !para.range_tags.is_empty() || !para.markpen_marks.is_empty()
        || decoration.treat_as_char || decoration.flow_with_text
        || decoration.affect_line_spacing
        || !matches!(decoration.text_wrap, TextWrap::InFrontOfText)
        || !matches!(decoration.vert_rel_to, VertRelTo::Paper)
        || !matches!(decoration.horz_rel_to, HorzRelTo::Paper)
        || !table.common.treat_as_char || !table.common.flow_with_text
        || table.common.allow_overlap
        || table.caption.is_some() || !matches!(table.page_break, TablePageBreak::RowBreak)
        || !matches!(table.common.text_wrap, TextWrap::TopAndBottom)
        || !matches!(table.common.vert_rel_to, VertRelTo::Para)
        || !matches!(table.common.vert_align, VertAlign::Top)
        || !matches!(table.common.horz_rel_to, HorzRelTo::Para)
        || table.common.vertical_offset != 0 || table.common.horizontal_offset != 0
        || table.outer_margin_top < 0 || table.outer_margin_bottom < 0
        || para.empty_control_stream_position(0)? != 0
        || para.empty_control_stream_position(1)? != 8
    { return None; }
    let [prefix, carrier] = para.line_segs.as_slice() else { return None; };
    let band = i64::from(table.common.height) + i64::from(table.outer_margin_top)
        + i64::from(table.outer_margin_bottom);
    if band <= 0 || prefix.tag != carrier.tag
        || prefix.tag & LineSeg::TAG_IMPLEMENTATION_PROPERTY != 0
        || para.line_seg_text_start(0) != 0 || para.line_seg_text_start(1) != 8
        || prefix.vertical_pos < 0 || prefix.text_height <= 0
        || prefix.line_spacing < 0 || prefix.line_spacing != carrier.line_spacing
        || prefix.column_start != 0 || carrier.column_start != 0
        || prefix.segment_width <= 0 || prefix.segment_width != carrier.segment_width
        || i64::from(prefix.line_height) != band || i64::from(carrier.line_height) != band
        || i64::from(carrier.text_height) != band
        || i64::from(prefix.text_height) * 2 >= band
        || prefix.baseline_distance < 0 || prefix.baseline_distance > prefix.text_height
        || carrier.baseline_distance < 0 || i64::from(carrier.baseline_distance) > band
        || i64::from(carrier.vertical_pos) - i64::from(prefix.vertical_pos)
            != i64::from(prefix.text_height) + i64::from(prefix.line_spacing)
    { return None; }
    Some(prefix.vertical_pos)
}

/// 빈 host의 full-band TAC 표가 두 번째 저장 줄을 온전히 점유했을 때 표의 실제
/// 상단을 복원한다. 한컴은 그 줄의 `text_height`를 `표 높이 + 위·아래 outMargin`으로
/// 기록하고, 잉크를 `vertical_pos + outMargin.top`에 둔다.
///
/// 이 조건은 table PageItem 경로에서만 쓴다. 일반 인라인 표와 셀 안 표는 각자의
/// baseline/flow 계약을 유지한다.
fn stored_empty_full_band_tac_table_top(
    para: &Paragraph,
    control_index: usize,
    table: &crate::model::table::Table,
    col_area: &LayoutRect,
    dpi: f64,
) -> Option<f64> {
    if !para.text.trim().is_empty()
        || !table.common.treat_as_char
        || !matches!(table.common.text_wrap, TextWrap::TopAndBottom)
        || para.stored_text_partition_dirty
        || !tac_has_only_in_front_decoration_shapes_before(para, control_index)
    {
        return None;
    }

    let band_height_hu = i64::from(table.common.height)
        + i64::from(table.outer_margin_top)
        + i64::from(table.outer_margin_bottom);
    if band_height_hu <= 0 {
        return None;
    }
    let synth = crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY;
    let mut candidates = para.line_segs.windows(2).filter_map(|pair| {
        let previous = &pair[0];
        let current = &pair[1];
        let current_text_height = i64::from(current.text_height);
        (previous.tag & synth == 0
            && current.tag & synth == 0
            && current.vertical_pos > previous.vertical_pos
            // HWP5/HWPX rounding tolerance: 8HU = 0.11px at 96dpi.
            && (current_text_height - band_height_hu).abs() <= 8
            && i64::from(previous.text_height) * 2 < band_height_hu)
            .then_some(current.vertical_pos)
    });
    let candidate_vpos = candidates.next()?;
    let vpos = duplicated_nonflow_prefix_band_origin(para, control_index, table)
        .unwrap_or(candidate_vpos);
    // 한 표는 하나의 full-band 저장 줄만 소유한다.
    if candidates.next().is_some() {
        return None;
    }
    let stored_y = hwpunit_to_px(vpos, dpi);
    (stored_y <= col_area.height + 60.0)
        .then(|| col_area.y + stored_y + hwpunit_to_px(table.outer_margin_top as i32, dpi))
}

/// 빈 host의 full-band TAC 표가 표 paint frame과 다음 문단의 시작을 같은 저장
/// `LINE_SEG`에 기록한 경우, 표 뒤 흐름의 하한을 복원한다.
///
/// `text_height`는 표의 선언 outer-box와 같고 다음 문단의 `vertical_pos`가
/// `vertical_pos + text_height + line_spacing`과 일치해야 한다. 따라서 일반 TAC의
/// 추정 spacing이 아니라 한컴이 저장한 다음 문단 top만 사용한다. 앞 장식 개체 때문에
/// 일반 TAC 후가산 경로가 소유 줄을 찾지 못하는 HWP5 full-band carrier에만 적용한다.
///
/// 앞 개체 판정은 "보이는가"가 아니라 "흐름을 전진시키는가"다. 글앞·글뒤 개체(그림·
/// 도형)는 줄을 점유하지 않으므로 소유 줄의 줄간격이 그대로 다음 문단 top에 남는다
/// (#7431 exam_eng p2 pi104: 글뒤 그림 2개 + TAC 표, 한컴 2020·2022 PDF 모두 저장
/// top을 따른다). 자리차지·어울림 개체는 별도 띠로 흐름을 밀기 때문에(#4622) 제외한다.
fn stored_empty_full_band_tac_table_flow_end(
    para: &Paragraph,
    control_index: usize,
    table: &crate::model::table::Table,
    following: &Paragraph,
    col_area: &LayoutRect,
    dpi: f64,
) -> Option<f64> {
    if !para.text.trim().is_empty()
        || !table.common.treat_as_char
        || !matches!(table.common.text_wrap, TextWrap::TopAndBottom)
        || para.stored_text_partition_dirty
        || !tac_has_only_non_flow_decorations_before(para, control_index)
    {
        return None;
    }

    let synth = crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY;
    let owner = para
        .line_segs
        .get(control_line_seg_index(para, control_index)?)
        .filter(|line| line.tag & synth == 0)?;
    let following = following
        .line_segs
        .iter()
        .find(|line| line.tag & synth == 0)?;
    let outer_box_height_hu = i64::from(table.common.height)
        + i64::from(table.outer_margin_top)
        + i64::from(table.outer_margin_bottom);
    if outer_box_height_hu <= 0 || (i64::from(owner.text_height) - outer_box_height_hu).abs() > 8 {
        return None;
    }

    let expected_next_vpos = i64::from(owner.vertical_pos)
        + i64::from(owner.text_height)
        + i64::from(owner.line_spacing);
    if following.vertical_pos <= owner.vertical_pos
        || (i64::from(following.vertical_pos) - expected_next_vpos).abs() > 8
    {
        return None;
    }

    let stored_y = hwpunit_to_px(following.vertical_pos, dpi);
    (stored_y <= col_area.height + 60.0).then_some(col_area.y + stored_y)
}

/// A single empty host with an unresolved zero-width text-line template must not
/// turn its outer top into a second paint inset. Its final empty paragraph row
/// still advances by one template line, not by the table's outer box. This is
/// deliberately not a general stored-anchor interpretation or a cache rewrite.
fn unresolved_single_table_placeholder_origin_hu(
    native_profile: bool,
    column_count: usize,
    paragraphs: &[Paragraph],
    index: usize,
    table: &crate::model::table::Table,
    measured_height: Option<f64>,
    dpi: f64,
) -> Option<i32> {
    use crate::model::paragraph::ColumnBreakType;
    let para = paragraphs.get(index)?;
    let prev = paragraphs.get(index.checked_sub(1)?)?;
    let next = paragraphs.get(index.checked_add(1)?)?;
    let plain_metadata = |p: &Paragraph| p.field_ranges.is_empty()
        && p.orphan_field_ends.is_empty() && p.range_tags.is_empty()
        && p.title_marks.is_empty() && p.markpen_marks.is_empty()
        && p.ctrl_data_records.iter().all(Option::is_none)
        && p.tab_extended.is_empty() && p.numbering_restart.is_none()
        && p.layout_only_fill_lines == 0 && !p.stored_text_partition_is_dirty()
        && !p.cell_format_vpos_dirty;
    if !native_profile || column_count != 1 || !para.text.is_empty()
        || !plain_metadata(para) || !plain_metadata(prev) || !plain_metadata(next)
        || !matches!(para.column_type, ColumnBreakType::None)
        || !matches!(next.column_type, ColumnBreakType::None)
        || !matches!(para.controls.as_slice(), [Control::Table(_)])
        || !prev.controls.iter().all(|c| matches!(c, Control::SectionDef(_) | Control::ColumnDef(_)))
        || !next.controls.is_empty() || !para_has_visible_text(prev) || !next.text.is_empty()
        || index.checked_add(2) != Some(paragraphs.len())
        || paragraphs.iter().flat_map(|p| &p.controls).filter(|c| matches!(c, Control::Table(_))).take(2).count() != 1
        || !is_para_topbottom_float(&table.common)
        || !matches!(table.common.vert_align, VertAlign::Top)
        || !matches!(table.common.horz_rel_to, HorzRelTo::Para)
        || !matches!(table.common.horz_align, HorzAlign::Left)
        || table.common.vertical_offset != 0 || table.common.horizontal_offset != 0
        || table.common.locked || table.common.size_protect || table.caption.is_some()
        || table.common.attr & (1 << 30) != 0 || table.attr & (1 << 30) != 0
        // The owned generator keeps raw default0x6 until serialization packs
        // its explicit None/nonrepeat semantics. Accept only that unsealed
        // constructor state with synchronized margin copies; never a sealed
        // source cache or unknown/noAdjust bits.
        || !(matches!(table.raw_table_record_attr, 0 | 0x0400_0000)
            || (table.raw_table_record_attr == 6 && table.raw_ctrl_seal.is_none()
                && table.common.margin.left == table.outer_margin_left
                && table.common.margin.right == table.outer_margin_right
                && table.common.margin.top == table.outer_margin_top
                && table.common.margin.bottom == table.outer_margin_bottom))
        || !matches!(table.common.height_criterion, crate::model::shape::SizeCriterion::Absolute)
        || !matches!(table.common.width_criterion, crate::model::shape::SizeCriterion::Absolute)
        || table.common.width == 0 || table.common.width > i32::MAX as u32
        || table.page_break != TablePageBreak::None || table.repeat_header || !table.zones.is_empty()
        || table.cell_spacing != 0
        || table.outer_margin_top <= 0 || table.outer_margin_left < 0
        || table.outer_margin_right < 0 || table.outer_margin_bottom < 0
        || (table.outer_margin_top == table.outer_margin_bottom
            && table.outer_margin_top == table.outer_margin_left
            && table.outer_margin_top == table.outer_margin_right)
        || table.row_count == 0 || table.col_count == 0
        || table.cells.len() != usize::from(table.row_count) * usize::from(table.col_count)
        || table.cells.iter().enumerate().any(|(i, c)|
            usize::from(c.row) != i / usize::from(table.col_count)
            || usize::from(c.col) != i % usize::from(table.col_count)
            || c.paragraphs.len() != 1 || c.cell_protect() || c.field_name.is_some()
            || c.row_span != 1 || c.col_span != 1 || c.width == 0 || c.height == 0
            || c.width > i32::MAX as u32 || c.height > i32::MAX as u32
            || c.text_direction != 0 || c.line_wrap != 0
            || c.paragraphs.iter().any(|p| !p.controls.is_empty() || !plain_metadata(p)))
        || table.common.height == 0 || table.common.height > i32::MAX as u32
        || !measured_height.is_some_and(|h| (h - hwpunit_to_px(table.common.height as i32, dpi)).abs() <= 0.2)
    { return None; }
    let [before] = prev.line_segs.as_slice() else { return None; };
    let [host] = para.line_segs.as_slice() else { return None; };
    let [following] = next.line_segs.as_slice() else { return None; };
    let template = |line: &crate::model::paragraph::LineSeg| {
        line.tag == 0x0006_0000 && line.line_height > 0 && line.text_height == line.line_height
            && line.baseline_distance > 0 && line.baseline_distance <= line.text_height
            && line.line_spacing >= 0 && line.column_start == 0
    };
    if !template(before) || !template(host) || !template(following)
        || host.segment_width != 0 || before.segment_width <= 0
        || following.segment_width != before.segment_width
        || host.vertical_pos <= 0 || before.vertical_pos < 0
        || host.line_height != before.line_height || host.line_height != following.line_height
        || host.line_spacing != before.line_spacing || host.line_spacing != following.line_spacing
        || host.text_height != before.text_height || host.text_height != following.text_height
        || host.baseline_distance != before.baseline_distance || host.baseline_distance != following.baseline_distance
        || i64::from(host.vertical_pos) - i64::from(before.vertical_pos)
            != i64::from(before.line_height) + i64::from(before.line_spacing)
        || i64::from(following.vertical_pos) - i64::from(host.vertical_pos)
            != i64::from(host.line_height) + i64::from(host.line_spacing)
        || i64::from(table.common.height) + i64::from(table.outer_margin_top)
            + i64::from(table.outer_margin_bottom)
            <= i64::from(host.line_height) + i64::from(host.line_spacing)
    { return None; }
    Some(host.vertical_pos)
}

/// The unresolved template is meaningful only when the existing flow plan
/// already reserves its complete outer band. Share this exact paint proof with
/// marker-HWPX lowering; do not reinterpret general HWPX-derived binaries.
pub(crate) fn unresolved_single_table_placeholder_paint_origin_hu(
    native_profile: bool,
    column_count: usize,
    paragraphs: &[Paragraph],
    index: usize,
    table: &crate::model::table::Table,
    measured_height: Option<f64>,
    dpi: f64,
    recomputed_native_host: bool,
    placement: Option<&crate::renderer::float_placement::ParagraphFloatPlacement>,
) -> Option<i32> {
    let origin = unresolved_single_table_placeholder_origin_hu(
        native_profile, column_count, paragraphs, index, table, measured_height, dpi)?;
    let p = placement?;
    let host = hwpunit_to_px(origin, dpi);
    let equal = |a: f64, b: f64| (a - b).abs() <= 0.000_001;
    (matches!(p.flow, crate::renderer::float_placement::ParagraphFloatFlow::Exclusion)
        && p.table_left.is_none()
        && p.stored_successor_line_origin.is_none()
        && (p.stored_host_origin.is_some_and(|v| equal(v, host))
            || (recomputed_native_host && p.stored_host_origin.is_none()))
        && equal(p.anchor_y, host)
        && equal(p.table_top, host + hwpunit_to_px(table.outer_margin_top as i32, dpi))
        && equal(p.occupied_bottom, p.table_top
            + hwpunit_to_px(table.common.height as i32, dpi)
            + hwpunit_to_px(table.outer_margin_bottom as i32, dpi)))
        .then_some(origin)
}

/// 저장 outer-box paint origin 보정의 layout 단계 안전문이다.
///
/// pagination 결과에 실제로 채워진 단 수가 아니라 활성 구역의 권위 단 수를
/// 사용하고, 측정 높이가 선언 높이와 일치하는 whole-table만 허용한다.
fn physical_outer_box_paint_inset_layout_gate(
    zone_column_count: usize,
    measured_total_height: Option<f64>,
    declared_height: f64,
) -> bool {
    zone_column_count == 1
        && measured_total_height.is_some_and(|measured| (measured - declared_height).abs() <= 0.5)
}

/// OWPML `NoteShapeType.noteLine.length`의 수평 길이 계약을 px로 해석한다.
///
/// 알 수 없는 음수만 손상 문서 호환을 위해 기존 1/3 폭 fallback으로 남긴다.
/// `0`의 수직 예약까지 없애는 일은 paint 길이와 별개의 pagination 계약이다.
fn note_separator_length_px(raw: i32, available_width: f64, dpi: f64) -> f64 {
    let available_width = available_width.max(0.0);
    let resolved = match raw {
        0 => 0.0,
        -1 => dpi * 5.0 / 2.54,
        -2 => dpi * 2.0 / 2.54,
        -3 => available_width / 3.0,
        -4 => available_width,
        value if value > 0 => hwpunit_to_px(value, dpi),
        _ => available_width / 3.0,
    };
    resolved.clamp(0.0, available_width)
}

/// 현재 FootnoteArea는 다단 각주도 body 전체 폭으로 합쳐 그린다.
///
/// 고정 길이(-1/-2)와 양수 HWPUNIT은 그 구조와 무관하게 해석할 수 있지만,
/// 상대 길이(-3/-4)는 실제 소유 단의 폭/시작점을 알아야 한다. 다단 placement를
/// 함께 고치기 전까지 상대 sentinel은 기존 1/3 폭을 보존해 범위를 넓히지 않는다.
fn footnote_separator_length_px(raw: i32, area_width: f64, dpi: f64) -> f64 {
    match raw {
        -3 | -4 => area_width.max(0.0) / 3.0,
        _ => note_separator_length_px(raw, area_width, dpi),
    }
}

#[derive(Debug, Clone, Copy)]
struct TacReceiptSealLine {
    shift_px: f64,
    line_height_px: f64,
    baseline_px: f64,
    vpos_hu: i32,
    char_style_id: u32,
    lang_index: usize,
    para_style_id: u16,
    filler_count: usize,
}

#[derive(Debug, Clone, Copy)]
struct TacPostF081cLine {
    count: usize,
    baseline_px: f64,
    char_style_id: u32,
    lang_index: usize,
}

fn effective_tac_segment_width_hu(para: &Paragraph, fallback_width_hu: i32) -> i32 {
    let seg_width = para.line_segs.first().map(|s| s.segment_width).unwrap_or(0);
    if seg_width > 0 {
        seg_width
    } else {
        fallback_width_hu.max(0)
    }
}

/// 쪽 말미 어울림 그림을 다음 물리 쪽의 시작으로 이월했는지 판별한다.
///
/// 조판은 이월 그림을 단의 첫 `Shape`로 기록하고 같은 쪽의 좁은 후속 문단에만
/// 어울림 앵커를 전달한다. 원본 호스트 문단은 이 쪽에 Full/Partial 항목으로 존재하지
/// 않는다. 이 세 가지는 일반 자리차지 항목과 구별되는 렌더러 내부 계약이다.
///
/// 현재 쪽이 실제로 소유한 후속 시작 줄이 vpos0 어울림 띠면 원래 문단 오프셋은
/// 앞 쪽에서 소비했다. 앞쪽 전폭 줄 뒤의 리셋도 PartialParagraph의 시작 컷으로
/// 소유를 확인하며, 문단 전체의 첫 줄을 이 쪽 시작으로 다시 해석하지 않는다.
fn deferred_page_start_square_picture_uses_body_top(
    col_content: &ColumnContent,
    item_ordinal: usize,
    paragraphs: &[Paragraph],
    para_index: usize,
    control_index: usize,
) -> bool {
    if item_ordinal != 0
        || col_content.items.iter().any(|item| {
            matches!(
                item,
                PageItem::FullParagraph { para_index: item_pi }
                    | PageItem::PartialParagraph { para_index: item_pi, .. }
                    if *item_pi == para_index
            )
        })
        || !col_content
            .wrap_anchors
            .values()
            .any(|anchor| anchor.anchor_para_index == para_index)
    {
        return false;
    }

    let Some(para) = paragraphs.get(para_index) else {
        return false;
    };
    let Some(Control::Picture(picture)) = para.controls.get(control_index) else {
        return false;
    };
    let common = &picture.common;
    if common.treat_as_char
        || !common.flow_with_text
        || !matches!(common.text_wrap, TextWrap::Square)
        || !matches!(common.vert_rel_to, VertRelTo::Para)
        || !matches!(common.vert_align, VertAlign::Top)
    {
        return false;
    }

    col_content
        .items
        .iter()
        .find_map(|item| {
            let (successor, start_line) = match item {
                PageItem::FullParagraph { para_index, .. } => (*para_index, 0),
                PageItem::PartialParagraph {
                    para_index,
                    start_line,
                    ..
                } => (*para_index, *start_line),
                _ => return None,
            };
            if successor != para_index + 1
                || col_content.wrap_anchors.get(&successor)?.anchor_para_index != para_index
            {
                return None;
            }
            paragraphs.get(successor)?.line_segs.get(start_line)
        })
        .is_some_and(|seg| {
            seg.vertical_pos == 0
                && seg.column_start == 0
                && seg.segment_width > 0
                && (seg.segment_width as i32 - common.horizontal_offset as i32).abs() <= 200
        })
}

#[derive(Clone)]
struct PagePreviewImage {
    mime: &'static str,
    data: Vec<u8>,
}

fn para_border_is_visible(border: &BorderLine) -> bool {
    !matches!(border.line_type, BorderLineType::None)
}

fn para_border_same_stroke(a: &BorderLine, b: &BorderLine) -> bool {
    a.line_type == b.line_type && a.width == b.width && a.color == b.color
}

fn para_border_can_use_rect_stroke(
    borders: &[BorderLine; 4],
    skip_top: bool,
    skip_bottom: bool,
) -> bool {
    borders.iter().all(para_border_is_visible)
        // Rectangle stroke 는 dash 정보를 표현하지 못하므로 점선/파선 문단 테두리는
        // 면별 LineNode 경로로 보내야 한컴의 선 모양과 일치한다.
        && borders
            .iter()
            .all(|border| matches!(border.line_type, BorderLineType::Solid))
        && borders[1..]
            .iter()
            .all(|border| para_border_same_stroke(&borders[0], border))
        && !skip_top
        && !skip_bottom
}

/// `Square/어울림` 그림이 문단 중간부터 본문을 감싸는 경우, HWP5는
/// `LINE_SEG`에서 그림 옆으로 좁아지는 첫 줄의 `vertical_pos`를 저장한다.
/// 개체 자체도 그 줄의 top에 맞춰야 한컴의 “서로 자리를 침범하지 않는”
/// 어울림 배치가 된다.
///
/// 일부 HWP5 원본은 문단 첫 줄의 `vertical_pos`가 0이 아니라 페이지/구역
/// 흐름 기준 누적값이다. 이때 좁아지는 줄의 raw vpos를 그대로 문단 y에
/// 더하면 `para_y + absolute_vpos`가 되어 그림이 페이지 하단 밖으로 밀린다.
/// 따라서 그림 배치에는 문단 첫 줄 대비 상대 delta만 사용한다.
fn square_wrap_first_narrow_line_vpos_px(
    para: &Paragraph,
    col_area: &LayoutRect,
    dpi: f64,
) -> Option<f64> {
    if para.line_segs.len() < 2 {
        return None;
    }
    let col_w_hu = px_to_hwpunit(col_area.width, dpi);
    let first_wrap_idx = para
        .line_segs
        .iter()
        .position(|seg| seg.is_in_wrap_zone(col_w_hu))?;
    if first_wrap_idx == 0 {
        return None;
    }
    let has_full_width_before = para.line_segs[..first_wrap_idx]
        .iter()
        .any(|seg| !seg.is_in_wrap_zone(col_w_hu) && seg.segment_width > 0);
    if !has_full_width_before {
        return None;
    }
    let base_vpos = para.line_segs.first()?.vertical_pos;
    let narrow_vpos = para.line_segs[first_wrap_idx].vertical_pos;
    if narrow_vpos < base_vpos {
        return None;
    }
    Some(hwpunit_to_px(narrow_vpos - base_vpos, dpi))
}

/// [#4384] TAC 표 앞 F081C 채움줄에 한컴 서명/날인 PUA(U+F012B)가 섞여 있는지 판정한다.
///
/// 종전에는 표 셀 텍스트가 "접수증"/"Filing Receipt" 문구를 담고 있는지로 이 표가
/// 서명/날인 자리를 필요로 하는지 판정했다. 그러나 실측(`samples/복학원서.hwp`
/// 문단 16)에서 F081C 채움 안에 U+F012B 한 글자가 실제로 섞여 저장돼 있음을 확인했다
/// — 한컴이 서명/날인 자리를 만들 때 채움 문자 사이에 이 PUA 를 심어 저장하는 게
/// 원인이다(`issue_937`: U+F012B 는 어디서나 `(인)` 으로 렌더돼야 하는 범용 한컴
/// 서명/날인 기호). 표 제목 문구는 사용자가 언제든 편집해 사라지지만, 이 PUA 는
/// 문서가 실제로 서명/날인 자리를 저장했다는 구조적 사실 자체라 편집으로 없어지지
/// 않는다. 10,000건 실 문서 코퍼스에서 이 F081C+F012B 조합을 쓰는 문서는
/// `samples/복학원서.hwp` 계열 외에 없었다(#4384 조사) — 문구 매칭보다 좁으면 좁았지
/// 넓지 않다.
fn tac_filler_line_has_signature_marker(composed: Option<&ComposedParagraph>) -> bool {
    composed
        .and_then(|c| c.lines.first())
        .is_some_and(|line| line.runs.iter().any(|run| run.text.contains('\u{F012B}')))
}

fn tac_receipt_filler_prefix(
    para: &Paragraph,
    composed: Option<&ComposedParagraph>,
    table: &crate::model::table::Table,
    control_index: usize,
    dpi: f64,
) -> Option<TacReceiptSealLine> {
    if control_index != 0
        || !table.common.treat_as_char
        || para.line_segs.len() < 2
        || !tac_filler_line_has_signature_marker(composed)
    {
        return None;
    }

    let comp = composed?;
    let first_line = comp.lines.first()?;
    let mut filler_count = 0usize;
    let mut first_style = None;
    for run in &first_line.runs {
        first_style.get_or_insert((run.char_style_id, run.lang_index));
        for ch in run.text.chars() {
            match ch {
                '\u{F081C}' => filler_count += 1,
                // [#4384] 이 문자의 존재가 위 tac_filler_line_has_signature_marker 게이트를
                // 통과시킨 실제 근거다 — filler_count 에는 넣지 않고 통과만 시킨다.
                '\u{F012B}' | '\u{FFFC}' | ' ' | '\t' | '\r' | '\n' => {}
                _ => return None,
            }
        }
    }
    if filler_count < 16 {
        return None;
    }

    let first_seg = para.line_segs.first()?;
    let table_seg = para.line_segs.get(1)?;
    let delta_hu = table_seg.vertical_pos - first_seg.vertical_pos;
    if delta_hu <= 0 {
        return None;
    }
    let shift_px = hwpunit_to_px(delta_hu, dpi);
    if shift_px < 4.0 {
        return None;
    }

    let (char_style_id, lang_index) = first_style.unwrap_or((0, 0));
    Some(TacReceiptSealLine {
        shift_px,
        line_height_px: hwpunit_to_px(first_seg.line_height, dpi),
        baseline_px: hwpunit_to_px(first_seg.baseline_distance, dpi),
        vpos_hu: first_seg.vertical_pos,
        char_style_id,
        lang_index,
        para_style_id: comp.para_style_id,
        filler_count,
    })
}

fn receipt_seal_line_text(
    filler_count: usize,
    style: &TextStyle,
    available_width: f64,
) -> (String, f64) {
    let mut side_count = (filler_count.saturating_sub(3) / 2).clamp(8, 96);
    let build =
        |count: usize| -> String { format!("{}(인){}", "-".repeat(count), "-".repeat(count)) };
    let mut text = build(side_count);
    let mut width = estimate_text_width(&text, style);

    while width > available_width && side_count > 8 {
        side_count -= 1;
        text = build(side_count);
        width = estimate_text_width(&text, style);
    }
    while width < available_width * 0.96 && side_count < 128 {
        let next = build(side_count + 1);
        let next_width = estimate_text_width(&next, style);
        if next_width > available_width {
            break;
        }
        side_count += 1;
        text = next;
        width = next_width;
    }

    (text, width)
}

fn push_tac_receipt_seal_line(
    tree: &mut PageLayoutContext,
    col_node: &mut RenderNode,
    section_index: usize,
    para_index: usize,
    line_top: f64,
    col_area: &LayoutRect,
    styles: &ResolvedStyleSet,
    seal: TacReceiptSealLine,
) {
    let mut style = resolved_to_text_style(styles, seal.char_style_id, seal.lang_index);
    style.available_width = col_area.width;
    let (text, width) = receipt_seal_line_text(seal.filler_count, &style, col_area.width);
    let line_height = seal.line_height_px.max(style.font_size * 1.2).max(1.0);
    let baseline = seal.baseline_px.max(if style.font_size > 0.0 {
        style.font_size * 0.85
    } else {
        10.0
    });
    let line_id = tree.next_id();
    let mut line_node = RenderNode::new(
        line_id,
        RenderNodeType::TextLine(TextLineNode::with_para_vpos(
            line_height,
            baseline,
            section_index,
            para_index,
            0,
            seal.vpos_hu,
        )),
        BoundingBox::new(col_area.x, line_top, col_area.width, line_height),
    );
    let run_id = tree.next_id();
    let run_node = RenderNode::new(
        run_id,
        RenderNodeType::TextRun(TextRunNode {
            text,
            style,
            char_shape_id: Some(seal.char_style_id),
            para_shape_id: Some(seal.para_style_id),
            section_index: Some(section_index),
            para_index: Some(para_index),
            char_start: None,
            cell_context: None,
            is_para_end: false,
            is_line_break_end: false,
            rotation: 0.0,
            is_vertical: false,
            char_overlap: None,
            border_fill_id: 0,
            baseline,
            field_marker: FieldMarkerType::None,
            layout_positions: None,
            display_text: None,
        }),
        BoundingBox::new(
            col_area.x + (col_area.width - width).max(0.0) / 2.0,
            line_top,
            width.min(col_area.width),
            line_height,
        ),
    );
    line_node.children.push(run_node);
    col_node.children.push(line_node);
}

fn f081c_marker_count(chars: &[char]) -> Option<usize> {
    let count = chars.len();
    if (1..=2).contains(&count) && chars.iter().all(|ch| *ch == '\u{F081C}') {
        Some(count)
    } else {
        None
    }
}

fn tac_receipt_post_f081c_line(
    para: &Paragraph,
    composed: Option<&ComposedParagraph>,
    table: &crate::model::table::Table,
    control_index: usize,
    dpi: f64,
) -> Option<TacPostF081cLine> {
    if control_index != 0
        || !table.common.treat_as_char
        || para.line_segs.len() < 2
        || !tac_filler_line_has_signature_marker(composed)
    {
        return None;
    }

    let positions = para.control_text_positions();
    let table_pos = *positions.get(control_index)?;
    let text_chars: Vec<char> = para.text.chars().collect();
    if table_pos >= text_chars.len() {
        return None;
    }
    let next_control_pos = positions
        .iter()
        .enumerate()
        .filter_map(|(ci, pos)| {
            (ci != control_index && *pos > table_pos).then_some((*pos).min(text_chars.len()))
        })
        .min()
        .unwrap_or(text_chars.len());
    let marker_chars = text_chars.get(table_pos..next_control_pos)?;
    let count = f081c_marker_count(marker_chars)?;

    let comp = composed?;
    let line = comp.lines.iter().find(|line| {
        line.char_start == table_pos
            && line
                .runs
                .iter()
                .flat_map(|run| run.text.chars())
                .eq(marker_chars.iter().copied())
    })?;
    let run = line.runs.first()?;
    Some(TacPostF081cLine {
        count,
        baseline_px: hwpunit_to_px(line.baseline_distance, dpi),
        char_style_id: run.char_style_id,
        lang_index: run.lang_index,
    })
}

#[allow(clippy::too_many_arguments)]
fn push_tac_post_f081c_line(
    tree: &mut PageLayoutContext,
    col_node: &mut RenderNode,
    section_index: usize,
    para_index: usize,
    table: &crate::model::table::Table,
    table_y_start: f64,
    col_area: &LayoutRect,
    styles: &ResolvedStyleSet,
    marker: TacPostF081cLine,
    dpi: f64,
) {
    let style = resolved_to_text_style(styles, marker.char_style_id, marker.lang_index);
    let font_size = if style.font_size > 0.0 {
        style.font_size
    } else {
        12.0
    };
    // [#5785 후속] 표 오른쪽 끝 마커 위치도 흐름 폭과 같은 규칙을 써야 한다.
    let table_width_hu: u32 = table.flow_width_hu();
    let marker_x = col_area.x + hwpunit_to_px(table_width_hu as i32, dpi);
    let width = (font_size * 0.45 * marker.count as f64).max(4.0);
    let stroke_width = (font_size * 0.055).clamp(0.5, 1.0);
    let line_y = table_y_start + marker.baseline_px - font_size * 0.26;
    let mut line = LineNode::new(
        marker_x,
        line_y,
        marker_x + width,
        line_y,
        LineStyle {
            color: style.color,
            width: stroke_width,
            dash: StrokeDash::Solid,
            ..Default::default()
        },
    );
    line.section_index = Some(section_index);
    line.para_index = Some(para_index);

    let id = tree.next_id();
    let bbox = line.ink_bbox();
    col_node
        .children
        .push(RenderNode::new(id, RenderNodeType::Line(line), bbox));
}

fn table_has_detached_para_flow_object(table: &crate::model::table::Table) -> bool {
    table
        .cells
        .iter()
        .flat_map(|cell| cell.paragraphs.iter())
        .flat_map(|p| p.controls.iter())
        .any(|ctrl| match ctrl {
            Control::Picture(pic) => {
                !pic.common.treat_as_char
                    && !pic.common.flow_with_text
                    && matches!(pic.common.text_wrap, TextWrap::TopAndBottom)
                    && matches!(pic.common.vert_rel_to, VertRelTo::Para)
            }
            Control::Shape(shape) => {
                let common = shape.common();
                !common.treat_as_char
                    && !common.flow_with_text
                    && matches!(common.text_wrap, TextWrap::TopAndBottom)
                    && matches!(common.vert_rel_to, VertRelTo::Para)
            }
            _ => false,
        })
}

type ParaFloatLanes = std::collections::HashMap<usize, FloatLaneSet>;

#[derive(Debug, Clone, Copy)]
struct VisibleFloatExclusion {
    /// Fixed page geometry survives paragraph cursor advancement/backtracking.
    fixed_textbox: bool,
    /// visible host 문단의 양수 offset 자리차지 표가 후속 본문을 밀어내야 하는 y 구간.
    top: f64,
    bottom: f64,
    /// 이 zone 을 만든 표가 앵커된 host 문단 index. 같은 문단의 텍스트(섹션 제목)는
    /// 자기 표가 만든 zone 에 밀리면 안 된다 — 한컴은 제목을 문단 앵커(표 위)에 두고
    /// 양수 offset 표를 그 아래에 둔다. consume 시 self-owned zone 을 skip 하는 데 쓴다.
    owner_para: usize,
    /// true: 후속 본문 줄도 이 밴드를 피한다(자리차지 T&B 표).
    /// false: 본문은 옆을 흐르고, 후속 자리차지(T&B) 표만 밴드 아래로 밀린다
    /// (어울림 Square 그림, #5929).
    blocks_text: bool,
}

/// 그린 노드에서 해당 컨트롤의 페인트 bbox 를 찾는다.
fn find_painted_control_bbox(
    node: &RenderNode,
    para_index: usize,
    control_index: usize,
) -> Option<BoundingBox> {
    let hit = match &node.node_type {
        RenderNodeType::Image(img) => {
            img.para_index == Some(para_index) && img.control_index == Some(control_index)
        }
        _ => false,
    };
    if hit && node.bbox.height > 0.0 {
        return Some(node.bbox);
    }
    node.children
        .iter()
        .rev()
        .find_map(|child| find_painted_control_bbox(child, para_index, control_index))
}

/// [#5929] 어울림(Square) 그림은 본문 흐름 y 를 밀지 않지만, allowOverlap=0 이면
/// 후속 자리차지(T&B) 표는 그림과 겹치면 안 된다. 본문 텍스트는 그림 옆을 흐르므로
/// `blocks_text=false`.
fn square_picture_side_wrap_exclusion(
    para: &Paragraph,
    para_index: usize,
    control_index: usize,
    col_node: &RenderNode,
) -> Option<VisibleFloatExclusion> {
    let Control::Picture(pic) = para.controls.get(control_index)? else {
        return None;
    };
    if pic.common.treat_as_char
        || pic.common.allow_overlap
        || !matches!(pic.common.text_wrap, TextWrap::Square)
        || !matches!(pic.common.vert_rel_to, VertRelTo::Para)
    {
        return None;
    }
    let bbox = find_painted_control_bbox(col_node, para_index, control_index)?;
    if bbox.height <= 0.0 {
        return None;
    }
    Some(VisibleFloatExclusion {
        fixed_textbox: false,
        top: bbox.y,
        bottom: bbox.y + bbox.height,
        owner_para: para_index,
        blocks_text: false,
    })
}

fn render_node_contains_text_for_para(node: &RenderNode, para_index: usize) -> bool {
    if let RenderNodeType::TextRun(run) = &node.node_type {
        if run.para_index == Some(para_index) {
            return true;
        }
    }
    node.children
        .iter()
        .any(|child| render_node_contains_text_for_para(child, para_index))
}

fn insert_before_para_text(parent: &mut RenderNode, para_index: usize, mut nodes: Vec<RenderNode>) {
    if nodes.is_empty() {
        return;
    }
    if let Some(pos) = parent
        .children
        .iter()
        .position(|child| render_node_contains_text_for_para(child, para_index))
    {
        for (offset, node) in nodes.drain(..).enumerate() {
            parent.children.insert(pos + offset, node);
        }
    } else {
        parent.children.extend(nodes);
    }
}

fn page_item_is_treat_as_char_picture_only(item: &PageItem, paragraphs: &[Paragraph]) -> bool {
    let para_index = match item {
        PageItem::FullParagraph { para_index }
        | PageItem::PartialParagraph { para_index, .. }
        | PageItem::Table { para_index, .. }
        | PageItem::PartialTable { para_index, .. }
        | PageItem::Shape { para_index, .. } => *para_index,
        PageItem::EndnoteSeparator { .. } => return false,
    };
    paragraphs
        .get(para_index)
        .map(|para| {
            para.text.trim().is_empty()
                && para.controls.iter().any(|ctrl| match ctrl {
                    Control::Picture(pic) => pic.common.treat_as_char,
                    Control::Shape(shape) => shape.common().treat_as_char,
                    _ => false,
                })
        })
        .unwrap_or(false)
}

/// [#2813] 빈 host 문단의 para-relative TopAndBottom 표 스택 뒤로 이연된 앵커 줄이다.
///
/// typeset은 한글 문서순을 보존하기 위해 `Table → Table → PartialParagraph` 순서로
/// PageItem을 남긴다. 마지막 줄은 공백뿐이라 잉크·높이를 만들 필요가 없지만, 일반
/// PartialParagraph layout 경로를 태우면 표의 실제 측정 높이를 다시 더해 본문 밖에서
/// 빈 줄을 그리려 한다. 앞쪽에 같은 host의 float 표가 두 개 이상 있는 경우에만 이를
/// 식별해 item 순서는 보존하고 빈 줄의 draw/flow advance는 생략한다.
fn is_deferred_blank_para_float_stack_anchor(
    item: &PageItem,
    item_ordinal: usize,
    items: &[PageItem],
    paragraphs: &[Paragraph],
) -> bool {
    let PageItem::PartialParagraph {
        para_index,
        start_line,
        ..
    } = item
    else {
        return false;
    };
    if *start_line != 0
        || paragraphs
            .get(*para_index)
            .map(para_has_visible_text)
            .unwrap_or(true)
    {
        return false;
    }

    // 바로 앞에 연속된 표만 세어, 같은 host의 이전 표가 우연히 둘 이상 있었다는 이유로
    // 일반 빈 문단의 간격을 없애지 않는다.
    let coanchored_float_count = items[..item_ordinal]
        .iter()
        .rev()
        .take_while(|previous| {
            let PageItem::Table {
                para_index: table_para_index,
                control_index,
            } = previous
            else {
                return false;
            };
            *table_para_index == *para_index
                && paragraphs
                    .get(*table_para_index)
                    .and_then(|para| para.controls.get(*control_index))
                    .is_some_and(|control| {
                        matches!(control, Control::Table(table)
                            if is_para_topbottom_float(&table.common))
                    })
        })
        .count();

    coanchored_float_count >= 2
}

/// 표 경로의 단일 레벨 (표 → 셀 → 문단)
#[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize)]
pub struct CellPathEntry {
    /// 문단 내 컨트롤 인덱스 (표)
    pub control_index: usize,
    /// 표 내 셀 인덱스
    pub cell_index: usize,
    /// 셀 내 문단 인덱스
    pub cell_para_index: usize,
    /// 텍스트 방향 (0=가로, 1=세로/영문눕힘, 2=세로/영문세움)
    pub text_direction: u8,
}

/// 표 셀 내부 문단 편집용 컨텍스트 (중첩 표 경로 지원)
#[derive(Debug, Clone, PartialEq, serde::Serialize)]
pub struct CellContext {
    /// 최외곽 표를 소유한 구역 문단 인덱스
    pub parent_para_index: usize,
    /// 표 경로 (depth 1=단일 표, depth 2+=중첩 표)
    pub path: Vec<CellPathEntry>,
    /// [#5820] 글상자(drawText) 내부 문단 여부 — 표 셀과 달리 한글은 글상자
    /// 안에서도 셀 밖 규칙(오른쪽 정렬 말미 공백 제외)을 적용한다.
    pub in_textbox: bool,
}

/// [#2091] 표 컨트롤 블록 배치 결과 — early_return 은 원본의 함수 조기 return 신호.
struct TableControlOut {
    y_offset: f64,
    tac_seg_applied: bool,
    para_float_lane_info: Option<(f64, f64, f64, f64, f64, Option<f64>)>,
    early_return: Option<(f64, bool)>,
}

/// [#2091] 표 컨트롤 블록 배치의 문단-스코프 스칼라 묶음.
#[derive(Clone, Copy)]
struct TableControlVars {
    y_offset: f64,
    para_y_for_table: f64,
    tac_table_y_before: f64,
    is_tac: bool,
    is_current_empty_para_float: bool,
    is_current_empty_square_sibling_float: bool,
    is_current_visible_para_float: bool,
    is_first_empty_para_float_control: bool,
    /// [#6032] 빈-host anchor 가 저장 vpos 로 되감겨 스냅됐는지 — 이 경우 흐름도
    /// 물리 사다리 여분(v_off+outer)을 계상해야 다음 문단이 표 위로 올라오지 않는다.
    rewind_anchor_snapped: bool,
    para_index: usize,
    control_index: usize,
}

impl CellContext {
    /// 최외곽 표의 컨트롤 인덱스 — 빈 경로면 None (HWP 변조/편집 API로 빈 경로 생성 가능).
    pub fn outermost_control(&self) -> Option<usize> {
        self.path.first().map(|e| e.control_index)
    }
    /// 최외곽 표의 셀 인덱스 — 빈 경로면 None.
    pub fn outermost_cell(&self) -> Option<usize> {
        self.path.first().map(|e| e.cell_index)
    }
    /// 최외곽 표의 셀 문단 인덱스 — 빈 경로면 None.
    pub fn outermost_cell_para(&self) -> Option<usize> {
        self.path.first().map(|e| e.cell_para_index)
    }
    /// 최내곽 레벨의 엔트리 — 빈 경로면 None.
    pub fn innermost(&self) -> Option<&CellPathEntry> {
        self.path.last()
    }
    /// 텍스트 방향 (최내곽 기준) — 빈 경로면 None.
    pub fn text_direction(&self) -> Option<u8> {
        self.innermost().map(|e| e.text_direction)
    }

    /// [#4334] 이 경로가 가리키는 **중첩 표 자신의** `(para_index, control_index)` —
    /// `layout_table`/`layout_partial_table_item` 의 `table_meta` 인자 형태 그대로다.
    /// 경로 마지막 항목이 그 중첩 표 컨트롤이고, 한 단계 바깥 항목의 `cell_para_index`
    /// 가 그 표를 담은 셀 문단이다. depth 1(최외곽 표)은 바깥 레벨이 없어 `None`.
    ///
    /// 재귀 중첩 표를 배치하는 세 곳(`table_layout.rs` 2곳, `table_partial.rs` 1곳)이
    /// `table_meta: None` 을 넘겨 `TableNode.para_index`/`control_index` 가 항상 비어
    /// 있었다 — #4334 stage3 가 실측한 "문서 위치 없는 노드" 의 주된 원인이다.
    pub fn nested_table_meta(&self) -> Option<(usize, usize)> {
        let table_entry = self.path.last()?;
        let parent_entry = self.path.get(self.path.len().checked_sub(2)?)?;
        Some((parent_entry.cell_para_index, table_entry.control_index))
    }

    /// (cell_index, cell_para_index, outer_table_control_index) — 최내곽 entry 의 3 필드.
    /// ImageNode / RectangleNode 등의 cell context 3 필드 매핑 boilerplate 통합용.
    /// path 가 비어있으면 (None, None, None).
    pub fn last_image_indices(&self) -> (Option<usize>, Option<usize>, Option<usize>) {
        match self.path.last() {
            Some(e) => (
                Some(e.cell_index),
                Some(e.cell_para_index),
                Some(e.control_index),
            ),
            None => (None, None, None),
        }
    }
}

/// [#6778] 항목이 가리키는 문단 서수.
fn page_item_para_index(item: &PageItem) -> Option<usize> {
    match item {
        PageItem::FullParagraph { para_index }
        | PageItem::PartialParagraph { para_index, .. }
        | PageItem::Table { para_index, .. }
        | PageItem::PartialTable { para_index, .. }
        | PageItem::Shape { para_index, .. } => Some(*para_index),
        PageItem::EndnoteSeparator { .. } => None,
    }
}

/// 항목이 그리는 첫 줄 서수 — 문단 중간에서 시작하는 조각만 0 이 아니다.
fn page_item_first_line(item: &PageItem) -> usize {
    match item {
        PageItem::PartialParagraph { start_line, .. } => *start_line,
        _ => 0,
    }
}

/// [#6778] 저장 사다리가 이 문단을 **개체 오른쪽 레인**에 두었는가.
///
/// 두 조건을 **모두** 요구한다. 둘 다 개체 상자와 직접 대조하므로, 폭만 우연히 맞는
/// 큰 들여쓰기 문단은 걸리지 않는다.
///
/// 1. **줄 시작이 개체의 오른쪽 경계 밖**이다 — `column_start >= object_right_hu`.
///    개체와 겹치지 않으려면 레인은 그 밖에서 시작할 수밖에 없다. 들여쓰기는 개체와
///    무관한 값이라 이 대조에서 갈린다(156757920: `cs=17626` vs 개체 우단 `17070`;
///    두 글자 들여쓰기 `≈2000` 은 통과 못 한다).
/// 2. **좁아진 폭이 개체 폭의 절반 이상**이다 — 개체가 실제로 그 줄을 밀어낸 증거.
///
/// ⚠ `column_start == 0` 인 **왼쪽 레인은 이 술어가 잡지 않는다.** 개체가 오른쪽에
/// 놓이고 글이 왼쪽으로 흐르는 형상(`#4090` 156492236: `horz=문단(26319)`, 후속
/// 문단 `cs=0`)이 여기 해당한다 — 렌더가 이미 제자리에 놓으므로 손대지 않는다.
/// 이 축이 고치는 것은 **오른쪽 레인**뿐이다.
///
/// 판정 대상은 항목이 **실제로 그리는 첫 줄**이다(`first_line`). 접두 줄만 개체 옆
/// 레인에 두고 나머지를 전폭 `PartialParagraph` 로 내보낸 문단(#4599, 156714641
/// p1 pi13 lines 7..9)에서 문단 첫 줄을 보면 전폭 꼬리를 레인으로 오판해, 흐름이
/// host 줄 높이로 되감기고 꼬리가 표·접두 줄 위에 겹쳐 그려진다.
fn stored_seg_is_side_lane(
    para: Option<&Paragraph>,
    first_line: usize,
    col_w_hu: i32,
    object_left_hu: i32,
    object_right_hu: i32,
) -> bool {
    let Some(para) = para else {
        return false;
    };
    let Some(seg) = para
        .line_segs
        .iter()
        .skip(first_line)
        .find(|s| s.tag & 0x8000_0000 == 0)
    else {
        return false;
    };
    let cs = seg.column_start as i64;
    let sw = seg.segment_width as i64;
    if sw <= 0 || cs <= 0 || object_right_hu <= 0 {
        return false;
    }
    // (1) 개체 오른쪽 경계 밖에서 시작하는가.
    if cs < object_right_hu as i64 {
        return false;
    }
    // (2) 개체 폭의 절반 이상 좁아졌는가.
    let object_w_hu = (object_right_hu - object_left_hu).max(0) as i64;
    (col_w_hu as i64 - sw) * 2 >= object_w_hu
}

fn para_has_visible_text(para: &Paragraph) -> bool {
    para.text.chars().any(|c| c > '\u{001F}' && c != '\u{FFFC}')
}

/// 저장 LINE_SEG가 없는 공백 전용 ViewText 문단에서 첫 RowBreak TAC 표는 한/글이
/// 좌우 대칭 기본 padding을 표 시작 inset으로 보존한다. PageItem TAC fallback의
/// 좌표에만 적용해, 저장 줄·후행 표·비대칭 padding의 기존 배치를 유지한다.
fn viewtext_first_rowbreak_table_left_inset(
    para: &Paragraph,
    control_index: usize,
    table: &crate::model::table::Table,
    dpi: f64,
) -> f64 {
    if crate::renderer::para_has_no_stored_line_segs(para)
        && !para.text.is_empty()
        && para.text.chars().all(char::is_whitespace)
        && control_index == 0
        && table.common.treat_as_char
        && matches!(
            table.page_break,
            crate::model::table::TablePageBreak::RowBreak
        )
        && table.padding.left > 0
        && table.padding.left == table.padding.right
    {
        hwpunit_to_px(
            i32::from(table.padding.left) + i32::from(table.outer_margin_left),
            dpi,
        )
    } else {
        0.0
    }
}

/// [#7203] 쪽(단) 맨 위에 앉은 어울림(TAC) 표 호스트의 저장 첫 줄 `vertical_pos`(px).
///
/// `LINE_SEG.vertical_pos` 는 문단 기준이 아니라 쪽(단) 상단 기준 절대값이다. 호스트
/// 문단이 단 맨 위에 오면 흐름 커서가 곧 단 상단이므로 저장값이 그대로 위 여백이 된다.
/// 본문 문단은 `paragraph_layout` 의 column-top 계약(Task #1811)이 이 값을 싣는데, 빈
/// 앵커 문단의 TAC 표는 `PageItem::FullParagraph` 가 발행되지 않아 그 블록을 못 타고
/// 저장값이 0 으로 뭉개졌다.
///
/// 정본 `pdf/hwpctl_API_v2.4-hwp-2020.pdf` 가 두 갈래를 갈라 준다 — 쪽 맨 위에 놓인 표
/// 15건 중 저장 `vpos=500HU`(6.67px)인 8건만 정본 윗변 `142.56` 대 rhwp `136.00` 으로
/// 어긋났고(`+6.56px`, 8건 전부 같은 값), `vpos=0` 인 1건과 자리차지 6건은
/// `136.01` 대 `136.00` 으로 이미 맞았다.
///
/// 상한은 Task #1811 과 같은 계약이다 — 쪽-상대 증거인 `vpos ≤ spacing_before` 만 쓰고
/// 누적축 인코딩(`vpos ≫ spacing_before`)은 쪽-상대 증거가 아니므로 종전대로 버린다.
/// 합성 사다리(`TAG_IMPLEMENTATION_PROPERTY`)도 증거가 아니다.
fn tac_column_top_stored_vpos_px(para: &Paragraph, spacing_before: f64, dpi: f64) -> Option<f64> {
    let seg = para.line_segs.first()?;
    if seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY != 0 {
        return None;
    }
    if seg.vertical_pos <= 0 {
        return None;
    }
    let vpos_px = hwpunit_to_px(seg.vertical_pos, dpi);
    (vpos_px <= spacing_before + 0.5).then_some(vpos_px)
}

fn para_has_non_whitespace_text(para: &Paragraph) -> bool {
    para.text
        .chars()
        .any(|c| c > '\u{001F}' && c != '\u{FFFC}' && !c.is_whitespace())
}

/// [#5584] 자리차지 표 호스트 문단의 **저장 줄 전부가 표 위**인가.
///
/// 한글은 호스트 텍스트를 표의 세로 오프셋보다 앞선 저장 vpos 에 그대로 둔다
/// (00072 별표 제목: 저장 줄 3420 < 표 vertOffset 4129 → 1쪽 표 위). rhwp 는
/// RowBreak 자리차지 표의 호스트 텍스트를 마지막 조각 뒤로 미루는 계약
/// (`defer_visible_rowbreak_host_text`)을 쓰는데, 그 계약은 표 **아래**에 놓이는
/// 서명란·발신명의 호스트를 위한 것이라 이 형상에서는 제목을 마지막 쪽 표
/// 하단 밖으로 보냈다. 저장 기하가 "전 줄이 표 위"를 증언할 때만 지연을 끈다 —
/// 일부 줄만 위인 혼합 형상은 뒤 텍스트가 소실될 수 있어 제외한다.
pub(crate) fn stored_host_lines_precede_float(
    para: &Paragraph,
    table: &crate::model::table::Table,
    control_index: usize,
) -> bool {
    let v_off = signed_hwpunit(table.common.vertical_offset);
    if v_off <= 0 {
        return false;
    }
    let stored: Vec<&crate::model::paragraph::LineSeg> = para
        .line_segs
        .iter()
        .filter(|ls| ls.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0)
        .collect();
    let Some(base) = stored.first().map(|ls| ls.vertical_pos) else {
        return false;
    };
    // [#6860] `v_off` 의 기준은 문단 첫 줄이 아니라 **앵커 줄**(표 제어 문자가 실린
    // 저장 줄)이다. 호스트가 한 줄이면 둘이 같아 #5584·#1686 핀은 그대로다.
    let anchor_top = stored_float_anchor_line_top(para, control_index, &stored).unwrap_or(base);
    let float_top = (anchor_top as i64 - base as i64) + v_off as i64;
    // 줄이 표 상단 **위에서 끝나야** 한다 — 표 상단이 줄 밴드 안이면 그
    // 줄은 표의 앵커 줄이지 선행 줄이 아니다(pr-1674 #1686 핀: v_off 607 <
    // 줄 높이 1200 → 안내문은 표 뒤가 정답). 00072 제목은 v_off 4129 ≥ 줄
    // 끝 1500 으로 표 위 선행 줄임이 증명된다.
    stored
        .iter()
        .all(|ls| (ls.vertical_pos as i64 - base as i64) + i64::from(ls.line_height) <= float_top)
}

/// [#6860] 자리차지 개체의 **앵커 줄** 상단 — 그 개체의 제어 문자가 실린 저장 줄이다.
///
/// 한글은 `vertOffset` 을 문단 첫 줄이 아니라 앵커 줄 기준으로 잰다. 3067979 문단 1523
/// (호스트 2줄, 표 제어 문자는 텍스트 맨 끝)의 저장 기하가 그 증거다 — 앵커 줄1 기준
/// 표 상단 32332+1256 = 33588 은 줄1 끝(33332) 바로 아래인데, 첫 줄 기준 30732+1256 =
/// 31988 은 줄0 이 끝난(31732) 뒤 줄1 이 시작(32332)하기도 전인 빈 자리다.
///
/// 제어 문자 위치를 못 구하면 `None` 을 돌려 호출부가 첫 줄로 되돌아가게 한다 — 호스트가
/// 한 줄이면 어느 쪽이든 같은 값이라 종전 계약(#5584 · #1686)은 그대로다.
fn stored_float_anchor_line_top(
    para: &Paragraph,
    control_index: usize,
    stored: &[&crate::model::paragraph::LineSeg],
) -> Option<i32> {
    // 줄의 `text_start` 와 같은 축(HWP5 UTF-16)으로 올려서 견준다.
    let anchor_u16 = if para.char_offsets.is_empty() {
        // [#6879] 글자가 하나도 없이 개체만 실린 문단은 `char_offsets` 가 비어 있어
        // 위 사상이 불가능하다. 이 형상에서는 인라인 개체 하나가 축을 정확히 8 유닛씩
        // 차지하므로 **앞선 인라인 개체 수 × 8** 이 곧 제어 문자 자리다
        // (156767332 pi=73: TAC 라벨 뒤 float → 8, 저장 줄1 `textpos=8` 과 일치).
        let inline_before = para
            .controls
            .iter()
            .take(control_index)
            .filter(|ctrl| {
                matches!(
                    ctrl,
                    Control::Shape(_)
                        | Control::Table(_)
                        | Control::Picture(_)
                        | Control::Equation(_)
                        | Control::Footnote(_)
                        | Control::Endnote(_)
                        | Control::AutoNumber(_)
                )
            })
            .count();
        (inline_before as u32).saturating_mul(8)
    } else {
        let char_pos = para.control_text_positions().get(control_index).copied()?;
        // 제어 문자가 텍스트 끝에 있으면 `char_offsets` 범위를 벗어나므로 마지막 글자
        // 바로 뒤로 잡는다.
        para.char_offsets
            .get(char_pos)
            .copied()
            .or_else(|| para.char_offsets.last().map(|last| last + 1))?
    };
    stored
        .iter()
        .rev()
        .find(|ls| para.line_seg_text_start_of(ls.text_start) <= anchor_u16)
        .map(|ls| ls.vertical_pos)
}

/// [#6860] 앵커 줄이 문단 첫 줄보다 아래일 때 그 **간격**(px).
///
/// `vertOffset` 의 기준점이 앵커 줄이므로 개체의 세로 원점도 그만큼 내려가야 한다.
/// 3067979 문단 1523: 앵커 줄1 이 첫 줄보다 1600HU(21.3px) 아래고, 정본도 캡션·표를
/// 딱 그만큼 아래에 그린다(정본 캡션 상단 = 둘째 줄 상단 + 16.2, 첫 괘선 = +29.7).
///
/// [`stored_host_lines_precede_float`] 이 참일 때만 돌려준다 — 그 게이트가 거짓이면
/// 호스트 줄이 개체 아래로 가는 형상이라 원점을 옮길 근거가 없다. 호스트가 한 줄이거나
/// 제어 문자가 첫 줄에 있으면 0 이므로 종전 배치가 그대로 보존된다.
pub(crate) fn stored_float_anchor_offset_px(
    para: &Paragraph,
    table: &crate::model::table::Table,
    control_index: usize,
    dpi: f64,
) -> f64 {
    hwpunit_to_px(
        stored_float_anchor_offset_hu(para, table, control_index),
        dpi,
    )
}

/// [#6860] 같은 값의 HWPUNIT 판 — 저장 사다리와 같은 축에서 견주는 호출부용.
///
/// `#6879`(typeset 의 `#5807` 판별식)는 TAC 줄 높이(HWPUNIT)와 직접 비교하므로 px 로
/// 내려갔다 오면 반올림이 섞인다.
pub(crate) fn stored_float_anchor_offset_hu(
    para: &Paragraph,
    table: &crate::model::table::Table,
    control_index: usize,
) -> i32 {
    if !stored_host_lines_precede_float(para, table, control_index) {
        return 0;
    }
    let stored: Vec<&crate::model::paragraph::LineSeg> = para
        .line_segs
        .iter()
        .filter(|ls| ls.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0)
        .collect();
    let Some(base) = stored.first().map(|ls| ls.vertical_pos) else {
        return 0;
    };
    let Some(anchor_top) = stored_float_anchor_line_top(para, control_index, &stored) else {
        return 0;
    };
    (anchor_top - base).max(0)
}

/// [#6879] 이 float 보다 **앞에** 줄을 차지하는 TAC 형제가 있는가.
///
/// `#6879` 가 앵커 줄 기준점을 조각 경로 밖(일반 배치·흐름 예약)까지 넓힌 형상은
/// "TAC 형제가 첫 줄을 차지하고 그 **뒤에** float 이 앵커된" 문단이다
/// (156767332 pi=73: ci=0 라벨 `tac=1` → ci=1 float).
///
/// 그 형제가 없으면 원점을 내릴 근거가 없다. 제어 문자가 여러 줄짜리 본문 **끝**에
/// 실린 평범한 문단도 앵커 줄이 마지막 줄로 잡히는데, 여기서 원점을 내리면
/// `#6718` 의 `vpos == 0` 되감김이 무효가 된다 — 27469 pi=23(표 하나 · `tac=false` ·
/// 형제 없음 · 제어 문자가 126자 끝 · 저장 줄 3개 spread 5280HU = 70.4px)에서
/// 4쪽 본문이 쪽 하한을 73.6px 넘었다.
///
/// 조각 경로(`#6860`)는 이 게이트를 쓰지 않는다 — 3067979 문단 1523 은 형제가 없어도
/// 앵커 줄 기준이 정본과 맞고, 그 경로는 `#6718` 되감김과 만나지 않는다.
pub(crate) fn has_line_taking_tac_sibling_before(para: &Paragraph, control_index: usize) -> bool {
    para.controls
        .iter()
        .take(control_index)
        .any(|ctrl| ctrl.is_treat_as_char_object())
}

/// [#6879] 일반 배치·흐름 예약이 쓰는 앵커 오프셋 — TAC 형제가 있을 때만 0 이 아니다.
///
/// 두 호출부가 같은 값을 봐야 배치와 예약이 어긋나지 않으므로 게이트를 여기 한 곳에
/// 둔다. 게이트가 거짓이면 종전(문단 상단 기준) 동작 그대로다.
pub(crate) fn tac_sibling_float_anchor_offset_px(
    para: &Paragraph,
    table: &crate::model::table::Table,
    control_index: usize,
    dpi: f64,
) -> f64 {
    if !has_line_taking_tac_sibling_before(para, control_index) {
        return 0.0;
    }
    stored_float_anchor_offset_px(para, table, control_index, dpi)
}

/// [#4610 · #4599 ④] 결재문서 템플릿의 공백-전용 TAC 캐리어 문단 페인트 변위.
///
/// 선행 문단이 앵커한 자리차지 표가 흐름 커서를 표 하단까지 밀어낸 뒤에 오는,
/// 공백 텍스트만으로 treat_as_char 표(문서번호란 등)를 실어 나르는 문단은 한글
/// 2022 가 첫 줄을 표 위 틈의 저장 vpos 위치에 그대로 둔다 (야간방호일지
/// 36374873 p1 pi4: 1×2 표 저장 vpos 13575 → y 256.6, 한글 PDF 실측 265.6 —
/// 종전 rhwp 는 1085 로 821px 하방). 저장 사다리가 문단 안에서 100px 이상의
/// 세그 간 간격(=저장 당시 레이아웃의 개체 밴드 증거)을 남긴 경우로 한정해
/// 렌더 y 만 저장 위치로 되돌린다 — 흐름 전진은 호출부가 보존한다. 낡은
/// 세대의 사다리(#4599 QUIET 47 의 문단 간격 누락류)는 문단-내 거대 간격을
/// 만들지 않으므로 이 게이트에 걸리지 않는다.
fn whitespace_tac_carrier_stored_paint_y(
    hwpx_stored_layout: bool,
    para: &Paragraph,
    composed: Option<&ComposedParagraph>,
    col_area_y: f64,
    flow_y: f64,
    dpi: f64,
) -> Option<f64> {
    if !hwpx_stored_layout || !para_has_visible_text(para) || para_has_non_whitespace_text(para) {
        return None;
    }
    // 컨트롤은 treat_as_char 표 1개뿐이어야 한다 — float host·그림/도형 문단 제외.
    let mut tac_tables = 0usize;
    for ctrl in &para.controls {
        match ctrl {
            Control::Table(t) if t.common.treat_as_char => tac_tables += 1,
            _ => return None,
        }
    }
    if tac_tables != 1 {
        return None;
    }
    let segs = &para.line_segs;
    if segs.len() < 2
        || segs
            .iter()
            .any(|s| s.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY != 0)
    {
        return None;
    }
    let (s0, s1) = (&segs[0], &segs[1]);
    if s0.vertical_pos < 0 {
        return None;
    }
    // 문단 내 저장 세그 간 간격 — 저장 당시 레이아웃의 개체 밴드 증거 (>100px).
    let intra_gap_hu = s1.vertical_pos as i64 - s0.vertical_pos as i64 - s0.line_height as i64;
    if intra_gap_hu < 7500 {
        return None;
    }
    // 실제 inline TAC 로 compose 되어 첫 줄에 타야 한다. 폭/줄 증거상 block 으로
    // 취급된 표는 저장 vpos 페인트 변위의 대상이 아니다.
    let comp = composed?;
    let (pos, _, _) = comp.tac_controls.first()?;
    // 공백 전용 문단이라 char/UTF-16 인덱스가 동일하다.
    // [#5961] 단 그 동일성은 두 값이 같은 축일 때만 성립한다 — `pos` 는 HWP5 축이므로
    // 저장 `text_start` 를 올려서 견준다.
    if *pos >= para.line_seg_text_start(1) as usize {
        return None;
    }
    let stored_y = col_area_y + hwpunit_to_px(s0.vertical_pos, dpi);
    let intra_gap_px = hwpunit_to_px(intra_gap_hu as i32, dpi);
    // 방향-한정: 흐름이 저장 위치보다 저장 간격 절반 이상 아래로 밀렸을 때만 되돌린다.
    if stored_y < col_area_y - 0.5 || flow_y - stored_y < intra_gap_px * 0.5 {
        return None;
    }
    Some(stored_y)
}

fn repeats_native_empty_host_rowbreak_fragment_margin(
    native_hwp5_layout: bool,
    paragraphs: &[Paragraph],
    para_index: usize,
    control_index: usize,
) -> bool {
    let Some(para) = paragraphs.get(para_index) else {
        return false;
    };
    let Some(Control::Table(table)) = para.controls.get(control_index) else {
        return false;
    };
    native_empty_host_rowbreak_line_advance_hu(
        native_hwp5_layout,
        para,
        table,
        paragraphs.get(para_index + 1),
    )
    .is_some()
}

/// [#4068] 앵커 문단이 저장 조판에서도 이 단을 시작하는지 — 구역 첫 문단이거나, 저장
/// 첫 줄 vpos 가 앞 문단 마지막 줄보다 위로 되감긴다(쪽·단 경계).
///
/// 앞 쪽 끝에 앵커된 표가 자리가 모자라 이 단 맨 위로 넘어온 경우(되감김 없음)는
/// 저장 세로 오프셋은 이전 단에 속한다. 새 단에서는 그 오프셋을 버리고 바깥 위 여백을
/// 적용한다. `정책연구용역사업 중간진도보고서` 24쪽 표(`pi=344`)가 해당한다.
fn stored_anchor_starts_column(paragraphs: &[Paragraph], para_index: usize) -> bool {
    let stored_seg = |paragraph: &Paragraph, last: bool| {
        let mut segs = paragraph.line_segs.iter().filter(|seg| {
            seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0
        });
        if last {
            segs.next_back().map(|seg| seg.vertical_pos)
        } else {
            segs.next().map(|seg| seg.vertical_pos)
        }
    };
    let Some(prev_index) = para_index.checked_sub(1) else {
        return true;
    };
    let (Some(host_vpos), Some(prev_vpos)) = (
        paragraphs
            .get(para_index)
            .and_then(|p| stored_seg(p, false)),
        paragraphs.get(prev_index).and_then(|p| stored_seg(p, true)),
    ) else {
        return false;
    };
    host_vpos < prev_vpos
}

/// Paint the first, unsplit form of the strict native-HWP empty-host RowBreak table at the
/// same top coordinate that `layout_partial_table` uses for its first fragment.  The ordinary
/// float lane intentionally omits outer margins (#2097); only callers that already proved the
/// narrow #2439 structural contract pass a non-zero `fragment_outer_top_px` here.
fn empty_host_float_raw_top(
    para_y: f64,
    vertical_offset_px: f64,
    fragment_outer_top_px: f64,
) -> f64 {
    (para_y + vertical_offset_px).max(para_y) + fragment_outer_top_px
}

/// [#7063] 글자 없는 자리차지 표 host 의 저장-vpos 후방 스냅을 흐름 커서로 되돌린다.
///
/// `vpos_adjust` 의 저장-vpos 스냅은 목적지에서 현재 문단의 `spacing_before` 를 미리
/// 빼고(#643), 뒤에서 그 문단을 조판할 때 다시 더해 상쇄한다. 그런데 **글자 없는
/// 자리차지 표 host** 는 조판할 글줄이 없어 그 재가산 경로를 타지 않는다(#7203). 그
/// 문단의 흐름 좌표(`para_y`)가 곧 표 윗변이 되는 이 갈래에서는 차감분이 그대로 남아
/// 표가 **앞 문단 마지막 줄 상자를 파고든다** — `hwpctl_API_v2.4` 60쪽 `pi=1465` 는 앞
/// 줄 상자 바닥 205.07 아래가 아니라 202.40 에 앉는다(`vpos_adjust` 의 ≤8px 후방 클램프는
/// 이 크기를 통과시킨다).
///
/// 한/글 정본은 이 자리에서 표 윗변을 **앞 줄 상자 바닥 + 줄간격 + 바깥여백 위**, 곧
/// 흐름 커서 + `outMargin.top` 에 둔다(정본 census 2문서 · `hwpctl_API_v2.4` 60쪽 잔차
/// 0.14px). 저장 vpos 자체는 정본보다 아래(+4.9px)라 사전 차감만 끄면 이번에는 그만큼
/// 과이동한다. 그래서 차감을 끄는 대신 **기준점을 흐름 커서로 되돌리고** 선언 바깥여백만
/// 얹는다.
///
/// 저장 사다리 증인(`native_empty_single_topbottom_table_saved_top`)이 있는 표는 이 앞
/// 갈래에서 이미 절대 좌표를 받으므로 여기 오지 않는다 — 같은 문서에서 그 갈래가 32건,
/// 이 갈래가 8건이고, 정본과 어긋나는 것은 이 갈래 쪽이다.
fn empty_float_vpos_snap_flow_top(
    para: &Paragraph,
    table: &crate::model::table::Table,
    para_y: f64,
    flow_snap_context: Option<(f64, f64)>,
    col_area: &LayoutRect,
    dpi: f64,
) -> Option<f64> {
    if !is_para_topbottom_float(&table.common) || para_has_visible_text(para) {
        return None;
    }
    // 세로 오프셋이 있는 표는 기준점이 흐름이 아니라 그 오프셋이다 — 별개 형상이다.
    if signed_hwpunit(table.common.vertical_offset) != 0 {
        return None;
    }
    let (flow_y_before_vpos_snap, prev_content_bottom_y) = flow_snap_context?;
    if !flow_y_before_vpos_snap.is_finite() || !prev_content_bottom_y.is_finite() {
        return None;
    }
    // 단 상단에서 시작하는 조각은 이 축의 결함이 없다(정본 13/13 일치). 스냅이 흐름을
    // 끌어올린 **단 중간** 배치만 본다.
    if para_y <= col_area.y + 0.5 || flow_y_before_vpos_snap <= para_y + 0.05 {
        return None;
    }
    // ⚠ 발동 조건은 스냅의 방향이 아니라 **결함의 관측 형태**다 — 표 윗변이 직전
    // 아이템의 줄 상자 바닥보다 위에 앉는 경우만이다(정본 없이 render tree 로 판정
    // 된다). 스냅이 표를 끌어올려도 앞 줄 아래에 남는 자리는 종전 좌표가 맞는다
    // (`hwpspec.hwp` 30쪽 `pi=179`: 앞 줄 바닥 699.70 · 표 701.10 — 여기서 흐름으로
    // 되돌리면 +10.4px 밀려 뒤 내용과 겹친다).
    if para_y >= prev_content_bottom_y - 0.05 {
        return None;
    }
    Some(flow_y_before_vpos_snap + hwpunit_to_px(table.outer_margin_top as i32, dpi).max(0.0))
}

fn para_line_spacing_px(para: &Paragraph, dpi: f64) -> f64 {
    para.line_segs
        .last()
        .filter(|seg| seg.line_spacing > 0)
        .map(|seg| hwpunit_to_px(seg.line_spacing, dpi))
        .unwrap_or(0.0)
}

fn has_following_non_positive_visible_float(para: &Paragraph, control_index: usize) -> bool {
    para.controls
        .iter()
        .skip(control_index + 1)
        .any(|ctrl| match ctrl {
            Control::Table(table) => {
                is_para_topbottom_float(&table.common)
                    && signed_hwpunit(table.common.vertical_offset) <= 0
            }
            _ => false,
        })
}

fn para_has_visible_inline_control(para: &Paragraph) -> bool {
    para.controls.iter().any(|ctrl| match ctrl {
        Control::Picture(pic) => pic.common.treat_as_char,
        Control::Shape(shape) => shape.common().treat_as_char,
        Control::Table(table) => table.common.treat_as_char,
        Control::Equation(eq) => eq.common.treat_as_char,
        Control::Form(form) => form.common.treat_as_char,
        _ => false,
    })
}

/// [#6134] `control_index` 앞에 놓인 같은 문단의 비-TAC 자리차지(TopAndBottom) 개체가
/// 차지하는 밴드 높이(px, 바깥 아래 여백 포함).
///
/// 한글은 자리차지 개체를 문단 글줄 **위**에 놓는다 — 그래서 그 문단의 글줄은 밴드
/// 아래로 내려가고, 저장 lineseg 의 vpos 도 그 자리를 가리킨다. 같은 문단에 매달린
/// 다른 개체가 "문단 기준" 세로 오프셋을 쓰면 그 기준점은 문단 상단(=밴드 상단)이
/// 아니라 **그 글줄**이다. rhwp 는 문단 상단으로 잡아 로고 글상자를 담당부서 표
/// 위에 얹었다(156731730 8쪽: 로고 y 765.1, 한글 1010.7 — 표 753.7~993.0 위).
///
/// 밴드 자신(=`control_index` 이하)은 제외한다 — 자기 기준점은 문단 상단이 맞다.
///
/// 대상은 **글앞으로/글뒤로 개체**로 한정한다. 자리차지 개체끼리의 세로 쌓기는 이미
/// 자기 계약(#2097 가로-컬럼 모델)이 있어 여기서 다시 더하면 이중 계상이고, 어울림
/// (Square)은 본문 흐름과 함께 배치되는 별개 축이다.
fn preceding_topbottom_band_height_px(para: &Paragraph, control_index: usize, dpi: f64) -> f64 {
    use crate::model::shape::TextWrap;
    let current_is_overlay = para
        .controls
        .get(control_index)
        .and_then(|ctrl| match ctrl {
            Control::Table(table) => Some(&table.common),
            Control::Picture(picture) => Some(&picture.common),
            Control::Shape(shape) => Some(shape.common()),
            _ => None,
        })
        .is_some_and(|common| {
            !common.treat_as_char
                && matches!(
                    common.text_wrap,
                    TextWrap::InFrontOfText | TextWrap::BehindText
                )
                && matches!(common.vert_rel_to, crate::model::shape::VertRelTo::Para)
        });
    if !current_is_overlay {
        return 0.0;
    }
    para.controls
        .iter()
        .take(control_index)
        .filter_map(|ctrl| match ctrl {
            Control::Table(table) => Some(&table.common),
            Control::Picture(picture) => Some(&picture.common),
            Control::Shape(shape) => Some(shape.common()),
            _ => None,
        })
        .filter(|common| is_para_topbottom_float(common))
        .map(|common| {
            hwpunit_to_px(common.height as i32, dpi)
                + hwpunit_to_px(i32::from(common.margin.bottom), dpi)
        })
        .sum()
}

/// [#6133] `control_index` 앞에 놓인 비-TAC 자리차지(TopAndBottom, vert=문단) 개체의
/// 양수 세로 오프셋이 host 글줄 높이 이상인가.
fn host_line_fits_above_offset_float(para: &Paragraph, control_index: usize, dpi: f64) -> bool {
    let Some(line_height) = para
        .line_segs
        .iter()
        .find(|seg| seg.tag & 0x8000_0000 == 0 && seg.line_height > 0)
        .map(|seg| hwpunit_to_px(seg.line_height, dpi))
    else {
        return false;
    };
    para.controls
        .iter()
        .take(control_index)
        .filter_map(|ctrl| match ctrl {
            Control::Table(table) => Some(&table.common),
            Control::Picture(picture) => Some(&picture.common),
            Control::Shape(shape) => Some(shape.common()),
            _ => None,
        })
        .filter(|common| is_para_topbottom_float(common))
        .any(|common| {
            hwpunit_to_px(signed_hwpunit(common.vertical_offset), dpi) >= line_height - 0.5
        })
}

fn para_is_empty_topbottom_table_anchor(para: &Paragraph) -> bool {
    !para_has_visible_text(para)
        && para
            .controls
            .iter()
            .any(|ctrl| matches!(ctrl, Control::Table(t) if is_para_topbottom_float(&t.common)))
}

/// 이 단에 이미 그려진 흐름 글자의 최하단 y — 없으면 `None`.
///
/// 저장 사다리의 음수 줄간격(`line_spacing < 0`)은 줄 상자를 글자보다 좁게 만든다.
/// 흐름 커서는 그 좁은 상자만 전진하므로, 뒤따르는 표가 이미 그려진 글자를 물 수
/// 있다. 그때 하한으로 쓴다. 개체(그림·도형·글상자)는 절대 좌표라 흐름 하한이 될
/// 수 없어 하위 노드까지 건너뛴다.
fn painted_flow_text_bottom(node: &RenderNode) -> Option<f64> {
    fn walk(node: &RenderNode, out: &mut f64) {
        match &node.node_type {
            RenderNodeType::Image(_)
            | RenderNodeType::Rectangle(_)
            | RenderNodeType::Ellipse(_)
            | RenderNodeType::Path(_)
            | RenderNodeType::Group(_)
            | RenderNodeType::TextBox
            // A table/cell owns its own measured flow. Its text is not a
            // preceding body paragraph, even when it paints beyond the box.
            | RenderNodeType::Table(_)
            | RenderNodeType::TableCell(_) => return,
            RenderNodeType::TextRun(_) => {
                *out = out.max(node.bbox.y + node.bbox.height);
            }
            _ => {}
        }
        for child in &node.children {
            walk(child, out);
        }
    }
    let mut bottom = f64::NEG_INFINITY;
    walk(node, &mut bottom);
    bottom.is_finite().then_some(bottom)
}

#[cfg(test)]
mod painted_flow_text_bottom_owner106_tests {
    use super::{painted_flow_text_bottom, CellContext, CellPathEntry};
    use crate::renderer::{
        render_tree::{
            BoundingBox, CaptionControlKind, CaptionOwner, FieldMarkerType, RenderNode,
            RenderNodeType, TableCellNode, TableNode, TextLineNode, TextRunNode,
        },
        TextStyle,
    };

    fn ink(y: f64, height: f64) -> RenderNode {
        RenderNode::new(
            2,
            RenderNodeType::TextRun(TextRunNode {
                text: "OWN".into(),
                style: TextStyle::default(),
                char_shape_id: Some(0),
                para_shape_id: Some(0),
                section_index: Some(0),
                para_index: Some(0),
                char_start: Some(0),
                cell_context: None,
                is_para_end: true,
                is_line_break_end: false,
                rotation: 0.0,
                is_vertical: false,
                char_overlap: None,
                border_fill_id: 0,
                baseline: height,
                field_marker: FieldMarkerType::None,
                layout_positions: None,
                display_text: None,
            }),
            BoundingBox::new(0.0, y, 5.0, height),
        )
    }

    fn owner(kind: RenderNodeType, child: RenderNode) -> RenderNode {
        let mut node = RenderNode::new(1, kind, BoundingBox::new(0.0, 0.0, 5.0, 5.0));
        node.children.push(child);
        node
    }

    fn body(child: RenderNode) -> RenderNode {
        owner(RenderNodeType::Column(0), child)
    }

    fn table(child: RenderNode) -> RenderNode {
        owner(
            RenderNodeType::Table(TableNode {
                row_count: 1,
                col_count: 1,
                border_fill_id: 0,
                section_index: Some(0),
                para_index: Some(0),
                control_index: Some(0),
                cell_context: None,
            }),
            child,
        )
    }

    fn cell(child: RenderNode) -> RenderNode {
        owner(
            RenderNodeType::TableCell(TableCellNode {
                col: 0,
                row: 0,
                col_span: 1,
                row_span: 1,
                border_fill_id: 0,
                text_direction: 0,
                clip: false,
                page_fragment: false,
                model_cell_index: Some(0),
            }),
            child,
        )
    }

    #[test]
    fn negative_spacing_body_ink_remains_the_flow_floor() {
        // A narrow line box must not hide glyph ink from a following table.
        let tree = body(owner(
            RenderNodeType::TextLine(TextLineNode::new(5.0, 4.0)),
            ink(0.0, 20.0),
        ));
        assert_eq!(painted_flow_text_bottom(&tree), Some(20.0));
    }

    #[test]
    fn table_cell_text_is_not_body_flow() {
        let tree = body(table(cell(ink(200.0, 20.0))));
        assert_eq!(painted_flow_text_bottom(&tree), None);
    }

    #[test]
    fn standalone_cell_text_is_not_body_flow() {
        let tree = body(cell(ink(200.0, 20.0)));
        assert_eq!(painted_flow_text_bottom(&tree), None);
    }

    #[test]
    fn nested_table_cell_text_is_not_body_flow() {
        let tree = body(table(cell(table(cell(ink(200.0, 20.0))))));
        assert_eq!(painted_flow_text_bottom(&tree), None);
    }

    #[test]
    fn sibling_caption_keeps_its_existing_flow_floor_behavior() {
        // layout_table emits the Table and caption TextLine as Column siblings.
        // The two subtree exclusions deliberately do not change caption handling.
        let mut line = TextLineNode::new(5.0, 4.0);
        line.caption_owner = CaptionOwner::new(
            Some(0),
            Some(0),
            Some(0),
            CaptionControlKind::Table,
        );
        let mut caption_ink = ink(200.0, 20.0);
        if let RenderNodeType::TextRun(run) = &mut caption_ink.node_type {
            run.cell_context = Some(CellContext {
                in_textbox: false,
                parent_para_index: 0,
                path: vec![CellPathEntry {
                    control_index: 0,
                    cell_index: 65534,
                    cell_para_index: 0,
                    text_direction: 0,
                }],
            });
        }
        let mut tree = body(table(cell(ink(2000.0, 500.0))));
        tree.children
            .push(owner(RenderNodeType::TextLine(line), caption_ink));
        assert_eq!(painted_flow_text_bottom(&tree), Some(220.0));
    }

    #[test]
    fn textbox_exclusion_is_preserved() {
        let tree = body(owner(RenderNodeType::TextBox, ink(200.0, 20.0)));
        assert_eq!(painted_flow_text_bottom(&tree), None);
    }

    #[test]
    fn overflowing_cell_does_not_replace_preceding_body_ink() {
        let mut tree = body(ink(10.0, 20.0));
        tree.children.push(table(cell(ink(2000.0, 500.0))));
        assert_eq!(painted_flow_text_bottom(&tree), Some(30.0));
    }

    #[test]
    fn body_after_table_still_owns_its_ink() {
        let mut tree = body(table(cell(ink(2000.0, 500.0))));
        tree.children.push(ink(60.0, 20.0));
        assert_eq!(painted_flow_text_bottom(&tree), Some(80.0));
    }
}


/// 빈 host 문단에 Para-relative Square 표 두 개가 함께 저장된 경우는 세로 block
/// 두 개가 아니라 동일한 HWP 페이지 좌표의 가로 lane이다. 이 형상은 HWP5의
/// `LINE_SEG`가 두 표의 공통 상단을 보존하므로, 일반 Square 본문-wrap과 분리한다.
fn para_is_empty_square_sibling_table_anchor(para: &Paragraph) -> bool {
    !para_has_visible_text(para)
        && para
            .controls
            .iter()
            .filter(|ctrl| {
                matches!(ctrl,
                    Control::Table(table)
                        if !table.common.treat_as_char
                            && matches!(table.common.text_wrap, TextWrap::Square)
                            && matches!(table.common.vert_rel_to, VertRelTo::Para)
                )
            })
            .take(2)
            .count()
            >= 2
}

/// sibling Square 표의 저장 anchor를 SVG 페이지 좌표로 변환한다. 이 HWP5 형상은
/// page base를 빼는 상대 ladder가 아니라 raw `vertical_pos`가 물리 페이지 위치다.
fn empty_square_sibling_table_saved_top(
    para: &Paragraph,
    col_area: &LayoutRect,
    dpi: f64,
) -> Option<f64> {
    if !para_is_empty_square_sibling_table_anchor(para) {
        return None;
    }
    let seg = para
        .line_segs
        .iter()
        .find(|seg| seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0)?;
    let top = col_area.y + hwpunit_to_px(seg.vertical_pos, dpi);
    (top >= col_area.y && top <= col_area.y + col_area.height).then_some(top)
}

/// empty-host TopAndBottom 그림 표 또는 신뢰 가능한 1×1 표가 native HWP의 raw page vpos와 선언 높이로
/// 현재 본문 안에 완전히 들어가는 경우의 paint anchor. `TopAndBottom`만으로는
/// CellBreak/RowBreak 데이터 표도 포함하므로, 일반 block/partial-table 분할을 우회할 수
/// 있는 이 특례는 그림을 담은 1×1, 그림+caption 2×1, 또는 실측 높이를 신뢰할 수 있는
/// 단순 1×1 RowBreak 표에만 적용한다.
fn is_single_noninline_picture_table(table: &crate::model::table::Table) -> bool {
    if table.common.treat_as_char
        || table.row_count != 1
        || table.col_count != 1
        || table.cells.len() != 1
        || !matches!(table.page_break, TablePageBreak::RowBreak)
    {
        return false;
    }

    let Some(cell) = table.cells.first() else {
        return false;
    };
    cell.row == 0
        && cell.col == 0
        && cell.row_span == 1
        && cell.col_span == 1
        && cell.paragraphs.len() == 1
        && cell.paragraphs.first().is_some_and(|cell_para| {
            cell_para.text.trim().is_empty()
                && cell_para.controls.len() == 1
                && matches!(
                    cell_para.controls.first(),
                    Some(Control::Picture(picture)) if !picture.common.treat_as_char
                )
        })
}

fn is_two_row_picture_caption_rowbreak_table(table: &crate::model::table::Table) -> bool {
    if table.row_count != 2
        || table.col_count != 1
        || table.cells.len() != 2
        || table
            .cells
            .iter()
            .any(|cell| cell.col != 0 || cell.row > 1 || cell.row_span != 1 || cell.col_span != 1)
    {
        return false;
    }

    let has_illustration = table.cells.iter().any(|cell| {
        cell.row == 0
            && cell.paragraphs.iter().any(|para| {
                // 표 자체가 비-TAC TopAndBottom float이면, 셀 내부의 도형/그림은
                // 글자처럼 취급돼도 그림 행의 paint 하단을 구성한다. 이 case를
                // 제외하면 묶음 Shape 다이어그램의 caption만 다음 본문과 겹친다.
                para.controls
                    .iter()
                    .any(|control| matches!(control, Control::Picture(_) | Control::Shape(_)))
            })
    });
    let has_caption_text = table
        .cells
        .iter()
        .any(|cell| cell.row == 1 && cell.paragraphs.iter().any(para_has_visible_text));
    has_illustration && has_caption_text
}

/// 일반 RowBreak 데이터 표가 raw page anchor 특례를 타지 않도록, 저장 좌표를
/// 신뢰할 수 있는 그림 표 구조만 통과시킨다.
fn is_stored_anchor_picture_table(table: &crate::model::table::Table) -> bool {
    !table.common.treat_as_char
        && matches!(table.page_break, TablePageBreak::RowBreak)
        && (is_single_noninline_picture_table(table)
            || is_two_row_picture_caption_rowbreak_table(table))
}

/// 그림이 아닌 1×1 RowBreak 표도 실측 높이가 선언 객체 높이와 같은 범위면 한컴의
/// empty-host raw anchor를 따른다. 셀 내용이 크게 팽창한 표는 일반 fragment 경로로
/// 보내야 하므로, 선언 높이의 1.5배 이내만 허용한다.
fn is_single_rowbreak_table_with_trustworthy_declared_height(
    table: &crate::model::table::Table,
    effective_height: Option<f64>,
    dpi: f64,
) -> bool {
    if table.common.treat_as_char
        || table.row_count != 1
        || table.col_count != 1
        || table.cells.len() != 1
        || !matches!(table.page_break, TablePageBreak::RowBreak)
    {
        return false;
    }

    let Some(cell) = table.cells.first() else {
        return false;
    };
    if cell.row != 0 || cell.col != 0 || cell.row_span != 1 || cell.col_span != 1 {
        return false;
    }

    let declared_height = hwpunit_to_px(table.common.height as i32, dpi).max(0.0);
    declared_height > 0.0
        && effective_height
            .is_some_and(|height| height <= declared_height * SINGLE_ROW_DECLARED_TRUST_MAX_RATIO)
}

// [#7203] `stored_topbottom_object_span` · `stored_ladder_leaves_object_room` 은
// `renderer::stored_float_anchor` 가 정본이다 — 조판(typeset)과 렌더가 같은 값을 쓴다.
use crate::renderer::stored_float_anchor::{
    stored_ladder_leaves_object_room, stored_single_topbottom_top_px,
    stored_topbottom_flow_advance_hu, stored_topbottom_object_span,
};

/// empty-host TopAndBottom 그림 표가 native HWP의 raw page vpos와 선언 높이로
/// 현재 본문 안에 완전히 들어가는 경우의 paint anchor.
fn native_empty_single_topbottom_table_saved_top(
    native_hwp5_layout: bool,
    para: &Paragraph,
    next_para: Option<&Paragraph>,
    table: &crate::model::table::Table,
    effective_height: Option<f64>,
    col_area: &LayoutRect,
    dpi: f64,
) -> Option<f64> {
    if !native_hwp5_layout
        || para_has_visible_text(para)
        || !is_para_topbottom_float(&table.common)
        || !(is_stored_anchor_picture_table(table)
            || is_single_rowbreak_table_with_trustworthy_declared_height(
                table,
                effective_height,
                dpi,
            ))
        || para
            .controls
            .iter()
            .filter(|control| matches!(control, Control::Table(_)))
            .count()
            != 1
    {
        return None;
    }
    // [#7203] 원점·수용 조건은 `stored_float_anchor` 한 곳이 정한다. 종전에는 여기와
    // typeset 이 각자 판정해, 같은 표를 두고 렌더는 저장 앵커를 쓰고 조판은 안 쓰는
    // 구간이 생겼다.
    stored_single_topbottom_top_px(para, next_para, table, col_area.height, dpi)
        .map(|top| col_area.y + top)
}

/// [#6032] 직전 문단에서 저장 vpos가 **되감기면** 이 빈-host 자리차지 표는 한글이
/// 새 쪽 첫 흐름 anchor로 배치한 개체다 (직전 쪽 말미 anchor의 표가 다음 쪽으로
/// 흘러넘친 뒤). 한글은 넘친 표 아래 흐름을 outer margin만큼만 전진시키는 반면
/// rhwp 흐름은 host 줄 간격까지 계상해 소폭 아래로 표류하고, 그 위에
/// `vertical_offset`이 다시 얹혀 표 하단 괘선이 다음 문단 글줄을 관통한다
/// (2912695 p2 "작성요령" 표 +6.1pt). 흐름이 저장 anchor 근방일 때만 저장 vpos로
/// host y를 되감는다 — 큰 격차는 pagination 자체가 다른 경우라 손대지 않는다.
fn native_empty_topbottom_rewind_anchor_saved_para_y(
    native_hwp5_layout: bool,
    prev_para: Option<&Paragraph>,
    para: &Paragraph,
    next_para: Option<&Paragraph>,
    table: &crate::model::table::Table,
    flow_para_y: f64,
    col_area: &LayoutRect,
    dpi: f64,
) -> Option<f64> {
    const MAX_REWIND_DRIFT_PX: f64 = 24.0;
    if !native_hwp5_layout
        || para_has_visible_text(para)
        || !is_para_topbottom_float(&table.common)
        || !matches!(
            table.common.vert_rel_to,
            crate::model::shape::VertRelTo::Para
        )
        || para
            .controls
            .iter()
            .filter(|control| matches!(control, Control::Table(_)))
            .count()
            != 1
    {
        return None;
    }
    let stored_vpos = |paragraph: &Paragraph| {
        paragraph
            .line_segs
            .iter()
            .rev()
            .find(|seg| {
                seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0
            })
            .map(|seg| seg.vertical_pos)
    };
    let host_vpos = stored_vpos(para)?;
    let prev_vpos = stored_vpos(prev_para?)?;
    let next_vpos = stored_vpos(next_para?)?;
    // 되감김(쪽 경계 신호) + 다음 문단이 같은 쪽에서 host 아래로 이어지는지 확인 —
    // 이 두 조건이 host vpos가 새 쪽의 page-relative 좌표임을 뒷받침한다.
    if host_vpos <= 0 || host_vpos >= prev_vpos || next_vpos <= host_vpos {
        return None;
    }
    let saved_para_y = col_area.y + hwpunit_to_px(host_vpos, dpi);
    let drift = flow_para_y - saved_para_y;
    if !(0.0 < drift && drift <= MAX_REWIND_DRIFT_PX) {
        return None;
    }
    let v_off = hwpunit_to_px(signed_hwpunit(table.common.vertical_offset), dpi).max(0.0);
    let bottom = saved_para_y + v_off + hwpunit_to_px(table.common.height as i32, dpi);
    (bottom <= col_area.y + col_area.height + 0.5).then_some(saved_para_y)
}

/// native HWP5의 빈-host 1×1 RowBreak 표에서 cell paragraph 경계를 넘는 저장
/// vpos reset은 첫 fragment의 raw page anchor를 명시한다. cell 전체 실측 높이는
/// reset 뒤 continuation까지 합산하므로, 일반 y cursor로 그리면 첫 fragment가
/// 기존 각주 아래로 밀린다. typeset이 이 형상만 fragment scan으로 보낸 뒤, layout도
/// 같은 anchor에서 첫 조각을 paint해야 페이지네이터/렌더러 좌표가 일치한다.
pub(crate) fn native_hwp5_internal_reset_rowbreak_first_fragment_saved_top(
    native_hwp5_layout: bool,
    para: &Paragraph,
    prev_para: Option<&Paragraph>,
    next_para: Option<&Paragraph>,
    table: &crate::model::table::Table,
    col_area: &LayoutRect,
    dpi: f64,
) -> Option<f64> {
    if !native_hwp5_layout
        || para_has_visible_text(para)
        || !is_para_topbottom_float(&table.common)
        || table.common.treat_as_char
        || table.row_count != 1
        || table.col_count != 1
        || table.cells.len() != 1
        || !matches!(table.page_break, TablePageBreak::RowBreak)
        || para
            .controls
            .iter()
            .filter(|control| matches!(control, Control::Table(_)))
            .count()
            != 1
    {
        return None;
    }

    let host_seg = para
        .line_segs
        .iter()
        .find(|seg| seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0)?;
    let next_seg = next_para?
        .line_segs
        .iter()
        .find(|seg| seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0)?;
    // 후속 source가 위로 되감겨야 cell reset tail이 다음 physical page에 속한다.
    if next_seg.vertical_pos >= host_seg.vertical_pos {
        return None;
    }

    let mut previous_vpos = None;
    let mut has_internal_reset = false;
    for cell_para in &table.cells[0].paragraphs {
        for seg in cell_para.line_segs.iter().filter(|seg| {
            seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0
        }) {
            if previous_vpos.is_some_and(|previous| previous > 0 && seg.vertical_pos <= 0) {
                has_internal_reset = true;
                break;
            }
            previous_vpos = Some(seg.vertical_pos);
        }
        if has_internal_reset {
            break;
        }
    }
    if !has_internal_reset {
        return None;
    }

    // [#7203] 앵커의 **저장 줄** vpos 가 아니라 **문단 상자 top** 에 건다.
    //
    // 자리차지 개체의 세로 기준은 문단 상단이고, 문단 간격(`spacing_before`)은 그 개체가
    // 아니라 뒤따르는 **줄**에 붙는다. 저장 줄 vpos 는 그 간격을 이미 지난 자리라, 그대로
    // 쓰면 조각이 간격만큼 아래로 내려간다. 같은 파일 계열의 그림 경로는 이미 이 규칙이다
    // (`float_placement.rs` 의 `anchor_y = host_y - spacing_before`).
    //
    // 한/글 정본 실측(`pdf/hwpctl_API_v2.4-hwp-2020.pdf`, 자리차지 표 44곳): 표 윗변은
    // `앞 문단 마지막 줄 바닥 + outer_margin_top` 한 값이며 앵커의 `spacing_before` 와
    // 무관하다. 간격이 0 인 문단은 이 보정이 no-op 이므로 종전 좌표가 그대로 유지된다.
    let leading_gap_hu = prev_para
        .and_then(|prev| {
            prev.line_segs
                .iter()
                .rev()
                .find(|seg| {
                    seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0
                })
                .map(|seg| {
                    seg.vertical_pos
                        .saturating_add(seg.line_height)
                        .saturating_add(seg.line_spacing.max(0))
                })
        })
        .map(|prev_bottom| host_seg.vertical_pos.saturating_sub(prev_bottom).max(0))
        .unwrap_or(0);
    let top = col_area.y + hwpunit_to_px(host_seg.vertical_pos - leading_gap_hu, dpi);
    let bottom = top + hwpunit_to_px(table.common.height as i32, dpi);
    (top >= col_area.y + col_area.height * 0.5 && bottom <= col_area.y + col_area.height + 0.5)
        .then_some(top)
}

/// native HWP5와 original HWPX에서 페이지를 넘긴 빈 RowBreak 그림 표는 저장된 cell height가 그 페이지의
/// 실제 그림+caption flow보다 크게 남을 수 있다. 표 frame은 원본을 보존한 채, 뒤의
/// 문단은 다음 저장 LINE_SEG anchor부터 재개해야 하는 형상만 골라 그 flow cursor를
/// 반환한다.
fn stored_layout_relocated_empty_rowbreak_picture_next_flow_top(
    stored_layout: bool,
    host_para: &Paragraph,
    table: &crate::model::table::Table,
    next_para: Option<&Paragraph>,
    col_area: &LayoutRect,
    dpi: f64,
) -> Option<f64> {
    if !stored_layout
        || para_has_visible_text(host_para)
        || host_para.controls.len() != 1
        || table.row_count != 1
        || table.col_count != 1
        || table.cells.len() != 1
        || !matches!(table.page_break, TablePageBreak::RowBreak)
        || !is_para_topbottom_float(&table.common)
        || !matches!(table.common.vert_rel_to, VertRelTo::Para)
    {
        return None;
    }
    let host_seg = host_para
        .line_segs
        .iter()
        .find(|seg| seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0)?;
    let next_seg = next_para?
        .line_segs
        .iter()
        .find(|seg| seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0)?;
    if host_seg.vertical_pos <= 0
        || next_seg.vertical_pos <= 0
        || next_seg.vertical_pos >= host_seg.vertical_pos
    {
        return None;
    }

    let cell = table.cells.first()?;
    if cell.row != 0
        || cell.col != 0
        || cell.row_span != 1
        || cell.col_span != 1
        || cell.height <= table.common.height
        || cell.paragraphs.len() != 1
    {
        return None;
    }
    let cell_para = cell.paragraphs.first()?;
    let cell_seg = cell_para
        .line_segs
        .iter()
        .find(|seg| seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0)?;
    let Control::Picture(picture) = cell_para.controls.first()? else {
        return None;
    };
    if !cell_para.text.trim().is_empty()
        || cell_para.controls.len() != 1
        || cell_para.line_segs.len() != 1
        || cell_seg.vertical_pos != 0
        || picture.common.treat_as_char
        || !picture.common.flow_with_text
        || !matches!(picture.common.text_wrap, TextWrap::TopAndBottom)
        || !matches!(picture.common.vert_rel_to, VertRelTo::Para)
        || !picture.caption.as_ref().is_some_and(|caption| {
            matches!(caption.direction, CaptionDirection::Bottom) && !caption.paragraphs.is_empty()
        })
    {
        return None;
    }

    let boundary_sum = i64::from(host_seg.vertical_pos)
        + i64::from(signed_hwpunit(table.common.vertical_offset))
        + i64::from(signed_hwpunit(picture.common.vertical_offset));
    if boundary_sum.abs() > 8 {
        return None;
    }

    let top = col_area.y + hwpunit_to_px(next_seg.vertical_pos, dpi);
    (top >= col_area.y && top <= col_area.y + col_area.height).then_some(top)
}

/// HWP5의 본문 포함 TopAndBottom 표 중, 여러 저장 줄보다 **짧은** 양수
/// `vertical_offset`을 가진 형상은 offset의 기준이 host 본문 끝이다. 이를 para
/// 시작점에만 더하면 그림이 아직 그려지는 본문 위에 놓인다 (1351000 p13).
///
/// 반대로 offset이 host 저장 높이 이상이면 이미 host 본문 아래를 가리키므로,
/// 이를 한 번 더 본문 끝에 가산하면 표가 한 문단 높이만큼 아래로 밀린다
/// (정책연구용역… HWP/HWPX p9, pi=222). 따라서 그 경우는 일반 Para anchor
/// 경로에 맡긴다.
/// [#6614] 문단 **끝**에 오는 비인라인 TAC 표가 저장 사다리에서 **자기 줄**을 받았으면
/// 그 줄 상단에 앉힌다.
///
/// 폭이 줄 폭과 같아 `is_tac_table_inline_in_para` 가 인라인을 거부한 TAC 표는
/// `table_y_start` 사슬의 마지막 `else { y_offset }` 로 떨어져 **문단 흐름 시작**에
/// 놓인다. 문단 첫 줄보다 위다. 그래서 표가 본문 위에 겹쳐 그려진다.
///
/// 실측 — `156658611` 1쪽 담당부서 표(px @96dpi, 오라클 한/글 2020):
///
/// ```text
/// 저장 사다리  seg0..3 vpos 53839/56359/58879/61399  lh 1400/1400/1400/1500  ← 글자 줄
///              seg4    vpos 69067                    lh 3696                 ← 표 줄
/// 표           height 3130 + om_top 283 + om_bottom 283 = 3696  ← seg4 와 정확히 일치
/// rhwp 770.8 (문단 흐름 시작) vs 한/글 약 1005 — 234px 위
/// ```
///
/// 밴드(`om_top + 선언높이 + om_bottom`)가 저장 줄 높이와 일치하는 것이 판별자다
/// (#5729 가 인라인 경로에 쓰는 것과 같은 계약).
///
/// ⚠ **우연 일치를 막는 가드가 필요하다.** 소형 TAC 표는 밴드가 글자 줄 높이와
/// 우연히 같을 수 있다(`is_tac_table_inline_in_para` 의 `own_line_evidence` 가 같은
/// 이유로 전면급 30000HU 로 한정한다). 여기서는 크기 대신
/// **① 표가 문단의 유일한 TAC 표 ② 맞는 줄이 마지막 줄 ③ 그 줄이 글자 줄보다
/// 1.5배 이상 높다 ④ 흐름보다 아래 ⑤ 단 안에 들어감** 다섯으로 좁힌다.
fn tac_paragraph_tail_stored_line_top(
    stored_layout: bool,
    has_receipt_filler: bool,
    para: &Paragraph,
    table: &crate::model::table::Table,
    col_area: &LayoutRect,
    rendered_host_origin: Option<f64>,
    flow_y: f64,
    dpi: f64,
) -> Option<f64> {
    // 접수증 필러(`tac_receipt_filler_prefix`)가 있는 문단은 #2020 이 "필러 줄 다음
    // line-seg" 라는 자기 계약을 갖는다(복학원서). 그 축을 건드리지 않는다.
    if !stored_layout
        || has_receipt_filler
        || !table.common.treat_as_char
        || (!para_has_visible_text(para) && rendered_host_origin.is_none())
    {
        return None;
    }
    // ① 이 문단의 유일한 TAC 표일 때만 — 여럿이면 어느 줄이 어느 표인지 모른다.
    if para
        .controls
        .iter()
        .filter(|c| matches!(c, Control::Table(t) if t.common.treat_as_char))
        .count()
        != 1
    {
        return None;
    }
    let stored: Vec<_> = para
        .line_segs
        .iter()
        .filter(|seg| seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0)
        .collect();
    if stored.len() < 2 {
        return None;
    }
    // ② 표 줄은 마지막 줄이어야 한다(문단 끝의 표).
    let last = stored.last()?;
    let band_hu = table.common.height as i64
        + table.outer_margin_top as i64
        + table.outer_margin_bottom as i64;
    if (last.line_height as i64 - band_hu).abs() > 75 {
        return None;
    }
    // ③ 글자 줄보다 확실히 높아야 한다(우연 일치 배제).
    let text_line_max = stored[..stored.len() - 1]
        .iter()
        .map(|seg| seg.line_height as i64)
        .max()
        .unwrap_or(0);
    if text_line_max <= 0 || (last.line_height as i64) * 2 < text_line_max * 3 {
        return None;
    }
    // A prefix already laid out in this column establishes the paragraph's
    // local origin. Preserve the saved distance between its rows, rather than
    // reintroducing an absolute section vpos after editing or flow placement.
    let line_top = rendered_host_origin
        .map(|origin| {
            origin
                + hwpunit_to_px(
                    last.vertical_pos.saturating_sub(stored[0].vertical_pos),
                    dpi,
                )
        })
        .unwrap_or_else(|| col_area.y + hwpunit_to_px(last.vertical_pos, dpi));
    let top = line_top + hwpunit_to_px(table.outer_margin_top as i32, dpi);
    // ④ 흐름보다 위로 올리지 않는다. ⑤ 단을 넘지 않는다.
    if top < flow_y - 0.5
        || top + hwpunit_to_px(table.common.height as i32, dpi) > col_area.y + col_area.height + 1.0
    {
        return None;
    }
    Some(top)
}

fn native_multiline_visible_float_table_top(
    native_hwp5_layout: bool,
    para: &Paragraph,
    table: &crate::model::table::Table,
    para_y: f64,
    dpi: f64,
) -> Option<f64> {
    if !native_hwp5_layout
        || !is_para_topbottom_float(&table.common)
        || !para_has_visible_text(para)
        || signed_hwpunit(table.common.vertical_offset) <= 0
        || para
            .controls
            .iter()
            .filter(|control| matches!(control, Control::Table(_)))
            .count()
            != 1
    {
        return None;
    }
    let stored: Vec<_> = para
        .line_segs
        .iter()
        .filter(|seg| seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0)
        .collect();
    if stored.len() < 3 {
        return None;
    }
    let first = stored.first()?;
    let last = stored.last()?;
    let host_height_hu = last
        .vertical_pos
        .saturating_sub(first.vertical_pos)
        .saturating_add(last.line_height)
        .max(0);
    if signed_hwpunit(table.common.vertical_offset) >= host_height_hu {
        return None;
    }
    Some(
        para_y
            + hwpunit_to_px(host_height_hu, dpi)
            + hwpunit_to_px(signed_hwpunit(table.common.vertical_offset), dpi)
            + hwpunit_to_px(table.outer_margin_top as i32, dpi),
    )
}
fn inline_equation_count(para: &Paragraph) -> usize {
    para.controls
        .iter()
        .filter(|ctrl| matches!(ctrl, Control::Equation(eq) if eq.common.treat_as_char))
        .count()
}

fn same_endnote_control(a: &EndnoteParaSource, b: &EndnoteParaSource) -> bool {
    a.section_index == b.section_index
        && a.para_index == b.para_index
        && a.control_index == b.control_index
}

fn para_large_tac_picture_or_shape_height_px(para: &Paragraph, dpi: f64) -> Option<f64> {
    para.controls
        .iter()
        .filter_map(|ctrl| match ctrl {
            Control::Picture(pic) if pic.common.treat_as_char => Some(
                hwpunit_to_px(pic.common.height as i32, dpi)
                    .max(hwpunit_to_px(pic.shape_attr.current_height as i32, dpi)),
            ),
            Control::Shape(shape) if shape.common().treat_as_char => {
                Some(hwpunit_to_px(shape.common().height as i32, dpi))
            }
            _ => None,
        })
        .reduce(f64::max)
}

fn endnote_question_number(para: &Paragraph) -> Option<u16> {
    let text = para.text.trim_start().strip_prefix('문')?;
    let digits: String = text.chars().take_while(|ch| ch.is_ascii_digit()).collect();
    (!digits.is_empty()).then(|| digits.parse().ok()).flatten()
}

fn textless_non_tac_topbottom_object_tail_advance_px(
    para: &Paragraph,
    control_index: usize,
    dpi: f64,
) -> Option<f64> {
    if para_has_visible_text(para) {
        return None;
    }
    match para.controls.get(control_index)? {
        Control::Picture(pic)
            if !pic.common.treat_as_char
                && matches!(pic.common.text_wrap, TextWrap::TopAndBottom)
                && matches!(pic.common.vert_rel_to, VertRelTo::Para) =>
        {
            para.line_segs
                .first()
                .map(|ls| hwpunit_to_px(ls.line_height + ls.line_spacing, dpi).max(0.0))
        }
        Control::Shape(shape)
            if !shape.common().treat_as_char
                && matches!(shape.common().text_wrap, TextWrap::TopAndBottom)
                && matches!(shape.common().vert_rel_to, VertRelTo::Para) =>
        {
            Some(hwpunit_to_px(shape.common().margin.bottom as i32, dpi).max(0.0))
        }
        _ => None,
    }
}

fn compact_endnote_title_gap_after_single_equation_tail(
    prev_para: &Paragraph,
    current_para: &Paragraph,
    prev_content_bottom_y: f64,
    y_offset: f64,
    prev_endnote_title_gap_px: f64,
    item_ordinal: usize,
    dpi: f64,
) -> Option<f64> {
    let current_is_endnote_question_title = endnote_question_number(current_para).is_some();
    if item_ordinal > 13
        || prev_endnote_title_gap_px < 50.0
        || !current_is_endnote_question_title
        || inline_equation_count(prev_para) != 1
    {
        return None;
    }

    let consumed_gap = y_offset - prev_content_bottom_y;
    if consumed_gap < prev_endnote_title_gap_px * 0.70 {
        return None;
    }

    let prev_seg = prev_para
        .line_segs
        .iter()
        .rev()
        .find(|seg| seg.segment_width > 0)
        .or_else(|| prev_para.line_segs.last())?;
    let current_first_vpos = current_para.line_segs.first()?.vertical_pos;
    let saved_gap_px = hwpunit_to_px(
        (current_first_vpos - (prev_seg.vertical_pos + prev_seg.line_height)).max(0),
        dpi,
    );
    if saved_gap_px >= prev_endnote_title_gap_px * 0.70
        && saved_gap_px <= prev_endnote_title_gap_px * 1.20
    {
        // 저장 vpos가 20mm급 미주 사이 간격 자체를 이미 표현하는 경계는
        // 단일 수식 tail 압축 대상으로 보지 않는다.
        return None;
    }

    // 페이지/단 첫머리로 이어진 미주 tail 뒤의 단일 수식 줄은 한컴/PDF에서
    // 20mm gap 전체를 다시 열지 않는다. 저장 vpos가 크게 튄 경우만 기본 7mm
    // 흐름 몫을 남기고, 일반 단일 수식 tail은 실제 수식 하단에 붙여 시작한다.
    let target_gap = if saved_gap_px > prev_endnote_title_gap_px * 1.50 {
        prev_endnote_title_gap_px * 0.35
    } else {
        0.0
    };
    let target_y = prev_content_bottom_y + target_gap;
    (target_y + 4.0 < y_offset).then_some(target_y)
}

fn para_has_visible_textless_float_shape_item(
    page_content: &PageContent,
    para: &Paragraph,
    para_index: usize,
) -> bool {
    if para_has_visible_text(para) || para_has_visible_inline_control(para) {
        return false;
    }

    para.controls
        .iter()
        .enumerate()
        .any(|(control_index, ctrl)| {
            let is_float_shape = match ctrl {
                Control::Picture(pic) => !pic.common.treat_as_char,
                Control::Shape(shape) => !shape.common().treat_as_char,
                // [#7047] 데코레이션(글앞/글뒤) 표 host 도 같은 축이다 — `#703` 단축이
                // 그 표를 `PageItem::Shape` 로 내므로 이 술어의 item 대조가 성립하고,
                // 전진량은 아래 `advance_line` 의 저장 사다리 증언이 정한다. 표를
                // 빼 두면 host 줄 높이가 흐름에서 통째로 빠져 뒤따르는 개체가 그만큼
                // 위에 놓인다(임대차계약서양식 3쪽: 6.0px · 15.3px).
                Control::Table(table) => !table.common.treat_as_char,
                _ => false,
            };
            is_float_shape
                && page_content.column_contents.iter().any(|cc| {
                    cc.items.iter().any(|it| {
                        matches!(
                            it,
                            PageItem::Shape {
                                para_index: pi,
                                control_index: ci,
                            } if *pi == para_index && *ci == control_index
                        )
                    })
                })
        })
}

/// 빈 float-host 문단의 줄 예약 여부를 **저장 사다리**로 판별한다 — 한글이 그 문서에서
/// 실제로 어떻게 했는지가 다음 문단과의 vpos 델타에 남는다(30213 9쪽 실측: 도식 앵커
/// 2560 = lh1600+gap960 전체 예약 — vert_rel_to 휴리스틱으로는 못 가르는 케이스).
/// 쪽 경계 리셋(음수 델타)·다중 lineseg·값 부재는 None 으로 물러나 휴리스틱에 맡긴다.
/// [#6524] 저장 사다리에서 이 문단이 **한 줄**일 때 그 줄의 대표 조각을 준다.
///
/// 어울림 개체를 안은 문단의 저장 줄은 개체를 피해 좌·우 띠로 쪼개져 `LINE_SEG` 조각
/// 둘로 남는다(30098 pi=36: 둘 다 `vpos=21722`·`lh=1500`·`sp=900`, `cs` 는 0 과 45305).
/// 같은 `vertical_pos` 를 공유하면서 `column_start` 가 갈라지는 조각은 **한 줄**이다
/// (#6299 술어, `height_measurer::is_same_vertpos_wrap_fragment` 와 같은 판별).
///
/// `cs` 까지 같은 쌍은 쪽 리셋·중복이라 뜻이 갈리고, 진짜 여러 줄은 stale 사다리일 수
/// 있으므로 둘 다 `None` 으로 물러난다.
fn stored_single_visual_line(para: &Paragraph) -> Option<&crate::model::paragraph::LineSeg> {
    let segs = para.line_segs.as_slice();
    let first = segs.first()?;
    segs[1..]
        .iter()
        .all(|other| {
            other.vertical_pos == first.vertical_pos && other.column_start != first.column_start
        })
        .then_some(first)
}

fn textless_host_ladder_line_advance(
    paragraphs: &[Paragraph],
    styles: &ResolvedStyleSet,
    dpi: f64,
    para_index: usize,
) -> Option<bool> {
    let cur = paragraphs.get(para_index)?;
    let next = paragraphs.get(para_index + 1)?;
    // [#6524] 물러날 대상은 "**줄**이 여럿"이지 "**조각**이 여럿"이 아니다. 종전 술어
    // `[seg]` 는 좌·우로 쪼개진 한 줄에서도 통째로 물러나 진행량 0 을 주었고, 다음 문단이
    // 24.00pt 위로 올라와 본문 전체가 15.00pt 상승했다(30098 3쪽: `추진경과` 제목이 도표
    // 테두리와 6.01pt 겹침, 한/글은 8.70pt 여유).
    let seg = stored_single_visual_line(cur)?;
    let next_seg = next.line_segs.first()?;
    // 줄 규모는 조각들의 최대값으로 본다 — 좌·우 띠는 같은 줄이라 높이를 더하지 않는다.
    let line_region = cur
        .line_segs
        .iter()
        .map(|s| s.line_height)
        .max()
        .unwrap_or(0)
        + cur
            .line_segs
            .iter()
            .map(|s| s.line_spacing)
            .max()
            .unwrap_or(0);
    if line_region <= 0 {
        return None;
    }
    // [#7047] 저장 델타는 줄 규모만이 아니라 **문단 간격까지** 포함한다 — 호스트의
    // `문단 뒤 간격` + 다음 문단의 `문단 앞 간격` 이 그대로 실려 있다. 같은 파일 아래쪽
    // `ladder_delta_px` 주석도 "저장 델타 = sb+lh+ls 전량" 이라고 적는다.
    //
    // 임대차계약서양식(#7047) 3쪽 빈 개체 호스트 7개 전량 실측 — 델타가 정확히 이 합이다.
    //   rec#829  1720 = lh 1100 + ls 220 + sa 200 + sb 200
    //   rec#847  2120 = lh 1400 + ls 420 + sa   0 + sb 300
    //   rec#947   886 = lh  450 + ls 136 + sa   0 + sb 300
    //   rec#958   494 = lh  150 + ls  44 + sa   0 + sb 300
    //   rec#1041 1794 = lh 1150 + ls 344 + sa   0 + sb 300   (1052·1092 동형)
    //
    // 간격을 빼면 줄 높이가 작은 호스트(450·150 HU)만 `delta/expected` 가 1.51·2.55 로
    // 커져 아래 stale 가드에 걸린다. 그러면 그 문단이 흐름을 **한 픽셀도 전진시키지
    // 않아**, 뒤따르는 개체가 저장 사다리보다 그 델타만큼 위에 놓인다(11.8px·6.6px —
    // 호스트에 글자를 넣는 돌연변이로 같은 값이 그대로 복구됨). 간격을 넣으면 7개 전부
    // 비율 1.0 이 된다. stale 반례(issue_2069: 델타가 저장 피치의 2배)는 간격을 넣어도
    // 비율 ~2.0 이라 가드가 그대로 잡는다.
    let para_spacing_hu = |pi: usize, after: bool| -> i32 {
        paragraphs
            .get(pi)
            .and_then(|p| styles.para_styles.get(p.para_shape_id as usize))
            .map(|ps| {
                let px = if after {
                    ps.spacing_after
                } else {
                    ps.spacing_before
                };
                ((px * 7200.0 / dpi).round() as i32).max(0)
            })
            .unwrap_or(0)
    };
    let expected =
        line_region + para_spacing_hu(para_index, true) + para_spacing_hu(para_index + 1, false);
    if expected <= 0 {
        return None;
    }
    // 합성 lineseg(HWPX 등 vpos 전부 0) 는 사다리가 아니다 — 실값일 때만 믿는다.
    if seg.vertical_pos == 0 && next_seg.vertical_pos == 0 {
        return None;
    }
    // [#5809] reflow/편집 산물(TAG_IMPLEMENTATION_PROPERTY)도 저장 증거가 아니다 —
    // Square 호스트까지 이 사다리 질의를 넓히면서(호출부) stale 사다리가
    // 계약을 뒤집던 반증(issue_2069 편집 시나리오)을 태그로 차단한다.
    let synth = crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY;
    if cur.line_segs.iter().any(|s| s.tag & synth != 0) || next_seg.tag & synth != 0 {
        return None;
    }
    let delta = next_seg.vertical_pos - seg.vertical_pos;
    if delta < 0 {
        return None; // 쪽/단 경계 리셋 — 사다리로 판별 불가
    }
    // [#5809] 예약 증언은 호스트 줄 규모(sb 여유 포함 1.5×)여야 한다 — 편집(Enter)
    // 으로 문단이 삽입된 stale 사다리는 델타가 여러 줄 규모로 남아(issue_2069
    // 한셀OLE: 저장 줄 피치의 2배) 예약으로 오판된다. 그 형상은 판별 불가로
    // 물러나 휴리스틱에 맡긴다.
    if delta * 2 > expected * 3 {
        return None;
    }
    if delta * 4 >= expected * 3 {
        return Some(true);
    }
    if delta * 4 <= expected {
        return Some(false);
    }
    None
}

/// [#7047] 빈 개체 host 가 **또 다른 빈 개체 host** 로 이어지는 사다리의 전진량.
///
/// 이 형상의 종전 간격은 `line_spacing` 뿐이다 — `#1133` 이 "빈 앵커 스택의 줄간격은
/// 표-표 사이 간격"이라고 보존하는 경로이고, `#6147` 의 사다리 증언은
/// `next_text_paragraph_vpos` 가 **다음 문단에 실제 글자**를 요구해 이 형상에서 침묵한다.
///
/// 그런데 저장 사다리는 그 문단이 줄 상자와 문단 간격까지 전진했다고 증언한다. 임대차
/// 계약서양식(#7047) 3쪽 표 host 둘이 각각 줄간격만 전진해 아래 개체가 10.0px · 19.3px
/// 위에 놓였다(host 에 글자 한 자를 넣는 돌연변이로 같은 값이 그대로 복구됨).
///
/// ```text
///   host      저장 델타 = 줄높이 + 줄간격 + host 뒤간격 + 다음 앞간격   종전
///   rec#947         886 =   450 +  136 +   0 +  300                  136
///   rec#1041       1794 =  1150 +  344 +   0 +  300                  344
/// ```
///
/// 등식이 **1 HWPUNIT 안에서** 성립할 때만 델타를 쓴다. 사다리가 표-표 간격만 증언하는
/// 문서(`#1133` 의 원래 대상)는 등식이 깨져 종전 경로가 그대로 남는다 — 광역 규칙이 아닌
/// 문단 단위 자기 게이트다.
///
/// 반환값에서 host 의 `문단 뒤 간격` 을 뺀다 — 호출부가 그 값을 이미 `y_offset` 에
/// 더했으므로, 합이 저장 델타와 정확히 같아진다.
fn stored_empty_anchor_stack_advance_hu(
    stored_layout: bool,
    paragraphs: &[Paragraph],
    styles: &ResolvedStyleSet,
    dpi: f64,
    para_index: usize,
) -> Option<i32> {
    if !stored_layout {
        return None;
    }
    let host = paragraphs.get(para_index)?;
    let next = paragraphs.get(para_index + 1)?;
    // 두 문단 모두 **글자 없는 부동 개체 전용 앵커**여야 한다.
    if !para_is_floating_anchor_without_text(host) || !para_is_floating_anchor_without_text(next) {
        return None;
    }
    let synth = crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY;
    // (vertical_pos, line_height, line_spacing) — 합성 사다리는 저장 증거가 아니다.
    let real_first = |p: &Paragraph| -> Option<(i32, i32, i32)> {
        p.line_segs
            .iter()
            .find(|s| s.tag & synth == 0 && s.line_height > 0)
            .map(|s| (s.vertical_pos, s.line_height, s.line_spacing))
    };
    let (host_vpos, host_line_height, host_line_spacing) = real_first(host)?;
    let (next_vpos, _, _) = real_first(next)?;
    let delta = next_vpos - host_vpos;
    if delta <= 0 {
        return None;
    }
    let spacing_hu = |pi: usize, after: bool| -> i32 {
        paragraphs
            .get(pi)
            .and_then(|p| styles.para_styles.get(p.para_shape_id as usize))
            .map(|ps| {
                let px = if after {
                    ps.spacing_after
                } else {
                    ps.spacing_before
                };
                ((px * 7200.0 / dpi).round() as i32).max(0)
            })
            .unwrap_or(0)
    };
    let host_spacing_after = spacing_hu(para_index, true);
    let expected = host_line_height
        + host_line_spacing.max(0)
        + host_spacing_after
        + spacing_hu(para_index + 1, false);
    if (delta - expected).abs() > 1 {
        return None;
    }
    Some((delta - host_spacing_after).max(0))
}

/// 글자가 없고 보이는 개체가 전부 비-TAC 부동 개체인 앵커 문단인가.
fn para_is_floating_anchor_without_text(para: &Paragraph) -> bool {
    if para_has_visible_text(para) {
        return false;
    }
    let mut saw_float = false;
    for control in &para.controls {
        let common = match control {
            Control::Table(table) => &table.common,
            Control::Picture(picture) => &picture.common,
            Control::Shape(shape) => shape.common(),
            _ => continue,
        };
        if common.treat_as_char {
            return false;
        }
        saw_float = true;
    }
    saw_float
}

fn textless_infront_para_host_requires_line_advance(para: &Paragraph) -> bool {
    if para_has_visible_text(para) {
        return false;
    }

    para.controls.iter().any(|ctrl| match ctrl {
        Control::Table(table) => {
            !table.common.treat_as_char
                && table.common.text_wrap == TextWrap::InFrontOfText
                && crate::renderer::empty_host_controls_are_flow_neutral(para)
        }
        Control::Picture(pic) => {
            let cm = &pic.common;
            // vert_rel_to 는 그림이 어디에 붙어 그려지는지를 정할 뿐, host 문단이
            // 흐름에서 줄을 차지하는지와는 무관하다. PAPER 앵커 그림도 한컴은
            // host 문단의 줄 진행량을 그대로 예약한다 — 저장 lineseg 실측:
            // 그림 host 문단 vertpos=57375/vertsize=1200, 다음 문단 vertpos=59295
            // (= +1920 HU, 정확히 한 줄).
            !cm.treat_as_char
                && matches!(cm.text_wrap, TextWrap::InFrontOfText)
                && matches!(cm.vert_rel_to, VertRelTo::Para | VertRelTo::Paper)
        }
        Control::Shape(shape) => {
            let cm = shape.common();
            !cm.treat_as_char
                && matches!(cm.text_wrap, TextWrap::InFrontOfText)
                && (matches!(cm.vert_rel_to, VertRelTo::Para)
                    || (matches!(cm.vert_rel_to, VertRelTo::Paper)
                        && shape.drawing().and_then(|d| d.text_box.as_ref()).is_some()))
        }
        _ => false,
    })
}

fn paragraph_line_advance_px(
    para: &Paragraph,
    composed: Option<&ComposedParagraph>,
    dpi: f64,
) -> f64 {
    let advance_hu: i32 = composed
        .map(|comp| {
            comp.lines
                .iter()
                .map(|line| line.line_height + line.line_spacing)
                .sum()
        })
        .unwrap_or_else(|| {
            para.line_segs
                .iter()
                .map(|seg| seg.line_height + seg.line_spacing)
                .sum()
        });

    hwpunit_to_px(advance_hu.max(0), dpi)
}

fn square_wrap_table_line_anchor_y(
    para: &Paragraph,
    table: &crate::model::table::Table,
    para_y: f64,
    dpi: f64,
) -> Option<f64> {
    if table.common.treat_as_char
        || !matches!(
            table.common.text_wrap,
            crate::model::shape::TextWrap::Square
        )
        || !matches!(table.common.vert_rel_to, VertRelTo::Para)
        || !matches!(table.common.vert_align, VertAlign::Top | VertAlign::Inside)
        || !matches!(
            table.common.horz_align,
            HorzAlign::Right | HorzAlign::Outside
        )
        || !para_has_visible_text(para)
        || para.line_segs.len() < 2
    {
        return None;
    }

    let first = para.line_segs.first()?;
    let max_width = para
        .line_segs
        .iter()
        .map(|seg| seg.segment_width)
        .max()
        .unwrap_or(0);
    if max_width <= 0 {
        return None;
    }

    let table_width = signed_hwpunit(table.common.width).max(0);
    let min_reduction = (table_width / 3).max(256);
    let anchor = para.line_segs.iter().skip(1).find(|seg| {
        if seg.vertical_pos < first.vertical_pos {
            return false;
        }
        let width_reduced =
            max_width > seg.segment_width && max_width - seg.segment_width >= min_reduction;
        let start_shifted = seg.column_start != first.column_start;
        width_reduced || start_shifted
    })?;

    Some(para_y + hwpunit_to_px(anchor.vertical_pos - first.vertical_pos, dpi))
}

pub(crate) const ENDNOTE_COLUMN_BOTTOM_BLEED_TOLERANCE_PX: f64 = 24.0;
/// [#4318] 마지막 단 split/tail 여유. 24px bleed 는 한 줄(≈12px)을 본문
/// 프레임 아래(+14px)에 통째 남긴다. 저장 vpos 수 px 보정만 허용한다.
pub(crate) const ENDNOTE_LAST_COLUMN_SPLIT_BLEED_PX: f64 = 4.0;

/// [#4318] 마지막 단에서 `added_height` 를 붙이면 본문 하단을 넘기는지.
pub(crate) fn endnote_last_column_tail_overflows_frame(
    current_height: f64,
    added_height: f64,
    available: f64,
) -> bool {
    current_height > available * 0.90
        && current_height + added_height > available + ENDNOTE_LAST_COLUMN_SPLIT_BLEED_PX
}

const ENDNOTE_COLUMN_BOTTOM_OVERFLOW_LOG_TOLERANCE_PX: f64 = 48.0;
const ENDNOTE_EQUATION_TAIL_LINE_BOX_OVERFLOW_LOG_TOLERANCE_PX: f64 = 68.0;
const ZERO_ENDNOTE_COLUMN_BOTTOM_OVERFLOW_LOG_TOLERANCE_PX: f64 = 33.0;

pub(crate) fn is_tolerated_endnote_column_bottom_bleed(
    is_endnote_flow: bool,
    content_bottom: f64,
    col_bottom: f64,
) -> bool {
    is_tolerated_endnote_column_bottom_bleed_with_limit(
        is_endnote_flow,
        content_bottom,
        col_bottom,
        ENDNOTE_COLUMN_BOTTOM_OVERFLOW_LOG_TOLERANCE_PX,
    )
}

fn is_tolerated_endnote_column_bottom_bleed_with_limit(
    is_endnote_flow: bool,
    content_bottom: f64,
    col_bottom: f64,
    log_tolerance_px: f64,
) -> bool {
    // 한컴은 compact 미주 하단에서 마지막 줄을 본문 하단보다 약간 아래,
    // 페이지 테두리 안쪽 여백에 남기기도 한다. 이 경우 줄을 다음 쪽으로
    // 넘기면 시각 분기가 틀어지므로, 작은 bleed는 page overflow로 보지 않는다.
    // 9pt 미주에서 수식/빈 TAC guide가 섞인 문단은 line box가 실제 ink보다
    // 크게 계산되어 40px대까지 내려가기도 한다. 조판 분기 기준은 기존 24px를
    // 유지하고 렌더 overflow 로그만 더 넓게 본다.
    is_endnote_flow
        && content_bottom > col_bottom
        && content_bottom <= col_bottom + log_tolerance_px
}

/// 문단 번호 상태 (수준별 카운터)
#[derive(Debug, Clone, Default)]
pub(crate) struct NumberingState {
    /// 현재 활성 numbering_id
    current_id: Option<u16>,
    /// 수준별 카운터 (0~6 → 1~7수준)
    counters: [u32; 7],
    /// numbering_id별 카운터 히스토리 ("이전 번호 목록에 이어" 지원)
    history: std::collections::HashMap<u16, [u32; 7]>,
}

impl NumberingState {
    /// 카운터를 초기 상태로 리셋
    fn reset(&mut self) {
        self.current_id = None;
        self.counters = [0; 7];
        self.history.clear();
    }

    /// 번호 문단 처리: 카운터를 갱신하고 현재 수준의 번호를 반환
    pub(crate) fn advance(
        &mut self,
        numbering_id: u16,
        level: u8,
        restart: Option<crate::model::paragraph::NumberingRestart>,
    ) -> [u32; 7] {
        use crate::model::paragraph::NumberingRestart;
        let level = (level as usize).min(6);

        // numbering_id가 변경되면 현재 카운터를 히스토리에 저장하고
        // 새 numbering_id의 히스토리에서 복원 (없으면 리셋)
        // HWP 동작:
        //   - 같은 id 연속 = "앞 번호 이어" (카운터 유지)
        //   - 다른 id (히스토리 있음) = "이전 번호 이어" (히스토리 복원)
        //   - 다른 id (히스토리 없음) = "새 번호 시작" (리셋)
        if self.current_id != Some(numbering_id) {
            if let Some(prev_id) = self.current_id {
                self.history.insert(prev_id, self.counters);
            }
            if let Some(saved) = self.history.get(&numbering_id).copied() {
                // 이전에 사용한 id → 히스토리에서 복원
                self.counters = saved;
            } else {
                // 처음 등장하는 id → 상위 레벨 카운터 상속, 현재 레벨 이하 리셋
                let prev = self.counters;
                self.counters = [0; 7];
                self.counters[..level].copy_from_slice(&prev[..level]);
            }
            self.current_id = Some(numbering_id);
        }

        // restart 모드 처리
        match restart {
            Some(NumberingRestart::ContinuePrevious) => {
                // 히스토리에서 복원 (이미 위에서 처리됨) — 카운터 증가만
            }
            Some(NumberingRestart::NewStart(start)) => {
                // 해당 수준의 카운터를 지정 값 - 1로 설정 (advance에서 +1 하므로)
                self.counters[level] = start.saturating_sub(1);
                // 하위 수준 리셋
                for i in (level + 1)..7 {
                    self.counters[i] = 0;
                }
            }
            None => {
                // 기본: 앞 번호 목록에 이어
            }
        }

        // 현재 수준 증가
        self.counters[level] += 1;

        // 하위 수준 리셋
        for i in (level + 1)..7 {
            self.counters[i] = 0;
        }

        self.counters
    }
}

/// 레이아웃 엔진
/// 레이아웃 검증 경고: 요소가 페이지 경계를 초과한 경우
#[derive(Debug, Clone)]
pub struct LayoutOverflow {
    /// 페이지 번호 (0-based)
    pub page_index: u32,
    /// 단 번호 (0-based)
    pub column_index: usize,
    /// 구역 인덱스 (0-based). [Task #1046] reflow hint 키 = (section_index, para_index).
    pub section_index: usize,
    /// 문단 인덱스 (구역-로컬)
    pub para_index: usize,
    /// 요소 종류
    pub item_type: &'static str,
    /// [Task #1046] 이 항목이 단의 첫 항목인가. true 면 다음 페이지로 이월해도 또 넘침
    /// (본문보다 큰 단일 항목 = page-larger) → reflow 대상 아님.
    pub is_first_in_column: bool,
    /// 요소의 실제 Y 좌표 (배치 후)
    pub element_y: f64,
    /// 단 영역 하단 Y 좌표
    pub column_bottom: f64,
    /// 초과량 (px)
    pub overflow_px: f64,
}

impl std::fmt::Display for LayoutOverflow {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "LAYOUT_OVERFLOW: page={}, sec={}, col={}, para={}, type={}, first={}, y={:.1}, bottom={:.1}, overflow={:.1}px",
            self.page_index, self.section_index, self.column_index, self.para_index,
            self.item_type, self.is_first_in_column, self.element_y, self.column_bottom, self.overflow_px)
    }
}

/// [#4515] 같은 페이지의 최상위 표끼리 y 구간이 겹치는 레이아웃 결함 경고.
///
/// `LAYOUT_OVERFLOW` 는 본문 하단(col_bottom) **초과**만 잡는다 — 표 하단이 본문
/// 하단으로 clamp 되는 겹침(#4514)은 초과량이 0 이라 침묵한다. 겹침은 하단 초과가
/// 아니라 형제 요소의 y 구간 **중첩**이므로 별도 축으로 검출한다. 셀 안에 중첩된
/// 표는 부모 표 영역 안에 있는 것이 정상이라 비교 대상이 아니다 — 최상위(Page
/// 직계 overlay 표 + Body→Column 직계 흐름 표)만 모아 비교한다.
#[derive(Debug, Clone)]
pub struct LayoutTableOverlap {
    /// 페이지 번호 (0-based, `LayoutOverflow.page_index` 와 같은 축)
    pub page_index: u32,
    /// 구역 인덱스 (0-based)
    pub section_index: usize,
    /// 위쪽 표(y 시작이 빠른 쪽)를 소유한 문단 인덱스
    pub para_a: usize,
    /// 아래쪽 표를 소유한 문단 인덱스
    pub para_b: usize,
    /// 위쪽 표의 y 구간 (px)
    pub a_y0: f64,
    pub a_y1: f64,
    /// 아래쪽 표의 y 구간 (px)
    pub b_y0: f64,
    pub b_y1: f64,
    /// 겹침량 (px) = a_y1 - b_y0
    pub overlap_px: f64,
}

impl std::fmt::Display for LayoutTableOverlap {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "LAYOUT_TABLE_OVERLAP: page={}, sec={}, para_a={}, para_b={}, a={:.1}~{:.1}, b={:.1}~{:.1}, overlap={:.1}px",
            self.page_index, self.section_index, self.para_a, self.para_b,
            self.a_y0, self.a_y1, self.b_y0, self.b_y1, self.overlap_px)
    }
}

/// [#4515] 테두리 접합 오차 허용 임계 (px). 이슈 실측: 46문서/491표에서 2pt 이하는
/// 전부 인접 표의 정상 접합이었다 (예: sample1 20쪽 1.7px).
const TABLE_OVERLAP_THRESHOLD_PX: f64 = 2.0;

/// [#4515] 페이지 루트에서 최상위 표의 (para_index, y0, y1) 을 모은다.
///
/// - Page 직계 `Table` = paper/overlay z-layer 로 배치된 표 (글앞/글뒤, 용지 기준)
/// - Body → Column 직계 `Table` = 본문 흐름 표
///
/// 둘은 render tree 상 부모가 다르지만 시각적으로 같은 본문 평면을 공유하므로 한
/// 집합으로 비교한다. Cell 하위로는 내려가지 않아 중첩 표는 자연히 제외된다.
fn collect_top_level_table_spans(page_root: &RenderNode) -> Vec<(usize, f64, f64)> {
    fn push_if_table(node: &RenderNode, out: &mut Vec<(usize, f64, f64)>) {
        if !node.visible {
            return;
        }
        if let RenderNodeType::Table(tn) = &node.node_type {
            out.push((
                tn.para_index.unwrap_or(usize::MAX),
                node.bbox.y,
                node.bbox.y + node.bbox.height,
            ));
        }
    }
    let mut out = Vec::new();
    for child in &page_root.children {
        push_if_table(child, &mut out);
        if matches!(child.node_type, RenderNodeType::Body { .. }) {
            for col in &child.children {
                if !matches!(col.node_type, RenderNodeType::Column(_)) {
                    continue;
                }
                for item in &col.children {
                    push_if_table(item, &mut out);
                }
            }
        }
    }
    out
}

/// [#4515] 최상위 표 y 구간 중첩 검출. y 시작 순으로 정렬해 인접 쌍의
/// `위쪽 표 하단 - 아래쪽 표 상단 > threshold` 를 겹침으로 판정한다.
fn detect_table_overlaps(
    mut spans: Vec<(usize, f64, f64)>,
    threshold_px: f64,
) -> Vec<(usize, usize, f64, f64, f64, f64, f64)> {
    spans.sort_by(|a, b| a.1.partial_cmp(&b.1).unwrap_or(std::cmp::Ordering::Equal));
    let mut out = Vec::new();
    for w in spans.windows(2) {
        let (pa, a0, a1) = w[0];
        let (pb, b0, b1) = w[1];
        let overlap = a1 - b0;
        if overlap > threshold_px {
            out.push((pa, pb, a0, a1, b0, b1, overlap));
        }
    }
    out
}

/// 어울림 문단의 마지막 TextRun에 is_para_end를 강제 설정 (↵ 표시용)
fn force_para_end_on_last_run(col_node: &mut RenderNode) {
    if let Some(line_node) = col_node.children.last_mut() {
        if let Some(run_node) = line_node.children.last_mut() {
            if let RenderNodeType::TextRun(ref mut tr) = run_node.node_type {
                tr.is_para_end = true;
            }
        }
    }
}

/// 빈 TopAndBottom 표 host 문단의 조판부호를 표 시작 위치에 직접 그린다.
fn push_empty_para_end_mark(
    tree: &mut PageLayoutContext,
    col_node: &mut RenderNode,
    para: &Paragraph,
    styles: &ResolvedStyleSet,
    section_index: usize,
    para_index: usize,
    x: f64,
    y: f64,
    dpi: f64,
) {
    let char_shape_id = para
        .char_shape_id_at(0)
        .or_else(|| para.char_shapes.first().map(|cs| cs.char_shape_id));
    let mut style = char_shape_id
        .map(|id| resolved_to_text_style(styles, id, 0))
        .unwrap_or_default();
    let line_height = para
        .line_segs
        .first()
        .map(|seg| hwpunit_to_px(seg.line_height, dpi))
        .unwrap_or_else(|| style.font_size.max(13.3));

    if style.font_size <= 0.0 {
        style.font_size = line_height.max(13.3);
    }
    if style.font_family.is_empty() {
        style.font_family = "바탕".to_string();
    }

    let font_size = style.font_size.max(1.0);
    let line_height = line_height.max(font_size);
    let baseline = ensure_min_baseline(font_size * 0.8, font_size);
    let line_id = tree.next_id();
    let mut line_node = RenderNode::new(
        line_id,
        RenderNodeType::TextLine(TextLineNode::new(line_height, font_size)),
        BoundingBox::new(x, y, font_size, line_height),
    );

    let run_id = tree.next_id();
    let run_node = RenderNode::new(
        run_id,
        RenderNodeType::TextRun(TextRunNode {
            text: String::new(),
            style,
            char_shape_id,
            para_shape_id: Some(para.para_shape_id),
            section_index: Some(section_index),
            para_index: Some(para_index),
            char_start: Some(0),
            cell_context: None,
            is_para_end: true,
            is_line_break_end: false,
            rotation: 0.0,
            is_vertical: false,
            char_overlap: None,
            border_fill_id: 0,
            baseline,
            field_marker: FieldMarkerType::None,
            layout_positions: None,
            display_text: None,
        }),
        BoundingBox::new(x, y, 0.0, line_height),
    );
    line_node.children.push(run_node);
    col_node.children.push(line_node);
}

/// [Task #1027 Stage A] VPOS_CORR 의 보정 목표 y(end_y) 계산 + 클램프(순수).
/// 렌더러(layout)와 페이지네이터(typeset)가 동일 측정을 쓰도록 추출한 공용 함수.
///
/// vpos_end/base 로 보정 목표를 구하고, 렌더러와 동일한 자가검증을 적용한다:
/// - 본문 영역 내(`col_area_y ..= col_area_y+height`)
/// - 단계당 ≤8px 백워드(`MAX_BACKWARD_PX`)
/// - stale table-host(TopAndBottom+vert=Para Table) forward jump 가드(>100px)
///
/// 반환: `(end_y, applied)`. `applied==true` 이면 호출자는 y 를 `end_y` 로 갱신.
pub(crate) fn vpos_corrected_end_y(
    is_page_path: bool,
    col_anchor_y: f64,
    col_area_y: f64,
    col_area_height: f64,
    vpos_end: i32,
    base: i32,
    curr_sb: f64,
    y_offset: f64,
    curr_has_topbottom_para_table: bool,
    skip_spacing_before_prededuct: bool,
    allow_large_backward: bool,
    dpi: f64,
) -> (f64, bool) {
    // [Task #412] page_path: col_anchor_y 기준, lazy_path: col_area_y 기준.
    let anchor = if is_page_path {
        col_anchor_y
    } else {
        col_area_y
    };
    let raw_end_y = anchor + hwpunit_to_px(vpos_end - base, dpi);
    let end_y = if skip_spacing_before_prededuct {
        // HWP3-origin HWP5 변환본은 parser 단계에서 paragraph vpos에서 spacing_before를
        // 이미 분리한다. 여기서 다시 sb_N을 사전 차감하면 문단 사이 간격이 사라져
        // sample16 p3의 3mm 격자 기준보다 본문이 위로 붙는다.
        raw_end_y
    } else {
        raw_end_y - curr_sb
    }
    .max(col_area_y);
    // [Task #643] 단계당 백워드 허용폭 8px.
    const MAX_BACKWARD_PX: f64 = 8.0;
    // [Task #874 #8] stale/inflated vpos forward jump 가드.
    const MAX_TABLE_HOST_FORWARD_PX: f64 = 100.0;
    let stale_table_host_vpos =
        curr_has_topbottom_para_table && end_y > y_offset + MAX_TABLE_HOST_FORWARD_PX;
    let backward_ok = end_y >= y_offset - MAX_BACKWARD_PX || allow_large_backward;
    let applied = end_y >= col_area_y
        && end_y <= col_area_y + col_area_height
        && backward_ok
        && !stale_table_host_vpos;
    (end_y, applied)
}

/// [Task #1027 Stage B] 문단이 vpos 보정을 무효화하는 overlay 개체를 포함하는지.
/// 글앞으로/글뒤로(InFrontOfText/BehindText) 또는 위아래(TopAndBottom)+vert=Para 인
/// 비-TAC Shape/Picture 는 vpos 에 개체 높이가 포함되어 과대하므로, 다음 항목의 vpos
/// 보정 base 산출에서 이 문단을 제외(bypass)한다. tac=true 는 LINE_SEG 에 통합되므로
/// 제외 대상 아님(#539). 렌더러·페이지네이터 공유.
/// 컨트롤이 실제로 놓인 줄 seg 인덱스 해석기 (#4531).
///
/// `control_index` 는 controls 배열 인덱스지 줄 인덱스가 아니다 — 비가시 컨트롤이
/// 끼면 어긋난다. `control_text_positions()`(텍스트-문자 좌표)와 `seg.text_start`
/// (UTF-16 유닛 좌표)를 `char_offsets` 로 같은 좌표계에 놓고 사영한다.
///
/// 텍스트와 `char_offsets`가 모두 없는 빈 TAC 캐리어는 예외다. 이 경우 컨트롤 위치는
/// 논리 1칸씩 증가하지만 HWP `LINE_SEG.text_start`는 컨트롤당 8-unit 원시 스트림을
/// 보존하므로, 그 단위로 환산해 소유 줄을 고른다.
pub(crate) fn control_line_seg_index(para: &Paragraph, control_index: usize) -> Option<usize> {
    match para.line_segs.len() {
        0 => return None,
        1 => return Some(0),
        _ => {}
    }
    let positions = para.control_text_positions();
    let p = *positions.get(control_index)?;
    if para.text.is_empty() && para.char_offsets.is_empty() {
        let stream_pos = para
            .empty_control_stream_position(control_index)
            .map_or_else(|| p.saturating_mul(8), |pos| pos as usize);
        // [#5961] `stream_pos` 는 컨트롤당 8유닛인 HWP5 축이므로 `text_start` 도 올린다.
        return para
            .line_segs
            .iter()
            .enumerate()
            .rev()
            .find(|(idx, _)| para.line_seg_text_start(*idx) as usize <= stream_pos)
            .map(|(idx, _)| idx)
            .or(Some(0));
    }
    let mut idx = 0usize;
    for (k, _seg) in para.line_segs.iter().enumerate().skip(1) {
        // [#5961] `char_offsets` 는 HWP5 축이므로 같은 자로 투영한다.
        let seg_start = para.line_seg_text_start(k);
        let start_txt = para.char_offsets.partition_point(|&o| o < seg_start);
        if p >= start_txt {
            idx = k;
        } else {
            break;
        }
    }
    Some(idx)
}

/// 앞선 글앞 도형은 호스트 줄의 흐름을 점유하지 않는다. 빈 문단에서 이 도형들 뒤의
/// TAC 표가 별도 저장 줄을 갖는 경우, 표의 소유 줄 `vpos`가 실제 페인트 기준이다.
/// Picture, 글자처럼 도형, 글뒤/어울림 도형은 #4622의 이중 가산 반증 범위이므로 제외한다.
fn tac_has_only_in_front_decoration_shapes_before(para: &Paragraph, control_index: usize) -> bool {
    let before = &para.controls[..control_index.min(para.controls.len())];
    !before.is_empty()
        && before.iter().all(|control| {
            matches!(control, Control::Shape(shape)
            if !shape.common().treat_as_char
                && matches!(
                    shape.common().text_wrap,
                    crate::model::shape::TextWrap::InFrontOfText
                ))
        })
}

/// TAC 표 앞 컨트롤이 모두 흐름을 전진시키지 않는 장식 개체(글앞·글뒤의 비-TAC
/// 그림·도형)인지 판정한다. 가시성은 기준이 아니다 — 글뒤 그림은 보이지만 줄을
/// 점유하지 않는다. 자리차지·어울림 개체와 글자처럼 개체는 흐름 참여자라 제외한다.
fn tac_has_only_non_flow_decorations_before(para: &Paragraph, control_index: usize) -> bool {
    let before = &para.controls[..control_index.min(para.controls.len())];
    !before.is_empty()
        && before.iter().all(|control| {
            let common = match control {
                Control::Shape(shape) => shape.common(),
                Control::Picture(picture) => &picture.common,
                _ => return false,
            };
            !common.treat_as_char
                && matches!(
                    common.text_wrap,
                    crate::model::shape::TextWrap::InFrontOfText
                        | crate::model::shape::TextWrap::BehindText
                )
        })
}

/// 글앞 장식 뒤의 TAC 표가 물리 표 상자까지 담은 저장 줄과 음수 줄간격을 함께
/// 기록한 경우, 표의 paint 높이에는 줄간격이 없지만 뒤 문단의 flow 예약에는 한 번
/// 포함된다. 이 음수분을 다시 예약하면 표 뒤 본문이 글꼴 높이만큼 아래로 밀린다.
/// 실제 표 소유 줄, 바깥 여백 포함 줄높이, 글앞 장식이라는 세 조건을 모두 확인해
/// 일반 TAC/도형의 저장 줄 계약에는 적용하지 않는다 (#7333 p13·p16~21).
fn tac_in_front_decoration_fixed_line_spacing_deduction_hu(
    para: &Paragraph,
    control_index: usize,
) -> Option<i32> {
    let Control::Table(table) = para.controls.get(control_index)? else {
        return None;
    };
    if !table.common.treat_as_char
        || !matches!(table.common.text_wrap, TextWrap::TopAndBottom)
        || !tac_has_only_in_front_decoration_shapes_before(para, control_index)
        || table.common.height >= 0x8000_0000
    {
        return None;
    }
    let seg = para
        .line_segs
        .get(control_line_seg_index(para, control_index)?)?;
    let outer_box_height = i64::from(table.common.height)
        + i64::from(table.outer_margin_top)
        + i64::from(table.outer_margin_bottom);
    (seg.line_spacing < 0 && i64::from(seg.line_height) >= outer_box_height - 10)
        .then_some(-seg.line_spacing)
}

/// 쪽 첫 저장 줄의 vpos가 문단 앞 간격을 포함하면 쪽 원점은 0이다.
/// 다음 문단의 저장 사다리도 앞 간격을 계상하는지 확인하여 측정과 배치가
/// 같은 원점을 소비한다. 명시적 쪽 나눔과 합성 줄은 이 증거로 사용하지 않는다.
/// A reflowed XML page can retain a complete physical source frame while its
/// runtime LINE_SEG ladder is section-cumulative. Authenticate the same offset
/// across a plain page head, one whole TAC table and its plain successor; the
/// original positive inset belongs to the page, not to the cumulative origin.
/// Unknown/edited/control-bearing text and incomplete object frames stay on the
/// existing path. This does not rewrite stored coordinates or infer an inset.
pub(crate) fn reconstructed_tac_page_basis(
    first: &Paragraph, next: Option<&Paragraph>, after: Option<&Paragraph>,
    styles: &ResolvedStyleSet, dpi: f64, body_height: f64,
) -> Option<i32> {
    use crate::model::paragraph::{ColumnBreakType, LineSeg};
    use crate::model::shape::{TextWrap, VertAlign, VertRelTo};
    let next = next?;
    let after = after?;
    if !body_height.is_finite() || body_height <= 0.0 || !dpi.is_finite() || dpi <= 0.0
        || styles.kerning_measurement_context.is_some()
        || styles.horizontal_shaping_context.is_some()
    { return None; }
    let closed_paragraph = |p: &Paragraph| {
        !p.stored_text_partition_is_dirty() && !p.cell_format_vpos_dirty
            && p.column_type == ColumnBreakType::None
            && p.field_ranges.is_empty() && p.orphan_field_ends.is_empty()
            && p.range_tags.is_empty() && p.title_marks.is_empty()
            && p.markpen_marks.is_empty() && p.ctrl_data_records.iter().all(Option::is_none)
            && p.tab_extended.is_empty() && p.numbering_restart.is_none()
            && p.layout_only_fill_lines == 0 && !p.text.contains('\t')
    };
    if !closed_paragraph(first) || !closed_paragraph(next) || !closed_paragraph(after)
        || !first.controls.is_empty() || !after.controls.is_empty()
        || !para_has_visible_text(first) || !para_has_visible_text(after)
        || first.line_segs.len() != 1 || next.line_segs.len() != 1
        || after.line_segs.len() != 1
    { return None; }
    let [Control::Table(table)] = next.controls.as_slice() else { return None; };
    if !table.common.treat_as_char || table.common.locked || table.common.size_protect
        || table.common.allow_overlap
        || !matches!(table.page_break, crate::model::table::TablePageBreak::RowBreak)
        || table.raw_table_record_attr & (1 << 30) != 0
        || table.common.vertical_offset != 0 || table.common.horizontal_offset != 0
        || !matches!(table.common.text_wrap, TextWrap::TopAndBottom)
        || !matches!(table.common.vert_rel_to, VertRelTo::Para)
        || !matches!(table.common.vert_align, VertAlign::Top)
        || table.caption.is_some() || table.row_count != 1 || table.col_count != 1
        || table.cells.len() != 1 || !table.zones.is_empty()
        || table.common.height == 0 || table.common.width == 0
        || table.outer_margin_top < 0 || table.outer_margin_bottom < 0
    { return None; }
    let cell = &table.cells[0];
    if cell.dirty_flag || cell.cell_protect() || cell.field_name.is_some()
        || cell.row_span != 1 || cell.col_span != 1 || cell.text_direction != 0
        || cell.line_wrap != 0 || cell.paragraphs.is_empty()
        || cell.paragraphs.iter().any(|p| !closed_paragraph(p) || !p.controls.is_empty())
    { return None; }
    let saved = |line: &LineSeg| line.line_height > 0 && line.text_height > 0
        && line.segment_width > 0 && line.line_spacing >= 0
        && line.tag & LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0;
    let physical = |p: &Paragraph| -> Option<i32> {
        let [source] = p.source_line_seg_vertical_pos.as_deref()? else { return None; };
        saved(&p.line_segs[0]).then_some(*source)
    };
    let a = physical(first)?;
    let b = physical(next)?;
    let c = physical(after)?;
    if c.checked_add(after.line_segs[0].line_height)?
        > crate::renderer::px_to_hwpunit(body_height, dpi) { return None; }
    let l = &first.line_segs[0];
    let t = &next.line_segs[0];
    let base = l.vertical_pos.checked_sub(a)?;
    let before = |p: &Paragraph| -> Option<i32> {
        let value = styles.para_styles.get(p.para_shape_id as usize)?.spacing_before;
        if !value.is_finite() || value <= 0.0 { return None; }
        Some(crate::renderer::px_to_hwpunit(value, dpi))
    };
    let gap = before(first)?;
    if base <= 0 || a != gap || before(next)? != gap || before(after)? != gap
        || a.checked_add(l.line_height)?.checked_add(l.line_spacing)?.checked_add(gap)? != b
        || b.checked_add(t.line_height)?.checked_add(t.line_spacing)?.checked_add(gap)? != c
        || t.vertical_pos.checked_sub(b)? != base
        // Import reconstruction closes an inline saved table at its own
        // advance and clears source_anchor_end. The next plain paragraph's
        // physical leading margin is then consumed by paint, not runtime vpos.
        || after.line_segs[0].vertical_pos.checked_sub(c)? != base.checked_sub(gap)?
        || t.vertical_pos.checked_add(t.line_height)?.checked_add(t.line_spacing)?
            != after.line_segs[0].vertical_pos
        || i64::from(t.line_height) != i64::from(table.common.height)
            + i64::from(table.outer_margin_top) + i64::from(table.outer_margin_bottom)
    { return None; }
    Some(base)
}

/// Binds one current inline table to its own published row. Extended control
/// coverage is exactly one 8-unit slot; no imported flag grants this witness.
fn current_mixed_tac_row(para:&Paragraph)->Option<usize>{
    if para.controls.len()!=1 || !matches!(para.controls[0],Control::Table(_))
        || para.text.contains('\t') || !para.tab_extended.is_empty()
        || !para.text.chars().any(|c|!c.is_whitespace()&&c>'\u{001f}'&&c!='\u{fffc}')
        || para.char_offsets.len()!=para.text.chars().count()
    {return None;}
    let positions=para.control_text_positions();let [control_at]=positions.as_slice() else{return None;};
    let count=para.text.chars().count();if *control_at>count{return None;}
    let mut offset=0u32;
    for(i,c)in para.text.chars().enumerate(){
        if i==*control_at{offset=offset.checked_add(crate::model::control::CTRL_CHAR_CODE_UNITS)?;}
        if para.char_offsets.get(i)!=Some(&offset){return None;}
        offset=offset.checked_add(c.len_utf16()as u32)?;
    }
    if *control_at==count{offset=offset.checked_add(crate::model::control::CTRL_CHAR_CODE_UNITS)?;}
    if offset.checked_add(1)!=Some(para.char_count)
        || para.line_segs.iter().any(|r|r.text_start!=0&&para.char_offsets.binary_search(&r.text_start).is_err())
    {return None;}
    control_line_seg_index(para,0).filter(|index|*index<para.line_segs.len())
}

/// An unrelated edit does not revoke an intact source column's leading-space
/// owner. A plain source paragraph closes against a following plain paragraph
/// or intact whole TAC object row. Altered/cut/recomputed rows remain fresh.
pub(crate) fn current_stored_margin_frame(
    first: &Paragraph, next: Option<&Paragraph>, column_width_hu: i32, column_height_hu: i32,
    styles: &ResolvedStyleSet, dpi: f64,
) -> bool {
    use crate::model::paragraph::{ColumnBreakType, LineSeg};
    let Some(next)=next else{return false;};
    let original=|p:&Paragraph|p.column_type==ColumnBreakType::None
        && !p.stored_text_partition_dirty && !p.cell_format_vpos_dirty
        && p.hwpx_axis_shift==0 && p.layout_only_fill_lines==0
        && p.range_tags.is_empty() && p.field_ranges.is_empty() && p.orphan_field_ends.is_empty()
        && p.source_line_seg_vertical_pos.as_ref().is_none_or(|source|
            source.len()==p.line_segs.len() && source.iter().zip(&p.line_segs).all(|(a,b)|*a==b.vertical_pos));
    if !original(first)||!original(next)||!first.controls.is_empty()
        || first.line_segs.is_empty() || next.line_segs.is_empty() || next.controls.len()>1
        || column_width_hu<=0 || column_height_hu<=0 || !para_has_visible_text(first)
    {return false;}
    let row_end=|r:&LineSeg|r.vertical_pos.checked_add(r.line_height).and_then(|v|v.checked_add(r.line_spacing));
    let Some(right)=first.line_segs[0].column_start.checked_add(first.line_segs[0].segment_width) else{return false;};
    let row=|r:&LineSeg|r.tag&LineSeg::TAG_IMPLEMENTATION_PROPERTY==0
        && r.vertical_pos>=0 && r.line_height>0 && r.text_height>0
        && r.baseline_distance>=0 && r.baseline_distance<=r.line_height && r.line_spacing>=0
        && row_end(r).is_some_and(|end|end<=column_height_hu)
        && r.column_start>=0 && r.segment_width>0 && right>0 && right<=column_width_hu
        && r.column_start.checked_add(r.segment_width)==Some(right);
    let closed=|p:&Paragraph|p.line_segs[0].text_start==0 && p.line_segs.iter().all(row)
        && p.line_segs.windows(2).all(|w|w[0].text_start<w[1].text_start && row_end(&w[0])==Some(w[1].vertical_pos));
    let coverage=|p:&Paragraph|{
        // TAB is an extended source slot, never a guessed one-unit plaintext gap.
        if p.text.is_empty() || p.text.contains('\t') || !p.tab_extended.is_empty()
            || p.char_offsets.len()!=p.text.chars().count(){return false;}
        let mut offset=0u32;
        for(i,c)in p.text.chars().enumerate(){
            if p.char_offsets.get(i)!=Some(&offset){return false;}
            let Some(next)=offset.checked_add(c.len_utf16()as u32)else{return false;};offset=next;
        }
        offset<=p.char_count && p.char_count-offset<=1
            && p.line_segs.iter().all(|r|p.char_offsets.binary_search(&r.text_start).is_ok())
    };
    if !closed(first)||!closed(next)||!coverage(first){return false;}
    let a=&first.line_segs[0];let last=first.line_segs.last().unwrap();let b=&next.line_segs[0];
    let Some(first_before)=styles.para_styles.get(first.para_shape_id as usize)
        .map(|s|px_to_hwpunit(s.spacing_before,dpi)) else{return false;};
    let Some(next_before)=styles.para_styles.get(next.para_shape_id as usize)
        .map(|s|px_to_hwpunit(s.spacing_before,dpi)) else{return false;};
    if first_before<=0 || next_before<=0 || a.vertical_pos!=first_before
        || row_end(last).and_then(|v|v.checked_add(next_before))!=Some(b.vertical_pos)
    {return false;}
    if next.controls.is_empty(){return para_has_visible_text(next)&&coverage(next)
        && stored_first_margin_is_page_relative(first,Some(next),styles,dpi);}
    let Control::Table(t)=&next.controls[0] else{return false;};
    // Pristine whole-line source and checked current mixed-flow ownership are
    // separate witnesses. A following table can never impersonate the first row.
    enum Owner{Pristine(usize),Mixed(usize)}
    let owner=if next.line_segs.len()==1 && crate::renderer::composer::stored_first_tac_line(next).is_some(){Owner::Pristine(0)}
        else{let Some(index)=current_mixed_tac_row(next)else{return false;};Owner::Mixed(index)};
    let index=match owner{Owner::Pristine(index)|Owner::Mixed(index)=>index};
    let table_row=&next.line_segs[index];
    if !t.common.treat_as_char || t.caption.is_some() || t.common.allow_overlap
        || t.raw_ctrl_seal!=Some(crate::model::raw_provenance::record_digest(&t.common))
        || t.outer_margin_top<0 || t.outer_margin_bottom<0
        || i64::from(table_row.line_height)!=i64::from(t.common.height)+i64::from(t.outer_margin_top)+i64::from(t.outer_margin_bottom)
        || t.cells.is_empty() || t.cells.iter().any(|cell|cell.dirty_flag
            || cell.paragraphs.iter().any(|p|p.stored_text_partition_dirty || p.cell_format_vpos_dirty
                || !p.controls.is_empty()))
    {return false;}
    stored_first_margin_is_page_relative(first,Some(next),styles,dpi)
}

pub(crate) fn stored_first_margin_is_page_relative(
    first: &Paragraph,
    next: Option<&Paragraph>,
    styles: &ResolvedStyleSet,
    dpi: f64,
) -> bool {
    if first.column_type == crate::model::paragraph::ColumnBreakType::Page {
        return false;
    }
    let Some(first_seg) = first.line_segs.first() else {
        return false;
    };
    let Some(last_seg) = first.line_segs.last() else {
        return false;
    };
    let Some(next) = next else {
        return false;
    };
    let Some(next_seg) = next.line_segs.first() else {
        return false;
    };
    let first_before = styles
        .para_styles
        .get(first.para_shape_id as usize)
        .map(|style| style.spacing_before)
        .unwrap_or(0.0);
    let next_before = styles
        .para_styles
        .get(next.para_shape_id as usize)
        .map(|style| style.spacing_before)
        .unwrap_or(0.0);
    let Some(stored_gap) = next_seg.vertical_pos
        .checked_sub(last_seg.vertical_pos)
        .and_then(|v| v.checked_sub(last_seg.line_height))
        .and_then(|v| v.checked_sub(last_seg.line_spacing))
    else { return false; };
    // 글자처럼 취급되는 도형이 있는 첫 문단은 제목과 개체가 저장 원점을 함께
    // 소유한다. 문단 앞 여백만으로 쪽 원점을 다시 정하면 후속 표가 그 여백만큼
    // 위로 이동한다. 일반 텍스트 문단의 여백 사다리와 구분한다(#6797 7쪽).
    !first
        .controls
        .iter()
        .any(|control| matches!(control, Control::Shape(shape) if shape.common().treat_as_char))
        && !para_has_overlay_shape(first)
        && !para_has_overlay_shape(next)
        && first_seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0
        && last_seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0
        && next_seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0
        && first_before > 0.5
        && next_before > 0.5
        && (hwpunit_to_px(first_seg.vertical_pos, dpi) - first_before).abs() <= 0.5
        && (hwpunit_to_px(
            stored_gap,
            dpi,
        ) - next_before)
            .abs()
            <= 0.5
}

pub(crate) fn para_has_overlay_shape(para: &Paragraph) -> bool {
    use crate::model::shape::{TextWrap, VertRelTo};
    para.controls.iter().any(|c| match c {
        Control::Shape(s) => {
            let cm = s.common();
            if cm.treat_as_char {
                return false;
            }
            matches!(cm.text_wrap, TextWrap::InFrontOfText | TextWrap::BehindText)
                || (matches!(cm.text_wrap, TextWrap::TopAndBottom)
                    && matches!(cm.vert_rel_to, VertRelTo::Para)
                    && !cm.treat_as_char)
        }
        Control::Picture(pic) => {
            let cm = &pic.common;
            if cm.treat_as_char {
                return false;
            }
            matches!(cm.text_wrap, TextWrap::InFrontOfText | TextWrap::BehindText)
                || (matches!(cm.text_wrap, TextWrap::TopAndBottom)
                    && matches!(cm.vert_rel_to, VertRelTo::Para))
        }
        _ => false,
    })
}

/// [#2019] 문단이 "부동 개체 전용 빈 앵커"인지 — 텍스트가 없고 모든 컨트롤이 부동
/// (자리차지 아님, tac=false) Shape/Picture/Table 인 경우.
///
/// 별지 서식(양식) 문단이 여기 해당한다: 부동 글상자·도형·표가 빈 앵커 문단에 매달려
/// Paper/Para 절대위치로 배치된다. 이 문단들을 일반 flow 로 취급하면 높이 예약 /
/// 단나누기 페이지분할 / zone 오프셋에 섹션 누적 vpos 사용이 겹쳐 페이지가 과분할된다
/// (74312 별지 서식: rhwp 81p vs 한글 18p).
///
/// 주의: 이 게이트는 81쪽 산란을 막는 부분 완화다. stored LINE_SEG vpos/line_height 를
/// 무조건 버리는 것이 한글 모델은 아니며, #2019 v3 에서는 Paper 앵커 절대 개체 extent 를
/// page-local pagination 에 반영해 PI-page/시각 정합을 별도로 해결해야 한다.
///
/// 자리차지(TopAndBottom)·tac=true 는 개체가 흐름 공간을 실제로 차지하므로 제외.
/// Shape/Picture 는 통과·글앞·글뒤만(Square 는 그림 좌우 흘림이 흔해 제외, 회귀 차단).
/// Table 은 부동 배치가 어울림(Square) 표준이므로 어울림 포함.
/// [Task #544 v2 정합] TAC picture/shape 배치 경로의 좌측 유효 margin 계산.
///
/// `paragraph_layout.rs` (커밋 a30dca73, Task #544 v2 Stage 2) 는 본문 텍스트 경로에서
/// `has_visible_stroke && border_spacing[0]==[1]==0` 조건에 `box_margin_left` 를 inner
/// padding 명목으로 한 번 더 가산하던 분기를 이중 inset 부작용으로 판단해 완전히
/// 제거했다 (`margin_left = box_margin_left` 단일 룰). 본 함수는 TAC picture/shape
/// 배치 경로가 그 규칙과 동일한 값을 쓰도록 통일한다 — border/stroke 유무는 더 이상
/// 좌측 margin 계산에 관여하지 않는다.
pub(crate) fn tac_picture_effective_margin_left(para_margin_left: f64, para_indent: f64) -> f64 {
    if para_indent > 0.0 {
        para_margin_left + para_indent
    } else {
        para_margin_left
    }
}

pub(crate) fn para_is_floating_overlay_anchor(para: &Paragraph) -> bool {
    use crate::model::shape::TextWrap;
    if !para.text.trim().is_empty() || para.controls.is_empty() {
        return false;
    }
    let shape_floating = |tac: bool, wrap: TextWrap| -> bool {
        !tac && matches!(
            wrap,
            TextWrap::InFrontOfText | TextWrap::BehindText | TextWrap::Through
        )
    };
    para.controls.iter().all(|c| match c {
        Control::Shape(s) => shape_floating(s.common().treat_as_char, s.common().text_wrap),
        Control::Picture(pic) => shape_floating(pic.common.treat_as_char, pic.common.text_wrap),
        Control::Table(t) => {
            !t.common.treat_as_char
                && matches!(
                    t.common.text_wrap,
                    TextWrap::InFrontOfText
                        | TextWrap::BehindText
                        | TextWrap::Through
                        | TextWrap::Square
                )
        }
        _ => false,
    })
}

/// 문단 앞뒤에서 소비할 확정된 흐름 간격이다.
/// 각주처럼 별도 영역에서 선택한 문단은 측정과 배치에 같은 결과를 전달한다.
#[derive(Debug, Clone, Copy)]
pub(crate) struct ParagraphVerticalSpacing {
    pub before: f64,
    pub after: f64,
}

pub struct LayoutEngine {
    /// DPI
    dpi: f64,
    /// Font selection이 확정한 slot→exact source를 layout session 수명에 공급한다.
    /// face parser는 보존하지 않고 immutable bytes만 소유해 self-reference를 피한다.
    exact_font_sources: crate::renderer::kerning::ExactFontSourceRegistry,
    /// Q3-D explicit opt-in slot request의 canonical snapshot. 공개 adapter와
    /// composer가 아직 소비하지 않으므로 product publication은 dormant다.
    horizontal_shaping_instance_requests:
        crate::renderer::shaping_context::HorizontalShapingInstanceRequestRegistry,
    /// 자동 번호 카운터
    auto_counter: std::cell::RefCell<AutoNumberCounter>,
    /// 문단 번호 상태
    numbering_state: std::cell::RefCell<NumberingState>,
    /// 투명선 표시 여부
    show_transparent_borders: std::cell::Cell<bool>,
    /// 잘림 보기: false이면 Body/셀 클립 해제
    clip_enabled: std::cell::Cell<bool>,
    /// 머리말/꼬리말 감추기 세트: (global_page_index, is_header)
    hidden_header_footer: std::cell::RefCell<std::collections::HashSet<(u32, bool)>>,
    /// [#5818] 현재 레이아웃 중인 셀에 어울림(Square 계열) float 그림/도형이 있는지.
    /// 셀 문단 줄이 저장 LINE_SEG cs/sw(wrap 배제 인코딩)를 존중할지 판정하는
    /// 셀-범위 신호 — layout_horizontal_cell_paragraphs 가 설정/복원한다.
    cell_has_square_float: std::cell::Cell<bool>,
    /// [#6175] 현재 구역의 용지/쪽 기준 어울림 개체 흐름 증거 — 본문 저장 행 admission의
    /// 외부 증거. 조판(TypesetEngine)과 같은 값을 써야 측정·페인트가 갈리지 않는다.
    body_float_carve_evidence: std::cell::RefCell<Vec<super::float_placement::FloatCarveEvidence>>,
    /// 총 쪽수 (머리말/꼬리말 필드 치환용)
    total_pages: std::cell::Cell<u32>,
    /// 현재 페이지 번호 (바탕쪽 글상자 쪽번호 치환용)
    current_page_number: std::cell::Cell<u32>,
    /// [Task #2102] 현재 렌더 중인 페이지가 소속 구역의 첫 쪽인지 여부.
    /// 쪽 배경의 **이미지 채우기**는 구역 첫 쪽에만 적용한다(한컴 실측 정합).
    /// 색/그라데이션 채우기·쪽 테두리선은 이 값과 무관하게 현행 유지.
    /// 기본값 true(=억제 없음)로 두어 렌더 경로 밖(테스트 등)의 기존 동작을 보존한다.
    current_page_is_section_first: std::cell::Cell<bool>,
    /// [#5717] 구역정의 "첫 쪽에만 테두리/배경 표시" (HWP5 flags bit 8/9,
    /// HWPX visibility SHOW_FIRST). (border, fill) 순. 기본 (false, false) =
    /// 제한 없음 — 전 쪽 적용(한글 실측: 156494214 테두리 3/3쪽).
    page_border_fill_first_page_only: std::cell::Cell<(bool, bool)>,
    /// 파일 이름 (머리말/꼬리말 필드 치환용)
    file_name: std::cell::RefCell<String>,
    /// 문단 테두리/배경 범위 수집
    /// (border_fill_id, x, y_start, width, y_end, top_inset, bottom_inset,
    ///  is_partial_start, is_partial_end, para_index)
    /// is_partial_start: 다른 컬럼/페이지에서 이어진 부분 (top edge 미렌더링)
    /// is_partial_end: 다음 컬럼/페이지로 이어지는 부분 (bottom edge 미렌더링)
    /// para_index: 본 range 가 속한 paragraph 인덱스 (Task #468: cross-column 박스 연속 검출용)
    para_border_ranges:
        std::cell::RefCell<Vec<(u16, f64, f64, f64, f64, f64, f64, bool, bool, usize)>>,
    /// 셀 문단 큐가 본문/부모 셀과 분리된 범위 안인지 여부.
    collect_cell_para_borders: std::cell::Cell<bool>,
    /// 문단 외곽선 box geometry override (Task #463): wrap=Square 호스트 문단의
    /// 텍스트는 좁은 wrap_area 에서 layout 되지만, 외곽선은 원래 col_area 의
    /// 전체 너비로 그려야 PDF 와 일치한다 (인라인 floating 표를 박스가 둘러쌈).
    /// `layout_wrap_around_paras` 가 호출 직전에 Some(원래 col_area.x, col_area.width)
    /// 로 설정하고, 호출 직후 None 으로 복원한다.
    border_box_override: std::cell::Cell<Option<(f64, f64)>>,
    /// 레이아웃 검증 결과: 경계 초과 목록
    layout_overflows: std::cell::RefCell<Vec<LayoutOverflow>>,
    /// [#4515] 레이아웃 검증 결과: 최상위 표 y 겹침 목록
    layout_table_overlaps: std::cell::RefCell<Vec<LayoutTableOverlap>>,
    /// [Task #1046 Stage 3 Class B/C/D] 직전 렌더한 항목(표/문단)의 실제 콘텐츠 하단(y).
    /// 표 뒤/문단 끝에 더해지는 trailing 간격(줄간격/spacing_after/outer_margin)이
    /// 포함된 y_offset 과 달리, 콘텐츠(표 행/마지막 텍스트 줄)가 실제로 점유한 마지막
    /// y 다. overflow 검출이 페이지 바닥의 후행 간격을 콘텐츠 초과로 오판하지 않도록
    /// 이 값으로 비교한다(페이지네이터의 trailing_ls 정책 #359/#404 와 정합). 항목
    /// 디스패치마다 NaN 으로 리셋되고 표/문단 렌더에서만 설정된다.
    last_item_content_bottom: std::cell::Cell<f64>,
    /// 실제 마지막 흐름 줄 상자의 끝. 빈 줄의 점유와 가시 콘텐츠를 구분한다.
    last_item_flow_line_bottom: std::cell::Cell<f64>,
    /// 직전 항목의 마지막 미주 줄이 공백 텍스트 + 수식만 가진 tail line-box 인지 여부.
    /// 이런 줄은 실제 ink보다 line box가 훨씬 커져 item overflow 로그만 남을 수 있다.
    last_item_endnote_equation_tail_line_box: std::cell::Cell<bool>,
    /// [#7418] 바로 앞 항목이 표 host 문단의 첫 줄부터 그린 글 조각이었으면
    /// (문단 번호, 문단 상단 y, 그 글의 내용 바닥).
    /// 같은 문단의 문단 기준 자리차지 표는 host 글과 겹칠 수 없을 뿐, 그 줄의 **줄간격**
    /// 띠에는 놓일 수 있다 — push-down 바닥을 흐름 y 가 아니라 이 값으로 잡는다.
    host_text_content_bottom: std::cell::Cell<Option<(usize, f64, f64)>>,
    /// [#7418] 지금 배치하는 표의 push-down 바닥(`host_text_content_bottom` 에서 온 값).
    pub(crate) table_push_floor: std::cell::Cell<Option<f64>>,
    /// 빈 줄 감추기로 높이 0 처리된 문단 인덱스 집합
    hidden_empty_paras: std::cell::RefCell<std::collections::HashSet<usize>>,
    /// [Task #1755] 지연 이월 표의 host 텍스트 줄이 typeset 에서 이월 전 쪽에
    /// PartialParagraph 로 pre-emit 된 문단 집합 — 마지막 fragment 뒤 host 렌더 억제.
    pre_emitted_host_paras: std::cell::RefCell<std::collections::HashSet<usize>>,
    /// [#2015] pre-emit 한 host 텍스트 높이(px) — vert_offset 이중계상 보정용.
    pre_emitted_host_heights: std::cell::RefCell<std::collections::HashMap<usize, f64>>,
    /// [#7418] 같은 host 글의 내용 높이(마지막 줄간격 제외) — typeset 과 같은 값.
    pub(crate) pre_emitted_host_content_heights:
        std::cell::RefCell<std::collections::HashMap<usize, f64>>,
    /// [#5854] 현재 구역의 저장 LINE_SEG 사다리가 통짜 합성값인지 — 단 진입 시 set.
    /// 참이면 줄 metrics 를 저장값이 아니라 글꼴·문단 스타일에서 다시 뽑고,
    /// `vertical_pos` 앵커 스냅을 끈다 (조판 경로와 같은 규칙).
    uniform_filler_ladder: std::cell::Cell<bool>,
    /// 렌더용 가상 미주 문단 시작 인덱스
    endnote_para_base: std::cell::Cell<usize>,
    /// 가상 미주 문단별 원본 위치
    endnote_para_sources: std::cell::RefCell<Vec<EndnoteParaSource>>,
    /// [Task #1246] 현재 섹션 미주의 between-notes 마진(HWPUNIT, 0=미적용). HeightCursor 가 미주
    /// 사이 min-gap 보정(gap 부족 시 끌어올림)에 사용한다. 섹션 렌더 셋업마다 갱신.
    endnote_between_notes_hu: std::cell::Cell<i32>,
    /// [#7470] 지금 배치 중인 단이 미주 흐름인가. 미주는 별도 조판 경로라 본문 전용 흐름 규칙
    /// (빈 host 줄의 그림 띠 흡수)을 배치에만 적용하지 않도록 가른다.
    column_is_endnote_flow: std::cell::Cell<bool>,
    /// 현재 섹션 미주의 정규화된 "구분선 위" 마진(HWPUNIT).
    endnote_separator_above_hu: std::cell::Cell<i32>,
    /// 현재 섹션 미주의 정규화된 "구분선 아래" 마진(HWPUNIT).
    endnote_separator_below_hu: std::cell::Cell<i32>,
    /// 현재 활성 필드 위치 — 안내문 렌더링 스킵용
    /// (section_idx, 본문 부모 para_idx, control_idx, cell_path)
    /// cell_path: 셀 내 필드일 경우 Some(Vec<(ctrl, cell, para)>)
    active_field:
        std::cell::RefCell<Option<(usize, usize, usize, Option<Vec<(usize, usize, usize)>>)>>,
    /// 조판부호 표시 여부
    show_control_codes: std::cell::Cell<bool>,
    /// 현재 페이지 용지 너비 (표 HorzRelTo::Paper 위치 계산용)
    current_paper_width: std::cell::Cell<f64>,
    /// 현재 페이지 본문 영역 (표 HorzRelTo::Page / VertRelTo::Page 위치 계산용)
    /// (x, y, width, height). 미설정 시 (0, 0, 0, 0) — 호출부에서 col_area로 폴백.
    current_body_area: std::cell::Cell<(f64, f64, f64, f64)>,
    /// 현재 페이지의 물리 높이 (px).
    ///
    /// [#3637] 셀 안 넘침 진단의 기준선이다. 본문 하단이 아니라 **쪽 하단**이어야 한다 —
    /// 본문 하단과 쪽 하단 사이(아래 여백·꼬리말 영역)에 그려진 글자는 실제로 보이므로
    /// 결함이 아니다. 본문 하단으로 재면 그 구간이 통째로 오탐이 된다.
    current_page_height: std::cell::Cell<f64>,
    /// [#3668] `LAYOUT_OVERFLOW_CELL` 발생 줄 수 누적. 셀 안 줄의 윗변이 쪽 하단 밖
    /// = 그 줄 확정 소실. stderr 진단과 같은 조건에서만 증가하며,
    /// `take_overflow_cell_lines` 로 읽으면서 리셋한다.
    overflow_cell_lines: std::cell::Cell<u32>,
    /// HWP3-origin HWP5 변환본 여부.
    /// [#2403] 소스분기 질의 표면 — set_layout_profile 로 배선 (종전 hwp3_variant/
    /// hwpx_source Cell 2개 통합).
    profile: std::cell::Cell<crate::model::provenance::LayoutCompatibilityProfile>,
    native_source_synthetic_context: std::cell::Cell<Option<[u8; 32]>>,
    completed_native_context: std::cell::Cell<Option<[u8;32]>>,
    /// HWP3 원본 및 HWP3-origin HWP5 변환본의 본문 흐름 spacing_before 보정 여부.
    use_hwp3_origin_flow_spacing_before: std::cell::Cell<bool>,
    /// [#2308] Source IR로부터 재생성되는 render-only width/TAC projection.
    /// 논리 path가 권위 key이고 이 엔진은 hot-path pointer index만 조회한다.
    render_normalization: std::cell::RefCell<
        std::sync::Arc<crate::renderer::render_normalization::RenderNormalizationOverlay>,
    >,
    /// [Task #1728 v2] RowBreak 셀-내 continuation 조각의 첫 가시 문단에서만 set.
    /// 이 문단은 셀-상단(is_column_top)이고 셀-상대 인덱스>0 이지만, 한컴은 앞 간격
    /// (spacing_before)을 유지하므로 column-top 트림을 우회해 전량 적용한다.
    keep_continuation_column_top_spacing_before: std::cell::Cell<bool>,
    /// [#5601] 셀 저장-앵커 스냅이 `para_y = anchored − spacing_before` 로 준비한
    /// 문단에서만 set. 스냅 계약은 composed 가 spacing_before 를 재가산하는 것인데,
    /// Center/Bottom 셀의 column-top 문단은 suppress 플래그가 그 재가산까지 막아
    /// 앞 간격이 통째로 유실된다(00451 제목 −26px). 이 토글이 켜진 문단은
    /// column-top 트림을 우회해 전량 재가산하고, 읽는 즉시 clear 된다.
    reapply_snap_anchored_spacing_before: std::cell::Cell<bool>,
    /// The first stored HWP5 body line may retain its saved top spacing after
    /// frame recomposition when it introduces a visible paragraph-float table.
    /// Set for one column item only; other page-top paragraphs keep their
    /// existing trim contract.
    page_top_float_caption_spacing_para: std::cell::Cell<Option<usize>>,
    /// [#6267] 지금 배치하는 자리차지(TopAndBottom) 표의 호스트 문단이 **이미 그린
    /// 본문 텍스트를 가지고 있는지**. body_bottom 클램프 해제(#5699 J3)의 판별자다 —
    /// 하단 고정 틀(#1658/#1858)은 빈 host 라 클램프가 흐름을 넘어도 겹칠 텍스트가
    /// 없지만, 글이 있는 host 는 클램프가 곧 겹침이다.
    para_float_host_has_text: std::cell::Cell<bool>,
    /// [#7063] 이 아이템의 (**저장-vpos 스냅 이전 흐름 커서**, **직전 아이템 내용
    /// 바닥**). 글자 없는 자리차지 표 host 는 스냅이 `spacing_before` 를 사전 차감한
    /// 자리에 그대로 앉는데(#7203 — 조판할 글줄이 없어 재가산 경로를 안 탄다), 저장
    /// 사다리 증인이 없으면 그 값이 곧 표 윗변이 되어 앞 줄 상자를 문다. 파고들기
    /// 판정과 한/글 정본의 기준점(흐름 커서)을 그 갈래에만 넘긴다.
    item_flow_snap_context: std::cell::Cell<Option<(f64, f64)>>,
    /// HWPX `Preview/PrvImage.png` 원본. HMapsi OLE처럼 일반 preview stream이 없는
    /// legacy 객체의 제한적 첫 페이지 fallback에 사용한다.
    hwpx_page_preview: std::cell::RefCell<Option<PagePreviewImage>>,
    /// [Task #1949] 셀 콘텐츠 유닛(cell_units) 메모이제이션. 거대 셀(수천 문단·중첩표)이
    /// RowBreak 로 여러 페이지에 걸칠 때, 각 페이지의 컷 판정이 같은 셀의 units 를
    /// 반복 재계산해 O(pages×cell) 로 폭증한다. cell_units 는 (cell,table,styles)의 순수
    /// 함수이고 셀 폭·콘텐츠는 렌더 중 불변이므로 셀 포인터를 키로 캐시한다. 문서
    /// 재조판(paginate) 경계에서 clear 하여 다른 IR 의 포인터 재사용을 방지한다.
    /// `Rc` 가 아니라 `Arc` 인 이유: `LayoutEngine` 은 `DocumentCore` 의 필드이고
    /// `DocumentCore` 는 `Send` 여야 한다(native 소비자가 스레드 경계 너머로 소유).
    /// [#3386] 선언 행높이 신뢰를 켤지. 조각 렌더 경로에서만 잠시 끈다.
    declared_trust_allowed: std::cell::Cell<bool>,
    cell_units_cache: std::cell::RefCell<
        std::collections::HashMap<usize, std::sync::Arc<Vec<table_layout::CellUnit>>>,
    >,
    /// [Issue #2063] 표 단위 불변량 `has_visible_text_with_nested_table` 를 표 포인터로
    /// 캐시한다. 이 값은 (측정 대상 셀과 무관한) 표 전체 스캔 결과인데 셀별
    /// `cell_units_uncached` 안에서 계산되어 52,694 셀 표에서 O(셀²)(≈28억) 로 폭증했다.
    /// `cell_units_cache` 와 동일 조판 경계에서 clear 한다.
    table_nested_text_flag_cache: std::cell::RefCell<std::collections::HashMap<usize, bool>>,
    /// [#4149] 셀 커서 fast path 프로브 차단 스캔(개요/번호 문단·AutoNumber 컨트롤
    /// 보유 여부)의 표 포인터 키 메모 — 거대 표 서브트리 재스캔 방지.
    /// `cell_units_cache` 와 동일 조판 경계에서 clear 한다.
    cursor_probe_block_cache: std::cell::RefCell<std::collections::HashMap<usize, bool>>,
    /// [#4149] Derived verdict keyed by source paragraph identity and actual
    /// cell width. This lives for the layout session and is cleared at the same
    /// source/style invalidation boundary as the other pointer-keyed caches.
    single_line_overflow_cache: super::composer::SingleLineOverflowCache,
    /// Issue #2214 test-only: cache miss가 실제 table-wide scan으로 이어진 횟수.
    #[cfg(test)]
    table_nested_text_flag_scan_count: std::cell::Cell<usize>,
}

mod anchor_box_flow;
mod border_rendering;
mod fixed_textbox_flow;
mod paragraph_layout;
mod picture_footnote;
mod shape_layout;
mod table_cell_content;
pub(crate) mod table_layout;
mod table_partial;
mod text_measurement;
mod utils;

pub(crate) use paragraph_layout::ensure_min_baseline;
pub(crate) use paragraph_layout::{assign_numbering_markers, list_marker_geometry};
pub(crate) use table_layout::border_style_has_diagonal;
// [#4149] 셀 커서 fast path 프로브 (document_core::queries::cursor_rect 전용)
pub(crate) use table_partial::{PartialTableCellProbe, ProbeCutPlan};
pub(crate) use text_measurement::{
    compute_char_positions, estimate_text_width, estimate_text_width_exact,
    estimate_text_width_unrounded, extract_tab_leaders_with_extended, find_next_tab_stop,
    hancom_regenerated_space_width, is_cjk_char, is_halfwidth_cjk_quote, kopub_space_advance_em,
    resolved_letter_spacing, resolved_to_text_style, split_into_clusters,
    trace_char_width_decisions, CharWidthDecision,
};
// [#6060] forces_halfwidth_cjk_quote 는 통합 테스트
// (tests/cases/issue_6060_cjk_quote_paint_measure_parity.rs) 에서 측정-페인트 정합을
// 직접 검증한다 — pub 노출.
pub use text_measurement::forces_halfwidth_cjk_quote;
pub use text_measurement::{EmbeddedTextMeasurer, TextMeasurer};
// [Task #826] map_pua_bullet_char 는 통합 테스트 (tests/issue_826.rs) 에서 직접 검증
// (PUA substitution 매핑 정합) — pub 노출.
pub(crate) use border_rendering::{
    body_page_border_outset, border_line_visual_span, border_width_to_px, create_border_line_nodes,
};
pub use paragraph_layout::map_pua_bullet_char;
// para_relative_float_table_lead 는 통합 테스트(tests/issue_6697_square_float_lead.rs)
// 에서 어울림 wrap 리드 계약을 직접 검증한다.
pub use table_layout::para_relative_float_table_lead;
pub(crate) use utils::{
    default_outline_numbering, drawing_to_line_style, drawing_to_shape_style,
    expand_numbering_format, find_bin_data, find_bin_data_bytes, find_bin_data_index,
    format_page_number, layout_rect_to_bbox, picture_display_size_hu, picture_flow_frame_size_hu,
    resolve_numbering_id,
};

#[cfg(test)]
mod integration_tests;
#[cfg(test)]
mod tests;

impl LayoutEngine {
    pub fn new(dpi: f64) -> Self {
        Self {
            dpi,
            exact_font_sources: crate::renderer::kerning::ExactFontSourceRegistry::default(),
            horizontal_shaping_instance_requests:
                crate::renderer::shaping_context::HorizontalShapingInstanceRequestRegistry::default(
                ),
            auto_counter: std::cell::RefCell::new(AutoNumberCounter::new()),
            numbering_state: std::cell::RefCell::new(NumberingState::default()),
            show_transparent_borders: std::cell::Cell::new(false),
            clip_enabled: std::cell::Cell::new(true),
            hidden_header_footer: std::cell::RefCell::new(std::collections::HashSet::new()),
            cell_has_square_float: std::cell::Cell::new(false),
            body_float_carve_evidence: std::cell::RefCell::new(Vec::new()),
            total_pages: std::cell::Cell::new(0),
            current_page_number: std::cell::Cell::new(0),
            current_page_is_section_first: std::cell::Cell::new(true),
            page_border_fill_first_page_only: std::cell::Cell::new((false, false)),
            file_name: std::cell::RefCell::new(String::new()),
            para_border_ranges: std::cell::RefCell::new(Vec::new()),
            collect_cell_para_borders: std::cell::Cell::new(false),
            border_box_override: std::cell::Cell::new(None),
            layout_overflows: std::cell::RefCell::new(Vec::new()),
            layout_table_overlaps: std::cell::RefCell::new(Vec::new()),
            last_item_content_bottom: std::cell::Cell::new(f64::NAN),
            last_item_flow_line_bottom: std::cell::Cell::new(f64::NAN),
            last_item_endnote_equation_tail_line_box: std::cell::Cell::new(false),
            host_text_content_bottom: std::cell::Cell::new(None),
            table_push_floor: std::cell::Cell::new(None),
            hidden_empty_paras: std::cell::RefCell::new(std::collections::HashSet::new()),
            pre_emitted_host_paras: std::cell::RefCell::new(std::collections::HashSet::new()),
            pre_emitted_host_heights: std::cell::RefCell::new(std::collections::HashMap::new()),
            pre_emitted_host_content_heights: std::cell::RefCell::new(
                std::collections::HashMap::new(),
            ),
            uniform_filler_ladder: std::cell::Cell::new(false),
            endnote_para_base: std::cell::Cell::new(usize::MAX),
            endnote_para_sources: std::cell::RefCell::new(Vec::new()),
            endnote_between_notes_hu: std::cell::Cell::new(0),
            column_is_endnote_flow: std::cell::Cell::new(false),
            endnote_separator_above_hu: std::cell::Cell::new(0),
            endnote_separator_below_hu: std::cell::Cell::new(0),
            active_field: std::cell::RefCell::new(None),
            show_control_codes: std::cell::Cell::new(false),
            current_paper_width: std::cell::Cell::new(0.0),
            current_body_area: std::cell::Cell::new((0.0, 0.0, 0.0, 0.0)),
            current_page_height: std::cell::Cell::new(0.0),
            overflow_cell_lines: std::cell::Cell::new(0),
            profile: std::cell::Cell::new(Default::default()),
            native_source_synthetic_context: std::cell::Cell::new(None),
            completed_native_context: std::cell::Cell::new(None),
            use_hwp3_origin_flow_spacing_before: std::cell::Cell::new(false),
            render_normalization: std::cell::RefCell::new(std::sync::Arc::new(
                crate::renderer::render_normalization::RenderNormalizationOverlay::default(),
            )),
            keep_continuation_column_top_spacing_before: std::cell::Cell::new(false),
            reapply_snap_anchored_spacing_before: std::cell::Cell::new(false),
            page_top_float_caption_spacing_para: std::cell::Cell::new(None),
            para_float_host_has_text: std::cell::Cell::new(false),
            item_flow_snap_context: std::cell::Cell::new(None),
            hwpx_page_preview: std::cell::RefCell::new(None),
            declared_trust_allowed: std::cell::Cell::new(true),
            cell_units_cache: std::cell::RefCell::new(std::collections::HashMap::new()),
            table_nested_text_flag_cache: std::cell::RefCell::new(std::collections::HashMap::new()),
            cursor_probe_block_cache: std::cell::RefCell::new(std::collections::HashMap::new()),
            single_line_overflow_cache: Default::default(),
            #[cfg(test)]
            table_nested_text_flag_scan_count: std::cell::Cell::new(0),
        }
    }

    /// [Task #1949] 셀 단위 레이아웃 캐시를 비운다. 문서 재조판 등 IR 이 바뀌는
    /// 경계에서 호출해 포인터 키 재사용으로 인한 오재사용을 방지한다.
    pub fn clear_layout_caches(&self) {
        self.cell_units_cache.borrow_mut().clear();
        self.table_nested_text_flag_cache.borrow_mut().clear();
        self.cursor_probe_block_cache.borrow_mut().clear();
        self.single_line_overflow_cache.clear();
    }

    pub(crate) fn register_exact_font_source(
        &mut self,
        slot: crate::renderer::kerning::ExactFontSlot,
        bytes: &[u8],
        face_index: u32,
    ) -> Result<
        crate::renderer::kerning::ExactFontRegistryRegistration,
        crate::renderer::kerning::ExactFontRegistryError,
    > {
        self.exact_font_sources.register(
            slot,
            crate::renderer::kerning::ExactFontSource { bytes, face_index },
        )
    }

    pub(crate) fn clear_exact_font_sources(&mut self) -> bool {
        let sources_cleared = self.exact_font_sources.clear();
        let requests_cleared = self.horizontal_shaping_instance_requests.clear();
        sources_cleared || requests_cleared
    }

    /// Q3-D internal command owner. The public native/WASM surface remains
    /// unopened until the activation matrix is approved. Validation and
    /// canonicalization complete before this mutates the request snapshot.
    #[allow(dead_code)]
    pub(crate) fn set_horizontal_shaping_instance_request_dormant(
        &mut self,
        slot: crate::renderer::kerning::ExactFontSlot,
        variations: &[crate::renderer::shaping::ShapingVariation],
    ) -> Result<
        crate::renderer::shaping_context::HorizontalShapingInstanceRequestRegistration,
        crate::renderer::shaping_context::HorizontalShapingInstanceRequestError,
    > {
        self.horizontal_shaping_instance_requests.set_verified(
            &self.exact_font_sources,
            slot,
            variations,
        )
    }

    pub(crate) fn clear_horizontal_shaping_instance_request(
        &mut self,
        slot: crate::renderer::kerning::ExactFontSlot,
    ) -> bool {
        self.horizontal_shaping_instance_requests.remove(slot)
    }

    pub(crate) fn horizontal_shaping_instance_request(
        &self,
        slot: crate::renderer::kerning::ExactFontSlot,
    ) -> Option<&[crate::renderer::shaping::ShapingVariation]> {
        self.horizontal_shaping_instance_requests
            .request_slice_for_slot(slot)
    }

    pub(crate) fn horizontal_shaping_instance_request_counts(&self) -> (usize, u64) {
        (
            self.horizontal_shaping_instance_requests.request_count(),
            self.horizontal_shaping_instance_requests.generation(),
        )
    }

    pub(crate) fn exact_font_source_handle(
        &self,
        slot: crate::renderer::kerning::ExactFontSlot,
    ) -> Option<&crate::renderer::kerning::ExactFontSourceHandle> {
        self.exact_font_sources.handle_for_slot(slot)
    }

    pub(crate) fn exact_font_source_session(
        &self,
    ) -> crate::renderer::kerning::KerningSourceSession<'_> {
        crate::renderer::kerning::KerningSourceSession::new(&self.exact_font_sources)
    }

    pub(crate) fn exact_font_layout_session(
        &self,
    ) -> crate::renderer::kerning::KerningLayoutSession<'_> {
        crate::renderer::kerning::KerningLayoutSession::new(&self.exact_font_sources)
    }

    /// HeightMeasurer, TypesetEngine, page-tree LayoutEngine, edit reflow가 한
    /// transaction에서 같은 slot/source 결정을 읽도록 immutable snapshot을 만든다.
    /// Source payload는 Arc라 복제되지 않는다.
    pub(crate) fn exact_font_measurement_context_snapshots(
        &self,
    ) -> (
        Option<std::sync::Arc<crate::renderer::kerning::KerningMeasurementContext>>,
        Option<std::sync::Arc<crate::renderer::shaping_context::HorizontalShapingContext>>,
    ) {
        if self.exact_font_sources.slot_count() == 0 {
            return (None, None);
        }
        let registry = self.exact_font_sources.clone();
        (
            Some(std::sync::Arc::new(
                crate::renderer::kerning::KerningMeasurementContext::new(registry.clone()),
            )),
            Some(std::sync::Arc::new(
                crate::renderer::shaping_context::HorizontalShapingContext::with_instance_requests(
                    registry,
                    self.horizontal_shaping_instance_requests.clone(),
                ),
            )),
        )
    }

    /// Q4-D2 vertical table-cell activation snapshot. The registry clone keeps
    /// immutable font bytes in Arc storage and cannot observe later host
    /// registration changes during the page transaction.
    pub(crate) fn vertical_shaping_context_snapshot(
        &self,
    ) -> Option<crate::renderer::shaping_vertical::VerticalShapingContext> {
        if self.exact_font_sources.slot_count() == 0 {
            None
        } else {
            Some(
                crate::renderer::shaping_vertical::VerticalShapingContext::new(
                    self.exact_font_sources.clone(),
                ),
            )
        }
    }

    pub(crate) fn exact_font_source_registry_counts(&self) -> (usize, usize, usize, u64) {
        (
            self.exact_font_sources.slot_count(),
            self.exact_font_sources.source_count(),
            self.exact_font_sources.total_source_bytes(),
            self.exact_font_sources.generation(),
        )
    }

    pub(crate) fn exact_font_source_bytes_for_resource_key(
        &self,
        key: &str,
    ) -> Option<std::sync::Arc<[u8]>> {
        let (byte_len, digest) = crate::paint::parse_font_blob_resource_key(key)?;
        if byte_len > crate::paint::MAX_PORTABLE_FONT_BLOB_BYTES {
            return None;
        }
        self.exact_font_sources
            .source_arc_matching(byte_len, |bytes| {
                crate::paint::resource_digest_hex(bytes) == digest
            })
    }

    pub(crate) fn set_render_normalization_overlay(
        &self,
        overlay: std::sync::Arc<crate::renderer::render_normalization::RenderNormalizationOverlay>,
    ) {
        *self.render_normalization.borrow_mut() = overlay;
    }

    #[inline]
    pub(crate) fn render_table_width_scale(&self, table: &crate::model::table::Table) -> f64 {
        self.render_normalization
            .borrow()
            .nested_table_width_scale(table)
    }

    pub(crate) fn render_normalization_overlay(
        &self,
    ) -> std::sync::Arc<crate::renderer::render_normalization::RenderNormalizationOverlay> {
        std::sync::Arc::clone(&self.render_normalization.borrow())
    }

    /// 기본 DPI(96)로 생성
    pub fn with_default_dpi() -> Self {
        Self::new(DEFAULT_DPI)
    }

    /// 레이아웃 검증 결과 조회 및 리셋
    pub fn take_overflows(&self) -> Vec<LayoutOverflow> {
        self.layout_overflows.borrow_mut().drain(..).collect()
    }

    /// [#3668] `LAYOUT_OVERFLOW_CELL` 누적 줄 수 조회 및 리셋.
    /// 페이지 렌더 경계마다 읽으면 페이지 단위 귀속이 된다.
    pub fn take_overflow_cell_lines(&self) -> u32 {
        self.overflow_cell_lines.replace(0)
    }

    /// 레이아웃 경계 초과 기록
    fn record_overflow(&self, overflow: LayoutOverflow) {
        eprintln!("{}", overflow);
        self.layout_overflows.borrow_mut().push(overflow);
    }

    /// [#4515] 최상위 표 y 겹침 검증 결과 조회 및 리셋
    pub fn take_table_overlaps(&self) -> Vec<LayoutTableOverlap> {
        self.layout_table_overlaps.borrow_mut().drain(..).collect()
    }

    /// [#4515] 최상위 표 y 겹침 기록
    fn record_table_overlap(&self, overlap: LayoutTableOverlap) {
        eprintln!("{}", overlap);
        self.layout_table_overlaps.borrow_mut().push(overlap);
    }

    pub(crate) fn is_body_flow_col_area(&self, col_area: &LayoutRect) -> bool {
        let (_, body_y, _, body_h) = self.current_body_area.get();
        body_h > 0.0 && (col_area.y - body_y).abs() < 1.0 && (col_area.height - body_h).abs() < 1.0
    }

    fn object_stable_index(para_index: usize, control_index: usize) -> u32 {
        ((para_index.min(u16::MAX as usize) as u32) << 16)
            | control_index.min(u16::MAX as usize) as u32
    }

    fn render_layer_from_common(
        common: &CommonObjAttr,
        para_index: usize,
        control_index: usize,
    ) -> RenderLayerInfo {
        RenderLayerInfo::new(
            Some(common.text_wrap),
            common.z_order,
            Self::object_stable_index(para_index, control_index),
        )
    }

    fn render_layer_from_control(
        control: &Control,
        para_index: usize,
        control_index: usize,
    ) -> Option<RenderLayerInfo> {
        match control {
            Control::Shape(shape) => Some(Self::render_layer_from_common(
                shape.common(),
                para_index,
                control_index,
            )),
            Control::Picture(picture) => Some(Self::render_layer_from_common(
                &picture.common,
                para_index,
                control_index,
            )),
            Control::Table(table) => Some(Self::render_layer_from_common(
                &table.common,
                para_index,
                control_index,
            )),
            Control::Equation(equation) => Some(Self::render_layer_from_common(
                &equation.common,
                para_index,
                control_index,
            )),
            _ => None,
        }
    }

    fn control_common_attr(control: &Control) -> Option<&CommonObjAttr> {
        match control {
            Control::Shape(shape) => Some(shape.common()),
            Control::Picture(picture) => Some(&picture.common),
            Control::Table(table) => Some(&table.common),
            Control::Equation(equation) => Some(&equation.common),
            _ => None,
        }
    }

    fn master_background_common_attr(control: &Control) -> Option<&CommonObjAttr> {
        match control {
            Control::Shape(shape) => Some(shape.common()),
            Control::Picture(picture) => Some(&picture.common),
            _ => None,
        }
    }

    fn render_layer_from_master_control(
        &self,
        control: &Control,
        para_index: usize,
        control_index: usize,
        paper_area: &LayoutRect,
        body_area: &LayoutRect,
    ) -> Option<RenderLayerInfo> {
        let common = Self::control_common_attr(control)?;
        let mut layer =
            Self::render_layer_from_common(common, para_index, control_index).for_master_page();
        if Self::master_background_common_attr(control).is_some_and(|common| {
            self.is_master_paper_background_control(common, paper_area, body_area)
        }) {
            layer.text_wrap = Some(TextWrap::BehindText);
        }
        Some(layer)
    }

    fn is_master_paper_background_control(
        &self,
        common: &CommonObjAttr,
        paper_area: &LayoutRect,
        body_area: &LayoutRect,
    ) -> bool {
        if !matches!(common.text_wrap, TextWrap::InFrontOfText) {
            return false;
        }
        if !matches!(common.horz_rel_to, HorzRelTo::Paper)
            || !matches!(common.vert_rel_to, VertRelTo::Paper)
        {
            return false;
        }

        let (width, height) = self.resolve_object_size(common, paper_area, body_area, paper_area);
        let (x, y) = self.compute_object_position(
            common,
            width,
            height,
            paper_area,
            paper_area,
            body_area,
            paper_area,
            paper_area.y,
            Alignment::Left,
        );

        let near_origin = (x - paper_area.x).abs() <= 1.0 && (y - paper_area.y).abs() <= 1.0;
        let covers_paper = width >= paper_area.width * 0.95 && height >= paper_area.height * 0.95;
        near_origin && covers_paper
    }

    fn push_layered_paper_children(
        paper_images: &mut Vec<RenderNode>,
        temp_parent: &mut RenderNode,
        layer: RenderLayerInfo,
    ) {
        for mut child in temp_parent.children.drain(..) {
            child.set_layer(layer);
            paper_images.push(child);
        }
    }

    fn render_layer_plane(layer: Option<RenderLayerInfo>) -> u8 {
        match layer.and_then(|layer| layer.text_wrap) {
            Some(TextWrap::BehindText) => 1,
            Some(TextWrap::InFrontOfText) => 3,
            _ => 2,
        }
    }

    /// 종이 기준 렌더 노드의 정렬키 `(plane, z_order, doc_path)`.
    /// 레이아웃 쿼리(`get_page_control_layout_native`)가 컨트롤별 plane/zOrder/stableIndex 를
    /// 프런트 히트테스트에 노출할 때 재사용한다(렌더 정렬과 단일 진실 원천 유지). [Task #1280 v2]
    ///
    /// [#4334] 세 번째 원소는 더 이상 `RenderLayerInfo.stable_index`(패킹된 u32,
    /// layer 없으면 `node.id` 폴백) 가 아니라 [`crate::renderer::render_tree::doc_path_for_node`]
    /// 가 노드 자신의 필드(para/control/cell 경로)에서 직접 유도하는 [`DocPath`]다 —
    /// `next_id()` 카운터를 전혀 참조하지 않는다. layer 있는 노드와 없는 노드가 예전엔
    /// 서로 다른 수 공간(패킹된 u32 vs 카운터)을 썼지만 이제 하나의 좌표계를 공유한다.
    /// 문서 위치를 유도할 수 없는 노드는 빈 경로로 폴백한다 — 빈 배열은 사전식
    /// 비교에서 항상 최솟값이라 결정적이지만, 그런 노드끼리의 상대 순서는 여전히
    /// `paper_images`/`mp_node.children` 삽입 순서(Rust 안정 정렬)를 따른다. #4334
    /// stage3 실측(`issue_4334_stage3_document_position_coverage_precheck`)으로 이
    /// 잔여는 표/바탕쪽 picture 는 아니고(플러밍 결손 3곳을 고쳤다) 표 셀 배경/무늬
    /// 이미지 채우기(`render_cell_background`, 문서 Control 이 아니라 셀 스타일에서
    /// 파생된 순수 장식이라 애초에 독립된 문서 위치가 없음) 로 수렴한다.
    pub(crate) fn paper_node_sort_key(node: &RenderNode) -> (u8, i32, DocPath) {
        let layer = node.layer;
        let z_order = layer.map(|layer| layer.z_order).unwrap_or(0);
        let doc_path = crate::renderer::render_tree::doc_path_for_node(node).unwrap_or_default();

        (Self::render_layer_plane(layer), z_order, doc_path)
    }

    fn sort_paper_render_nodes(paper_images: &mut [RenderNode]) {
        paper_images.sort_by_key(Self::paper_node_sort_key);
    }

    /// [#6121] 셀 안 anchored(비 TAC) 개체를 셀 본문 텍스트 위로 올린다.
    ///
    /// 한글은 표 칸 문단에 앵커된 자리차지/어울림 개체(글 뒤로 제외)를 칸의 본문
    /// 텍스트 **위**에 그린다 — 본문 흐름에서 개체가 문단 텍스트 뒤에 일괄
    /// 페인트되는 계약과 같다. 셀 조립은 문단 순서대로 개체를 즉시 밀어 넣으므로
    /// 뒤 문단 텍스트가 앞 문단 개체 위에 그려졌다(경찰청 보도자료 머리 칸:
    /// 흰색 서식-잔재 run 이 container 의 "경 찰 청" drawText 를 파먹음).
    /// `layout_cell_shape` 가 마킹한 layer(text_wrap·z_order·stable_index)를
    /// 소비해, 해당 자식들만 z_order 안정 정렬로 셀 children 끝으로 옮긴다 —
    /// 개체가 이미 셀 마지막 문단 뒤에 있으면 결과 순서는 그대로다.
    fn lift_cell_anchored_objects_above_text(node: &mut RenderNode) {
        for child in &mut node.children {
            Self::lift_cell_anchored_objects_above_text(child);
        }
        if !matches!(node.node_type, RenderNodeType::TableCell(_)) {
            return;
        }
        let lifts = |child: &RenderNode| {
            child
                .layer
                .is_some_and(|layer| !matches!(layer.text_wrap, Some(TextWrap::BehindText)))
        };
        if !node.children.iter().any(lifts) {
            return;
        }
        let mut kept: Vec<RenderNode> = Vec::with_capacity(node.children.len());
        let mut lifted: Vec<RenderNode> = Vec::new();
        for child in node.children.drain(..) {
            if lifts(&child) {
                lifted.push(child);
            } else {
                kept.push(child);
            }
        }
        lifted.sort_by_key(|child| {
            child
                .layer
                .map(|layer| (layer.z_order, layer.stable_index))
                .unwrap_or((0, 0))
        });
        kept.extend(lifted);
        node.children = kept;
    }

    /// 빈 줄 감추기 문단 집합 설정
    pub fn set_hidden_empty_paras(&self, paras: &std::collections::HashSet<usize>) {
        *self.hidden_empty_paras.borrow_mut() = paras.clone();
    }

    /// [Task #1755] 이월 전 쪽에 host 텍스트가 pre-emit 된 문단 집합 설정
    pub fn set_pre_emitted_host_paras(&self, paras: &std::collections::HashSet<usize>) {
        *self.pre_emitted_host_paras.borrow_mut() = paras.clone();
    }

    /// [#2015] pre-emit 된 host 텍스트 높이 맵 설정 (vert_offset 이중계상 보정용)
    pub fn set_pre_emitted_host_heights(
        &self,
        heights: &std::collections::HashMap<usize, f64>,
        content_heights: &std::collections::HashMap<usize, f64>,
    ) {
        *self.pre_emitted_host_heights.borrow_mut() = heights.clone();
        *self.pre_emitted_host_content_heights.borrow_mut() = content_heights.clone();
    }

    /// 렌더용 가상 미주 문단과 원본 Endnote 내부 문단의 매핑을 설정한다.
    pub fn set_endnote_para_sources(&self, base: usize, sources: &[EndnoteParaSource]) {
        self.endnote_para_base.set(base);
        *self.endnote_para_sources.borrow_mut() = sources.to_vec();
    }

    /// [Task #1236] 이 미주 문단의 다음 렌더 문단이 **같은 미주(문제)** 내 연속 문단인지.
    ///
    /// 같은 미주 연속이면 다줄 미주 문단의 마지막 줄에도 trailing 줄간격을 적용해야
    /// 풀이 본문 줄간격이 균일해진다(다줄 문단 다음 줄간격이 좁아지는 #1236 증상 해소).
    /// 미주의 마지막 문단(=다음이 새 문제 = between-notes margin 적용)이면 false 를 반환해
    /// 문제-사이 간격(7mm 등) 중복 가산을 막는다.
    fn endnote_para_has_same_endnote_successor(&self, para_index: usize) -> bool {
        let base = self.endnote_para_base.get();
        let Some(local_idx) = para_index.checked_sub(base) else {
            return false;
        };
        let sources = self.endnote_para_sources.borrow();
        match (sources.get(local_idx), sources.get(local_idx + 1)) {
            (Some(cur), Some(next)) => {
                cur.section_index == next.section_index
                    && cur.para_index == next.para_index
                    && cur.control_index == next.control_index
            }
            _ => false,
        }
    }

    /// [Task #1246] 현재 섹션 미주의 between-notes 마진(HU)을 설정한다(섹션 렌더 셋업마다 호출).
    /// HeightCursor 가 미주 사이 min-gap 보정에 사용. 0 = 미적용.
    pub fn set_endnote_between_notes_hu(&self, between_notes_hu: i32) {
        self.endnote_between_notes_hu.set(between_notes_hu.max(0));
    }

    /// 현재 섹션 미주의 정규화된 "미주 모양" 여백을 설정한다.
    pub fn set_endnote_shape_margins_hu(
        &self,
        separator_above_hu: i32,
        between_notes_hu: i32,
        separator_below_hu: i32,
    ) {
        self.endnote_separator_above_hu
            .set(separator_above_hu.max(0));
        self.endnote_between_notes_hu.set(between_notes_hu.max(0));
        self.endnote_separator_below_hu
            .set(separator_below_hu.max(0));
    }

    pub(crate) fn current_endnote_zero_spacing_profile(&self) -> bool {
        self.endnote_separator_above_hu.get() == 0
            && self.endnote_between_notes_hu.get() == 0
            && self.endnote_separator_below_hu.get() == 0
    }

    fn current_endnote_zero_between_large_separator_profile(&self) -> bool {
        self.endnote_between_notes_hu.get() == 0
            && self.endnote_separator_above_hu.get() > ENDNOTE_BETWEEN_NOTES_BASE_FLOW_HU
            && self.endnote_separator_below_hu.get() > ENDNOTE_BETWEEN_NOTES_BASE_FLOW_HU
    }

    fn endnote_para_source_for(&self, para_index: usize) -> Option<EndnoteParaSource> {
        let base = self.endnote_para_base.get();
        let local_idx = para_index.checked_sub(base)?;
        self.endnote_para_sources.borrow().get(local_idx).cloned()
    }

    pub(crate) fn is_tolerated_current_endnote_bottom_bleed(
        &self,
        is_endnote_flow: bool,
        content_bottom: f64,
        col_bottom: f64,
        equation_tail_line_box: bool,
    ) -> bool {
        let log_tolerance_px = if self.current_endnote_zero_spacing_profile() {
            ZERO_ENDNOTE_COLUMN_BOTTOM_OVERFLOW_LOG_TOLERANCE_PX
        } else if equation_tail_line_box {
            ENDNOTE_EQUATION_TAIL_LINE_BOX_OVERFLOW_LOG_TOLERANCE_PX
        } else {
            ENDNOTE_COLUMN_BOTTOM_OVERFLOW_LOG_TOLERANCE_PX
        };
        is_tolerated_endnote_column_bottom_bleed_with_limit(
            is_endnote_flow,
            content_bottom,
            col_bottom,
            log_tolerance_px,
        )
    }

    fn note_ref_for_endnote_equation(
        &self,
        para_index: usize,
        inner_control_index: usize,
    ) -> Option<NoteControlRef> {
        let base = self.endnote_para_base.get();
        let local_idx = para_index.checked_sub(base)?;
        let src = self.endnote_para_sources.borrow().get(local_idx)?.clone();
        Some(NoteControlRef {
            kind: "endnote".to_string(),
            section_index: src.section_index,
            para_index: src.para_index,
            control_index: src.control_index,
            note_para_index: src.note_para_index,
            inner_control_index,
        })
    }

    /// 번호 상태를 초기화한다.
    pub fn reset_numbering_state(&self) {
        self.numbering_state.borrow_mut().reset();
    }

    /// [#2403] 소스분기 프로파일 배선 — 종전 set_hwp3_variant + set_hwpx_source
    /// 통합. set_hwp3_variant 의 결합 부수효과(hwp3 변환본 → flow spacing_before
    /// 보정 동시 활성)를 그대로 승계한다; 별도 값이 필요한 호출자는 이어서
    /// set_hwp3_origin_flow_spacing_before 로 덮어쓴다 (rendering 경로 종전 순서).
    pub fn set_layout_profile(
        &self,
        profile: crate::model::provenance::LayoutCompatibilityProfile,
    ) {
        self.profile.set(profile);
        self.use_hwp3_origin_flow_spacing_before
            .set(profile.hwp3_layout());
    }

    pub(crate) fn set_completed_native_context(&self,context:Option<[u8;32]>) {
        self.completed_native_context.set(context);
    }
    fn owns_completed_native_frame(&self,para:&Paragraph,control:usize,page:&PageContent,col:&LayoutRect,layout:&PageLayoutInfo,current_flow:f64)->bool {
        let Some(context)=self.completed_native_context.get() else{return false;};
        if !para.owns_completed_native_rows(context) {return false;}
        let Some(f)=para.completed_native_rows.as_ref().and_then(|o|o.native_frame) else{return false;};
        layout.column_areas.get(f.column as usize).is_some_and(|owned|
            (owned.x-col.x).abs()<0.01 && (owned.width-col.width).abs()<0.01)
            && para.owns_completed_native_frame_at(context,page.page_index,f.column,control,current_flow-col.y,self.dpi/7200.0)

    }
    pub(crate) fn set_native_source_synthetic_context(&self, context: Option<[u8; 32]>) {
        self.native_source_synthetic_context.set(context);
    }

    pub fn set_hwp3_origin_flow_spacing_before(&self, enabled: bool) {
        self.use_hwp3_origin_flow_spacing_before.set(enabled);
    }

    /// HWPX page preview 이미지를 렌더 fallback용으로 설정한다.
    pub fn set_hwpx_page_preview(&self, data: Option<&[u8]>) {
        *self.hwpx_page_preview.borrow_mut() = data.and_then(|bytes| {
            if bytes.starts_with(b"\x89PNG\r\n\x1a\n") {
                Some(PagePreviewImage {
                    mime: "image/png",
                    data: bytes.to_vec(),
                })
            } else if bytes.starts_with(b"GIF8") {
                Some(PagePreviewImage {
                    mime: "image/gif",
                    data: bytes.to_vec(),
                })
            } else {
                None
            }
        });
    }

    /// 이미 렌더된 인라인 이미지 노드의 y 좌표를 dy만큼 이동 (캡션 Top 보정)
    fn offset_inline_image_y(
        node: &mut RenderNode,
        para_index: usize,
        control_index: usize,
        dy: f64,
    ) {
        for child in node.children.iter_mut() {
            if let RenderNodeType::Image(ref img) = child.node_type {
                if img.para_index == Some(para_index) && img.control_index == Some(control_index) {
                    child.bbox.y += dy;
                    return;
                }
            }
            // 재귀 탐색 (line_node 등 하위 노드)
            Self::offset_inline_image_y(child, para_index, control_index, dy);
        }
    }

    /// 번호 카운터를 진행시킨다 (이전 페이지 문단의 번호 재계산용).
    pub fn advance_numbering(&self, numbering_id: u16, level: u8) {
        self.numbering_state
            .borrow_mut()
            .advance(numbering_id, level, None);
    }

    /// 잘림 보기 여부를 설정한다.
    pub fn set_clip_enabled(&self, enabled: bool) {
        self.clip_enabled.set(enabled);
    }

    /// 투명선 표시 여부를 설정한다.
    pub fn set_show_transparent_borders(&self, enabled: bool) {
        self.show_transparent_borders.set(enabled);
    }

    /// 머리말/꼬리말 감추기 세트를 설정한다.
    pub fn set_hidden_header_footer(&self, hidden: &std::collections::HashSet<(u32, bool)>) {
        *self.hidden_header_footer.borrow_mut() = hidden.clone();
    }

    /// 총 쪽수를 설정한다 (머리말/꼬리말 필드 치환용).
    pub fn set_total_pages(&self, total: u32) {
        self.total_pages.set(total);
    }

    /// [Task #2102] 현재 렌더 페이지가 소속 구역의 첫 쪽인지 설정한다.
    /// 쪽 배경 이미지 채우기를 구역 첫 쪽에만 적용하기 위한 페이지별 컨텍스트.
    pub fn set_current_page_is_section_first(&self, is_first: bool) {
        self.current_page_is_section_first.set(is_first);
    }

    /// [#5717] 구역정의 "첫 쪽에만 테두리/배경 표시" 플래그를 설정한다.
    /// (HWP5 flags bit 8/9, HWPX visibility SHOW_FIRST). 켜진 축은
    /// `current_page_is_section_first` 가 아닐 때 해당 쪽 테두리/배경을 그리지 않는다.
    pub fn set_page_border_fill_first_page_only(&self, border: bool, fill: bool) {
        self.page_border_fill_first_page_only.set((border, fill));
    }

    /// 파일 이름을 설정한다 (머리말/꼬리말 필드 치환용).
    pub fn set_file_name(&self, name: &str) {
        *self.file_name.borrow_mut() = name.to_string();
    }

    /// 활성 필드 설정 (안내문 렌더링 스킵용)
    pub fn set_active_field(
        &self,
        info: Option<(usize, usize, usize, Option<Vec<(usize, usize, usize)>>)>,
    ) {
        *self.active_field.borrow_mut() = info;
    }

    /// 조판부호 표시 여부 설정
    pub fn set_show_control_codes(&self, enabled: bool) {
        self.show_control_codes.set(enabled);
    }

    /// 자동 번호 카운터 초기화
    pub fn reset_auto_counter(&self) {
        self.auto_counter.borrow_mut().reset();
    }

    /// 페이지 분할 결과와 원본 문단으로부터 렌더 트리를 생성한다.
    ///
    /// - `paragraphs`: 본문 구역의 문단 슬라이스
    /// - `header_paragraphs`: 머리말 컨트롤이 속한 구역의 문단 슬라이스 (구역 간 상속 시 다를 수 있음)
    /// - `footer_paragraphs`: 꼬리말 컨트롤이 속한 구역의 문단 슬라이스
    pub fn build_render_tree(
        &self,
        page_content: &PageContent,
        paragraphs: &[Paragraph],
        header_paragraphs: &[Paragraph],
        footer_paragraphs: &[Paragraph],
        composed: &[ComposedParagraph],
        styles: &ResolvedStyleSet,
        footnote_shape: &FootnoteShape,
        bin_data_content: &[BinDataContent],
        active_master_page: Option<&MasterPage>,
        measured_tables: &[MeasuredTable],
        page_border_fill: Option<&PageBorderFill>,
        outline_numbering_id: u16,
        wrap_around_paras: &[super::pagination::WrapAroundPara],
    ) -> PageRenderTree {
        self.build_render_tree_with_current_selections(page_content,paragraphs,header_paragraphs,footer_paragraphs,composed,styles,footnote_shape,bin_data_content,active_master_page,measured_tables,page_border_fill,outline_numbering_id,wrap_around_paras,false,None,None)
    }

    pub(crate) fn build_render_tree_with_current_selections(
        &self,
        page_content: &PageContent,
        paragraphs: &[Paragraph],
        header_paragraphs: &[Paragraph],
        footer_paragraphs: &[Paragraph],
        composed: &[ComposedParagraph],
        styles: &ResolvedStyleSet,
        footnote_shape: &FootnoteShape,
        bin_data_content: &[BinDataContent],
        active_master_page: Option<&MasterPage>,
        measured_tables: &[MeasuredTable],
        page_border_fill: Option<&PageBorderFill>,
        outline_numbering_id: u16,
        wrap_around_paras: &[super::pagination::WrapAroundPara],
        collect_current_selections:bool,
        current_frame_paint_plan:Option<super::current_frame_rows_plan::CurrentFramePaintPlan>,
        accepted:Option<super::current_accepted_composition::CurrentAcceptedCompositionView>,
    ) -> PageRenderTree {
        let layout = &page_content.layout;
        // [#6175] 본문 저장 행 admission의 외부-기하 증거 - 조판이 구역당 한 번
        // 계산하는 것과 **같은 함수·같은 입력**이라 두 경로가 갈리지 않는다.
        *self.body_float_carve_evidence.borrow_mut() =
            super::float_placement::paper_or_page_float_carve_evidence(paragraphs);
        let mut tree = PageRenderTree::new(
            page_content.page_index,
            layout.page_width,
            layout.page_height,
        );
        if collect_current_selections {tree.frame_mut().current_physical_selections.enable_new_page_capture();}
        if collect_current_selections {if let Some(plan)=current_frame_paint_plan.as_ref(){
            tree.frame_mut().current_physical_selections.bind_current_plan(plan);
        }}
        tree.frame_mut().current_frame_paint_plan=current_frame_paint_plan;

        tree.frame_mut().current_accepted_composition=accepted;
        // 페이지 배경. hide_fill(쪽 배경 감추기) 시 커스텀 채우기(색/그라데이션/이미지)만
        // 숨기고 흰 종이 바탕 pageBackground 는 유지한다. 통째로 스킵하면 raster 기본 투명
        // clear 상태로 남아 export-png 가 RGB flatten 시 페이지 전체가 검게 나온다 (#2083).
        let hide_fill = page_content
            .page_hide
            .as_ref()
            .map(|ph| ph.hide_fill)
            .unwrap_or(false);
        self.build_page_background(
            &mut tree,
            layout,
            page_border_fill,
            styles,
            bin_data_content,
            hide_fill,
        );

        // 쪽 테두리선 (감추기 설정 시 건너뜀)
        let hide_border = page_content
            .page_hide
            .as_ref()
            .map(|ph| ph.hide_border)
            .unwrap_or(false);
        if !hide_border {
            self.build_page_borders(&mut tree, layout, page_border_fill, styles);
        }

        // 바탕쪽 (감추기 설정 시 건너뜀)
        let hide_master = page_content
            .page_hide
            .as_ref()
            .map(|ph| ph.hide_master_page)
            .unwrap_or(false);
        if !hide_master {
            self.build_master_page(
                &mut tree,
                active_master_page,
                layout,
                composed,
                styles,
                bin_data_content,
                page_content.section_index,
                page_content.page_number,
            );
        }

        // 머리말 (감추기 설정 시 건너뜀)
        let hide_header = page_content
            .page_hide
            .as_ref()
            .map(|ph| ph.hide_header)
            .unwrap_or(false);
        if !hide_header {
            self.build_header(
                &mut tree,
                page_content,
                header_paragraphs,
                composed,
                styles,
                layout,
                bin_data_content,
                page_border_fill,
            );
        }

        // 본문 영역 노드 (clip_rect은 콘텐츠 레이아웃 후 확정)
        let body_id = tree.next_id();
        let body_bbox = layout_rect_to_bbox(&layout.body_area);
        let mut body_node = RenderNode::new(
            body_id,
            RenderNodeType::Body {
                clip_rect: None, // 레이아웃 후 설정
            },
            body_bbox,
        );

        // 단별 콘텐츠 레이아웃
        let mut paper_images: Vec<RenderNode> = Vec::new();
        self.build_columns(
            tree.frame_mut(),
            &mut body_node,
            &mut paper_images,
            page_content,
            paragraphs,
            composed,
            styles,
            bin_data_content,
            measured_tables,
            layout,
            outline_numbering_id,
            wrap_around_paras,
        );

        // 단 구분선은 build_columns 내부의 emit_zone_column_separators 가 zone(또는
        // page layout 폴백)별 콘텐츠 높이로 그린다. 과거 page-level build_column_separators
        // 는 body 전체높이를 고정으로 그려 부분 페이지에서 구분선이 과도하게 길었고,
        // zone emit 과 이중 렌더되어 [Task #1333 v2] 에서 제거되었다.

        // 콘텐츠 레이아웃 후 clip_rect 확정:
        // 자식 노드(표 등)의 실제 바운딩 박스를 재귀적으로 반영하여
        // body_area보다 큰 콘텐츠(표 외곽 테두리 등)가 잘리지 않도록 함
        if self.clip_enabled.get() {
            // [#3127] clip 하방 확장은 콘텐츠 종류로 갈린다.
            //
            // - 흐름 콘텐츠(표/문단/셀 등)는 body_area 를 넘겨 배치돼도 잘리면 안 된다.
            //   (예: body 바닥 아래로 늘어난 표 마지막 셀의 용지 규격 줄
            //   `210mm×297mm(백상지 ㎡)`. 브라우저는 clip 밖도 그리지만 svg2pdf 는
            //   엄격히 잘라 PDF 에서 소실됐다.)
            // - 부동 그림/도형은 body_bottom+10 상한을 유지한다 — 대형 부동 그림이
            //   꼬리말 영역까지 clip 을 확장하던 Task #460 회귀를 막기 위해서다.
            //
            // 그래서 흐름 콘텐츠 bbox 는 상한 없이 반영하고, 부동 그림 bbox 는 상한
            // 적용분과 별도로 모아 두 결과를 합친다.
            fn is_floating_object(node: &RenderNode) -> bool {
                matches!(
                    node.node_type,
                    RenderNodeType::Image(_)
                        | RenderNodeType::Group(_)
                        | RenderNodeType::Path(_)
                        | RenderNodeType::Ellipse(_)
                        | RenderNodeType::Rectangle(_)
                        | RenderNodeType::Line(_)
                        | RenderNodeType::TextBox
                        | RenderNodeType::Placeholder(_)
                        | RenderNodeType::RawSvg(_)
                )
            }
            // clip 을 **가시** 자식 bbox 로 확장. `float_subtree` 가 참이면 그 서브트리는
            // 부동 그림으로 취급해 상한 적용 대상 clip 만 넓힌다.
            //
            // TableCell 자체가 clip이면 그 cell 밖의 자손은 현재 PageRenderTree에는
            // 존재해도 이전/다음 페이지용 연속 흐름일 뿐 paint되지 않는다. 그 tail을
            // body clip 확장에 재귀 반영하면 Canvas/WASM이 물리 쪽 밖을 재생할 수 있고,
            // SVG의 cell clip과도 의미가 달라진다(42065 RowBreak 1×1 중첩 표).
            fn expand_clip(
                flow: &mut BoundingBox,
                float: &mut BoundingBox,
                node: &RenderNode,
                float_subtree: bool,
            ) {
                let cb = &node.bbox;
                let is_float = float_subtree || is_floating_object(node);
                let target: &mut BoundingBox = if is_float { &mut *float } else { &mut *flow };
                let child_bottom = cb.y + cb.height;
                let child_right = cb.x + cb.width;
                if child_bottom > target.y + target.height {
                    target.height = child_bottom - target.y;
                }
                if child_right > target.x + target.width {
                    target.width = child_right - target.x;
                }
                if cb.x < target.x {
                    target.width += target.x - cb.x;
                    target.x = cb.x;
                }
                if cb.y < target.y {
                    target.height += target.y - cb.y;
                    target.y = cb.y;
                }
                let clips_descendants = matches!(
                    node.node_type,
                    RenderNodeType::TableCell(ref cell) if cell.clip
                );
                if !clips_descendants {
                    for child in &node.children {
                        expand_clip(flow, float, child, is_float);
                    }
                }
            }
            let mut flow_clip = body_bbox;
            let mut float_clip = body_bbox;
            for child in &body_node.children {
                expand_clip(&mut flow_clip, &mut float_clip, child, false);
            }
            // [#5855] 부동 개체 clip 의 하한은 **용지 하단**이다.
            //
            // 한글은 쪽 기준으로 앉힌 개체를 본문 영역에 가두지 않는다 — 꼬리말 자리에
            // 놓인 로고 띠(156618554_petfood_press: 정답지 이미지 하단 1056.0px, 본문 하단
            // 1028.1px)가 그대로 보인다. `body_bottom + 10` 상한은 그 20.9px 를 지웠다.
            //
            // Task #460 이 이 상한으로 막으려던 것은 대형 부동 그림이 body clip 을 넓혀
            // **흐름 콘텐츠**까지 꼬리말로 새게 하는 것이었다. 그런데 #3127 이후 흐름
            // clip(`flow_clip`)은 상한 없이 따로 잡히므로, 합집합의 하단은 이미 흐름
            // 콘텐츠가 결정한다. 이 상한이 실제로 자르고 있는 것은 부동 개체 자신뿐이다.
            // 용지 밖으로는 여전히 나가지 못한다.
            let max_bottom = layout.page_height.max(body_bbox.y + body_bbox.height);
            if float_clip.y + float_clip.height > max_bottom {
                float_clip.height = max_bottom - float_clip.y;
            }
            // 두 clip 의 합집합 = 흐름 오버플로는 보존, 부동 그림은 상한 적용.
            let x0 = flow_clip.x.min(float_clip.x);
            let y0 = flow_clip.y.min(float_clip.y);
            let x1 = (flow_clip.x + flow_clip.width).max(float_clip.x + float_clip.width);
            let y1 = (flow_clip.y + flow_clip.height).max(float_clip.y + float_clip.height);
            let clip = BoundingBox {
                x: x0,
                y: y0,
                width: x1 - x0,
                height: y1 - y0,
            };
            body_node.node_type = RenderNodeType::Body {
                clip_rect: Some(clip),
            };
        }

        tree.root.children.push(body_node);

        Self::sort_paper_render_nodes(&mut paper_images);

        // [Task #604 Stage 6] 용지 기준 개체: body 위 z-layer 로 배치 (한컴 변환 메커니즘
        // 정합). Task #1197 부터 Picture/Table/Shape 공통 layer 메타데이터로 같은
        // text-wrap/z-order 축을 보존한다.
        for img_node in paper_images {
            tree.root.children.push(img_node);
        }

        // 각주 영역
        self.build_footnote_area(
            &mut tree,
            page_content,
            paragraphs,
            footnote_shape,
            styles,
            layout,
        );

        // 꼬리말 + 쪽 번호 (감추기 설정 시 건너뜀)
        let hide_footer = page_content
            .page_hide
            .as_ref()
            .map(|ph| ph.hide_footer)
            .unwrap_or(false);
        let mut footer_node = if !hide_footer {
            self.build_footer(
                tree.frame_mut(),
                page_content,
                footer_paragraphs,
                composed,
                styles,
                layout,
                bin_data_content,
            )
        } else {
            let fid = tree.next_id();
            RenderNode::new(
                fid,
                RenderNodeType::Footer,
                layout_rect_to_bbox(&layout.footer_area),
            )
        };
        self.build_page_number(
            &mut tree,
            &mut footer_node,
            page_content,
            styles,
            layout,
            page_border_fill,
        );
        tree.root.children.push(footer_node);

        // composer를 거치지 않고 직접 만들어진 표 셀/머리말 TextRun까지 같은
        // 한컴 PDF 표시 계약을 적용한다. 원문 IR과 char offset은 변경하지 않는다.
        tree.apply_legacy_hancom_product_display_projection();

        // [#6121] 셀 안 anchored 개체 ↔ 셀 본문 텍스트 페인트 순서 정합.
        Self::lift_cell_anchored_objects_above_text(&mut tree.root);

        // [#4515] 최상위 표 y 겹침 자가 검증. paper/overlay 표가 root 에 모두 붙은
        // 페이지 조립 완료 시점에 검사해야 글앞/글뒤 표까지 대상에 들어간다.
        for (pa, pb, a0, a1, b0, b1, overlap) in detect_table_overlaps(
            collect_top_level_table_spans(&tree.root),
            TABLE_OVERLAP_THRESHOLD_PX,
        ) {
            self.record_table_overlap(LayoutTableOverlap {
                page_index: page_content.page_index,
                section_index: page_content.section_index,
                para_a: pa,
                para_b: pb,
                a_y0: a0,
                a_y1: a1,
                b_y0: b0,
                b_y1: b1,
                overlap_px: overlap,
            });
        }

        // A current plan is a render-call input, never a cached page permission.
        tree.frame_mut().current_frame_paint_plan=None;
        tree.frame_mut().current_accepted_composition=None;
        tree
    }

    /// 머리말/꼬리말 문단을 해당 영역에 레이아웃한다.
    /// [Task #825] `outer_section_index` + `outer_hf_ref` — 머리말/꼬리말 그림 클릭
    /// hit-test marker (Some 일 때 ImageNode 에 전파). None 이면 기존 동작 (그림 미선택).
    #[allow(clippy::too_many_arguments)]
    fn layout_header_footer_paragraphs(
        &self,
        tree: &mut PageLayoutContext,
        area_node: &mut RenderNode,
        hf_paragraphs: &[Paragraph],
        _composed: &[ComposedParagraph],
        styles: &ResolvedStyleSet,
        area: &LayoutRect,
        body_area: &LayoutRect,
        paper_area: &LayoutRect,
        table_area: Option<&LayoutRect>,
        page_index: u32,
        page_number: u32,
        bin_data_content: &[BinDataContent],
        outer_section_index: Option<usize>,
        outer_hf_ref: Option<crate::renderer::render_tree::HeaderFooterImageRef>,
        is_header: bool,
        list_attr: u32,
        band_height_hu: u32,
    ) {
        // [#6186] 머리말/꼬리말 subList 의 `vertAlign`(HWPX) = LIST_HEADER list_attr
        // 비트 21~22 (0=TOP, 1=CENTER, 2=BOTTOM). 파서는 이미 값을 싣는데
        // 레이아웃이 읽지 않아 늘 밴드 맨 위에 놓였다 — 156755659 는 BOTTOM 이라
        // 쪽번호가 21.8px 위에 붙어, 같은 자리에 겹쳐 놓인 글상자와 두 줄로 갈렸다.
        // 내용 높이를 **줄 높이 합으로 정확히 알 수 있을 때만** 정렬한다 — 표·도형·
        // 그림이 든 꼬리말은 이 합이 과소평가라 과잉 이동한다(exam_kor: 꼬리말에
        // 상자가 들어 있어 17.97px 더 내려가 한글과 멀어졌다 — 한글 A4 실측 쪽 하단
        // 82.1px 위 = A3 환산 116.2, 종전 118.5 가 맞고 변경값 100.6 은 틀림).
        // 쪽번호 같은 인라인 필드는 줄 안에서 자리를 차지하므로 줄 높이에 이미 들어
        // 있다 — 배제 대상은 **자기 높이를 갖는 개체**(표·도형·그림)뿐이다.
        let text_only_footer = !hf_paragraphs.is_empty()
            && hf_paragraphs.iter().all(|para| {
                !para.line_segs.is_empty()
                    && !para.controls.iter().any(|c| {
                        matches!(
                            c,
                            Control::Table(_) | Control::Shape(_) | Control::Picture(_)
                        )
                    })
            });
        let vert_align = if text_only_footer {
            (list_attr >> 21) & 0b11
        } else {
            0
        };
        let content_h: f64 = hf_paragraphs
            .iter()
            .filter_map(|para| para.line_segs.iter().map(|seg| seg.line_height).max())
            .map(|lh| hwpunit_to_px(lh, self.dpi))
            .sum();
        // 정렬 기준은 **문서가 선언한 밴드 높이**(HWPX subList `textHeight`)다.
        // 공유 `layout.footer_area` 는 아래 여백까지 품고 있고(그 rect 는 쪽 계산에도
        // 쓰여 건드리면 쪽수가 흔들린다 — issue_1733 등 8핀 실측), 한글의 세로 정렬은
        // 꼬리말 밴드 안에서만 일어난다. 선언값이 없으면(HWP5 등) 종전대로 area 전체.
        //
        // **선언값이 없으면(HWP5 등) 정렬을 적용하지 않는다.** `area.height` 로 물러서면
        // 밴드가 아래 여백까지 품고 있어 과잉 이동한다 — exam_kor(HWP5, A3 렌더)에서
        // 꼬리말 상자가 17.97px 더 내려가 한글과 멀어졌다(한글 A4 기준 쪽 하단에서
        // 82.1px 위 = A3 환산 116.2px; 종전 118.5px 가 맞고 변경 후 100.6px 는 틀림).
        // HWPX subList 가 `textHeight` 로 밴드를 명시할 때만 그 안에서 정렬한다.
        let slack = if band_height_hu > 0 {
            let band_h = hwpunit_to_px(band_height_hu as i32, self.dpi).min(area.height);
            (band_h - content_h).max(0.0)
        } else {
            0.0
        };
        // HWP5의 그림 혼합 footer는 저장 LINE_SEG가 footer 안 줄 grid를 완전히
        // 표현한다. `BOTTOM` subList에서 첫 줄의 vpos는 0이지만, 한컴은 첫 줄의
        // line_spacing을 footer 원점 뒤의 선행 여백으로 쓴다. 그림을 포함했다는
        // 이유만으로 text-only 정렬을 피하던 기존 경로는 이 1회 선행 여백도 버려
        // rule·로고·AutoNumber를 함께 위로 올렸다(#7333, 452 HU = 6.03px).
        //
        // 임의의 stale vpos를 원점으로 삼지 않는다. 각 문단이 정확히 한 저장 줄을
        // 가지고 vpos가 직전 줄의 height+spacing만큼 진행하며, 전체 grid가 선언한
        // subList 높이 안에 닫힐 때만 적용한다.
        let stored_mixed_footer_leading = if !text_only_footer {
            self.bottom_aligned_footer_grid_leading_px(hf_paragraphs, list_attr, band_height_hu)
        } else {
            0.0
        };
        let mut y_offset = area.y
            + match vert_align {
                1 => slack / 2.0,
                2 => slack,
                _ => 0.0,
            }
            + stored_mixed_footer_leading;
        for (i, para) in hf_paragraphs.iter().enumerate() {
            // 테이블 컨트롤이 있으면 테이블 렌더링
            let has_table = para.controls.iter().any(|c| matches!(c, Control::Table(_)));
            let has_shape = para.controls.iter().any(|c| matches!(c, Control::Shape(_)));
            let has_picture = para
                .controls
                .iter()
                .any(|c| matches!(c, Control::Picture(_)));
            if has_table {
                for (ci, ctrl) in para.controls.iter().enumerate() {
                    if let Control::Table(t) = ctrl {
                        let alignment = styles
                            .para_styles
                            .get(para.para_shape_id as usize)
                            .map(|s| s.alignment)
                            .unwrap_or(Alignment::Left);
                        // Task #445: 꼬리말 영역의 wrap=TopAndBottom + vert=Para 표는
                        // 첫 라인의 line_height/2 만큼 아래로 anchor 됨 (HWP 가 line center
                        // 기준으로 표를 배치하는 동작과 일치). 이 보정이 없으면 페이지 번호
                        // 박스가 본문 바닥과 붙어 보이는 문제(Task #445) 발생.
                        // [Issue #924] 머릿말에서는 적용하지 않음 — 표가 header_area 안에 정확히 위치해야 함.
                        // 꼬리말은 Task #445에서 필요하므로 유지.
                        let line_anchor_offset = if !is_header
                            && matches!(
                                t.common.text_wrap,
                                crate::model::shape::TextWrap::TopAndBottom
                            )
                            && matches!(t.common.vert_rel_to, crate::model::shape::VertRelTo::Para)
                            && i == 0
                        {
                            let lh_hu = para
                                .line_segs
                                .first()
                                .map(|ls| ls.line_height as i32)
                                .unwrap_or(0);
                            hwpunit_to_px(lh_hu, self.dpi) / 2.0
                        } else {
                            0.0
                        };
                        let table_y = y_offset + line_anchor_offset;
                        let table_area = table_area.unwrap_or(area);
                        y_offset = self.layout_table(
                            tree,
                            area_node,
                            t.as_ref(),
                            0,
                            styles,
                            0,
                            table_area,
                            table_y,
                            bin_data_content,
                            None,
                            0,
                            Some((i, ci)),
                            alignment,
                            None,
                            0.0,
                            0.0,
                            None,
                            None,
                            None,
                            None,
                            false,
                            is_header,
                            0.0,
                            None,
                            Self::standalone_table_char_border_fill(Some(para), t.as_ref(), styles),
                        );
                    }
                }
            } else if has_picture {
                // Picture 컨트롤이 있는 문단
                let comp = self.compose_header_footer_paragraph(para, page_number, styles);
                if comp.tac_controls.is_empty() {
                    // 글자처럼 취급하지 않는 그림과 쪽번호 AutoNumber가 같은 꼬리말
                    // 문단에 공존할 수 있다. 그림만 개별 배치하고 끝내면 AutoNumber가
                    // 조합 텍스트에 남아 있어도 전혀 그려지지 않는다(#7333).
                    // 그림의 y 누적은 다음 그림 배치용이므로, 인라인 필드는 원래
                    // 문단 기준선(text_y)에서 따로 레이아웃한다.
                    let text_y = y_offset;
                    // 머리말/꼬리말 내 Picture: header/footer area 기준 배치
                    for (ci, ctrl) in para.controls.iter().enumerate() {
                        if let Control::Picture(pic) = ctrl {
                            if pic.common.treat_as_char {
                                let pic_container = LayoutRect {
                                    x: area.x,
                                    y: y_offset,
                                    width: area.width,
                                    height: area.height - (y_offset - area.y),
                                };
                                // [Task #825] inner para_index = i (hf_paragraphs 안 인덱스),
                                // inner control_index = ci. outer 위치는 outer_hf_ref 보존.
                                self.layout_picture_full(
                                    tree,
                                    area_node,
                                    pic,
                                    &pic_container,
                                    bin_data_content,
                                    Alignment::Left,
                                    outer_section_index,
                                    Some(i),
                                    Some(ci),
                                    outer_hf_ref.clone(),
                                    None, // [Task #1151 v4] cell_ctx: 머리말/꼬리말 path
                                    styles,
                                );
                            } else {
                                // `Paper`/`Page` 기준은 header/footer 틀을 원점으로
                                // 다시 해석하므로 para_y의 저장 grid 선행을 읽지 않는다.
                                // 완전한 BOTTOM HWP5 grid로 확인한 경우에만 그 틀 원점도
                                // 첫 줄 leading만큼 이동한다. `Para`/`Column` 그림은 이미
                                // y_offset을 쓰므로 여기서 area를 움직이면 두 번 더해진다.
                                let picture_area = if !is_header
                                    && stored_mixed_footer_leading > 0.0
                                    && matches!(
                                        pic.common.vert_rel_to,
                                        VertRelTo::Paper | VertRelTo::Page
                                    ) {
                                    LayoutRect {
                                        y: area.y + stored_mixed_footer_leading,
                                        ..*area
                                    }
                                } else {
                                    *area
                                };
                                self.layout_header_footer_picture(
                                    tree,
                                    area_node,
                                    pic,
                                    &picture_area,
                                    y_offset,
                                    bin_data_content,
                                    outer_section_index,
                                    i,
                                    ci,
                                    outer_hf_ref.clone(),
                                    styles,
                                );
                            }
                            let pic_h = hwpunit_to_px(pic.common.height as i32, self.dpi);
                            y_offset += pic_h;
                        }
                    }
                    let has_page_auto_number = para.controls.iter().any(|ctrl| {
                        matches!(
                            ctrl,
                            Control::AutoNumber(number)
                                if matches!(
                                    number.number_type,
                                    crate::model::control::AutoNumberType::Page
                                        | crate::model::control::AutoNumberType::TotalPage
                                )
                        )
                    });
                    if has_page_auto_number {
                        let text_end = self.layout_paragraph(
                            tree,
                            area_node,
                            para,
                            Some(&comp),
                            styles,
                            area,
                            text_y,
                            0,
                            usize::MAX - i,
                            None,
                            None,
                            None,
                        );
                        y_offset = y_offset.max(text_end);
                    }
                } else {
                    // TAC Picture: layout_paragraph에서 인라인 배치
                    y_offset = self.layout_paragraph(
                        tree,
                        area_node,
                        para,
                        Some(&comp),
                        styles,
                        area,
                        y_offset,
                        0,
                        usize::MAX - i,
                        None,
                        Some(bin_data_content),
                        None, // 머리말/꼬리말 컨텍스트 — wrap zone 무관
                    );
                }
            } else if has_shape {
                // [#5802] 글자처럼 취급(TAC) 도형은 paragraph_layout 이 inline 좌표를
                // 등록해야 layout_shape 가 그린다 — 미등록 TAC 는 #476 가드가 조용히
                // 스킵한다. 머리말/꼬리말 문단은 종전에 layout_shape 만 불러, 쪽번호
                // 묶음처럼 TAC 도형으로 저장된 내용이 통째로 소실됐다(611쪽 보고서
                // 꼬리말 전량). 본문 등록 키와 충돌하지 않게 구역 인덱스는 HF 전용
                // 센티널(usize::MAX)을 등록·조회 양쪽에 쓴다.
                let has_tac_shape = para
                    .controls
                    .iter()
                    .any(|c| matches!(c, Control::Shape(s) if s.common().treat_as_char));
                let hf_shape_section = usize::MAX;
                if has_tac_shape {
                    let comp = self.compose_header_footer_paragraph(para, page_number, styles);
                    self.layout_paragraph(
                        tree,
                        area_node,
                        para,
                        Some(&comp),
                        styles,
                        area,
                        y_offset,
                        hf_shape_section,
                        i,
                        None,
                        Some(bin_data_content),
                        None,
                    );
                }
                // Shape 컨트롤 렌더링 (머리말/꼬리말 내 글상자 등)
                for (ci, ctrl) in para.controls.iter().enumerate() {
                    if let Control::Shape(_) = ctrl {
                        self.layout_shape(
                            tree,
                            area_node,
                            hf_paragraphs,
                            i,
                            ci,
                            if has_tac_shape { hf_shape_section } else { 0 },
                            styles,
                            area,
                            body_area,
                            paper_area,
                            y_offset,
                            Alignment::Left,
                            bin_data_content,
                            &std::collections::HashMap::new(),
                            is_header,
                        );
                    }
                }
                // 텍스트도 함께 렌더링 (TAC 도형 경로는 위에서 이미 문단을 레이아웃함)
                if !has_tac_shape && !para.text.is_empty() {
                    let comp = self.compose_header_footer_paragraph(para, page_number, styles);
                    y_offset = self.layout_paragraph(
                        tree,
                        area_node,
                        para,
                        Some(&comp),
                        styles,
                        area,
                        y_offset,
                        0,
                        usize::MAX - i,
                        None,
                        None,
                        None, // 머리말/꼬리말 컨텍스트 — wrap zone 무관
                    );
                }
            } else {
                // 일반 텍스트 문단 레이아웃 (필드 마커 치환 포함)
                let comp = self.compose_header_footer_paragraph(para, page_number, styles);
                y_offset = self.layout_paragraph(
                    tree,
                    area_node,
                    para,
                    Some(&comp),
                    styles,
                    area,
                    y_offset,
                    0,
                    usize::MAX - i,
                    None,
                    None,
                    None, // 머리말/꼬리말 컨텍스트 — wrap zone 무관
                );
            }
            if y_offset >= area.y + area.height {
                break;
            }
        }
    }

    /// `BOTTOM` footer의 완전한 HWP5 저장 줄 grid가 갖는 첫 줄 선행 간격.
    ///
    /// 그림·자동번호가 섞인 footer는 실제 그림 상자를 줄 높이로 환산할 수 없어
    /// 일반 text-only subList 정렬을 적용할 수 없다. 다만 모든 inner 문단의 한 줄
    /// grid가 저장되어 있고 그 grid가 `textHeight` 안에 닫히면, 한컴이 첫 줄
    /// `line_spacing`을 footer 원점 뒤의 선행으로 쓰는 계약은 독립적으로 남아 있다.
    /// 이 함수는 그 좁은 경우만 허용한다.
    fn bottom_aligned_footer_grid_leading_px(
        &self,
        paragraphs: &[Paragraph],
        list_attr: u32,
        band_height_hu: u32,
    ) -> f64 {
        if (list_attr >> 21) & 0b11 != 2 || band_height_hu == 0 || paragraphs.is_empty() {
            return 0.0;
        }
        // #7333의 저장 leading은 Paper/Page 기준 그림과 쪽번호가 섞인 footer의
        // 계약이다. 도형만 든 footer에도 한 줄 grid가 있을 수 있으나 그 경우
        // 일반 footer 원점에 선행 여백을 더하면 snapshot을 이동시킨다.
        let has_picture = paragraphs.iter().any(|paragraph| {
            paragraph
                .controls
                .iter()
                .any(|control| matches!(control, Control::Picture(_)))
        });
        let has_page_number = paragraphs.iter().any(|paragraph| {
            paragraph.controls.iter().any(|control| {
                matches!(
                    control,
                    Control::AutoNumber(number)
                        if matches!(
                            number.number_type,
                            crate::model::control::AutoNumberType::Page
                                | crate::model::control::AutoNumberType::TotalPage
                        )
                )
            })
        });
        if !has_picture || !has_page_number {
            return 0.0;
        }

        let mut expected_vpos = 0_i32;
        let mut leading_hu = None;
        for paragraph in paragraphs {
            let [line] = paragraph.line_segs.as_slice() else {
                return 0.0;
            };
            if line.vertical_pos != expected_vpos || line.line_height <= 0 || line.line_spacing <= 0
            {
                return 0.0;
            }
            leading_hu.get_or_insert(line.line_spacing);
            let Some(next_vpos) = line
                .vertical_pos
                .checked_add(line.line_height)
                .and_then(|value| value.checked_add(line.line_spacing))
            else {
                return 0.0;
            };
            expected_vpos = next_vpos;
        }

        if expected_vpos > band_height_hu as i32 {
            return 0.0;
        }
        hwpunit_to_px(leading_hu.unwrap_or(0), self.dpi)
    }

    fn compose_header_footer_paragraph(
        &self,
        para: &Paragraph,
        page_number: u32,
        styles: &ResolvedStyleSet,
    ) -> ComposedParagraph {
        let mut comp = crate::renderer::composer::compose_paragraph_in_context(para, styles);
        self.substitute_hf_field_markers(&mut comp, page_number);
        if para.controls.iter().any(|ctrl| {
            matches!(ctrl, Control::AutoNumber(an)
                if an.number_type == crate::model::control::AutoNumberType::Page)
        }) {
            self.substitute_page_auto_numbers_in_composed(para, &mut comp, page_number);
        }
        if para.controls.iter().any(|ctrl| {
            matches!(ctrl, Control::AutoNumber(an)
                if an.number_type == crate::model::control::AutoNumberType::TotalPage)
        }) {
            self.substitute_total_page_auto_numbers_in_composed(
                para,
                &mut comp,
                self.total_pages.get(),
            );
        }
        comp
    }

    /// 머리말/꼬리말 ComposedParagraph의 필드 마커를 실제 값으로 치환한다.
    /// - `\u{0015}` → 현재 쪽번호
    /// - `\u{0016}` → 총 쪽수
    /// - `\u{0017}` → 파일 이름
    ///
    /// 치환 결과는 `run.text` 가 아니라 `display_text` 에 넣고, 마커 하나를 제 런으로
    /// 떼어낸다. `text` 가 모델과 같은 글자 수를 유지해야 `char_start` 와 같은 공간에
    /// 있고, 그래야 히트테스트가 모델 오프셋을 돌려준다 — `convert_pua_display_text`
    /// 가 세운 규약과 같다 (Task #3216).
    fn substitute_hf_field_markers(&self, comp: &mut ComposedParagraph, page_number: u32) {
        let total = self.total_pages.get();
        let file_name = self.file_name.borrow();

        let field_value = |ch: char| -> Option<String> {
            match ch {
                '\u{0015}' => Some(page_number.to_string()),
                '\u{0016}' => Some(total.to_string()),
                '\u{0017}' => Some(file_name.clone()),
                _ => None,
            }
        };

        for line in &mut comp.lines {
            let mut new_runs = Vec::new();
            for run in &line.runs {
                if !run.text.chars().any(|ch| field_value(ch).is_some()) {
                    new_runs.push(run.clone());
                    continue;
                }
                // 마커마다 [앞 텍스트][필드][뒤 텍스트] 로 쪼갠다. 필드 런은 모델 1자에
                // 표시값 N자라, 캐럿이 필드 안으로 들어가지 않고 앞뒤로만 놓인다.
                // 조각은 자기 글자에 맞는 표시 텍스트를 새로 갖는다. 원본 런의
                // `display_text` 는 **런 전체**에 대해 만들어진 값이라(이 함수는
                // `convert_pua_display_text` 직후에 돌아간다) 그대로 물려주면 조각이
                // 남의 글자를 그린다. 형제 `substitute_page_auto_numbers_in_composed`도
                // 원본 marker 문자열은 보존하고 해당 문단의 표시 문자열을 다시 만든다.
                let mut plain = String::new();
                let push_plain = |new_runs: &mut Vec<_>, text: String| {
                    let mut piece = run.clone();
                    piece.display_text = Self::pua_display_for(&text);
                    piece.text = text;
                    new_runs.push(piece);
                };
                for ch in run.text.chars() {
                    let Some(value) = field_value(ch) else {
                        plain.push(ch);
                        continue;
                    };
                    if !plain.is_empty() {
                        push_plain(&mut new_runs, std::mem::take(&mut plain));
                    }
                    let mut field = run.clone();
                    field.text = ch.to_string();
                    field.display_text = Some(value);
                    new_runs.push(field);
                }
                if !plain.is_empty() {
                    push_plain(&mut new_runs, plain);
                }
            }
            line.runs = new_runs;
        }
    }

    /// PUA 표시 확장이 필요한 글자가 있으면 그 표시 문자열을, 없으면 `None` 을 준다.
    ///
    /// `convert_pua_display_text` 와 같은 규칙(`expand_pua_display_text`)을 쓰되 조각
    /// 단위로 다시 만든다 — 원본 런의 값을 잘라 쓸 수 없기 때문이다(표시 길이가 모델과
    /// 다르므로 모델 인덱스로 자를 수 없다).
    fn pua_display_for(text: &str) -> Option<String> {
        let expanded = crate::renderer::composer::expand_pua_display_text(text);
        (expanded != text).then_some(expanded)
    }

    /// `AutoNumber(Page)` 컨트롤의 placeholder 문자만 현재 쪽번호로 치환한다.
    ///
    /// HWPX는 `<hp:autoNum numType="PAGE">` 뒤에 `<hp:fwSpace/>` 같은 공백 텍스트를
    /// 같은 문단에 둘 수 있다. 공백 run 전체를 쪽번호로 바꾸면 짝수 머리말처럼
    /// `쪽번호 + 전각공백 + 제목` 구조에서 쪽번호가 두 번 출력될 수 있으므로,
    /// 컨트롤 placeholder 한 글자만 치환한다.
    pub(crate) fn substitute_page_auto_numbers_in_composed(
        &self,
        para: &Paragraph,
        comp: &mut ComposedParagraph,
        page_number: u32,
    ) {
        // [#6986] 총쪽수도 함께 넘겨 한 번에 치환한다 — 따로 부르면 서로를 지운다.
        self.substitute_auto_numbers_in_composed(para, comp, page_number, self.total_pages.get());
    }

    /// `AutoNumber(TotalPage)` 컨트롤의 placeholder 문자를 문서 총 쪽수로 치환한다.
    ///
    /// HWP atno 컨트롤의 번호 종류(표 144) 값 6은 "총 쪽수" 필드다. 과거엔 파서가 이
    /// 값을 인식하지 못해 Page로 폴백했고, 렌더러도 Page 치환만 수행해서 꼬리말의
    /// 총 쪽수 상자가 현재 쪽번호와 같은 값을 두 번 표시했다 (예: "3/8" 이어야 할 것이
    /// "3/3"으로 표시).
    pub(crate) fn substitute_total_page_auto_numbers_in_composed(
        &self,
        para: &Paragraph,
        comp: &mut ComposedParagraph,
        total_pages: u32,
    ) {
        // [#6986] 현재 쪽번호도 함께 넘겨 한 번에 치환한다.
        self.substitute_auto_numbers_in_composed(
            para,
            comp,
            self.current_page_number.get(),
            total_pages,
        );
    }

    /// `AutoNumber(Page)` 와 `AutoNumber(TotalPage)` 를 **한 번에** 치환한다.
    ///
    /// [#6986] 둘을 따로 치환하면 안 된다 — 같은 런에 두 자리가 있으면 뒤 치환이
    /// `display_text` 를 `run.text` 에서 다시 만들면서 앞 치환을 버린다.
    pub(crate) fn substitute_auto_numbers_in_composed(
        &self,
        para: &Paragraph,
        comp: &mut ComposedParagraph,
        page_number: u32,
        total_pages: u32,
    ) {
        let mut replacements: Vec<(usize, String)> = Vec::new();
        for (an_type, value) in [
            (crate::model::control::AutoNumberType::Page, page_number),
            (
                crate::model::control::AutoNumberType::TotalPage,
                total_pages,
            ),
        ] {
            if value == 0 {
                continue;
            }
            let value_str = value.to_string();
            let mut positions = self.auto_number_placeholder_positions(para, an_type);
            positions.sort_unstable();
            positions.dedup();
            replacements.extend(positions.into_iter().map(|pos| (pos, value_str.clone())));
        }
        if replacements.is_empty() {
            return;
        }
        replacements.sort_unstable_by_key(|(pos, _)| *pos);
        replacements.dedup_by_key(|(pos, _)| *pos);
        Self::replace_composed_chars_with_display(comp, &replacements);
    }

    fn auto_number_placeholder_positions(
        &self,
        para: &Paragraph,
        an_type: crate::model::control::AutoNumberType,
    ) -> Vec<usize> {
        let ctrl_positions = para.control_text_positions();
        let text_chars: Vec<char> = para.text.chars().collect();
        let mut positions = Vec::new();
        let mut search_from = 0usize;

        // [#6986] 종류가 다른 `AutoNumber` 도 **자리를 소비한다.**
        //
        // 종전에는 다른 종류를 `continue` 로 건너뛰면서 `search_from` 을 전진시키지
        // 않았다. 그래서 한 문단에 `PAGE` 와 `TOTAL_PAGE` 가 같이 있으면, 두 번째
        // 종류의 폴백 탐색이 0 부터 시작해 **첫 번째 컨트롤의 자리**를 집었다.
        //
        // 법령 HWPX 의 꼬리말 표 셀이 그 형상이다 —
        // `<hp:t>- </hp:t><PAGE/><hp:t> / </hp:t><TOTAL_PAGE/><hp:t> -</hp:t>`.
        // 두 치환이 같은 자리를 쓰면 나중 것이 앞 것을 덮어, 한쪽은 총쪽수가 찍히고
        // 다른 쪽은 빈칸이 된다(`- / 187 -`). v0.8.3 에서 `TOTAL_PAGE` 치환이
        // 들어오면서 생긴 회귀다(`e69a2d286`).
        //
        // 그래서 **모든** `AutoNumber` 를 순서대로 돌며 자리를 하나씩 소비하고,
        // 그중 요청한 종류의 것만 돌려준다.
        for (ctrl_idx, ctrl) in para.controls.iter().enumerate() {
            let Control::AutoNumber(an) = ctrl else {
                continue;
            };
            let wanted = an.number_type == an_type;

            let direct_pos = ctrl_positions.get(ctrl_idx).copied().filter(|&pos| {
                Self::is_auto_number_placeholder_at(para, &text_chars, pos)
                    || text_chars
                        .get(pos)
                        .map_or(false, |ch| Self::is_auto_number_placeholder_char(*ch))
            });

            let pos = direct_pos.or_else(|| {
                Self::find_auto_number_placeholder_char(para, &text_chars, search_from)
            });

            if let Some(pos) = pos {
                if wanted {
                    positions.push(pos);
                }
                search_from = pos.saturating_add(1);
            }
        }

        positions
    }

    fn is_auto_number_placeholder_char(ch: char) -> bool {
        ch == '\u{0015}' || ch.is_whitespace()
    }

    fn is_auto_number_placeholder_at(para: &Paragraph, text_chars: &[char], idx: usize) -> bool {
        if !text_chars
            .get(idx)
            .map_or(false, |ch| Self::is_auto_number_placeholder_char(*ch))
        {
            return false;
        }

        let Some(&current) = para.char_offsets.get(idx) else {
            return false;
        };
        let next = para
            .char_offsets
            .get(idx.saturating_add(1))
            .copied()
            .unwrap_or_else(|| para.char_count.saturating_sub(1));

        next.saturating_sub(current) >= 8
    }

    fn find_auto_number_placeholder_char(
        para: &Paragraph,
        text_chars: &[char],
        search_from: usize,
    ) -> Option<usize> {
        let preferred = text_chars
            .iter()
            .enumerate()
            .skip(search_from)
            .find(|(idx, _)| Self::is_auto_number_placeholder_at(para, text_chars, *idx))
            .map(|(idx, _)| idx);

        preferred.or_else(|| {
            if !para.char_offsets.is_empty() {
                return text_chars
                    .iter()
                    .enumerate()
                    .rev()
                    .find(|(idx, ch)| {
                        *idx >= search_from && Self::is_auto_number_placeholder_char(**ch)
                    })
                    .map(|(idx, _)| idx);
            }
            text_chars
                .iter()
                .enumerate()
                .skip(search_from)
                .find(|(_, ch)| Self::is_auto_number_placeholder_char(**ch))
                .map(|(idx, _)| idx)
        })
    }

    /// AutoNumber의 모델 placeholder 한 글자를 유지한 채 표시값만 바꾼다.
    ///
    /// 같은 문단에 명시적으로 넣은 쪽번호 필드(`U+0015`)가 있어도 AutoNumber 컨트롤이
    /// 가리키는 위치만 처리해야 한다. 모든 `U+0015`를 일괄 치환하면 명시 필드의
    /// `display_text` 규약을 깨고, 필드 뒤의 캐럿이 다시 표시 문자열 공간으로 밀린다.
    ///
    /// marker와 뒤 공백을 별도 run으로 자르면 각 run의 정수 폭 반올림 때문에 SVG의
    /// 소수 glyph advance와 다음 공백의 앵커가 어긋난다. 따라서 raw `text` 전체는
    /// 그대로 두고, 그 동일 모델 run의 `display_text`만 재구성한다. 모델 길이는
    /// 보존되며 SVG는 연속 표시 문자열의 문자별 정확한 advance를 사용한다.
    /// 모델 문자 위치 → 치환 문자열 목록을 **런 단위로 한 번에** 적용한다.
    ///
    /// [#6986] 종전에는 위치 하나마다 `display_text` 를 `run.text` 에서 **새로
    /// 만들었다.** 그래서 같은 런에 치환 자리가 둘이면 뒤 치환이 앞 치환을 통째로
    /// 버렸다 — 법령 HWPX 꼬리말의
    /// `<hp:t>- </hp:t><PAGE/><hp:t> / </hp:t><TOTAL_PAGE/><hp:t> -</hp:t>` 에서
    /// `PAGE` 치환이 사라져 `- / 187 -` 로 렌더된다(v0.8.3 회귀).
    ///
    /// 위치를 모아 한 번에 재구성하면 서로를 지우지 않는다.
    fn replace_composed_chars_with_display(
        comp: &mut ComposedParagraph,
        replacements: &[(usize, String)],
    ) -> bool {
        if replacements.is_empty() {
            return false;
        }
        let mut applied = false;
        for line in &mut comp.lines {
            let mut run_start = line.char_start;
            for run_idx in 0..line.runs.len() {
                let run_len = line.runs[run_idx].text.chars().count();
                let run_end = run_start + run_len;

                let mut in_run: Vec<(usize, &str)> = replacements
                    .iter()
                    .filter(|(pos, _)| *pos >= run_start && *pos < run_end)
                    .map(|(pos, rep)| (pos - run_start, rep.as_str()))
                    .collect();
                if !in_run.is_empty() {
                    in_run.sort_unstable_by_key(|(rel, _)| *rel);
                    let chars: Vec<char> = line.runs[run_idx].text.chars().collect();
                    // 번호 자리만 든 런은 표시 숫자의 언어별 글꼴을 사용한다. 원본
                    // 공백의 한글 슬롯을 유지하면 영문 슬롯에 저장된 숫자 글꼴이
                    // 사라지고, 글상자의 오른쪽 정렬 폭까지 달라진다.
                    let replacement_lang =
                        (chars.len() == 1 && in_run.len() == 1 && in_run[0].0 == 0)
                            .then(|| in_run[0].1.chars().next())
                            .flatten()
                            .map(crate::renderer::style_resolver::detect_lang_category);
                    let mut display = String::new();
                    let mut cursor = 0usize;
                    for (rel, rep) in in_run {
                        if rel >= chars.len() {
                            continue;
                        }
                        let plain: String = chars[cursor..rel].iter().collect();
                        display
                            .push_str(&crate::renderer::composer::expand_pua_display_text(&plain));
                        display.push_str(rep);
                        cursor = rel + 1;
                    }
                    let tail: String = chars[cursor.min(chars.len())..].iter().collect();
                    display.push_str(&crate::renderer::composer::expand_pua_display_text(&tail));
                    // `line.runs[run_idx].text` 는 marker 를 포함한 원 모델 문자열이다.
                    // 바꾸지 않아야 char_start/offset 이 표시 자릿수에 끌려가지 않는다.
                    line.runs[run_idx].display_text = Some(display);
                    if let Some(lang) = replacement_lang {
                        line.runs[run_idx].lang_index = lang;
                    }
                    applied = true;
                }
                run_start = run_end;
            }
        }
        applied
    }

    /// 페이지 배경 노드를 생성하여 tree에 추가한다.
    fn build_page_background(
        &self,
        tree: &mut PageRenderTree,
        layout: &PageLayoutInfo,
        page_border_fill: Option<&PageBorderFill>,
        styles: &ResolvedStyleSet,
        bin_data_content: &[BinDataContent],
        hide_fill: bool,
    ) {
        // hide_fill: 커스텀 채우기(색/그라데이션/이미지)는 억제하되 흰 종이 바탕은 유지 (#2083).
        // [Task #2102] 쪽 배경 이미지 채우기는 구역 첫 쪽에만 적용한다(한컴 실측 정합).
        // 색/그라데이션 채우기는 이 조건과 무관하게 모든 쪽에 유지한다.
        let allow_bg_image = self.current_page_is_section_first.get();
        // [#5717] 구역정의 bit9(첫 쪽에만 배경)가 켜진 구역에서는 첫 쪽이 아니면
        // 커스텀 채우기 전체를 hide_fill 과 동일하게 억제한다(흰 종이 바탕 유지).
        // 성북구 실측: 한글은 남색 배경을 1쪽에만 칠한다 — rhwp 는 172쪽 전부였다.
        let hide_fill = hide_fill
            || (self.page_border_fill_first_page_only.get().1
                && !self.current_page_is_section_first.get());
        let (page_bg_color, page_bg_gradient, page_bg_image) = if hide_fill {
            (Some(0x00FFFFFF), None, None)
        } else if let Some(pbf) = page_border_fill {
            if pbf.border_fill_id > 0 {
                let bf_idx = (pbf.border_fill_id - 1) as usize;
                if let Some(bs) = styles.border_styles.get(bf_idx) {
                    let img = if allow_bg_image {
                        bs.image_fill.as_ref().and_then(|img_fill| {
                            find_bin_data_bytes(bin_data_content, img_fill.bin_data_id).map(
                                |data| PageBackgroundImage {
                                    data,
                                    fill_mode: img_fill.fill_mode,
                                    brightness: img_fill.brightness,
                                    contrast: img_fill.contrast,
                                    effect: img_fill.effect,
                                },
                            )
                        })
                    } else {
                        None
                    };
                    (bs.fill_color.or(Some(0x00FFFFFF)), bs.gradient.clone(), img)
                } else {
                    (Some(0x00FFFFFF), None, None)
                }
            } else {
                (Some(0x00FFFFFF), None, None)
            }
        } else {
            (Some(0x00FFFFFF), None, None)
        };

        let fill_area = if hide_fill {
            0 // 종이 바탕은 페이지 전체
        } else {
            page_border_fill
                .map(|pbf| (pbf.attr >> 3) & 0x03)
                .unwrap_or(0)
        };
        let bg_bbox = match fill_area {
            1 => BoundingBox::new(
                layout.body_area.x,
                layout.body_area.y,
                layout.body_area.width,
                layout.body_area.height,
            ),
            2 => page_border_fill
                .and_then(|pbf| pbf.border_fill_id.checked_sub(1)
                    .and_then(|index| styles.border_styles.get(index as usize))
                    .map(|style| self.page_border_bounds(layout, pbf, &style.borders)))
                .map(|bounds| {
                    // Border spacing may place outlines outside the sheet. A fill
                    // is clipped to the sheet and never leaks onto adjacent pages.
                    let left = bounds.x.clamp(0.0, layout.page_width);
                    let top = bounds.y.clamp(0.0, layout.page_height);
                    let right = (bounds.x + bounds.width).clamp(left, layout.page_width);
                    let bottom = (bounds.y + bounds.height).clamp(top, layout.page_height);
                    BoundingBox::new(left, top, right - left, bottom - top)
                })
                .unwrap_or_else(|| BoundingBox::new(0.0, 0.0, 0.0, 0.0)),
            _ => BoundingBox::new(0.0, 0.0, layout.page_width, layout.page_height),
        };

        let bg_id = tree.next_id();
        let bg_node = RenderNode::new(
            bg_id,
            RenderNodeType::PageBackground(PageBackgroundNode {
                background_color: page_bg_color,
                border_color: None,
                border_width: 0.0,
                gradient: page_bg_gradient,
                image: page_bg_image,
            }),
            bg_bbox,
        );
        tree.root.children.push(bg_node);
    }

    /// 자동 쪽번호의 최종 글자 기준선(96dpi 등의 레이아웃 좌표)이다.
    /// 꼬리말 밴드의 아래끝은 종이 높이에서 아래쪽 여백을 뺀 선이다.
    /// 밴드가 있는 경우 꼬리말 여백만 바꾼 한컴 대조군에서는 쪽번호가 이동하지 않는다.
    fn footer_page_number_y(
        &self,
        layout: &PageLayoutInfo,
        footer_area: &LayoutRect,
        font_size: f64,
    ) -> f64 {
        let margin_footer = (layout.page_height - (footer_area.y + footer_area.height)).max(0.0);
        let band_bottom = if margin_footer > 1e-6 {
            footer_area.y + margin_footer
        } else {
            // 꼬리말 밴드가 없으면 자동 번호는 남은 아래쪽 여백의 중앙을 쓴다.
            // 뺄셈으로 복구한0의 부동소수점 오차만 허용한다.
            footer_area.y + footer_area.height / 2.0
        };
        // 글상자 상단과 기준선을 혼용하지 않고 아래끝에서 기준선 여유를 뺀다.
        band_bottom - font_size / 3.0
    }

    fn page_number_baseline_y(
        &self,
        layout: &PageLayoutInfo,
        page_border_fill: Option<&PageBorderFill>,
        font_size: f64,
    ) -> Option<f64> {
        let pbf = page_border_fill.filter(|p| p.border_fill_id > 0)?;
        let paper_based = matches!(pbf.basis, PageBorderBasis::PaperBased);
        if paper_based {
            return None;
        }
        // 쪽 테두리 경로도 같은 아래쪽 여백 기준선을 소비한다.
        Some(self.footer_page_number_y(layout, &layout.footer_area, font_size))
    }

    fn page_border_bounds(
        &self,
        layout: &PageLayoutInfo,
        pbf: &PageBorderFill,
        borders: &[BorderLine; 4],
    ) -> BoundingBox {
        let paper_based = matches!(pbf.basis, PageBorderBasis::PaperBased);
        let (base_x, base_y, base_w, base_h) = if paper_based {
            (0.0, 0.0, layout.page_width, layout.page_height)
        } else {
            // Inclusion applies only to body-based borders. Use the same
            // configured story bands as pagination, even for empty stories.
            let body_top = layout.body_area.y;
            let body_bottom = body_top + layout.body_area.height;
            let top = if pbf.attr & 2 != 0 {
                layout.header_area.y.clamp(0.0, body_top)
            } else { body_top };
            let bottom = if pbf.attr & 4 != 0 {
                (layout.footer_area.y + layout.footer_area.height)
                    .clamp(body_bottom, layout.page_height)
            } else { body_bottom };
            (layout.body_area.x, top, layout.body_area.width, bottom - top)
        };

        let sp_l = hwpunit_to_px(pbf.spacing_left as i32, self.dpi);
        let sp_r = hwpunit_to_px(pbf.spacing_right as i32, self.dpi);
        let sp_t = hwpunit_to_px(pbf.spacing_top as i32, self.dpi);
        let sp_b = hwpunit_to_px(pbf.spacing_bottom as i32, self.dpi);
        let (out_l, out_r, out_t, out_b) = if paper_based {
            (0.0, 0.0, 0.0, 0.0)
        } else {
            (
                body_page_border_outset(&borders[0]),
                body_page_border_outset(&borders[1]),
                body_page_border_outset(&borders[2]),
                0.0,
            )
        };
        // 종이 기준: 종이 가장자리에서 안쪽(+)으로 spacing
        // 쪽 기준: 본문 영역에서 바깥쪽(-)으로 spacing + 선 묶음 폭만큼 확장
        // 단 하단은 footer/쪽번호 영역과 맞닿으므로 한컴처럼 spacing까지만
        // 반영한다. 상단/좌우 outset은 Stage 29 로고 정합을 유지한다.
        let (bx, by, bw, bh) = if paper_based {
            (
                base_x + sp_l,
                base_y + sp_t,
                base_w - sp_l - sp_r,
                base_h - sp_t - sp_b,
            )
        } else {
            (
                base_x - sp_l - out_l,
                base_y - sp_t - out_t,
                base_w + sp_l + sp_r + out_l + out_r,
                base_h + sp_t + sp_b + out_t + out_b,
            )
        };
        BoundingBox::new(bx, by, bw.max(0.0), bh.max(0.0))
    }

    fn build_page_borders(
        &self,
        tree: &mut PageRenderTree,
        layout: &PageLayoutInfo,
        page_border_fill: Option<&PageBorderFill>,
        styles: &ResolvedStyleSet,
    ) {
        // [#5717] 구역정의 bit8(첫 쪽에만 테두리)가 켜진 구역에서는 첫 쪽이 아니면
        // 쪽 테두리를 그리지 않는다. 꺼진 문서(코퍼스 [X,1,1] 테두리 11건)는 한글도
        // 전 쪽에 그리므로 현행 유지.
        if self.page_border_fill_first_page_only.get().0
            && !self.current_page_is_section_first.get()
        {
            return;
        }
        if let Some(pbf) = page_border_fill.filter(|p| p.border_fill_id > 0) {
            let bf_idx = (pbf.border_fill_id - 1) as usize;
            if let Some(bs) = styles.border_styles.get(bf_idx) {
                // 외곽선 위치 기준: PageBorderFill.basis (PaperBased/BodyBased).
                // 회귀 history:
                //   - task877: paper_based = (attr & 0x01) != 0 — sample16 정합, 시험지 회귀
                //   - #920: paper_based = (attr & 0x01) == 0 — 시험지 정합, sample16 회귀
                //   - #952: paper_based = true 전역 — 당시 모든 sample 정합 판정
                //   - #987: bfid 정정 + attr 존중 — 변환본 logo overlap 회귀 (#1006)
                // 정답: PageBorderFill.basis 를 직접 따른다.
                // HWP3 원본은 쪽 기준(BodyBased), HWP5/HWPX는 저장된 UI 기준에 따라
                // PaperBased/BodyBased를 분리한다.
                // 또한 머리말 conditional clip 제거 (그림 이동 시 외곽선 shrink 회귀 해소),
                // 꼬리말 clip 은 유지 (페이지 번호 외곽선 안쪽 회귀 해소 — PR #1011).
                // [Task #1029] PR #1003 cherry-pick `--theirs` 충돌 해소로 본 로직이
                // PR #987 attr 비트 해석으로 revert 되어 HWP3 native (attr=0) 만
                // body-edge 로 좁아진 시각 회귀 발생 — 본 task 에서 PR #1011 상태 복원.
                let paper_based = matches!(pbf.basis, PageBorderBasis::PaperBased);
                if std::env::var("RHWP_DEBUG_PAGE_BORDER").is_ok() {
                    eprintln!(
                        "PAGE_BORDER: attr=0x{:08x} bit0={} bit1={} bit2={} paper_based={} bfid={} spacing(L={},R={},T={},B={})",
                        pbf.attr, pbf.attr & 0x01, (pbf.attr >> 1) & 0x01, (pbf.attr >> 2) & 0x01,
                        paper_based, pbf.border_fill_id,
                        pbf.spacing_left, pbf.spacing_right, pbf.spacing_top, pbf.spacing_bottom,
                    );
                }
                let borders = &bs.borders;
                let bounds = self.page_border_bounds(layout, pbf, borders);
                let (bx, by, bw, bh) = (bounds.x, bounds.y, bounds.width, bounds.height);

                let top_nodes =
                    create_border_line_nodes(tree.frame_mut(), &borders[2], bx, by, bx + bw, by);
                for n in top_nodes {
                    tree.root.children.push(n);
                }
                let bottom_nodes = create_border_line_nodes(
                    tree.frame_mut(),
                    &borders[3],
                    bx,
                    by + bh,
                    bx + bw,
                    by + bh,
                );
                for n in bottom_nodes {
                    tree.root.children.push(n);
                }
                let left_nodes =
                    create_border_line_nodes(tree.frame_mut(), &borders[0], bx, by, bx, by + bh);
                for n in left_nodes {
                    tree.root.children.push(n);
                }
                let right_nodes = create_border_line_nodes(
                    tree.frame_mut(),
                    &borders[1],
                    bx + bw,
                    by,
                    bx + bw,
                    by + bh,
                );
                for n in right_nodes {
                    tree.root.children.push(n);
                }
            }
        }
    }

    fn header_table_area_from_page_border(
        &self,
        layout: &PageLayoutInfo,
        page_border_fill: Option<&PageBorderFill>,
    ) -> Option<LayoutRect> {
        let pbf = page_border_fill.filter(|p| p.border_fill_id > 0)?;
        if !matches!(pbf.basis, PageBorderBasis::PaperBased) {
            return None;
        }

        let left = hwpunit_to_px(pbf.spacing_left as i32, self.dpi);
        let right = layout.page_width - hwpunit_to_px(pbf.spacing_right as i32, self.dpi);
        if right <= left {
            return None;
        }

        let mut area = layout.header_area;
        area.x = left;
        area.width = right - left;
        Some(area)
    }

    /// 확장 바탕쪽을 기존 렌더 트리에 추가한다 (외부 호출용).
    pub(crate) fn build_master_page_into(
        &self,
        tree: &mut PageRenderTree,
        active_master_page: Option<&MasterPage>,
        layout: &PageLayoutInfo,
        composed: &[ComposedParagraph],
        styles: &ResolvedStyleSet,
        bin_data_content: &[BinDataContent],
        section_index: usize,
        page_number: u32,
    ) {
        self.build_master_page(
            tree,
            active_master_page,
            layout,
            composed,
            styles,
            bin_data_content,
            section_index,
            page_number,
        );
    }

    /// 바탕쪽 영역 노드를 생성하여 tree에 추가한다.
    fn build_master_page(
        &self,
        tree: &mut PageRenderTree,
        active_master_page: Option<&MasterPage>,
        layout: &PageLayoutInfo,
        composed: &[ComposedParagraph],
        styles: &ResolvedStyleSet,
        bin_data_content: &[BinDataContent],
        section_index: usize,
        page_number: u32,
    ) {
        if let Some(mp) = active_master_page {
            // 영역 0×0 바탕쪽은 MEMO 컨트롤 오분류 방어용 가드 — 렌더링 skip
            if mp.text_width == 0 && mp.text_height == 0 {
                return;
            }
            if !mp.paragraphs.is_empty() {
                let previous_page_number = self.current_page_number.get();
                // HWPX masterPage@pageNumber/hasNumRef is not a reliable signal to suppress
                // inline autoNum(PAGE) controls. exam_social.hwpx uses pageNumber=0 and
                // hasNumRef=0 even though the bottom master-page table contains the visible
                // page number. Header duplicate page numbers are handled at the AutoNumber
                // placeholder level instead of disabling master-page numbering wholesale.
                self.current_page_number.set(page_number);
                let mp_id = tree.next_id();
                let paper_area = LayoutRect {
                    x: 0.0,
                    y: 0.0,
                    width: layout.page_width,
                    height: layout.page_height,
                };
                let body_area = &layout.body_area;
                // HWP/HWPX에서 `PAGE` 기준은 물리 용지(PAPER)가 아니라 본문 영역 기준이다.
                // 바탕쪽은 본문보다 먼저 렌더링되므로 표 위치 계산용 현재 페이지 context를
                // 여기서 명시적으로 채워야 `vertRelTo=PAGE`, `horzRelTo=PAGE`가 올바르게 동작한다.
                self.current_paper_width.set(layout.page_width);
                self.current_page_height.set(layout.page_height);
                self.current_body_area.set((
                    body_area.x,
                    body_area.y,
                    body_area.width,
                    body_area.height,
                ));
                let mut mp_node = RenderNode::new(
                    mp_id,
                    RenderNodeType::MasterPage,
                    layout_rect_to_bbox(&paper_area),
                );
                // 바탕쪽 그룹에 provenance layer 부여 (#2318): layer 없는 자식(텍스트 라인 등)이
                // 상속받아 replay plane 분류에서 BehindText 상한이 적용된다.
                mp_node.layer = Some(RenderLayerInfo::new(None, 0, 0).for_master_page());
                // 바탕쪽 문단 렌더링: 컨트롤(표/도형/그림)은 compute_object_position으로 배치,
                // 텍스트 문단은 layout_paragraph로 배치
                let mut mp_y_offset = paper_area.y;
                for (pi, para) in mp.paragraphs.iter().enumerate() {
                    let has_controls = !para.controls.is_empty();
                    if has_controls {
                        for (ci, ctrl) in para.controls.iter().enumerate() {
                            let layer = self.render_layer_from_master_control(
                                ctrl,
                                pi,
                                ci,
                                &paper_area,
                                body_area,
                            );
                            let mut temp_parent = layer.map(|_| {
                                RenderNode::new(
                                    0,
                                    RenderNodeType::MasterPage,
                                    layout_rect_to_bbox(&paper_area),
                                )
                            });
                            let target_node = temp_parent.as_mut().unwrap_or(&mut mp_node);
                            match ctrl {
                                Control::Shape(_) | Control::Equation(_) => {
                                    // [바탕쪽 col_area] 바탕쪽에는 단(column)·문단 흐름이
                                    // 없다. `Para`/`Column` 기준 가로 위치는 물리 용지가
                                    // 아니라 본문 텍스트 영역을 기준으로 해석해야 한다
                                    // (한컴 정합). col_area 로 paper_area 를 그대로 넘기면
                                    // Para-Left 개체가 용지 좌단(x=0), Para-Right 개체가
                                    // 용지 우단(x=용지폭)에 붙어 좌우 여백 밖으로 튄다
                                    // (머리말 쪽번호/홀수형 상자). 세로 기준은 기존 동작을
                                    // 보존하기 위해 용지 y/height 를 유지하고, 가로(x/width)
                                    // 만 본문 영역으로 교정한다. `Paper`/`Page` 기준은
                                    // compute_object_position 에서 paper_area/body_area 를
                                    // 직접 쓰므로 이 값에 영향받지 않는다.
                                    let master_col_area = LayoutRect {
                                        x: body_area.x,
                                        y: paper_area.y,
                                        width: body_area.width,
                                        height: paper_area.height,
                                    };
                                    self.layout_shape(
                                        tree.frame_mut(),
                                        target_node,
                                        &mp.paragraphs,
                                        pi,
                                        ci,
                                        section_index,
                                        styles,
                                        &master_col_area,
                                        body_area,
                                        &paper_area,
                                        paper_area.y,
                                        Alignment::Left,
                                        bin_data_content,
                                        &std::collections::HashMap::new(),
                                        false,
                                    );
                                }
                                Control::Picture(pic) => {
                                    let (pic_w, pic_h) = self.resolve_object_size(
                                        &pic.common,
                                        &paper_area,
                                        body_area,
                                        &paper_area,
                                    );
                                    let (pic_x, pic_y) = self.compute_object_position(
                                        &pic.common,
                                        pic_w,
                                        pic_h,
                                        &paper_area,
                                        &paper_area,
                                        body_area,
                                        &paper_area,
                                        paper_area.y,
                                        Alignment::Left,
                                    );
                                    let pic_area = super::layout::LayoutRect {
                                        x: pic_x,
                                        y: pic_y,
                                        width: pic_w,
                                        height: pic_h,
                                    };
                                    let mut positioned = (**pic).clone();
                                    positioned.common.horizontal_offset = 0;
                                    positioned.common.vertical_offset = 0;
                                    positioned.common.horz_rel_to = HorzRelTo::Para;
                                    positioned.common.vert_rel_to = VertRelTo::Para;
                                    positioned.common.horz_align = HorzAlign::Left;
                                    positioned.common.vert_align = VertAlign::Top;
                                    self.layout_picture(
                                        tree.frame_mut(),
                                        target_node,
                                        &positioned,
                                        &pic_area,
                                        bin_data_content,
                                        Alignment::Left,
                                        Some(section_index),
                                        // [#4334] 바탕쪽 문단/컨트롤 로컬 인덱스(pi/ci) — 이전에는
                                        // None 이라 stableIndex 가 next_id() 폴백에 의존했다.
                                        // Control::Table/Shape 분기(위)가 이미 이 pi/ci 를
                                        // object_stable_index 계산에 쓰던 것과 같은 값.
                                        Some(pi),
                                        Some(ci),
                                        None, // [Task #1151 v4] cell_ctx: 바탕쪽 picture 는 셀 중첩 없음
                                        styles,
                                    );
                                }
                                Control::Table(t) => {
                                    let alignment = styles
                                        .para_styles
                                        .get(para.para_shape_id as usize)
                                        .map(|s| s.alignment)
                                        .unwrap_or(Alignment::Left);
                                    // 바탕쪽 표: PAPER 기준은 paper_area, PAGE 기준은 위에서 설정한
                                    // current_body_area를 통해 본문 영역으로 계산된다.
                                    self.layout_table(
                                        tree.frame_mut(),
                                        target_node,
                                        t,
                                        section_index,
                                        styles,
                                        0,
                                        &paper_area,
                                        0.0,
                                        bin_data_content,
                                        None,
                                        0,
                                        Some((pi, ci)),
                                        alignment,
                                        None,
                                        0.0,
                                        0.0,
                                        None,
                                        None,
                                        None,
                                        None,
                                        false,
                                        false,
                                        0.0,
                                        None,
                                        Self::standalone_table_char_border_fill(
                                            Some(para),
                                            t,
                                            styles,
                                        ),
                                    );
                                }
                                _ => {}
                            }
                            if let (Some(layer), Some(temp_parent)) = (layer, temp_parent.as_mut())
                            {
                                Self::push_layered_paper_children(
                                    &mut mp_node.children,
                                    temp_parent,
                                    layer,
                                );
                            }
                        }
                    } else if !para.text.is_empty() {
                        // 컨트롤 없는 텍스트 문단: vpos 기반 y 위치 사용
                        let mut comp =
                            crate::renderer::composer::compose_paragraph_in_context(para, styles);
                        self.substitute_hf_field_markers(&mut comp, page_number);
                        // 바탕쪽 탭은 레이아웃 위치 지정용이므로 탭 리더를 그리지 않음
                        comp.tab_extended.clear();
                        // LINE_SEG vpos로 문단 시작 y 결정 (빈 문단 건너뜀 보상)
                        if let Some(first_ls) = para.line_segs.first() {
                            let vpos_y =
                                paper_area.y + hwpunit_to_px(first_ls.vertical_pos, self.dpi);
                            if vpos_y > mp_y_offset {
                                mp_y_offset = vpos_y;
                            }
                        }
                        mp_y_offset = self.layout_paragraph(
                            tree.frame_mut(),
                            &mut mp_node,
                            para,
                            Some(&comp),
                            styles,
                            &paper_area,
                            mp_y_offset,
                            0,
                            usize::MAX - pi,
                            None,
                            None,
                            None, // 바탕쪽 컨텍스트 — wrap zone 무관
                        );
                    } else {
                        // 빈 문단: LINE_SEG vpos로 y 위치 갱신
                        if let Some(first_ls) = para.line_segs.first() {
                            let vpos_y =
                                paper_area.y + hwpunit_to_px(first_ls.vertical_pos, self.dpi);
                            let lh = hwpunit_to_px(first_ls.line_height, self.dpi);
                            let ls = hwpunit_to_px(first_ls.line_spacing, self.dpi);
                            mp_y_offset = (vpos_y + lh + ls).max(mp_y_offset);
                        }
                    }
                }
                // Hancom prepares master-page furniture through object order, not raw XML
                // order: text-wrap plane, zOrder, then stable source index.
                Self::sort_paper_render_nodes(&mut mp_node.children);
                tree.root.children.push(mp_node);
                self.current_page_number.set(previous_page_number);
            }
        }
    }

    #[allow(clippy::too_many_arguments)]
    /// 머리말·꼬리말에 직접 놓인 부동 그림.
    ///
    /// [#6608] 머리말·꼬리말 안 개체는 그 틀(`area`)이 배치 기준이다 — 용지(`Paper`)·
    /// 쪽(`Page`) 기준도 물리 용지나 본문 영역이 아니라 틀 원점에서 오프셋을 잰다.
    /// `pic-in-head-02.hwp` 머리말 그림(`PAPER`, 오프셋 (245, 1066)HU)을 한/글은
    /// 틀 원점 (왼쪽 여백 75.6, 위 여백 37.8)px 에서 재 (78.68, 51.94)px 에 그리는데,
    /// 종전엔 용지 (0, 0) 에서 재 (3.3, 14.2)px 였다 — 6쪽 전부 쪽 여백만큼 어긋났다.
    /// 실측은 `PAPER` 만 있고 `Page` 는 같은 틀로 푼다(본문 영역은 머리말 안에서 뜻이 없다).
    fn layout_header_footer_picture(
        &self,
        tree: &mut PageLayoutContext,
        area_node: &mut RenderNode,
        pic: &crate::model::image::Picture,
        area: &LayoutRect,
        para_y: f64,
        bin_data_content: &[BinDataContent],
        outer_section_index: Option<usize>,
        inner_para_index: usize,
        inner_control_index: usize,
        outer_hf_ref: Option<crate::renderer::render_tree::HeaderFooterImageRef>,
        // [#6284] 캡션 문단 조판에 필요하다.
        styles: &ResolvedStyleSet,
    ) {
        let rotation = pic.shape_attr.rotation_angle.rem_euclid(360);
        let uses_rotated_frame = rotation != 0
            && pic.shape_attr.current_width > 0
            && pic.shape_attr.current_height > 0
            && pic.common.width > 0
            && pic.common.height > 0;
        let (pic_width_hu, pic_height_hu) = if uses_rotated_frame {
            (
                pic.shape_attr.current_width as i32,
                pic.shape_attr.current_height as i32,
            )
        } else {
            picture_display_size_hu(pic)
        };
        let frame_width = if uses_rotated_frame {
            hwpunit_to_px(pic.common.width as i32, self.dpi)
        } else {
            hwpunit_to_px(pic_width_hu, self.dpi)
        };
        let frame_height = if uses_rotated_frame {
            hwpunit_to_px(pic.common.height as i32, self.dpi)
        } else {
            hwpunit_to_px(pic_height_hu, self.dpi)
        };

        let (frame_x, frame_y) = self.compute_object_position(
            &pic.common,
            frame_width,
            frame_height,
            area,
            area,
            area,
            area,
            para_y,
            Alignment::Left,
        );
        let mut positioned = pic.clone();
        positioned.common.horizontal_offset = 0;
        positioned.common.vertical_offset = 0;
        positioned.common.horz_rel_to = HorzRelTo::Para;
        positioned.common.vert_rel_to = VertRelTo::Para;
        positioned.common.horz_align = HorzAlign::Left;
        positioned.common.vert_align = VertAlign::Top;
        let pic_container = LayoutRect {
            x: frame_x,
            y: frame_y,
            width: frame_width,
            height: frame_height,
        };
        self.layout_picture_full(
            tree,
            area_node,
            &positioned,
            &pic_container,
            bin_data_content,
            Alignment::Left,
            outer_section_index,
            Some(inner_para_index),
            Some(inner_control_index),
            outer_hf_ref,
            None,
            styles,
        );
    }

    /// 머리말 영역 노드를 생성하여 tree에 추가한다.
    fn build_header(
        &self,
        tree: &mut PageRenderTree,
        page_content: &PageContent,
        paragraphs: &[Paragraph],
        composed: &[ComposedParagraph],
        styles: &ResolvedStyleSet,
        layout: &PageLayoutInfo,
        bin_data_content: &[BinDataContent],
        page_border_fill: Option<&PageBorderFill>,
    ) {
        let source_section = page_content
            .active_header
            .as_ref()
            .map(|reference| reference.source_section_index)
            .unwrap_or(page_content.section_index);
        let section_styles = styles.for_section(source_section);
        let styles = &section_styles;
        self.current_page_number.set(page_content.page_number);
        let header_id = tree.next_id();
        let mut header_node = RenderNode::new(
            header_id,
            RenderNodeType::Header,
            layout_rect_to_bbox(&layout.header_area),
        );
        // 감추기 플래그가 설정된 페이지는 머리말 내용을 렌더링하지 않음
        let hidden = self
            .hidden_header_footer
            .borrow()
            .contains(&(page_content.page_index, true));
        if !hidden {
            if let Some(hf_ref) = &page_content.active_header {
                {
                    if let Some(ctrl) = crate::renderer::pagination::resolve_header_footer_control(
                        paragraphs, hf_ref,
                    ) {
                        if let Control::Header(header) = ctrl {
                            let header_table_area =
                                self.header_table_area_from_page_border(layout, page_border_fill);
                            // [Task #825] 머리말 그림 hit-test marker.
                            let outer_ref = crate::renderer::render_tree::HeaderFooterImageRef {
                                outer_para_index: hf_ref.para_index,
                                outer_control_index: hf_ref.control_index,
                                kind: crate::renderer::render_tree::HeaderFooterKind::Header,
                            };
                            self.layout_header_footer_paragraphs(
                                tree.frame_mut(),
                                &mut header_node,
                                &header.paragraphs,
                                composed,
                                styles,
                                &layout.header_area,
                                &layout.body_area,
                                &LayoutRect {
                                    x: 0.0,
                                    y: 0.0,
                                    width: layout.page_width,
                                    height: layout.page_height,
                                },
                                header_table_area.as_ref(),
                                page_content.page_index,
                                page_content.page_number,
                                bin_data_content,
                                Some(hf_ref.source_section_index),
                                Some(outer_ref),
                                true,
                                header.list_attr,
                                header.text_height,
                            );
                        }
                    }
                }
            }
        }
        // Header bbox를 자식 노드 범위까지 확장 + 셀 클리핑 해제
        // (머리말 표 셀 내 Shape가 header_area 밖에 배치될 수 있음)
        Self::expand_bbox_to_children(&mut header_node);
        Self::disable_cell_clip_recursive(&mut header_node);
        // [Task #825] 머리말 안 모든 ImageNode 에 header_footer_ref 부여 + 인덱스 정규화.
        // TAC 인라인 picture 는 layout_paragraph 경로에서 para_index = usize::MAX - i 로
        // 인코딩되어 ImageNode 에 저장되므로, 본 후처리로 inner para idx 회복.
        if let Some(hf_ref) = &page_content.active_header {
            let outer_ref = crate::renderer::render_tree::HeaderFooterImageRef {
                outer_para_index: hf_ref.para_index,
                outer_control_index: hf_ref.control_index,
                kind: crate::renderer::render_tree::HeaderFooterKind::Header,
            };
            Self::propagate_header_footer_ref(
                &mut header_node,
                &outer_ref,
                hf_ref.source_section_index,
            );
        }
        tree.root.children.push(header_node);
    }

    /// Preserve source provenance without rewriting shape layout/cache keys.
    /// Images retain their existing header/footer editing address normalization.
    fn propagate_header_footer_ref(
        node: &mut RenderNode,
        outer_ref: &crate::renderer::render_tree::HeaderFooterImageRef,
        section_index: usize,
    ) {
        node.header_footer_source = Some((section_index, outer_ref.clone()));
        // CaptionOwner currently describes body controls, not an HF subList.
        // Do not publish an internal key (or a fabricated body address) as owner.
        if let RenderNodeType::TextLine(line) = &mut node.node_type {
            line.caption_owner = None;
        }
        if let RenderNodeType::Image(img) = &mut node.node_type {
            // TAC 경로 인코딩 회복: para_index 가 MAX 근처면 usize::MAX - i 로 저장된 것.
            if let Some(pi) = img.para_index {
                if pi >= usize::MAX - 1024 {
                    img.para_index = Some(usize::MAX - pi);
                }
            }
            img.section_index = Some(section_index);
            img.header_footer_ref = Some(outer_ref.clone());
        }
        for child in node.children.iter_mut() {
            Self::propagate_header_footer_ref(child, outer_ref, section_index);
        }
    }

    /// 노드의 bbox를 자식 노드 범위까지 확장
    fn expand_bbox_to_children(node: &mut RenderNode) {
        let mut min_x = node.bbox.x;
        let mut min_y = node.bbox.y;
        let mut max_x = node.bbox.x + node.bbox.width;
        let mut max_y = node.bbox.y + node.bbox.height;
        for child in &node.children {
            min_x = min_x.min(child.bbox.x);
            min_y = min_y.min(child.bbox.y);
            max_x = max_x.max(child.bbox.x + child.bbox.width);
            max_y = max_y.max(child.bbox.y + child.bbox.height);
        }
        node.bbox.x = min_x;
        node.bbox.y = min_y;
        node.bbox.width = max_x - min_x;
        node.bbox.height = max_y - min_y;
    }

    /// 자식 노드의 TableCell clip을 재귀적으로 해제
    fn disable_cell_clip_recursive(node: &mut RenderNode) {
        if let RenderNodeType::TableCell(ref mut tc) = node.node_type {
            tc.clip = false;
        }
        for child in &mut node.children {
            Self::disable_cell_clip_recursive(child);
        }
    }

    /// 꼬리말 영역 노드를 생성하여 반환한다.
    fn build_footer(
        &self,
        tree: &mut PageLayoutContext,
        page_content: &PageContent,
        paragraphs: &[Paragraph],
        composed: &[ComposedParagraph],
        styles: &ResolvedStyleSet,
        layout: &PageLayoutInfo,
        bin_data_content: &[BinDataContent],
    ) -> RenderNode {
        let source_section = page_content
            .active_footer
            .as_ref()
            .map(|reference| reference.source_section_index)
            .unwrap_or(page_content.section_index);
        let section_styles = styles.for_section(source_section);
        let styles = &section_styles;
        self.current_page_number.set(page_content.page_number);
        let footer_id = tree.next_id();
        let mut footer_node = RenderNode::new(
            footer_id,
            RenderNodeType::Footer,
            layout_rect_to_bbox(&layout.footer_area),
        );
        // 감추기 플래그가 설정된 페이지는 꼬리말 내용을 렌더링하지 않음
        let hidden = self
            .hidden_header_footer
            .borrow()
            .contains(&(page_content.page_index, false));
        // [#6186] 꼬리말 subList 의 세로 정렬.
        // LIST_HEADER `list_attr` bit 21~22 (0=위 1=가운데 2=아래) — 표 셀과 같은 규약이며
        // HWP5(`parser/control.rs`)·HWPX(`parser/hwpx/section.rs` 의 `2 << 21`) 양쪽이
        // 같은 자리에 싣는다.
        let mut footer_valign: u32 = 0;
        if !hidden {
            if let Some(hf_ref) = &page_content.active_footer {
                {
                    if let Some(ctrl) = crate::renderer::pagination::resolve_header_footer_control(
                        paragraphs, hf_ref,
                    ) {
                        if let Control::Footer(footer) = ctrl {
                            footer_valign = (footer.list_attr >> 21) & 0x03;
                            // [Task #825] 꼬리말 그림 hit-test marker.
                            let outer_ref = crate::renderer::render_tree::HeaderFooterImageRef {
                                outer_para_index: hf_ref.para_index,
                                outer_control_index: hf_ref.control_index,
                                kind: crate::renderer::render_tree::HeaderFooterKind::Footer,
                            };
                            self.layout_header_footer_paragraphs(
                                tree,
                                &mut footer_node,
                                &footer.paragraphs,
                                composed,
                                styles,
                                &layout.footer_area,
                                &layout.body_area,
                                &LayoutRect {
                                    x: 0.0,
                                    y: 0.0,
                                    width: layout.page_width,
                                    height: layout.page_height,
                                },
                                None,
                                page_content.page_index,
                                page_content.page_number,
                                bin_data_content,
                                Some(hf_ref.source_section_index),
                                Some(outer_ref),
                                false,
                                footer.list_attr,
                                footer.text_height,
                            );
                        }
                    }
                }
            }
        }
        // [#6186] 꼬리말 글을 밴드 안에서 세로 정렬한다. 종전에는 `y_offset = area.y` 로
        // 무조건 밴드 맨 위에 놓아, `vertAlign="BOTTOM"` 문서의 쪽번호가 21.8px 위에
        // 그려졌다(156755659: 겹쳐 놓인 글상자 `2 - 2` 와 두 줄로 갈라져 보인다).
        //
        // 글이 놓이는 밴드의 **아래끝은 아래쪽 여백 선**이다. `footer_area` 는 본문
        // 하단부터 **꼬리말 여백 선**까지라 아래쪽 여백만큼 더 길다(이 문서: 56.7px 대
        // 실제 37.8px — 용지 84188 / footer 2834 / bottom 4251 HU). 그 아래끝으로
        // 정렬하면 19px 더 내려간다. `margin_footer` 는 `footer_page_number_y`
        // (Task #1728)가 쓰는 것과 같은 관용구로 되찾는다.
        if footer_valign > 0 && !footer_node.children.is_empty() {
            let margin_footer =
                (layout.page_height - (layout.footer_area.y + layout.footer_area.height)).max(0.0);
            let band_bottom = layout.footer_area.y + margin_footer;
            let content_bottom = footer_node
                .children
                .iter()
                .map(|c| c.bbox.y + c.bbox.height)
                .fold(f64::MIN, f64::max);
            let slack = band_bottom - content_bottom;
            // 내용이 밴드보다 크면 종전대로 위에서 시작한다 — 위로 밀어 올리지 않는다.
            let dy = if slack > 0.0 {
                if footer_valign == 1 {
                    slack / 2.0
                } else {
                    slack
                }
            } else {
                0.0
            };
            if dy > 0.05 {
                for child in footer_node.children.iter_mut() {
                    Self::translate_subtree_y(child, dy);
                }
            }
        }
        Self::expand_bbox_to_children(&mut footer_node);
        Self::disable_cell_clip_recursive(&mut footer_node);
        // [Task #825] 꼬리말 안 모든 ImageNode 에 header_footer_ref 부여 + 인덱스 정규화.
        if let Some(hf_ref) = &page_content.active_footer {
            let outer_ref = crate::renderer::render_tree::HeaderFooterImageRef {
                outer_para_index: hf_ref.para_index,
                outer_control_index: hf_ref.control_index,
                kind: crate::renderer::render_tree::HeaderFooterKind::Footer,
            };
            Self::propagate_header_footer_ref(
                &mut footer_node,
                &outer_ref,
                hf_ref.source_section_index,
            );
        }
        footer_node
    }

    /// 각주 영역 노드를 생성하여 tree에 추가한다.
    fn build_footnote_area(
        &self,
        tree: &mut PageRenderTree,
        page_content: &PageContent,
        paragraphs: &[Paragraph],
        footnote_shape: &FootnoteShape,
        styles: &ResolvedStyleSet,
        layout: &PageLayoutInfo,
    ) {
        let mut footnote_layout = layout.clone();
        if !page_content.footnotes.is_empty() {
            let fn_height = self.estimate_footnote_area_height(
                &page_content.footnotes,
                paragraphs,
                footnote_shape,
                styles,
                layout.body_area.width,
            );
            footnote_layout.update_footnote_area(fn_height);
        }

        if !page_content.footnotes.is_empty() {
            let fn_id = tree.next_id();
            let mut fn_node = RenderNode::new(
                fn_id,
                RenderNodeType::FootnoteArea,
                layout_rect_to_bbox(&footnote_layout.footnote_area),
            );

            self.layout_footnote_area(
                tree.frame_mut(),
                &mut fn_node,
                &page_content.footnotes,
                paragraphs,
                styles,
                &footnote_layout.footnote_area,
                footnote_shape,
            );
            tree.root.children.push(fn_node);
        }
    }

    /// 쪽 번호를 렌더링한다.
    fn build_page_number(
        &self,
        tree: &mut PageRenderTree,
        footer_node: &mut RenderNode,
        page_content: &PageContent,
        styles: &ResolvedStyleSet,
        layout: &PageLayoutInfo,
        page_border_fill: Option<&PageBorderFill>,
    ) {
        // 감추기(PageHide)에서 쪽 번호 감추기가 설정되어 있으면 건너뜀
        if let Some(ref ph) = page_content.page_hide {
            if ph.hide_page_num {
                return;
            }
        }
        if let Some(pnp) = &page_content.page_number_pos {
            if pnp.position == 0 {
                return;
            }
            let page_num_text = format_page_number(
                page_content.page_number,
                pnp.format,
                pnp.prefix_char,
                pnp.suffix_char,
                pnp.dash_char,
            );
            let target_area = match pnp.position {
                1..=3 | 7 | 9 => &layout.header_area,
                _ => &layout.footer_area,
            };

            // [#3048] 스타일이 없는 pgnp 의 기본 크기는 10pt 이다. 문서에
            // `쪽 번호` 스타일이 있으면 그 글자 모양을 사용한다. 원본 PDF 의
            // #7336 쪽번호는 HCRDotum 인데, 고정 `바탕`은 폭·획·세로 위치를
            // 모두 다르게 그렸다.
            const PAGE_NUMBER_PT: f64 = 10.0;
            let page_number_char_style = styles
                .page_number_char_style_id
                .and_then(|id| styles.char_styles.get(id));
            let font_size = page_number_char_style
                .map(|style| style.font_size)
                .filter(|size| *size > 0.0)
                .unwrap_or(PAGE_NUMBER_PT * self.dpi / 72.0);

            // [#3048] 폭은 실제 폰트 메트릭으로 잰다. 종전 `문자수 × 크기 × 0.6` 은
            // 장식 공백이 든 `- 1 -`(5자)을 30pt 로 과대평가해(실측 24.8pt) 가운데·
            // 오른쪽 정렬 위치를 약 2pt 왼쪽으로 밀었다. 아래 TextRunNode 가 쓰는
            // 스타일과 **같은 값**으로 재야 측정과 렌더가 어긋나지 않는다.
            let page_num_style = TextStyle {
                font_family: page_number_char_style
                    .and_then(|style| style.font_families.get(1).or(style.font_families.first()))
                    .filter(|family| !family.is_empty())
                    .cloned()
                    .unwrap_or_else(|| "바탕".to_string()),
                font_size,
                color: page_number_char_style
                    .map(|style| style.text_color)
                    .unwrap_or(0x000000),
                ..Default::default()
            };
            let text_width = estimate_text_width(&page_num_text, &page_num_style);

            let is_odd_page = page_content.page_number % 2 == 1;
            let x = match pnp.position {
                1 | 4 => target_area.x,
                3 | 6 => target_area.x + target_area.width - text_width,
                2 | 5 => target_area.x + (target_area.width - text_width) / 2.0,
                // 바깥쪽: 홀수쪽→오른쪽, 짝수쪽→왼쪽
                7 | 8 => {
                    if is_odd_page {
                        target_area.x + target_area.width - text_width
                    } else {
                        target_area.x
                    }
                }
                // 안쪽: 홀수쪽→왼쪽, 짝수쪽→오른쪽
                9 | 10 => {
                    if is_odd_page {
                        target_area.x
                    } else {
                        target_area.x + target_area.width - text_width
                    }
                }
                _ => target_area.x + (target_area.width - text_width) / 2.0,
            };

            // 자동 꼬리말 쪽번호는 아래쪽 여백 선을 기준으로 배치한다.
            // 머리말 위치의 기존 실제 글자 배치는 이번 보정 범위 밖이다.
            let border_drawn = !page_content
                .page_hide
                .as_ref()
                .map(|ph| ph.hide_border)
                .unwrap_or(false);
            let is_footer = !matches!(pnp.position, 1..=3 | 7 | 9);
            let footer_center = if is_footer {
                self.footer_page_number_y(layout, target_area, font_size)
            } else {
                target_area.y + target_area.height / 2.0 + font_size / 3.0
            };
            // 본문 기준 테두리 경로도 공통 쪽번호 기준선을 사용한다.
            // 종이 기준 테두리·감추기 여부로 별도의 글자 원점을 만들지 않는다.
            let y = if is_footer {
                self.page_number_baseline_y(layout, page_border_fill, font_size)
                    .filter(|_| border_drawn)
                    .unwrap_or(footer_center)
            } else {
                footer_center
            };
            // 꼬리말의 줄과 글자 상자는 같은 최종 기준선을 공유한다.
            // 글꼴 이름이나 각주 유무에 따른 임시 이동은 적용하지 않는다.
            let run_y = if is_footer { y - font_size } else { y };

            let line_id = tree.next_id();
            let mut line_node = RenderNode::new(
                line_id,
                RenderNodeType::TextLine(TextLineNode::new(font_size * 1.2, font_size)),
                BoundingBox::new(x, y - font_size, text_width, font_size * 1.2),
            );

            let run_id = tree.next_id();
            let run_node = RenderNode::new(
                run_id,
                RenderNodeType::TextRun(TextRunNode {
                    text: page_num_text,
                    style: page_num_style,
                    char_shape_id: None,
                    para_shape_id: None,
                    section_index: None,
                    para_index: None,
                    char_start: None,
                    cell_context: None,
                    is_para_end: true,
                    is_line_break_end: false,
                    rotation: 0.0,
                    is_vertical: false,
                    char_overlap: None,
                    border_fill_id: 0,
                    baseline: font_size,
                    field_marker: FieldMarkerType::None,
                    layout_positions: None,
                    display_text: None,
                }),
                BoundingBox::new(x, run_y, text_width, font_size),
            );
            line_node.children.push(run_node);

            match pnp.position {
                1..=3 | 7 | 9 => tree.root.children.push(line_node),
                _ => footer_node.children.push(line_node),
            }
        }
    }

    /// 단별 콘텐츠를 레이아웃하여 body_node에 추가한다.
    #[allow(clippy::too_many_arguments)]
    fn build_columns(
        &self,
        tree: &mut PageLayoutContext,
        body_node: &mut RenderNode,
        paper_images: &mut Vec<RenderNode>,
        page_content: &PageContent,
        paragraphs: &[Paragraph],
        composed: &[ComposedParagraph],
        styles: &ResolvedStyleSet,
        bin_data_content: &[BinDataContent],
        measured_tables: &[MeasuredTable],
        layout: &PageLayoutInfo,
        outline_numbering_id: u16,
        wrap_around_paras: &[super::pagination::WrapAroundPara],
    ) {
        let mut prev_zone_y_end: f64 = 0.0;
        let mut current_zone_start_y: f64 = 0.0;
        let mut last_zone_y_offset: f64 = -1.0;
        // [Task #866 v2 Stage 3] zone 별 단 구분선 렌더용. 페이지 내 다단 zone 의 ColumnDef
        // (예: pi=2 의 2단/구분선 type=7) 를 반영하고, [Task #1333] 이후 단 구분선은
        // 이 zone emit 경로 하나에서 그린다.
        let mut prev_zone_layout_for_sep: Option<PageLayoutInfo> = None;
        let mut prev_zone_sep_y_start: f64 = 0.0;
        // [Task #853/#866] 직전 zone 의 "디자인 spacing"(1단 ColumnDef 의 `간격`, 다단은 0).
        // 한컴은 zone 전환 시 (이전 zone 디자인 spacing /2)+(새 zone /2) 만큼 세로 여백을
        // 둔다(shortcut.hwp 1쪽 헤더 띠 ColumnDef 간격=10mm → 제목↔헤더 5mm, 헤더↔본문 5mm).
        // pagination 측 process_multicolumn_break 의 동작과 동일 시멘틱.
        let design_spacing_of = |para_idx: usize| -> f64 {
            paragraphs
                .get(para_idx)
                .and_then(|p| {
                    p.controls.iter().find_map(|c| match c {
                        Control::ColumnDef(cd) if cd.column_count.max(1) <= 1 => {
                            Some(hwpunit_to_px(cd.spacing as i32, self.dpi))
                        }
                        Control::ColumnDef(_) => Some(0.0),
                        _ => None,
                    })
                })
                .unwrap_or(0.0)
        };
        let mut prev_zone_design_px: f64 = 0.0;
        let mut prev_zone_was_solo: bool = false;
        let mut prev_zone_was_multi: bool = false;
        // [Task #866 v3 Stage 1] 직전 zone 이 헤더 띠(TAC wrap=TopAndBottom 표만 보유) 였으면
        // solo_zone_pad 의 leaving 분기를 제외 (typeset.rs::leaving_is_header_band 와 동일).
        let mut prev_zone_was_header_band: bool = false;
        let mut zone_start_col_idx = 0;

        // 다단 레이아웃: body_area 전체에 걸치는 TopAndBottom 개체의 예약 높이
        // (한 단에만 할당되더라도 모든 단에 적용)
        let body_wide_reserved: Vec<(usize, f64)> = if page_content.column_contents.len() > 1 {
            self.calculate_body_wide_shape_reserved(
                paragraphs,
                &page_content.column_contents,
                &layout.body_area,
            )
        } else {
            Vec::new()
        };

        for (col_content_idx, col_content) in page_content.column_contents.iter().enumerate() {
            let zone_layout = col_content.zone_layout.as_ref().unwrap_or(layout);
            let col_idx = col_content.column_index as usize;
            let col_area_base = if col_idx < zone_layout.column_areas.len() {
                &zone_layout.column_areas[col_idx]
            } else {
                &zone_layout.body_area
            };

            let is_new_zone = (col_content.zone_y_offset - last_zone_y_offset).abs() > 0.1;
            if is_new_zone {
                prev_zone_y_end -= super::parallel_blank_tail_spacing_excess_px(
                    &page_content.column_contents[zone_start_col_idx..col_content_idx],
                    paragraphs,
                    self.dpi,
                );
                zone_start_col_idx = col_content_idx;
                // 직전 zone 의 단 구분선 emit (있다면).
                if let Some(pz) = prev_zone_layout_for_sep.take() {
                    self.emit_zone_column_separators(
                        tree,
                        body_node,
                        &pz,
                        prev_zone_sep_y_start,
                        prev_zone_y_end,
                    );
                }
                // 새 zone 의 디자인 spacing = 이 zone 첫 paragraph 의 ColumnDef `간격`(1단 한정).
                let new_zone_first_para = col_content.items.first().and_then(|it| match it {
                    PageItem::FullParagraph { para_index }
                    | PageItem::PartialParagraph { para_index, .. }
                    | PageItem::Table { para_index, .. }
                    | PageItem::PartialTable { para_index, .. }
                    | PageItem::Shape { para_index, .. } => Some(*para_index),
                    PageItem::EndnoteSeparator { .. } => None,
                });
                let new_zone_design = new_zone_first_para
                    .map(|pi| design_spacing_of(pi))
                    .unwrap_or(0.0);
                // [Task #866 v2 Stage 2/4] pagination 측 solo_zone_pad 와 동일:
                //   (1) 1단/간격=0 zone 진입·이탈, (2) [단나누기] 로 시작한 새 zone → +20px.
                // [Task #874 Case 5 v4] solo_zero 인정 범위를 spacing ≤ 1mm (283 HU) 까지
                // 확장. shortcut.hwp 의 `<스타일에서>` (pi=148) 등 일부 `<...>` 소제목 zone 은
                // ColumnDef 가 1단/spacing=1mm 으로 정의되어 있어 strict == 0 검사를 통과 못
                // 했고, 결과적으로 solo_zone_pad +16 이 누락되어 페이지 4 본문 (스타일 적용
                // 등) 줄간격이 1.92 px 까지 좁아짐. typeset.rs::tac_band_extra 가 < 4.0 px 까지
                // 인정하는 것과 동일 시멘틱.
                let new_zone_is_solo_zero = new_zone_first_para
                    .and_then(|pi| {
                        paragraphs.get(pi).map(|p| {
                            p.controls.iter().any(|c| {
                                matches!(c,
                        Control::ColumnDef(cd) if cd.column_count.max(1) <= 1 && cd.spacing <= 283)
                            })
                        })
                    })
                    .unwrap_or(false);
                // [Task #874 Case 5 v4] solo_zero leaving 인정 범위도 1mm (3.8 px) 까지 확장.
                let prev_zone_is_solo_zero = prev_zone_design_px < 4.0 && prev_zone_was_solo;
                let column_break_new_band = new_zone_first_para
                    .and_then(|pi| paragraphs.get(pi))
                    .map(|p| p.column_type == crate::model::paragraph::ColumnBreakType::Column)
                    .unwrap_or(false);
                let new_band_is_multicol = zone_layout.column_areas.len() > 1;
                let title_exit_pad = col_content_idx.checked_sub(1).and_then(|previous| {
                    let previous_para = page_content.column_contents[previous]
                        .items
                        .last()
                        .and_then(|item| match item {
                            PageItem::FullParagraph { para_index } => paragraphs.get(*para_index),
                            _ => None,
                        })?;
                    super::solo_title_exit_pad_px(
                        previous_para,
                        paragraphs.get(new_zone_first_para?)?,
                        prev_zone_design_px,
                        new_zone_design,
                        self.dpi,
                    )
                });
                let previous_zone_para = |column_index: usize| {
                    page_content.column_contents[column_index]
                        .items
                        .last()
                        .and_then(|item| match item {
                            PageItem::FullParagraph { para_index }
                            | PageItem::Table { para_index, .. } => paragraphs.get(*para_index),
                            _ => None,
                        })
                };
                let header_entry_pad = col_content_idx.checked_sub(1).and_then(|previous| {
                    super::solo_header_gap_half_px(
                        previous_zone_para(previous)?,
                        paragraphs.get(new_zone_first_para?)?,
                        self.dpi,
                    )
                });
                let header_exit_pad = col_content_idx.checked_sub(2).and_then(|title| {
                    super::solo_header_gap_half_px(
                        previous_zone_para(title)?,
                        previous_zone_para(title + 1)?,
                        self.dpi,
                    )
                });
                let solo_zone_pad = if prev_zone_was_header_band {
                    0.0
                } else if let Some(pad) = header_entry_pad.or(header_exit_pad) {
                    pad
                } else if let Some(title_exit_pad) = title_exit_pad {
                    title_exit_pad
                } else if column_break_new_band && prev_zone_was_multi && new_band_is_multicol {
                    super::multicol_band_break_pad_px(self.dpi)
                } else if new_zone_is_solo_zero || prev_zone_is_solo_zero || column_break_new_band {
                    super::solo_zone_pad_px(new_zone_is_solo_zero, prev_zone_was_multi, self.dpi)
                } else {
                    0.0
                };
                if col_content.zone_y_offset > 0.0 {
                    current_zone_start_y = prev_zone_y_end
                        + prev_zone_design_px / 2.0
                        + new_zone_design / 2.0
                        + solo_zone_pad;
                } else {
                    current_zone_start_y = 0.0;
                }
                prev_zone_design_px = new_zone_design;
                prev_zone_was_solo = new_zone_is_solo_zero
                    || (new_zone_design > 0.5
                        && new_zone_first_para
                            .and_then(|pi| paragraphs.get(pi))
                            .map(|p| {
                                p.controls.iter().any(|c| {
                                    matches!(c,
                            Control::ColumnDef(cd) if cd.column_count.max(1) <= 1)
                                })
                            })
                            .unwrap_or(false));
                prev_zone_was_multi = zone_layout.column_areas.len() >= 2;
                last_zone_y_offset = col_content.zone_y_offset;
                // 본 zone 이 다단 + 구분선 보유 시 종료 시점에 emit 하기 위해 기록.
                // [Task #1333] zone emit(emit_zone_column_separators)이 단 구분선의 단일
                // 경로다. zone_layout=None(초기 단정의·연속 페이지)은 unwrap_or(layout)로
                // page layout 을 따르며, 콘텐츠가 채워진 높이까지만 구분선을 그린다(한컴 정합).
                // 꽉 찬 페이지는 콘텐츠≈body 라 전체 높이로, 부분 페이지(섹션 끝 등)는 콘텐츠
                // 하단까지만 그려진다. body 초과분은 emit_zone_column_separators 가 캡한다.
                if zone_layout.column_areas.len() >= 2 && zone_layout.separator_type > 0 {
                    prev_zone_layout_for_sep = Some(zone_layout.clone());
                    prev_zone_sep_y_start = current_zone_start_y.max(zone_layout.body_area.y);
                } else {
                    prev_zone_layout_for_sep = None;
                }
            }

            let col_area = if current_zone_start_y > col_area_base.y {
                LayoutRect {
                    x: col_area_base.x,
                    y: current_zone_start_y,
                    width: col_area_base.width,
                    height: (col_area_base.y + col_area_base.height - current_zone_start_y)
                        .max(0.0),
                }
            } else {
                *col_area_base
            };

            let (col_node, y_offset) = self.build_single_column(
                tree,
                paper_images,
                col_content,
                page_content,
                paragraphs,
                composed,
                styles,
                bin_data_content,
                measured_tables,
                layout,
                zone_layout,
                &col_area,
                outline_numbering_id,
                wrap_around_paras,
                &body_wide_reserved,
            );

            // [Task #874 Case 5] solo-single zone (1단 ColumnDef + 1 paragraph) leaving 시
            // 마지막 paragraph 의 trailing line_spacing 을 prev_zone_y_end 에 포함하지
            // 않는다. zone 간 gap 은 design_spacing/2 + solo_zone_pad 가 담당하므로
            // trailing_ls 까지 더하면 이중 가산. 한컴 PDF 측정 (shortcut.hwp 1쪽):
            // 본문 첫 줄 top 195.3 px (Hancom) vs 210.7 px (rhwp pre) = +15.4 px
            // (≈11.5pt) 넓다. 제목 paragraph 의 trailing_ls 16 px 이 y_offset 에 포함되어
            // 다음 zone(헤더 띠 + 본문) 을 일괄 하향. zone 내부 paragraph 의 trailing_ls 는
            // 영향 없음 (y_offset 누적 자체는 유지).
            //
            // 적용 조건 (모두 만족):
            // - prev_zone_was_solo: 현재 zone 이 solo (1단 ColumnDef) — 다단 본문 zone
            //   leaving 에는 미적용 (페이지 4 "개체 모양 복사" → `<스타일에서>` 전환의
            //   본문 paragraph 줄간격이 좁아지는 사용자 피드백).
            // - last paragraph 가 TAC 헤더 띠/ `<...>` solo 가 아닐 것 — pi=81/pi=127
            //   형식의 ls=480/600 HU 는 한컴 의도 간격이므로 보존. solo 판단은
            //   진입·이탈과 같은 1mm 이하를 사용한다(pi=148의 1mm 포함).
            let last_para_idx = col_content.items.last().and_then(|it| match it {
                PageItem::FullParagraph { para_index }
                | PageItem::PartialParagraph { para_index, .. }
                | PageItem::Table { para_index, .. } => Some(*para_index),
                _ => None,
            });
            let last_para = last_para_idx.and_then(|pi| paragraphs.get(pi));
            let last_is_tac_band = last_para
                .map(|p| p.controls.iter().any(|c| matches!(c,
                    Control::Table(t) if t.common.treat_as_char
                        && matches!(t.common.text_wrap, crate::model::shape::TextWrap::TopAndBottom))))
                .unwrap_or(false);
            let last_is_solo_text = last_para
                .map(|p| {
                    p.controls.iter().any(|c| {
                        matches!(c,
                    Control::ColumnDef(cd) if cd.column_count.max(1) <= 1 && cd.spacing <= 283)
                    }) && p.text.trim_start().starts_with('<')
                })
                .unwrap_or(false);
            let apply_trailing_ls_subtract =
                prev_zone_was_solo && !last_is_tac_band && !last_is_solo_text;
            let last_para_trailing_ls = if apply_trailing_ls_subtract {
                last_para
                    .and_then(|p| p.line_segs.last())
                    .map(|ls| hwpunit_to_px(ls.line_spacing, self.dpi))
                    .unwrap_or(0.0)
            } else {
                0.0
            };
            let y_offset_no_trailing = (y_offset - last_para_trailing_ls).max(0.0);

            if y_offset_no_trailing > prev_zone_y_end {
                prev_zone_y_end = y_offset_no_trailing;
            }
            // [Task #866] 헤더 띠의 저장 줄 수로 잔여 높이를 구분한다. 한 줄 표는
            // 소비한 아래 여백을 빼고, 선행 줄을 포함한 표는 그 줄이 소비한 몫을 뺀다.
            // 이전의 items 수와 band/2 추정은 같은 31.09px 띠에서도 2·3쪽 본문
            // 첫 줄을 각각 +4.59px, −8.21px 어긋나게 했다.
            prev_zone_was_header_band = false;
            if let Some(last_para_idx) = col_content.items.last().and_then(|it| match it {
                PageItem::Table { para_index, .. } => Some(*para_index),
                _ => None,
            }) {
                if let Some(p) = paragraphs.get(last_para_idx) {
                    let cd_gap_zero = if p
                        .controls
                        .iter()
                        .any(|c| matches!(c, Control::ColumnDef(_)))
                    {
                        p.controls.iter().any(|c| matches!(c,
                            Control::ColumnDef(cd) if cd.column_count.max(1) <= 1 && cd.spacing == 0))
                    } else {
                        (0..last_para_idx)
                            .rev()
                            .find_map(|i| {
                                paragraphs.get(i).and_then(|pp| {
                                    pp.controls.iter().find_map(|c| match c {
                                        Control::ColumnDef(cd) => {
                                            Some(cd.column_count.max(1) <= 1 && cd.spacing <= 283)
                                        }
                                        _ => None,
                                    })
                                })
                            })
                            .unwrap_or(false)
                    };
                    if cd_gap_zero {
                        if let Some((band, partial_tail)) =
                            p.controls.iter().find_map(|c| match c {
                                Control::Table(t)
                                    if t.common.treat_as_char
                                        && matches!(
                                            t.common.text_wrap,
                                            crate::model::shape::TextWrap::TopAndBottom
                                        ) =>
                                {
                                    Some((
                                        super::single_tac_header_tail_px(
                                            t.common.height,
                                            t.outer_margin_top,
                                            self.dpi,
                                        ),
                                        super::partial_tac_header_tail_px(
                                            t.common.height,
                                            t.outer_margin_bottom,
                                            p.line_segs.last().map_or(0, |line| line.line_spacing),
                                            self.dpi,
                                        ),
                                    ))
                                }
                                _ => None,
                            })
                        {
                            // 저장 줄이 하나면 소비한 아래 여백을 다시 예약하지 않는다. 둘 이상이면
                            // 선행 줄의 소비를 뺀 공통 잔여 높이를 조판과 같이 쓴다.
                            if p.line_segs.len() <= 1 {
                                prev_zone_y_end += band;
                            } else {
                                prev_zone_y_end += partial_tail;
                            }
                            prev_zone_was_header_band = true;
                        }
                    }
                }
            }
            body_node.children.push(col_node);
        }

        // 마지막 zone 의 단 구분선 emit.
        if let Some(pz) = prev_zone_layout_for_sep.take() {
            self.emit_zone_column_separators(
                tree,
                body_node,
                &pz,
                prev_zone_sep_y_start,
                prev_zone_y_end,
            );
        }
    }

    /// [Task #866 v2 Stage 3] 단일 zone 의 단 구분선을 emit.
    /// zone_layout 기준 + y 범위 인자로 단 구분선을 그린다.
    fn emit_zone_column_separators(
        &self,
        tree: &mut PageLayoutContext,
        body_node: &mut RenderNode,
        zone_layout: &PageLayoutInfo,
        y_start: f64,
        y_end: f64,
    ) {
        // [Task #1333 v2] 콘텐츠 높이(y_end)가 body 영역 하단을 넘으면 하단에서 자른다.
        // 꽉 찬 페이지에서 prev_zone_y_end 가 trailing 간격 등으로 body 를 초과해 구분선이
        // 페이지 밖까지 그려지던 결함(예: 대상문서 p22 105%) 정정. 부분 페이지(콘텐츠 < body
        // 하단)와 sub-page zone 은 영향 없음.
        let body_bottom = zone_layout.body_area.y + zone_layout.body_area.height;
        let y_end = y_end.min(body_bottom);
        if zone_layout.column_areas.len() < 2 || zone_layout.separator_type == 0 || y_end <= y_start
        {
            return;
        }
        let line_width = border_width_to_px(zone_layout.separator_width).max(0.5);
        let dash = match zone_layout.separator_type {
            2 => StrokeDash::Dash,
            3 => StrokeDash::Dot,
            4 => StrokeDash::DashDot,
            5 => StrokeDash::DashDotDot,
            6 => StrokeDash::Dash,
            7 => StrokeDash::Dot,
            _ => StrokeDash::Solid,
        };
        for i in 0..zone_layout.column_areas.len() - 1 {
            let left = &zone_layout.column_areas[i];
            let right = &zone_layout.column_areas[i + 1];
            let (left, right) = if left.x <= right.x {
                (left, right)
            } else {
                (right, left)
            };
            let sep_x = (left.x + left.width + right.x) / 2.0;
            let sep_id = tree.next_id();
            let sep_line = LineNode::new(
                sep_x,
                y_start,
                sep_x,
                y_end,
                LineStyle {
                    color: zone_layout.separator_color,
                    width: line_width,
                    dash,
                    ..Default::default()
                },
            );
            let sep_bbox = sep_line.ink_bbox();
            let sep_node = RenderNode::new(sep_id, RenderNodeType::Line(sep_line), sep_bbox);
            body_node.children.push(sep_node);
        }
    }

    /// 단일 단의 콘텐츠를 레이아웃한다.
    #[allow(clippy::too_many_arguments)]
    /// [Task #1363 v3 옵션 3] 미주 단의 전 items 를 scratch 로 **1회 순차 레이아웃**해 정확한
    /// 렌더 단 bottom(px, col_area 상대)을 반환한다. per-para 고립 측정 + HeightCursor 시뮬의
    /// 컨텍스트 의존·순차 상호작용(vpos forward-jump ↔ trailing) 발산을 회피한다 — 렌더
    /// 코드(`build_single_column`) 자체로 측정하므로 sim==render 가 구조적으로 보장된다.
    ///
    /// `items`/`paragraphs`/`composed` 는 호출부에서 단 items 만 추출해 **로컬 0-기반 재색인**해
    /// 전달한다. `col_area` 는 상대 프레임(`y=0`)으로 둔다. 표/그림 개체는 measured_tables/
    /// bin_data 없이 측정(미주 단은 텍스트/수식 지배 — 표 미주는 근사). numbering/overflow 등
    /// 상태는 매 호출 새 scratch 엔진이라 격리된다([[tech_endnote_overflow_nonmonotonic_gate]]).
    pub(crate) fn measure_endnote_column_bottom(
        &self,
        items: Vec<PageItem>,
        paragraphs: &[Paragraph],
        composed: &[ComposedParagraph],
        styles: &ResolvedStyleSet,
        col_area: &LayoutRect,
        start_height: f64,
        section_index: usize,
        between_notes_hu: i32,
    ) -> f64 {
        self.endnote_between_notes_hu.set(between_notes_hu);
        // 로컬 paras 는 전부 미주 para(0-기반 재색인). `endnote_para_base=0` 으로 미주 vpos
        // 정규화 경로(`endnote_line_vpos_base`: para_index >= base)를 활성화한다 — 미설정 시
        // usize::MAX 라 정규화가 꺼져 para 의 절대 파일-vpos 가 그대로 새어 단독 측정이
        // 폭발한다(수식 para 35px→13721px).
        self.endnote_para_base.set(0);
        let layout_info = PageLayoutInfo {
            page_width: col_area.width,
            page_height: col_area.y + col_area.height,
            header_area: *col_area,
            body_area: *col_area,
            column_areas: vec![*col_area],
            column_direction: crate::model::page::ColumnDirection::LeftToRight,
            footnote_area: *col_area,
            footer_area: *col_area,
            dpi: self.dpi,
            separator_type: 0,
            separator_width: 0,
            separator_color: 0,
            pagination_tolerance_px: 0.0,
        };
        let col_content = ColumnContent {
            column_index: 0,
            start_height,
            endnote_flow: true,
            items,
            zone_layout: None,
            zone_y_offset: 0.0,
            wrap_around_paras: Vec::new(),
            used_height: 0.0,
            wrap_anchors: std::collections::HashMap::new(),
            overlay_continuations: Vec::new(),
            overlay_cuts: Vec::new(),
            inline_placements: Default::default(),
            inline_flow_plans: Default::default(),
            paragraph_float_placements: Default::default(),
        };
        let page_content = PageContent {
            page_index: 0,
            page_number: 0,
            page_number_restarted: false,
            section_index,
            layout: layout_info.clone(),
            column_contents: Vec::new(),
            active_header: None,
            active_footer: None,
            page_number_pos: None,
            page_hide: None,
            footnotes: Vec::new(),
            active_master_page: None,
            extra_master_pages: Vec::new(),
            ladder_band_tables: Vec::new(),
        };
        // [#4277] 높이 측정 전용 — paint 트리가 아니라 흐름 상태만 만든다.
        let mut frame = PageLayoutContext::new(0, col_area.width, col_area.y + col_area.height);
        let mut paper_images: Vec<RenderNode> = Vec::new();
        let (_node, y_offset) = self.build_single_column(
            &mut frame,
            &mut paper_images,
            &col_content,
            &page_content,
            paragraphs,
            composed,
            styles,
            &[],
            &[],
            &layout_info,
            &layout_info,
            col_area,
            0,
            &[],
            &[],
        );
        // y_offset 은 col_area 절대 프레임의 단 콘텐츠 bottom. 호출부가 `current_height`
        // (=col_area.y 가 단 시작) 프레임과 정합하도록 그대로 반환한다.
        y_offset
    }

    /// [Task #2120] 문단 테두리/배경 연속 그룹 병합 렌더링 (Task #321 v6) —
    /// 원본 무변경 통이동. stroke signature 병합 + 그룹 사각형/테두리 방출.
    #[allow(clippy::too_many_arguments)]
    fn render_para_border_groups(
        &self,
        tree: &mut PageLayoutContext,
        composed: &[ComposedParagraph],
        col_node: &mut RenderNode,
        styles: &ResolvedStyleSet,
        col_area: &LayoutRect,
    ) {
        let ranges = self.para_border_ranges.borrow();
        if !ranges.is_empty() {
            // 연속 ranges 를 시각적 stroke signature 로 병합 (Task #321 v6 근본 수정).
            // bf_id 가 달라도 동일한 stroke (line_type/width/color) 면 HWP/PDF 처럼 하나의
            // 사각형으로 보이도록 병합. invisible (any_w=false) 그룹은 별개로 유지.
            use crate::model::style::BorderLineType;
            type StrokeSig = Option<(BorderLineType, u8, u32)>;
            let stroke_sig = |bf_id: u16| -> StrokeSig {
                let idx = (bf_id as usize).saturating_sub(1);
                let bs = styles.border_styles.get(idx)?;
                let top = &bs.borders[2];
                let any_w = bs
                    .borders
                    .iter()
                    .any(|b| !matches!(b.line_type, BorderLineType::None));
                if any_w {
                    Some((top.line_type, top.width, top.color))
                } else {
                    None
                }
            };
            let connects = |pi: usize| {
                composed
                    .get(pi)
                    .and_then(|p| styles.para_styles.get(p.para_style_id as usize))
                    .is_some_and(|style| style.border_connect)
            };
            // 그룹 튜플: (bf_id, x, y_start, w, y_end, top_inset, bottom_inset,
            //              is_partial_start, is_partial_end, first_para_idx, last_para_idx)
            let mut groups: Vec<(u16, f64, f64, f64, f64, f64, f64, bool, bool, usize, usize)> =
                Vec::new();
            for &(
                bf_id,
                x,
                y_start,
                w,
                y_end,
                top_inset,
                bottom_inset,
                is_partial_start,
                is_partial_end,
                para_idx,
            ) in ranges.iter()
            {
                if let Some(last) = groups.last_mut() {
                    // bf_id 가 동일하면 기존 동작과 호환 (1차 병합).
                    // 다른 bf_id 지만 동일한 visible stroke 인 경우에만 시각 병합 (None ≠ None 으로 처리).
                    let last_sig = stroke_sig(last.0);
                    let cur_sig = stroke_sig(bf_id);
                    let same_visual = if last.0 == bf_id {
                        true
                    } else {
                        last_sig.is_some() && last_sig == cur_sig
                    };
                    if same_visual
                        && (last.10 == para_idx || connects(last.10))
                        && (y_start - last.4) < 30.0
                    {
                        last.4 = y_end;
                        last.6 = bottom_inset;
                        // 그룹의 partial_end 는 마지막 range 의 값으로 갱신.
                        // partial_start 는 첫 range 값(last.7)을 유지.
                        last.8 = is_partial_end;
                        last.10 = para_idx; // last_para_idx 갱신
                                            // Task #463: 첫 항목이 PartialParagraph (좁은 geometry, 예: pi=50
                                            // 우측 단 시작) 이고 후속 항목이 넓은 geometry 일 때, 박스가 좁게
                                            // 굳어 후속 paragraph 가 박스 밖으로 튀어나오는 것을 방지하기 위해
                                            // merge 그룹의 x/width 를 최대 범위로 확장한다.
                        let last_right = last.1 + last.3;
                        let cur_right = x + w;
                        let new_x = last.1.min(x);
                        let new_right = last_right.max(cur_right);
                        last.1 = new_x;
                        last.3 = new_right - new_x;
                        continue;
                    }
                }
                groups.push((
                    bf_id,
                    x,
                    y_start,
                    w,
                    y_end,
                    top_inset,
                    bottom_inset,
                    is_partial_start,
                    is_partial_end,
                    para_idx,
                    para_idx,
                ));
            }

            // Task #468: cross-column 박스 연속 검출.
            // sequential 인접 paragraph 가 같은 stroke_sig 면 박스가 다른 컬럼/페이지로 이어진 것.
            // [Task #471] bf_id 비교가 아닌 stroke_sig 비교 — 머지(Task #321 v6)가 visual
            // stroke 기준으로 동작하므로 그룹의 g.0 bf_id 는 첫 range 의 bf_id 만 보존됨.
            // 그룹의 visual sig 와 인접 paragraph 의 visual sig 비교가 정확.
            for g in groups.iter_mut() {
                let bf_id = g.0;
                if bf_id == 0 {
                    continue;
                }
                let first_pi = g.9;
                let last_pi = g.10;
                let group_sig = stroke_sig(bf_id);
                if group_sig.is_none() {
                    continue;
                }

                let para_bf = |pi: usize| -> u16 {
                    composed
                        .get(pi)
                        .and_then(|c| styles.para_styles.get(c.para_style_id as usize))
                        .map(|s| s.border_fill_id)
                        .unwrap_or(0)
                };

                if !g.7 && first_pi > 0 && connects(first_pi - 1) {
                    let prev_sig = stroke_sig(para_bf(first_pi - 1));
                    if prev_sig.is_some() && prev_sig == group_sig {
                        g.7 = true;
                    }
                }

                if !g.8 && connects(last_pi) {
                    let next_sig = stroke_sig(para_bf(last_pi + 1));
                    if next_sig.is_some() && next_sig == group_sig {
                        g.8 = true;
                    }
                }
            }

            // Task #445: paragraph border 가 col_area 바닥을 넘지 않도록 클램프.
            // vpos-reset 미지원으로 paragraph 가 col_bottom 너머에 layout 될 수 있는데,
            // border 까지 따라가면 페이지/꼬리말 영역까지 침범 (예: exam_kor p8 의 1671px).
            // 텍스트 자체의 overflow 처리는 별도 이슈.
            let col_top = col_area.y;
            let col_bot = col_area.y + col_area.height;
            for g in groups.iter_mut() {
                if g.2 < col_top {
                    g.2 = col_top;
                }
                if g.4 > col_bot {
                    g.4 = col_bot;
                }
            }
            groups.retain(|g| g.4 > g.2);

            let groups_len = groups.len();
            for (
                gi,
                (
                    bf_id,
                    x,
                    y_start,
                    w,
                    y_end,
                    top_inset,
                    bottom_inset,
                    is_partial_start,
                    is_partial_end,
                    first_para_idx,
                    _,
                ),
            ) in groups.clone().into_iter().enumerate()
            {
                let height = y_end - y_start;
                if height <= 0.0 {
                    continue;
                }
                // 인접한 다른 border 그룹 (간격 < 4px) 과는 inset 충돌 회피.
                let prev_touches = gi > 0 && (y_start - groups[gi - 1].4) < 4.0;
                let next_touches = gi + 1 < groups_len && (groups[gi + 1].2 - y_end) < 4.0;
                let idx = (bf_id as usize).saturating_sub(1);
                let border_style = styles.border_styles.get(idx);
                let fill_color = border_style.and_then(|bs| bs.fill_color);
                let borders = border_style.map(|bs| bs.borders);
                let stroke_width = borders
                    .map(|borders| {
                        borders
                            .iter()
                            .filter(|border| para_border_is_visible(border))
                            .map(|border| {
                                super::layout::border_rendering::border_width_to_px(border.width)
                            })
                            .fold(0.0, f64::max)
                    })
                    .unwrap_or(0.0);
                // Task #321 v6: ParaShape::border_spacing 정식 반영 + stroke 있을 때 default 2px 최소.
                // 인접 border 그룹과 충돌 방지를 위해 인접 경계는 inset 0.
                let default_min_inset: f64 = if connects(first_para_idx) { 2.0 } else { 0.0 };
                let top_pad = if stroke_width > 0.0 && !prev_touches {
                    top_inset.max(default_min_inset)
                } else {
                    top_inset
                };
                let bot_pad = if stroke_width > 0.0 && !next_touches {
                    bottom_inset.max(default_min_inset)
                } else {
                    bottom_inset
                };
                // Task #469: cross-column / cross-page 로 이어진 partial 박스의 후속 부분은
                // 이전/다음 컬럼에서 이미 inset 이 적용되었으므로 여기서 다시 col_top/col_bot
                // 너머로 박스를 확장하면 안 된다 (헤더선/꼬리말선과 충돌).
                // y_start/y_end 는 L1707 에서 col_top..col_bot 으로 이미 클램프됨.
                let effective_top_pad = if is_partial_start { 0.0 } else { top_pad };
                let effective_bot_pad = if is_partial_end { 0.0 } else { bot_pad };
                let rect_y = y_start - effective_top_pad;
                let rect_h = height + effective_top_pad + effective_bot_pad;
                // Wrap inner edge 처리: partial_start 면 top, partial_end 면 bottom 미렌더링.
                let skip_top = stroke_width > 0.0 && is_partial_start;
                let skip_bottom = stroke_width > 0.0 && is_partial_end;
                let can_use_rect_stroke = borders
                    .map(|borders| para_border_can_use_rect_stroke(&borders, skip_top, skip_bottom))
                    .unwrap_or(false);
                if can_use_rect_stroke {
                    // 기존 경로: 단일 Rectangle (fill + 4면 stroke)
                    let stroke_border = borders.expect("can_use_rect_stroke requires borders")[0];
                    let rect_id = tree.next_id();
                    let rect_node = RenderNode::new(
                        rect_id,
                        RenderNodeType::Rectangle(super::render_tree::RectangleNode::new(
                            0.0,
                            super::ShapeStyle {
                                fill_color,
                                stroke_color: Some(stroke_border.color),
                                stroke_width: super::layout::border_rendering::border_width_to_px(
                                    stroke_border.width,
                                ),
                                ..Default::default()
                            },
                            None,
                        )),
                        super::render_tree::BoundingBox::new(x, rect_y, w, rect_h),
                    );
                    col_node.children.insert(0, rect_node);
                } else {
                    // wrap 케이스: fill 만 Rectangle 로, stroke 는 면별 LineNode 로 분해.
                    if fill_color.is_some() {
                        let rect_id = tree.next_id();
                        let rect_node = RenderNode::new(
                            rect_id,
                            RenderNodeType::Rectangle(super::render_tree::RectangleNode::new(
                                0.0,
                                super::ShapeStyle {
                                    fill_color,
                                    stroke_color: None,
                                    stroke_width: 0.0,
                                    ..Default::default()
                                },
                                None,
                            )),
                            super::render_tree::BoundingBox::new(x, rect_y, w, rect_h),
                        );
                        col_node.children.insert(0, rect_node);
                    }
                    let mut push_border_line =
                        |border: &BorderLine, x1: f64, y1: f64, x2: f64, y2: f64| {
                            if !para_border_is_visible(border) {
                                return;
                            }
                            let nodes = super::layout::border_rendering::create_border_line_nodes(
                                tree, border, x1, y1, x2, y2,
                            );
                            for node in nodes {
                                col_node.children.insert(0, node);
                            }
                        };
                    let x_left = x;
                    let x_right = x + w;
                    let y_top = rect_y;
                    let y_bot = rect_y + rect_h;
                    if let Some(borders) = borders {
                        push_border_line(&borders[0], x_left, y_top, x_left, y_bot);
                        push_border_line(&borders[1], x_right, y_top, x_right, y_bot);
                        if !skip_top {
                            push_border_line(&borders[2], x_left, y_top, x_right, y_top);
                        }
                        if !skip_bottom {
                            push_border_line(&borders[3], x_left, y_bot, x_right, y_bot);
                        }
                    }
                }
            }
        }
    }

    /// 단(column) 콘텐츠 레이아웃 전에 페이지 좌표계 상태를 채운다.
    /// build_single_column 과 [#4149] 셀 커서 fast path 프로브가 공유한다 —
    /// 프로브가 전량 빌드와 동일한 좌표계(용지 폭/본문 영역)에서 동작해야
    /// cell_units 메모 등 포인터-키 캐시가 동일 값으로 채워진다.
    pub(crate) fn prime_column_layout_env(&self, layout: &PageLayoutInfo) {
        // 현재 페이지 용지 너비 설정 (표 HorzRelTo::Paper 위치 계산용)
        self.current_paper_width.set(layout.page_width);
        // [#3637] 쪽 높이도 여기서 채운다. 바탕쪽 분기(위)에서만 채우면 바탕쪽 없는
        // 문서에서 0 으로 남아 셀 넘침 진단이 통째로 침묵한다.
        self.current_page_height.set(layout.page_height);
        // 현재 페이지 본문 영역 설정 (표 HorzRelTo::Page / VertRelTo::Page 계산용 — Task #347)
        let ba = &layout.body_area;
        self.current_body_area
            .set((ba.x, ba.y, ba.width, ba.height));

        // 문단 테두리 범위 수집 초기화
        self.para_border_ranges.borrow_mut().clear();
    }

    fn build_single_column(
        &self,
        tree: &mut PageLayoutContext,
        paper_images: &mut Vec<RenderNode>,
        col_content: &ColumnContent,
        page_content: &PageContent,
        paragraphs: &[Paragraph],
        composed: &[ComposedParagraph],
        styles: &ResolvedStyleSet,
        bin_data_content: &[BinDataContent],
        measured_tables: &[MeasuredTable],
        layout: &PageLayoutInfo,
        zone_layout: &PageLayoutInfo,
        col_area: &LayoutRect,
        outline_numbering_id: u16,
        wrap_around_paras: &[super::pagination::WrapAroundPara],
        body_wide_reserved: &[(usize, f64)],
    ) -> (RenderNode, f64) {
        let col_node_id = tree.next_id();
        tree.current_physical_selections.register_frame(col_node_id,page_content,col_content,col_area);
        let mut col_node = RenderNode::new(
            col_node_id,
            RenderNodeType::Column(col_content.column_index),
            layout_rect_to_bbox(col_area),
        );
        // [#3820 Stage 72] typeset은 wrap 문단을 실제 anchor 표가 있는 column에
        // 기록한다. PaginationResult의 전역 목록은 이전 호환 필드라 현재 경로에서는
        // 비어 있다. 전역 목록만 넘기면 기록된 prefix가 layout까지 전달되지 않아
        // right-side Square 표 옆 본문이 소실된다(issue4090 p5/p7/p15/p17).
        // 전역 목록은 기존 synthetic/legacy caller의 fallback으로만 보존한다.
        let column_wrap_around_paras = if col_content.wrap_around_paras.is_empty() {
            wrap_around_paras
        } else {
            &col_content.wrap_around_paras
        };

        self.prime_column_layout_env(layout);
        self.column_is_endnote_flow.set(col_content.endnote_flow);

        // TopAndBottom 글상자/표/이미지의 앵커 문단별 예약 높이 목록
        let mut shape_reserved = self.calculate_shape_reserved_heights(
            paragraphs,
            &col_content.items,
            col_area,
            &layout.body_area,
        );
        // body_area 전체에 걸치는 개체의 예약 높이 병합 (현재 단에도 반영)
        for &(pi, bottom_y) in body_wide_reserved {
            if let Some(existing) = shape_reserved.iter_mut().find(|(p, _)| *p == pi) {
                if bottom_y > existing.1 {
                    existing.1 = bottom_y;
                }
            } else {
                shape_reserved.push((pi, bottom_y));
            }
        }
        let allow_negative_visual_start = col_content.endnote_flow
            && col_content.start_height < -0.5
            && col_content
                .items
                .first()
                .map(|item| page_item_is_treat_as_char_picture_only(item, paragraphs))
                .unwrap_or(false);
        let start_shift = if allow_negative_visual_start {
            col_content.start_height.min(0.0)
        } else {
            0.0
        };
        let visual_col_y = col_area.y + start_shift;
        let visual_col_height = col_area.height - start_shift;
        let mut y_offset = visual_col_y;
        // [미주 구분선 아래 여백] 구분선 직후 첫 미주 본문 y 를 구분선의 belowLine 바닥
        // (layout_endnote_separator_item 반환 new_y)으로 floor 한다. 저장 vpos 가 구분선
        // 위(문서끝 재배치된 미주)여도 구분선 아래로 내려 텍스트 가림을 막는다. 정상 vpos
        // (구역끝 미주)는 이미 new_y 이상이라 max 로 불변.
        let mut endnote_sep_body_floor: Option<f64> = None;
        // body_area 전체에 걸치는 개체: 단 시작 y_offset을 개체 하단 아래로 초기화
        for &(_, bottom_y) in body_wide_reserved {
            if bottom_y > y_offset {
                y_offset = bottom_y;
            }
        }
        // [#5792] 앞 쪽에서 잘린 overlay 표의 잔여 행(#4568)이 이 단 상단을 차지하는
        // 형상에서는 본문 흐름이 그 아래에서 시작한다. `reserve_px` 는 typeset 이
        // 같은 값으로 예약한 높이다 — 예약이 0 인 조각(#4514 필러 형상)은 종전대로
        // 흐름을 밀지 않는다. 예약하지 않으면 본문 문단이 잔여 행과 같은 y 에서
        // 시작해 글자가 겹치고, 그 본문이 배치한 표가 잔여 행의 페인트 상한을 깎아
        // 남은 행이 통째로 사라진다.
        let overlay_top_reserve = col_content
            .overlay_continuations
            .iter()
            .map(|cont| cont.reserve_px)
            .fold(0.0_f64, f64::max);
        if overlay_top_reserve > 0.0 {
            y_offset = y_offset.max(col_area.y + overlay_top_reserve);
        }
        // [Task #901 Stage 8/10] TopAndBottom flow-around: anchor paragraph 의 text 가 picture
        // 위에 fit 가능하면 pre-jump skip, render 후 post-jump 적용.
        // (bottom_y, anchor_first_vpos) — Stage 10: vpos_lazy_base 를 anchor first vpos 로
        // 직접 설정. file vpos 가 anchor 첫 줄 vpos 기준 누적이므로, lazy_base 를 anchor
        // 첫 줄 vpos 로 두면 후속 paragraph 의 end_y = col_anchor_y + (vpos_end - first_vpos)
        // → file 의 누적 vpos 가 정확히 visual y 로 매핑됨.
        let mut pending_topbottom_post_jump: Option<(f64, i32)> = None;
        // [Task #412] vpos 보정 anchor: 첫 PageItem 이 실제 렌더링되는 y_offset.
        // body_wide_reserved 푸시 후의 y_offset 이 첫 항목의 vpos(=base) 에 대응됨.
        // 이를 anchor 로 사용해야 vpos→y 변환이 정확함 (col_area.y 는 단 영역 top
        // 으로 vpos=0 이 아니라 vpos=base 도 아닌 일반적으로 어긋난 값).
        let col_anchor_y = y_offset;

        let mut para_start_y: std::collections::HashMap<usize, f64> =
            std::collections::HashMap::new();
        let mut para_float_lanes: ParaFloatLanes = std::collections::HashMap::new();
        let mut visible_float_exclusions: Vec<VisibleFloatExclusion> = Vec::new();
        // Fixed-position textboxes do not depend on the paragraph cursor. Paint
        // them once before flow layout so following tables see their grown bounds.
        // Blank anchor paragraphs must not consume these object heights again.
        self.layout_column_shapes_pass(
            tree,
            &mut col_node,
            paper_images,
            col_content,
            page_content,
            paragraphs,
            composed,
            styles,
            bin_data_content,
            layout,
            col_area,
            &para_start_y,
            Some(&mut visible_float_exclusions),
        );
        fixed_textbox_flow::merge_fixed_bands(&mut visible_float_exclusions);
        // [Task #1151 v9 결함 D] paragraph 단위 inline picture 가로 분배 cursor state.
        // 같은 paragraph 의 sibling tac=true picture 들이 가로로 inline 분배 (한컴 native 정합).
        let mut para_inline_state: std::collections::HashMap<
            usize,
            super::layout::paragraph_layout::ParaInlineState,
        > = std::collections::HashMap::new();

        let multi_col_width = if zone_layout.column_areas.len() > 1 {
            let widths: Vec<f64> = zone_layout.column_areas.iter().map(|a| a.width).collect();
            let max_w = widths.iter().cloned().fold(0.0f64, f64::max);
            let min_w = widths.iter().cloned().fold(f64::MAX, f64::min);
            let diff_hu = ((max_w - min_w) / self.dpi * 7200.0).round() as i32;
            if diff_hu > 1000 {
                Some((col_area.width / self.dpi * 7200.0).round() as i32)
            } else {
                None
            }
        } else {
            None
        };
        let zone_column_count = zone_layout.column_areas.len();

        let col_width_hu = (col_area.width / self.dpi * 7200.0).round() as i32;
        let mut prev_tac_seg_applied = false;
        let mut tac_seg_applied_para: Option<usize> = None;
        let mut prev_endnote_title_gap_px = 0.0;
        let mut prev_endnote_title_gap_from_continued_partial = false;
        let mut pending_textless_equation_tail_gap_restore: Option<(EndnoteParaSource, f64)> = None;

        // 고정값 줄간격 TAC 표 병행 (Task #9): 표 하단 비교용
        let mut fix_table_start_y: f64 = 0.0;
        let mut fix_table_visual_h: f64 = 0.0;
        let mut fix_overlay_active = false;

        // vpos 보정을 위한 페이지 기준 vpos 계산
        // 페이지 첫 항목의 vpos를 기준점으로 삼아 모든 페이지에서 vpos 보정 적용
        let saved_inline_heading_page = matches!(col_content.items.first(), Some(PageItem::FullParagraph { para_index })
            if self.profile.get().hwp5_stored_pagination_layout()
                && *para_index > 0
                && paragraphs.get(*para_index).is_some_and(|para| {
                    para.line_segs.len() == 1
                        && (1..=2500).contains(&para.line_segs[0].vertical_pos)
                        && para.controls.len() == 1
                        && matches!(&para.controls[0], Control::Shape(shape) if shape.common().treat_as_char)
                        && !para_has_visible_text(para)
                })
                && paragraphs.get(*para_index - 1).and_then(|para| para.line_segs.last())
                    .is_some_and(|seg| seg.vertical_pos.saturating_add(seg.line_height) > 60_000)
                && paragraphs.get(*para_index + 1).and_then(|para| para.line_segs.first())
                    .is_some_and(|seg| seg.vertical_pos > paragraphs[*para_index].line_segs[0].vertical_pos
                        && seg.vertical_pos < 30_000));
        // 저장 HWP/HWPX 쪽은 첫 vpos가 문단 앞 간격과 정확히 같은 문단으로 시작할 수 있다.
        // 이 vpos는 쪽 원점 자체가 아니라 원점부터의 여백이다.
        // 이후 항목에 쪽 상대 vpos를 적용하기 전에 다음 저장 문단도 같은
        // 단계별 위치 관계에서 자기 앞 간격을 반영하는지 확인한다(#7406, 90쪽).
        // 명시적으로 쪽을 나누는 문단은 새 흐름을 시작하므로
        // 그 문단의 첫 vpos를 쪽 기준점으로 유지한다
        // (issue1853, 10쪽).
        let stored_first_margin_is_page_relative_in_column = matches!(
            col_content.items.first(),
            Some(PageItem::FullParagraph { para_index })
                if (self.profile.get().hwpx_stored_layout()
                    || self.profile.get().hwp5_stored_pagination_layout())
                    && paragraphs.get(*para_index).is_some_and(|first| {
                        (!self.profile.get().session_edited()
                            || (self.profile.get().hwp5_stored_pagination_layout()
                                && current_stored_margin_frame(first,paragraphs.get(*para_index+1),
                                    px_to_hwpunit(col_area.width,self.dpi),px_to_hwpunit(col_area.height,self.dpi),styles,self.dpi)
                                && !col_content.endnote_flow && col_content.start_height==0.0
                                && col_content.zone_layout.is_none() && col_content.zone_y_offset==0.0
                                && !col_content.wrap_anchors.contains_key(para_index)
                                && !column_wrap_around_paras.iter().any(|w| w.para_index==*para_index)
                                && super::typeset::current_native_plain_format_matches_saved(
                                    first,composed.get(*para_index),styles,self.dpi,col_area.width,&self.profile,
                                    crate::renderer::stored_line_ladder_is_uniform_filler(paragraphs,styles),
                                    &self.body_float_carve_evidence)))
                        && stored_first_margin_is_page_relative(
                            first, paragraphs.get(*para_index + 1), styles, self.dpi,
                        )
                    })
        );
        let vpos_page_base_init: Option<i32> = col_content
            .items
            .first()
            .and_then(|item| {
                match item {
                    PageItem::FullParagraph { para_index } => paragraphs
                        .get(*para_index)
                        .and_then(|p| p.line_segs.first())
                        .map(|seg| seg.vertical_pos),
                    PageItem::PartialParagraph {
                        para_index,
                        start_line,
                        ..
                    } => paragraphs
                        .get(*para_index)
                        .and_then(|p| p.line_segs.get(*start_line))
                        .map(|seg| seg.vertical_pos),
                    PageItem::Table {
                        para_index,
                        control_index,
                    } => {
                        let source = paragraphs.get(*para_index)?.line_segs.first()?.vertical_pos;
                        let has_host_line = col_content.items.iter().any(|item| {
                            matches!(item,
                                PageItem::FullParagraph { para_index: owner }
                                    | PageItem::PartialParagraph { para_index: owner, start_line: 0, .. }
                                if owner == para_index)
                        });
                        if has_host_line {
                            // 표 뒤에도 호스트 글줄이 있으면 저장 vpos는 그 글줄의 좌표다.
                            // 측정이 확정한 원점이 있으면 공유하고, 없으면 실제 흐름에서 역산한다.
                            col_content.paragraph_float_placements
                                .get(&(*para_index, *control_index))
                                .and_then(|placement| placement.stored_host_origin)
                                .map(|origin| source.saturating_sub(px_to_hwpunit(origin, self.dpi)))
                        } else {
                            // 호스트 글줄 없이 표만 새 단을 열면 저장 프레임의 기준을 유지한다.
                            Some(source)
                        }
                    }
                    // PartialTable/Shape: 지연 보정 사용
                    _ => None,
                }
            })
            .map(|base| {
                // 저장 HWP5의 새 쪽을 인라인 도형 제목이 열면 그 제목 자체의
                // vpos(예: 1000HU)는 쪽 원점이 아니다. 도형은 자체 좌표로 그려지고
                // 뒤따르는 본문은 쪽-상대 vpos를 그대로 따른다. 제목 vpos를
                // page_base로 빼면 뒤의 문단·표가 그만큼 위로 밀린다.
                let reconstructed = if zone_column_count == 1 && self.profile.get().hwpx_stored_layout()
                    && !self.profile.get().hwp3_layout()
                    && !self.profile.get().session_edited() && !col_content.endnote_flow
                {
                    match col_content.items.first() {
                        Some(PageItem::FullParagraph { para_index }) => paragraphs.get(*para_index)
                            .and_then(|first| reconstructed_tac_page_basis(
                                first, paragraphs.get(*para_index + 1),
                                paragraphs.get(*para_index + 2), styles, self.dpi, col_area.height)),
                        _ => None,
                    }
                } else { None };
                if let Some(origin) = reconstructed { origin }
                else if saved_inline_heading_page || stored_first_margin_is_page_relative_in_column {
                    0
                } else {
                    base
                }
            });
        // (base=0 무차별 부여는 다쪽 분할표 연속 컬럼에서 오작동 — HeightCursor 의
        // [Task #1027 Stage C] inter-item VPOS_CORR 상태머신을 HeightCursor 로 캡슐화.
        // vpos_page_base/lazy_base, prev_layout_para, prev_item_was_partial_table(#991:
        // 분할 표 직후 첫 문단은 sequential 신뢰)를 보유하며 항목 사이 vpos 보정을 위임.
        let mut hcursor = HeightCursor::new(
            self.dpi,
            visual_col_y,
            visual_col_height,
            col_anchor_y,
            vpos_page_base_init,
            self.use_hwp3_origin_flow_spacing_before.get(),
            false,
            col_content.endnote_flow && col_content.start_height < -0.5,
            col_content.endnote_flow,
        );
        hcursor.suppress_hwpx_stale_forward = self.profile.get().hwpx_stored_layout();
        hcursor.native_stored_plain_trailing = self.profile.get().hwp5_stored_pagination_layout()
            && !col_content.endnote_flow && col_content.start_height==0.0
            && col_content.zone_y_offset==0.0 && col_anchor_y==visual_col_y
            && vpos_page_base_init.is_some_and(|base|match col_content.items.first() {
                Some(PageItem::Table{para_index,control_index})=>paragraphs.get(*para_index)
                    .and_then(|p|crate::renderer::composer::stored_table_column_line_vpos(p,*control_index))==Some(base),
                _=>false,
            });
        // [#5854] 통짜 합성 LINE_SEG 사다리 판정 — 본문 단에서만 갱신한다. 미주 단은
        // `paragraphs` 가 미주 전용 재색인 배열이라 구역 판정의 근거가 아니므로 본문에서
        // 정해진 값을 그대로 이어 쓴다 (조판 경로 `TypesetEngine` 과 같은 구역 단위 값).
        if !col_content.endnote_flow {
            self.uniform_filler_ladder
                .set(crate::renderer::stored_line_ladder_is_uniform_filler(
                    paragraphs, styles,
                ));
        }
        hcursor.uniform_filler_ladder = self.uniform_filler_ladder.get();
        hcursor.session_edited = self.profile.get().session_edited();
        // [Task #1246] 미주 흐름 컬럼에만 between-notes 마진(HU)을 주입 → HeightCursor 가 새 미주
        // 제목 forward 흐름의 min-gap 보정에 사용. 본문 컬럼은 0 (무영향).
        if col_content.endnote_flow {
            hcursor.endnote_between_notes_hu = self.endnote_between_notes_hu.get();
        }

        // 1차 패스: 표, 문단, 텍스트 렌더링 (글상자 제외)
        let mut square_beside_band: Option<(f64, i32, i32)> = None;
        let col_w_hu = px_to_hwpunit(col_area.width, self.dpi);
        let paragraph_last_items: std::collections::HashMap<_, _> = col_content
            .items
            .iter()
            .enumerate()
            .map(|(index, item)| (item.para_index(), index))
            .collect();
        // #7359 p14: the page begins with one saved text line, followed by a
        // visible paragraph-float table and its caption in the next paragraph.
        // Both stored vpos steps carry their own paragraph spacing.  Restrict
        // the page-top fallback to this complete ladder shape; applying it to
        // unrelated first paragraphs grows body-overflow baselines.
        let page_top_float_caption_spacing_para = (|| {
            if !self.profile.get().hwp5_stored_pagination_layout()
                || (y_offset - col_area.y).abs() >= 0.5
            {
                return None;
            }
            let (
                Some(PageItem::FullParagraph {
                    para_index: first_pi,
                }),
                Some(PageItem::Table {
                    para_index: host_pi,
                    control_index,
                }),
                Some(PageItem::PartialParagraph {
                    para_index: caption_pi,
                    start_line: 0,
                    ..
                }),
            ) = (
                col_content.items.first(),
                col_content.items.get(1),
                col_content.items.get(2),
            )
            else {
                return None;
            };
            if *host_pi != *first_pi + 1 || *caption_pi != *host_pi {
                return None;
            }
            let first = paragraphs.get(*first_pi)?;
            let host = paragraphs.get(*host_pi)?;
            let Control::Table(table) = host.controls.get(*control_index)? else {
                return None;
            };
            if !first.controls.is_empty()
                || first.line_segs.len() != 1
                || host.line_segs.len() != 1
                || !para_has_non_whitespace_text(first)
                || !para_has_non_whitespace_text(host)
                || !is_para_topbottom_float(&table.common)
                || first.line_segs[0].tag
                    & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY
                    != 0
                || host.line_segs[0].tag
                    & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY
                    != 0
            {
                return None;
            }
            let first_spacing = styles
                .para_styles
                .get(first.para_shape_id as usize)?
                .spacing_before;
            let host_spacing = styles
                .para_styles
                .get(host.para_shape_id as usize)?
                .spacing_before;
            let first_vpos = hwpunit_to_px(first.line_segs[0].vertical_pos, self.dpi);
            let host_saved_gap = hwpunit_to_px(
                host.line_segs[0].vertical_pos
                    - first.line_segs[0].vertical_pos
                    - first.line_segs[0].line_height
                    - first.line_segs[0].line_spacing,
                self.dpi,
            );
            (first_spacing > 0.5
                && host_spacing > 0.5
                && (first_vpos - first_spacing).abs() < 0.5
                && (host_saved_gap - host_spacing).abs() < 0.5)
                .then_some(*first_pi)
        })();
        let mut deferred_paragraph_spacing = std::collections::HashMap::new();
        // [#7418] host 글 조각 기록은 같은 단 안의 바로 다음 표만 쓴다 — 앞 쪽 끝의 기록이
        // 새 쪽 첫 표로 새면 앞 쪽 좌표가 문단 상단이 된다(1480000 4구역: 칸 줄 550개가
        // 용지 밖 1.5px).
        self.host_text_content_bottom.set(None);
        for (item_ordinal, item) in col_content.items.iter().enumerate() {
            self.page_top_float_caption_spacing_para.set(
                (item_ordinal == 0)
                    .then_some(page_top_float_caption_spacing_para)
                    .flatten(),
            );
            // vpos 기반 y_offset 보정
            let item_para = match item {
                PageItem::FullParagraph { para_index } => *para_index,
                PageItem::PartialParagraph { para_index, .. } => *para_index,
                PageItem::Table { para_index, .. } => *para_index,
                PageItem::PartialTable { para_index, .. } => *para_index,
                PageItem::Shape { para_index, .. } => *para_index,
                PageItem::EndnoteSeparator { .. } => {
                    // [미주 구분선 위치 — 한컴 정합] 직전 본문 문단 마지막 줄의 trailing
                    // 줄간격(line_spacing)은 한컴이 note 영역에 포함하지 않는다. rhwp 문단
                    // advance 는 포함하므로 그만큼 note 영역(구분선+본문)을 위로 올린다.
                    let trailing_ls_px = col_content.items[..item_ordinal]
                        .iter()
                        .rev()
                        .find_map(|it| match it {
                            PageItem::FullParagraph { para_index }
                            | PageItem::PartialParagraph { para_index, .. } => paragraphs
                                .get(*para_index)
                                .and_then(|p| p.line_segs.last())
                                .filter(|ls| ls.line_spacing > 0)
                                .map(|ls| hwpunit_to_px(ls.line_spacing, self.dpi)),
                            _ => None,
                        })
                        .unwrap_or(0.0);
                    y_offset = (y_offset - trailing_ls_px).max(0.0);
                    let (new_y, _) = self.layout_column_item(
                        tree,
                        &mut col_node,
                        paper_images,
                        &mut para_start_y,
                        &mut deferred_paragraph_spacing,
                        &mut para_float_lanes,
                        &mut visible_float_exclusions,
                        &mut para_inline_state,
                        item,
                        page_content,
                        paragraphs,
                        composed,
                        styles,
                        bin_data_content,
                        measured_tables,
                        layout,
                        col_area,
                        zone_column_count,
                        outline_numbering_id,
                        multi_col_width,
                        y_offset,
                        prev_tac_seg_applied,
                        column_wrap_around_paras,
                        &col_content.wrap_anchors,
                        &col_content.inline_placements,
                        &col_content.inline_flow_plans,
                        &col_content.paragraph_float_placements,
                    );
                    y_offset = new_y;
                    endnote_sep_body_floor = Some(new_y);
                    continue;
                }
            };
            // [#2813] 공백-only host 앵커 줄은 표 스택의 문서순을 보존하는 PageItem일
            // 뿐, 표를 측정한 뒤 다시 그 높이를 소비하는 flow 요소가 아니다. 이 줄을
            // 일반 paragraph로 layout하면 본문 하단 밖에 빈 줄을 재배치해
            // LAYOUT_OVERFLOW를 남긴다. item은 유지해 dump/selection 순서를 보존하고,
            // draw와 advance만 생략한다.
            if is_deferred_blank_para_float_stack_anchor(
                item,
                item_ordinal,
                &col_content.items,
                paragraphs,
            ) {
                continue;
            }
            // [Task #901 Stage 8/10] post-jump 적용: 직전 anchor paragraph 가 flow-around 로
            // 그림 위에 렌더된 경우 후속 paragraph 의 y_offset 을 picture bottom 으로 jump
            // + vpos_lazy_base 를 anchor first_vpos 로 set → file vpos 누적이 visual y 와 정합.
            // Shape/Table item 은 skip (vpos_lazy_base reset 회피).
            let item_is_paragraph = matches!(
                item,
                PageItem::FullParagraph { .. } | PageItem::PartialParagraph { .. }
            );
            if item_is_paragraph {
                if let Some((bottom_y, anchor_first_vpos)) = pending_topbottom_post_jump.take() {
                    // y_offset 이 bottom_y 보다 작으면 jump (예: iris Shape pre-jump 미적용 케이스)
                    if bottom_y > y_offset {
                        y_offset = bottom_y;
                    }
                    // vpos_lazy_base 는 항상 set (anchor first_vpos 기준 후속 paragraph 정합)
                    hcursor.vpos_lazy_base = Some(anchor_first_vpos);
                    hcursor.vpos_page_base = None;
                }
            }
            // TopAndBottom 글상자: 앵커 문단에 도달하면 y_offset을 글상자 하단 아래로 점프
            let mut shape_jumped = false;
            for &(anchor_pi, bottom_y) in &shape_reserved {
                if item_para == anchor_pi && bottom_y > y_offset {
                    // [Task #901 Stage 8] flow-around 시도: anchor 의 text height 가 picture 위
                    // 영역 (col_area.y ~ picture_top_y) 에 fit 가능하면 pre-jump skip.
                    use crate::model::shape::TextWrap;
                    let anchor_para = &paragraphs[anchor_pi];
                    let picture_top_y_opt: Option<f64> =
                        anchor_para.controls.iter().find_map(|c| {
                            let common = match c {
                                Control::Picture(pic) if !pic.common.treat_as_char => {
                                    Some(&pic.common)
                                }
                                Control::Shape(s) if !s.common().treat_as_char => Some(s.common()),
                                Control::Table(t) if !t.common.treat_as_char => Some(&t.common),
                                _ => None,
                            }?;
                            if !matches!(common.text_wrap, TextWrap::TopAndBottom) {
                                return None;
                            }
                            let (_bot, top) =
                                self.calc_shape_bottom_y(common, col_area, &layout.body_area);
                            Some(top)
                        });
                    let text_height = composed
                        .get(anchor_pi)
                        .map(|comp| {
                            comp.lines
                                .iter()
                                .map(|line| {
                                    crate::renderer::hwpunit_to_px(
                                        line.line_height + line.line_spacing,
                                        self.dpi,
                                    )
                                })
                                .sum::<f64>()
                        })
                        .unwrap_or(f64::MAX);
                    let fits_above = picture_top_y_opt
                        .map(|top_y| text_height + 4.0 <= (top_y - y_offset))
                        .unwrap_or(false);
                    if fits_above {
                        // Stage 11: 후속 paragraph item 의 first vpos 를 peek 하여 base 직접 계산.
                        // base = next_para_vpos - (bottom_y - col_area.y) * scale^-1
                        // → end_y for next para = bottom_y (iris 직하 정합).
                        let next_para_vpos: Option<i32> = col_content
                            .items
                            .iter()
                            .skip_while(|it| match it {
                                PageItem::FullParagraph { para_index } => *para_index != anchor_pi,
                                PageItem::PartialParagraph { para_index, .. } => {
                                    *para_index != anchor_pi
                                }
                                _ => true,
                            })
                            .skip(1) // anchor item 자체 skip
                            .find_map(|it| match it {
                                PageItem::FullParagraph { para_index }
                                | PageItem::PartialParagraph { para_index, .. } => paragraphs
                                    .get(*para_index)
                                    .and_then(|p| p.line_segs.first())
                                    .map(|s| s.vertical_pos),
                                _ => None,
                            });
                        let base_for_post = if let Some(npv) = next_para_vpos {
                            let visual_diff_hu =
                                ((bottom_y - col_area.y) / self.dpi * 7200.0).round() as i32;
                            npv - visual_diff_hu
                        } else {
                            anchor_para
                                .line_segs
                                .first()
                                .map(|s| s.vertical_pos)
                                .unwrap_or(0)
                        };
                        pending_topbottom_post_jump = Some((bottom_y, base_for_post));
                    } else {
                        // [#4533 HWP3] 비-tac TopAndBottom float 표인데 저장
                        // 사다리가 표를 예약하지 않은 서식 문서(하동군 21918361:
                        // host lh 13.3px·다음 문단 델타 21.3px vs 표 730px)는
                        // 점프를 생략한다 — typeset 의 hwp3_topbottom_no_reserve
                        // 와 짝. 표는 그 자리에 그려지고 후속 텍스트가 겹치는
                        // 것이 한글의 정본이며, typeset 예산과 일치해야 후속
                        // 줄이 쪽 밖으로 밀리지 않는다.
                        let tot = picture_top_y_opt.map(|top| bottom_y - top).unwrap_or(0.0);
                        let host_lh_px = anchor_para
                            .line_segs
                            .iter()
                            .find(|s| s.tag & 0x8000_0000 == 0)
                            .map(|s| hwpunit_to_px(s.line_height, self.dpi));
                        let next_gap_px = paragraphs
                            .get(anchor_pi + 1)
                            .and_then(|np| np.line_segs.first())
                            .zip(anchor_para.line_segs.first())
                            .filter(|(ns, hs)| ns.vertical_pos > hs.vertical_pos)
                            .map(|(ns, hs)| {
                                hwpunit_to_px(ns.vertical_pos - hs.vertical_pos, self.dpi)
                            });
                        let is_float_table_anchor = anchor_para.controls.iter().any(|c| {
                            matches!(c, Control::Table(t)
                            if !t.common.treat_as_char
                                && matches!(
                                    t.common.text_wrap,
                                    crate::model::shape::TextWrap::TopAndBottom
                                ))
                        });
                        let hwp3_no_reserve = (self.profile.get().hwp3_native_layout()
                            || (self.profile.get().hwp3_layout()
                                && self.profile.get().hwpx_container()))
                            && is_float_table_anchor
                            && tot > 1.0
                            && host_lh_px.is_some_and(|lh| lh < tot * 0.25)
                            && next_gap_px.is_some_and(|g| g < tot * 0.25);
                        if !hwp3_no_reserve {
                            y_offset = bottom_y;
                            shape_jumped = true;
                        }
                    }
                }
            }

            let current_is_endnote_question_title = col_content.endnote_flow
                && paragraphs
                    .get(item_para)
                    .map(|p| p.text.trim_start().starts_with('문'))
                    .unwrap_or(false);
            let current_endnote_source = if col_content.endnote_flow {
                self.endnote_para_source_for(item_para)
            } else {
                None
            };
            if current_is_endnote_question_title {
                if let (Some((pending_source, delta)), Some(current_source)) = (
                    pending_textless_equation_tail_gap_restore.as_ref(),
                    current_endnote_source.as_ref(),
                ) {
                    if !same_endnote_control(pending_source, current_source) {
                        // textless equation tail 뒤 제목에서 생략한 logical gap은
                        // 해당 미주의 본문까지는 적용하지 않는다. 다음 미주 제목을
                        // 만날 때만 vpos base에 복원해 후속 문항이 같이 당겨지지
                        // 않게 한다.
                        hcursor.shift_vpos_base_for_rendered_delta(*delta);
                        pending_textless_equation_tail_gap_restore = None;
                    }
                }
            }
            let y_before_vpos = y_offset;
            let prev_item_content_bottom_y = if item_ordinal > 0 {
                let content_bottom_y = self.last_item_content_bottom.get();
                content_bottom_y.is_finite().then_some(content_bottom_y)
            } else {
                None
            };
            hcursor.prev_item_content_bottom_y = prev_item_content_bottom_y;
            hcursor.prev_item_flow_line_bottom_y = if item_ordinal > 0 {
                let bottom = self.last_item_flow_line_bottom.get();
                bottom.is_finite().then_some(bottom)
            } else {
                None
            };
            // [#4613 · #4599 밴드-플로우] 전방 스냅 기각 판정용 — vpos_adjust 이전의 순차 흐름 위치.
            let y_before_vpos_adjust = y_offset;
            // [#4639 · #4599 ⑧] TAC-직후 보정 스킵의 예외 — 직전 TAC host 문단이 비-TAC
            // TopAndBottom Shape/Picture float 를 함께 앵커한 경우, TAC 전진은 표
            // 줄만 소비하고 그림 밴드는 흐름에 남는다(36442008 p1: 그림
            // 706.7..911.3 위로 '붙임' 절이 220.8px 겹침 — 한글 2022 캐시 PDF·저장
            // 사다리 모두 955.2 실측). 이때는 저장 사다리 보정을 허용해 후속
            // 문단이 그림 밴드 아래로 스냅되게 한다. hwpx stored layout 한정.
            let prev_tac_host_sibling_float = prev_tac_seg_applied
                && self.profile.get().hwpx_stored_layout()
                && tac_seg_applied_para
                    .or(hcursor.prev_layout_para)
                    .and_then(|pi| paragraphs.get(pi))
                    .is_some_and(|p| {
                        p.controls
                            .iter()
                            .any(|c| matches!(c, Control::Table(t) if t.common.treat_as_char))
                            && p.controls.iter().any(|c| {
                                let cm = match c {
                                    Control::Shape(sh) => sh.common(),
                                    Control::Picture(pic) => &pic.common,
                                    _ => return false,
                                };
                                !cm.treat_as_char
                                    && matches!(
                                        cm.text_wrap,
                                        TextWrap::TopAndBottom | TextWrap::Square
                                    )
                                    && matches!(
                                        cm.vert_rel_to,
                                        crate::model::shape::VertRelTo::Para
                                    )
                            })
                    });
            // [편집 세션] 분할 표 조각은 typeset 이 fresh 컷으로 이 쪽 잔여에
            // 배치한 신생 아이템이다 — 저장 사다리 전방 점프로 당기면 조각이 쪽
            // 하단 밖에 그려진다(셀 Enter 재현: 조각이 쪽 하단을 수백 px 넘김).
            // 이 쪽에 선행 아이템이 있는 조각은 흐름 y 를 신뢰한다.
            let session_fresh_partial_table = self.profile.get().session_edited()
                && item_ordinal > 0
                && matches!(item, PageItem::PartialTable { .. });
            // [편집 세션] 저장 사다리의 음수 줄간격은 줄 상자를 글자보다 좁게
            // 만들어(lh > 0 · ls < 0 → 상자가 글자보다 낮음), 흐름 커서가 글자
            // 하단보다 위에 머문다. 편집으로 표가 이 쪽에 재배치되면 그 좁은
            // 상자 위치에 표를 그려 앞 문구를 문다. 한글은 재조판에서 표를
            // 글자 아래에 놓는다.
            if self.profile.get().session_edited()
                && item_ordinal > 0
                && matches!(item, PageItem::Table { .. } | PageItem::PartialTable { .. })
            {
                if let Some(text_bottom) = painted_flow_text_bottom(&col_node) {
                    if y_offset < text_bottom {
                        y_offset = text_bottom;
                    }
                }
            }
            if !shape_jumped
                && !session_fresh_partial_table
                && (!prev_tac_seg_applied
                    || current_is_endnote_question_title
                    || prev_tac_host_sibling_float)
            {
                // [Task #1027 Stage C] inter-item VPOS_CORR 보정을 HeightCursor 에 위임 (동작 동일).
                // 이전 문단 overlay-shape/분할표 bypass, page/lazy base 산출, sb 차감,
                // ≤8px 백워드 클램프를 모두 캡슐화 (Stage A/B 함수 결합). 렌더러·페이지네이터 공유.
                // [#7351] 표 조각은 host 문단의 앞 간격을 그리지 않으므로
                // 스냅의 `sb_N` 사전 차감에서 뺀다.
                hcursor.curr_item_is_table_fragment = matches!(item, PageItem::PartialTable { .. });
                let semantic_successor = crate::renderer::float_placement::native_whole_stack_owns_successor(
                    self.profile.get().hwp5_stored_pagination_layout(), page_content.column_contents.len() == 1,
                    &col_content.items[..item_ordinal], item_para, paragraphs);
                if semantic_successor {
                    if let Some(line) = paragraphs[item_para].line_segs.first() {
                        hcursor.vpos_page_base = Some(line.vertical_pos
                            - crate::renderer::px_to_hwpunit(y_offset - hcursor.col_anchor_y, self.dpi));
                        hcursor.vpos_lazy_base = None;
                    }
                } else {
                    y_offset = hcursor.vpos_adjust(y_offset, item_para, paragraphs, styles);
                }
                hcursor.curr_item_is_table_fragment = false;
            } // !shape_jumped
              // [#5699 H1] 밴드-바닥 활성 단(사다리-미계상 표를 이 단에서 교정): 저장
              // vpos 는 표 밴드를 모르는 좌표계다. 후방 스냅은 순차 흐름과 바닥 중
              // 큰 쪽 아래로 내려가지 못한다 — 바닥 상수만으로 막으면 연속 문단이
              // 같은 y 에 적층되고(9·※ 실측), 순차 흐름만으로 막으면 스냅이
              // vpos_adjust 밖 경로에서 온 아이템을 놓친다.
            if hcursor.min_flow_floor > f64::MIN {
                let guard = y_before_vpos_adjust.max(hcursor.min_flow_floor);
                if y_offset < guard {
                    y_offset = guard;
                }
                if std::env::var("RHWP_5699_DBG").is_ok() {
                    eprintln!(
                        "DBG5699 pi={} y_before={:.1} y_now={:.1} floor={:.1}",
                        item_para, y_before_vpos_adjust, y_offset, hcursor.min_flow_floor
                    );
                }
            }
            // Empty Square sibling 표 직전의 본문은 같은 물리 페이지의 raw LINE_SEG
            // 좌표를 따른다. 일반 cursor가 앞선 표의 측정 높이만큼 늦어지면 본문이
            // 다음 pair(표 2/그림 9) 위에 그려진다. 다음 항목이 정확히 이 pair이고,
            // 저장 위치에서 현재 줄 조각 전체가 pair 상단 전에 끝나는 경우에만
            // backward snap을 허용한다.
            let next_square_sibling_top = col_content
                .items
                .iter()
                .skip(item_ordinal + 1)
                // HWP5에서는 각주가 붙은 heading/bullet과 그 다음 본문 문단 뒤에
                // sibling pair가 이어질 수 있다. 그 두 문단까지 같은 raw-vpos run으로
                // 보되, 더 먼 내용까지 끌어오지 않도록 look-ahead를 두 item으로 한정한다.
                .take(2)
                .find_map(|next| match next {
                    PageItem::Table { para_index, .. }
                        if paragraphs
                            .get(*para_index)
                            .is_some_and(para_is_empty_square_sibling_table_anchor) =>
                    {
                        paragraphs.get(*para_index).and_then(|next_para| {
                            empty_square_sibling_table_saved_top(next_para, &col_area, self.dpi)
                        })
                    }
                    _ => None,
                });
            if self.profile.get().hwp5_stored_pagination_layout()
                && item_is_paragraph
                && next_square_sibling_top.is_some()
                && paragraphs.get(item_para).is_some_and(para_has_visible_text)
            {
                let (start_line, end_line) = match item {
                    PageItem::FullParagraph { .. } => composed
                        .get(item_para)
                        .map(|comp| (0, comp.lines.len()))
                        .unwrap_or((0, 0)),
                    PageItem::PartialParagraph {
                        start_line,
                        end_line,
                        ..
                    } => (*start_line, *end_line),
                    _ => (0, 0),
                };
                let stored_top = paragraphs
                    .get(item_para)
                    .and_then(|para| {
                        para.line_segs.iter().find(|seg| {
                            seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY
                                == 0
                        })
                    })
                    .map(|seg| col_area.y + hwpunit_to_px(seg.vertical_pos, self.dpi));
                let visual_height = composed
                    .get(item_para)
                    .map(|comp| {
                        let end = end_line.min(comp.lines.len());
                        (start_line.min(end)..end)
                            .map(|line_idx| {
                                let line = &comp.lines[line_idx];
                                hwpunit_to_px(line.line_height, self.dpi)
                                    + if line_idx + 1 < end {
                                        hwpunit_to_px(line.line_spacing, self.dpi)
                                    } else {
                                        0.0
                                    }
                            })
                            .sum::<f64>()
                    })
                    .unwrap_or(0.0);
                if let (Some(square_top), Some(stored_top)) = (next_square_sibling_top, stored_top)
                {
                    if stored_top + visual_height <= square_top - 0.5 && stored_top + 0.5 < y_offset
                    {
                        y_offset = stored_top;
                        // 이 특수 page-relative snap 뒤에는 기존 상대 ladder를 다음
                        // table에 재사용하지 않는다. pair 자체는 lane의 raw 좌표가 단일
                        // 진실원천이고, 후속 쪽에서 새 base가 잡힌다.
                        hcursor.vpos_page_base = None;
                        hcursor.vpos_lazy_base = None;
                    }
                }
            }
            let current_title_tail_backtracked =
                current_is_endnote_question_title && y_offset < y_before_vpos - 32.0;
            let current_large_gap_title_compacted_by_cursor = current_is_endnote_question_title
                && col_content.endnote_flow
                && self.endnote_between_notes_hu.get() > 3000
                && y_offset < y_before_vpos - 0.5;
            let current_line_height_px = paragraphs
                .get(item_para)
                .and_then(|p| p.line_segs.first())
                .map(|seg| hwpunit_to_px(seg.line_height.max(0), self.dpi))
                .unwrap_or(0.0);
            let endnote_title_direct_bottom_fit = current_is_endnote_question_title
                && col_content.endnote_flow
                && current_line_height_px > 0.0
                && y_offset + current_line_height_px > col_area.y + col_area.height + 0.5
                && y_offset <= col_area.y + col_area.height + 80.0;
            if endnote_title_direct_bottom_fit {
                // TAC/수식 직후에는 prev_tac_seg_applied 때문에 HeightCursor 보정이
                // 생략될 수 있다. 그래도 새 문항 제목 1줄이 단 하단 안쪽에 들어가면
                // 한컴/PDF처럼 제목 tail만 현재 단에 남긴다.
                y_offset = (col_area.y + col_area.height - current_line_height_px - 7.0)
                    .max(col_area.y)
                    .min(y_offset);
            }
            let endnote_title_bottom_fit_applied = current_is_endnote_question_title
                && current_line_height_px > 0.0
                && y_offset < y_before_vpos - 0.5
                && y_before_vpos + current_line_height_px > col_area.y + col_area.height + 0.5
                && y_offset + current_line_height_px <= col_area.y + col_area.height + 0.5;
            let mut compacted_equation_tail_title_gap = false;
            let compact_single_equation_tail_gap_profile = self.endnote_between_notes_hu.get() > 0
                && self.endnote_between_notes_hu.get() <= ENDNOTE_BETWEEN_NOTES_BASE_FLOW_HU;
            if compact_single_equation_tail_gap_profile
                && current_is_endnote_question_title
                && col_content.endnote_flow
                && !endnote_title_direct_bottom_fit
                && !endnote_title_bottom_fit_applied
            {
                if let (Some(prev_pi), Some(prev_content_bottom_y), Some(current_para)) = (
                    hcursor.prev_layout_para,
                    prev_item_content_bottom_y,
                    paragraphs.get(item_para),
                ) {
                    if let Some(prev_para) = paragraphs.get(prev_pi) {
                        if let Some(compacted_y) =
                            compact_endnote_title_gap_after_single_equation_tail(
                                prev_para,
                                current_para,
                                prev_content_bottom_y,
                                y_offset,
                                prev_endnote_title_gap_px,
                                item_ordinal,
                                self.dpi,
                            )
                        {
                            y_offset = compacted_y.max(col_area.y);
                            hcursor.vpos_page_base = None;
                            hcursor.vpos_lazy_base = None;
                            compacted_equation_tail_title_gap = true;
                        }
                    }
                }
            }
            // [Task #1355] 미주 제목 saved-vpos 점프에 의한 gap 이중계상 정정.
            // 직전 미주 콘텐츠의 trailing line-spacing 이 흐름에 "미주 사이" gap 을 이미
            // 만들었는데(flow_advance ≈ gap), 제목의 saved LINE_SEG vpos 가 직전 bottom 보다
            // 크게 점프(원본에서 단/쪽 경계를 건넌 미주)하면 vpos_adjust 가 saved 기준으로 gap
            // 을 한 번 더 더해 제목 앞 여백이 약 2배가 된다(예: p18 문30 → 문24 답안 본문 초과).
            // 이때만 제목을 흐름 위치(y_before_vpos)로 되돌려 gap 을 한 번만 남긴다.
            // saved-vpos 점프가 작은 일반 순차 미주(2022_oct q19 등)는 vpos_adjust 가 정답
            // 이므로 제외 — flow_advance 만으로는 양자 시그니처가 동일(둘 다 ≈gap)해 구분 불가,
            // saved-vpos 점프량(원본 단/쪽 경계 신호)으로 구분한다.
            if current_is_endnote_question_title
                && col_content.endnote_flow
                && !compacted_equation_tail_title_gap
                && !endnote_title_direct_bottom_fit
                && !endnote_title_bottom_fit_applied
                && !current_title_tail_backtracked
                && prev_endnote_title_gap_px > 0.0
                && y_offset > y_before_vpos + 4.0
            {
                let cur_first_vpos = paragraphs
                    .get(item_para)
                    .and_then(|p| p.line_segs.first())
                    .map(|s| s.vertical_pos);
                let prev_last_bottom_vpos = hcursor
                    .prev_layout_para
                    .and_then(|pi| paragraphs.get(pi))
                    .and_then(|p| p.line_segs.last())
                    .map(|s| s.vertical_pos + s.line_height);
                let saved_delta_hu = match (cur_first_vpos, prev_last_bottom_vpos) {
                    (Some(cf), Some(pb)) => cf - pb,
                    _ => 0,
                };
                // 이중계상은 직전 미주 문단이 "수식 전용(보이는 텍스트 없음)" tail 일 때만
                // 발생한다(수식 tail 의 trailing line-spacing 인플레이션 + saved-vpos 점프).
                // 직전이 텍스트 문단이면 vpos_adjust 가 정답이므로 제외(2022_sep q15,
                // 2022_oct q29 회귀 방지).
                let prev_is_textless = hcursor
                    .prev_layout_para
                    .and_then(|pi| paragraphs.get(pi))
                    .map(|p| !para_has_visible_text(p))
                    .unwrap_or(false);
                if let Some(prev_bottom) = prev_item_content_bottom_y {
                    let flow_advance = y_before_vpos - prev_bottom;
                    if prev_is_textless
                        && flow_advance >= prev_endnote_title_gap_px * 0.9
                        && flow_advance <= prev_endnote_title_gap_px * 1.25
                        && saved_delta_hu > 5000
                    {
                        y_offset = y_before_vpos;
                        hcursor.vpos_page_base = None;
                        hcursor.vpos_lazy_base = None;
                        compacted_equation_tail_title_gap = true;
                    }
                }
            }
            if current_is_endnote_question_title
                && col_content.endnote_flow
                && !endnote_title_direct_bottom_fit
                && !endnote_title_bottom_fit_applied
                && !compacted_equation_tail_title_gap
            {
                let section_between_notes_gap_px =
                    hwpunit_to_px(self.endnote_between_notes_hu.get(), self.dpi);
                let zero_between_large_separator_profile =
                    self.current_endnote_zero_between_large_separator_profile();
                let effective_endnote_title_gap_px = if zero_between_large_separator_profile {
                    section_between_notes_gap_px
                } else if prev_endnote_title_gap_px >= 50.0 {
                    prev_endnote_title_gap_px
                } else {
                    section_between_notes_gap_px
                };
                let previous_item_para_index = item_ordinal
                    .checked_sub(1)
                    .and_then(|idx| col_content.items.get(idx))
                    .and_then(|prev_item| match prev_item {
                        PageItem::FullParagraph { para_index }
                        | PageItem::PartialParagraph { para_index, .. } => Some(*para_index),
                        _ => None,
                    });
                if let (Some(prev_pi), Some(prev_content_bottom_y)) = (
                    previous_item_para_index.or(hcursor.prev_layout_para),
                    prev_item_content_bottom_y,
                ) {
                    if let Some(prev_para) = paragraphs.get(prev_pi) {
                        let prev_has_textless_equation_tail = inline_equation_count(prev_para) > 0
                            && !para_has_visible_text(prev_para);
                        if prev_has_textless_equation_tail && effective_endnote_title_gap_px >= 50.0
                        {
                            let saved_head_gap_px = paragraphs
                                .get(item_para)
                                .and_then(|current_para| {
                                    let current_source = self.endnote_para_source_for(item_para)?;
                                    let prev_source = self.endnote_para_source_for(prev_pi)?;
                                    if current_source.note_para_index != 0
                                        || same_endnote_control(&current_source, &prev_source)
                                    {
                                        return None;
                                    }
                                    let is_last_column = (col_content.column_index as usize + 1)
                                        >= zone_layout.column_areas.len().max(1);
                                    let visible_separator_large_between_profile =
                                        self.endnote_between_notes_hu.get() > 3000
                                            && self.endnote_separator_above_hu.get()
                                                <= ENDNOTE_BETWEEN_NOTES_BASE_FLOW_HU
                                            && self.endnote_separator_below_hu.get()
                                                <= ENDNOTE_BETWEEN_NOTES_BASE_FLOW_HU;
                                    if !is_last_column || !visible_separator_large_between_profile {
                                        return None;
                                    }
                                    let mut saw_visible_body_before_large_tac = false;
                                    let mut current_head_has_large_tac = false;
                                    for (next_pi, next_para) in
                                        paragraphs.iter().enumerate().skip(item_para + 1).take(24)
                                    {
                                        let Some(next_source) =
                                            self.endnote_para_source_for(next_pi)
                                        else {
                                            continue;
                                        };
                                        if !(same_endnote_control(&current_source, &next_source)
                                            && next_source.note_para_index
                                                > current_source.note_para_index
                                            && next_source.note_para_index
                                                <= current_source.note_para_index + 8)
                                        {
                                            continue;
                                        }
                                        if !para_has_visible_text(next_para)
                                            && para_large_tac_picture_or_shape_height_px(
                                                next_para, self.dpi,
                                            )
                                            .is_some_and(|height| height >= 80.0)
                                            && saw_visible_body_before_large_tac
                                        {
                                            current_head_has_large_tac = true;
                                            break;
                                        }
                                        if para_has_visible_text(next_para) {
                                            saw_visible_body_before_large_tac = true;
                                        }
                                    }
                                    if !current_head_has_large_tac {
                                        return None;
                                    }
                                    let prev_seg = prev_para.line_segs.last()?;
                                    let current_first =
                                        current_para.line_segs.first()?.vertical_pos;
                                    let prev_content_bottom =
                                        prev_seg.vertical_pos + prev_seg.line_height;
                                    let saved_gap_hu = (current_first - prev_content_bottom).max(0);
                                    if saved_gap_hu <= 0 {
                                        return None;
                                    }
                                    let saved_gap_px = hwpunit_to_px(saved_gap_hu, self.dpi);
                                    (saved_gap_px >= 24.0)
                                        .then_some(saved_gap_px.min(effective_endnote_title_gap_px))
                                })
                                .unwrap_or(0.0);
                            let target_y = if saved_head_gap_px > 0.0 {
                                y_offset + saved_head_gap_px
                            } else {
                                prev_content_bottom_y + effective_endnote_title_gap_px
                            };
                            if y_offset + 1.0 < target_y {
                                let delta = target_y - y_offset;
                                y_offset = target_y;
                                hcursor.shift_vpos_base_for_rendered_delta(delta);
                                if saved_head_gap_px > 0.0 {
                                    compacted_equation_tail_title_gap = true;
                                }
                            }
                        }
                    }
                }
            }
            let compact_endnote_title_gap_already_compacted = current_is_endnote_question_title
                && (hcursor.last_compacted_endnote_title_gap || compacted_equation_tail_title_gap);
            let suppress_zero_between_large_separator_title_gap = self
                .current_endnote_zero_between_large_separator_profile()
                && prev_endnote_title_gap_px >= 50.0;
            let textless_equation_tail_gap_already_visible = current_is_endnote_question_title
                && col_content.endnote_flow
                && prev_endnote_title_gap_px > 0.0
                && !prev_endnote_title_gap_from_continued_partial
                && y_before_vpos > col_area.y + col_area.height * 0.65
                && hcursor
                    .prev_layout_para
                    .and_then(|prev_pi| {
                        let prev_para = paragraphs.get(prev_pi)?;
                        let prev_content_bottom_y = prev_item_content_bottom_y?;
                        let prev_has_textless_equation_tail = inline_equation_count(prev_para) > 0
                            && !para_has_visible_text(prev_para);
                        let required_gap_y = prev_content_bottom_y + prev_endnote_title_gap_px;
                        (prev_has_textless_equation_tail && y_offset + 0.5 >= required_gap_y)
                            .then_some(())
                    })
                    .is_some();
            let should_preserve_endnote_title_gap = current_is_endnote_question_title
                && prev_endnote_title_gap_px > 0.0
                && !endnote_title_direct_bottom_fit
                && !endnote_title_bottom_fit_applied
                && !compact_endnote_title_gap_already_compacted
                && !suppress_zero_between_large_separator_title_gap
                && !textless_equation_tail_gap_already_visible
                && !current_title_tail_backtracked
                && !current_large_gap_title_compacted_by_cursor
                && (prev_endnote_title_gap_from_continued_partial
                    || y_offset > y_before_vpos + 0.5);
            if textless_equation_tail_gap_already_visible {
                let min_y = y_before_vpos + prev_endnote_title_gap_px;
                if y_offset < min_y {
                    if let Some(source) = current_endnote_source.clone() {
                        pending_textless_equation_tail_gap_restore =
                            Some((source, min_y - y_offset));
                    }
                }
            }
            if should_preserve_endnote_title_gap {
                // Compact 미주에서 다음 문제 제목이 오면 LINE_SEG의 절대 vpos가
                // 현재 쪽/단 기준과 어긋나 직전 미주 내용 뒤의 "미주 사이"
                // 간격이 사라질 수 있다. 직전 paragraph 조각의 trailing
                // line_spacing을 공통 gap으로 보존하고, 후속 항목도 같은 기준을
                // 따르도록 vpos base를 함께 이동한다.
                // 다만 단 하단부 textless equation tail은 직전 content bottom 기준
                // gap이 이미 충분한 경우가 있다. 이때 logical flow 기준으로 다시
                // 보존하면 다음 문항 영역을 침범하므로 여기서 한 번 더 얹지 않는다.
                let min_y = y_before_vpos + prev_endnote_title_gap_px;
                if y_offset < min_y {
                    let delta = min_y - y_offset;
                    y_offset = min_y;
                    hcursor.shift_vpos_base_for_rendered_delta(delta);
                }
            }
            let current_vpos_rewinds_from_prev = hcursor
                .prev_layout_para
                .and_then(|prev_pi| {
                    let prev_first = paragraphs
                        .get(prev_pi)
                        .and_then(|p| p.line_segs.first())
                        .map(|seg| seg.vertical_pos)?;
                    let curr_first = paragraphs
                        .get(item_para)
                        .and_then(|p| p.line_segs.first())
                        .map(|seg| seg.vertical_pos)?;
                    Some(curr_first < prev_first)
                })
                .unwrap_or(false);

            let next_is_endnote_question_title = col_content.endnote_flow
                && col_content
                    .items
                    .get(item_ordinal + 1)
                    .and_then(|next_item| match next_item {
                        PageItem::FullParagraph { para_index }
                        | PageItem::PartialParagraph { para_index, .. } => Some(*para_index),
                        _ => None,
                    })
                    .and_then(|pi| paragraphs.get(pi))
                    .map(|p| p.text.trim_start().starts_with('문'))
                    .unwrap_or(false);
            if (matches!(
                item,
                PageItem::PartialParagraph { start_line, .. } if *start_line > 0
            ) && !next_is_endnote_question_title)
                || current_vpos_rewinds_from_prev
            {
                // 이어지는 partial paragraph는 이전 쪽/단에서 시작한 문단의 나머지다.
                // 다음 항목과의 간격은 원본 절대 vpos 차이가 아니라 현재 쪽의 순차 y를
                // 따라야 한다. 그렇지 않으면 3-09월 10쪽 첫 수식 뒤 문8)이 크게 밀린다.
                //
                // compact endnote 에서는 같은 쪽/단 안에서도 다음 미주 묶음이 낮은 vpos 로
                // 되감기는 구간이 있다(3-09월 p17/p18). 되감긴 문단을 다음 문단의 기준으로
                // 계속 쓰면 다음 줄이 위로 끌려가 겹치므로 여기서 vpos 기준을 끊는다.
                hcursor.prev_layout_para = None;
                hcursor.vpos_page_base = None;
                hcursor.vpos_lazy_base = None;
                // [#5820] 단, 쪽/단의 **첫 항목**이 이어지는 partial 이면 스냅
                // 기준(base)을 여기서 그 연속 줄의 저장 vpos 로 직접 세운다 —
                // 완전 리셋로 남기면 뒤의 lazy 역산이 빈 문단 trailing-ls bridge
                // 로 base 를 ls 만큼 낮춰 쪽 전체 스냅이 +ls 밀린다(156560092
                // 2쪽: 역산 base 67062 vs 저장 67902, 글상자 y +11.2px — 조판
                // 패스는 같은 자리에서 텍스트-연속 역산으로 67902 를 얻어 두
                // 패스가 발산했다). 순차-y 원칙(위 주석)은 유지된다 — 첫 항목의
                // 배치 y 와 저장 vpos 를 같은 자리에 놓는 base 라 partial 직후
                // 항목의 보정이 순차 y 와 일치한다.
                if item_ordinal == 0
                    || resolved_stored_square_fragment_in_column(
                        &paragraphs[item_para],
                        item_para,
                        col_content,
                        self.dpi,
                    )
                {
                    if let PageItem::PartialParagraph {
                        para_index,
                        start_line,
                        ..
                    } = item
                    {
                        if *start_line > 0 {
                            let seed = paragraphs
                                .get(*para_index)
                                .and_then(|p| p.line_segs.get(*start_line))
                                .filter(|seg| {
                                    seg.tag
                                        & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY
                                        == 0
                                })
                                .map(|seg| {
                                    seg.vertical_pos
                                        - ((y_offset - visual_col_y) / self.dpi * 7200.0).round()
                                            as i32
                                });
                            hcursor.vpos_lazy_base = seed;
                        }
                    }
                }
            } else {
                hcursor.prev_layout_para = Some(item_para);
            }

            // Percent 전환: 표 하단과 비교 (Task #9)
            if fix_overlay_active {
                let is_fixed = paragraphs
                    .get(item_para)
                    .and_then(|p| styles.para_styles.get(p.para_shape_id as usize))
                    .map(|ps| ps.line_spacing_type == crate::model::style::LineSpacingType::Fixed)
                    .unwrap_or(false);
                // [Task #716] 빈 paragraph (text_len=0 또는 control 문자/object placeholder
                // 만 존재) 는 시각적으로 invisible. fix_overlay push 가 적용되어도
                // 보이는 차이가 없는 반면 y_offset 만 (table_bottom - y_offset) 만큼
                // 누적되어 forward drift 의 누적 원인이 된다 (page 1 LAYOUT_OVERFLOW
                // 의 99.3%: pi=1 +8 px + pi=3 +12 px). Task #9 의 push 의도(텍스트
                // paragraph 가 TAC 표 위에 침범하지 않도록 보호) 는 그대로 유지하고,
                // 빈 paragraph 는 push 대상에서 제외한다. fix_overlay_active 는 유지하여
                // 후속 비-empty paragraph 가 push 대상이 될 수 있게 한다.
                // [#4599 ⑨] 공백(스페이스류)만 있는 문단도 #716 의 취지("시각적으로
                // invisible — push 가 보이는 차이 없이 y_offset 드리프트만 누적")와
                // 동일하다. 36392662 p1: was_tac 아이템마다 seg0(lh 1300) 기반의
                // 과소 '표 하단'(621.0/638.3)이 재활성화되며 공백 host 줄과 공백
                // 문단을 +17.3px 씩 두 번 밀어 '나' 절이 사다리·한글 2022 PDF(627.7)
                // 보다 34.5px 아래로 밀렸다 — 공백 문단을 push 대상에서 제외하면
                // 후속 잉크 문단('나')이 627.9 로 정렬된다(실측).
                let is_empty_para = paragraphs
                    .get(item_para)
                    .map(|p| {
                        p.text.is_empty()
                            || p.text
                                .chars()
                                .all(|c| c <= '\u{001F}' || c == '\u{FFFC}' || c.is_whitespace())
                    })
                    .unwrap_or(false);
                if !is_fixed && !is_empty_para {
                    let table_bottom = fix_table_start_y + fix_table_visual_h;
                    if y_offset < table_bottom {
                        y_offset = table_bottom;
                    }
                    fix_overlay_active = false;
                }
            }

            if item_is_paragraph && !visible_float_exclusions.is_empty() {
                // [#4613 · #4599 밴드-플로우] 낡은 사다리 전방 스냅 기각 — 한글 2022 는
                // TopAndBottom 자리차지 표 위 틈에 들어가는 줄을 틈에 배치하는데,
                // 구세대 한글이 저장한 사다리는 그 줄을 표 아래에 둔 채였다
                // (36477266 p2: pi5 'ㅇ 사업명' 저장 Δv=259px = 표 아래, 한글 2022
                // PDF 실측 y=369 = 표 위 틈). 순차 흐름 위치에서 줄 전체가 활성
                // exclusion 밴드 위에 들어가는 단일 줄 문단을 저장 사다리가 밴드
                // 안/아래로 보내면, 그 전방 스냅을 기각하고 사다리 base 를 역보정해
                // 후속 문단의 상대 간격을 유지한다. 서명-한정: hwpx stored layout,
                // 선행 문단 소유 zone, 단일 저장 seg, 8px 초과 전방 스냅만.
                if self.profile.get().hwpx_stored_layout() && y_offset > y_before_vpos_adjust + 8.0
                {
                    // 잉크 있는(비공백 텍스트) 단일 줄만 — 공백 줄의 밴드 배치는
                    // PDF 로 관측 불가한 데다, 전화친절도 6460000-202600001 p58 실측
                    // 에서 공백 줄 기각이 후속 흐름을 −25px 어긋내는 반증이 나왔다.
                    let single_line_probe = paragraphs.get(item_para).and_then(|p| {
                        (p.line_segs.len() == 1 && para_has_non_whitespace_text(p))
                            .then(|| {
                                p.line_segs
                                    .first()
                                    .map(|seg| hwpunit_to_px(seg.line_height, self.dpi))
                            })
                            .flatten()
                    });
                    // 틈이 실제로 비어 있다는 증거 — 직전 렌더 아이템이 zone 소유
                    // 문단의 줄(호스트 제목/줄)이어야 한다. 페이지/단 상단처럼 틈을
                    // 이미 다른 항목(호스트 줄 미방출 상태의 표 상단 영역)이 차지한
                    // 형상에서 기각하면 줄이 그 위에 겹친다(36425171 p4 pi17 실측:
                    // 정당한 96→297 스냅을 기각해 +24.9px 악화 — 귀책 격리로 좁힘).
                    let prev_item_is_owner_line = |owner: usize| {
                        item_ordinal
                            .checked_sub(1)
                            .and_then(|idx| col_content.items.get(idx))
                            .is_some_and(|prev_item| {
                                matches!(prev_item,
                                    PageItem::FullParagraph { para_index }
                                    | PageItem::PartialParagraph { para_index, .. }
                                        if *para_index == owner)
                            })
                    };
                    if let Some(probe) = single_line_probe {
                        if probe > 0.0
                            && visible_float_exclusions.iter().any(|zone| {
                                zone.blocks_text
                                    && zone.owner_para < item_para
                                    && prev_item_is_owner_line(zone.owner_para)
                                    && y_before_vpos_adjust + probe <= zone.top + 0.5
                                    && y_offset + 0.5 >= zone.top
                            })
                        {
                            let delta = y_offset - y_before_vpos_adjust;
                            y_offset = y_before_vpos_adjust;
                            hcursor.shift_vpos_base_for_rendered_backtrack(delta);
                        }
                    }
                }
                visible_float_exclusions
                    .retain(|zone| zone.fixed_textbox || y_offset < zone.bottom - 0.5);
                // [Task #1794] 잉크-겹침 프로브를 HWP5 소스에도 적용 — 자리차지 표의
                // exclusion zone 과 문단 첫 줄 잉크가 겹치면 소스 포맷과 무관하게 표
                // 아래로 밀어야 한다 (seoul_0765: HWPX 직파스와 HWP5 재파스의 표 앵커
                // 95.16px 갈림). HWPX 전용 게이트는 도입 당시 blast radius 제한이었다.
                let item_probe_height = {
                    match item {
                        PageItem::FullParagraph { para_index } => paragraphs
                            .get(*para_index)
                            .and_then(|p| {
                                p.line_segs.first().map(|seg| {
                                    let line_height = if p.controls.is_empty()
                                        && seg.text_height > 0
                                        && seg.text_height < seg.line_height
                                    {
                                        seg.text_height
                                    } else {
                                        seg.line_height
                                    };
                                    // [Task #1789] line_spacing 은 겹침 판정에서 제외 —
                                    // 잉크가 zone 위에 들어가는 줄을 spacing 포함분 수 px
                                    // 겹침으로 표 아래로 밀면 한컴 저장 flow(36385142 pi8
                                    // vpos=34925 = 표 위 유지)와 어긋난다 (최대 345px).
                                    hwpunit_to_px(line_height, self.dpi)
                                })
                            })
                            .unwrap_or(0.0),
                        PageItem::PartialParagraph {
                            para_index,
                            start_line,
                            ..
                        } => paragraphs
                            .get(*para_index)
                            .and_then(|p| {
                                p.line_segs.get(*start_line).map(|seg| {
                                    let line_height = if p.controls.is_empty()
                                        && seg.text_height > 0
                                        && seg.text_height < seg.line_height
                                    {
                                        seg.text_height
                                    } else {
                                        seg.line_height
                                    };
                                    // [Task #1789] line_spacing 은 겹침 판정에서 제외 —
                                    // 잉크가 zone 위에 들어가는 줄을 spacing 포함분 수 px
                                    // 겹침으로 표 아래로 밀면 한컴 저장 flow(36385142 pi8
                                    // vpos=34925 = 표 위 유지)와 어긋난다 (최대 345px).
                                    hwpunit_to_px(line_height, self.dpi)
                                })
                            })
                            .unwrap_or(0.0),
                        _ => 0.0,
                    }
                };
                // NO_LS 본문은 저장 줄 probe가 0이다. 현재 frame에서 계산한
                // 잉크 높이를 사용하되 줄간격은 기존 계약처럼 충돌 검사에서 뺀다.
                let probe_line = match item {
                    PageItem::PartialParagraph { start_line, .. } => *start_line,
                    _ => 0,
                };
                let item_probe_height = paragraphs
                    .get(item_para)
                    .and_then(|para| {
                        self.computed_plain_text_probe_height(
                            para,
                            composed.get(item_para),
                            styles,
                            col_area.width,
                            probe_line,
                            col_content.wrap_anchors.contains_key(&item_para),
                        )
                    })
                    .unwrap_or(item_probe_height);
                let mut jump_to = y_offset;
                // [#2808] 단일 표 host 의 post-text 는 한컴에서 앵커에 남는다(#1549 유지).
                // exclusion 소비는 #2439 의 다중 co-anchored float 스택(표 2개+서명란)
                // 형상에서만 필요하므로, owner 문단의 co-anchored float 가 2개 이상일
                // 때로 한정한다 — 아니면 별지/서식류 단일 표 문서가 +1 과분할된다.
                let owner_has_coanchored_stack = paragraphs
                    .get(item_para)
                    .map(|owner| {
                        owner
                            .controls
                            .iter()
                            .filter(|control| {
                                matches!(control, Control::Table(t)
                                    if is_para_topbottom_float(&t.common))
                            })
                            .count()
                            >= 2
                    })
                    .unwrap_or(false);
                let same_owner_table_precedes = owner_has_coanchored_stack
                    && col_content.items[..item_ordinal].iter().any(|previous| {
                        matches!(previous,
                            PageItem::Table { para_index, .. }
                                | PageItem::PartialTable { para_index, .. }
                                if *para_index == item_para)
                    });
                // [#4613 · #4599 밴드-플로우] 잉크 없는(공백 전용·컨트롤 없음) 문단은 밴드와
                // 충돌할 잉크가 없다 — 한글 2022 는 이런 빈 줄을 자리차지 표 밴드에
                // 겹친 채 그대로 두고, 다음 잉크 줄부터 표 아래에서 재개한다
                // (36477266 p2 pi7 ' ': 한글 유지 y 425..439, 표 하단 583.2 직후
                // 4.3px 에서 pi8 재개 — PDF 실측). hwpx stored layout 한정.
                let item_para_inkless = self.profile.get().hwpx_stored_layout()
                    && paragraphs
                        .get(item_para)
                        .is_some_and(|p| p.controls.is_empty() && !para_has_non_whitespace_text(p));
                // [#6761] 자리차지 표 밴드 뒤 문단의 **앞 간격은 밴드 안에서 소비된다** — 첫 줄
                // top 은 `max(흐름 + 앞 간격, 밴드 하단)` 이다. 문단 layout 이 첫 줄 앞에 이
                // 간격을 더하므로 밴드로 밀 때 그만큼 덜 민다.
                //
                // 근거는 한컴 저장 사다리다. 코퍼스 HWP5 6,582건에서 "글자 있는 host 의 비-TAC
                // 자리차지 표(vert=문단, 양수 offset) 다음 문단(앞 간격 > 0)" 141곳을 재면 다음
                // 문단 vpos 가 표 바깥여백 상자 하단과 **90곳 모두 0HU 차로 같고**, 하단+앞 간격인
                // 곳은 0곳이다(나머지는 쪽을 넘는 표·캡션). `1480000-201900042` 83쪽 pi=153:
                // 저장 44518 = 표 상자 하단 44518, 정본 PDF 도 같은 자리인데 rhwp 는 20px 아래에
                // 그려 마지막 표가 본문 바닥을 넘었다. typeset 은 이미 저장 자리로 회계한다.
                // HWPX 코퍼스는 흡수 8 · 가산 4(쪽 원점 없는 연속 vpos 생성기)로 갈리므로 HWP5
                // 저장 사다리 프로필에만 적용한다.
                let band_absorbed_spacing_before = match item {
                    PageItem::FullParagraph { .. }
                        if self.profile.get().hwp5_stored_pagination_layout() =>
                    {
                        paragraphs
                            .get(item_para)
                            .and_then(|p| styles.para_styles.get(p.para_shape_id as usize))
                            .map(|s| {
                                crate::renderer::hwp3_variant_flow_spacing_before(
                                    s.spacing_before,
                                    self.use_hwp3_origin_flow_spacing_before.get(),
                                )
                            })
                            .unwrap_or(0.0)
                            .max(0.0)
                    }
                    _ => 0.0,
                };
                let mut jump_line_lead = 0.0;
                for zone in &visible_float_exclusions {
                    // [Issue #1549] 자기 문단에 앵커된 float 표는 그 문단의 텍스트(제목)를
                    // 밀어내지 않는다 — 제목은 앵커(표 위)에 남아야 한다. owner 가 다른 후속
                    // 문단은 그대로 표 아래로 밀린다.
                    // [#2439] 단, 같은 문단의 표 항목 뒤에 emit 된 post-text(서명란)는
                    // 이미 표 뒤 순서로 확정된 것이므로 자기 exclusion 도 소비해야 한다.
                    if zone.owner_para == item_para && !same_owner_table_precedes {
                        continue;
                    }
                    // [#5929] 어울림 그림 밴드는 본문 텍스트가 옆을 흐른다 — 자리차지
                    // 표만 피하면 된다 (layout_table_control_block 의 consult).
                    if !zone.blocks_text {
                        continue;
                    }
                    if item_para_inkless {
                        continue;
                    }
                    let starts_in_zone = jump_to + 0.5 >= zone.top && jump_to < zone.bottom;
                    let overlaps_zone = item_probe_height > 0.0
                        && jump_to < zone.top
                        && jump_to + item_probe_height > zone.top + 0.5;
                    if starts_in_zone || overlaps_zone {
                        let absorbed = if zone.fixed_textbox {
                            0.0
                        } else {
                            band_absorbed_spacing_before
                        };
                        let target = (zone.bottom - absorbed).max(zone.top);
                        if target > jump_to {
                            jump_to = target;
                            jump_line_lead = zone.bottom - target;
                        }
                    }
                }
                if jump_to > y_offset + 0.5 {
                    let delta = jump_to - y_offset;
                    y_offset = jump_to;
                    // [#4533] 자리차지 밴드의 공간이 저장 사다리에 이미 인코딩된
                    // 문서(2135039: pi7 vpos 11535 = 밴드 포함 위치, 기대 229.4 ==
                    // 점프 결과)에서 base 를 이동하면 후속 전 문단이 밴드 높이만큼
                    // 이중 전진한다(+123.9px). 점프 결과가 사다리 기대와 일치하면
                    // 이동을 생략한다 — 사다리가 밴드를 모르는 문서(점프가 진짜
                    // 렌더-외 변위)만 종전대로 이동.
                    let ladder_encodes_jump = paragraphs
                        .get(item_para)
                        .and_then(|p| p.line_segs.first())
                        .and_then(|s| hcursor.ladder_expected_y(col_area.y, s.vertical_pos))
                        // 사다리 기대값은 첫 줄 top 이다 — 흡수한 앞 간격까지 더한 자리와 잰다.
                        .map(|exp| (exp - (jump_to + jump_line_lead)).abs() <= 6.0)
                        .unwrap_or(false);
                    if !ladder_encodes_jump {
                        hcursor.shift_vpos_base_for_rendered_delta(delta);
                    }
                }
            }

            // [#6797, #6798] 빈 host의 표가 앞 문단 float 밴드와 실제로 충돌할
            // 때만 저장 앵커로 회피한다. 원본 pi=71의 목표 top은 296.8px다.
            // host 텍스트가 있는 경우는 문단 경로가 스냅을 소유한다.
            // 이 경로는 현재 단에 들어가는 유효한 저장 좌표만 사용하며, offset
            // 배치 또는 이미 회피된 표를 다시 이동하지 않는다.
            // exclusion은 후행 형제도 소비하므로 여기서 제거하지 않는다.
            if !item_is_paragraph && !visible_float_exclusions.is_empty() {
                if let PageItem::Table {
                    para_index: table_para,
                    control_index,
                } = item
                {
                    let anchor = paragraphs.get(*table_para);
                    // [#6798] 문단 상단 기준의 zero-offset 표에만 저장 앵커를 적용한다.
                    // 바깥 여백은 위치 offset이 아니다. 원본 pi=71도 위 여백이
                    // 141 HU이므로 이를 0으로 제한하면 정상 회피까지 막는다.
                    // 다른 위치 기준, 정렬, offset은 표 배치 경로의 소유다.
                    let flow_table = anchor.and_then(|para| {
                        let Some(Control::Table(table)) = para.controls.get(*control_index) else {
                            return None;
                        };
                        (!para_has_visible_text(para)
                            && !table.common.treat_as_char
                            && table.common.vert_rel_to == crate::model::shape::VertRelTo::Para
                            && table.common.vert_align == crate::model::shape::VertAlign::Top
                            && table.common.vertical_offset == 0)
                            .then_some(table)
                    });
                    let stored_top = anchor
                        .and_then(|para| {
                            para.line_segs.iter().find(|seg| {
                                seg.tag
                                    & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY
                                    == 0
                            })
                        })
                        .map(|seg| col_area.y + hwpunit_to_px(seg.vertical_pos, self.dpi));
                    if let (Some(table), Some(stored_top)) = (flow_table, stored_top) {
                        let height = hwpunit_to_px(
                            table.common.height.min(i32::MAX as u32) as i32,
                            self.dpi,
                        ) + hwpunit_to_px(table.outer_margin_top as i32, self.dpi)
                            + hwpunit_to_px(table.outer_margin_bottom as i32, self.dpi);
                        let column_bottom = col_area.y + col_area.height;
                        // 현재 페이지에 속한 완전한 표만 대상으로 한다. 범위 밖 저장
                        // 좌표를 clamp한 뒤 채택하면 잘못된 페이지 소유를 감추게 된다.
                        if stored_top.is_finite()
                            && y_offset.is_finite()
                            && height > 0.0
                            && stored_top >= col_area.y
                            && stored_top + height <= column_bottom + 0.5
                        {
                            let jump_to = visible_float_exclusions
                                .iter()
                                .filter(|zone| zone.blocks_text && zone.owner_para < *table_para)
                                // 이미 회피한 표, 또는 밴드에 닿지 않는 표는 불변이다.
                                .filter(|zone| {
                                    y_offset < zone.bottom
                                        && y_offset + height > zone.top
                                        && stored_top + 0.5 >= zone.bottom
                                })
                                .fold(y_offset, |acc, _| acc.max(stored_top));
                            if jump_to > y_offset + 0.5 {
                                y_offset = jump_to;
                            }
                        }
                    }
                }
            }

            // [#6784] 밴드를 벗어난 첫 항목 자체를 표 아래에서 그린다.
            // paint 뒤 new_y만 올리면 저장 vpos가 없는 첫 항목은 이미 겹쳐 있다.
            if let Some((bottom, lane_left_hu, lane_right_hu)) = square_beside_band {
                if !stored_seg_is_side_lane(
                    paragraphs.get(item_para),
                    page_item_first_line(item),
                    col_w_hu,
                    lane_left_hu,
                    lane_right_hu,
                ) {
                    y_offset = y_offset.max(bottom);
                    square_beside_band = None;
                }
            }

            let _dbg_tac = std::env::var("RHWP_DEBUG_TAC_CURSOR").is_ok();
            let _y_in = y_offset;
            let _item_desc = if _dbg_tac {
                match item {
                    PageItem::FullParagraph { para_index } => format!("FullPara pi={}", para_index),
                    PageItem::PartialParagraph { para_index, .. } => {
                        format!("PartialPara pi={}", para_index)
                    }
                    PageItem::Table {
                        para_index,
                        control_index,
                    } => format!("Table pi={} ci={}", para_index, control_index),
                    PageItem::PartialTable {
                        para_index,
                        control_index,
                        ..
                    } => format!("PartialTable pi={} ci={}", para_index, control_index),
                    PageItem::Shape {
                        para_index,
                        control_index,
                        ..
                    } => format!("Shape pi={} ci={}", para_index, control_index),
                    PageItem::EndnoteSeparator { .. } => "EndnoteSeparator".to_string(),
                }
            } else {
                String::new()
            };
            // [Task #1046 Stage 3 Class B] 표 콘텐츠 하단 기록을 항목마다 리셋 —
            // 표 항목 렌더에서만 설정되므로, 비-표 항목/다른 표에 stale 값이 새지 않는다.
            self.last_item_content_bottom.set(f64::NAN);
            self.last_item_flow_line_bottom.set(f64::NAN);
            self.last_item_endnote_equation_tail_line_box.set(false);
            if !matches!(item, PageItem::Table { .. }) {
                self.host_text_content_bottom.set(None);
            }
            let zero_between_shape_tail_margin_px = match item {
                PageItem::Shape {
                    para_index,
                    control_index,
                } if col_content.endnote_flow
                    && item_ordinal == 0
                    && self.current_endnote_zero_between_large_separator_profile() =>
                {
                    let current_source = self.endnote_para_source_for(*para_index);
                    let next_para_index =
                        col_content
                            .items
                            .get(item_ordinal + 1)
                            .and_then(|it| match it {
                                PageItem::FullParagraph { para_index }
                                | PageItem::PartialParagraph { para_index, .. }
                                | PageItem::Table { para_index, .. }
                                | PageItem::PartialTable { para_index, .. }
                                | PageItem::Shape { para_index, .. } => Some(*para_index),
                                PageItem::EndnoteSeparator { .. } => None,
                            });
                    let next_is_new_question = next_para_index
                        .and_then(|next_pi| {
                            let next_para = paragraphs.get(next_pi)?;
                            let next_source = self.endnote_para_source_for(next_pi)?;
                            let current_source = current_source.as_ref()?;
                            let same_note = current_source.section_index
                                == next_source.section_index
                                && current_source.para_index == next_source.para_index
                                && current_source.control_index == next_source.control_index;
                            (endnote_question_number(next_para).is_some() && !same_note)
                                .then_some(())
                        })
                        .is_some();
                    if next_is_new_question {
                        paragraphs
                            .get(*para_index)
                            .and_then(|para| {
                                textless_non_tac_topbottom_object_tail_advance_px(
                                    para,
                                    *control_index,
                                    self.dpi,
                                )
                            })
                            .unwrap_or(0.0)
                    } else {
                        0.0
                    }
                }
                _ => 0.0,
            };
            // 구분선 직후 첫 미주 본문: belowLine 바닥(new_y)으로 floor.
            if let Some(floor) = endnote_sep_body_floor.take() {
                y_offset = y_offset.max(floor);
            }
            // [#5699 H1] 표 아이템의 시작 y — 아래 페인트 높이 산출용.
            // A validated stored host and its tail table share the origin fixed
            // before pagination fit. Generate text here; do not relocate a painted
            // table tree (line/path coordinates need not live in node.bbox).
            if matches!(
                item,
                PageItem::FullParagraph { .. } | PageItem::PartialParagraph { start_line: 0, .. }
            ) {
                if let Some(origin) = col_content.paragraph_float_placements.iter().find_map(
                    |(&(pi, _), placement)| {
                        (pi == item_para)
                            .then_some(placement.stored_host_origin)
                            .flatten()
                    },
                ) {
                    let spacing_before = styles
                        .para_styles
                        .get(paragraphs[item_para].para_shape_id as usize)
                        .map(|style| style.spacing_before)
                        .unwrap_or(0.0);
                    y_offset = col_area.y + origin - spacing_before;
                }
            }
            if matches!(
                item,
                PageItem::FullParagraph { .. } | PageItem::PartialParagraph { start_line: 0, .. }
            ) {
                let previous_is_partial_table = item_ordinal
                    .checked_sub(1)
                    .and_then(|index| col_content.items.get(index))
                    .is_some_and(|previous| {
                        matches!(previous, PageItem::PartialTable { para_index, .. } if *para_index < item_para)
                    });
                let spacing_before = styles
                    .para_styles
                    .get(paragraphs[item_para].para_shape_id as usize)
                    .map(|style| style.spacing_before)
                    .unwrap_or(0.0);
                let stored_frame_shared_spacing =
                    crate::renderer::float_placement::stored_frame_successor_shared_spacing_px(
                        &col_content.paragraph_float_placements,
                        item_para,
                        spacing_before,
                        y_offset - col_area.y,
                    );
                y_offset -= stored_frame_shared_spacing;
                let shared_spacing =
                    crate::renderer::float_placement::stored_after_partial_table_shared_spacing_px(
                        (self.profile.get().hwpx_stored_layout()
                            || self.profile.get().hwp5_stored_pagination_layout())
                            && !self.profile.get().session_edited(),
                        previous_is_partial_table,
                        &paragraphs[item_para],
                        spacing_before,
                        y_offset - col_area.y,
                        self.dpi,
                    );
                y_offset -= shared_spacing;
                let caption_shared_spacing =
                    crate::renderer::float_placement::hwpx_after_picture_caption_shared_spacing_px(
                        self.profile.get().hwpx_stored_layout()
                            && !self.profile.get().session_edited(),
                        item_para.checked_sub(1).and_then(|i| paragraphs.get(i)),
                        &paragraphs[item_para],
                        spacing_before,
                        y_offset - col_area.y,
                        self.dpi,
                    );
                y_offset -= caption_shared_spacing;
            }
            // 저장 HWPX는 떠 있는 그림의 배치 하단에 빈 문단을 정확히 놓을 수 있다.
            // 그 빈 문단의 한 줄은 그림과 뒤 캡션 사이를 구분한다.
            // 그림 호스트의 줄높이는 이미 흐름 커서에 포함되어 있으므로 다시 더하면
            // 빈 줄과 캡션, 이후 본문이 함께 밀린다(#7406, 92–93쪽).
            // 다음 문단의 저장 원점은 음수 간격을 포함한 빈 줄의 물리 전진도 소유한다.
            // 빈 글자의 표시를 숨기더라도 독립적으로 저장된 그 간격을 지우면 안 된다.
            let mut saved_picture_empty_flow_end = None;
            if self.profile.get().hwpx_stored_layout() && !self.profile.get().session_edited() {
                let picture_bottom_origin = (|| {
                    let PageItem::FullParagraph { para_index } = item else {
                        return None;
                    };
                    let PageItem::Shape {
                        para_index: host_index,
                        control_index,
                    } = col_content.items.get(item_ordinal.checked_sub(1)?)?
                    else {
                        return None;
                    };
                    if *host_index + 1 != *para_index {
                        return None;
                    }
                    let host = paragraphs.get(*host_index)?;
                    let para = paragraphs.get(*para_index)?;
                    let next = paragraphs.get(*para_index + 1)?;
                    let Control::Picture(picture) = host.controls.get(*control_index)? else {
                        return None;
                    };
                    if picture.common.treat_as_char
                        || picture.common.text_wrap != TextWrap::TopAndBottom
                        || picture.caption.is_some()
                        || !para.text.trim().is_empty()
                        || !para.controls.is_empty()
                        || para.line_segs.len() != 1
                    {
                        return None;
                    }
                    let saved_line = para.line_segs.first()?;
                    let next_line = next.line_segs.first()?;
                    let saved_advance = next_line
                        .vertical_pos
                        .checked_sub(saved_line.vertical_pos)?;
                    let full_advance = saved_line
                        .line_height
                        .checked_add(saved_line.line_spacing)?;
                    if saved_line.tag
                        & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY
                        != 0
                        || next_line.tag
                            & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY
                            != 0
                        || saved_advance <= 0
                        || (saved_advance != saved_line.line_height
                            && saved_advance != full_advance)
                    {
                        return None;
                    }
                    let image_bottom = col_node.children.iter().rev().find_map(|node| {
                        let RenderNodeType::Image(image) = &node.node_type else {
                            return None;
                        };
                        (image.para_index == Some(*host_index)
                            && image.control_index == Some(*control_index))
                        .then_some(node.bbox.y + node.bbox.height)
                    })?;
                    let saved_y = col_area.y
                        + hwpunit_to_px(
                            saved_line.vertical_pos - vpos_page_base_init.unwrap_or(0),
                            self.dpi,
                        );
                    let flow_end = image_bottom + hwpunit_to_px(saved_advance, self.dpi);
                    ((saved_y - image_bottom).abs() <= 1.0
                        && y_offset > image_bottom + 0.5
                        && image_bottom >= col_area.y
                        && flow_end <= col_area.y + col_area.height + 0.5)
                        .then_some((image_bottom, flow_end))
                })();
                if let Some((origin, flow_end)) = picture_bottom_origin {
                    y_offset = origin;
                    saved_picture_empty_flow_end = Some(flow_end);
                }
            }
            // [#7063] 저장-vpos 스냅 이전의 흐름 커서와 직전 아이템 내용 바닥을
            // 아이템 배치에 넘긴다.
            self.item_flow_snap_context.set(
                prev_item_content_bottom_y.map(|prev_bottom| (y_before_vpos_adjust, prev_bottom)),
            );
            let item_start_y_for_band = y_offset;
            let (mut new_y, was_tac) = self.layout_column_item(
                tree,
                &mut col_node,
                paper_images,
                &mut para_start_y,
                &mut deferred_paragraph_spacing,
                &mut para_float_lanes,
                &mut visible_float_exclusions,
                &mut para_inline_state,
                item,
                page_content,
                paragraphs,
                composed,
                styles,
                bin_data_content,
                measured_tables,
                layout,
                col_area,
                zone_column_count,
                outline_numbering_id,
                multi_col_width,
                y_offset,
                prev_tac_seg_applied,
                column_wrap_around_paras,
                &col_content.wrap_anchors,
                &col_content.inline_placements,
                &col_content.inline_flow_plans,
                &col_content.paragraph_float_placements,
            );
            // 명시적 부분 본문이 이미 줄 흐름을 소비한 확정 Exclusion 표는
            // 기하만 출력한다. 표의 시각 하단을 본문 전진으로 다시 더하지 않는다.
            if matches!(item, PageItem::Table { .. })
                && resolved_stored_square_fragment_in_column(
                    &paragraphs[item_para],
                    item_para,
                    col_content,
                    self.dpi,
                )
            {
                new_y = _y_in;
            }
            if let Some(flow_end) = saved_picture_empty_flow_end {
                new_y = flow_end;
            }
            if let PageItem::FullParagraph { para_index } = item {
                if let Some(plan) = col_content.inline_flow_plans.get(para_index) {
                    hcursor.min_flow_floor = hcursor.min_flow_floor.max(col_area.y + plan.end);
                }
            }
            if zero_between_shape_tail_margin_px > 0.0 {
                // 미주 사이 0에서 직전 미주의 마지막 수식 tail을 앞 단에 남기고
                // 비TAC 그림만 다음 단으로 넘긴 경우, 한컴은 그림 뒤 bottom margin을
                // 새 문항 앞 빈 줄처럼 소비하지 않는다.
                new_y = (new_y - zero_between_shape_tail_margin_px).max(_y_in);
            }
            if _dbg_tac {
                eprintln!(
                    "TAC_CURSOR  {} y_in={:.1} y_out={:.1} dy={:.1} was_tac={}",
                    _item_desc,
                    _y_in,
                    new_y,
                    new_y - _y_in,
                    was_tac,
                );
            }
            if col_content.endnote_flow && std::env::var("RHWP_EN_SSOT_DEBUG").is_ok() {
                eprintln!(
                    "EN_RENDER pi={} y_in_rel={:.1} y_out_rel={:.1} dy={:.1} col_h={:.1}",
                    item_para,
                    _y_in - col_area.y,
                    new_y - col_area.y,
                    new_y - _y_in,
                    col_area.height,
                );
            }
            // [#5699 H2] TopAndBottom(위·아래 어울림) 비-tac 그림/도형 Shape 아이템은
            // 단 흐름을 후퇴시키지 못한다 — Square 는 후속 텍스트가 개체 옆으로
            // 흐르도록 앵커 y 로 되돌리는 것이 정당하지만, TopAndBottom 은 텍스트가
            // 개체 아래에서만 이어지므로 후퇴는 이미 전진한 흐름(저장 앵커 줄)을
            // 지운다. 베트남노동시장1125 p75 실측: host 문단의 TopAndBottom 차트
            // Shape 아이템이 841.7→307.6 으로 흐름을 되감아 후속 문단들이 방금
            // 페인트한 표(307..549)를 관통했다.
            if new_y < _y_in {
                if let PageItem::Shape {
                    para_index,
                    control_index,
                } = item
                {
                    let topbottom_nontac = paragraphs
                        .get(*para_index)
                        .and_then(|p| p.controls.get(*control_index))
                        .is_some_and(|c| {
                            let common = match c {
                                Control::Picture(pic) => Some(&pic.common),
                                Control::Shape(shape) => Some(shape.common()),
                                Control::Equation(eq) => Some(&eq.common),
                                _ => None,
                            };
                            common.is_some_and(|cm| {
                                !cm.treat_as_char
                                    && matches!(
                                        cm.text_wrap,
                                        crate::model::shape::TextWrap::TopAndBottom
                                    )
                            })
                        });
                    if topbottom_nontac {
                        if std::env::var("RHWP_5699_DBG").is_ok() {
                            eprintln!(
                                "DBG5699_H2 pi={} ci={} rewind {:.1}→{:.1} 금지",
                                para_index, control_index, _y_in, new_y
                            );
                        }
                        new_y = _y_in;
                    }
                }
            }
            // [#6888] 자기 앵커보다 **아래로 떨어진** 자리차지 개체는 흐름을 전진시키지
            // 않는다. `#409` 의 전진은 밴드가 앵커에서 시작할 때의 계약이고, 양수
            // `vertOffset` 이 밴드를 아래로 내려 놓으면 그 사이 콘텐츠는 밀릴 이유가 없다.
            // 조판과 같은 판별을 써야 `#409` 가 막으려던 desync 가 안 생긴다.
            if new_y > _y_in {
                if let PageItem::Shape {
                    para_index,
                    control_index,
                } = item
                {
                    let displaced = paragraphs.get(*para_index).is_some_and(|para| {
                        para.controls
                            .get(*control_index)
                            .and_then(|control| match control {
                                Control::Picture(pic) => Some(&pic.common),
                                Control::Shape(shape) => Some(shape.common()),
                                Control::Equation(eq) => Some(&eq.common),
                                _ => None,
                            })
                            .is_some_and(|common| {
                                crate::renderer::topbottom_float_displaced_below_following_flow(
                                    para,
                                    paragraphs.get(*para_index + 1),
                                    common,
                                    self.dpi,
                                )
                            })
                    });
                    if displaced {
                        new_y = _y_in;
                    }
                }
            }
            // [#6778] Square(어울림) 표 옆 레인 — 흐름은 host 줄만 전진한다.
            //
            // 조판(`#4090` `hangul_flowed_beside_table`)은 저장 host 줄높이가 표
            // 높이의 1/4 미만이면 표를 **세로 배제 밴드**로 잡고 흐름은 host 줄만
            // 전진시킨다. 렌더에는 그 짝이 없어 표 높이를 통째로 태웠고, 저장 사다리가
            // 옆 레인(`column_start`/`segment_width`)을 지정한 후속 문단이 **가로만**
            // 옆으로 가고 세로는 표 아래로 밀렸다(156757920 1쪽: 렌더 +202.1px,
            // 4줄이 본문·용지 밖). 되돌리려 해도 역행이 커서 vpos 스냅 가드가 기각한다.
            if let PageItem::Table {
                para_index,
                control_index,
            } = item
            {
                if let Some((advance, band_bottom, lane_left_hu, lane_right_hu)) =
                    paragraphs.get(*para_index).and_then(|para| {
                        let Some(Control::Table(t)) = para.controls.get(*control_index) else {
                            return None;
                        };
                        if t.common.treat_as_char
                            || !matches!(t.common.text_wrap, crate::model::shape::TextWrap::Square)
                            || para_has_visible_text(para)
                        {
                            return None;
                        }
                        // 개체 상자를 **단 기준**으로 읽을 수 있을 때만 진행한다 —
                        // `column_start` 가 단 기준이라 다른 기준계와는 대조가 성립하지
                        // 않는다.
                        if !matches!(
                            t.common.horz_rel_to,
                            crate::model::shape::HorzRelTo::Column
                                | crate::model::shape::HorzRelTo::Para
                        ) {
                            return None;
                        }
                        let total =
                            hwpunit_to_px(t.common.height.min(i32::MAX as u32) as i32, self.dpi)
                                + hwpunit_to_px(t.outer_margin_top as i32, self.dpi)
                                + hwpunit_to_px(t.outer_margin_bottom as i32, self.dpi);
                        let host_lh = para
                            .line_segs
                            .iter()
                            .find(|s| s.tag & 0x8000_0000 == 0)
                            .map(|s| hwpunit_to_px(s.line_height, self.dpi))?;
                        let table_w_hu = t.common.width.min(i32::MAX as u32) as i32;
                        let left_hu = crate::renderer::float_placement::signed_hwpunit(
                            t.common.horizontal_offset,
                        )
                        .max(0);
                        (total > 1.0 && host_lh < total * 0.25 && table_w_hu > 0).then_some((
                            host_lh,
                            _y_in + total,
                            left_hu,
                            left_hu.saturating_add(table_w_hu),
                        ))
                    })
                {
                    // ⚠ 저장 사다리가 **다음 항목을 개체 오른쪽 레인에 두었을 때만**
                    // 발동한다. 이 한 겹이 `#4090`(156492236)을 가른다 — 그 문서는
                    // 개체가 오른쪽(`horz=문단(26319)`)이고 후속 문단이 `cs=0` 인
                    // 왼쪽 레인이라 술어를 통과하지 못한다(실측: 해당 문서의 Square
                    // 표 15곳 전부 `next_is_lane=false`). 이 겹을 빼면 그 문서의
                    // 레인과 표 아래 꼬리가 함께 위로 밀려 글자겹침이 4 → 64건이 된다.
                    let next_item = col_content.items.get(item_ordinal + 1);
                    let next_is_lane = next_item
                        .and_then(page_item_para_index)
                        .and_then(|next_pi| paragraphs.get(next_pi))
                        .is_some_and(|next| {
                            stored_seg_is_side_lane(
                                Some(next),
                                next_item.map_or(0, page_item_first_line),
                                col_w_hu,
                                lane_left_hu,
                                lane_right_hu,
                            )
                        });
                    // 렌더가 host 줄보다 많이 태웠을 때만 되돌린다. 이미 host 줄만
                    // 전진했다면 손댈 것이 없다.
                    if next_is_lane && new_y > _y_in + advance + 0.5 {
                        new_y = _y_in + advance;
                        square_beside_band = Some((band_bottom, lane_left_hu, lane_right_hu));
                    } else if let Some(stored_y) = col_content
                        .items
                        .get(item_ordinal + 1)
                        .and_then(|next| match next {
                            // [#7158] 다음 항목이 **이 표 옆에서 이미 그려진 문단의
                            // 나머지**인 경우. 위 `next_is_lane` 축(다음 항목 전체가
                            // 옆 레인)과 다르다 — 여기서는 앞줄만 옆에 놓였고 나머지는
                            // 표 아래 전폭으로 이어진다. 흐름이 표 높이를 다시 타면
                            // 같은 문단 안에서 줄이 떨어진다(156492236 9쪽 +95.5px).
                            PageItem::PartialParagraph {
                                para_index: next_pi,
                                start_line,
                                ..
                            } if *start_line > 0 => {
                                let continues_this_table =
                                    column_wrap_around_paras.iter().any(|w| {
                                        w.para_index == *next_pi
                                            && w.has_text
                                            && w.end_line == *start_line
                                            && w.table_para_index == *para_index
                                    });
                                if !continues_this_table {
                                    return None;
                                }
                                // prefix의 실제 배치 결과를 이어받는다. 단 상단에 저장
                                // 절대 vpos를 더하면 선행 여백으로 이동한 표 앵커를 잃어
                                // 첫 줄만 내려가고 suffix와 겹친다.
                                let seg = paragraphs.get(*next_pi)?.line_segs.get(*start_line)?;
                                let previous_line = u32::try_from(start_line - 1).ok()?;
                                col_node.children.iter().rev().find_map(|node| {
                                    let RenderNodeType::TextLine(line) = &node.node_type else {
                                        return None;
                                    };
                                    if line.section_index != Some(page_content.section_index)
                                        || line.para_index != Some(*next_pi)
                                        || line.line_index != Some(previous_line)
                                    {
                                        return None;
                                    }
                                    let previous_vpos = line.vpos?;
                                    let delta = seg.vertical_pos.checked_sub(previous_vpos)?;
                                    (previous_vpos >= 0 && delta >= 0)
                                        .then(|| node.bbox.y + hwpunit_to_px(delta, self.dpi))
                                })
                            }
                            _ => None,
                        })
                        .filter(|y| new_y > *y + 0.5)
                    {
                        new_y = stored_y;
                        square_beside_band = Some((band_bottom, lane_left_hu, lane_right_hu));
                    }
                }
            }
            // #6950: paragraph completion owns the union of text flow and the
            // resolved trailing object, independently of their emission order.
            // Only the final item closes the paragraph. Following paragraphs,
            // including empty ones, consume their own line advances afterwards.
            if paragraph_last_items.get(&item_para) == Some(&item_ordinal) {
                if let Some(spacing) = deferred_paragraph_spacing.remove(&item_para) {
                    new_y += spacing;
                }
                let spacing_after = paragraphs
                    .get(item_para)
                    .and_then(|para| styles.para_styles.get(para.para_shape_id as usize))
                    .map_or(0.0, |style| style.spacing_after);
                for (&(owner, _), placement) in &col_content.paragraph_float_placements {
                    if owner == item_para
                        && matches!(
                            placement.flow,
                            super::float_placement::ParagraphFloatFlow::StoredPicture { .. }
                        )
                    {
                        new_y =
                            col_area.y + placement.paragraph_end(new_y - col_area.y, spacing_after);
                    }
                    if owner == item_para
                        && placement.flow == super::float_placement::ParagraphFloatFlow::NextLine
                    {
                        new_y =
                            col_area.y + placement.paragraph_end(new_y - col_area.y, spacing_after);
                        hcursor.min_flow_floor = hcursor.min_flow_floor.max(new_y);
                    }
                }
            }
            y_offset = new_y;
            if was_tac {
                tac_seg_applied_para = Some(item_para);
            }
            // A TAC segment is a paragraph-level line-segment condition, not a property
            // of whichever PageItem happened to be emitted last for that paragraph.
            // PR #1088 may render a para-relative float after a TAC table; keep the
            // next-paragraph vpos guard active until we leave that host paragraph.
            prev_tac_seg_applied = was_tac || tac_seg_applied_para == Some(item_para);
            // [Task #991] 다음 반복의 vpos 보정용 — 직전 항목이 분할 표였는지 기록.
            hcursor.prev_item_was_partial_table = matches!(item, PageItem::PartialTable { .. });
            let mut next_endnote_title_gap_from_continued_partial = false;
            prev_endnote_title_gap_px = if col_content.endnote_flow {
                match item {
                    PageItem::FullParagraph { para_index } => paragraphs
                        .get(*para_index)
                        .and_then(|p| p.line_segs.last())
                        // [Task #1257] line_spacing>1000 이 주입된 between-notes 갭 마커. 직전
                        // 미주가 tall 줄(수식)로 끝나도 갭은 보존해야 하므로 line_height 제한 제거
                        // (문26 lh=2070·문29 lh=6897 케이스가 갭 0 으로 떨어지던 원인).
                        .filter(|seg| seg.line_spacing > 1000)
                        .map(|seg| hwpunit_to_px(seg.line_spacing.max(0), self.dpi))
                        .unwrap_or(0.0),
                    PageItem::PartialParagraph {
                        para_index,
                        start_line,
                        end_line,
                    } if *start_line > 0 => paragraphs
                        .get(*para_index)
                        .and_then(|p| p.line_segs.get(end_line.saturating_sub(1)))
                        .map(|seg| {
                            next_endnote_title_gap_from_continued_partial = true;
                            hwpunit_to_px(seg.line_spacing.max(0), self.dpi)
                        })
                        .unwrap_or(0.0),
                    _ => 0.0,
                }
            } else {
                0.0
            };
            prev_endnote_title_gap_from_continued_partial =
                next_endnote_title_gap_from_continued_partial;

            // 고정값 줄간격 TAC 표 병행 (Task #9)
            if was_tac {
                if let Some(para) = paragraphs.get(item_para) {
                    if let Some(seg) = para.line_segs.first() {
                        let ps = styles.para_styles.get(para.para_shape_id as usize);
                        if seg.line_spacing < 0
                            && ps.is_some_and(|s| {
                                matches!(
                                    s.line_spacing_type,
                                    crate::model::style::LineSpacingType::Fixed
                                )
                            })
                        {
                            // 고정 줄간격에서만 후속 줄의 개체 겹침을 해소한다.
                            // Percent의 음수 간격은 문서가 의도한 줄 전진이다.
                            let sa = ps.map(|s| s.spacing_after).unwrap_or(0.0);
                            fix_table_start_y = y_offset
                                - hwpunit_to_px(seg.line_height + seg.line_spacing, self.dpi)
                                    .max(0.0)
                                - sa;
                            fix_table_visual_h = hwpunit_to_px(seg.line_height, self.dpi);
                            fix_overlay_active = true;
                        }
                    }
                }
            }

            // 표/Shape 처리 후 vpos 기준점 무효화
            // 표/Shape의 LINE_SEG lh는 개체 높이를 포함하여 실제 렌더링 높이와 다르므로
            // vpos 누적이 순차 y_offset과 drift를 일으킴 → 기준점 재산출 필요
            // 예외: Para-relative float 표(vert=Para, TopAndBottom, non-TAC)는
            // 앵커 문단에 attach되므로 후속 문단의 vpos 교정 기준점을 초기화하면 안 됨.
            // 초기화하면 한컴이 Para-float 기준으로 기록한 후속 문단 vpos가 잘못된
            // lazy_base로 교정되어 앵커 y가 상승 → body_bottom clamp → LAYOUT_OVERFLOW.
            let is_table_or_shape = matches!(
                item,
                PageItem::Table { .. } | PageItem::PartialTable { .. } | PageItem::Shape { .. }
            );
            let is_para_float_table = if let PageItem::Table {
                para_index,
                control_index,
            } = item
            {
                paragraphs
                    .get(*para_index)
                    .and_then(|p| p.controls.get(*control_index))
                    .map(|c| {
                        matches!(
                            c,
                            Control::Table(t)
                            if !t.common.treat_as_char
                                && matches!(t.common.text_wrap, crate::model::shape::TextWrap::TopAndBottom)
                                && matches!(t.common.vert_rel_to, VertRelTo::Para)
                        )
                    })
                    .unwrap_or(false)
            } else {
                false
            };
            // 예외 2 (#1898): 실제 텍스트 줄에 통합된 글자처럼(tac) 인라인 개체의
            // Shape 항목은 흐름에 독립 높이를 만들지 않는다(호스트 LINE_SEG 는 텍스트
            // 줄 높이, 본 항목 dy=0). 기준점을 초기화하면 다음 문단 vpos_adjust 가
            // lazy_base 재산출에서 trailing-ls bridge 를 다시 적용해, 불릿 그림 문단
            // 마다 렌더 y 가 줄간격 1회분씩 과대 전진한다 (36388711 p9: layout
            // 33.1px vs 렌더 44.8px, 한컴 32.9px). 단, 텍스트 없는 tac-전용 문단
            // (LINE_SEG lh = 개체 높이, sample16 pi=71 RFP 박스)은 종전대로 초기화 —
            // 그 lh 는 개체 높이를 포함해 vpos 누적과 순차 y 의 drift 근거가 맞다.
            let is_inline_tac_object = if let PageItem::Shape {
                para_index,
                control_index,
            } = item
            {
                paragraphs
                    .get(*para_index)
                    .map(|p| {
                        para_has_visible_text(p)
                            && p.controls
                                .get(*control_index)
                                .map(|c| match c {
                                    Control::Picture(pic) => pic.common.treat_as_char,
                                    Control::Shape(shape) => shape.common().treat_as_char,
                                    Control::Equation(eq) => eq.common.treat_as_char,
                                    _ => false,
                                })
                                .unwrap_or(false)
                    })
                    .unwrap_or(false)
            } else {
                false
            };
            let heading_shape_keeps_page_base = saved_inline_heading_page
                && matches!(item, PageItem::Shape { para_index, control_index: 0 }
                    if matches!(col_content.items.first(), Some(PageItem::FullParagraph { para_index: first }) if first == para_index));
            // 저장 컷이 본문을 소유하고 확정 표 원점이 그 재시작과 같으면
            // 표 뒤에도 본문 사다리의 기준을 유지한다. 후처리에서 이를 지우면
            // typeset과 다른 원점으로 뒤 문단을 다시 배치하게 된다.
            let resolved_stored_wrap_fragment = matches!(item, PageItem::Table { .. })
                && resolved_stored_square_fragment_in_column(
                    &paragraphs[item_para],
                    item_para,
                    col_content,
                    self.dpi,
                );
            if !heading_shape_keeps_page_base
                && !resolved_stored_wrap_fragment
                && (was_tac || (is_table_or_shape && !is_para_float_table && !is_inline_tac_object))
            {
                hcursor.vpos_page_base = None;
                hcursor.vpos_lazy_base = None;
            }

            // [#5699 H1] 저장 사다리가 자리차지 표 밴드를 계상하지 않은 자기모순
            // 문서(자치법규 서식류): 페인트된 밴드 하단을 흐름 바닥으로 고정해,
            // 후속 문단의 저장 vpos 스냅이 표 위로 되감아 겹치지 못하게 한다.
            // typeset 의 계상 교정(stored_ladder_omits_tac_band)과 같은 판별 —
            // 선언·페인트 정합 조건이 있어 발산 문서(#2237/#2148)에는 불발.
            // [#5699 H1] typeset 이 "사다리-미계상 표 밴드" 자기모순을 판별해
            // 실높이로 교정한 표(page_content.ladder_band_tables): 페인트된 밴드
            // 하단을 흐름 바닥으로 고정해, 후속 문단의 저장 vpos 스냅이 표 위로
            // 되감아 겹치지 못하게 한다. 판정은 typeset 한 곳에서만 한다 — 렌더가
            // 근사식으로 재판정하면 두 판정이 갈라져 단독 발동한다(tac-img-02 실측).
            if let PageItem::Table {
                para_index,
                control_index,
            } = item
            {
                if page_content
                    .ladder_band_tables
                    .contains(&(*para_index, *control_index))
                    || col_content
                        .inline_placements
                        .contains_key(&(*para_index, *control_index))
                {
                    let content_bottom = self.last_item_content_bottom.get();
                    if content_bottom.is_finite() {
                        if std::env::var("RHWP_5699_DBG").is_ok() {
                            eprintln!("DBG5699_LY pi={} floor→{:.1}", para_index, content_bottom);
                        }
                        hcursor.min_flow_floor = hcursor.min_flow_floor.max(content_bottom);
                    }
                }
            }

            // [Task #1046 Stage 1] 렌더러 항목별 y_offset 진행 로그 (페이지네이터 cur_h 대조).
            if std::env::var("RHWP_TABLE_DRIFT").is_ok() {
                eprintln!(
                    "LAYOUT_Y: page={} sec={} ord={} pi={} y_after={:.1} (body_top={:.1})",
                    page_content.page_index,
                    page_content.section_index,
                    item_ordinal,
                    item_para,
                    y_offset,
                    col_area.y,
                );
            }

            // 자가 검증: 배치 후 y_offset이 단 영역 하단을 초과하는지 확인
            let col_bottom = col_area.y + col_area.height;
            let tolerance = 2.0; // 반올림 오차 허용 (2px)
                                 // [Task #1046 Stage 3 Class B] 표 항목은 표 뒤 trailing 간격(host 문단 줄간격/
                                 // spacing_after)이 더해진 y_offset 대신 실제 콘텐츠 하단으로 초과를 판정한다.
                                 // 페이지 바닥의 후행 간격은 다음 항목이 다음 페이지로 가므로 시각적 초과가
                                 // 아니다(문단 trailing_ls 정책 #359/#404 의 표 대응). 표가 아니거나 콘텐츠
                                 // 하단 미기록(NaN)이면 종전대로 y_offset 사용.
            let check_y = match item {
                PageItem::Table { .. }
                | PageItem::PartialTable { .. }
                | PageItem::FullParagraph { .. }
                | PageItem::PartialParagraph { .. }
                | PageItem::Shape { .. } => {
                    let cb = self.last_item_content_bottom.get();
                    if cb.is_finite() {
                        cb
                    } else {
                        y_offset
                    }
                }
                _ => y_offset,
            };
            // 마지막 continuation 직전 항목도 미주 꼬리로 본다. 작은 bottom
            // bleed는 draw overflow가 없으면 한컴식 하단 배치 허용 범위다.
            let same_endnote_successor = match item {
                PageItem::FullParagraph { para_index }
                | PageItem::PartialParagraph { para_index, .. } => {
                    self.endnote_para_has_same_endnote_successor(*para_index)
                }
                _ => false,
            };
            let is_endnote_tail_item = col_content.endnote_flow
                && (item_ordinal + 1 == col_content.items.len()
                    || (item_ordinal + 2 == col_content.items.len()
                        && current_is_endnote_question_title)
                    || (item_ordinal + 2 == col_content.items.len()
                        && matches!(
                            col_content.items.get(item_ordinal + 1),
                            Some(PageItem::PartialParagraph { .. })
                        ))
                    || same_endnote_successor);
            let is_zero_spacing_endnote_item =
                col_content.endnote_flow && self.current_endnote_zero_spacing_profile();
            let tolerated_endnote_bottom_bleed = self.is_tolerated_current_endnote_bottom_bleed(
                is_endnote_tail_item || is_zero_spacing_endnote_item,
                check_y,
                col_bottom,
                self.last_item_endnote_equation_tail_line_box.get(),
            );
            if check_y > col_bottom + tolerance && !tolerated_endnote_bottom_bleed {
                let (item_type, para_idx) = match item {
                    PageItem::FullParagraph { para_index } => ("FullParagraph", *para_index),
                    PageItem::PartialParagraph { para_index, .. } => {
                        ("PartialParagraph", *para_index)
                    }
                    PageItem::Table { para_index, .. } => ("Table", *para_index),
                    PageItem::PartialTable { para_index, .. } => ("PartialTable", *para_index),
                    PageItem::Shape { para_index, .. } => ("Shape", *para_index),
                    PageItem::EndnoteSeparator { .. } => ("EndnoteSeparator", usize::MAX),
                };
                self.record_overflow(LayoutOverflow {
                    page_index: page_content.page_index,
                    section_index: page_content.section_index,
                    column_index: col_content.column_index as usize,
                    para_index: para_idx,
                    item_type,
                    is_first_in_column: item_ordinal == 0,
                    element_y: check_y,
                    column_bottom: col_bottom,
                    overflow_px: check_y - col_bottom,
                });
            }
        }

        // 2차 패스: 글상자(Shape) z-order 정렬 후 렌더링
        self.layout_column_shapes_pass(
            tree,
            &mut col_node,
            paper_images,
            col_content,
            page_content,
            paragraphs,
            composed,
            styles,
            bin_data_content,
            layout,
            col_area,
            &para_start_y,
            None,
        );

        // [#4568] 앞 쪽에서 쪽 하단에 잘린 overlay 표의 잔여 행을 이 단 최상단에
        // 이어 그린다. 흐름 항목이 아니므로 1차 패스의 y_offset 에 관여하지 않고,
        // shapes pass 와 같은 z-층위에서 그린다. `layout_partial_table_item` 의
        // 연속 조각 경로(`is_continuation=true` → 제목행 반복 규약 포함)를 그대로
        // 재사용하고, 반환 y 는 버린다 — 이 조각은 흐름을 소비하지 않는다.
        if !col_content.overlay_continuations.is_empty() {
            let overlay_ctx = ColumnItemCtx {
                page_content,
                paragraphs,
                composed,
                styles,
                bin_data_content,
                measured_tables,
                layout,
                col_area,
                zone_column_count: zone_layout.column_areas.len(),
                outline_numbering_id,
                multi_col_width: None,
                prev_tac_seg_applied: false,
                wrap_around_paras: column_wrap_around_paras,
                wrap_anchors: &col_content.wrap_anchors,
                inline_placements: &col_content.inline_placements,
                inline_flow_plans: &col_content.inline_flow_plans,
                paragraph_float_placements: &col_content.paragraph_float_placements,
            };
            // 이 단에 이미 그려진 표들의 최상단 y — 잔여 행이 그 아래로 내려가면
            // #4514 가 잡은 표 겹침이 재발한다(실측: pi=158 잔여 행 727px ↔ pi=186
            // 앵커 429.7px, 겹침 375.5px). 잔여 행은 그 경계 위까지만, 행 단위로
            // 잘라 그린다. 필러 흐름이 저장 사다리와 어긋난 문서에서만 발동하는
            // 보수 가드다 — 사다리 정합 문서는 앵커가 잔여 행 아래에 온다.
            // overlay 앵커 표는 shapes pass 가 `paper_images` z-층으로 옮기므로
            // `col_node` 자식만 보면 놓친다. 이 단의 x 범위와 겹치는 것만 본다.
            let existing_table_top = col_node
                .children
                .iter()
                .chain(paper_images.iter())
                .filter(|n| matches!(n.node_type, RenderNodeType::Table(_)))
                .filter(|n| {
                    n.bbox.x < col_area.x + col_area.width && n.bbox.x + n.bbox.width > col_area.x
                })
                .map(|n| n.bbox.y)
                .filter(|y| *y > col_area.y + 1.0)
                .fold(f64::INFINITY, f64::min);
            let mut overlay_para_start_y = para_start_y.clone();
            for cont in &col_content.overlay_continuations {
                let table = paragraphs
                    .get(cont.para_index)
                    .and_then(|p| p.controls.get(cont.control_index))
                    .and_then(|c| match c {
                        Control::Table(t) => Some(t),
                        _ => None,
                    });
                let Some(table) = table else {
                    continue;
                };
                let row_count = table.row_count as usize;
                if cont.start_row >= row_count {
                    continue;
                }
                // 겹침 상한 안에 들어가는 행까지만 그린다.
                let room = existing_table_top - col_area.y;
                let mut end_row = cont.start_row;
                if room > 1.0 {
                    let mut cum = 0.0;
                    let mt = measured_tables
                        .iter()
                        .find(|m| m.para_index == cont.para_index);
                    for r in cont.start_row..row_count {
                        let rh = mt
                            .and_then(|m| m.row_heights.get(r))
                            .copied()
                            .unwrap_or(0.0);
                        if cum + rh > room {
                            break;
                        }
                        cum += rh;
                        end_row = r + 1;
                    }
                }
                if end_row <= cont.start_row {
                    continue;
                }
                let _ = self.layout_partial_table_item(
                    tree,
                    &mut col_node,
                    &mut overlay_para_start_y,
                    cont.para_index,
                    cont.control_index,
                    cont.start_row,
                    end_row,
                    true,
                    &[],
                    &[],
                    false,
                    false,
                    false,
                    None,
                    None,
                    &overlay_ctx,
                    col_area.y,
                );
            }
        }

        // [#4533 ④-a] 자리차지 표 앵커 줄 재배치 — 테두리 병합 전에 수행해
        // 테두리가 이동된 줄 박스를 따라가게 한다.
        self.relocate_float_anchor_lines_below_band(
            &mut col_node,
            paragraphs,
            &col_content.paragraph_float_placements,
        );

        // 문단 테두리/배경 연속 그룹 병합 렌더링 — #2120 추출
        self.render_para_border_groups(tree, composed, &mut col_node, styles, col_area);

        tree.current_physical_selections.finish_frame(col_node.id);
        (col_node, y_offset)
    }

    /// [#4533 ④-a] 비-tac TopAndBottom 자리차지 표의 앵커 줄을 한글은 밴드
    /// **아래**에 둔다(상주시 20155931 실측: 앵커 줄 렌더 198.1 vs 사다리 446.6,
    /// 사이에 표 235px — dev −248.5 정확 일치 · 공작기계 156658370 동형 −226.6).
    /// rhwp 는 흐름 순서대로 줄을 밴드 위에 그린다 — 밴드·후속 문단 위치는
    /// 이미 사다리와 일치하므로 **줄 노드만** 사다리 위치로 재배치한다.
    ///
    /// 판별자는 ②판과 같은 직전-갭 서명: 직전 저장 줄 끝→호스트 vpos 갭이
    /// 표높이×0.85 이상(= 표의 공간이 앵커 줄 위에 예약됨). 목표는 다음
    /// 열-직속 줄의 **확정 y** 에서 저장 vpos 델타를 되뺀 값 — 흐름 좌표와
    /// 사다리 좌표의 페이지 오프셋을 이웃에서 직접 얻으므로 절대 vpos 환산의
    /// 다구역·다쪽 함정([[stored-ladder-is-not-a-full-page-oracle]])이 없다.
    /// 하향·발산>2px 한정(멱등) — 전면 사다리 스냅은 #3386 에서 반증됐다.
    fn relocate_float_anchor_lines_below_band(
        &self,
        col_node: &mut RenderNode,
        paragraphs: &[Paragraph],
        placements: &std::collections::HashMap<
            (usize, usize),
            super::float_placement::ParagraphFloatPlacement,
        >,
    ) {
        // HWPX 도 한글이 저장한 `<hp:linesegarray>` 사다리를 갖는 문서는 같은
        // 서명이 성립한다(영월군 21296471: 앵커 pi5 렌더 237.7 vs 사다리 562.2,
        // 사이에 표 316px — dev −324.5, 한글 2022 PDF 실측으로 방향 확정).
        // lineseg 부재·전부 0 문서는 파서가 line_segs 를 비워 아래 len==1
        // 게이트가 자연 배제한다.
        let profile = self.profile.get();
        if !(profile.hwp5_stored_pagination_layout() || profile.hwpx_stored_layout()) {
            return;
        }
        let lines: Vec<(usize, usize, i32, f64, f64)> = col_node
            .children
            .iter()
            .enumerate()
            .filter_map(|(i, n)| match &n.node_type {
                RenderNodeType::TextLine(tl) => {
                    Some((i, tl.para_index?, tl.vpos?, n.bbox.y, tl.line_height))
                }
                _ => None,
            })
            .collect();
        for w in 0..lines.len() {
            let (child_idx, pi, vpos, y, _) = lines[w];
            if placements
                .iter()
                .any(|(&(host, _), placement)| host == pi && placement.stored_host_origin.is_some())
            {
                continue; // Already generated from the shared, pre-fit origin.
            }
            let Some(para) = paragraphs.get(pi) else {
                continue;
            };
            if para.line_segs.len() != 1 {
                continue;
            }
            if lines.iter().filter(|l| l.1 == pi).count() != 1 {
                continue;
            }
            let band_h: f64 = para
                .controls
                .iter()
                .map(|c| match c {
                    Control::Table(t)
                        if !t.common.treat_as_char
                            && matches!(
                                t.common.text_wrap,
                                crate::model::shape::TextWrap::TopAndBottom
                            ) =>
                    {
                        hwpunit_to_px(t.common.height as i32, self.dpi)
                    }
                    _ => 0.0,
                })
                .sum();
            if band_h <= 0.0 {
                continue;
            }
            // 직전-끝은 **이 열에 렌더된 줄들의 저장 사다리**로만 구한다 —
            // 문단 전역을 훑으면 앞 쪽 문단들의 vpos(쪽마다 리셋)가 오염시켜
            // 다쪽 문서(공작기계 p3)에서 갭이 허상으로 쪼그라든다.
            let prev_end_px = lines[..w]
                .iter()
                .filter(|l| l.2 < vpos)
                .map(|l| hwpunit_to_px(l.2, self.dpi) + l.4)
                .fold(f64::NEG_INFINITY, f64::max);
            if !prev_end_px.is_finite() {
                continue;
            }
            let gap_before = hwpunit_to_px(vpos, self.dpi) - prev_end_px;
            if gap_before < band_h * 0.85 {
                continue;
            }
            let Some(&(_, _, next_vpos, next_y, _)) = lines.get(w + 1) else {
                continue;
            };
            if next_vpos <= vpos {
                continue;
            }
            let target = next_y - hwpunit_to_px(next_vpos - vpos, self.dpi);
            let delta = target - y;
            if delta > 2.0 {
                Self::translate_subtree_y(&mut col_node.children[child_idx], delta);
                // [#4533 ⑤-a 잔여] hwpx 는 한글이 앵커 줄 공간을 밴드 위에서
                // 소비하지 않는다 — 밴드 상단 = 문단 상단(원 앵커 줄 y) +
                // vertOffset + outMargin_top. 한글 2022 PDF 테두리 실측 3표본:
                // 영월군 +0.2 · 81240 +0.1(문단 프레임 보정 후) · 가족센터
                // +0.6px. native HWP5 는 앵커 줄 소비가 실물과 일치(상주시
                // 실측: 공통 −4.4px 바이어스뿐)하므로 제외. 단일 자리차지 표
                // 한정, 상향 이동만(멱등).
                if profile.hwpx_stored_layout() {
                    let bands: Vec<(f64, f64)> = para
                        .controls
                        .iter()
                        .filter_map(|c| match c {
                            Control::Table(t)
                                if !t.common.treat_as_char
                                    && matches!(
                                        t.common.text_wrap,
                                        crate::model::shape::TextWrap::TopAndBottom
                                    ) =>
                            {
                                Some((
                                    hwpunit_to_px(t.common.vertical_offset as i32, self.dpi),
                                    hwpunit_to_px(t.common.margin.top as i32, self.dpi),
                                ))
                            }
                            _ => None,
                        })
                        .collect();
                    let table_nodes: Vec<usize> = col_node
                        .children
                        .iter()
                        .enumerate()
                        .filter_map(|(i, n)| match &n.node_type {
                            RenderNodeType::Table(t) if t.para_index == Some(pi) => Some(i),
                            _ => None,
                        })
                        .collect();
                    if let ([(off_px, margin_px)], [tbl_idx]) = (&bands[..], &table_nodes[..]) {
                        let band_shift =
                            (y + off_px + margin_px) - col_node.children[*tbl_idx].bbox.y;
                        if (-200.0..=-2.0).contains(&band_shift) {
                            Self::translate_subtree_y(&mut col_node.children[*tbl_idx], band_shift);
                        }
                    }
                }
            }
        }
    }

    /// 노드와 모든 자손의 y 를 dy 만큼 이동한다.
    fn translate_subtree_y(node: &mut RenderNode, dy: f64) {
        node.bbox.y += dy;
        Self::translate_node_payload_y(node, dy);
        for child in node.children.iter_mut() {
            Self::translate_subtree_y(child, dy);
        }
    }

    /// [#6921] `bbox` 말고 **자기 좌표**를 들고 다니는 노드의 y 도 같이 옮긴다.
    ///
    /// 백엔드는 노드마다 다른 것을 읽는다. `Rectangle`·`Ellipse`·`Image`·글자는
    /// `node.bbox` 로 그리지만, `Line` 은 `x1/y1–x2/y2` 를, `Path` 는 `commands` 의
    /// 절대 좌표를 그대로 경로로 삼는다(`svg.rs` 의 `draw_line`·`draw_path_with_gradient`).
    /// bbox 만 옮기면 그 둘은 **옮기기 전 자리에 그려지고 bbox 만 따로 논다.**
    ///
    /// 148733091 12쪽: `vertAlign` 정렬이 꼬리말을 `dy = 23.88px` 내리는데 문단 테두리
    /// 이중선의 bbox 만 `1031.8` 로 가고 방출은 `1007.92` 에 남았다. 그 자리는 아직 본문
    /// 영역(바닥 `1009.2`) 안이라 선이 본문 마지막 글줄을 가로질렀다.
    /// 한/글 정본(engine 2020)은 같은 선을 `1028.2` 에 그린다.
    fn translate_node_payload_y(node: &mut RenderNode, dy: f64) {
        match &mut node.node_type {
            RenderNodeType::Line(line) => {
                line.y1 += dy;
                line.y2 += dy;
            }
            RenderNodeType::Path(path) => {
                for cmd in path.commands.iter_mut() {
                    match cmd {
                        PathCommand::MoveTo(_, y) | PathCommand::LineTo(_, y) => *y += dy,
                        PathCommand::CurveTo(_, y1, _, y2, _, y) => {
                            *y1 += dy;
                            *y2 += dy;
                            *y += dy;
                        }
                        PathCommand::ArcTo(_, _, _, _, _, _, y) => *y += dy,
                        PathCommand::ClosePath => {}
                    }
                }
            }
            _ => {}
        }
    }

    /// 단 내 개별 PageItem을 레이아웃한다 (1차 패스).
    /// 반환값: (새 y_offset, TAC 표 line_seg 줄간격 적용 여부)
    #[allow(clippy::too_many_arguments)]
    fn layout_column_item(
        &self,
        tree: &mut PageLayoutContext,
        col_node: &mut RenderNode,
        paper_images: &mut Vec<RenderNode>,
        para_start_y: &mut std::collections::HashMap<usize, f64>,
        deferred_paragraph_spacing: &mut std::collections::HashMap<usize, f64>,
        para_float_lanes: &mut ParaFloatLanes,
        visible_float_exclusions: &mut Vec<VisibleFloatExclusion>,
        // [Task #1151 v9 결함 D] sibling TAC picture 가로 분배 cursor state.
        para_inline_state: &mut std::collections::HashMap<
            usize,
            super::layout::paragraph_layout::ParaInlineState,
        >,
        item: &PageItem,
        page_content: &PageContent,
        paragraphs: &[Paragraph],
        composed: &[ComposedParagraph],
        styles: &ResolvedStyleSet,
        bin_data_content: &[BinDataContent],
        measured_tables: &[MeasuredTable],
        layout: &PageLayoutInfo,
        col_area: &LayoutRect,
        zone_column_count: usize,
        outline_numbering_id: u16,
        multi_col_width: Option<i32>,
        mut y_offset: f64,
        prev_tac_seg_applied: bool,
        wrap_around_paras: &[super::pagination::WrapAroundPara],
        wrap_anchors: &std::collections::HashMap<usize, super::pagination::WrapAnchorRef>,
        inline_placements: &std::collections::HashMap<
            (usize, usize),
            super::float_placement::InlineBoxPlacement,
        >,
        inline_flow_plans: &std::collections::HashMap<usize, super::inline_flow::InlineFlowPlan>,
        paragraph_float_placements: &std::collections::HashMap<
            (usize, usize),
            super::float_placement::ParagraphFloatPlacement,
        >,
    ) -> (f64, bool) {
        let ctx = ColumnItemCtx {
            page_content,
            paragraphs,
            composed,
            styles,
            bin_data_content,
            measured_tables,
            layout,
            col_area,
            zone_column_count,
            outline_numbering_id,
            multi_col_width,
            prev_tac_seg_applied,
            wrap_around_paras,
            wrap_anchors,
            inline_placements,
            inline_flow_plans,
            paragraph_float_placements,
        };
        let mut applied_tac_segment = false;
        match item {
            PageItem::FullParagraph { para_index } => {
                if let Some(plan) = inline_flow_plans.get(para_index) {
                    let para = &paragraphs[*para_index];
                    self.apply_paragraph_numbering(
                        composed.get(*para_index),
                        para,
                        styles,
                        outline_numbering_id,
                    );
                    para_start_y.insert(*para_index, col_area.y + plan.start);
                    self.layout_inline_flow_plan(
                        tree,
                        col_node,
                        para,
                        styles,
                        col_area,
                        page_content.section_index,
                        *para_index,
                        bin_data_content,
                        measured_tables,
                        plan,
                    );
                    return (col_area.y + plan.end, false);
                }
                let deferred_empty_float_text_anchor_y =
                    para_index.checked_sub(1).and_then(|host_index| {
                        let host = paragraphs.get(host_index)?;
                        let following = paragraphs.get(*para_index)?;
                        let Control::Table(table) = host.controls.first()? else {
                            return None;
                        };
                        empty_offset_float_deferred_text_ladder_hu(host, table, following).map(
                            |(vertical_pos, line_advance)| {
                                col_area.y
                                    + hwpunit_to_px(
                                        vertical_pos.saturating_add(line_advance),
                                        self.dpi,
                                    )
                            },
                        )
                    });
                if let Some(anchor_y) = deferred_empty_float_text_anchor_y {
                    // 양수 offset 빈 host 표는 본문을 표 아래로 밀어내지 않는다. 표의
                    // 저장 anchor부터 다음 계산 본문을 재개해 표 위 gap을 먼저 채운다.
                    y_offset = anchor_y;
                }
                // 빈 줄 감추기: 높이 0 처리된 문단은 문단부호만 렌더링하고 y_offset 변경 없음
                if self.hidden_empty_paras.borrow().contains(para_index) {
                    // 문단부호는 렌더링 (클리핑 바깥에 표시)
                    if let Some(comp) = composed.get(*para_index) {
                        if let Some(para) = paragraphs.get(*para_index) {
                            para_start_y.insert(*para_index, y_offset);
                            self.layout_paragraph(
                                tree,
                                col_node,
                                para,
                                Some(comp),
                                styles,
                                col_area,
                                y_offset,
                                page_content.section_index,
                                *para_index,
                                multi_col_width,
                                Some(bin_data_content),
                                ctx.wrap_anchors.get(para_index),
                            );
                        }
                    }
                    return (y_offset, false);
                }
                if let Some(para) = paragraphs.get(*para_index) {
                    if para_has_visible_textless_float_shape_item(page_content, para, *para_index) {
                        // 빈 non-TAC 그림/도형 host 문단은 바로 뒤 Shape PageItem 이 실제
                        // 개체를 렌더한다. 여기서 layout_paragraph 를 태우면 보이지 않는
                        // 빈 줄이 저장 vpos 기준으로 페이지 밖에 기록되어 overflow 오탐이 난다.
                        para_start_y.entry(*para_index).or_insert(y_offset);
                        // 저장 사다리가 그 문서의 진실이다 — 한글이 이 앵커 줄을 예약했는지
                        // 다음 문단 vpos 델타로 먼저 묻고, 판별 불가일 때만 vert_rel_to
                        // 휴리스틱(글앞 도장류 예약·BehindText 비예약)으로 물러난다.
                        // overlay(글앞/글뒤) 호스트가 원 대상이었고, [#5809] Square 등
                        // 흐름 상호작용 wrap 호스트도 사다리에 묻는다 — 156518601 p1:
                        // 빈 Square host 문단의 줄(29.9px)을 안 주면 typeset(사다리
                        // 스냅으로 예약)과 desync 로 본문 전체가 22.6px 위로 밀린다.
                        // 종전 반증(issue_2069 OLE enter/backspace: 편집 후 stale
                        // 사다리가 계약을 뒤집음)은 사다리 질의 함수의 합성 태그
                        // 가드(TAG_IMPLEMENTATION_PROPERTY 배제)가 차단한다 — 편집이
                        // 만든 reflow lineseg 는 저장 증거로 쓰지 않는다.
                        let has_overlay_float = para.controls.iter().any(|c| {
                            let cm = match c {
                                Control::Picture(pic) => &pic.common,
                                Control::Shape(shape) => shape.common(),
                                // [#7047] 데코레이션(글앞/글뒤) **표** host 도 사다리에
                                // 묻는다 — `#703` 단축이 흐름을 0 소비해 이 문단의 줄이
                                // 통째로 빠지는데, 전진 여부의 판정 근거는 그림·도형
                                // host 와 똑같이 저장 델타다. 표를 빼 두면 질의가 아예
                                // 돌지 않아 휴리스틱이 "전진 없음"으로 답한다.
                                Control::Table(table) => &table.common,
                                _ => return false,
                            };
                            !cm.treat_as_char
                                && matches!(
                                    cm.text_wrap,
                                    TextWrap::InFrontOfText | TextWrap::BehindText
                                )
                        });
                        // [#5809] Square 계열 확장 갈래는 다음 문단이 **가시 텍스트**를
                        // 가질 때만 — 저장 사다리의 예약 증언은 다음 실내용의 저장
                        // 위치가 근거다. 편집(Enter)으로 삽입된 빈 부호 문단(issue_2069
                        // 한셀OLE)은 증언력이 없고 sequential 이 정답이다.
                        let has_square_float_before_text = para.controls.iter().any(|c| {
                            let cm = match c {
                                Control::Picture(pic) => &pic.common,
                                Control::Shape(shape) => shape.common(),
                                _ => return false,
                            };
                            !cm.treat_as_char
                                && matches!(
                                    cm.text_wrap,
                                    TextWrap::Square | TextWrap::Tight | TextWrap::Through
                                )
                        }) && paragraphs
                            .get(*para_index + 1)
                            .is_some_and(para_has_visible_text);
                        // 저장된 TopAndBottom 그림/도형 host도 다음 문단까지의 줄
                        // 전진을 보존한다. 개체의 예약 높이와 앵커 문단의 줄은 별개다.
                        // 빈 후속 문단도 유효한 저장 LineSeg가 있으면 증거가 된다.
                        let has_top_bottom_float = para.controls.iter().any(|c| {
                            let cm = match c {
                                Control::Picture(pic) => &pic.common,
                                Control::Shape(shape) => shape.common(),
                                _ => return false,
                            };
                            !cm.treat_as_char && cm.text_wrap == TextWrap::TopAndBottom
                        });
                        let has_ladder_float = has_overlay_float
                            || has_square_float_before_text
                            || has_top_bottom_float;
                        let ladder_verdict = has_ladder_float
                            .then(|| {
                                textless_host_ladder_line_advance(
                                    paragraphs,
                                    styles,
                                    self.dpi,
                                    *para_index,
                                )
                            })
                            .flatten();
                        // [#5929] 사다리가 **아예 없는** 문서(합성 lineseg 뿐인 기계
                        // 생성본)에서는 위 증언 경로가 통째로 침묵한다. 그때는 조판을
                        // 따라야 한다 — typeset 은 이 빈 어울림 host 문단에 제 줄을
                        // 그대로 계상한다(`dump-pages`: pi=8 h=54.1). 페인트만 0 으로
                        // 두면 뒤따르는 자리차지 표가 그 한 줄만큼 위로 올라와 그림과
                        // 겹친다(사용자 보고: 표가 이미지와 겹침).
                        //
                        // 게이트를 저장 증거 부재로 좁힌다 — 사다리가 있는 문서는
                        // #5809 의 증언 경로가 그대로 답한다(issue_2069 편집 반례 포함).
                        let no_stored_ladder_square_host = ladder_verdict.is_none()
                            && crate::renderer::para_has_no_stored_line_segs(para)
                            && para.controls.iter().any(|c| {
                                let cm = match c {
                                    Control::Picture(pic) => &pic.common,
                                    Control::Shape(shape) => shape.common(),
                                    _ => return false,
                                };
                                !cm.treat_as_char
                                    && matches!(
                                        cm.text_wrap,
                                        TextWrap::Square | TextWrap::Tight | TextWrap::Through
                                    )
                                    && matches!(cm.vert_rel_to, VertRelTo::Para)
                            });
                        let advance_line = ladder_verdict.unwrap_or_else(|| {
                            no_stored_ladder_square_host
                                || textless_infront_para_host_requires_line_advance(para)
                        });
                        if advance_line {
                            // [#5809] 사다리가 예약을 증언한 케이스는 저장 델타
                            // (다음 문단 vpos − 호스트 vpos = sb+lh+ls 전량)가 정확한
                            // 전진량이다 — lh+ls 만 주면 문단 앞 간격(sb)이 유실된다.
                            let ladder_delta_px = (ladder_verdict == Some(true))
                                .then(|| {
                                    let cur = paragraphs.get(*para_index)?;
                                    let next = paragraphs.get(*para_index + 1)?;
                                    // [#6524] 사다리 질의와 **같은 술어**를 써야 한다.
                                    // 여기만 `[seg]` 로 두면 좌·우 조각 문단이 저장 델타를
                                    // 못 받고 `paragraph_line_advance_px` 로 물러나는데,
                                    // 그 폴백은 조각 둘을 **두 줄**로 세어 24.00pt 를 더
                                    // 전진시킨다(30098 pi=36: 24.00 대신 48.00).
                                    let seg = stored_single_visual_line(cur)?;
                                    let delta =
                                        next.line_segs.first()?.vertical_pos - seg.vertical_pos;
                                    (delta > 0).then(|| hwpunit_to_px(delta, self.dpi))
                                })
                                .flatten();
                            let advance = ladder_delta_px.unwrap_or_else(|| {
                                let lines = paragraph_line_advance_px(
                                    para,
                                    composed.get(*para_index),
                                    self.dpi,
                                );
                                if crate::renderer::para_has_no_stored_line_segs(para) {
                                    // [#5929] 사다리가 없으면 조판이 기준이다 — typeset 은
                                    // 이 문단을 `sb + lines + sa` 로 계상한다(형제 빈 문단과
                                    // 같은 54.1px). 줄 부분만 주면 문단 앞뒤 간격(20px)이
                                    // 유실돼 표가 그만큼 위로 올라온다.
                                    let style_id = composed
                                        .get(*para_index)
                                        .map(|c| c.para_style_id as usize)
                                        .unwrap_or(para.para_shape_id as usize);
                                    let (sb, sa) = styles
                                        .para_styles
                                        .get(style_id)
                                        .map(|st| (st.spacing_before, st.spacing_after))
                                        .unwrap_or((0.0, 0.0));
                                    // typeset 은 NO_LS 빈 host 문단의 줄을 composer
                                    // placeholder(400HU≈5.3px)가 아니라 저장 글자모양의
                                    // 완전한 em 줄박스로 계상한다(빈 문단 fallback 무조건
                                    // 적용, #3820). 페인트도 같은 메트릭을 써야 두 장부가
                                    // 일치한다 — placeholder 를 그대로 세면 뒤 문단 전체가
                                    // 그 차액만큼 위로 붙는다.
                                    let line_part =
                                        paragraph_layout::empty_no_lineseg_paragraph_metrics(
                                            para,
                                            styles,
                                            styles.para_styles.get(style_id),
                                            self.profile.get().hwp3_layout(),
                                            self.dpi,
                                        )
                                        .map(|(lh, ls, _)| lh + ls)
                                        .unwrap_or(lines);
                                    line_part + sb.max(0.0) + sa.max(0.0)
                                } else {
                                    lines
                                }
                            });
                            return (y_offset + advance, false);
                        }
                        // NO_LS 문서의 Square 등 흐름
                        // 상호작용 앵커 빈 문단은 한글이 완전한 em 줄박스를 예약한다
                        // (사용안내 pi1/pi6 실측 27.7px — PrvImage 줄 좌표 대조).
                        // 위 사다리 계약(Square ladder 뒤집힘 반증)은 저장 lineseg 가
                        // 있는 문단 얘기이므로 NO_LS 한정으로만 전진을 부여한다.
                        let para_no_ls = !para.line_segs.iter().any(|seg| {
                            seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY
                                == 0
                        });
                        if para_no_ls {
                            let para_style_id = composed
                                .get(*para_index)
                                .map(|c| c.para_style_id as usize)
                                .unwrap_or(para.para_shape_id as usize);
                            if let Some((lh, ls, _)) =
                                paragraph_layout::empty_no_lineseg_paragraph_metrics(
                                    para,
                                    styles,
                                    styles.para_styles.get(para_style_id),
                                    self.profile.get().hwp3_layout(),
                                    self.dpi,
                                )
                            {
                                return (y_offset + lh + ls, false);
                            }
                        }
                        return (y_offset, false);
                    }

                    let seg_width = effective_tac_segment_width_hu(
                        para,
                        px_to_hwpunit(col_area.width, self.dpi),
                    );
                    let has_block_table = para.controls.iter()
                        .any(|c| matches!(c, Control::Table(t) if !t.common.treat_as_char
                            || (t.common.treat_as_char
                                && !crate::renderer::height_measurer::is_tac_table_inline_in_para(t, seg_width, para))));
                    if has_block_table {
                        if para_is_empty_topbottom_table_anchor(para) {
                            // 빈 기본 표 host 문단은 별도 빈 줄로 소비하지 않는다.
                            // 표 PageItem 렌더 시 같은 y에 문단부호를 얹어 한컴처럼
                            // 첫 조판부호가 표와 겹쳐 보이게 한다.
                            para_start_y.entry(*para_index).or_insert(y_offset);
                            return (y_offset, false);
                        }

                        let comp = composed.get(*para_index);
                        let para_style_id = comp
                            .map(|c| c.para_style_id as usize)
                            .unwrap_or(para.para_shape_id as usize);
                        if let Some(para_style) = styles.para_styles.get(para_style_id) {
                            // 번호 카운터 전진 (후속 문단의 번호 연속성 유지)
                            // Bullet은 카운터를 사용하지 않으므로 제외
                            if para_style.head_type == HeadType::Outline
                                || para_style.head_type == HeadType::Number
                            {
                                let nid = resolve_numbering_id(
                                    para_style.head_type,
                                    para_style.numbering_id,
                                    outline_numbering_id,
                                );
                                if nid > 0 {
                                    self.numbering_state.borrow_mut().advance(
                                        nid,
                                        para_style.para_level,
                                        para.numbering_restart,
                                    );
                                }
                            }
                            if para_style.spacing_before > 0.0 {
                                y_offset += para_style.spacing_before;
                            }
                        }
                        // 어울림 표 호스트 문단의 텍스트는 layout_wrap_around_paras에서 처리
                        let is_wrap_host = para.controls.iter().any(|c| {
                            if let Control::Table(t) = c {
                                !t.common.treat_as_char
                                    && matches!(
                                        t.common.text_wrap,
                                        crate::model::shape::TextWrap::Square
                                    )
                            } else {
                                false
                            }
                        });
                        // 블록 표/도형 외에 실제 텍스트가 있는지 확인
                        // (예: [선][선][표][표]참고문헌 → 표 아래에 텍스트 렌더링 필요)
                        let has_real_text = !is_wrap_host
                            && para
                                .text
                                .chars()
                                .any(|c| c > '\u{001F}' && c != '\u{FFFC}' && !c.is_whitespace());
                        if has_real_text {
                            if let Some(comp) = comp {
                                // 컨트롤 전용 줄(runs가 모두 제어문자)을 건너뛰고 텍스트 줄부터 렌더링
                                let text_start_line = first_text_line(comp);
                                if let Some(start_line) = text_start_line {
                                    para_start_y.insert(*para_index, y_offset);
                                    y_offset = self.layout_partial_paragraph(
                                        tree,
                                        col_node,
                                        para,
                                        Some(comp),
                                        styles,
                                        styles.hwp3_variant
                                            && self.endnote_para_source_for(*para_index).is_none(),
                                        col_area,
                                        y_offset,
                                        start_line,
                                        comp.lines.len(),
                                        page_content.section_index,
                                        *para_index,
                                        multi_col_width,
                                        Some(bin_data_content),
                                        ctx.wrap_anchors.get(para_index),
                                    );
                                }
                            }
                        }
                        return (y_offset, false);
                    }

                    let has_inline_tables = para.controls.iter()
                        .any(|c| matches!(c, Control::Table(t) if t.common.treat_as_char
                            && crate::renderer::height_measurer::is_tac_table_inline_in_para(t, seg_width, para)));

                    // [Task #565] 인라인 표 + 다른 인라인 컨트롤(수식/treat_as_char Picture/Shape)
                    // 이 같이 있는 문단은 layout_inline_table_paragraph 가 인라인 수식 등을
                    // 처리하지 않아 shape_layout fallback (col_area.x, para_y) 으로 9개 수식이
                    // 동일 좌표에 겹친다 (exam_science.hwp 12/15/18/19번). 일반
                    // layout_paragraph 로 보내 인라인 표 + 인라인 수식이 같은 line/x 체계
                    // (run_tacs / inline_x) 로 정상 배치되도록 한다.
                    let has_other_inline_ctrls = para.controls.iter().any(|c| match c {
                        Control::Equation(_) => true,
                        Control::Picture(p) => p.common.treat_as_char,
                        Control::Shape(s) => s.common().treat_as_char,
                        _ => false,
                    });

                    if has_inline_tables && !has_other_inline_ctrls {
                        // 인라인 표 문단도 번호 카운터 전진 필요
                        self.apply_paragraph_numbering(
                            composed.get(*para_index),
                            para,
                            styles,
                            outline_numbering_id,
                        );
                        para_start_y.insert(*para_index, y_offset);
                        let para_flow_start = y_offset;
                        // [#4610 · #4599 ④] 공백-전용 TAC 캐리어 문단의 페인트 변위 —
                        // 렌더 y 만 저장 vpos 로 되돌리고 흐름 전진량은 보존한다.
                        let paint_y = whitespace_tac_carrier_stored_paint_y(
                            self.profile.get().hwpx_stored_layout(),
                            para,
                            composed.get(*para_index),
                            col_area.y,
                            y_offset,
                            self.dpi,
                        )
                        .unwrap_or(y_offset);
                        let inline_flow_end = self.layout_inline_table_paragraph(
                            tree,
                            col_node,
                            para,
                            composed.get(*para_index),
                            styles,
                            col_area,
                            paint_y,
                            page_content.section_index,
                            *para_index,
                            bin_data_content,
                            measured_tables,
                        );
                        y_offset = if paint_y < para_flow_start {
                            para_flow_start + (inline_flow_end - paint_y).max(0.0)
                        } else {
                            inline_flow_end
                        };
                        // [#4532 기전 2호] 저장 lineseg 한 줄(표를 품는 거대 lh)을
                        // 재래핑이 여러 줄로 쪼개면 줄마다 lh 를 상속해 흐름이 배로
                        // 붊(사천시 21606965: 401.1px = 사다리 206.4 의 2배). 채택된
                        // 사다리-국소식(#4531, 1551a2ff7)과 같은 구성으로 표 뒤 흐름을
                        // 다음 문단 저장 vpos 델타에 맞춘다 — 저장 seg 가 자기
                        // 레이아웃과 일치하는 문서(HWP3 변환본 등)에서는 구성상
                        // 무동작이라, 상한 캡이 issue_1892 를 깨던 함정이 없다.
                        // 개입은 재래핑 서명(조판 2줄 이상)일 때만.
                        if self.profile.get().hwp5_stored_pagination_layout() {
                            if let [seg] = para.line_segs.as_slice() {
                                let target = (seg.line_height > 0)
                                    .then(|| paragraphs.get(*para_index + 1))
                                    .flatten()
                                    .and_then(|np| {
                                        let ns = np.line_segs.first()?;
                                        let delta = ns.vertical_pos - seg.vertical_pos;
                                        if delta <= 0
                                            || delta
                                                >= seg.line_height.saturating_mul(4).max(160_000)
                                        {
                                            return None;
                                        }
                                        let sb = |id: u16| {
                                            styles
                                                .para_styles
                                                .get(id as usize)
                                                .map(|ps| ps.spacing_before.max(0.0))
                                                .unwrap_or(0.0)
                                        };
                                        Some(
                                            para_flow_start
                                                + sb(para.para_shape_id)
                                                + hwpunit_to_px(delta, self.dpi)
                                                - sb(np.para_shape_id),
                                        )
                                    });
                                // 자기일관(저장 seg == 자기 레이아웃) 문서는 target
                                // 이 현재값과 같아 무동작 — 발산했을 때만 교정된다.
                                if let Some(t) = target {
                                    if (y_offset - t).abs() > 2.0 {
                                        y_offset = t;
                                    }
                                }
                            }
                        }
                        // 이 경로도 표를 품은 줄의 간격까지 이미 소비했다.
                        // 다음 문단에서 PageItem 종류만 보고 그 간격을 다시 붙이지 않는다.
                        applied_tac_segment = true;
                    } else {
                        let comp = composed.get(*para_index);
                        let numbered_comp = self.apply_paragraph_numbering(
                            comp,
                            para,
                            styles,
                            outline_numbering_id,
                        );
                        let final_comp = numbered_comp.as_ref().or(comp);

                        para_start_y.insert(*para_index, y_offset);
                        // [#4610 · #4599 ④] 공백-전용 TAC 캐리어 문단은 렌더 y 만 저장 vpos 로
                        // 되돌리고(paint 변위) 흐름 전진량은 변위 전과 동일하게 보존한다
                        // — 후속 문단(야간방호일지 pi5~7, PDF 실측 정합)은 움직이지 않는다.
                        let paint_y = whitespace_tac_carrier_stored_paint_y(
                            self.profile.get().hwpx_stored_layout(),
                            para,
                            final_comp,
                            col_area.y,
                            y_offset,
                            self.dpi,
                        )
                        .unwrap_or(y_offset);
                        let flow_end = self.layout_paragraph(
                            tree,
                            col_node,
                            para,
                            final_comp,
                            styles,
                            col_area,
                            paint_y,
                            page_content.section_index,
                            *para_index,
                            multi_col_width,
                            Some(bin_data_content),
                            ctx.wrap_anchors.get(para_index),
                        );
                        y_offset = if paint_y < y_offset {
                            y_offset + (flow_end - paint_y).max(0.0)
                        } else {
                            flow_end
                        };
                    }
                    // TAC Shape 높이 보정: 문단에 TAC Shape(개체묶기 등)가 있으면
                    // Shape 높이가 문단 텍스트 높이보다 클 수 있으므로 y_offset을 보정.
                    // LINE_SEG lh가 Shape+캡션+간격을 모두 포함하므로 max(Shape.height, lh)를 사용.
                    // 보정 시 원래 문단 간격(spacing_after)도 유지한다.
                    {
                        let has_tac_shape = para
                            .controls
                            .iter()
                            .any(|c| matches!(c, Control::Shape(s) if s.common().treat_as_char));
                        if has_tac_shape {
                            // LINE_SEG lh = 이미지+캡션+간격 전체 높이
                            let seg_lh: f64 = para
                                .line_segs
                                .iter()
                                .map(|seg| hwpunit_to_px(seg.line_height, self.dpi))
                                .fold(0.0f64, f64::max);
                            let shape_max_h: f64 = para
                                .controls
                                .iter()
                                .filter_map(|c| match c {
                                    Control::Shape(s) if s.common().treat_as_char => {
                                        Some(hwpunit_to_px(s.common().height as i32, self.dpi))
                                    }
                                    _ => None,
                                })
                                .fold(0.0f64, f64::max);
                            let effective_h = seg_lh.max(shape_max_h);
                            if effective_h > 0.0 {
                                let para_start = *para_start_y.get(para_index).unwrap_or(&y_offset);
                                // [#6551] `para_start` 는 **문단 앞 간격(sb) 이전** 위치다.
                                // 개체는 sb 아래에서 시작하므로 그만큼 더해야 한다. 종전에는
                                // 이를 버리고 `para_start + lh` 로 덮어써, 이 블록이
                                // `layout_paragraph` 가 이미 적용한 sb 를 되돌렸다
                                // (113424 7쪽 pi=73: 렌더 전진량 43.5에 sb 13.3이 빠져
                                // 다음 제목이 글상자 안으로 올라왔다).
                                let (sb, sa) = styles
                                    .para_styles
                                    .get(para.para_shape_id as usize)
                                    .map(|s| (s.spacing_before, s.spacing_after))
                                    .unwrap_or((0.0, 0.0));
                                // 단 상단 문단은 한컴이 `sb` 를 트림한다(`is_column_top`)
                                // — `layout_paragraph` 도 그렇게 놓으므로 여기서 더하면
                                // 되레 어긋난다. 단 아래로 흐른 문단에만 더한다.
                                let sb_applied = if para_start > col_area.y + 0.5 {
                                    sb.max(0.0)
                                } else {
                                    0.0
                                };
                                let shape_bottom = para_start + sb_applied + effective_h;
                                if shape_bottom > y_offset {
                                    // [#6665, #7406] 저장 줄 뒤의 다음 vpos가
                                    // lh + ls 전진을 증명할 때만 도형 높이 바닥값에도
                                    // 꼬리 ls를 복원한다. HWPX OLE 차트의 캡션 다음
                                    // 본문도 이 경로를 사용한다. 바닥값 판정에는 ls를
                                    // 넣지 않아 순수 개체 줄의 기존 소유권은 유지한다.
                                    // lh == 도형 프레임 높이인 순수 개체 줄(#1116)은
                                    // paragraph_layout의 높이 접힘과 짝을 이뤄 ls 없는
                                    // 바닥값이 전진량을 소유한다. 프레임보다 큰 저장
                                    // 줄 상자를 복원할 때만 별도의 꼬리 ls를 더한다.
                                    let profile = self.profile.get();
                                    let stored_shape_line = (profile.hwpx_stored_layout()
                                        || ((profile.hwp5_stored_pagination_layout()
                                            || profile.hwp3_layout())
                                            && !profile.hwp3_native_layout()))
                                        && para.text.chars().all(|c| {
                                            c.is_whitespace() || c <= '\u{001F}' || c == '\u{FFFC}'
                                        });
                                    let trailing_ls = match para.line_segs.as_slice() {
                                        [seg]
                                            if stored_shape_line
                                                && seg.line_height > 0
                                                && seg.line_spacing > 0
                                                && shape_max_h
                                                    < hwpunit_to_px(seg.line_height, self.dpi)
                                                && paragraphs
                                                    .get(*para_index + 1)
                                                    .and_then(|next| next.line_segs.first())
                                                    .is_some_and(|next| {
                                                        i64::from(next.vertical_pos)
                                                            - i64::from(seg.vertical_pos)
                                                            == i64::from(seg.line_height)
                                                                + i64::from(seg.line_spacing)
                                                    }) =>
                                        {
                                            hwpunit_to_px(seg.line_spacing, self.dpi)
                                        }
                                        _ => 0.0,
                                    };
                                    y_offset = shape_bottom + trailing_ls + sa;
                                }
                            }
                        }
                    }
                    // 각주 위첨자: footnote_positions가 있으면 인라인으로 이미 처리됨
                    let has_inline_fn = composed
                        .get(*para_index)
                        .map(|c| !c.footnote_positions.is_empty())
                        .unwrap_or(false);
                    if !has_inline_fn {
                        self.add_footnote_superscripts(tree, col_node, para, styles);
                    }
                }
            }
            PageItem::PartialParagraph {
                para_index,
                start_line,
                end_line,
            } => {
                if let Some(para) = paragraphs.get(*para_index) {
                    // Task #318: wrap=Square 표 호스트 문단의 텍스트는
                    // layout_wrap_around_paras (자가 wrap 경로) 가 처리한다. PartialParagraph
                    // 측에서 같은 paragraph 를 layout_partial_paragraph 로 다시 호출하면
                    // 호스트 텍스트 + 인라인 수식이 중복 emit 됨 (#301 회귀).
                    // FullParagraph 경로 (`is_wrap_host` 가드, layout.rs:1639) 와 동일한 처리.
                    let is_wrap_host = para.controls.iter().any(|c| {
                        if let Control::Table(t) = c {
                            !t.common.treat_as_char
                                && matches!(
                                    t.common.text_wrap,
                                    crate::model::shape::TextWrap::Square
                                )
                        } else {
                            false
                        }
                    });
                    let explicit_stored_fragment =
                        explicitly_split_stored_square_host(para, *start_line, *end_line);
                    // 저장 줄이 없고 표 옆에 글자 띠가 없는 host(표가 단 폭을 채움)는
                    // 글자가 표 아래로 흐른다 — typeset 이 post-text 로 소유시킨 이 줄을
                    // 일반 경로로 그린다. 띠가 있으면 표 경로가 띠에 그린다.
                    let host_text_follows_table = is_wrap_host
                        && crate::renderer::is_no_lineseg_visible_text_host(para)
                        && crate::renderer::no_lineseg_square_table_host_band(
                            para,
                            px_to_hwpunit(col_area.width, self.dpi),
                        )
                        .is_none();
                    if is_wrap_host && !explicit_stored_fragment && !host_text_follows_table {
                        return (y_offset, false);
                    }

                    // TAC 블록 표 문단의 post-text PP: 텍스트가 공백만이면 건너뜀
                    // (Table PageItem에서 이미 y_offset이 결정됨)
                    if prev_tac_seg_applied {
                        let seg_width = effective_tac_segment_width_hu(
                            para,
                            px_to_hwpunit(col_area.width, self.dpi),
                        );
                        let has_tac_block = para.controls.iter().any(|c| {
                            matches!(c, Control::Table(t) if t.common.treat_as_char
                                && !crate::renderer::height_measurer::is_tac_table_inline_in_para(
                                    t, seg_width, para))
                        });
                        if has_tac_block {
                            let pp_text_only_ws = if let Some(comp) = composed.get(*para_index) {
                                comp.lines[*start_line..*end_line].iter().all(|line| {
                                    line.runs.iter().all(|r| {
                                        r.text.chars().all(|c| {
                                            c.is_whitespace() || c <= '\u{001F}' || c == '\u{FFFC}'
                                        })
                                    })
                                })
                            } else {
                                false
                            };
                            // 가시 글자가 없어도 표와 다른 저장 줄은 자기 높이·간격을 소유한다.
                            // 실제 TAC 소유 줄의 끝 뒤에서 시작하는 원본 꼬리는 표 밴드의 사본이 아니다.
                            let independent_stored_tail = para
                                .line_segs
                                .get(*start_line..*end_line)
                                .filter(|segs| !segs.is_empty())
                                .is_some_and(|segs| {
                                    segs.iter().all(|seg| {
                                        seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0
                                            && seg.line_height > 0
                                    }) && para.controls.iter().enumerate().all(|(ci, control)| {
                                        if !matches!(control, Control::Table(table) if table.common.treat_as_char) {
                                            return true;
                                        }
                                        control_line_seg_index(para, ci)
                                            .filter(|line| *line < *start_line)
                                            .and_then(|line| para.line_segs.get(line))
                                            .is_some_and(|host| {
                                                i64::from(segs[0].vertical_pos)
                                                    >= i64::from(host.vertical_pos)
                                                        + i64::from(host.line_height)
                                                        + i64::from(host.line_spacing)
                                            })
                                    })
                                });
                            if pp_text_only_ws && !independent_stored_tail {
                                // 같은 개체 줄의 공백 캐리어는 이미 소비한 표 높이를 더하지 않는다.
                                return (y_offset, true);
                            }
                        }
                    }
                    // 번호 카운터는 첫 조각에서만 전진한다. 글머리는 카운터가 없으므로
                    // 이어지는 조각에도 같은 마커 폭을 전달해 본문 내어쓰기를 유지한다.
                    // 마커를 실제로 그리는지는 start_line을 받은 배치 경로가 결정한다.
                    let continuation_bullet = styles
                        .para_styles
                        .get(para.para_shape_id as usize)
                        .is_some_and(|style| style.head_type == HeadType::Bullet);
                    let comp = if *start_line == 0 || continuation_bullet {
                        let numbered = self.apply_paragraph_numbering(
                            composed.get(*para_index),
                            para,
                            styles,
                            outline_numbering_id,
                        );
                        // numbered가 있으면 composed 업데이트는 불가하므로
                        // layout_partial_paragraph에 직접 전달
                        numbered.or_else(|| composed.get(*para_index).cloned())
                    } else {
                        composed.get(*para_index).cloned()
                    };
                    // [Issue #677] 같은 paragraph 의 TAC 표를 선행한 PP 는 y_offset 이
                    // 이미 표 바닥까지 누적된 상태로 진입한다. 그러나 HWP IR 는 line 1 의
                    // lh 에 표 높이를 인코딩 (table 가 line 1 안의 인라인 객체) 하므로
                    // PP 의 y 를 LineSeg.vpos 정합 위치로 리셋하지 않으면 표 높이만큼
                    // 이중 누적 (LAYOUT_OVERFLOW). 조건 가드 3개로 좁게 발동:
                    //   1) start_line > 0 (문단 첫 PP 미적용)
                    //   2) para 가 TAC 표 보유 (treat_as_char=true)
                    //   3) para_start_y 등록 (Table item 선행 처리됨 → 같은 column)
                    let pp_y_in = if *start_line > 0
                        && para
                            .controls
                            .iter()
                            .any(|c| matches!(c, Control::Table(t) if t.common.treat_as_char))
                        && para_start_y.contains_key(para_index)
                    {
                        if let (Some(seg), Some(seg0), Some(para_top)) = (
                            para.line_segs.get(*start_line),
                            para.line_segs.first(),
                            para_start_y.get(para_index).copied(),
                        ) {
                            // [#5700] 되감긴 꼬리(저장 vpos 가 첫 줄보다 작음 — 한글이
                            // 표 뒤에서 쪽을 끊은 흔적)에는 이 리셋을 적용하지 않는다.
                            // 델타가 음수라 PP 가 문단 시작 위(쪽 상단·심하면 쪽 밖
                            // 음수 y)로 튀어 그리기 순서가 역전된다(해양경찰청 p139:
                            // pi759 꼬리 y 1004.9→100.1 로 리셋되어 앞 문단 위에
                            // 그려짐 · 문화예술산업 p327: y −421). 순차 흐름(표 바닥)
                            // 을 유지한다 — #677 의 이중 누적 방지는 정방향 델타
                            // 케이스에만 해당한다.
                            if seg.vertical_pos >= seg0.vertical_pos {
                                // 표 다음 줄은 이미 측정·배치한 표의 흐름 끝을 기준으로
                                // 저장 줄 사이의 간격만 이어받는다. 문단 시작에서 저장
                                // vpos를 다시 적용하면 내용에 따라 커진 표 안으로 되감긴다.
                                // 표와 같은 줄의 텍스트는 #677의 저장 앵커를 유지한다.
                                let preceding_table_line = prev_tac_seg_applied
                                    .then(|| {
                                        para.controls.iter().enumerate().find_map(|(ci, c)| {
                                            if !matches!(c, Control::Table(t) if t.common.treat_as_char)
                                            {
                                                return None;
                                            }
                                            let line = control_line_seg_index(para, ci)?;
                                            (line + 1 == *start_line)
                                                .then(|| para.line_segs.get(line))
                                                .flatten()
                                        })
                                    })
                                    .flatten();
                                if let Some(host) = preceding_table_line {
                                    let stored_end = i64::from(host.vertical_pos)
                                        + i64::from(host.line_height)
                                        + i64::from(host.line_spacing);
                                    let gap = i64::from(seg.vertical_pos) - stored_end;
                                    y_offset + gap as f64 * self.dpi / 7200.0
                                } else {
                                    para_top
                                        + hwpunit_to_px(
                                            seg.vertical_pos - seg0.vertical_pos,
                                            self.dpi,
                                        )
                                }
                            } else {
                                y_offset
                            }
                        } else {
                            y_offset
                        }
                    } else {
                        y_offset
                    };
                    // 문단 첫 부분을 먼저 그린 경우 뒤 개체의 문단 기준점은
                    // 그 글줄의 원점이다. 소비한 줄 끝으로 앵커를 새로 만들지 않는다.
                    if *start_line == 0 {
                        para_start_y.entry(*para_index).or_insert(pp_y_in);
                    }
                    let pp_y_out = self.layout_partial_paragraph(
                        tree,
                        col_node,
                        para,
                        comp.as_ref(),
                        styles,
                        styles.hwp3_variant && self.endnote_para_source_for(*para_index).is_none(),
                        col_area,
                        pp_y_in,
                        *start_line,
                        *end_line,
                        page_content.section_index,
                        *para_index,
                        None,
                        Some(bin_data_content),
                        ctx.wrap_anchors.get(para_index),
                    );
                    // The last text fragment need not end the paragraph: another
                    // object can follow it, or the table can extend below its text.
                    // Remove the text's after-spacing before merging occupied flow;
                    // the existing last-item owner adds it once after every item.
                    let deferred_spacing = comp
                        .as_ref()
                        .filter(|c| *end_line >= c.lines.len())
                        .and_then(|_| ctx.tac_text_tail_spacing_after(*para_index))
                        .unwrap_or(0.0);
                    if deferred_spacing > 0.0 {
                        deferred_paragraph_spacing.insert(*para_index, deferred_spacing);
                    }
                    y_offset = y_offset.max(pp_y_out - deferred_spacing);
                    let content_bottom = self.last_item_content_bottom.get();
                    if *start_line == 0 && content_bottom.is_finite() {
                        self.host_text_content_bottom.set(Some((
                            *para_index,
                            pp_y_in,
                            content_bottom,
                        )));
                    }
                }
            }
            PageItem::Table {
                para_index,
                control_index,
            } => {
                let host_text = self
                    .host_text_content_bottom
                    .take()
                    .filter(|(host, _, _)| host == para_index);
                if let Some((_, para_top, _)) = host_text {
                    // host 글이 표 앞 항목으로 그려졌으면 문단 기준 오프셋의 기준점은 그
                    // 글을 그리기 **전**의 문단 상단이다(FullParagraph 경로가 남기는 값과 같다).
                    para_start_y.entry(*para_index).or_insert(para_top);
                }
                self.table_push_floor
                    .set(host_text.map(|(_, _, bottom)| bottom));
                let out = self.layout_table_item(
                    tree,
                    col_node,
                    paper_images,
                    para_start_y,
                    para_float_lanes,
                    visible_float_exclusions,
                    *para_index,
                    *control_index,
                    &ctx,
                    y_offset,
                );
                self.table_push_floor.set(None);
                return out;
            }
            PageItem::PartialTable {
                para_index,
                control_index,
                start_row,
                end_row,
                is_continuation,
                start_cut,
                end_cut,
                is_block_split,
                start_cut_is_block,
                row_cursor_is_nested,
                end_row_height_override,
                start_row_height_override,
            } => {
                y_offset = self.layout_partial_table_item(
                    tree,
                    col_node,
                    para_start_y,
                    *para_index,
                    *control_index,
                    *start_row,
                    *end_row,
                    *is_continuation,
                    start_cut,
                    end_cut,
                    *is_block_split,
                    *start_cut_is_block,
                    *row_cursor_is_nested,
                    *end_row_height_override,
                    *start_row_height_override,
                    &ctx,
                    y_offset,
                );
            }
            PageItem::Shape {
                para_index,
                control_index,
            } => {
                y_offset = self.layout_shape_item(
                    tree,
                    col_node,
                    paper_images,
                    para_start_y,
                    para_inline_state,
                    *para_index,
                    *control_index,
                    &ctx,
                    y_offset,
                );
                // [#5929] 어울림 그림은 흐름 y 를 되돌리므로, 후속 T&B 표가
                // 그림 페인트 bbox 를 피할 수 있게 exclusion 을 남긴다.
                if let Some(para) = ctx.paragraphs.get(*para_index) {
                    if let Some(zone) = square_picture_side_wrap_exclusion(
                        para,
                        *para_index,
                        *control_index,
                        col_node,
                    ) {
                        visible_float_exclusions.push(zone);
                    }
                }
            }
            PageItem::EndnoteSeparator {
                separator_length,
                margin_above,
                margin_below,
                line_type,
                line_width,
                color,
            } => {
                y_offset = self.layout_endnote_separator_item(
                    tree,
                    col_node,
                    ctx.col_area,
                    y_offset,
                    *separator_length,
                    *margin_above,
                    *margin_below,
                    *line_type,
                    *line_width,
                    *color,
                );
            }
        }
        (y_offset, applied_tac_segment)
    }

    #[allow(clippy::too_many_arguments)]
    fn layout_endnote_separator_item(
        &self,
        tree: &mut PageLayoutContext,
        col_node: &mut RenderNode,
        col_area: &LayoutRect,
        mut y_offset: f64,
        separator_length: i32,
        margin_above: i16,
        margin_below: i16,
        line_type: u8,
        line_width_raw: u8,
        color: crate::model::ColorRef,
    ) -> f64 {
        y_offset += hwpunit_to_px(margin_above as i32, self.dpi);
        let has_separator = line_type != 0 && line_width_raw != 0;
        let line_width = if has_separator {
            let line_width = border_width_to_px(line_width_raw).max(0.5);
            let sep_length = note_separator_length_px(separator_length, col_area.width, self.dpi);
            let line_id = tree.next_id();
            let sep_line = LineNode::new(
                col_area.x,
                y_offset,
                col_area.x + sep_length,
                y_offset,
                LineStyle {
                    color,
                    width: line_width,
                    dash: StrokeDash::Solid,
                    ..Default::default()
                },
            );
            let sep_bbox = sep_line.ink_bbox();
            let line_node = RenderNode::new(line_id, RenderNodeType::Line(sep_line), sep_bbox);
            col_node.children.push(line_node);
            line_width
        } else {
            0.0
        };
        y_offset + line_width + hwpunit_to_px(margin_below as i32, self.dpi)
    }

    /// [Task #2091] 표 컨트롤(anchor/TAC/float) 블록 배치 — 원본 무변경 통이동.
    /// 원본의 함수 조기 return 은 `TableControlOut::early_return` 으로 반환.
    #[allow(clippy::too_many_arguments)]
    fn layout_table_control_block(
        &self,
        tree: &mut PageLayoutContext,
        col_node: &mut RenderNode,
        paper_images: &mut Vec<RenderNode>,
        para_start_y: &mut std::collections::HashMap<usize, f64>,
        para_float_lanes: &mut ParaFloatLanes,
        visible_float_exclusions: &mut Vec<VisibleFloatExclusion>,
        ctx: &ColumnItemCtx,
        para: &Paragraph,
        v: TableControlVars,
    ) -> TableControlOut {
        let ColumnItemCtx {
            page_content,
            paragraphs,
            composed,
            styles,
            bin_data_content,
            measured_tables,
            layout,
            col_area,
            zone_column_count,
            outline_numbering_id,
            multi_col_width,
            prev_tac_seg_applied,
            wrap_around_paras,
            wrap_anchors,
            ..
        } = ctx;
        let TableControlVars {
            mut y_offset,
            mut para_y_for_table,
            mut tac_table_y_before,
            is_tac,
            is_current_empty_para_float,
            is_current_empty_square_sibling_float,
            is_current_visible_para_float,
            is_first_empty_para_float_control,
            rewind_anchor_snapped,
            para_index,
            control_index,
        } = v;
        let flow_placement = ctx
            .inline_placements
            .get(&(para_index, control_index))
            .filter(|_| is_tac);
        let mut tac_seg_applied = false;
        let mut para_float_lane_info: Option<(f64, f64, f64, f64, f64, Option<f64>)> = None;
        if let Some(Control::Table(t)) = para.controls.get(control_index) {
            let (font_slots,font_sources,_,_)=self.exact_font_source_registry_counts();
            let current_stack = (self.profile.get().hwp5_origin_hwpx()
                && !self.profile.get().hwp3_layout() && !self.profile.get().hangul2024_layout()
                && font_slots==0 && font_sources==0).then(||
                current_body_stack::current_table_top(ctx, para_index, control_index, y_offset, self.dpi)).flatten();
            if let Some(plan) = current_stack { para_y_for_table = plan.table_top; }
            // Independent current-allocation candidate. The existing source,
            // completed-row and narrow stack paths retain their own contracts.
            let current_frame_top=if current_stack.is_none(){tree.current_frame_paint_plan.as_ref().and_then(|plan|
                plan.table_top(paragraphs,page_content.section_index,page_content.page_index,
                    page_content.column_contents.first()?.column_index,col_area,para_index,control_index,y_offset))}else{None};
            if let Some(top)=current_frame_top {para_y_for_table=top;}

            if self.owns_completed_native_frame(para,control_index,page_content,col_area,layout,y_offset) {
                para_y_for_table=y_offset;
            }
            if let Some(placement) = flow_placement {
                // metadata는 여백 포함 줄의 pen이다. inline_x_override가 있는 표 paint는
                // 호출자가 여백을 소비한 테두리 좌표를 받으므로 여기서 한 번 변환한다.
                y_offset =
                    col_area.y + placement.y + hwpunit_to_px(t.outer_margin_top as i32, self.dpi);
                tac_table_y_before = y_offset;
            }
            let raw_mt = measured_tables
                .iter()
                .find(|mt| mt.para_index == para_index && mt.control_index == control_index);
            let fitted_visible_mt = if is_current_visible_para_float {
                raw_mt.map(|measured| {
                    // typeset format_table 과 같은 가드 — 편집 세션이거나 중첩 표
                    // 없는 텍스트 행이 선언 행높이를 1.5배 넘게 초과했으면(셀 편집
                    // 성장) 압축하지 않는다(압축하면 커진 행의 몫을 다른 행이
                    // 빼앗겨 내부가 위로 밀린다).
                    if self.profile.get().session_edited()
                        || crate::renderer::height_measurer::measured_table_has_grown_text_row(
                            measured, t, self.dpi,
                        )
                    {
                        measured.clone()
                    } else {
                        fit_measured_table_to_declared_height(measured, t, self.dpi)
                    }
                })
            } else {
                None
            };
            let mt = fitted_visible_mt.as_ref().or(raw_mt);
            let declared_height = hwpunit_to_px(signed_hwpunit(t.common.height), self.dpi);
            let unresolved_placeholder_origin = unresolved_single_table_placeholder_paint_origin_hu(
                self.profile.get().hwp5_stored_pagination_layout(),
                *zone_column_count, paragraphs, para_index, t,
                mt.map(|measured| measured.total_height), self.dpi,
                self.profile.get().native_hwp5_layout() && self.profile.get().session_edited(),
                ctx.paragraph_float_placements.get(&(para_index, control_index)),
            ).map(|hu| col_area.y + hwpunit_to_px(hu, self.dpi));
            // 확정 표 원점은 위여백을 이미 소비했다. 같은 계획이 없는 저장 표만
            // 기존 출력 보정을 적용하며, 아래 흐름 끝에서도 그 보정만 되돌린다.
            let physical_outer_box_paint_inset = !ctx
                .paragraph_float_placements
                .contains_key(&(para_index, control_index))
                && physical_outer_box_paint_inset_layout_gate(
                    *zone_column_count,
                    mt.map(|measured| measured.total_height),
                    declared_height,
                )
                && is_current_empty_para_float
                && (native_empty_host_physical_outer_box_paint_inset(
                    self.profile.get().hwp5_stored_pagination_layout(),
                    para,
                    t,
                    paragraphs.get(para_index + 1),
                ) || anchor_box_flow::offset_table_has_stored_outer_box(
                    self.profile.get().hwp5_stored_pagination_layout(),
                    para,
                    t,
                    paragraphs.get(para_index + 1),
                ));
            let physical_outer_box_paint_inset_y = if physical_outer_box_paint_inset {
                hwpunit_to_px(t.outer_margin_top as i32, self.dpi)
            } else {
                0.0
            };
            let para_style = styles.para_styles.get(para.para_shape_id as usize);
            let alignment = para_style.map(|s| s.alignment).unwrap_or(Alignment::Left);
            let margin_left = para_style.map(|s| s.margin_left).unwrap_or(0.0);
            let indent = para_style.map(|s| s.indent).unwrap_or(0.0);
            // [Issue #6190] 저장 LINE_SEG 의 `TAG_INDENTATION`(bit 20)이 꺼진 첫 줄에는
            // 들여쓰기를 얹지 않는다 — `paragraph_layout` 의 본문 줄과 같은 계약이다.
            // 이 계약이 없으면 표 호스트 문단이 들여쓰기만큼 밀려 표가 용지 밖으로
            // 나간다(156458354 3쪽: 표 우변 829.8, 용지 793.7).
            let stored_first_seg_denies_indent = para.line_segs.first().is_some_and(|seg| {
                seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0
                    && seg.tag & crate::model::paragraph::LineSeg::TAG_INDENTATION == 0
            });
            let table_owner_line = composed.get(para_index).and_then(|comp| {
                para.control_text_positions()
                    .get(control_index)
                    .and_then(|position| {
                        comp.lines
                            .iter()
                            .rposition(|line| line.char_start <= *position)
                    })
                    .map(|index| (index, comp.lines.len()))
            });
            let effective_margin =
                if let Some((index, count)) = table_owner_line.filter(|_| t.common.treat_as_char) {
                    // 표도 자신이 속한 글줄의 들여쓰기·내어쓰기와 저장 플래그를 소비한다.
                    margin_left
                        + crate::renderer::equation_tac_flow::paragraph_line_indent_for_source(
                            indent,
                            index,
                            Some(para),
                            count,
                            true,
                        )
                } else if indent > 0.0 && !stored_first_seg_denies_indent {
                    margin_left + indent
                } else {
                    margin_left
                };
            let margin_right = para_style.map(|s| s.margin_right).unwrap_or(0.0);
            let table_y_before = y_offset;
            let tbl_is_square = matches!(t.common.text_wrap, crate::model::shape::TextWrap::Square);
            // [#4533 ⑥] '위 예약' Square float — 저장 사다리가 표 공간을
            // 앵커 **위**에 예약(직전 문단 저장 끝→호스트 vpos 갭 ≈ 표높이)한
            // 문서는 한글이 표를 그 공간에, 앵커 줄을 아래에 둔다(아세안
            // 156454300 실측: 갭 182.3 vs 표 188.1 — rhwp 는 표를 앵커 뒤에
            // 그리고 +201 전진해 시각·흐름 모두 반대였고, typeset 은 밴드
            // 비예약이라 조판·렌더 desync). 판별자는 ④-a 직전-갭 계보.
            let square_reserved_above_gap: Option<f64> = (|| {
                if !self.profile.get().hwp5_stored_pagination_layout()
                    || !tbl_is_square
                    || t.common.treat_as_char
                    || para_has_non_whitespace_text(para)
                    || para_index == 0
                {
                    return None;
                }
                let tot = hwpunit_to_px(t.common.height as i32, self.dpi);
                let host_lh = para
                    .line_segs
                    .iter()
                    .find(|sg| sg.tag & 0x8000_0000 == 0)
                    .map(|sg| hwpunit_to_px(sg.line_height, self.dpi))?;
                let ps = paragraphs.get(para_index - 1)?.line_segs.last()?;
                let hs = para.line_segs.first()?;
                if hs.vertical_pos <= ps.vertical_pos + ps.line_height {
                    return None;
                }
                let gap = hwpunit_to_px(
                    hs.vertical_pos - (ps.vertical_pos + ps.line_height),
                    self.dpi,
                );
                (tot > 1.0 && gap >= tot * 0.85 && host_lh < tot * 0.25).then_some(gap)
            })();
            // インラインTAC表: paragraph_layoutで計算された位置を使用
            let inline_pos = if is_tac {
                tree.get_inline_shape_position(
                    page_content.section_index,
                    para_index,
                    control_index,
                    None,
                )
            } else {
                None
            };
            // [Task #1470 Stage 2] paragraph_layout가 인라인 TAC 표를 이미
            // 렌더하고 좌표를 등록한 경우, PageItem 표 경로에서는 본문 흐름
            // advance만 보존하고 같은 컨트롤을 다시 그리지 않는다.
            let tac_already_rendered_inline = is_tac && inline_pos.is_some();
            let tbl_inline_x = if let Some((ix, _)) = inline_pos {
                Some(ix)
            } else if !is_tac
                && tbl_is_square
                && matches!(t.common.horz_rel_to, crate::model::shape::HorzRelTo::Para)
            {
                // [Issue #480 / #590] horz_rel_to=Para 인 Square wrap 표만 paragraph 영역
                // (col_area + margin) 기준으로 정렬. horz_rel_to=Column/Page/Paper 는
                // compute_table_x_position 의 기본 분기에서 명세대로 처리한다.
                // (Task #295: halign=Right 표가 좌측에 잘못 배치되는 문제 수정)
                let tbl_w = hwpunit_to_px(t.common.width as i32, self.dpi);
                let area_x = col_area.x + effective_margin;
                let area_w = (col_area.width - effective_margin - margin_right).max(0.0);
                // [#6887] 왼쪽 정렬 어울림 표의 저장 `horzOffset` 은 **바깥 여백
                // 상자**의 왼끝을 가리킨다 — 표 자신의 왼끝은 거기서
                // `outMargin.left` 만큼 안쪽이다. 바로 위 TAC 분기(`base_x`)와
                // 개체 경로(`shape_layout::form_object_origin`)는 이미 이 여백을
                // 싣고 있고 어울림 표 경로만 빠져 있었다. 오른쪽·가운데 정렬은
                // 기준 폭 산식이 달라(`area_w`) 실측 근거가 나올 때까지 둔다.
                let om_l = para_relative_left_aligned_outer_margin_left_hu(t)
                    .map(|hu| hwpunit_to_px(hu, self.dpi))
                    .unwrap_or(0.0);
                let x = match t.common.horz_align {
                    crate::model::shape::HorzAlign::Right
                    | crate::model::shape::HorzAlign::Outside => area_x + (area_w - tbl_w).max(0.0),
                    crate::model::shape::HorzAlign::Center => {
                        area_x + (area_w - tbl_w).max(0.0) / 2.0
                    }
                    _ => area_x + om_l,
                };
                Some(x)
            } else if is_tac {
                // TAC 문단에 PageItem::FullParagraph 가 발행되지 않아
                // paragraph_layout 가 호출되지 않는 케이스(선행 공백만 있는 TAC 표 등):
                // composed.lines[0] 의 runs 에서 TAC 이전 텍스트 폭을 직접
                // 합산해 표 x 좌표에 반영한다. inline_shape_position 미세팅 상태에서
                // 기본값 col_area.x(body_left) 으로 붕괴되는 현상 방지.
                // [Issue #842 #2] 문단이 여러 줄이고 line 0 에 *실제 텍스트*(필러/공백/
                // 오브젝트마커가 아닌 가시 글자)가 있으면 — 예: line 0 = "파일" 텍스트 +
                // line 1 = 자체 줄의 헤더 바 표 — 표는 line 0 텍스트 *다음* 이 아니라
                // 자체 줄 좌측에서 시작하므로 leading = 0. line 0 이 HWP TAC 필러(U+F081C)/
                // 공백뿐인 경우(예: 복학원서.hwp pi=16, 한컴이 표 폭만큼 필러를 채워
                // 줄바꿈시킨 케이스)는 종전대로 compute_tac_leading_width 사용.
                // "실제 텍스트" 판정은 alphanumeric(한글 음절·라틴·숫자·한자 등 Letter/Number)
                // 만 인정 — HWP TAC 필러(U+F081C 등 PUA), 공백, 오브젝트마커는 PUA/공백이라
                // 자동 제외된다 (복학원서.hwp pi=16 line 0 = U+F081C/U+F012B 필러 99개 → 제외).
                let line0_has_real_text = composed
                    .get(para_index)
                    .map(|c| {
                        c.lines.len() > 1
                            && c.lines
                                .first()
                                .map(|l0| {
                                    l0.runs
                                        .iter()
                                        .any(|r| r.text.chars().any(|ch| ch.is_alphanumeric()))
                                })
                                .unwrap_or(false)
                    })
                    .unwrap_or(false);
                // [Issue #6167] 저장 사다리가 표에 자기 줄(`horzpos=0`)을 줬으면 앞 줄의
                // 공백은 표의 x 가 아니다. 113424 38쪽 `[별지 제5호 서식]` 표는 앞 공백
                // 18자(120.0px)만큼 밀려 본문 우단 83.6px·용지 8.0px 밖으로 잘렸다 —
                // 한글 2020·2024 모두 표를 좌단(75.32)에 둔다.
                let stored_own_line = paragraphs
                    .get(para_index)
                    .is_some_and(|p| stored_ladder_gives_tac_table_its_own_line(p, control_index));
                // 합성 줄도 개행으로 결정된 자기 줄의 머리 공백을 소유한다.
                // 앞 제목 줄의 유무로 그 공백을 버리거나 셀 padding으로 대신하지 않는다.
                let computed_own_line = crate::renderer::para_has_no_stored_line_segs(para)
                    && composed.get(para_index).is_some_and(|comp| {
                        let position = para.control_text_positions().get(control_index).copied();
                        position.is_some_and(|position| {
                            comp.lines
                                .iter()
                                .rposition(|line| line.char_start <= position)
                                .is_some_and(|index| {
                                    index > 0
                                        && comp.lines[index - 1].has_line_break
                                        && para
                                            .text
                                            .chars()
                                            .take(comp.lines[index].char_start)
                                            .last()
                                            == Some('\n')
                                })
                        })
                    });
                let leading = if (line0_has_real_text && !computed_own_line) || stored_own_line {
                    0.0
                } else {
                    composed
                        .get(para_index)
                        .map(|c| {
                            // [#6298] 블록 취급 표의 문단 내 char 위치 — `tac_controls`
                            // 와 같은 좌표계(`find_render_inline_control_positions`)로
                            // 뽑아야 정지점이 어긋나지 않는다.
                            let block_pos = paragraphs.get(para_index).and_then(|p| {
                                crate::renderer::composer::find_render_inline_control_positions(p)
                                    .get(control_index)
                                    .copied()
                            });
                            compute_tac_leading_width(c, control_index, styles, block_pos)
                        })
                        .unwrap_or(0.0)
                };
                // [#6737] leading 을 실었을 때 표가 단 오른쪽을 **한 글자 이상** 넘으면
                // 그 leading 은 실제가 아니다 — 한컴은 그런 표를 다음 줄 좌단에 둔다.
                //
                // `stored_own_line` 만으로는 못 걸러진다. 그 판정은 표의 **문자 축**
                // 위치와 저장 `text_start`(**HWP5 축**)를 견주는데, 앞에 확장 컨트롤이
                // 있으면 컨트롤 하나당 8 유닛씩 벌어져 영원히 거짓이 된다
                // (156487948 pi=0: 문자 40 vs 저장 72 — 그림 2개 때문에 32 차이).
                // `#6167` 이 그 술어를 세울 때 쓴 문서는 선행 컨트롤이 없어 두 축이
                // 우연히 겹쳤을 뿐이다.
                //
                // 축 환산 대신 **기하**로 막는다. 156487948: leading 392.0 + 표 635.5
                // = 1027.5 가 단폭 642.5 를 385px 넘겨, 표 오른쪽 절반과 셀 4개가
                // 용지 밖으로 나가 70자가 사라졌다.
                //
                // ⚠ 여유 한 글자(16px)는 필러 기반 leading 을 지키기 위한 것이다 —
                // `복학원서.hwp`(#677 골든)는 leading 5.13px + 표 642.5 로 단폭을
                // 5.1px 만 넘는데, 그 축은 `#1195` 한컴 실측으로 보정된 별도 축이다.
                const TAC_LEADING_OVERHANG_TOLERANCE_PX: f64 = 16.0;
                let leading = {
                    let tbl_w = hwpunit_to_px(t.common.width as i32, self.dpi);
                    let avail = (col_area.width - effective_margin - margin_right).max(0.0);
                    if leading > 0.0 && leading + tbl_w > avail + TAC_LEADING_OVERHANG_TOLERANCE_PX
                    {
                        0.0
                    } else {
                        leading
                    }
                };
                // [Issue #3396] 한글은 TAC 표를 "문자"로 취급해 advance =
                // outMargin.left + 표폭 + outMargin.right 로 잡고, 괘선(테두리)은
                // pen + outMargin.left 에 그린다 (오라클 실측: 156678235 p1 JUSTIFY
                // 표 좌측 괘선 = col_x + om_l, p5 RIGHT 표 우측 괘선 =
                // 우측 여백 - om_r, 표+여백이 단폭을 넘어도 클램프 없음).
                // 단, U+F081C 필러 기반 leading(compute_tac_leading_width)이 있는
                // 케이스는 [#1195] 한컴 실측으로 보정된 별도 축이라 om 을 겹치면
                // 이중 가산이 된다 (복학원서 접수증 오라클 실측: 한컴 ※ 81.7 vs
                // rhwp leading 포함 86.9 — leading 축 자체의 잔차가 미해결이므로
                // 그 케이스는 종전 위치를 유지한다).
                let (om_l, om_r) = if leading > 0.0 && !computed_own_line {
                    (0.0, 0.0)
                } else {
                    (
                        hwpunit_to_px(t.outer_margin_left as i32, self.dpi),
                        hwpunit_to_px(t.outer_margin_right as i32, self.dpi),
                    )
                };
                let base_x = col_area.x
                    + effective_margin
                    + leading
                    + om_l
                    + if computed_own_line {
                        0.0
                    } else {
                        viewtext_first_rowbreak_table_left_inset(para, control_index, t, self.dpi)
                    };
                // [Issue #291] ParaShape align 반영:
                // TAC 표가 inline_shape_position 미설정 상태에서 단/문단 좌측에
                // 붙어버리는 회귀를 막는다. ParaShape align=Right 인 경우 표를
                // 단의 우측 끝 - 표 폭 - margin_right 위치로 이동시켜 한컴과 일치.
                // align=Center 도 동일 원리로 처리.
                let aligned_x = match para_style.map(|s| s.alignment) {
                    Some(crate::model::style::Alignment::Right) => {
                        let tbl_w = hwpunit_to_px(t.common.width as i32, self.dpi);
                        let avail_right = col_area.x + col_area.width - margin_right;
                        (avail_right - om_r - tbl_w).max(base_x)
                    }
                    Some(crate::model::style::Alignment::Center) => {
                        let tbl_w = hwpunit_to_px(t.common.width as i32, self.dpi);
                        // 인라인 위치가 없는 TAC 표도 host 문단의 가용 줄 영역에서
                        // 가운데 정렬한다. 왼쪽 여백만 있는 경우 단 전체 폭에서
                        // 정렬하면 표가 여백의 절반만큼 왼쪽으로 치우친다.
                        let line_width =
                            (col_area.width - effective_margin - margin_right).max(0.0);
                        let center = col_area.x
                            + effective_margin
                            + (line_width - tbl_w) / 2.0
                            + (om_l - om_r) / 2.0;
                        center.max(base_x)
                    }
                    _ => base_x,
                };
                if std::env::var("RHWP_DIAG_TACX").is_ok() {
                    eprintln!(
                        "DIAG_TACX pi={} ci={} align={:?} base_x={:.2} aligned_x={:.2} tblw={:.2} om_l={} om_r={} col_x={:.2} col_w={:.2} eff_ml={:.2} mr={:.2} leading={:.2}",
                        para_index,
                        control_index,
                        alignment,
                        base_x,
                        aligned_x,
                        hwpunit_to_px(t.common.width as i32, self.dpi),
                        t.outer_margin_left,
                        t.outer_margin_right,
                        col_area.x,
                        col_area.width,
                        effective_margin,
                        margin_right,
                        leading,
                    );
                }
                Some(aligned_x)
            } else {
                None
            };
            let tbl_inline_x = flow_placement
                .filter(|placement| placement.advance_end.is_none())
                .map(|placement| {
                    col_area.x + placement.x + hwpunit_to_px(t.outer_margin_left as i32, self.dpi)
                })
                .or(tbl_inline_x);
            let tac_detached_line_shift =
                if is_tac && inline_pos.is_none() && table_has_detached_para_flow_object(t) {
                    para.line_segs
                        .first()
                        .filter(|seg| seg.vertical_pos > 0)
                        .map(|seg| hwpunit_to_px(seg.vertical_pos, self.dpi))
                        .unwrap_or(0.0)
                } else {
                    0.0
                };
            let table_visual_height = mt
                .map(|m| m.total_height)
                .filter(|h| *h > 0.0)
                .unwrap_or_else(|| hwpunit_to_px(t.common.height as i32, self.dpi));
            let tac_receipt_seal_line = if is_tac && inline_pos.is_none() {
                tac_receipt_filler_prefix(
                    para,
                    composed.get(para_index),
                    t,
                    control_index,
                    self.dpi,
                )
            } else {
                None
            };
            let tac_post_f081c_line = if is_tac && inline_pos.is_none() {
                tac_receipt_post_f081c_line(
                    para,
                    composed.get(para_index),
                    t,
                    control_index,
                    self.dpi,
                )
            } else {
                None
            };
            // [#2019 v3] 빈 앵커에 매달린 Paper/Page 기준 Square 표는 본문 flow 표가
            // 아니라 페이지 절대좌표 부동 표다. 표 자체는 선언 y 에 그리되, 뒤따르는
            // 문단을 표 아래로 밀지 않는다.
            // [#7548] 쪽·종이 기준 어울림 표는 host 문단에 본문이 있어도 절대 위치다.
            // 한/글 36295751: 표 상단 = 본문 상단 + vertOffset(PAGE = 본문 영역),
            // host·뒤 문단은 표 위로 흐르고 표는 흐름을 밀지 않는다.
            let paper_page_square_empty_top = if !is_tac
                && tbl_is_square
                && matches!(
                    t.common.vert_rel_to,
                    crate::model::shape::VertRelTo::Paper | crate::model::shape::VertRelTo::Page
                ) {
                let v_off = hwpunit_to_px(signed_hwpunit(t.common.vertical_offset), self.dpi);
                let (ref_y, ref_h) = match t.common.vert_rel_to {
                    crate::model::shape::VertRelTo::Page => {
                        (layout.body_area.y, layout.body_area.height)
                    }
                    _ => (0.0, layout.page_height),
                };
                let om_top =
                    if matches!(t.common.vert_rel_to, crate::model::shape::VertRelTo::Paper) {
                        hwpunit_to_px(t.outer_margin_top as i32, self.dpi)
                    } else {
                        0.0
                    };
                let om_bottom =
                    if matches!(t.common.vert_rel_to, crate::model::shape::VertRelTo::Paper) {
                        hwpunit_to_px(t.outer_margin_bottom as i32, self.dpi)
                    } else {
                        0.0
                    };
                Some(match t.common.vert_align {
                    crate::model::shape::VertAlign::Top
                    | crate::model::shape::VertAlign::Inside => ref_y + v_off + om_top,
                    crate::model::shape::VertAlign::Center => {
                        ref_y + (ref_h - table_visual_height) / 2.0 + v_off
                    }
                    crate::model::shape::VertAlign::Bottom
                    | crate::model::shape::VertAlign::Outside => {
                        ref_y + ref_h - table_visual_height - v_off - om_bottom
                    }
                })
            } else {
                None
            };
            // vert=Paper로 body_area 위에 배치되는 표
            // 본문 영역 외부(머리말/꼬리말 자리)에 그려지는 페이지/페이퍼 앵커 TopAndBottom 표는
            // 본문 흐름의 y_offset을 진행시키지 않고 out-of-flow로 paper_images에 렌더한다.
            // (Task #295: vert=Page valign=Bottom 푸터 표가 좌단 y_offset을 본문 하단으로
            //  끌어올려 후속 콘텐츠를 깨뜨리는 문제 수정 — Paper만 다루던 기존 분기를 Page까지 확장)
            let renders_outside_body = !is_tac
                && matches!(
                    t.common.vert_rel_to,
                    crate::model::shape::VertRelTo::Paper | crate::model::shape::VertRelTo::Page
                )
                && matches!(
                    t.common.text_wrap,
                    crate::model::shape::TextWrap::TopAndBottom
                )
                && {
                    let tbl_h = hwpunit_to_px(t.common.height as i32, self.dpi);
                    let v_off = hwpunit_to_px(t.common.vertical_offset as i32, self.dpi);
                    let tbl_y = match t.common.vert_align {
                        crate::model::shape::VertAlign::Top
                        | crate::model::shape::VertAlign::Inside => v_off,
                        crate::model::shape::VertAlign::Center => {
                            (layout.page_height - tbl_h) / 2.0 + v_off
                        }
                        crate::model::shape::VertAlign::Bottom
                        | crate::model::shape::VertAlign::Outside => {
                            layout.page_height - tbl_h - v_off
                        }
                    };
                    // 표 상단이 본문 위(머리말)이거나, 표 하단이 본문 아래(꼬리말)에 걸치는 경우
                    let body_bottom = layout.body_area.y + layout.body_area.height;
                    tbl_y < layout.body_area.y || tbl_y + tbl_h > body_bottom
                };
            // [#4068] 단 맨 위 문단 기준 자리차지 표의 테두리 원점 보정(px, 아래 폴백 갈래에서만).
            let mut column_top_outer_box_inset_y = 0.0f64;
            if is_current_empty_para_float && !renders_outside_body {
                let width_px = hwpunit_to_px(signed_hwpunit(t.common.width), self.dpi);
                if width_px > 0.0 {
                    let placement_ctx = FloatPlacementContext::new(**col_area)
                        .with_body_area(layout.body_area)
                        .with_paper_width(layout.page_width)
                        .with_host_margins(effective_margin, margin_right);
                    let (x_start, x_end) =
                        horizontal_range(&t.common, width_px, placement_ctx, self.dpi);
                    let v_offset_px =
                        hwpunit_to_px(signed_hwpunit(t.common.vertical_offset), self.dpi);
                    let fragment_outer_top_px = native_empty_host_rowbreak_line_advance_hu(
                        self.profile.get().hwp5_stored_pagination_layout(),
                        para,
                        t,
                        paragraphs.get(para_index + 1),
                    )
                    .map(|_| hwpunit_to_px(t.outer_margin_top as i32, self.dpi))
                    .unwrap_or_else(|| {
                        // rhwp가 HWP5에서 내보낸 HWPX의 비분할 빈-host 표는
                        // 저장 HWPX 줄 배치 계약을 쓰지 않는다. 측정이 예약한
                        // outer_top을 실제 첫 표 원점에도 소비한다. 저장 top이나
                        // 별도 flow snap이 있으면 아래 raw_top 선택에서 우선한다.
                        // 한컴 2020 #7265 셀 서식 편집본: 본문 132.3px,
                        // 표 테두리 136.0px = 본문 + 283HU.
                        if self.profile.get().hwp5_origin_hwpx()
                            // This explicit native row already owns the same
                            // pre-inset frame used before HWP -> XML storage.
                            // Do not add its outer margin again at paint time.
                            && !self.owns_completed_native_frame(para,control_index,page_content,col_area,layout,y_offset)
                            && !self.native_source_synthetic_context.get()
                                .is_some_and(|context| para.owns_native_source_synthetic_rows(context))
                            && !(layout.column_areas.len()==1
                                && (crate::renderer::float_placement::plain_positive_offset_stack(paragraphs,para_index)
                                    || crate::renderer::float_placement::closed_full_width_positive_pair(paragraphs,para_index)
                                    || (para_index==2 && crate::renderer::float_placement::negative_pair_has_frame_anchor(paragraphs))))
                            && !is_current_empty_square_sibling_float
                            && is_para_topbottom_float(&t.common)
                            && matches!(t.page_break, TablePageBreak::None)
                        {
                            return hwpunit_to_px(t.outer_margin_top as i32, self.dpi);
                        }
                        // [#6378] 원본 HWPX 는 HWP5 RowBreak helper 가 꺼져
                        // outMargin.top 이 빈 host 상단에 안 실린다. 같은
                        // 문서 HWP 는 y 가 3.8px 아래(283HU)다. 모든 T&B
                        // 빈 host 에 더하면 #1133 연속 표 간격이 줄어든다.
                        original_hwpx_column_rowbreak_equal_outer_margin_hu(
                            !self.profile.get().hwp5_stored_pagination_layout(),
                            t,
                        )
                        .map(|hu| hwpunit_to_px(hu, self.dpi))
                        .unwrap_or(0.0)
                    });
                    let stored_top = (!is_current_empty_square_sibling_float)
                        .then(|| {
                            native_empty_single_topbottom_table_saved_top(
                                self.profile.get().hwp5_stored_pagination_layout(),
                                para,
                                paragraphs.get(para_index + 1),
                                t,
                                mt.map(|measured| measured.total_height),
                                col_area,
                                self.dpi,
                            )
                        })
                        .flatten();
                    let stored_flow_advance = stored_top.and_then(|_| {
                        stored_topbottom_flow_advance_hu(para, paragraphs.get(para_index + 1), t)
                            .map(|height| hwpunit_to_px(height as i32, self.dpi))
                    });
                    let raw_top = if let Some(plan) = current_stack {
                        plan.table_top
                    } else if let Some(top)=current_frame_top {
                        top
                    } else if let Some(placement) = ctx
                        .paragraph_float_placements
                        .get(&(para_index, control_index))
                    {
                        col_area.y + placement.table_top
                    } else if is_current_empty_square_sibling_float {
                        // 이 pair는 같은 저장 LINE_SEG의 page-relative 좌표를 공유한다.
                        // 현재 흐름 y를 쓰면 첫 표 아래에 둘째 표를 수직으로 쌓아
                        // 본문·각주를 침범한다.
                        empty_square_sibling_table_saved_top(para, col_area, self.dpi)
                            .unwrap_or_else(|| {
                                empty_host_float_raw_top(
                                    para_y_for_table,
                                    v_offset_px,
                                    fragment_outer_top_px,
                                )
                            })
                    } else if let Some(stored_top) = stored_top {
                        stored_top
                    } else if let Some(flow_top) = empty_float_vpos_snap_flow_top(
                        para,
                        t,
                        para_y_for_table,
                        self.item_flow_snap_context.get(),
                        col_area,
                        self.dpi,
                    ) {
                        flow_top
                    } else {
                        // [#4068] 문단 기준 자리차지 표의 세로 오프셋은 바깥 여백 상자의 윗변을
                        // 가리킨다 — 테두리는 그 아래 `outMargin.top` 에 선다. 흐름은 이미 바깥
                        // 상자를 예약하므로(`pic-in-table-with-toggle` 저장 다음 줄 vpos 39354 =
                        // 283 + 38788 + 283) 그림 원점만 옮긴다.
                        //
                        // ⚠ 단 맨 위 앵커로 한정한다. 앵커가 앞 내용 아래면 `para_y` 가 이미
                        // 앞 줄의 줄간격·저장 스냅을 소비해 정본과 맞고(hwpspec 쪽 중간 표
                        // 36건이 그대로 맞음), 여기서 더하면 두 번 든다. 흐름 커서(`raw_top`)
                        // 를 올리면 `compute_table_y_position` 의 #6598 저장 앵커 갈래가 깨어나
                        // 저장 vpos 까지 한 번 더 얹으므로(hwpspec 18쪽 103.6 → 117.8, 정본
                        // 111.16) 커서가 아니라 paint inset 으로 넣는다.
                        //
                        // 앞 쪽에 앵커된 표가 자리가 모자라 이 단 맨 위로 넘어왔으면(저장 vpos
                        // 되감김 없음) 한/글은 세로 오프셋을 버리고 단 윗변 + 바깥 여백에 둔다
                        // (`정책연구용역사업 중간진도보고서` 24쪽 `pi=344`: vOff 560HU 인데 정본
                        // 그림 88.8 = 본문 83.2 + 283HU + 칸 여백 141HU).
                        if !is_current_empty_square_sibling_float
                            && is_para_topbottom_float(&t.common)
                            && t.outer_margin_top > 0
                            && fragment_outer_top_px == 0.0
                            && (para_y_for_table - col_area.y).abs() < 0.5
                            // 앞 문단이 같은 쪽에 있으면 앵커는 단 맨 위가 아니다 — `para_y` 만
                            // 칼럼 상단으로 들어온 #6598 형상은 저장 앵커 갈래가 맡는다.
                            && !para_index.checked_sub(1).is_some_and(|prev_index| {
                                page_content.column_contents.iter().any(|column| {
                                    column.items.iter().any(|item| item.para_index() == prev_index)
                                })
                            })
                        {
                            let outer_top_px = hwpunit_to_px(t.outer_margin_top as i32, self.dpi);
                            column_top_outer_box_inset_y =
                                if stored_anchor_starts_column(paragraphs, para_index) {
                                    outer_top_px
                                } else {
                                    outer_top_px - v_offset_px.max(0.0)
                                };
                        }
                        empty_host_float_raw_top(
                            para_y_for_table,
                            v_offset_px,
                            fragment_outer_top_px,
                        )
                    };
                    let lane_top = para_float_lanes
                        .entry(para_index)
                        .or_default()
                        .pushed_top(x_start, x_end, raw_top);
                    // 앞선 형제 표 lane 에 밀렸으면 앵커가 단 맨 위가 아니다.
                    if (lane_top - raw_top).abs() >= 0.01 {
                        column_top_outer_box_inset_y = 0.0;
                    }
                    para_float_lane_info = Some((
                        x_start,
                        x_end,
                        raw_top,
                        lane_top,
                        y_offset,
                        stored_flow_advance,
                    ));
                }
            }
            let mut table_visual_shift = 0.0;
            let mut table_y_end = y_offset;
            if renders_outside_body {
                let tmp_id = tree.next_id();
                let mut tmp_node = RenderNode::new(
                    tmp_id,
                    RenderNodeType::Column(0),
                    layout_rect_to_bbox(&layout.body_area),
                );
                let _table_y_end = self.layout_table(
                    tree,
                    &mut tmp_node,
                    t,
                    page_content.section_index,
                    styles,
                    *outline_numbering_id,
                    &layout.body_area,
                    y_offset,
                    bin_data_content,
                    mt,
                    0,
                    Some((para_index, control_index)),
                    alignment,
                    None,
                    effective_margin,
                    margin_right,
                    tbl_inline_x,
                    None,
                    Some(para_y_for_table),
                    None,
                    false,
                    false,
                    0.0,
                    None,
                    Self::standalone_table_char_border_fill(Some(para), t, styles),
                );
                let layer = Self::render_layer_from_common(&t.common, para_index, control_index);
                Self::push_layered_paper_children(paper_images, &mut tmp_node, layer);
                // 종이 기준 떠 있는 개체는 본문 밖에 그리지만, 다음 저장 글줄이
                // 호스트 줄의 끝과 뒤 간격의 합에서 시작하면
                // 그 호스트 줄은 본문 흐름에 남는다.
                if self.profile.get().hwpx_stored_layout()
                    && matches!(t.common.vert_rel_to, crate::model::shape::VertRelTo::Paper)
                    && !para_has_visible_text(para)
                {
                    if let (Some(seg), Some(next)) = (
                        para.line_segs.first(),
                        paragraphs
                            .get(para_index + 1)
                            .and_then(|p| p.line_segs.first()),
                    ) {
                        if seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY
                            == 0
                            && next.tag
                                & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY
                                == 0
                            && next.vertical_pos
                                == seg
                                    .vertical_pos
                                    .saturating_add(seg.line_height)
                                    .saturating_add(seg.line_spacing)
                        {
                            y_offset = y_offset.max(
                                col_area.y
                                    + hwpunit_to_px(
                                        seg.vertical_pos.saturating_add(seg.line_height),
                                        self.dpi,
                                    )
                                    - hwpunit_to_px(t.outer_margin_bottom as i32, self.dpi),
                            );
                        }
                    }
                }
            } else {
                let square_anchor_y = if !is_tac && tbl_is_square {
                    square_wrap_table_line_anchor_y(para, t, para_y_for_table, self.dpi)
                } else {
                    None
                };
                let visible_outer_top_px = if is_current_visible_para_float {
                    hwpunit_to_px(t.outer_margin_top as i32, self.dpi)
                } else {
                    0.0
                };
                let has_preceding_coanchored_float = is_current_visible_para_float
                    && para.controls.iter().take(control_index).any(|control| {
                        matches!(control, Control::Table(previous)
                            if is_para_topbottom_float(&previous.common))
                    });
                let profile = self.profile.get();
                let issue2439_visible_host_stack = profile.hwp5_stored_pagination_layout()
                    && page_content.column_contents.len() == 1
                    && is_current_visible_para_float
                    && signed_hwpunit(t.common.vertical_offset) > 0
                    && has_preceding_coanchored_float
                    && para
                        .controls
                        .iter()
                        .filter(|control| matches!(control, Control::Table(_)))
                        .count()
                        == 2
                    && para.line_segs.iter().any(|seg| {
                        seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0
                    });
                let table_y_start = if let Some(placement) = ctx
                    .paragraph_float_placements
                    .get(&(para_index, control_index))
                {
                    // typeset의 확정 결과에는 앵커와 바깥 여백이 이미 포함된다.
                    // legacy 호스트 높이/제목/앵커 보정을 다시 실행하지 않는다.
                    col_area.y + placement.table_top
                } else {
                    let table_y_start =
                        if let Some((_, _, _, lane_top, _, _)) = para_float_lane_info {
                            lane_top
                        } else if let Some(g) = square_reserved_above_gap {
                            // 예약 공간 상단 — 앵커(현재 흐름 y)에서 사다리 갭만큼 위.
                            (y_offset - g).max(col_area.y)
                        } else if let Some(abs_y) = paper_page_square_empty_top {
                            abs_y
                        } else if let Some((_, iy)) = inline_pos {
                            iy
                        } else if let Some(stored_host_bottom_top) =
                            native_multiline_visible_float_table_top(
                                self.profile.get().hwp5_stored_pagination_layout(),
                                para,
                                t,
                                para_y_for_table,
                                self.dpi,
                            )
                        {
                            stored_host_bottom_top
                        } else if is_current_visible_para_float {
                            let v_off =
                                hwpunit_to_px(signed_hwpunit(t.common.vertical_offset), self.dpi);
                            if self.profile.get().hwpx_stored_layout() && v_off <= 0.0 {
                                let flow_at_para_start =
                                    (table_y_before - para_y_for_table).abs() < 0.5;
                                table_y_before
                                    + if flow_at_para_start {
                                        visible_outer_top_px
                                    } else {
                                        0.0
                                    }
                                    + v_off.max(0.0)
                            } else if v_off < 0.0 {
                                para_y_for_table + visible_outer_top_px + v_off
                            } else {
                                para_y_for_table
                            }
                        } else if let Some(anchor_y) = square_anchor_y {
                            table_visual_shift = (anchor_y - y_offset).max(0.0);
                            anchor_y
                        } else if !is_tac
                            && tbl_is_square
                            && matches!(t.common.vert_rel_to, VertRelTo::Para)
                            && para_has_visible_text(para)
                            && signed_hwpunit(t.common.vertical_offset) > 0
                        {
                            // [#5566] 가시 텍스트 host 에 앵커된 어울림(Square) 표의 문단 기준
                            // 양수 세로 오프셋. 종전에는 이 형상이 어느 분기에도 안 걸려
                            // 폴백(y_offset = 앵커 줄 상단)으로 떨어져 표가 host 첫 줄 텍스트
                            // 위에 얹혔다(가로 오프셋은 tbl_inline_x 로 적용돼 세로만 소실 —
                            // 20180108093532000 8쪽, 10k 영향 64문서). 빈 host 는 위의
                            // para_float_lane 경로가, 저장 사다리 신호가 있는 우측 다줄 wrap 은
                            // square_anchor_y 가 이미 정합 처리하므로 여기 오지 않는다.
                            // 음수 오프셋은 실측이 없어 종전(무시) 동작을 유지한다.
                            para_y_for_table
                                + hwpunit_to_px(signed_hwpunit(t.common.vertical_offset), self.dpi)
                        } else if tac_detached_line_shift > 0.0 {
                            y_offset + tac_detached_line_shift
                        // The typesetter's inline placement already includes the
                        // local row origin. A saved section vpos must not replace
                        // it after the prefix has been positioned in that row.
                        } else if let Some(tail_top) = flow_placement
                            .is_none()
                            .then(|| {
                                tac_paragraph_tail_stored_line_top(
                                    self.profile.get().hwpx_stored_layout()
                                        || self.profile.get().hwp5_stored_pagination_layout(),
                                    tac_receipt_seal_line.is_some(),
                                    para,
                                    t,
                                    col_area,
                                    self.table_push_floor.get().map(|_| para_y_for_table),
                                    y_offset,
                                    self.dpi,
                                )
                            })
                            .flatten()
                        {
                            tail_top
                        } else if let Some(om_top) = square_float_outer_margin_top_hu(t)
                            .filter(|_| !para_has_visible_text(para))
                        {
                            // [#7287] **빈 host** 어울림 자리차지 표에는 전용 갈래가 없어 여기
                            // 폴백까지 떨어졌고, 그래서 위쪽 바깥여백을 아무도 내지 않았다.
                            // 저장 앵커 경로도 `compute_table_y_position` 의 절대 배치 분기도
                            // 모두 자리차지(T&B) 전용이다. 흐름 위치에서 그 여백만큼 넣는다.
                            //
                            // 가시 host 는 제외한다 — 그쪽은 host 줄의 흐름이 이미 자리를
                            // 정한다. `hwp_table_test-m.hwp` 1쪽 표(가시 host·`vOff>0`)는
                            // 정본 250.77 에 대해 251.0 으로 이미 맞고, 여백을 더하면 벗어난다.
                            y_offset + hwpunit_to_px(om_top, self.dpi)
                        } else {
                            y_offset
                        };
                    // [Issue #1535] visible-host co-anchored float 표도 문단(아래 visible_float_exclusions
                    // 소비부)과 동일하게 선행 float 표가 점유한 세로 영역을 벗어나 배치되어야 한다.
                    // 표 배치는 기존에 exclusion 을 push 만 하고 consult 하지 않아, 연속 문단의
                    // float 표가 앞 문단 float 표 위에 겹쳐 그려졌다. 표의 자연 상단
                    // (para_y + outer_margin + v_offset, = compute_table_y_position 의 raw_y)이
                    // 활성 exclusion 영역 안에서 시작하면 그 영역 하단으로 내려 시작점을 끌어올린다.
                    // compute_table_y_position 이 raw_y.max(y_start) 로 클램프하므로 table_y_start
                    // (= y_start)를 올리면 표가 해당 영역 아래로 밀린다.
                    let table_y_start = if is_para_topbottom_float(&t.common)
                        && !visible_float_exclusions.is_empty()
                    {
                        let v_off =
                            hwpunit_to_px(signed_hwpunit(t.common.vertical_offset), self.dpi);
                        // 빈-host float 은 base table_y_start(=흐름 위치)가 곧 자연 상단이고,
                        // visible host 는 para_y+outer+v_off 가 자연 상단이다. 둘 중 큰 값을
                        // 자연 상단으로 보아 선행 exclusion 밴드 안에서 시작하면 그 하단으로 내린다.
                        let natural_top = table_y_start
                            .max(para_y_for_table + visible_outer_top_px + v_off.max(0.0));
                        let mut floor = table_y_start;
                        for zone in visible_float_exclusions.iter() {
                            // Fixed textboxes use a full-height intersection probe below.
                            if zone.fixed_textbox {
                                continue;
                            }
                            if natural_top + 0.5 >= zone.top && natural_top < zone.bottom {
                                // 빈-host(text 없는) float 은 자기 offset 이 선행 exclusion 에
                                // 흡수되어 표끼리 붙는다. zone 하단 아래로 그 offset 만큼 띄워
                                // 복원한다(한컴: 표-표 간격 = 후행 표 offset). visible host 는
                                // part 3(host-title-line)이 간격을 처리하므로 여기선 zone 하단만.
                                let restore = if is_current_visible_para_float {
                                    if issue2439_visible_host_stack && zone.owner_para == para_index
                                    {
                                        // #2439: 같은 저장 host의 후행 표가 선행 표 아래로
                                        // 밀려나도 자신의 outer-top은 사라지지 않는다.
                                        visible_outer_top_px
                                    } else {
                                        0.0
                                    }
                                } else if !zone.blocks_text {
                                    // [#5929] 어울림 그림 아래 자리차지 표는 바깥 위 여백을
                                    // 유지한다(한컴: 표가 그림 바닥에 붙지 않음).
                                    visible_outer_top_px.max(v_off.max(0.0))
                                } else {
                                    v_off.max(0.0)
                                };
                                floor = floor.max(zone.bottom + restore);
                            }
                        }
                        let table_height = mt
                            .map(|measured| measured.total_height)
                            .unwrap_or_else(|| hwpunit_to_px(t.common.height as i32, self.dpi));
                        let gap = if is_current_visible_para_float {
                            0.0
                        } else {
                            v_off.max(0.0)
                        };
                        fixed_textbox_flow::table_floor(
                            visible_float_exclusions,
                            natural_top.max(floor),
                            table_height,
                            gap,
                        )
                        .map_or(floor, |fixed_floor| floor.max(fixed_floor))
                    } else {
                        table_y_start
                    };
                    // [#7203] 단 맨 위 어울림(TAC) 표는 호스트의 저장 첫 줄 `vertical_pos`
                    // 만큼 아래다. 흐름 커서가 곧 단 상단이라 그 저장값이 위 여백인데,
                    // 빈 앵커 문단은 `paragraph_layout` 을 타지 않아 Task #1811 의
                    // column-top vpos 계약을 못 받고 0 으로 뭉개졌다.
                    // typeset의 확정 줄 상자에는 이미 이 원점이 있으므로 다시 더하지 않는다.
                    let table_y_start = if is_tac
                        && inline_pos.is_none()
                        && flow_placement.is_none()
                        && self.profile.get().hwp5_stored_pagination_layout()
                        && (para_y_for_table - col_area.y).abs() < 1.0
                    {
                        let spacing_before = para_style.map(|st| st.spacing_before).unwrap_or(0.0);
                        table_y_start
                            + tac_column_top_stored_vpos_px(para, spacing_before, self.dpi)
                                .unwrap_or(0.0)
                    } else {
                        table_y_start
                    };
                    // [#6104] 자리차지(vert=Para) 표 밴드는 후속 TAC 제목 상자에도 적용돼야
                    // 한다. 문단 경로의 exclusion 소비는 FullParagraph 만 보고, TAC 표는
                    // PageItem::Table 로 따로 그려져 선행 표 데이터 행 위에 올라탔다
                    // (36483048 4쪽: 제목 상자 498.4..534.8 ↔ 표1 459.6..531.2). 이미
                    // 그린 선행 owner 밴드만 피하므로 앵커 예약 이중 계상(#4090)은 없다.
                    let table_y_start = if is_tac && !visible_float_exclusions.is_empty() {
                        let tac_h = hwpunit_to_px(t.common.height as i32, self.dpi);
                        let mut floor = table_y_start;
                        for zone in visible_float_exclusions.iter() {
                            if !zone.blocks_text || zone.owner_para >= para_index {
                                continue;
                            }
                            let starts_in_zone = floor + 0.5 >= zone.top && floor < zone.bottom;
                            let overlaps_zone =
                                tac_h > 0.0 && floor < zone.top && floor + tac_h > zone.top + 0.5;
                            if starts_in_zone || overlaps_zone {
                                floor = floor.max(zone.bottom);
                            }
                        }
                        floor
                    } else {
                        table_y_start
                    };
                    // [Issue #1549] visible-host 의 양수 offset float 표는 host 텍스트(섹션 제목)가
                    // line 0 으로 그려지는 줄 *아래*에 와야 한다(한컴: 제목 위, 표 아래). 제목과 표는
                    // 같은 문단 앵커를 공유하고 선행 float exclusion 으로 함께 같은 y 까지 밀리므로,
                    // 작은 offset 은 흡수되어 둘이 겹친다. 제목이 그려지는 위치(선행 exclusion 아래로
                    // 밀린 para 흐름) + 제목 줄높이 아래로 표를 내려 겹침을 막는다. 큰 offset 으로 표가
                    // 이미 더 아래면 max 라 영향 없다.
                    let table_y_start = if is_current_visible_para_float
                        && signed_hwpunit(t.common.vertical_offset) > 0
                    {
                        let host_line_px = para
                            .line_segs
                            .first()
                            .map(|s| hwpunit_to_px(s.line_height, self.dpi))
                            .unwrap_or(0.0);
                        // [Task #2711 v2] title_flow_y 는 선행 float exclusion 으로 이미
                        // 밀려난 `table_y_start`(위 exclusion 보정 블록의 결과)를 기준으로
                        // 삼아야 한다. 종전에는 미보정 `para_y_for_table`에서 다시 자체
                        // exclusion 루프를 돌렸는데, 이 루프의 판정 조건(오프셋/outer 미포함
                        // 원시 좌표)이 위 exclusion 보정 블록의 판정 조건과 달라 같은 zone을
                        // 못 잡는 경우가 있었다 — 그 결과 candidate(title_flow_y+host_line_px+
                        // outer)가 이미 밀려난 table_y_start보다 작게 나와 max()가 밀려난 값을
                        // 그대로 선택해 host-title 줄 예약분이 사라지고, 그 줄(예: "7. [필수]")과
                        // 표 첫 줄이 같은 y 에 겹쳐 그려졌다 (synam-001.hwp p30 "7. [필수]" 행).
                        // #2439의 같은 문단 2표 저장 형상은 host 텍스트가 두 표 뒤에서
                        // 재개되는 별도 계약이다. 이 경로까지 이미 밀린 표 좌표를 기준으로
                        // 삼으면 host 텍스트가 후행 표 위에 남으므로 기존 문단 흐름 기준을
                        // 유지하고, 일반 visible-host float에서만 실제 표 시작점을 기준으로
                        // host 한 줄을 예약한다.
                        let mut title_flow_y = if has_preceding_coanchored_float {
                            para_y_for_table
                        } else {
                            table_y_start
                        };
                        for zone in visible_float_exclusions.iter() {
                            if title_flow_y + 0.5 >= zone.top && title_flow_y < zone.bottom {
                                title_flow_y = title_flow_y.max(zone.bottom);
                            }
                        }
                        table_y_start.max(title_flow_y + host_line_px + visible_outer_top_px)
                    } else {
                        table_y_start
                    };
                    if let Some(seal_line) = tac_receipt_seal_line {
                        let line_top = table_y_start;
                        push_tac_receipt_seal_line(
                            tree,
                            col_node,
                            page_content.section_index,
                            para_index,
                            line_top,
                            col_area,
                            styles,
                            seal_line,
                        );
                        table_y_start + seal_line.shift_px
                    } else {
                        table_y_start
                    }
                };
                let allow_para_top_bleed =
                    is_current_visible_para_float && signed_hwpunit(t.common.vertical_offset) < 0;
                // 이월된 빈 RowBreak 그림 표의 stale negative picture offset은 native
                // HWP5와 original HWPX 모두 outer host의 저장 vpos가 있어야만 정확히
                // page-local top으로 정규화할 수 있다. nested/header/footer 호출은 아래
                // 인자 경로에서 계속 None으로 제한된다 (#3738).
                let outer_host_stored_vpos_hu =
                    if self.profile.get().hwp5_stored_pagination_layout()
                        || self.profile.get().hwpx_stored_layout()
                    {
                        para.line_segs
                            .iter()
                            .find(|seg| {
                                seg.tag
                                    & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY
                                    == 0
                            })
                            .map(|seg| seg.vertical_pos)
                    } else {
                        None
                    };
                let table_y_start = if is_tac && inline_pos.is_none() {
                    stored_empty_full_band_tac_table_top(para, control_index, t, col_area, self.dpi)
                        .unwrap_or(table_y_start)
                } else {
                    table_y_start
                };
                let table_child_start=col_node.children.len();
                let table_visual_end = if tac_already_rendered_inline {
                    table_y_start + table_visual_height
                } else {
                    self.layout_table(
                        tree,
                        col_node,
                        t,
                        page_content.section_index,
                        styles,
                        *outline_numbering_id,
                        col_area,
                        table_y_start,
                        bin_data_content,
                        mt,
                        0,
                        Some((para_index, control_index)),
                        alignment,
                        None,
                        effective_margin,
                        margin_right,
                        tbl_inline_x,
                        None,
                        Some(para_y_for_table + visible_outer_top_px),
                        outer_host_stored_vpos_hu,
                        allow_para_top_bleed,
                        false,
                        if physical_outer_box_paint_inset {
                            physical_outer_box_paint_inset_y
                        } else {
                            column_top_outer_box_inset_y
                        },
                        ctx.paragraph_float_placements
                            .get(&(para_index, control_index))
                            .map(|p| {
                                (
                                    p.table_left.map(|left| col_area.x + left),
                                    unresolved_placeholder_origin.unwrap_or(col_area.y + p.table_top),
                                )
                            }),
                        Self::standalone_table_char_border_fill(Some(para), t, styles),
                    )
                };
                // [#4068] 단 맨 위 테두리 보정은 표 실물만 옮긴다 — 뒤 문단은 저장 흐름이
                // 바깥 상자를 이미 계상하므로 흐름 끝에서 되돌린다(hwpspec 35·44·46쪽 다음 표가
                // 정본 그대로). 단, 같은 host 의 다른 표는 이 표 실물 아래에 쌓인다
                // (`rowbreak-problem-pages` 13쪽: 컨트롤 순서상 앞인 TAC 띠(`ci=0`)가 표(`ci=1`)
                // 뒤에 놓이고, 정본에서 표 아랫변 + 바깥 여백 아래다).
                let column_top_outer_box_inset_y = if physical_outer_box_paint_inset {
                    0.0
                } else {
                    column_top_outer_box_inset_y
                };
                let host_stacks_following_table =
                    para.controls.iter().enumerate().any(|(index, control)| {
                        index != control_index && matches!(control, Control::Table(_))
                    });
                let table_flow_end = table_visual_end
                    - physical_outer_box_paint_inset_y
                    - if host_stacks_following_table {
                        0.0
                    } else {
                        column_top_outer_box_inset_y
                    };
                let mut emitted_tables=col_node.children[table_child_start..].iter().filter(|node|matches!(&node.node_type,
                    RenderNodeType::Table(owner) if owner.section_index==Some(page_content.section_index)
                    &&owner.para_index==Some(para_index)&&owner.control_index==Some(control_index)&&owner.cell_context.is_none()));
                let emitted_border=emitted_tables.next().map(|n|[n.bbox.x,n.bbox.y,n.bbox.width,n.bbox.height]);
                let emitted_border=if emitted_tables.next().is_none(){emitted_border}else{None};
                tree.current_physical_selections.record_table(super::current_physical_selections::WholeTableSelection{
                    node:col_node.id,paragraph:para_index,control:control_index,incoming_y:table_y_before,paragraph_y:para_y_for_table,
                    selected_y:table_y_start,selected_outer_inset:if physical_outer_box_paint_inset{physical_outer_box_paint_inset_y}else{column_top_outer_box_inset_y},
                    visual_height:table_visual_height,visual_end:table_visual_end,flow_end:table_flow_end,emitted_border,
                    lane_input:para_float_lane_info.map(|(a,b,c,d,e,f)|[a,b,c,d,e,f.unwrap_or(0.0)]),
                    typed_float:ctx.paragraph_float_placements.contains_key(&(para_index,control_index)),inline:inline_pos.is_some(),treat_as_char:is_tac});
                if is_tac {
                    let marker_x = tbl_inline_x.unwrap_or(col_area.x + effective_margin);
                    tree.set_inline_shape_position(
                        page_content.section_index,
                        para_index,
                        control_index,
                        None,
                        marker_x,
                        table_y_start,
                    );
                }
                if let Some(marker_line) = tac_post_f081c_line {
                    push_tac_post_f081c_line(
                        tree,
                        col_node,
                        page_content.section_index,
                        para_index,
                        t,
                        table_y_start,
                        col_area,
                        styles,
                        marker_line,
                        self.dpi,
                    );
                }
                if is_first_empty_para_float_control && !is_tac {
                    let marker_x = tbl_inline_x.unwrap_or(col_area.x + effective_margin);
                    // FullParagraph에서 빈 줄 진행을 생략한 대신, 표와 같은 줄에
                    // host 문단부호를 렌더링한다. 표 뒤 빈 문단은 그대로 남아
                    // 아래쪽 탈출 위치를 제공한다.
                    push_empty_para_end_mark(
                        tree,
                        col_node,
                        para,
                        styles,
                        page_content.section_index,
                        para_index,
                        marker_x,
                        unresolved_placeholder_origin.unwrap_or(table_y_start + column_top_outer_box_inset_y),
                        self.dpi,
                    );
                }
                table_y_end = table_visual_end;
                // [Task #1841] 자리차지(TopAndBottom) 표 아래에서 host 본문이 재개될 때
                // 표의 바깥 여백 bottom 을 띄운다 (한글 실측: 표 하단→첫 줄 gap =
                // rhwp 10.2pt + outer_bottom 8.5pt = 한글 18.7pt, 결재문서 헤더 표
                // 852HU 계열 — 동작소방서 36385142/관악소방서 36389312).
                let visible_outer_bottom_px = if is_current_visible_para_float {
                    hwpunit_to_px(t.outer_margin_bottom as i32, self.dpi)
                } else {
                    0.0
                };
                // Native HWP5's empty 1×1 RowBreak host has a separate flow
                // box from its minimum painted cell box.  The former layout
                // branch advanced only to `table_visual_end`; a run of 1300HU
                // anchors therefore used the 21.1px padded paint height and
                // discarded the 566HU outer margins, instead of consuming the
                // declared 17.3px height plus both margins (76076 p33). Keep
                // this source contract deliberately narrower than generic
                // empty floats: Square sibling lanes and stored HWPX layout
                // have separate coordinate contracts.
                let empty_reflow_flow_end =
                    crate::renderer::float_placement::reflow_empty_table_host(para, t)
                        .then(|| {
                            ctx.paragraph_float_placements
                                .get(&(para_index, control_index))
                                .map(|placement| col_area.y + placement.occupied_bottom)
                        })
                        .flatten();
                let empty_rowbreak_flow_end = if let Some(end) = empty_reflow_flow_end {
                    // The resolved box has already consumed its outer top.
                    // Its accepted bottom also owns the host's after-space.
                    Some(end)
                } else if (self.profile.get().hwp5_stored_pagination_layout()
                    || (self.profile.get().hwpx_stored_layout()
                        && !self.profile.get().session_edited()
                        && stored_column_top_coanchored_float_box(
                            para,control_index,table_y_start,col_area.y,table_visual_height,self.dpi,
                        )))
                    && is_current_empty_para_float
                    && !is_current_empty_square_sibling_float
                    && is_para_topbottom_float(&t.common)
                    && matches!(t.page_break, TablePageBreak::RowBreak)
                    && t.row_count == 1
                    && t.col_count == 1
                    && t.cells.len() == 1
                {
                    let declared_height_px = hwpunit_to_px(t.common.height as i32, self.dpi);
                    let outer_top_px = hwpunit_to_px(t.outer_margin_top as i32, self.dpi);
                    let outer_bottom_px = hwpunit_to_px(t.outer_margin_bottom as i32, self.dpi);
                    Some(
                        (table_y_start + declared_height_px + outer_top_px + outer_bottom_px)
                            .max(table_visual_end - column_top_outer_box_inset_y + outer_bottom_px),
                    )
                } else {
                    None
                };
                y_offset = if is_current_visible_para_float {
                    let mut flow_y = if signed_hwpunit(t.common.vertical_offset) > 0 {
                        if issue2439_visible_host_stack {
                            // #2439: 저장된 두 표 visible-host 형상은 후행 표가 선행
                            // 표 아래로 밀려난 높이까지 host 흐름이 실제로 소비한다.
                            // typeset의 table_bottom + outer-bottom + LineSeg 간격과
                            // 같은 경계에서 뒤의 서명문을 시작시킨다.
                            table_visual_end
                                + visible_outer_bottom_px
                                + para_line_spacing_px(para, self.dpi)
                        } else {
                            table_y_before
                        }
                    } else if self.profile.get().hwpx_stored_layout() {
                        let following_non_positive =
                            has_following_non_positive_visible_float(para, control_index);
                        let inter_float_gap = if following_non_positive {
                            para_line_spacing_px(para, self.dpi)
                        } else {
                            0.0
                        };
                        table_visual_end + inter_float_gap + visible_outer_bottom_px
                    } else {
                        table_y_before.max(table_visual_end + visible_outer_bottom_px)
                    };
                    // [#6312] 글이 있는 host 는 위 분기가 표 밴드만 소비하고 자기
                    // 글줄(lh+ls)을 버린다. 저장 사다리가 그 줄만 증언하고, 표 **뒤**
                    // 같은 문단 텍스트가 흐름을 이미 소비하지 않을 때만 밴드 아래에
                    // 계상한다 — 표 높이는 다시 더하지 않는다(#4090). 표 **앞**
                    // pre-text 는 밴드와 별개라 이 줄을 대체하지 않는다.
                    let host_post_text_exists = {
                        let mut seen_this_table = false;
                        let mut found = false;
                        for cc in &page_content.column_contents {
                            for item in &cc.items {
                                match item {
                                    PageItem::Table {
                                        para_index: item_para,
                                        control_index: item_ctrl,
                                    } if *item_para == para_index
                                        && *item_ctrl == control_index =>
                                    {
                                        seen_this_table = true;
                                    }
                                    PageItem::PartialParagraph {
                                        para_index: item_para,
                                        ..
                                    }
                                    | PageItem::FullParagraph {
                                        para_index: item_para,
                                    } if *item_para == para_index && seen_this_table => {
                                        found = true;
                                    }
                                    _ => {}
                                }
                            }
                        }
                        found
                    };
                    if !host_post_text_exists {
                        if let Some(line_advance) = stored_visible_anchor_band_host_line_advance_hu(
                            self.profile.get().hwp5_stored_pagination_layout()
                                || self.profile.get().hwpx_stored_layout(),
                            para,
                            control_index,
                            paragraphs.get(para_index + 1),
                        ) {
                            flow_y += hwpunit_to_px(line_advance, self.dpi);
                        }
                    }
                    flow_y
                } else if paper_page_square_empty_top.is_some() {
                    table_y_before
                } else if table_visual_shift > 0.0 {
                    (table_visual_end - table_visual_shift).max(table_y_before)
                } else if {
                    // [#4533 HWP3] 비-tac TopAndBottom float 인데 저장 사다리가
                    // 표를 예약하지 않은 서식 문서(하동군 21918361: host lh
                    // 13.3px·다음 문단 델타 21.3px vs 표 730px) — typeset 의
                    // 동일 판별자(hwp3_topbottom_no_reserve)와 짝을 이뤄 흐름을
                    // 전진시키지 않는다. 표는 그 자리에 그려지고 후속 텍스트가
                    // 겹치는 것이 한글의 정본.
                    let host_lh_px = para
                        .line_segs
                        .iter()
                        .find(|s| s.tag & 0x8000_0000 == 0)
                        .map(|s| hwpunit_to_px(s.line_height, self.dpi));
                    let next_gap_px = paragraphs
                        .get(para_index + 1)
                        .and_then(|np| np.line_segs.first())
                        .zip(para.line_segs.first())
                        .filter(|(ns, hs)| ns.vertical_pos > hs.vertical_pos)
                        .map(|(ns, hs)| hwpunit_to_px(ns.vertical_pos - hs.vertical_pos, self.dpi));
                    let tot = table_visual_end - table_y_before;
                    (self.profile.get().hwp3_native_layout()
                        || (self.profile.get().hwp3_layout()
                            && self.profile.get().hwpx_container()))
                        && !t.common.treat_as_char
                        && matches!(
                            t.common.text_wrap,
                            crate::model::shape::TextWrap::TopAndBottom
                        )
                        && tot > 1.0
                        && host_lh_px.is_some_and(|lh| lh < tot * 0.25)
                        && next_gap_px.is_some_and(|g| g < tot * 0.25)
                } {
                    table_y_before
                } else if square_reserved_above_gap.is_some() {
                    // [#4533 ⑥] 표는 예약 공간(앵커 위)에 이미 놓였다 — 흐름은
                    // 전진하지 않는다(앵커·후속 문단이 사다리 위치 유지).
                    table_y_before
                } else if crate::renderer::float_placement::square_successor_starts_beside_table(
                    para,
                    paragraphs
                        .get(para_index + 1)
                        .and_then(crate::renderer::float_placement::stored_line_lane_probe),
                    t,
                ) {
                    // [#7548] 어울림 표는 흐름을 표 하단까지 밀지 않는다. 다음 문단의
                    // 저장 첫 줄이 표 옆 차선에 놓여 있으면 한/글은 그 줄을 표 띠 옆에
                    // 그린다. 커서는 host 본문 끝(아래 #1218 보정)에서 이어진다.
                    table_y_before
                } else {
                    empty_rowbreak_flow_end.unwrap_or(table_flow_end)
                };
                let signed_vertical_offset = signed_hwpunit(t.common.vertical_offset);
                let zero_offset_has_following_coanchored_float = signed_vertical_offset == 0
                    && para.controls.iter().skip(control_index + 1).any(|control| {
                        matches!(control, Control::Table(following)
                            if is_para_topbottom_float(&following.common))
                    });
                if is_current_visible_para_float
                    && (signed_vertical_offset > 0 || zero_offset_has_following_coanchored_float)
                    && table_visual_height > 0.0
                {
                    let table_visual_top = table_visual_end - table_visual_height;
                    if table_visual_end > table_visual_top + 0.5 {
                        // [#2439] offset=0 인 첫 co-anchored 표도 후행 float 가 있으면
                        // exclusion 을 남겨야 한다. 그렇지 않으면 후행 양수-offset 표의
                        // 자연 상단이 첫 표 안에 있어도 #1535 충돌 회피가 보지 못해 두
                        // 표가 겹친다. 단독 zero-offset 표는 기존 flow 누적만 유지한다.
                        // exclusion 하단을 표의 outer_margin_bottom 만큼 늘려, 다음 섹션
                        // 제목(이 zone 을 consult)이 표 아래로 그 여백만큼 띄워지게 한다
                        // (한컴: 섹션 표와 다음 섹션 제목 사이 간격 = 표 아래 외곽여백).
                        let margin_bottom_px =
                            hwpunit_to_px(t.outer_margin_bottom as i32, self.dpi);
                        let host_line_spacing_px = if issue2439_visible_host_stack {
                            // 마지막 co-anchored 표 뒤의 host 서명문은 표 하단 여백과
                            // 저장 LineSeg 간격을 모두 지난 뒤 시작한다. exclusion에
                            // 포함해 뒤의 post-text 흐름과 typeset을 같은 경계로 맞춘다.
                            para_line_spacing_px(para, self.dpi)
                        } else {
                            0.0
                        };
                        let placement = ctx
                            .paragraph_float_placements
                            .get(&(para_index, control_index));
                        visible_float_exclusions.push(VisibleFloatExclusion {
                            fixed_textbox: false,
                            top: placement.map_or(table_visual_top, |p| col_area.y + p.table_top),
                            bottom: placement.map_or(
                                table_visual_end + margin_bottom_px + host_line_spacing_px,
                                |p| col_area.y + p.occupied_bottom,
                            ),
                            owner_para: para_index,
                            blocks_text: true,
                        });
                    }
                }
            }
            // [Task #1046 Stage 3 Class B] 표 실제 콘텐츠 하단 기록 — 이후 더해지는
            // 표 뒤 trailing 간격(tac 줄간격/표 아래 간격)을 제외한 값. overflow 검출이
            // 페이지 바닥의 후행 간격을 콘텐츠 초과로 오판하지 않도록 한다.
            self.last_item_content_bottom.set(table_y_end);
            // [Task #1046 Stage 3 Class B 진단] 통째 표 렌더 분해 — 표 시작/끝,
            // para 시작, host before. 동작 불변(게이트).
            if std::env::var("RHWP_TABLE_DRIFT").is_ok() {
                eprintln!(
                    "WHOLE_TABLE_Y: pi={} sec={} tac={} table_y_start={:.1} table_y_end={:.1} table_h={:.1} para_y={:.1} table_y_before={:.1}",
                    para_index, page_content.section_index, is_tac,
                    if let Some((_, iy)) = inline_pos { iy } else { table_y_before },
                    table_y_end,
                    table_y_end - (if let Some((_, iy)) = inline_pos { iy } else { table_y_before }),
                    para_y_for_table, table_y_before,
                );
            }
            // 저장 줄 계획의 pen/advance는 typeset과 동일하다. 표 하단에서 gap을
            // 다시 추측하거나 위아래 여백을 후가산하지 않는다.
            if let Some(end) = flow_placement.and_then(|placement| placement.advance_end) {
                return TableControlOut {
                    y_offset: col_area.y + end,
                    tac_seg_applied: true,
                    para_float_lane_info,
                    early_return: Some((col_area.y + end, true)),
                };
            }
            // ── TAC 표: 줄간격 처리 ──
            // layout_table 반환값(표 하단)에 line_spacing을 더하여 다음 표 시작 y 결정
            if is_tac {
                // [#4531] control_index 를 seg 인덱스로 그대로 쓰면 비가시 컨트롤
                // (secd/cold/책갈피)이 낀 문단에서 어긋난다('hwpdf cycle#3' 폴백이
                // 알던 그 함정 — 규제영향분석서 코호트의 근인). 컨트롤의 텍스트 위치를
                // seg.text_start 경계(char_offsets 로 같은 좌표계 환산)에 사영해 실제
                // 줄 seg 를 찾는다. 해석 불가 시 기존 값 유지.
                // HWPX 계산-lineseg 는 저장 사다리가 아니라 이 사영이 성립하지 않는다
                // — hwp5 네이티브 프로파일에서만 교정한다(56734607.hwpx 신규 회귀 실측).
                let seg_idx = if self.profile.get().hwp5_stored_pagination_layout() {
                    control_line_seg_index(para, control_index).unwrap_or(control_index)
                } else {
                    control_index
                };
                let tac_count_total = para
                    .controls
                    .iter()
                    .filter(|c| matches!(c, Control::Table(t) if t.common.treat_as_char))
                    .count();
                let tac_idx_current = para
                    .controls
                    .iter()
                    .take(control_index + 1)
                    .filter(|c| matches!(c, Control::Table(t) if t.common.treat_as_char))
                    .count();
                // TAC 표 사이에 non-TAC 표가 있는지 확인
                let has_non_tac_between = para
                    .controls
                    .iter()
                    .skip(control_index + 1)
                    .take_while(|c| !matches!(c, Control::Table(t) if t.common.treat_as_char))
                    .any(|c| matches!(c, Control::Table(t) if !t.common.treat_as_char));
                if tac_idx_current < tac_count_total && !has_non_tac_between {
                    // 다음 TAC가 있으면: vpos 차이분만 추가 (= line_spacing)
                    // 이후 tac_seg_applied 경로의 line_spacing 추가를 스킵하기 위해
                    // 여기서 직접 return (spacing_after/line_spacing 이중 적용 방지)
                    if let (Some(seg), Some(next_seg)) =
                        (para.line_segs.get(seg_idx), para.line_segs.get(seg_idx + 1))
                    {
                        let gap = next_seg
                            .vertical_pos
                            .saturating_sub(seg.vertical_pos.saturating_add(seg.line_height));
                        y_offset += hwpunit_to_px(gap, self.dpi);
                    }
                    return TableControlOut {
                        y_offset,
                        tac_seg_applied,
                        para_float_lane_info,
                        early_return: Some((y_offset, true)),
                    };
                } else {
                    // 마지막 TAC: line_end 보정 (vpos 기반)
                    // 표 실제 하단을 상한으로 clamp (ls는 이후 TAC seg handling에서 추가)
                    if let Some(seg) = para.line_segs.get(seg_idx) {
                        let line_end = para_y_for_table
                            + hwpunit_to_px(seg.vertical_pos + seg.line_height, self.dpi);
                        // 글앞/글뒤(overlay) + tac 표: 표 시각은 종이층 절대 배치라
                        // table_y_end 가 흐름을 따라오지 않는다. tac 는 앵커 줄에 통합되고
                        // (#539) 한글도 그 줄 높이만큼 전진한다(148720174 2쪽 사다리:
                        // 표 43940 + th 7348 + gap 400 = 다음 문단 51688 실측). clamp 와
                        // max_correction 이 이 전진을 막아 후속 문단이 표 위로 91px
                        // 겹치던 결함 — overlay tac 는 앵커 줄 top + 저장 줄 높이로 전진한다
                        // (line_end 의 seg.vertical_pos 는 누적 vpos 라 여기선 못 쓴다).
                        let overlay_tac = matches!(
                            t.common.text_wrap,
                            crate::model::shape::TextWrap::InFrontOfText
                                | crate::model::shape::TextWrap::BehindText
                        );
                        if overlay_tac {
                            // 저장 lh(th)는 **외곽여백 상·하를 이미 포함**한다(#521 정의
                            // lh = om_top + cell_h + om_bottom; 민간위탁 실측 13045 =
                            // 285 + 12480 + 280). 흐름에는 om_top 이 선가산되고 #521 이
                            // om_bottom 을 후가산하므로 그대로 두면 표당 om 상하합만큼
                            // 밀린다(#4531 코호트 ① +7.6px/표 실측). 기준을 선가산 전
                            // (para_y)으로 되돌리고 om_bottom 을 선공제해 순전진을
                            // **sb + th + ls** 로 맞춘다 — 사다리 vpos 는 다음 문단의
                            // sb 까지 포함하므로 호스트 문단의 sb 는 살려야 한다
                            // (1차 시도에서 base 롤백이 sb 까지 지워 규제영향분석서
                            // 코호트가 반증: 심의소위 실측 33210 = th 30250 + gap 960
                            // + host sb 2000). 다중 seg 호스트(표 앞 자기 줄 보유)는
                            // para_y 가 앵커 줄 top 이 아니므로 기존 기준을 유지한다.
                            let om_px = hwpunit_to_px(t.outer_margin_bottom as i32, self.dpi);
                            let ls_px = hwpunit_to_px(seg.line_spacing.max(0), self.dpi);
                            // **사다리-국소 판별자**: sb 를 사다리가 품는지(심의소위) 안
                            // 품는지(민간위탁 p6)는 같은 문서 안에서도 갈린다 — 스타일로
                            // 추정하지 않고, 다음 문단 저장 vpos 와의 델타에서 "다음
                            // 문단이 스스로 더할 style-sb"와 이 분기 뒤의 사후가산
                            // (ls·om_bottom)만 빼서 목표를 구성한다. 구성상 다음 줄
                            // top == 호스트 줄 top + 사다리 델타가 되어 관습과 무관하게
                            // 정확하다. 되돌아감·값 부재는 th 기반 기본식으로 폴백.
                            let ladder_target =
                                if !self.profile.get().hwp5_stored_pagination_layout() {
                                    None
                                } else {
                                    paragraphs
                                        .get(para_index + 1)
                                        .and_then(|np| np.line_segs.first().map(|ns| (np, ns)))
                                        .filter(|(_, ns)| {
                                            ns.vertical_pos > seg.vertical_pos
                                                && ns.vertical_pos - seg.vertical_pos
                                                    < seg.line_height.saturating_mul(4).max(160_000)
                                        })
                                        .map(|(np, ns)| {
                                            let next_sb = styles
                                                .para_styles
                                                .get(np.para_shape_id as usize)
                                                .map(|ps| ps.spacing_before.max(0.0))
                                                .unwrap_or(0.0);
                                            let om_top_px =
                                                hwpunit_to_px(t.outer_margin_top as i32, self.dpi);
                                            tac_table_y_before - om_top_px.max(0.0)
                                                + hwpunit_to_px(
                                                    ns.vertical_pos - seg.vertical_pos,
                                                    self.dpi,
                                                )
                                                - next_sb
                                                - ls_px
                                                - om_px.max(0.0)
                                        })
                                };
                            if let Some(target) = ladder_target {
                                // 사다리 신뢰 시 방향 무관 직접 설정 — 표 시각 전진이
                                // 사다리보다 컸던 것이 바로 결함이므로 상향 가드를 두면
                                // 교정이 무력화된다(민간위탁 실측).
                                y_offset = target;
                            } else {
                                let base = if para.line_segs.len() == 1 {
                                    para_y_for_table
                                } else {
                                    tac_table_y_before
                                };
                                let anchor_line_end = base
                                    + hwpunit_to_px(seg.line_height, self.dpi)
                                    - om_px.max(0.0);
                                if anchor_line_end > y_offset {
                                    y_offset = anchor_line_end;
                                }
                            }
                        } else {
                            let clamped = line_end.min(table_y_end);
                            let max_correction =
                                hwpunit_to_px(seg.line_spacing * 2 + 1000, self.dpi);
                            if clamped > y_offset && (clamped - y_offset) <= max_correction {
                                y_offset = clamped;
                            }
                            // [#4533 HWP3] 서식 코호트(영월군 20099369·채권조서
                            // 20117321 등 5+건): 저장 앵커 lh(1000u)가 표(397px)를
                            // 안 품는 tac 표에서 typeset 은 저장 스텝(#2373)을
                            // 따르는데 layout 만 렌더 표높이로 전진해 조판·렌더가
                            // 갈라진다 — 영월군 실측 typeset diff 0.0 vs layout
                            // +388, 후속 38줄이 typeset 예산 밖(쪽 밖)으로. 저장
                            // 델타가 정상이고 발산 >2px 면 사다리 스텝으로 맞춘다.
                            // HWP5 는 같은 식이 2중 반증(여가부·규제영향분석서
                            // 코호트 — 한글이 문서별 반대 진실)이라 HWP3 계보
                            // (직파싱 + 변환본 — 왕복 등식 유지) 한정. ls 는 이후 TAC seg handling 이 후가산하므로
                            // 선공제한다.
                            // 변환본(HWP3→HWPX/HWP5, /RhwpHwp3Origin 마커 =
                            // hwp3_layout)도 같은 스텝을 밟아야 render-diff 왕복
                            // 등식이 성립한다(hwp3-sample p7 14.9px OVER 실측).
                            // 자기일관 변환본(1892 계열)은 발산 0 이라 무동작.
                            if self.profile.get().hwp3_native_layout()
                                || self.profile.get().hwp3_layout()
                            {
                                if let Some((np, ns)) = paragraphs
                                    .get(para_index + 1)
                                    .and_then(|np| np.line_segs.first().map(|ns| (np, ns)))
                                    .filter(|(_, ns)| {
                                        ns.vertical_pos > seg.vertical_pos
                                            && ns.vertical_pos - seg.vertical_pos
                                                < seg.line_height.saturating_mul(4).max(160_000)
                                    })
                                {
                                    let ls_px = hwpunit_to_px(seg.line_spacing.max(0), self.dpi);
                                    // 다음 문단이 스스로 더할 style-sb 는 사다리
                                    // 델타에 이미 들어 있으므로 선공제한다(채택된
                                    // ③식과 동일 구성 — 누락 시 서식27 계열이
                                    // +15~19px 잔여로 신규 2건 발생 실측).
                                    let next_sb = styles
                                        .para_styles
                                        .get(np.para_shape_id as usize)
                                        .map(|ps| ps.spacing_before.max(0.0))
                                        .unwrap_or(0.0);
                                    let target = tac_table_y_before
                                        + hwpunit_to_px(
                                            ns.vertical_pos - seg.vertical_pos,
                                            self.dpi,
                                        )
                                        - ls_px
                                        - next_sb;
                                    if (y_offset - target).abs() > 2.0 {
                                        y_offset = target;
                                    }
                                }
                            }
                        }
                    }
                }
                tac_seg_applied = true;
            }
            // ── 어울림 문단 렌더링 ──
            // 후속 wrap 문단이 없어도 호스트 본문이 표 옆에 wrap되어야 하므로
            // wrap_around_paras 비어 있어도 호출 (Task #295: pi=27 자가 wrap 누락 수정)
            let split_host_text_owned_by_fragments = page_content.column_contents.iter().any(|column| {
                column.items.iter().any(|item| {
                    matches!(item, PageItem::PartialParagraph { para_index: owner, start_line, end_line }
                        if *owner == para_index
                            && explicitly_split_stored_square_host(para, *start_line, *end_line))
                })
            });
            let table_is_square =
                matches!(t.common.text_wrap, crate::model::shape::TextWrap::Square);
            if !is_tac && table_is_square {
                // 저장 줄이 없는 host 는 첫 줄 cs/sw 가 없어 띠 폭이 0 이 된다 —
                // 표 기하로 띠를 도출한다(typeset 흐름 전진과 같은 helper).
                let no_lineseg_band = crate::renderer::no_lineseg_square_table_host_band(
                    para,
                    px_to_hwpunit(col_area.width, self.dpi),
                );
                let (wrap_cs, wrap_sw) = no_lineseg_band.unwrap_or_else(|| {
                    para.line_segs
                        .first()
                        .map_or((0, 0), |s| (s.column_start, s.segment_width))
                });
                // 저장 줄도 띠도 없으면 host 글자는 표 아래 post-text 로 그린다(위 PartialParagraph).
                let paint_host_text_in_band = no_lineseg_band.is_some()
                    || para.line_segs.iter().any(|seg| {
                        seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0
                    });
                let wrap_text_x = col_area.x + hwpunit_to_px(wrap_cs, self.dpi);
                let wrap_text_width = hwpunit_to_px(wrap_sw, self.dpi);
                // [Task #1745] 텍스트 혼합 anchor: 후속 어울림 문단 띠는 표 geometry 로.
                //
                // [#3820 Stage 72] 빈 host의 우측 Square 표는 host LINE_SEG가 전폭인
                // 반면 다음 문단이 표 왼쪽 띠를 저장한다. typeset은 이미 같은 helper로
                // 해당 문단을 WrapAroundPara로 흡수하므로, layout도 동일한 strip을 써야
                // 한다. 여기서 host의 전폭을 fallback으로 쓰면 prefix가 표 옆이 아닌
                // 전폭 compose 경로에 남아 paint되지 않는다(issue4090 p5/p7/p15/p17).
                let strip = crate::renderer::text_anchor_square_table_strip(para)
                    .or_else(|| {
                        crate::renderer::empty_host_square_table_left_strip(
                            para,
                            px_to_hwpunit(col_area.width, self.dpi),
                        )
                    })
                    .or(no_lineseg_band);
                let (strip_x, strip_width) = strip
                    .map(|(cs, sw)| {
                        (
                            col_area.x + hwpunit_to_px(cs, self.dpi),
                            hwpunit_to_px(sw, self.dpi),
                        )
                    })
                    .unwrap_or((wrap_text_x, wrap_text_width));
                // Task #463: 인라인 floating 표 우측 x 계산 (paragraph border box 확장용).
                // table_layout::compute_table_x_position 와 동일 공식.
                let tbl_x_right = compute_square_wrap_tbl_x_right(t, col_area, self.dpi);
                let host_plan = ctx
                    .inline_flow_plans
                    .get(&para_index)
                    .filter(|plan| plan.square_host_control == Some(control_index));
                if let Some(plan) = host_plan {
                    self.layout_inline_flow_plan(
                        tree,
                        col_node,
                        para,
                        styles,
                        col_area,
                        page_content.section_index,
                        para_index,
                        bin_data_content,
                        measured_tables,
                        plan,
                    );
                    // A Square object owns an exclusion, while this cursor
                    // follows the shared host text rows, including successors
                    // that can continue beside the object.
                    y_offset = col_area.y + plan.end;
                }
                self.layout_wrap_around_paras(
                    tree,
                    col_node,
                    paragraphs,
                    composed,
                    styles,
                    col_area,
                    page_content.section_index,
                    para_index,
                    wrap_around_paras,
                    table_y_before,
                    y_offset,
                    wrap_text_x,
                    wrap_text_width,
                    strip_x,
                    strip_width,
                    host_plan.is_none()
                        && !split_host_text_owned_by_fragments
                        && paint_host_text_in_band,
                    0.0,
                    bin_data_content,
                    Some(tbl_x_right),
                );
                // [#1218] 어울림(Square) 호스트 본문이 표보다 길면 커서를 본문 하단까지
                // 전진시킨다. 그렇지 않으면 다음 단락이 표 하단(=현재 y_offset)에서 시작해
                // 표보다 아래로 내려온 본문 줄과 겹친다(3-09월_교육_통합_2023 4쪽 문26).
                // 본문 ≤ 표 인 기존 다수 케이스는 host_text_bottom ≤ y_offset 이라 불변.
                if let Some(comp) = composed
                    .get(para_index)
                    .filter(|_| host_plan.is_none() && !split_host_text_owned_by_fragments)
                {
                    let mut text_h = 0.0;
                    let mut last_ls = 0.0;
                    for line in &comp.lines {
                        let lh = hwpunit_to_px(line.line_height, self.dpi);
                        let ls = hwpunit_to_px(line.line_spacing, self.dpi);
                        text_h += lh + ls;
                        last_ls = ls;
                    }
                    // 마지막 줄의 trailing line_spacing 은 본문 하단에서 제외(height_for_fit 정합).
                    let host_text_bottom = table_y_before + (text_h - last_ls).max(0.0);
                    if host_text_bottom > y_offset {
                        y_offset = host_text_bottom;
                    }
                }
                // [#6128] host 뿐 아니라 **뒤따르는 어울림 문단**도 표보다 아래까지
                // 내려올 수 있다. 그 문단들은 저장 vpos 로 배치되는데(아래 띠 경로),
                // 흐름은 표 바닥에서 멈춰 다음 일반 문단이 그 줄 위에 겹쳐 그려졌다
                // (156653004 4쪽: "산·학·관 관계자 400명 내외*" 둘째 줄 위에
                // "* 대통령실 …"). 조판(typeset)은 같은 계약을
                // `extend_square_band_to_source_bottom` 으로 이미 갖고 있다 —
                // 페인트도 같은 저장 좌표로 흐름을 끌어올린다.
                if let Some(wrap_bottom) = Self::square_wrap_paras_source_bottom(
                    paragraphs,
                    wrap_around_paras,
                    para_index,
                    self.dpi,
                ) {
                    let wrap_text_bottom = table_y_before + wrap_bottom;
                    if wrap_text_bottom > y_offset {
                        y_offset = wrap_text_bottom;
                    }
                }
            }
        }
        // [#5701] 자리차지(TopAndBottom) 표 host 의 저장 사다리가 문단 **내부**
        // 에서 되감기면(법무부 연구용역보고서 p76 pi485: 63298→21050 — 한글이
        // 표 뒤에서 쪽을 끊은 흔적) vpos-델타 기반 흐름 전진이 0 으로 붕괴해,
        // 표가 430px 를 페인트하고도 y 가 쪽 상단에 남아 후속 문단(pi486)이
        // 표 위에 겹쳐 그려진다(r=1.00 이중 페인트). 페인트된 콘텐츠 하단을
        // 흐름 하한으로 삼는다 — 되감긴 host 한정이라 정상 자리차지 표의
        // 전진 회계는 불변이다.
        if matches!(
            para.controls.get(control_index),
            Some(Control::Table(tbl))
                if !tbl.common.treat_as_char
                    && matches!(
                        tbl.common.text_wrap,
                        crate::model::shape::TextWrap::TopAndBottom
                    )
        ) && para
            .line_segs
            .iter()
            .filter(|s| s.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0)
            .map(|s| s.vertical_pos)
            .collect::<Vec<_>>()
            .windows(2)
            .any(|w| w[1] < w[0] && w[0] > 5000)
        {
            let painted_bottom = self.last_item_content_bottom.get();
            if painted_bottom.is_finite() && painted_bottom > y_offset {
                y_offset = painted_bottom;
            }
        }
        if std::env::var("RHWP_DIAG_5701").is_ok() {
            eprintln!(
                "DIAG5701_TBL_EXIT pi={} y_out={:.1} content_bottom={:.1}",
                para_index,
                y_offset,
                self.last_item_content_bottom.get(),
            );
        }
        TableControlOut {
            y_offset,
            tac_seg_applied,
            para_float_lane_info,
            early_return: None,
        }
    }

    /// Table PageItem 레이아웃 (layout_column_item에서 분리)
    #[allow(clippy::too_many_arguments)]
    fn layout_table_item(
        &self,
        tree: &mut PageLayoutContext,
        col_node: &mut RenderNode,
        paper_images: &mut Vec<RenderNode>,
        para_start_y: &mut std::collections::HashMap<usize, f64>,
        para_float_lanes: &mut ParaFloatLanes,
        visible_float_exclusions: &mut Vec<VisibleFloatExclusion>,
        para_index: usize,
        control_index: usize,
        ctx: &ColumnItemCtx,
        mut y_offset: f64,
    ) -> (f64, bool) {
        let ColumnItemCtx {
            page_content,
            paragraphs,
            composed,
            styles,
            bin_data_content,
            measured_tables,
            layout,
            col_area,
            outline_numbering_id,
            multi_col_width,
            prev_tac_seg_applied,
            wrap_around_paras,
            wrap_anchors,
            ..
        } = ctx;
        // 표 앵커 문단의 y 위치 등록
        // TAC 표: 이전 TAC가 y_offset을 진행시킨 경우 갱신 (같은 문단 TAC+블록 구조)
        // 비-TAC 표: 문단 시작 y를 유지 (각 표가 독립적으로 vert offset 기준 배치)
        let is_current_tac = paragraphs
            .get(para_index)
            .and_then(|p| p.controls.get(control_index))
            .map(|c| matches!(c, Control::Table(t) if t.common.treat_as_char))
            .unwrap_or(false);
        let is_current_empty_square_sibling_float = paragraphs
            .get(para_index)
            .is_some_and(para_is_empty_square_sibling_table_anchor);
        let tac_line_fits_above_offset_float = paragraphs
            .get(para_index)
            .is_some_and(|para| host_line_fits_above_offset_float(para, control_index, self.dpi));
        let deferred_empty_float_anchor_y = paragraphs.get(para_index).and_then(|host| {
            host.controls
                .get(control_index)
                .and_then(|control| match control {
                    Control::Table(table)
                        if paragraphs.get(para_index + 1).is_some_and(|following| {
                            empty_offset_float_deferred_text_ladder_hu(host, table, following)
                                .is_some()
                        }) =>
                    {
                        host.line_segs
                            .iter()
                            .find(|seg| {
                                seg.tag
                                    & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY
                                    == 0
                            })
                            .map(|seg| col_area.y + hwpunit_to_px(seg.vertical_pos, self.dpi))
                    }
                    _ => None,
                })
        });
        // #7333: 글앞 장식 도형 뒤의 TAC 화면표는 도형이 붙은 첫 저장 줄이 아니라
        // 표 제어문자가 놓인 줄의 `vpos`에서 시작한다. 앞선 글앞 도형은 첫 저장 줄을
        // 기준으로 별도 배치하므로 문단 원점(`para_start_y`)은 그대로 두고 표만
        // 소유 줄로 내린다. 표 줄이 실제 table frame을 품는 경우에만 채택해 #4622의
        // 가시 개체 이중 가산 반증을 피한다.
        let tac_in_front_decoration_line_shift = paragraphs.get(para_index).and_then(|para| {
            let Control::Table(table) = para.controls.get(control_index)? else {
                return None;
            };
            if !self.profile.get().hwp5_stored_pagination_layout()
                || !table.common.treat_as_char
                || !tac_has_only_in_front_decoration_shapes_before(para, control_index)
            {
                return None;
            }
            let first = para.line_segs.first()?;
            let owned = para
                .line_segs
                .get(control_line_seg_index(para, control_index)?)?;
            if owned.line_height < signed_hwpunit(table.common.height) {
                return None;
            }
            let delta_hu = owned
                .vertical_pos
                .saturating_sub(first.vertical_pos)
                .saturating_sub(table.outer_margin_top as i32);
            (delta_hu > 0).then(|| hwpunit_to_px(delta_hu as i32, self.dpi))
        });
        let y_offset_before_tac_in_front_decoration_shift = y_offset;
        if let Some(shift) = tac_in_front_decoration_line_shift {
            y_offset += shift;
        }
        if let Some(anchor_y) = deferred_empty_float_anchor_y {
            // typeset가 다음 계산 본문을 표보다 먼저 배치해도 표는 host의 저장 anchor에
            // 남겨야 한다. 그렇지 않으면 표까지 본문 높이만큼 함께 아래로 이동한다.
            para_start_y.insert(para_index, anchor_y);
        } else if let Some(existing_y) = para_start_y.get(&para_index) {
            // A preceding host fragment owns the paragraph origin; advancing
            // the table cursor does not create a new origin for its later row.
            if tac_in_front_decoration_line_shift.is_none()
                && is_current_tac
                && self.table_push_floor.get().is_none()
                && y_offset > *existing_y + 1.0
                && !tac_line_fits_above_offset_float
            {
                para_start_y.insert(para_index, y_offset);
            }
        } else {
            para_start_y.insert(
                para_index,
                tac_in_front_decoration_line_shift
                    .map(|_| y_offset_before_tac_in_front_decoration_shift)
                    .unwrap_or(y_offset),
            );
        }
        let mut para_y_for_table = *para_start_y.get(&para_index).unwrap_or(&y_offset);
        if let Some(shift) = tac_in_front_decoration_line_shift {
            para_y_for_table += shift;
        }
        if let Some(para) = paragraphs.get(para_index) {
            let is_tac = para
                .controls
                .get(control_index)
                .map(|c| matches!(c, Control::Table(t) if t.common.treat_as_char))
                .unwrap_or(false);
            let is_current_empty_topbottom_float = para
                .controls
                .get(control_index)
                .map(|c| {
                    matches!(
                        c,
                        Control::Table(t)
                            if is_para_topbottom_float(&t.common) && !para_has_visible_text(para)
                    )
                })
                .unwrap_or(false);
            // Empty Para-relative Square sibling 표도 같은 높이를 공유하는 부동 lane이지만,
            // 일반 TopAndBottom empty anchor와는 저장 좌표 해석이 다르다. 아래 lane
            // 경로에는 함께 넣고 raw top/flow bottom에서만 별도로 처리한다.
            let is_current_empty_para_float =
                is_current_empty_topbottom_float || is_current_empty_square_sibling_float;
            // [#6032] 직전 쪽 말미 anchor 의 표가 이 쪽으로 흘러넘친 뒤의 빈-host
            // 자리차지 anchor 는 저장 vpos 로 되감긴다. 흐름이 저장 anchor 보다 소폭
            // 아래로 표류했으면 원천(para_y/y_offset)에서 되감아야 lane·exclusion·
            // layout_table 이 파생하는 좌표가 전부 함께 정렬된다.
            let mut rewind_anchor_snapped = false;
            if is_current_empty_topbottom_float && !is_current_empty_square_sibling_float {
                if let Some(Control::Table(t)) = para.controls.get(control_index) {
                    if let Some(saved_para_y) = native_empty_topbottom_rewind_anchor_saved_para_y(
                        self.profile.get().hwp5_stored_pagination_layout(),
                        para_index
                            .checked_sub(1)
                            .and_then(|prev_index| paragraphs.get(prev_index)),
                        para,
                        paragraphs.get(para_index + 1),
                        t,
                        para_y_for_table,
                        col_area,
                        self.dpi,
                    ) {
                        y_offset -= para_y_for_table - saved_para_y;
                        para_y_for_table = saved_para_y;
                        para_start_y.insert(para_index, saved_para_y);
                        rewind_anchor_snapped = true;
                    }
                }
            }
            // [#6879] float 의 세로 기준점은 문단 상단이 아니라 **앵커 줄**(그 개체의
            // 제어 문자가 실린 저장 줄)이다. 앞선 TAC 형제가 첫 줄을 차지한 문단에서
            // 이것을 안 옮기면 float 이 그 줄 위로 올라가 겹친다 (156767332 pi=73:
            // 라벨 98.2..138.4 vs float 128.0). 앵커가 첫 줄이면 0 이라 종전과 같다.
            if let Some(placement) = ctx
                .paragraph_float_placements
                .get(&(para_index, control_index))
            {
                para_y_for_table = col_area.y + placement.anchor_y;
            } else if let Some(Control::Table(t)) = para.controls.get(control_index) {
                let anchor_offset =
                    tac_sibling_float_anchor_offset_px(para, t, control_index, self.dpi);
                if anchor_offset > 0.0 {
                    para_y_for_table += anchor_offset;
                }
            }
            let is_current_visible_para_float = para
                .controls
                .get(control_index)
                .map(|c| {
                    matches!(
                        c,
                        Control::Table(t)
                            if is_para_topbottom_float(&t.common)
                                && para_has_non_whitespace_text(para)
                    )
                })
                .unwrap_or(false);
            self.para_float_host_has_text
                .set(is_current_visible_para_float);
            let is_first_empty_para_float_control = is_current_empty_para_float
                && para.controls.iter().position(|c| {
                    matches!(
                        c,
                        Control::Table(t)
                            if (is_para_topbottom_float(&t.common)
                                || (!t.common.treat_as_char
                                    && matches!(t.common.text_wrap, TextWrap::Square)
                                    && matches!(t.common.vert_rel_to, VertRelTo::Para)))
                                && !para_has_visible_text(para)
                    )
                }) == Some(control_index);
            let relocated_next_flow_top =
                para.controls
                    .get(control_index)
                    .and_then(|control| match control {
                        Control::Table(table) => {
                            stored_layout_relocated_empty_rowbreak_picture_next_flow_top(
                                self.profile.get().hwp5_stored_pagination_layout()
                                    || self.profile.get().hwpx_stored_layout(),
                                para,
                                table,
                                paragraphs.get(para_index + 1),
                                col_area,
                                self.dpi,
                            )
                        }
                        _ => None,
                    });
            // ── 표 위 간격 ──
            {
                let comp = composed.get(para_index);
                let ps_id = comp
                    .map(|c| c.para_style_id as usize)
                    .unwrap_or(para.para_shape_id as usize);
                let is_column_top = (y_offset - col_area.y).abs() < 1.0;
                if is_tac {
                    if !prev_tac_seg_applied {
                        let outer_margin_top_px =
                            if let Some(Control::Table(t)) = para.controls.get(control_index) {
                                hwpunit_to_px(t.outer_margin_top as i32, self.dpi)
                            } else {
                                0.0
                            };
                        if !is_column_top {
                            let spacing_before = styles
                                .para_styles
                                .get(ps_id)
                                .map(|ps| ps.spacing_before)
                                .unwrap_or(0.0);
                            if spacing_before > 0.0 {
                                y_offset += spacing_before;
                            }
                        }
                        if outer_margin_top_px > 0.0 {
                            y_offset += outer_margin_top_px;
                        }
                    } else if let Some(Control::Table(t)) = para.controls.get(control_index) {
                        // [#5729] 직전 TAC 의 저장 seg 로 흐름이 전진해 왔어도, 이
                        // 표의 저장 밴드가 정확히 om_top+선언높이+om_bottom 이면
                        // 표 상단 앞의 om_top 은 그 밴드 몫이다 — 건너뛰면 표가
                        // 3.8px 위로 앉아 직전 표 괘선과 4.2px 겹친다 (156505870
                        // 연달은 자리차지 표 4개 중 2~4번째, 한글 이중 괘선 간격
                        // 0.4px vs rhwp 4.3px).
                        if Self::tac_stored_band_is_outer_box(para, t) {
                            y_offset += hwpunit_to_px(t.outer_margin_top as i32, self.dpi);
                        }
                        // [#5809 실측②] 직전 TAC 의 seg 전진은 줄 간격까지만 담는다.
                        // **문단이 바뀌는** TAC-모순(treat_as_char + 자리차지) 빈 host
                        // 표는 자기 문단의 위 간격(sb)을 여기서 받아야 한다 — 건너뛰면
                        // 표가 저장 사다리보다 sb 만큼 위에 앉는다. 156518601 실측:
                        // 5쪽 그림 표(sb 20px)가 한글·저장 사다리(간격 28px = ls 8 +
                        // sb 20) 대비 19.8px 위, 9쪽 연속 host 4개(sb 6.7px)는 표당
                        // ~sb 씩 계단 누적. 같은 문단 안의 후속 TAC(vpos 델타 전진이
                        // 간격을 이미 담음)와 구분하기 위해 첫 컨트롤로 한정한다.
                        if control_index == 0
                            && !is_column_top
                            && self.profile.get().hwpx_stored_layout()
                            && t.common.treat_as_char
                            && matches!(
                                t.common.text_wrap,
                                crate::model::shape::TextWrap::TopAndBottom
                            )
                            && !para_has_non_whitespace_text(para)
                        {
                            let spacing_before = styles
                                .para_styles
                                .get(ps_id)
                                .map(|ps| ps.spacing_before.max(0.0))
                                .unwrap_or(0.0);
                            if spacing_before > 0.0 {
                                y_offset += spacing_before;
                                if std::env::var("RHWP_DIAG_TAC").is_ok() {
                                    eprintln!(
                                        "DIAG_PAINT_SB pi={} sb={:.1} y={:.1}",
                                        para_index, spacing_before, y_offset,
                                    );
                                }
                            }
                        }
                    }
                } else if !is_current_empty_para_float && !is_current_visible_para_float {
                    // [#6267] 자리차지(para-float) 표는 흐름을 소비하지 않고
                    // compute_table_y_position 이 sb 이전 앵커(para_y_for_table)로
                    // 따로 앉힌다. 그러므로 여기서 y_offset 에 더한 sb 는 표에는
                    // 닿지 않고 **호스트 문단 텍스트만** 밀어내는데, 그 텍스트를 그리는
                    // layout_composed_paragraph 는 (!is_column_top 이면) sb 를 다시
                    // 가산한다 — 이중 계상이다. 156726353 1쪽 문단 8: 저장 사다리 대비
                    // 문단 5~7 은 +75.6px 인데 문단 8 만 +91.6px(=sb 16.0px)로 튀어
                    // 자리차지 표와 18pt 겹쳤다.
                    if let Some(ps) = styles.para_styles.get(ps_id) {
                        if ps.spacing_before > 0.0 && !is_column_top {
                            y_offset += ps.spacing_before;
                        }
                    }
                }
            }
            // ── 호스트 문단 텍스트 렌더링 ──
            // [#6184] 이 가드는 **현재 쪽**의 항목만 훑는다. typeset 이 host 줄을
            // 이월 전 쪽에 pre-emit 한 경우(`pre_emit_visible_rowbreak_host_text`)
            // 그 항목은 앞 쪽에 있어 여기서 안 보이고, 같은 줄이 두 쪽에 그려진다
            // (156489124 pi=324: 12쪽 1030.3 과 13쪽 75.6). pre-emit 기록은 쪽을
            // 넘어 남으므로 함께 본다 — 분할 표 경로의 `host_pre_emitted` 가드와
            // 같은 계약을 통짜 표 경로에도 둔다.
            let text_already_laid_out = self
                .pre_emitted_host_paras
                .borrow()
                .contains(&para_index)
                || page_content.column_contents.iter().any(|cc| {
                    cc.items.iter().any(|it| {
                        matches!(it, PageItem::PartialParagraph { para_index: pi, .. } if *pi == para_index)
                    })
                });
            // [편집 세션] host 텍스트가 typeset 에서 다음 쪽 PartialParagraph 로
            // 재배정되면 이 쪽 items 에는 없다 — 저장-형상용 fallback 이 그걸 "미배치"로
            // 오인해 이 쪽에 한 번 더 그리면 문구·로고가 두 쪽에 중복된다(셀 끝
            // Enter 재현). 편집 세션은 PP 아이템 배정이 진실이므로 끈다.
            if !is_tac && !text_already_laid_out && !self.profile.get().session_edited() {
                let host_is_not_square =
                    if let Some(Control::Table(ht)) = para.controls.get(control_index) {
                        !matches!(ht.common.text_wrap, crate::model::shape::TextWrap::Square)
                    } else {
                        true
                    };
                if host_is_not_square {
                    let has_real_text =
                        para.text.chars().any(|c| c > '\u{001F}' && c != '\u{FFFC}');
                    if has_real_text {
                        if let Some(comp) = composed.get(para_index) {
                            let text_start_line = comp.lines.iter().position(|line| {
                                line.runs.iter().any(|r| {
                                    r.text.chars().any(|c| c > '\u{001F}' && c != '\u{FFFC}')
                                })
                            });
                            if let Some(start_line) = text_start_line {
                                let text_end_line = comp
                                    .lines
                                    .iter()
                                    .rposition(|line| {
                                        line.runs.iter().any(|r| {
                                            r.text
                                                .chars()
                                                .any(|c| c > '\u{001F}' && c != '\u{FFFC}')
                                        })
                                    })
                                    .map(|i| i + 1)
                                    .unwrap_or(comp.lines.len());
                                para_start_y.insert(para_index, y_offset);
                                let _text_y_end = self.layout_partial_paragraph(
                                    tree,
                                    col_node,
                                    para,
                                    Some(comp),
                                    styles,
                                    styles.hwp3_variant
                                        && self.endnote_para_source_for(para_index).is_none(),
                                    col_area,
                                    y_offset,
                                    start_line,
                                    text_end_line,
                                    page_content.section_index,
                                    para_index,
                                    *multi_col_width,
                                    Some(bin_data_content),
                                    wrap_anchors.get(&para_index),
                                );
                            }
                        }
                    }
                }
            }
            let tac_above_offset_float_flow =
                (is_tac && tac_line_fits_above_offset_float && y_offset > para_y_for_table + 1.0)
                    .then_some(y_offset);
            if tac_above_offset_float_flow.is_some() {
                y_offset = para_y_for_table;
            }
            // ── 표 레이아웃 ──
            let tac_table_y_before = y_offset; // Task #9: 표 렌더 전 y 보존
            let table_ctl_out = self.layout_table_control_block(
                tree,
                col_node,
                paper_images,
                para_start_y,
                para_float_lanes,
                visible_float_exclusions,
                ctx,
                para,
                TableControlVars {
                    y_offset,
                    para_y_for_table,
                    tac_table_y_before,
                    is_tac,
                    is_current_empty_para_float,
                    is_current_empty_square_sibling_float,
                    is_current_visible_para_float,
                    is_first_empty_para_float_control,
                    rewind_anchor_snapped,
                    para_index,
                    control_index,
                },
            );
            y_offset = table_ctl_out.y_offset;
            if let Some(restore) = tac_above_offset_float_flow {
                y_offset = restore.max(y_offset);
            }
            let tac_seg_applied = table_ctl_out.tac_seg_applied;
            let para_float_lane_info = table_ctl_out.para_float_lane_info;
            if let Some(ret) = table_ctl_out.early_return {
                return ret;
            }
            // ── 표 아래 간격 ──
            // out-of-flow로 그려진 표(머리말/꼬리말 자리)는 본문 흐름 간격을 추가하지 않는다.
            let is_outside_body = if let Some(Control::Table(t)) = para.controls.get(control_index)
            {
                !t.common.treat_as_char
                    && matches!(
                        t.common.vert_rel_to,
                        crate::model::shape::VertRelTo::Paper
                            | crate::model::shape::VertRelTo::Page
                    )
                    && matches!(
                        t.common.text_wrap,
                        crate::model::shape::TextWrap::TopAndBottom
                    )
                    && {
                        let tbl_h = hwpunit_to_px(t.common.height as i32, self.dpi);
                        let v_off = hwpunit_to_px(t.common.vertical_offset as i32, self.dpi);
                        let tbl_y = match t.common.vert_align {
                            crate::model::shape::VertAlign::Top
                            | crate::model::shape::VertAlign::Inside => v_off,
                            crate::model::shape::VertAlign::Center => {
                                (layout.page_height - tbl_h) / 2.0 + v_off
                            }
                            crate::model::shape::VertAlign::Bottom
                            | crate::model::shape::VertAlign::Outside => {
                                layout.page_height - tbl_h - v_off
                            }
                        };
                        let body_bottom = layout.body_area.y + layout.body_area.height;
                        tbl_y < layout.body_area.y || tbl_y + tbl_h > body_bottom
                    }
            } else {
                false
            };
            if !tac_seg_applied && !is_outside_body && !is_current_visible_para_float {
                let comp = composed.get(para_index);
                let para_style_id = comp
                    .map(|c| c.para_style_id as usize)
                    .unwrap_or(para.para_shape_id as usize);
                if let Some(para_style) = styles.para_styles.get(para_style_id) {
                    if para_style.spacing_after > 0.0 {
                        y_offset += para_style.spacing_after;
                    }
                }
                // [Task #1147 v2] 빈 앵커 TopAndBottom 비-TAC 표는 다음
                // 항목이 일반 문단일 때 host_line_spacing=0 으로 맞춘다. 단, [Task
                // #1133] 다음 항목도 빈 앵커 TopAndBottom 표이면 해당 line_spacing 이
                // 표-표 사이 간격이므로 HWP처럼 보존한다.
                let next_is_empty_topbottom_table_anchor = paragraphs
                    .get(para_index + 1)
                    .map(para_is_empty_topbottom_table_anchor)
                    .unwrap_or(false);
                let suppress_empty_anchor_spacing =
                    is_current_empty_para_float && !next_is_empty_topbottom_table_anchor;
                if let Some(seg) = para.line_segs.last() {
                    // [#4533 ⑥] 위-예약 Square 판별 재계산(렌더 함수와 동일식) —
                    // 앵커·후속 문단 vpos 동일(붕괴 사다리)이라 후행 간격도 0.
                    let square_reserved_above = (|| {
                        let Some(Control::Table(tb)) = para.controls.get(control_index) else {
                            return false;
                        };
                        if !self.profile.get().hwp5_stored_pagination_layout()
                            || tb.common.treat_as_char
                            || !matches!(tb.common.text_wrap, crate::model::shape::TextWrap::Square)
                            || para_has_non_whitespace_text(para)
                            || para_index == 0
                        {
                            return false;
                        }
                        let tot = hwpunit_to_px(tb.common.height as i32, self.dpi);
                        let Some(host_lh) = para
                            .line_segs
                            .iter()
                            .find(|sg| sg.tag & 0x8000_0000 == 0)
                            .map(|sg| hwpunit_to_px(sg.line_height, self.dpi))
                        else {
                            return false;
                        };
                        let (Some(ps), Some(hs)) = (
                            paragraphs
                                .get(para_index - 1)
                                .and_then(|pp| pp.line_segs.last()),
                            para.line_segs.first(),
                        ) else {
                            return false;
                        };
                        if hs.vertical_pos <= ps.vertical_pos + ps.line_height {
                            return false;
                        }
                        let gap = hwpunit_to_px(
                            hs.vertical_pos - (ps.vertical_pos + ps.line_height),
                            self.dpi,
                        );
                        tot > 1.0 && gap >= tot * 0.85 && host_lh < tot * 0.25
                    })();
                    // [#7047] 빈 개체 host 가 **또 다른 빈 개체 host** 로 이어지는 사다리.
                    //
                    // 그 형상에서 종전 간격은 `line_spacing` 뿐인데(#1133 의 표-표 간격),
                    // 저장 사다리는 `줄높이 + 줄간격 + host 뒤간격 + 다음 앞간격` 전량을
                    // 증언한다. 임대차계약서양식 3쪽 실측 — 표 host 둘이 각각 줄간격만
                    // 전진해 아래 개체가 10.0px · 19.3px 위에 놓였다.
                    //
                    // ```text
                    //   rec#947   저장 델타  886 =  450 + 136 + 0 + 300     rhwp 136 뿐
                    //   rec#1041  저장 델타 1794 = 1150 + 344 + 0 + 300     rhwp 344 뿐
                    // ```
                    //
                    // 등식이 **1 HWPUNIT 안에서** 성립할 때만 델타를 쓴다 — 사다리가
                    // 표-표 간격만 증언하는 문서(#1133 원래 대상)는 등식이 깨져 종전
                    // 경로가 그대로 유지된다. 자기 게이트라 광역 규칙이 아니다.
                    let stored_anchor_stack_gap = stored_empty_anchor_stack_advance_hu(
                        self.profile.get().hwp5_stored_pagination_layout()
                            || self.profile.get().hwpx_stored_layout(),
                        paragraphs,
                        styles,
                        self.dpi,
                        para_index,
                    );
                    let gap = if square_reserved_above {
                        // [#4533 ⑥] 위-예약 Square: 앵커·후속 문단 vpos 가 동일
                        // (붕괴 사다리) — 후행 간격도 사다리가 0 으로 증언한다.
                        0
                    } else if let Some(ladder_gap) = stored_anchor_stack_gap {
                        ladder_gap
                    } else if suppress_empty_anchor_spacing {
                        0
                    } else if is_current_empty_para_float {
                        seg.line_spacing.max(0)
                    } else if seg.line_spacing > 0 {
                        seg.line_spacing
                    } else {
                        seg.line_height
                    };
                    // [#6900] **사다리가 다음 문단을 이미 표 하단에 두면 더 띄우지 않는다.**
                    //
                    // 이 간격은 표 뒤 host 앵커 줄의 후행 간격이다. 그런데 앵커 줄의
                    // 사다리(`lh`)가 **앞선 TAC 표 한 장만** 덮고 뒤따르는 비-TAC 표는
                    // 덮지 않는 문단이 있다. 그런 문단에서는 표 하단이 이미 사다리가
                    // 지목한 다음 문단 자리까지 내려와 있어서, 여기서 간격을 더하면
                    // 후속 문단이 통째로 그만큼 밀린다(156521182 4쪽: 출처 줄이 본문을
                    // 13.4px 넘어 사라짐).
                    //
                    // ```text
                    //   pi=30 seg0  vpos 0      lh 45.3   ← 첫 TAC 표만 덮는다
                    //   표 하단(그린 값)          977.4
                    //   pi=31 저장 vpos 64803  → 977.4    ← 사다리가 표 하단을 지목
                    //   종전                     977.4 + 14.9(seg.line_spacing) = 992.3
                    // ```
                    //
                    // 다음 문단의 저장 vpos 를 이 문단의 사다리 기준점으로 환산한다.
                    // 중복 간격이라는 증거는 그 위치가 현재 표 하단과 일치하는 것이다.
                    // 표 하단보다 훨씬 위인 저장 위치는 재배치 또는 표 높이 변화일 수
                    // 있으므로 간격을 없애는 근거로 쓰지 않는다. 기존 0.5px 환산 오차만
                    // 양방향으로 허용하며, 근거가 불충분하면 종전 간격을 유지한다.
                    let ladder_already_at_flow = self.profile.get().hwp5_stored_pagination_layout()
                        && para
                            .line_segs
                            .first()
                            .zip(
                                paragraphs
                                    .get(para_index + 1)
                                    .and_then(|next| next.line_segs.first()),
                            )
                            .is_some_and(|(host_first, next_first)| {
                                // 되감김(다음 쪽으로 넘어간 문단)은 기준점이 달라 못 쓴다.
                                let next_ladder_y = para_y_for_table
                                    - hwpunit_to_px(host_first.vertical_pos, self.dpi)
                                    + hwpunit_to_px(next_first.vertical_pos, self.dpi);
                                next_first.vertical_pos > host_first.vertical_pos
                                    && (next_ladder_y - y_offset).abs() <= 0.5
                            });
                    if gap > 0 && !ladder_already_at_flow {
                        y_offset += hwpunit_to_px(gap, self.dpi);
                    }
                }
            }
            if let Some((x_start, x_end, raw_top, lane_top, global_y_before, stored_flow_advance)) =
                para_float_lane_info
            {
                let reserved_height = (y_offset - lane_top).max(0.0);
                let lanes = para_float_lanes.entry(para_index).or_default();
                lanes.place(
                    Some(control_index),
                    x_start,
                    x_end,
                    raw_top,
                    reserved_height,
                );
                let single_positive_empty_float_before_plain_text = para
                    .controls
                    .get(control_index)
                    .and_then(|control| match control {
                        Control::Table(table) => native_empty_host_rowbreak_line_advance_hu(
                            self.profile.get().hwp5_stored_pagination_layout(),
                            para,
                            table,
                            paragraphs.get(para_index + 1),
                        )
                        .map(|line_advance| (table.as_ref(), line_advance)),
                        _ => None,
                    });
                // [#6147] #2439 의 특수형이 아닌 빈 앵커 밴드도 저장 사다리가
                // host 줄 advance 만 증언하면 그 줄을 흐름에 계상한다.
                let stored_empty_anchor_band_host_tail_px =
                    (single_positive_empty_float_before_plain_text.is_none())
                        .then(|| {
                            stored_empty_anchor_band_host_line_advance_hu(
                                self.profile.get().hwp5_stored_pagination_layout()
                                    || self.profile.get().hwpx_stored_layout(),
                                para,
                                control_index,
                                paragraphs.get(para_index + 1),
                            )
                            .map(|line_advance| {
                                let outer_bottom = match para.controls.get(control_index) {
                                    Some(Control::Table(table)) => table.outer_margin_bottom as i32,
                                    Some(Control::Picture(picture)) => {
                                        i32::from(picture.common.margin.bottom)
                                    }
                                    Some(Control::Shape(shape)) => {
                                        i32::from(shape.common().margin.bottom)
                                    }
                                    _ => 0,
                                };
                                hwpunit_to_px(line_advance, self.dpi)
                                    + hwpunit_to_px(outer_bottom, self.dpi)
                            })
                        })
                        .flatten();
                let deferred_empty_offset_float_bottom = deferred_empty_float_anchor_y.map(|_| {
                    let outer_bottom = para
                        .controls
                        .get(control_index)
                        .and_then(|control| match control {
                            Control::Table(table) => Some(table.outer_margin_bottom as i32),
                            _ => None,
                        })
                        .unwrap_or(0);
                    lanes.max_bottom() + hwpunit_to_px(outer_bottom, self.dpi)
                });
                let lane_flow_bottom = if let Some(placement) = ctx
                    .paragraph_float_placements
                    .get(&(para_index, control_index))
                {
                    // 같은 수용 프레임이 실제 배치 원점과 흐름 끝을 함께 소유한다.
                    // 뒤의 앵커·호스트 꼬리 분기가 이 끝점을 덮어쓰지 않아야 한다.
                    col_area.y + placement.occupied_bottom
                } else if let Some(bottom) = deferred_empty_offset_float_bottom {
                    // 생성 본문을 먼저 gap에 배치한 뒤에는 offset을 뺀 예약 높이가 아니라
                    // 실제 표 하단과 바깥 아래 여백까지 흐름을 진행해야 다음 문단이 표와
                    // 겹치지 않는다.
                    bottom
                } else if let Some((table, line_advance)) =
                    single_positive_empty_float_before_plain_text
                {
                    // #2439: a single empty-host TopAndBottom float followed by an ordinary
                    // text paragraph must clear the table's painted lane. `global + reserved`
                    // below deliberately omits the visual vertical offset; using it here put
                    // the signature line inside the table by exactly that offset.
                    let stored_rowbreak_host_tail = hwpunit_to_px(line_advance, self.dpi)
                        + hwpunit_to_px(table.outer_margin_bottom as i32, self.dpi);
                    lanes.max_bottom() + stored_rowbreak_host_tail
                } else if let Some(host_tail) = stored_empty_anchor_band_host_tail_px {
                    // [#6147] 저장 사다리가 host 줄 advance 만 증언하는 빈 앵커 밴드는
                    // 그 줄 상자를 개체 아래에 실제로 차지한다 — #2439 와 같은 꼬리
                    // (줄 advance + 바깥 아래 여백)를 페인트 lane 하단에 얹는다.
                    lanes.max_bottom() + host_tail
                } else if is_current_empty_square_sibling_float {
                    // 두 Square 표는 x lane이 겹치지 않으면 같은 raw top을 사용한다.
                    // 첫 표의 전역 cursor를 둘째 표의 base로 더하지 않아야 가로 pair가
                    // 다시 세로로 누적되지 않는다.
                    lanes.max_bottom()
                } else if is_current_empty_para_float {
                    let is_native_picture_caption_float =
                        self.profile.get().hwp5_stored_pagination_layout()
                            && para.controls.get(control_index).is_some_and(|control| {
                                matches!(control, Control::Table(table)
                                    if is_two_row_picture_caption_rowbreak_table(table)
                                        && signed_hwpunit(table.common.vertical_offset) > 0)
                            });
                    // Empty-anchor TopAndBottom tables can encode a visual
                    // vertical offset separately from the flow height measured
                    // by pagination. Keep the table painted at lane_top, but
                    // advance following items by the reserved table height only.
                    //
                    // 단, native HWP의 2행 그림+caption RowBreak 표는 caption 행까지
                    // 표의 실제 paint 영역이다. 표 뒤에 빈 guide 문단이 끼고 그 다음
                    // 본문이 과거 vpos로 되감기는 형상에서는 `global + reserved`가
                    // 양수 vertical offset만큼 caption 하단보다 위에 남는다. 그 상태로
                    // 후속 본문을 배치하면 caption과 겹친다(정책연구 p182, pi=1904).
                    // 이 구조만 lane의 물리 하단을 flow floor로 삼는다. 일반 empty
                    // float의 offset-only 예약 계약은 그대로 유지한다.
                    //
                    // [#5870] 저장 사다리가 물리 공식(v_off + outer_top + 표높이 +
                    // outer_bottom)과 정확히 일치하는 문단은 한글이 그 합만큼 흐름을
                    // 전진시킨 증거이므로 여분을 마저 계상한다 — 아니면 다음 빈-host
                    // float 가 그만큼 위로 올라와 겹친다(10645 40쪽 결재란 19.7px 침범).
                    // typeset 의 place_table_with_text 흐름 가산과 대칭. 광역 규칙이
                    // 아닌 문단 단위 증거 게이트인 근거는 helper 주석(#2097 반증)에.
                    // [#6032] anchor 가 저장 vpos 로 되감겨 스냅된 문단은 "후속이
                    // 텍스트면 저장 vpos 재고정으로 무결" 전제가 깨진다(후속 문단
                    // 재고정이 발동하지 않는 형상) — 사다리 정확일치 증거가 있으면
                    // 후속이 일반 텍스트여도 여분을 계상한다.
                    let physical_ladder_extras_px =
                        ((self.profile.get().hwp5_stored_pagination_layout()
                            || self.profile.get().hwpx_stored_layout())
                            && (rewind_anchor_snapped
                                || paragraphs
                                    .get(para_index + 1)
                                    .is_some_and(para_is_empty_topbottom_table_anchor))
                            && para
                                .controls
                                .iter()
                                .filter(|control| matches!(control, Control::Table(_)))
                                .count()
                                == 1)
                            .then(|| {
                                let host_vpos = para
                                    .line_segs
                                    .iter()
                                    .find(|seg| seg.tag & 0x8000_0000 == 0)
                                    .map(|seg| seg.vertical_pos)?;
                                let next_vpos = paragraphs
                                    .get(para_index + 1)?
                                    .line_segs
                                    .iter()
                                    .find(|seg| seg.tag & 0x8000_0000 == 0)
                                    .map(|seg| seg.vertical_pos)?;
                                match para.controls.get(control_index)? {
                                    Control::Table(table) => empty_host_physical_ladder_extras_hu(
                                        table, host_vpos, next_vpos,
                                    )
                                    .map(|extras_hu| hwpunit_to_px(extras_hu as i32, self.dpi)),
                                    _ => None,
                                }
                            })
                            .flatten();
                    // 저장 사다리가 전체 흐름 상자를 증명한 경우에는 그 높이가
                    // 예약량이다. 앞 표 때문에 저장 원점과 paint 원점이 달라져도
                    // 두 원점의 차이를 높이에 더하지 않는다. 테두리 원점만 알려진
                    // 앵커는 기존 offset/예약 계약으로 처리한다.
                    if let Some(advance) = stored_flow_advance {
                        global_y_before + advance
                    } else if is_native_picture_caption_float {
                        lanes.max_bottom()
                    } else {
                        global_y_before + reserved_height + physical_ladder_extras_px.unwrap_or(0.0)
                    }
                } else {
                    lanes.max_bottom()
                };
                y_offset = global_y_before.max(lane_flow_bottom);
            }
            if tac_seg_applied {
                // [hwpdf cycle#3 — 폴백 한정] control_index 는 컨트롤 배열 인덱스지 줄
                // 인덱스가 아니다. 표 앞 비가시 컨트롤(SectionDef/ColumnDef/책갈피 등)은
                // 줄 seg 를 만들지 않아 get(control_index)=None 이 되며, 이때는 표가 곧
                // 호스트 줄이므로 마지막(=유일) seg 의 줄간격을 적용해야 후속 본문이
                // 위로 당겨지지 않는다.
                //
                // 단, 표 앞에 가시 개체(그림/그리기/표)가 있으면 그 개체들은 별도
                // 경로로 배치되고 다음 문단 위치가 파일 lineseg(vpos=lh+sp 포함)로 이미
                // 확정되므로, 여기서 줄간격을 다시 더하면 이중 적용된다(test_521: 이메일
                // 박스 TAC 표 앞 그림 2개 → 한컴 간격은 호스트 줄간격 제외, gap≈20px).
                // → 폴백은 표 앞 컨트롤이 전부 비가시일 때로 한정한다.
                let only_invisible_before_tac = para.controls
                    [..control_index.min(para.controls.len())]
                    .iter()
                    .all(|c| {
                        !matches!(
                            c,
                            Control::Table(_) | Control::Picture(_) | Control::Shape(_)
                        )
                    });
                // [#4622 · #4599 ⑦] control_index 를 seg 인덱스로 쓰는 폴백은 표 앞에 자기
                // 줄이 있는 문단에서 어긋난다 — 36392662 p1 pi7: seg0(공백 줄,
                // lh=1300·ls=-1300)을 표 줄로 오인해 아래 음수-ls 리셋이 advance=0
                // 으로 흐름을 문단 시작에 되돌렸고, 후속 '나' 절이 6×6 표 위에 77px
                // 겹쳤다(한글 2022 PDF·저장 사다리 모두 표 아래 627.7 실측 — 표 줄은
                // seg1, lh=13377=표+여백). #4531 이 native 한정으로 도입한 앵커 사영
                // (control_line_seg_index)을 **전 세그 저장-태그** hwpx 사다리로
                // 확장한다 — 종전 hwpx 제외 근거(56734607 계산-lineseg 회귀)는 저장
                // 태그 검사로 배제된다.
                let all_segs_stored = !para.line_segs.is_empty()
                    && para.line_segs.iter().all(|s| {
                        s.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0
                    });
                // 사영 채택은 그 seg 가 실제 표 줄이라는 기하 증거(lh ≥ 표 선언 높이)
                // 가 있을 때만 — 무증거 사영은 body 전체를 +10px 급 과전진시키는
                // 반증(156556059 p3, 쪽번호 앵커 실측)이 나왔다.
                // 표 앞 가시 개체(그림/도형/표) 보유 문단은 test_521 계약(이중 가산
                // 방지, host_seg=None)을 유지한다 — 사영이 이를 우회하면 ls 가 재가산
                // 된다(156556059 p3 pi40: TAC 앞 Shape, +10.4px 반증 실측).
                // HWP5와 그 marker HWPX도 컨트롤 번호와 저장 줄 번호가 다르다.
                // 앞 텍스트 줄의 음수 줄간격으로 표 뒤 흐름을 되돌리지 않도록,
                // 표 높이를 담은 실제 소속 줄을 같은 사영으로 고른다.
                // 용지 고정 그림은 host 줄의 흐름을 소유하지 않는다. 원본
                // 표 줄과 다음 줄이 정확히 이어지는 경우에는 그 장식 때문에
                // 표의 후행 간격을 버리지 않는다. 문단 상대 가시 개체는 기존
                // 이중 가산 방지 계약을 그대로 따른다.
                let has_only_paper_decoration_before_tac = para.controls
                    [..control_index.min(para.controls.len())]
                    .iter()
                    .all(|control| match control {
                        Control::Picture(picture) => {
                            !picture.common.treat_as_char
                                && picture.common.vert_rel_to
                                    == crate::model::shape::VertRelTo::Paper
                        }
                        Control::Table(_) | Control::Shape(_) => false,
                        _ => true,
                    });
                let continuous_stored_table_line =
                    self.profile.get().hwp5_stored_pagination_layout()
                        && has_only_paper_decoration_before_tac
                        && control_line_seg_index(para, control_index)
                            .and_then(|index| para.line_segs.get(index))
                            .is_some_and(|seg| {
                                crate::renderer::composer::tac_next_line_full_spacing(
                                    para,
                                    paragraphs.get(para_index + 1),
                                    styles
                                        .para_styles
                                        .get(para.para_shape_id as usize)
                                        .map_or(0.0, |shape| shape.spacing_after),
                                    paragraphs
                                        .get(para_index + 1)
                                        .and_then(|next| {
                                            styles.para_styles.get(next.para_shape_id as usize)
                                        })
                                        .map_or(0.0, |shape| shape.spacing_before),
                                    seg,
                                    self.profile.get(),
                                    self.dpi,
                                )
                            });
                let projected_seg = if (self.profile.get().hwp5_stored_pagination_layout()
                    || (self.profile.get().hwpx_stored_layout() && all_segs_stored))
                    && (only_invisible_before_tac || continuous_stored_table_line)
                {
                    let table_h = para.controls.get(control_index).and_then(|c| match c {
                        Control::Table(t) if t.common.height < 0x8000_0000 => {
                            Some(t.common.height as i64)
                        }
                        _ => None,
                    });
                    control_line_seg_index(para, control_index)
                        .and_then(|idx| para.line_segs.get(idx))
                        .filter(|seg| table_h.is_some_and(|h| i64::from(seg.line_height) >= h))
                } else {
                    None
                };
                let host_seg = projected_seg
                    .or_else(|| para.line_segs.get(control_index))
                    .or_else(|| {
                        if only_invisible_before_tac {
                            para.line_segs.last()
                        } else {
                            None
                        }
                    });
                // [Task #2220] 저장 host lh 가 표 outer_margin 을 포함하는 증거
                // (lh ≥ 표 선언높이 + om 상하합, 주보 p1: 24700 = 22996 + 852×2).
                // 이 경우 저장 lh 기반 advance 는 문단 줄 상단(para_y) 기준이어야
                // 하며, om_top 선가산분·om_bottom 후가산(#521)을 겹치면 om 상하합
                // (1704HU=22.7px)만큼 후속 본문이 밀려 단 하단이 절단된다.
                let mut stored_lh_covers_om = false;
                if let Some(seg) = host_seg {
                    if seg.line_spacing > 0 {
                        let native_stored_layout = self.profile.get().hwp5_stored_pagination_layout()
                            && (!self.profile.get().session_edited() || (self.profile.get().native_hwp5_layout() && crate::renderer::composer::unchanged_native_tac_spacing(
                                para_index,para,paragraphs.get(para_index+1),control_index,seg,measured_tables,
                                styles,self.dpi)));
                        y_offset += if crate::renderer::composer::tac_next_line_full_spacing(
                            para,
                            paragraphs.get(para_index + 1),
                            styles
                                .para_styles
                                .get(para.para_shape_id as usize)
                                .map_or(0.0, |shape| shape.spacing_after),
                            paragraphs
                                .get(para_index + 1)
                                .and_then(|next| {
                                    styles.para_styles.get(next.para_shape_id as usize)
                                })
                                .map_or(0.0, |shape| shape.spacing_before),
                            seg,
                            self.profile.get(),
                            self.dpi,
                        ) {
                            hwpunit_to_px(seg.line_spacing, self.dpi)
                        } else {
                            crate::renderer::composer::tac_host_trailing_spacing(
                                para,
                                control_index,
                                seg,
                                self.profile.get().hwpx_stored_layout(),
                                native_stored_layout,
                                self.dpi,
                            )
                        };
                    } else if seg.line_spacing < 0 {
                        // 음수 ls (Fixed 줄간격 TAC 표): y를 문단 advance로 리셋 (Task #9)
                        // 표 렌더 높이가 아닌, 일반 문단과 동일한 lh+ls advance 사용
                        let advance =
                            hwpunit_to_px(seg.line_height + seg.line_spacing, self.dpi).max(0.0);
                        stored_lh_covers_om = matches!(
                            para.controls.get(control_index),
                            Some(Control::Table(t))
                                if t.common.height < 0x8000_0000
                                    && i64::from(seg.line_height)
                                        >= t.common.height as i64
                                            + t.outer_margin_top as i64
                                            + t.outer_margin_bottom as i64
                                            - 10
                                    && t.outer_margin_top as i64 + t.outer_margin_bottom as i64 > 0
                        );
                        y_offset = if stored_lh_covers_om {
                            para_y_for_table + advance
                        } else {
                            tac_table_y_before + advance
                        };
                    }
                } else if crate::renderer::para_has_no_stored_line_segs(para) {
                    // [#5788] 저장 lineseg 가 없는(기계생성) 문서는 앵커 줄의 trailing
                    // line_spacing 을 실을 seg 가 없어 표 아래 문단이 그만큼 붙는다
                    // (3190263: 표 19개 × −9.2px 누적으로 8쪽 vs 한글 9쪽; 한글 계산
                    // 조판은 앵커 줄간격을 더한다). 문단 스타일의 퍼센트 줄간격을
                    // 앵커 글꼴 크기로 환산해 보충한다 — 저장 lineseg 보유 문서
                    // (#1116 핀 계열)는 위 경로 그대로라 불변.
                    let ps_id_for_ls = composed
                        .get(para_index)
                        .map(|c| c.para_style_id as usize)
                        .unwrap_or(para.para_shape_id as usize);
                    let font_size = para
                        .char_shapes
                        .first()
                        .and_then(|cs| styles.char_styles.get(cs.char_shape_id as usize))
                        .map(|c| c.font_size)
                        .unwrap_or(0.0);
                    if let Some(ps) = styles.para_styles.get(ps_id_for_ls) {
                        use crate::model::style::LineSpacingType;
                        let extra = match ps.line_spacing_type {
                            LineSpacingType::Percent if ps.line_spacing > 100.0 => {
                                font_size * (ps.line_spacing - 100.0) / 100.0
                            }
                            LineSpacingType::SpaceOnly => ps.line_spacing.max(0.0),
                            _ => 0.0,
                        };
                        if extra > 0.0 {
                            y_offset += extra;
                        }
                    }
                }
                let comp = composed.get(para_index);
                let ps_id = comp
                    .map(|c| c.para_style_id as usize)
                    .unwrap_or(para.para_shape_id as usize);
                // A visible same-paragraph tail transfers after-spacing to the
                // paragraph's last emitted item, not merely its last text fragment.
                // Whitespace-only tails are skipped above and do not own completion.
                if let Some(ps) = styles.para_styles.get(ps_id) {
                    if ps.spacing_after > 0.0
                        && ctx.tac_text_tail_spacing_after(para_index).is_none()
                    {
                        y_offset += ps.spacing_after;
                    }
                }
                // [Task #521] TAC 표 outer_margin_bottom 적용 (한컴 명세 정합).
                // layout_partial_table_item:2642-2647 와 동일 처리. lh = cell_h +
                // outer_margin_bottom 으로 한컴이 정의하므로, layout_table 가
                // cell_h 만 advance 한 후 outer_margin_bottom 을 별도 적용해야
                // 다음 paragraph 가 정합 (exam_eng p2 18번 ① 위치 -8 px shortfall).
                let outer_margin_bottom_px =
                    if let Some(Control::Table(t)) = para.controls.get(control_index) {
                        hwpunit_to_px(t.outer_margin_bottom as i32, self.dpi)
                    } else {
                        0.0
                    };
                // [Task #2220] 저장 lh 가 om 을 포함한 advance 를 썼으면 om_bottom
                // 은 이미 반영됨 — #521 후가산은 그 외 경로에만 적용.
                if outer_margin_bottom_px > 0.0 && !stored_lh_covers_om {
                    y_offset += outer_margin_bottom_px;
                }
                // 앞선 글앞 장식 도형은 호스트 줄의 흐름에 참여하지 않아 `host_seg`를
                // 의도적으로 비운다. 그 경우 물리 표 상자를 포함한 실제 소유 줄의
                // 음수 Fixed 줄간격도 누락된다. 표 paint와 outer margin은 위에서 이미
                // 반영했으므로, 뒤 문단의 흐름에만 이 저장 간격을 더한다(#7333 p13,
                // p16~21). 양수 간격 및 일반 가시 개체 조합은 기존 분기를 유지한다.
                if self.profile.get().hwp5_stored_pagination_layout() {
                    if let Some(deduction_hu) =
                        tac_in_front_decoration_fixed_line_spacing_deduction_hu(para, control_index)
                    {
                        y_offset -= hwpunit_to_px(deduction_hu, self.dpi);
                    }
                    // Full-band 빈 TAC carrier는 표의 paint origin과 다음 문단 top을
                    // 같은 저장 LINE_SEG 사다리에 기록한다. 앞 InFrontOfText 장식이
                    // host_seg의 일반 후가산을 막아도, 이 정확한 등식이 성립하면
                    // 다음 문단의 저장 top보다 흐름이 위에 남아서는 안 된다(#7333
                    // p14·p22·p23·p33). 계산된 일반 TAC 흐름이 이미 더 아래면 유지한다.
                    if let Some(stored_flow_end) =
                        para.controls
                            .get(control_index)
                            .and_then(|control| match control {
                                Control::Table(table) => {
                                    paragraphs.get(para_index + 1).and_then(|following| {
                                        stored_empty_full_band_tac_table_flow_end(
                                            para,
                                            control_index,
                                            table,
                                            following,
                                            col_area,
                                            self.dpi,
                                        )
                                    })
                                }
                                _ => None,
                            })
                    {
                        y_offset = y_offset.max(stored_flow_end);
                    }
                }
                // TAC 표도 호스트 문단의 점유 영역이다. 별도 PageItem 경로로
                // 그려져 layout_composed_paragraph를 거치지 않아도 문단 외곽선을
                // 누락하지 않는다. 이미 텍스트 범위를 수집했다면 같은 문단만 확장한다.
                if let Some(ps) = styles
                    .para_styles
                    .get(ps_id)
                    .filter(|ps| ps.border_fill_id > 0)
                {
                    let mut ranges = self.para_border_ranges.borrow_mut();
                    if let Some(range) = ranges.iter_mut().rev().find(|range| range.9 == para_index)
                    {
                        range.2 = range.2.min(para_y_for_table);
                        range.4 = range.4.max(y_offset);
                    } else if y_offset > para_y_for_table {
                        ranges.push((
                            ps.border_fill_id,
                            col_area.x,
                            para_y_for_table,
                            col_area.width,
                            y_offset,
                            ps.border_spacing[2],
                            ps.border_spacing[3],
                            false,
                            false,
                            para_index,
                        ));
                    }
                }
                return (y_offset, true);
            }
            // ── 같은 문단의 인라인 TAC 표 렌더링 ──
            if !is_tac {
                let seg_width =
                    effective_tac_segment_width_hu(para, px_to_hwpunit(col_area.width, self.dpi));
                for (ci, ctrl) in para.controls.iter().enumerate() {
                    if ci == control_index {
                        continue;
                    }
                    if let Control::Table(inline_t) = ctrl {
                        if inline_t.common.treat_as_char
                            && crate::renderer::height_measurer::is_tac_table_inline_in_para(
                                inline_t, seg_width, para,
                            )
                        {
                            let mt = measured_tables
                                .iter()
                                .find(|m| m.para_index == para_index && m.control_index == ci);
                            let alignment = composed
                                .get(para_index)
                                .map(|c| {
                                    styles
                                        .para_styles
                                        .get(c.para_style_id as usize)
                                        .map(|s| s.alignment)
                                        .unwrap_or(Alignment::Left)
                                })
                                .unwrap_or(Alignment::Left);
                            // paragraph_layout에서 계산된 인라인 좌표 사용
                            let inline_pos = tree.get_inline_shape_position(
                                page_content.section_index,
                                para_index,
                                ci,
                                None,
                            );
                            let (inline_x, inline_y) = if let Some((ix, iy)) = inline_pos {
                                (Some(ix), iy)
                            } else {
                                (None, para_y_for_table)
                            };
                            let tac_new_y = self.layout_table(
                                tree,
                                col_node,
                                inline_t,
                                page_content.section_index,
                                styles,
                                *outline_numbering_id,
                                col_area,
                                inline_y,
                                bin_data_content,
                                mt,
                                0,
                                Some((para_index, ci)),
                                alignment,
                                None,
                                0.0,
                                0.0,
                                inline_x,
                                None,
                                None,
                                None,
                                false,
                                false,
                                0.0,
                                None,
                                Self::standalone_table_char_border_fill(
                                    Some(para),
                                    inline_t,
                                    styles,
                                ),
                            );
                            y_offset = y_offset.max(tac_new_y);
                        }
                    }
                }
            }
            // 이월 표의 paint frame/cell height는 유지한다. 단, HWP5가 다음 문단에
            // 새 page-local LINE_SEG anchor를 저장한 좁은 형상에서는 stale cell bottom을
            // 후속 문단 flow로 소비하지 않는다.
            if let Some(next_flow_top) = relocated_next_flow_top {
                y_offset = next_flow_top;
            }
        }
        (y_offset, false)
    }

    /// 어울림 배치 표 옆에 빈 리턴 문단을 렌더링
    /// 표는 왼쪽, 문단(하드 리턴)은 오른쪽에 배치
    /// `table_content_offset`: 현재 페이지에서 표시되는 표 콘텐츠의
    /// 어울림 배치 표 옆 문단 렌더링 (텍스트 문단 + 빈 리턴 ↵ 마크)
    ///
    /// table_content_offset: 분할 표에서 이전 페이지에 표시된 행 높이 합 (px)
    #[allow(clippy::too_many_arguments)]
    /// PartialTable PageItem 레이아웃 (layout_column_item에서 분리)
    #[allow(clippy::too_many_arguments)]
    fn layout_partial_table_item(
        &self,
        tree: &mut PageLayoutContext,
        col_node: &mut RenderNode,
        para_start_y: &mut std::collections::HashMap<usize, f64>,
        para_index: usize,
        control_index: usize,
        start_row: usize,
        end_row: usize,
        is_continuation: bool,
        start_cut: &[usize],
        end_cut: &[usize],
        is_block_split: bool,
        // [#6935] 시작 컷의 인덱스 공간 — 끝 컷과 다를 수 있다.
        start_cut_is_block: bool,
        row_cursor_is_nested: bool,
        end_row_height_override: Option<f64>,
        start_row_height_override: Option<f64>,
        ctx: &ColumnItemCtx,
        mut y_offset: f64,
    ) -> f64 {
        let ColumnItemCtx {
            page_content,
            paragraphs,
            composed,
            styles,
            bin_data_content,
            measured_tables,
            col_area,
            outline_numbering_id,
            multi_col_width,
            wrap_around_paras,
            wrap_anchors,
            ..
        } = ctx;
        let defer_visible_rowbreak_host_text = paragraphs.get(para_index).and_then(|para| {
            para.controls
                .get(control_index)
                .and_then(|ctrl| match ctrl {
                    Control::Table(t)
                        if !t.common.treat_as_char
                            && is_para_topbottom_float(&t.common)
                            && matches!(
                                t.page_break,
                                crate::model::table::TablePageBreak::RowBreak
                            )
                            && para_has_non_whitespace_text(para)
                            // [#5584] 저장 기하가 "호스트 줄 전부가 표 위" 를
                            // 증언하면 지연하지 않는다 — 그 줄은 pre-text 다.
                            && !stored_host_lines_precede_float(para, t, control_index) =>
                    {
                        Some(t.row_count as usize)
                    }
                    _ => None,
                })
        });
        // [Task #1755] typeset 이 host 텍스트 줄을 이월 전 쪽에 PartialParagraph 로
        // pre-emit 한 문단은 fragment 쪽 host 렌더(첫 부분/마지막 뒤 모두)를 억제한다.
        let host_pre_emitted = self.pre_emitted_host_paras.borrow().contains(&para_index);
        let render_deferred_rowbreak_host_text_after = !host_pre_emitted
            && defer_visible_rowbreak_host_text.is_some_and(|row_count| {
                is_continuation && end_cut.is_empty() && end_row >= row_count
            });
        // ── 분할 표 첫 부분: 호스트 문단 텍스트 렌더링 ──
        if !is_continuation && defer_visible_rowbreak_host_text.is_none() && !host_pre_emitted {
            if let Some(para) = paragraphs.get(para_index) {
                let is_tac = para
                    .controls
                    .get(control_index)
                    .map(|c| matches!(c, Control::Table(t) if t.common.treat_as_char))
                    .unwrap_or(false);
                if !is_tac {
                    let has_real_text =
                        para.text.chars().any(|c| c > '\u{001F}' && c != '\u{FFFC}');
                    if has_real_text {
                        if let Some(comp) = composed.get(para_index) {
                            let text_start_line = comp.lines.iter().position(|line| {
                                line.runs.iter().any(|r| {
                                    r.text.chars().any(|c| c > '\u{001F}' && c != '\u{FFFC}')
                                })
                            });
                            if let Some(start_line) = text_start_line {
                                let text_end_line = comp
                                    .lines
                                    .iter()
                                    .rposition(|line| {
                                        line.runs.iter().any(|r| {
                                            r.text
                                                .chars()
                                                .any(|c| c > '\u{001F}' && c != '\u{FFFC}')
                                        })
                                    })
                                    .map(|i| i + 1)
                                    .unwrap_or(comp.lines.len());
                                // [#6860] 자리차지 개체의 세로 원점은 문단 상단이 아니라 **앵커 줄** 상단이다.
                                // 호스트 줄을 표 위에 그리는 이 경로에서 원점을 옮기지 않으면 앞 줄이 캡션과
                                // 겹친다 (3067979: 줄 517.3/538.7 vs 캡션 534.1 — 20.8px 겹침).
                                let anchor_offset = match para.controls.get(control_index) {
                                    Some(Control::Table(t)) => stored_float_anchor_offset_px(
                                        para,
                                        t,
                                        control_index,
                                        self.dpi,
                                    ),
                                    _ => 0.0,
                                };
                                para_start_y.insert(para_index, y_offset + anchor_offset);
                                let _text_y_end = self.layout_partial_paragraph(
                                    tree,
                                    col_node,
                                    para,
                                    Some(comp),
                                    styles,
                                    styles.hwp3_variant
                                        && self.endnote_para_source_for(para_index).is_none(),
                                    col_area,
                                    y_offset,
                                    start_line,
                                    text_end_line,
                                    page_content.section_index,
                                    para_index,
                                    *multi_col_width,
                                    Some(bin_data_content),
                                    wrap_anchors.get(&para_index),
                                );
                            }
                        }
                    }
                }
            }
        }
        let (pt_margin_left, pt_margin_right) = if let Some(para) = paragraphs.get(para_index) {
            let ps = styles.para_styles.get(para.para_shape_id as usize);
            let ml = ps.map(|s| s.margin_left).unwrap_or(0.0);
            let ind = ps.map(|s| s.indent).unwrap_or(0.0);
            let mr = ps.map(|s| s.margin_right).unwrap_or(0.0);
            (if ind > 0.0 { ml + ind } else { ml }, mr)
        } else {
            (0.0, 0.0)
        };
        let pt_mt = measured_tables
            .iter()
            .find(|mt| mt.para_index == para_index && mt.control_index == control_index);
        let repeat_fragment_outer_margin = paragraphs
            .get(para_index)
            .map(|para| {
                if repeats_native_empty_host_rowbreak_fragment_margin(
                    self.profile.get().hwp5_stored_pagination_layout(),
                    paragraphs,
                    para_index,
                    control_index,
                ) {
                    return true;
                }
                match para.controls.get(control_index) {
                    Some(Control::Table(table)) => {
                        crate::renderer::float_placement::native_empty_host_cellbreak_fragment_repeats_outer_margin(
                            self.profile.get().hwp5_stored_pagination_layout(),
                            para,
                            table,
                        )
                    }
                    _ => false,
                }
            })
            .unwrap_or(false);
        // 비-TAC 자리차지 표에서 vert offset이 있으면 문단 시작 y 전달.
        // layout_partial_table 내부에서 vert_offset을 적용하므로 이중 적용 방지.
        // [Task #712] HwpUnit=u32 이라 `vertical_offset > 0` 가드는 음수 비트표현
        // (예: -1796 HU = 4294965500u32) 도 통과시킴. signed 비교로 정정.
        let pt_y_start = if let Some(para) = paragraphs.get(para_index) {
            if let Some(Control::Table(t)) = para.controls.get(control_index) {
                if !is_continuation {
                    if let Some(stored_top) =
                        native_hwp5_internal_reset_rowbreak_first_fragment_saved_top(
                            self.profile.get().hwp5_stored_pagination_layout(),
                            para,
                            para_index.checked_sub(1).and_then(|i| paragraphs.get(i)),
                            paragraphs.get(para_index + 1),
                            t,
                            col_area,
                            self.dpi,
                        )
                    {
                        stored_top
                    } else if !t.common.treat_as_char
                        && matches!(
                            t.common.text_wrap,
                            crate::model::shape::TextWrap::TopAndBottom
                        )
                        && matches!(t.common.vert_rel_to, crate::model::shape::VertRelTo::Para)
                        && (t.common.vertical_offset as i32) > 0
                    {
                        para_start_y.get(&para_index).copied().unwrap_or(y_offset)
                    } else {
                        y_offset
                    }
                } else if !t.common.treat_as_char
                    && matches!(
                        t.common.text_wrap,
                        crate::model::shape::TextWrap::TopAndBottom
                    )
                    && matches!(t.common.vert_rel_to, crate::model::shape::VertRelTo::Para)
                    && (t.common.vertical_offset as i32) > 0
                {
                    para_start_y.get(&para_index).copied().unwrap_or(y_offset)
                } else {
                    y_offset
                }
            } else {
                y_offset
            }
        } else {
            y_offset
        };
        let pt_y_before = y_offset;
        y_offset = self.layout_partial_table(
            tree,
            col_node,
            paragraphs,
            para_index,
            control_index,
            page_content.section_index,
            styles,
            *outline_numbering_id,
            col_area,
            pt_y_start,
            bin_data_content,
            start_row,
            end_row,
            is_continuation,
            start_cut,
            end_cut,
            is_block_split,
            start_cut_is_block,
            row_cursor_is_nested,
            end_row_height_override,
            start_row_height_override,
            pt_margin_left,
            pt_margin_right,
            pt_mt,
            None,
            false,
            None,
            ctx.paragraph_float_placements
                .get(&(para_index, control_index))
                .map(|p| col_area.y + p.table_top),
        );
        if render_deferred_rowbreak_host_text_after {
            if let Some(para) = paragraphs.get(para_index) {
                let has_real_text = para.text.chars().any(|c| c > '\u{001F}' && c != '\u{FFFC}');
                if has_real_text {
                    if let Some(comp) = composed.get(para_index) {
                        let text_start_line = comp.lines.iter().position(|line| {
                            line.runs
                                .iter()
                                .any(|r| r.text.chars().any(|c| c > '\u{001F}' && c != '\u{FFFC}'))
                        });
                        if let Some(start_line) = text_start_line {
                            let text_end_line = comp
                                .lines
                                .iter()
                                .rposition(|line| {
                                    line.runs.iter().any(|r| {
                                        r.text.chars().any(|c| c > '\u{001F}' && c != '\u{FFFC}')
                                    })
                                })
                                .map(|i| i + 1)
                                .unwrap_or(comp.lines.len());
                            para_start_y.insert(para_index, y_offset);
                            y_offset = self.layout_partial_paragraph(
                                tree,
                                col_node,
                                para,
                                Some(comp),
                                styles,
                                styles.hwp3_variant
                                    && self.endnote_para_source_for(para_index).is_none(),
                                col_area,
                                y_offset,
                                start_line,
                                text_end_line,
                                page_content.section_index,
                                para_index,
                                *multi_col_width,
                                Some(bin_data_content),
                                wrap_anchors.get(&para_index),
                            );
                        }
                    }
                }
            }
        }
        // [Task #1046 Stage 3 Class B/C] 분할 표 실제 콘텐츠 하단 기록 — 이후 더해지는
        // spacing_after/outer_margin_bottom(표 뒤 trailing 간격) 제외. overflow 검출이
        // 페이지 바닥의 후행 간격을 콘텐츠 초과로 오판하지 않도록 한다.
        self.last_item_content_bottom.set(y_offset);
        if let Some(para) = paragraphs.get(para_index) {
            if let Some(Control::Table(table)) = para.controls.get(control_index) {
                let opens =
                    crate::renderer::float_placement::column_rowbreak_fragment_opens_outer_top(
                        self.profile.get().hwpx_stored_layout(),
                        (self.profile.get().hwpx_stored_layout()
                            || self.profile.get().hwp5_stored_pagination_layout())
                        .then_some(para),
                        table,
                        false,
                        0,
                        &[],
                        true,
                    );
                if crate::renderer::float_placement::column_rowbreak_caption_outer_spacing_px(
                    opens, para, table, self.dpi,
                ) > 0.0
                    || (is_continuation
                        && end_cut.is_empty()
                        && end_row >= table.row_count as usize
                        && (!para_has_visible_text(para)
                            || ctx.paragraph_float_placements
                                .get(&(para_index, control_index))
                                .is_some_and(|placement| {
                                    placement.flow == crate::renderer::float_placement::ParagraphFloatFlow::NextLine
                                })))
                {
                    if let Some(placement) = ctx
                        .paragraph_float_placements
                        .get(&(para_index, control_index))
                    {
                        // 결정된 캡션 프레임의 원점과 흐름 끝을 함께 사용한다.
                        // 종료 여백은 표 내용이 아닌 뒤 흐름에 속한다.
                        y_offset = col_area.y + placement.occupied_bottom;
                    }
                }
            }
            let comp = composed.get(para_index);
            let para_style_id = comp
                .map(|c| c.para_style_id as usize)
                .unwrap_or(para.para_shape_id as usize);
            let is_tac = para
                .controls
                .get(control_index)
                .map(|c| matches!(c, Control::Table(t) if t.common.treat_as_char))
                .unwrap_or(false);
            if let Some(para_style) = styles.para_styles.get(para_style_id) {
                if is_tac {
                    if para_style.spacing_after > 0.0 {
                        y_offset += para_style.spacing_after;
                    }
                    let outer_margin_bottom_px =
                        if let Some(Control::Table(t)) = para.controls.get(control_index) {
                            hwpunit_to_px(t.outer_margin_bottom as i32, self.dpi)
                        } else {
                            0.0
                        };
                    if outer_margin_bottom_px > 0.0 {
                        y_offset += outer_margin_bottom_px;
                    }
                } else {
                    if para_style.spacing_after > 0.0 {
                        y_offset += para_style.spacing_after;
                    }
                }
            }
            // #2439: typeset reserves this margin for every proven native-HWP RowBreak
            // fragment.  Keep it outside `last_item_content_bottom`: it is trailing flow, not
            // painted content, and therefore must not trigger an overflow report.
            if !is_tac && repeat_fragment_outer_margin {
                if let Some(Control::Table(table)) = para.controls.get(control_index) {
                    y_offset += hwpunit_to_px(table.outer_margin_bottom as i32, self.dpi);
                }
            }

            // The terminal nested child owns the visible table bbox, while its saved
            // empty host Enter owns only the following flow advance. Typeset records
            // the same value on the terminal continuation; consume it here after
            // `last_item_content_bottom` so it cannot enlarge the table border.
            if is_continuation && end_cut.is_empty() {
                if let Some(Control::Table(table)) = para.controls.get(control_index) {
                    if end_row >= table.row_count as usize {
                        y_offset += table_layout::native_terminal_child_host_line_spacing(
                            self.profile.get().hwp5_stored_pagination_layout(),
                            table,
                            self.dpi,
                        );
                        y_offset +=
                            self.saved_single_cell_terminal_host_spacing_px(table, para, styles);
                    }
                }
            }
        }
        // ── 분할 표: 어울림 문단 렌더링 ──
        if let Some(para) = paragraphs.get(para_index) {
            if let Some(Control::Table(t)) = para.controls.get(control_index) {
                let pt_is_tac = t.common.treat_as_char;
                let pt_is_square =
                    matches!(t.common.text_wrap, crate::model::shape::TextWrap::Square);
                if !pt_is_tac && pt_is_square && !wrap_around_paras.is_empty() {
                    let wrap_cs = para.line_segs.first().map(|s| s.column_start).unwrap_or(0);
                    let wrap_sw = para.line_segs.first().map(|s| s.segment_width).unwrap_or(0);
                    let wrap_text_x = col_area.x + hwpunit_to_px(wrap_cs, self.dpi);
                    let wrap_text_width = hwpunit_to_px(wrap_sw, self.dpi);
                    // [Task #1745] 텍스트 혼합 anchor: 후속 어울림 문단 띠는 표 geometry 로,
                    // 호스트 텍스트는 이미 "분할 표 첫 부분" 경로에서 렌더됨 → 이중 렌더 방지.
                    let strip =
                        crate::renderer::text_anchor_square_table_strip(para).or_else(|| {
                            crate::renderer::empty_host_square_table_left_strip(
                                para,
                                px_to_hwpunit(col_area.width, self.dpi),
                            )
                        });
                    let (strip_x, strip_width) = strip
                        .map(|(cs, sw)| {
                            (
                                col_area.x + hwpunit_to_px(cs, self.dpi),
                                hwpunit_to_px(sw, self.dpi),
                            )
                        })
                        .unwrap_or((wrap_text_x, wrap_text_width));
                    let content_offset = if let Some(mt) = pt_mt {
                        mt.range_height(0, start_row)
                    } else {
                        0.0
                    };
                    let tbl_x_right = compute_square_wrap_tbl_x_right(t, col_area, self.dpi);
                    self.layout_wrap_around_paras(
                        tree,
                        col_node,
                        paragraphs,
                        composed,
                        styles,
                        col_area,
                        page_content.section_index,
                        para_index,
                        wrap_around_paras,
                        pt_y_before,
                        y_offset,
                        wrap_text_x,
                        wrap_text_width,
                        strip_x,
                        strip_width,
                        strip.is_none(),
                        content_offset,
                        bin_data_content,
                        Some(tbl_x_right),
                    );
                }
            }
        }
        y_offset
    }

    /// Shape PageItem 레이아웃 (layout_column_item에서 분리)
    #[allow(clippy::too_many_arguments)]
    #[allow(clippy::too_many_arguments)]
    fn layout_shape_item(
        &self,
        tree: &mut PageLayoutContext,
        col_node: &mut RenderNode,
        paper_images: &mut Vec<RenderNode>,
        para_start_y: &mut std::collections::HashMap<usize, f64>,
        // [Task #1151 v9 결함 D] sibling TAC picture 가로 분배 cursor state.
        para_inline_state: &mut std::collections::HashMap<
            usize,
            super::layout::paragraph_layout::ParaInlineState,
        >,
        para_index: usize,
        control_index: usize,
        ctx: &ColumnItemCtx,
        y_offset: f64,
    ) -> f64 {
        let ColumnItemCtx {
            page_content,
            paragraphs,
            composed,
            styles,
            bin_data_content,
            layout,
            col_area,
            wrap_around_paras,
            wrap_anchors,
            ..
        } = ctx;
        // Task #402: 같은 paragraph 안에 TAC 컨트롤(표/그림/도형) 2개 이상이 서로 다른 line에
        // 배치된 경우, 두 번째 이후의 그림은 paragraph 시작 y가 아니라 진행된 y_offset
        // (선행 TAC 후속 위치)에 그려져야 표와 겹치지 않는다. control_index 이전에 같은
        // paragraph의 TAC 컨트롤이 있고 y_offset이 기존 등록값보다 진행됐으면 갱신한다.
        //
        // [Task #1151 v9 결함 D] sibling TAC picture 만 있는 경우 (= 가로 분배 시나리오) 는
        // para_start_y 갱신 X — picture 의 y 는 line_top_y 로 동일 유지. has_prior_tac 의
        // 종류를 Table/Shape vs Picture 로 분리하여 picture-only 시퀀스에서 y 진행을 차단.
        let has_prior_non_picture_tac = paragraphs
            .get(para_index)
            .map(|p| {
                p.controls.iter().take(control_index).any(|c| match c {
                    Control::Table(t) => t.common.treat_as_char,
                    Control::Shape(s) => s.common().treat_as_char,
                    _ => false,
                })
            })
            .unwrap_or(false);
        let has_prior_tac_picture = paragraphs
            .get(para_index)
            .map(|p| {
                p.controls.iter().take(control_index).any(|c| match c {
                    Control::Picture(p) => p.common.treat_as_char,
                    _ => false,
                })
            })
            .unwrap_or(false);
        if has_prior_non_picture_tac {
            // 선행 TAC Table/Shape 가 있는 경우만 진행된 y_offset 으로 갱신.
            let needs_update = para_start_y
                .get(&para_index)
                .map(|&existing| y_offset > existing + 1.0)
                .unwrap_or(true);
            if needs_update {
                para_start_y.insert(para_index, y_offset);
            }
        } else if !has_prior_tac_picture {
            // 첫 picture (선행 TAC picture 도 Table/Shape 도 없음): paragraph 시작 y 등록.
            para_start_y.entry(para_index).or_insert(y_offset);
        }
        // 선행 picture 만 있는 경우 (has_prior_tac_picture && !has_prior_non_picture_tac):
        // para_start_y 의 기존 값 유지 — 가로 분배의 첫 picture y 와 동일.
        let mut result_y = y_offset;
        if let Some(para) = paragraphs.get(para_index) {
            if let Some(ctrl) = para.controls.get(control_index) {
                if let Control::Picture(pic) = ctrl {
                    if pic.common.treat_as_char {
                        let (pic_w, pic_h) = self.resolve_inline_picture_size(pic, col_area);
                        // [#6603] 줄 안 폭·높이는 바깥 여백을 포함한 상자로 세고, 잉크는
                        // 상자의 (왼쪽, 위) 여백 안쪽에 그린다 (paragraph_layout 과 같은 계약).
                        let (margin_left, margin_right, margin_top, margin_bottom) =
                            super::layout::paragraph_layout::tac_picture_outer_margins_px(
                                pic, self.dpi,
                            );
                        let box_w = pic_w + margin_left + margin_right;
                        let box_h = pic_h + margin_top + margin_bottom;
                        // 같은 paragraph 의 sibling wrap=TopAndBottom 개체(tac=false)가
                        // 차지하는 vertical 영역만큼 picture y 보정.
                        let sibling_reserved_hu =
                            super::layout::paragraph_layout::calc_sibling_topandbottom_reserved_hu(
                                &para.controls,
                            );
                        let sibling_reserved_px = hwpunit_to_px(sibling_reserved_hu, self.dpi);

                        // [Task #1151 v9 결함 D] sibling TAC picture 시퀀스 위치 판별.
                        // 한컴 native 정합: 동일 paragraph 안 sibling tac=true picture 들이
                        // 가로로 inline 분배 (inline glyph 처럼).
                        let tac_pic_seq: Vec<(usize, f64)> = para
                            .controls
                            .iter()
                            .enumerate()
                            .filter_map(|(ci, control)| match control {
                                Control::Picture(sibling) if sibling.common.treat_as_char => {
                                    let (ml, mr, _, _) =
                                        super::layout::paragraph_layout::tac_picture_outer_margins_px(
                                            sibling, self.dpi,
                                        );
                                    Some((
                                        ci,
                                        self.resolve_inline_picture_size(sibling, col_area).0
                                            + ml
                                            + mr,
                                    ))
                                }
                                _ => None,
                            })
                            .collect();
                        let position_in_seq =
                            tac_pic_seq.iter().position(|(ci, _)| *ci == control_index);
                        let is_single_pic = tac_pic_seq.len() == 1;
                        let is_first_in_seq = position_in_seq == Some(0);
                        let is_subsequent_in_seq = position_in_seq.map(|p| p > 0).unwrap_or(false);
                        let is_last_in_seq = position_in_seq
                            .map(|p| p == tac_pic_seq.len() - 1)
                            .unwrap_or(false);

                        // pic_y 결정:
                        // - 단일 picture / 시퀀스 첫 picture: paragraph 시작 y + sibling_reserved
                        //   + 라벨/그림 높이 정합 보정
                        // - 시퀀스 후속 picture: state.line_top_y (pic_x wrap 처리 후 결정 — 아래)
                        // [Task #1151 v9 결함 D fix] pic_y 의 시퀀스 후속 picture 결정은 pic_x
                        // (wrap 처리 포함) 뒤로 옮김. 그 전에는 placeholder 로 default 값 사용.
                        let _ = is_single_pic;
                        let comp = composed.get(para_index);
                        // sibling 자리차지 표 예약은 통짜 배치 가정이다 — 표가 분할
                        // 이월된 쪽에서는 "문단 시작 + 전체 표 높이"가 단 하단을 넘어
                        // tac 그림이 쪽 밖에 그려진다(재현 문서 A 셀 Enter: 로고만
                        // 쪽 하단 밖). 그때는 흐름 y(분할 조각·후행 텍스트 뒤)로
                        // 폴백한다.
                        let para_y_for_pic = {
                            let reserved_based =
                                para_start_y.get(&para_index).copied().unwrap_or(y_offset)
                                    + sibling_reserved_px;
                            if sibling_reserved_px > 0.0
                                && reserved_based > col_area.y + col_area.height + 60.0
                            {
                                y_offset
                            } else {
                                reserved_based
                            }
                        };
                        let default_pic_y = self.compute_tac_picture_shape_y(
                            para,
                            comp,
                            styles,
                            para_y_for_pic,
                            pic_h,
                        );
                        let para_style_id = comp
                            .map(|c| c.para_style_id as usize)
                            .unwrap_or(para.para_shape_id as usize);
                        let para_style_ref = styles.para_styles.get(para_style_id);
                        let para_alignment = para_style_ref
                            .map(|s| s.alignment)
                            .unwrap_or(Alignment::Left);
                        // Task #347: 첫 줄 effective_margin (hanging indent: indent<0 → first-line은 margin_left만 적용)
                        let para_margin_left = para_style_ref.map(|s| s.margin_left).unwrap_or(0.0);
                        let para_indent = para_style_ref.map(|s| s.indent).unwrap_or(0.0);
                        // [Task #544 v2 정합] paragraph_layout.rs (a30dca73, Task #544 v2 Stage 2)
                        // 는 has_visible_stroke / bs_left_px / bs_right_px 를 보고
                        // box_margin_left 를 inner padding 으로 한 번 더 가산하던 분기를
                        // 이중 inset 부작용으로 판단해 완전히 제거했다 (margin_left =
                        // box_margin_left 단일 룰, PDF 정합 확인됨). 본 TAC picture/shape
                        // 경로는 그 수정이 반영되지 않아 테두리 있는 문단(has_visible_stroke)
                        // + border_spacing[0]=[1]=0 조건에서 그림이 같은 문단의 텍스트보다
                        // para_margin_left 만큼 더 오른쪽으로 밀리는 결함이 있었다
                        // (exam_kor.hwp p18/pi=46,50,54,56... 실측 확인 — inner_pad_left=11.33px
                        // 만큼 이중 가산). paragraph_layout.rs 와 동일하게 가산 없이 통일한다.
                        let mut effective_margin_left =
                            tac_picture_effective_margin_left(para_margin_left, para_indent);
                        // [Task #534 v2] LINE_SEG.column_start 는 Square wrap 인라인 표/그림이
                        // 좌측에 floating 시 표 영역 이후 텍스트 시작 위치를 HWP IR 가 인코딩.
                        // layout_shape_item 은 col_area.x 그대로 사용 → picture (TAC) 가 표
                        // 영역 위에 겹쳐 표시되는 결함 (예: exam_kor p18 pi=50/56 [A]/[B]
                        // 표시기 + 그림). cs 가 effective_margin_left 보다 크면 cs 우선.
                        let line_seg_cs_px = para
                            .line_segs
                            .first()
                            .map(|s| hwpunit_to_px(s.column_start, self.dpi))
                            .unwrap_or(0.0);
                        if line_seg_cs_px > effective_margin_left {
                            effective_margin_left = line_seg_cs_px;
                        }
                        let para_margin_right =
                            para_style_ref.map(|s| s.margin_right).unwrap_or(0.0);
                        let avail_w =
                            (col_area.width - effective_margin_left - para_margin_right).max(box_w);
                        // [Task #1151 v9 결함 D] pic_x 결정:
                        // - 단일 picture: 기존 alignment 그대로
                        // - 시퀀스 첫 picture: total_tac_width 기반 alignment + state 초기화
                        // - 시퀀스 후속 picture: state.cursor_x 사용 (가로 누적)
                        let pic_x = if is_subsequent_in_seq {
                            let cur = para_inline_state
                                .get(&para_index)
                                .map(|s| s.cursor_x)
                                .unwrap_or(col_area.x + effective_margin_left);
                            let line_right = col_area.x + effective_margin_left + avail_w;
                            // [Task #1151 v9 Stage 24] line wrap: cursor_x + pic_w > avail 면
                            // 다음 line 으로 wrap (cursor_x reset, line_top_y advance).
                            if cur + box_w > line_right + 0.5 {
                                if let Some(state) = para_inline_state.get_mut(&para_index) {
                                    state.cursor_x = col_area.x + effective_margin_left;
                                    state.line_top_y += state.line_height;
                                    state.line_height = 0.0;
                                }
                                col_area.x + effective_margin_left
                            } else {
                                cur
                            }
                        } else if is_first_in_seq && !is_single_pic {
                            // 시퀀스 첫 picture: 전체 시퀀스 폭 기반 alignment.
                            let total_tac_width: f64 = tac_pic_seq.iter().map(|(_, w)| w).sum();
                            let align_offset = match para_alignment {
                                Alignment::Center | Alignment::Distribute => {
                                    (avail_w - total_tac_width).max(0.0) / 2.0
                                }
                                Alignment::Right => (avail_w - total_tac_width).max(0.0),
                                _ => 0.0,
                            };
                            col_area.x + effective_margin_left + align_offset
                        } else {
                            // 단일 picture (기존 경로): 기존 alignment 그대로.
                            match para_alignment {
                                Alignment::Center | Alignment::Distribute => {
                                    col_area.x
                                        + effective_margin_left
                                        + (avail_w - box_w).max(0.0) / 2.0
                                }
                                Alignment::Right => {
                                    col_area.x + effective_margin_left + (avail_w - box_w).max(0.0)
                                }
                                _ => col_area.x + effective_margin_left,
                            }
                        };

                        // [Task #1151 v9 결함 D fix] pic_y 의 시퀀스 후속 picture 결정 —
                        // pic_x wrap 처리 후 갱신된 state.line_top_y 사용 (wrap 시 진행됨).
                        let pic_y = if is_subsequent_in_seq {
                            para_inline_state
                                .get(&para_index)
                                .map(|s| s.line_top_y)
                                .unwrap_or(default_pic_y)
                        } else {
                            default_pic_y
                        };

                        // Task #347: paragraph_layout이 호출되지 않는 빈 문단(텍스트 없음 +
                        // TAC 그림만 있는 경우)에서는 인라인 그림이 누락되어
                        // 박스 프레임 시각이 사라지고 후속 InFrontOfText 표가 위로 겹침.
                        // 호스트 문단에 실제 텍스트가 없으면 여기서 직접 이미지 노드를 생성하고
                        // y_offset을 그림 높이만큼 진행시킨다.
                        let has_real_text =
                            para.text.chars().any(|c| c > '\u{001F}' && c != '\u{FFFC}');
                        let has_full_para_item = page_content.column_contents.iter().any(|cc| {
                            cc.items.iter().any(|it| {
                                matches!(
                                    it,
                                    PageItem::FullParagraph { para_index: pi }
                                        if *pi == para_index
                                )
                            })
                        });
                        // [Task #418/#376] paragraph_layout 의 빈 문단 + TAC Picture 분기에서
                        // 이미 ImageNode 가 emit 되어 inline_shape_position 이 등록된 경우,
                        // 여기서 또 push 하면 이중 emit 이 된다. 등록된 경우 push 를 스킵하고
                        // result_y 만 갱신한다.
                        //
                        // [Task #1452 Stage 6] FullParagraph 가 있는 문단은 paragraph_layout 이
                        // TAC 그림을 줄 안에 배치한다. 위치 등록이 아직 안 보이는 순서여도
                        // Shape fallback 을 그리면 같은 투명 그림이 한 번 더 합성된다.
                        let registered_inline_pos = tree.get_inline_shape_position(
                            page_content.section_index,
                            para_index,
                            control_index,
                            None,
                        );
                        let already_registered = registered_inline_pos.is_some();
                        let effective_pic_y = registered_inline_pos
                            .map(|(_, registered_y)| registered_y)
                            .unwrap_or(pic_y);
                        // paragraph_layout 이 이미 emit 한 인라인 그림은 실제 bbox 높이와 같은
                        // common.height 기준으로 content bottom 을 판정한다.
                        let effective_pic_h = if already_registered {
                            hwpunit_to_px(pic.common.height as i32, self.dpi)
                        } else {
                            pic_h
                        };
                        // [Task #1151 v9 결함 D] state 갱신 — 가로 분배 cursor 누적.
                        // 첫 picture 시 line_top_y / cursor_x 초기화. 후속 picture 마다 cursor_x 가산.
                        if !is_single_pic {
                            let entry = para_inline_state.entry(para_index).or_insert(
                                super::layout::paragraph_layout::ParaInlineState {
                                    cursor_x: pic_x + box_w,
                                    line_top_y: pic_y,
                                    line_height: box_h,
                                },
                            );
                            if is_subsequent_in_seq {
                                entry.cursor_x = pic_x + box_w;
                                entry.line_height = entry.line_height.max(box_h);
                            } else {
                                // 첫 picture: 초기화 (기존 값 덮어쓰기)
                                entry.cursor_x = pic_x + box_w;
                                entry.line_top_y = pic_y;
                                entry.line_height = box_h;
                            }
                        }

                        if !already_registered && !has_full_para_item {
                            let bin_data_id = pic.image_attr.bin_data_id;
                            let image_data = find_bin_data_bytes(bin_data_content, bin_data_id);
                            let crop = pic.render_crop_rect();
                            let original_size_hu = pic.crop_reference_size();
                            let img_id = tree.next_id();
                            let img_node = RenderNode::new(
                                img_id,
                                RenderNodeType::Image(ImageNode {
                                    section_index: Some(page_content.section_index),
                                    para_index: Some(para_index),
                                    control_index: Some(control_index),
                                    crop,
                                    original_size_hu,
                                    effect: pic.image_attr.effect,
                                    brightness: pic.image_attr.brightness,
                                    contrast: pic.image_attr.contrast,
                                    opacity: pic.image_attr.opacity(),
                                    transform: utils::extract_shape_transform(&pic.shape_attr),
                                    // [Issue #1167] wrap 모드 보존 — SVG plane multi-pass z-order
                                    // 판별에 사용 (BehindText 워터마크가 본문 뒤로). PaintOp
                                    // 경로(skia/canvaskit)는 별도로 image.text_wrap 을 set 하므로 무관.
                                    text_wrap: Some(pic.common.text_wrap),
                                    external_path: pic.image_attr.external_path.clone(),
                                    content_inset: utils::picture_content_inset(pic),
                                    ..ImageNode::new(bin_data_id, image_data)
                                }),
                                BoundingBox::new(
                                    pic_x + margin_left,
                                    pic_y + margin_top,
                                    pic_w,
                                    pic_h,
                                ),
                            );
                            // Task #347: 같은 문단의 InFrontOfText 표가 이미 렌더되어
                            // col_node.children에 들어있으면 그 앞에 끼워넣어 z-order 보존
                            // (인라인 TAC 그림은 박스 프레임 시각이고 InFrontOfText 표가
                            //  본문 콘텐츠로 그 위에 그려져야 함).
                            let insert_pos = col_node.children.iter().position(|c| {
                                matches!(&c.node_type, RenderNodeType::Table(t)
                                    if t.para_index == Some(para_index))
                            });
                            if let Some(pos) = insert_pos {
                                col_node.children.insert(pos, img_node);
                            } else {
                                col_node.children.push(img_node);
                            }
                            // 후속 InFrontOfText 객체의 para_y 기준이 되도록 위치 등록
                            tree.set_inline_shape_position(
                                page_content.section_index,
                                para_index,
                                control_index,
                                None,
                                pic_x + margin_left,
                                pic_y + margin_top,
                            );
                            if !has_real_text {
                                // [Task #462] LINE_SEG 의 lh+ls 를 advance 로 사용 — 이미지 박스
                                // 높이만 사용하면 leading + line_spacing 이 누락되어 다음 문단이
                                // 그림 바로 아래에 붙음. max(pic_h) 는 LINE_SEG 가 비정상적으로
                                // 작은 경우의 안전장치.
                                // [Task #1151 v9 결함 D] 가로 분배 시퀀스의 중간 picture 는 result_y
                                // 진행 안 함 (y_offset 유지). 시퀀스 마지막 picture 또는 단일 picture
                                // 에서만 advance — 다음 paragraph 가 가로 분배 영역 아래로 진행.
                                if !has_full_para_item {
                                    let line_advance = para
                                        .line_segs
                                        .first()
                                        .map(|ls| {
                                            hwpunit_to_px(
                                                ls.line_height + ls.line_spacing,
                                                self.dpi,
                                            )
                                        })
                                        .unwrap_or(pic_h);
                                    if is_single_pic || is_last_in_seq {
                                        // 시퀀스 마지막: state 의 line_height (시퀀스 최대 height) 기반 advance
                                        let line_top_y = para_inline_state
                                            .get(&para_index)
                                            .map(|s| s.line_top_y)
                                            .unwrap_or(pic_y);
                                        let line_height = para_inline_state
                                            .get(&para_index)
                                            .map(|s| s.line_height)
                                            .unwrap_or(pic_h);
                                        result_y = line_top_y + line_advance.max(line_height);
                                    }
                                    // 중간 picture: result_y = y_offset (그대로 유지, line 4527 의 default)
                                }
                            }
                        } else if !has_real_text && !has_full_para_item {
                            // [Task #418/#376] paragraph_layout 가 이미 emit 함 — push 스킵, result_y 만 갱신
                            // [Task #462] 동일하게 LINE_SEG 기반 advance 사용
                            // [Task #1151 v9 결함 D] 가로 분배 시퀀스의 중간 picture 는 result_y
                            // 진행 안 함 (y_offset 유지). 시퀀스 마지막 picture 또는 단일 picture
                            // 에서만 advance — 다음 paragraph 가 가로 분배 영역 아래로 진행.
                            let line_advance = para
                                .line_segs
                                .first()
                                .map(|ls| hwpunit_to_px(ls.line_height + ls.line_spacing, self.dpi))
                                .unwrap_or(pic_h);
                            if is_single_pic || is_last_in_seq {
                                // 시퀀스 마지막: state 의 line_height (시퀀스 최대 height) 기반 advance
                                let line_top_y = para_inline_state
                                    .get(&para_index)
                                    .map(|s| s.line_top_y)
                                    .unwrap_or(pic_y);
                                let line_height = para_inline_state
                                    .get(&para_index)
                                    .map(|s| s.line_height)
                                    .unwrap_or(pic_h);
                                result_y = line_top_y + line_advance.max(line_height);
                            }
                            // 중간 picture: result_y = y_offset (그대로 유지, line 4527 의 default)
                        }

                        let mut pic_content_bottom = effective_pic_y + effective_pic_h;
                        if let Some(ref caption) = pic.caption {
                            use crate::model::shape::CaptionDirection;
                            let caption_spacing = hwpunit_to_px(caption.spacing as i32, self.dpi);
                            let caption_h = self.calculate_caption_height(&pic.caption, styles);
                            // 캡션은 실제로 그려진 그림 상자 바로 아래에 붙는다.
                            // `effective_pic_y` 는 emit 된 ImageNode 의 상단이므로 상자 바닥은
                            // 그 높이를 더한 값이다. 종전에는 상단에 `max(baseline, 높이)` 를
                            // 더했는데, 저장 줄이 그림+캡션을 통째로 예약해 baseline 이 그림보다
                            // 큰 줄에서는 (baseline − 그림 높이)만큼 캡션이 내려가 줄을 넘고,
                            // 그 아래 내용이 전부 밀렸다 (156489219 5쪽: 캡션 +25.5pt, 뒤따르는
                            // 표·그림 +17.9pt). 보통 줄은 baseline < 그림 높이라 두 식이 같다.
                            let image_bottom = effective_pic_y + effective_pic_h;
                            let cap_y = match caption.direction {
                                CaptionDirection::Bottom => image_bottom + caption_spacing,
                                CaptionDirection::Top => effective_pic_y,
                                _ => image_bottom + caption_spacing,
                            };
                            if caption.direction == CaptionDirection::Top {
                                let dy = caption_h + caption_spacing;
                                Self::offset_inline_image_y(
                                    col_node,
                                    para_index,
                                    control_index,
                                    dy,
                                );
                            }
                            let cell_ctx = CellContext {
                                in_textbox: false,
                                parent_para_index: para_index,
                                path: vec![CellPathEntry {
                                    control_index,
                                    cell_index: 0,
                                    cell_para_index: 0,
                                    text_direction: 0,
                                }],
                            };
                            self.layout_caption(
                                tree,
                                col_node,
                                caption,
                                styles,
                                col_area,
                                pic_x,
                                pic_w,
                                cap_y,
                                &mut self.auto_counter.borrow_mut(),
                                bin_data_content,
                                Some(cell_ctx),
                                CaptionOwner::new(
                                    Some(page_content.section_index),
                                    Some(para_index),
                                    Some(control_index),
                                    CaptionControlKind::Image,
                                ),
                            );
                            // [Task #864 Stage F] caption 이 차지한 영역까지 result_y 진행.
                            // 미진행 시 다음 paragraph 가 caption 위에 그려져 겹침
                            // (HWP3 sample14 page 4 "Visual Block을 이용한 대소문자 변경"
                            // 가 본문 "먼저 원하는 구간을..." 와 겹침). Bottom 만 진행 (Top
                            // 은 위에서 offset_inline_image_y 로 image 전체를 밀어서 처리).
                            //
                            // [Task #957] 빈 caption (text 없음 + controls 없음) 은 SVG 에 invisible.
                            // pic_y = para_start_y[para_idx] 가 has_prior_tac 로 인해 후속 위치로
                            // 갱신되면 image_bottom = pic_y + pic_h 가 페이지 바깥 위치로 계산되어
                            // result_y 가 phantom +caption_h 만큼 누적 → 후속 paragraph 가 다음
                            // 페이지로 밀림 (sample16 page 18 pi=394 ci=1 "그림" 의 empty caption
                            // 으로 +430.6px advance). 빈 caption 은 advance skip.
                            let caption_is_empty = caption.paragraphs.iter().all(|p| {
                                p.text.chars().all(|c| c <= '\u{001F}' || c == '\u{FFFC}')
                                    && p.controls.is_empty()
                            });
                            if !caption_is_empty
                                && matches!(caption.direction, CaptionDirection::Bottom)
                            {
                                let cap_bottom = cap_y + caption_h;
                                if cap_bottom > result_y {
                                    result_y = cap_bottom;
                                }
                                pic_content_bottom = pic_content_bottom.max(cap_bottom);
                            }
                        }
                        let prev_bottom = self.last_item_content_bottom.get();
                        self.last_item_content_bottom
                            .set(if prev_bottom.is_finite() {
                                prev_bottom.max(pic_content_bottom)
                            } else {
                                pic_content_bottom
                            });
                    } else {
                        let is_paper_based = (pic.common.vert_rel_to == VertRelTo::Paper
                            || pic.common.vert_rel_to == VertRelTo::Page)
                            && (pic.common.horz_rel_to == HorzRelTo::Paper
                                || pic.common.horz_rel_to == HorzRelTo::Page);
                        if is_paper_based {
                            let mut temp_parent = RenderNode::new(
                                tree.next_id(),
                                RenderNodeType::Column(0),
                                BoundingBox::new(0.0, 0.0, layout.page_width, layout.page_height),
                            );
                            let paper_area = LayoutRect {
                                x: 0.0,
                                y: 0.0,
                                width: layout.page_width,
                                height: layout.page_height,
                            };
                            let _ = self.layout_body_picture(
                                tree,
                                &mut temp_parent,
                                pic,
                                &paper_area,
                                col_area,
                                &layout.body_area,
                                &paper_area,
                                bin_data_content,
                                styles,
                                Alignment::Left,
                                0.0,
                                page_content.section_index,
                                para_index,
                                control_index,
                                false,
                            );
                            let layer = Self::render_layer_from_common(
                                &pic.common,
                                para_index,
                                control_index,
                            );
                            Self::push_layered_paper_children(
                                paper_images,
                                &mut temp_parent,
                                layer,
                            );
                        } else {
                            let comp = composed.get(para_index);
                            let para_style_id = comp
                                .map(|c| c.para_style_id as usize)
                                .unwrap_or(para.para_shape_id as usize);
                            let para_style = styles.para_styles.get(para_style_id);
                            let alignment =
                                para_style.map(|s| s.alignment).unwrap_or(Alignment::Left);
                            let deferred_page_start_square = wrap_anchors
                                .values()
                                .any(|anchor| anchor.anchor_para_index == para_index)
                                && page_content.column_contents.iter().any(|column| {
                                    matches!(
                                        column.items.first(),
                                        Some(PageItem::Shape {
                                            para_index: item_pi,
                                            control_index: item_ci,
                                        }) if *item_pi == para_index && *item_ci == control_index
                                    ) && deferred_page_start_square_picture_uses_body_top(
                                        column,
                                        0,
                                        paragraphs,
                                        para_index,
                                        control_index,
                                    )
                                });
                            // [#6704] 앵커 문단이 앞 쪽/단에서 이어진 조각이면
                            // `para_start_y` 는 그 문단의 시작이 아니라 이 쪽에서 흐름이
                            // 도달한 자리다. Para 기준 개체는 흐름에서 빠져 있으므로 그
                            // 자리를 쓰면 앞 항목이 흘린 만큼 그대로 내려간다 —
                            // hwp3-sample 7쪽 그림이 +85.6px. 한/글은 넘어온 쪽의 본문
                            // 맨 위를 기준으로 삼는다.
                            //
                            // 본문 흐름은 같은 규칙을 이미 지킨다(layout.rs 의
                            // `PartialParagraph { start_line > 0 }` 분기: "이어지는 partial
                            // paragraph 는 이전 쪽/단에서 시작한 문단의 나머지다"). 여기서는
                            // 그 규칙을 개체 앵커에 연결한다.
                            let anchor_starts_on_earlier_page = ctx
                                .page_content
                                .column_contents
                                .iter()
                                .flat_map(|cc| cc.items.iter())
                                .any(|it| {
                                    matches!(it,
                                        PageItem::PartialParagraph { para_index: q, start_line, .. }
                                            if *q == para_index && *start_line > 0)
                                });
                            let para_base_y = if anchor_starts_on_earlier_page {
                                ctx.col_area.y
                            } else {
                                para_start_y.get(&para_index).copied().unwrap_or(y_offset)
                            };
                            if std::env::var("RHWP_5715_DBG").is_ok() {
                                eprintln!(
                                    "[5715] pi={para_index} ci={control_index} base={para_base_y:.1} from_map={} y_off={y_offset:.1}",
                                    para_start_y.contains_key(&para_index)
                                );
                            }
                            let para_base_y = if deferred_page_start_square {
                                // next-page owner의 `vpos=0` narrow band는 새 physical
                                // page의 body top을 가리킨다. layout_body_picture가
                                // para-relative offset을 한 번 적용하므로 source offset을
                                // 여기서 상쇄한다 (#3820 p127 Figure 56).
                                para_base_y
                                    - hwpunit_to_px(pic.common.vertical_offset as i32, self.dpi)
                            } else {
                                para_base_y
                            };
                            let pic_y = if matches!(
                                pic.common.text_wrap,
                                crate::model::shape::TextWrap::Square
                            ) && matches!(
                                pic.common.vert_rel_to,
                                crate::model::shape::VertRelTo::Para
                            ) {
                                square_wrap_first_narrow_line_vpos_px(para, col_area, self.dpi)
                                    .map(|dy| para_base_y + dy)
                                    .unwrap_or(para_base_y)
                            } else {
                                para_base_y
                            };
                            let saved_y_offset = y_offset;
                            // [Task #1079] 파일 vpos 가 이미 그림 공간을 반영(그림 para 줄 앞
                            // gap ≥ 그림 높이)하면 그림 높이 추가 진행 생략(typeset pushdown
                            // 게이트와 동일 조건). #409 계열(gap 작음)은 현행 유지.
                            // [편집 세션] 이 게이트의 근거(파일 vpos gap)는 저장
                            // 시점 형상이다 — 셀 편집으로 앞 문단(표 host)이 자라면
                            // gap 은 이미 소비된 공간이라, 그림을 gap 안(base 위)으로
                            // 올리면 커진 표 하단에 겹친다(셀 Enter 재현: 그림이
                            // 표 하단 위에 그려짐).
                            let vpos_accounts_for_height =
                                !self.profile.get().session_edited() && para_index > 0 && {
                                    const PUSHDOWN_GAP_TOL_PX: f64 = 8.0;
                                    let obj_h = hwpunit_to_px(pic.common.height as i32, self.dpi);
                                    let v_cur = paragraphs[para_index]
                                        .line_segs
                                        .first()
                                        .map(|s| s.vertical_pos);
                                    let prev_end = paragraphs[para_index - 1]
                                        .line_segs
                                        .last()
                                        .map(|s| s.vertical_pos + s.line_height);
                                    match (v_cur, prev_end) {
                                        (Some(vc), Some(pe)) if vc > pe => {
                                            hwpunit_to_px((vc - pe) as i32, self.dpi)
                                                >= obj_h - PUSHDOWN_GAP_TOL_PX
                                        }
                                        _ => false,
                                    }
                                };
                            // [#5715] #1079 gap 휴리스틱은 그 gap 이 **현재 쪽에 물리적으로
                            // 실재**할 때만 유효하다. 쪽 리셋 뒤 유령 사다리(앞 lineage 의
                            // vpos 65410 이 리셋 0-기저 쪽에 섞임)가 만든 가짜 gap 이면
                            // 바닥-정렬이 그림을 단 상단 위로 밀어 지면 밖 소실이 된다
                            // (베트남노동시장1125: 124쪽 중 8쪽의 차트가 본문 위/지면 밖).
                            // 바닥-정렬 목표가 단 상단을 넘으면 기각하고, 같은 문단의 선행
                            // float(표)이 이미 진행시킨 흐름(y_offset) 뒤로 배치한다.
                            let (vpos_accounts_for_height, pic_y) = if vpos_accounts_for_height
                                && pic_y - hwpunit_to_px(pic.common.height as i32, self.dpi)
                                    < col_area.y - 0.5
                            {
                                (false, pic_y.max(y_offset))
                            } else {
                                (vpos_accounts_for_height, pic_y)
                            };
                            // 조판이 확정한 저장 그림 프레임은 실제 배치에서도 같은 앵커를 쓴다.
                            // 뒤 호스트 줄의 원점이나 그림 높이로 이 앵커를 다시 추정하지 않는다.
                            let stored_picture = ctx.paragraph_float_placements
                                .get(&(para_index, control_index))
                                .filter(|placement| matches!(placement.flow,
                                    super::float_placement::ParagraphFloatFlow::StoredPicture { .. })
                                    || (placement.flow == super::float_placement::ParagraphFloatFlow::Exclusion
                                        && placement.stored_host_origin.is_some()));
                            let (vpos_accounts_for_height, pic_y) = stored_picture
                                .map(|placement| (false, col_area.y + placement.anchor_y))
                                .unwrap_or((vpos_accounts_for_height, pic_y));
                            // typeset의 ObjectPlacementFrame과 같은 문단 좌우 여백을
                            // Para 기준 그림에도 준다. paint만 단 전체를 기준으로
                            // 두면 TIFF 그림과 캡션이 저장 1000HU만큼 왼쪽으로 간다
                            // (#7406 p61). 다른 상대 기준은 별도 column/body/paper다.
                            let para_margin_left = para_style.map_or(0.0, |s| s.margin_left);
                            let para_margin_right = para_style.map_or(0.0, |s| s.margin_right);
                            let pic_container = LayoutRect {
                                x: col_area.x + para_margin_left,
                                y: pic_y,
                                width: (col_area.width - para_margin_left - para_margin_right)
                                    .max(0.0),
                                height: col_area.height - (pic_y - col_area.y),
                            };
                            result_y = self.layout_body_picture(
                                tree,
                                col_node,
                                pic,
                                &pic_container,
                                col_area,
                                &layout.body_area,
                                &LayoutRect {
                                    x: 0.0,
                                    y: 0.0,
                                    width: layout.page_width,
                                    height: layout.page_height,
                                },
                                bin_data_content,
                                styles,
                                alignment,
                                pic_y,
                                page_content.section_index,
                                para_index,
                                control_index,
                                vpos_accounts_for_height,
                            );
                            if let Some(placement) = stored_picture {
                                result_y = col_area.y
                                    + placement.paragraph_end(saved_y_offset - col_area.y, 0.0);
                            }
                            // layout_body_picture needs the host paragraph y for Para-relative
                            // positioning, but InFront pictures must not rewind the
                            // already-advanced text flow cursor back to that paragraph y.
                            //
                            // Keep BehindText on the legacy non-advancing path. HWP5 files such
                            // as samples/복학원서.hwp use an empty first paragraph with a
                            // BehindText logo; preserving the advanced cursor there inserts an
                            // extra line-height before the following table.
                            if matches!(
                                pic.common.text_wrap,
                                crate::model::shape::TextWrap::InFrontOfText
                            ) {
                                result_y = saved_y_offset;
                            }
                            // A co-anchored fixed title needs the otherwise
                            // empty host's content line. Keep ordinary BehindText
                            // logo hosts on the legacy path described above.
                            if self.profile.get().hwp5_stored_pagination_layout() {
                                if let Some(floor) = anchor_box_flow::backdrop_title_host_floor(
                                    para,
                                    &pic.common,
                                    pic_y,
                                    self.dpi,
                                ) {
                                    result_y = result_y.max(floor.min(saved_y_offset));
                                }
                            }
                            // [Task #959] horz_rel_to=Column 의 picture 가 col_area 우측을
                            // 초과하는 위치에 emit 되면 한컴 viewer 는 column flow 에
                            // reservation 하지 않음. rhwp 는 cursor 를 picture height 만큼
                            // advance → 후속 paragraph 처짐.
                            // (3-11월_실전_통합_2022 page 1 우측 단 pi=69 picture
                            //  pic_emit_x=767 > col_right=759 → +274px advance → 문9 처짐)
                            // Picture 의 좌측 edge (x) 가 col_area 우측을 초과하면 advance skip.
                            if matches!(pic.common.horz_rel_to, HorzRelTo::Column) {
                                // [Issue #1230] emit 폭 판정은 layout_body_picture 와 동일한
                                // 프레임 크기를 사용해야 skip 판정이 실제 배치와 일치한다.
                                let (pic_width_hu, _) = picture_flow_frame_size_hu(pic);
                                let pic_width_px = hwpunit_to_px(pic_width_hu, self.dpi);
                                let h_offset_px =
                                    hwpunit_to_px(pic.common.horizontal_offset as i32, self.dpi);
                                let pic_emit_x = match pic.common.horz_align {
                                    crate::model::shape::HorzAlign::Left
                                    | crate::model::shape::HorzAlign::Inside => {
                                        col_area.x + h_offset_px
                                    }
                                    crate::model::shape::HorzAlign::Center => {
                                        col_area.x
                                            + (col_area.width - pic_width_px) / 2.0
                                            + h_offset_px
                                    }
                                    crate::model::shape::HorzAlign::Right
                                    | crate::model::shape::HorzAlign::Outside => {
                                        col_area.x + col_area.width - pic_width_px - h_offset_px
                                    }
                                };
                                if pic_emit_x >= col_area.x + col_area.width {
                                    result_y = saved_y_offset;
                                }
                            }
                            // [Task #683] 빈 paragraph (텍스트 없음) + Para-relative TopAndBottom
                            // 그림 (caption 없음) 의 layout 진행량 보정. 한컴 한글 2022 PDF 는
                            // 그림 다음에 paragraph 의 line baseline 1줄(line_height + line_spacing)
                            // 을 추가 진행하나 rhwp 기본 layout 은 image_height 만 진행하여
                            // cluster 거리가 1 line 부족 (pr-149.hwp 18864 HU vs 17280 HU 결함).
                            if matches!(
                                pic.common.text_wrap,
                                crate::model::shape::TextWrap::TopAndBottom
                            ) && matches!(
                                pic.common.vert_rel_to,
                                crate::model::shape::VertRelTo::Para
                            ) && pic.caption.is_none()
                                // 확정된 뒤 줄 원점은 호스트 점유를 이미 포함한다.
                                && stored_picture
                                    .and_then(|placement| placement.stored_successor_line_origin)
                                    .is_none()
                            {
                                let has_visible_text =
                                    para.text.chars().any(|c| c > '\u{001F}' && c != '\u{FFFC}');
                                // [#7470] host 줄이 그림 띠에 흡수된 빈 host(`sw=0`)는 더하지 않는다.
                                if !has_visible_text
                                    && (self.column_is_endnote_flow.get()
                                        || !crate::renderer::empty_host_line_absorbed_by_topbottom_float(
                                            para,
                                            &pic.common,
                                        ))
                                {
                                    let line_advance = para
                                        .line_segs
                                        .first()
                                        .map(|ls| {
                                            hwpunit_to_px(
                                                ls.line_height + ls.line_spacing,
                                                self.dpi,
                                            )
                                        })
                                        .unwrap_or(0.0);
                                    result_y += line_advance;
                                }
                            }
                            // Square wrap + Para-relative: 그림 높이로 column y를 밀지 않는다.
                            // 텍스트는 그림 옆에 segment_width로 제어되어 흐르므로
                            // 후속 문단은 앵커 단락 직후(shape item y_offset)부터 시작해야 한다.
                            // layout_body_picture의 y_offset은 pic_y(=단락 시작 y)이므로
                            // 반환값이 para_start_y로 거슬러 올라감 — 이를 shape item y로 복원.
                            if matches!(pic.common.text_wrap, crate::model::shape::TextWrap::Square)
                                && matches!(
                                    pic.common.vert_rel_to,
                                    crate::model::shape::VertRelTo::Para
                                )
                            {
                                result_y = y_offset;
                            }
                            // [Task #525] Picture Square wrap 의 호스트 paragraph 텍스트는
                            // 정상 PageItem::FullParagraph 경로 (layout_composed_paragraph 의
                            // has_picture_shape_square_wrap 분기, paragraph_layout.rs:822/973)
                            // 가 LINE_SEG.cs/sw 기반으로 그림 옆 (좁은) + 그림 아래 (넓은)
                            // 모두 처리. Task #604 Stage 2 의 wrap_anchors 메타데이터 채널
                            // 로 FullParagraph path 가 cs offset 을 정확히 적용하므로 별도 호출 불필요.
                        }
                    }
                } else if let Control::Shape(shape) = ctrl {
                    let common = shape.common();
                    if common.treat_as_char {
                        let has_real_text =
                            para.text.chars().any(|c| c > '\u{001F}' && c != '\u{FFFC}');
                        let registered_inline_pos = tree.get_inline_shape_position(
                            page_content.section_index,
                            para_index,
                            control_index,
                            None,
                        );
                        let already_registered = registered_inline_pos.is_some();

                        if !has_real_text {
                            let shape_w = hwpunit_to_px(common.width as i32, self.dpi);
                            let shape_h = hwpunit_to_px(common.height as i32, self.dpi);
                            // [Task #990] 해당 문단에 PageItem::FullParagraph 가
                            // 발행되었으면(빈 문단이 호스트인 RFP 형) layout_paragraph
                            // 가 이미 LINE_SEG advance 를 마쳤으므로, Shape 항목은
                            // 글상자를 호스트 문단 시작(para_start)에 배치하고 재진행
                            // 하지 않는다 — 이중 가산 방지(Task #974 c3e32151 회귀).
                            // FullParagraph 항목이 없으면(선행 표 등에 이어 붙은
                            // Shape, 예: hy-001 pi=27) Task #974 동작을 유지한다.
                            let has_full_para_item =
                                page_content.column_contents.iter().any(|cc| {
                                    cc.items.iter().any(|it| {
                                        matches!(
                                            it,
                                            PageItem::FullParagraph { para_index: pi }
                                                if *pi == para_index
                                        )
                                    })
                                });
                            let para_start =
                                para_start_y.get(&para_index).copied().unwrap_or(y_offset);
                            let shape_y = if let Some((_, registered_y)) = registered_inline_pos {
                                registered_y
                            } else if has_full_para_item {
                                para_start
                            } else {
                                y_offset
                            };

                            if !already_registered {
                                let comp = composed.get(para_index);
                                let para_style_id = comp
                                    .map(|c| c.para_style_id as usize)
                                    .unwrap_or(para.para_shape_id as usize);
                                let para_style_ref = styles.para_styles.get(para_style_id);
                                let para_alignment = para_style_ref
                                    .map(|s| s.alignment)
                                    .unwrap_or(Alignment::Left);
                                let para_margin_left =
                                    para_style_ref.map(|s| s.margin_left).unwrap_or(0.0);
                                let para_indent = para_style_ref.map(|s| s.indent).unwrap_or(0.0);
                                let para_margin_right =
                                    para_style_ref.map(|s| s.margin_right).unwrap_or(0.0);
                                let effective_margin_left = if para_indent > 0.0 {
                                    para_margin_left + para_indent
                                } else {
                                    para_margin_left
                                };
                                let avail_w =
                                    (col_area.width - effective_margin_left - para_margin_right)
                                        .max(shape_w);
                                let shape_x = match para_alignment {
                                    Alignment::Center | Alignment::Distribute => {
                                        col_area.x
                                            + effective_margin_left
                                            + (avail_w - shape_w).max(0.0) / 2.0
                                    }
                                    Alignment::Right => {
                                        col_area.x
                                            + effective_margin_left
                                            + (avail_w - shape_w).max(0.0)
                                    }
                                    _ => col_area.x + effective_margin_left,
                                };

                                tree.set_inline_shape_position(
                                    page_content.section_index,
                                    para_index,
                                    control_index,
                                    None,
                                    shape_x,
                                    shape_y,
                                );
                            }

                            // [Task #990] FullParagraph 항목이 없는 경우에만
                            // LINE_SEG 1회분을 진행한다. FullParagraph 가 있으면
                            // 이미 진행되었으므로 result_y(=y_offset)를 유지한다.
                            if !has_full_para_item {
                                // 텍스트 없는 호스트 문단에서 자리차지 개체는 하나가
                                // 한 줄을 차지한다. 그러니 진행분은 **이 개체의** 줄
                                // 이어야 하는데 first() 는 언제나 첫 줄이다. 같은
                                // 문단에 선행 자리차지 개체가 있으면(표+글상자 등)
                                // 앞 개체의 줄 높이로 전진해 그만큼 과전진한다
                                // (1351000 정책연구용역 중간보고서 pi=1920:
                                // ls[0] 표 449.9px 로 전진, 실제 도형 줄은 222.1px
                                // — 227.8px 과전진이 뒤따르는 문단 10개를 쪽 밖으로
                                // 밀어냈다). 선행 자리차지 개체 수를 줄 인덱스로 쓴다.
                                let line_idx = para
                                    .controls
                                    .iter()
                                    .take(control_index)
                                    .filter(|c| match c {
                                        Control::Table(t) => t.common.treat_as_char,
                                        Control::Picture(p) => p.common.treat_as_char,
                                        Control::Shape(s) => s.common().treat_as_char,
                                        _ => false,
                                    })
                                    .count();
                                let line_advance = para
                                    .line_segs
                                    .get(line_idx)
                                    .or_else(|| para.line_segs.first())
                                    .map(|ls| {
                                        hwpunit_to_px(ls.line_height + ls.line_spacing, self.dpi)
                                    })
                                    .unwrap_or(shape_h);
                                result_y = shape_y + line_advance.max(shape_h);
                            }
                            let prev_bottom = self.last_item_content_bottom.get();
                            let shape_bottom = shape_y + shape_h;
                            self.last_item_content_bottom
                                .set(if prev_bottom.is_finite() {
                                    prev_bottom.max(shape_bottom)
                                } else {
                                    shape_bottom
                                });
                        }
                    } else if !common.treat_as_char
                        && matches!(shape.as_ref(), ShapeObject::Ole(_))
                        && matches!(common.text_wrap, TextWrap::Square)
                        && matches!(common.vert_rel_to, VertRelTo::Para)
                    {
                        let has_visible_text =
                            para.text.chars().any(|c| c > '\u{001F}' && c != '\u{FFFC}');
                        if !has_visible_text {
                            let line_advance = para
                                .line_segs
                                .first()
                                .map(|ls| hwpunit_to_px(ls.line_height + ls.line_spacing, self.dpi))
                                .unwrap_or(0.0);
                            result_y = result_y.max(y_offset + line_advance);
                        }
                    } else if !common.treat_as_char
                        && matches!(
                            common.text_wrap,
                            crate::model::shape::TextWrap::TopAndBottom
                        )
                        && matches!(common.vert_rel_to, crate::model::shape::VertRelTo::Para)
                    {
                        // [Issue #1156] 비-TAC 자리차지(TopAndBottom) 객체(차트 OLE 등):
                        // 자리차지 객체는 본문 텍스트를 위/아래로 밀어내므로, 후속 콘텐츠
                        // 시작 y(result_y)를 객체 높이 + 아래 여백만큼 진행시켜 텍스트가
                        // 객체 영역과 겹치지 않게 한다. (typeset.rs Stage 2 의 current_height
                        // 가산과 layout 정합 — 단 이동 후 단 시작 y_offset 기준.)
                        let shape_h = hwpunit_to_px(common.height as i32, self.dpi);
                        let margin_bottom = hwpunit_to_px(common.margin.bottom as i32, self.dpi);
                        let advance = shape_h + margin_bottom;
                        if y_offset + advance > result_y {
                            result_y = y_offset + advance;
                        }
                    }
                }
            }
        }
        result_y
    }

    #[allow(clippy::too_many_arguments)]
    /// [#6128] Square 어울림 표에 딸린 문단들이 저장 좌표에서 표 앵커보다
    /// 얼마나 아래까지 내려오는지(px). 조판의
    /// `extend_square_band_to_source_bottom` 과 같은 식이다 — 그쪽은 흐름 예산,
    /// 이쪽은 페인트 커서를 같은 값으로 맞춘다.
    fn square_wrap_paras_source_bottom(
        paragraphs: &[Paragraph],
        wrap_around_paras: &[super::pagination::WrapAroundPara],
        table_para_index: usize,
        dpi: f64,
    ) -> Option<f64> {
        let anchor_top = paragraphs
            .get(table_para_index)?
            .line_segs
            .iter()
            .find(|seg| {
                seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0
            })?
            .vertical_pos;
        let mut bottom: Option<i32> = None;
        for wp in wrap_around_paras
            .iter()
            .filter(|wp| wp.table_para_index == table_para_index && wp.has_text)
        {
            let Some(para) = paragraphs.get(wp.para_index) else {
                continue;
            };
            let para_bottom = para
                .line_segs
                .iter()
                .filter(|seg| {
                    seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0
                })
                .map(|seg| {
                    seg.vertical_pos
                        .saturating_add(seg.line_height)
                        .saturating_add(seg.line_spacing)
                })
                .max();
            if let Some(para_bottom) = para_bottom {
                bottom = Some(bottom.map_or(para_bottom, |best: i32| best.max(para_bottom)));
            }
        }
        let bottom = bottom?;
        (bottom > anchor_top).then(|| hwpunit_to_px(bottom - anchor_top, dpi))
    }

    fn layout_wrap_around_paras(
        &self,
        tree: &mut PageLayoutContext,
        col_node: &mut RenderNode,
        paragraphs: &[Paragraph],
        composed: &[ComposedParagraph],
        styles: &ResolvedStyleSet,
        col_area: &LayoutRect,
        section_index: usize,
        table_para_index: usize,
        wrap_around_paras: &[super::pagination::WrapAroundPara],
        table_y_start: f64,
        table_y_end: f64,
        wrap_text_x: f64,
        wrap_text_width: f64,
        // [Task #1745] 후속 어울림 문단(WrapAroundPara)이 놓일 wrap 띠. 표 단독 anchor
        // 는 wrap_text_x/width 와 동일. 텍스트 혼합 anchor 는 표 geometry 로 도출한
        // 띠(text_anchor_square_table_strip) — host 영역(전폭)과 분리된다.
        strip_x: f64,
        strip_width: f64,
        // [Task #1745] 호스트 문단 텍스트 렌더 여부. 분할 표의 텍스트 혼합 anchor 는
        // 호스트 텍스트가 이미 일반 경로(분할 표 첫 부분)에서 렌더되므로 false 로
        // 이중 렌더를 막는다.
        render_host_text: bool,
        table_content_offset: f64,
        bin_data_content: &[BinDataContent],
        // Task #463: 인라인 floating 표(예: 인용 따옴표 ｢｣)의 우측 끝 x 좌표.
        // wrap host paragraph 의 외곽선이 이 표 위치까지 둘러싸도록 box 너비를
        // 확장하기 위해 caller 에서 계산하여 전달한다. None 이면 box 미확장.
        tbl_x_right: Option<f64>,
    ) {
        // 이 표에 연관된 어울림 문단만 필터링
        let related: Vec<_> = wrap_around_paras
            .iter()
            .filter(|wp| wp.table_para_index == table_para_index)
            .collect();

        let table_para = match paragraphs.get(table_para_index) {
            Some(p) => p,
            None => return,
        };
        // 표 문단의 LINE_SEG에서 기준 vertical_pos — 후속 어울림 문단 배치에만 쓴다.
        // 저장 줄이 없는 host 도 자기 글자는 아래에서 그려야 하므로 여기서 끝내지 않는다.
        let table_base_vpos = table_para.line_segs.first().map(|s| s.vertical_pos);

        // 어울림 텍스트 영역
        // Task #463: wrap_text_x 는 LINE_SEG.column_start 기반으로 paragraph
        // margin_left 를 이미 포함하지만, layout_composed_paragraph 가 col_area.x 에
        // margin_left 를 한 번 더 더하기 때문에 wrap host 텍스트가 한 단계 더
        // 들여쓰기 됨 (학생3 wrap host 가 학생1 보다 +margin_left 만큼 우측으로 밀림).
        // wrap_area.x 를 margin_left 만큼 좌측으로 보정하고 width 도 그만큼 확장.
        // (inner_pad 는 외곽선 안쪽 여백으로 wrap_cs 와 무관하므로 보정 대상 아님)
        let host_para_style = composed
            .get(table_para_index)
            .and_then(|c| styles.para_styles.get(c.para_style_id as usize));
        let host_margin_left = host_para_style.map(|s| s.margin_left).unwrap_or(0.0);
        let host_margin_right = host_para_style.map(|s| s.margin_right).unwrap_or(0.0);
        let wrap_area = LayoutRect {
            x: wrap_text_x - host_margin_left,
            y: col_area.y,
            width: wrap_text_width + host_margin_left + host_margin_right,
            height: col_area.height,
        };
        // [Task #1745] 후속 어울림 문단용 띠 영역 (표 단독 anchor 는 wrap_area 와 동일).
        let strip_area = LayoutRect {
            x: strip_x - host_margin_left,
            y: col_area.y,
            width: strip_width + host_margin_left + host_margin_right,
            height: col_area.height,
        };

        // 호스트 문단(표 문단) 텍스트를 어울림 영역에 렌더링
        let has_host_text = table_para
            .text
            .chars()
            .any(|c| c > '\u{001F}' && c != '\u{FFFC}');
        if table_content_offset == 0.0 && render_host_text {
            if has_host_text {
                if let Some(comp) = composed.get(table_para_index) {
                    let text_start_line = comp.lines.iter().position(|line| {
                        line.runs
                            .iter()
                            .any(|r| r.text.chars().any(|c| c > '\u{001F}' && c != '\u{FFFC}'))
                    });
                    if let Some(start_line) = text_start_line {
                        // 호스트 본문의 모든 텍스트 줄을 wrap 영역에 렌더링
                        // (Task #295: 자가 wrap host의 다중 줄 누락 수정)
                        let text_end_line = comp
                            .lines
                            .iter()
                            .rposition(|line| {
                                line.runs.iter().any(|r| {
                                    r.text.chars().any(|c| c > '\u{001F}' && c != '\u{FFFC}')
                                })
                            })
                            .map(|i| i + 1)
                            .unwrap_or(comp.lines.len());
                        // Task #463: wrap host 의 외곽선은 원래 col_area 너비로 그려야
                        // 인라인 floating 표(인용 따옴표 ｢｣ 등)를 박스가 둘러쌈. tbl_x_right
                        // 가 col_area 우측을 넘으면 그 위치까지 박스 너비를 확장한다.
                        let prev_override = self.border_box_override.get();
                        let extended_width = match tbl_x_right {
                            Some(tx) if tx > col_area.x + col_area.width => tx - col_area.x,
                            _ => col_area.width,
                        };
                        self.border_box_override
                            .set(Some((col_area.x, extended_width)));
                        self.layout_partial_paragraph(
                            tree,
                            col_node,
                            table_para,
                            Some(comp),
                            styles,
                            styles.hwp3_variant
                                && self.endnote_para_source_for(table_para_index).is_none(),
                            &wrap_area,
                            table_y_start,
                            start_line,
                            text_end_line,
                            section_index,
                            table_para_index,
                            None,
                            Some(bin_data_content),
                            None, // 표 호스트 어울림 문단 — 별도 wrap_anchor 메커니즘
                        );
                        self.border_box_override.set(prev_override);
                        // 어울림 문단은 항상 ↵ 표시 필요 — 부분 렌더링 시 is_para_end 강제 설정
                        force_para_end_on_last_run(col_node);
                    }
                }
            } else {
                // 호스트 문단에 텍스트 없음 (빈 문단 + 표): ↵ 마크 렌더링
                let seg = table_para.line_segs.first();
                let line_height = seg
                    .map(|s| crate::renderer::hwpunit_to_px(s.line_height, self.dpi))
                    .unwrap_or(13.3);
                let font_size = seg
                    .map(|s| crate::renderer::hwpunit_to_px(s.line_height, self.dpi))
                    .unwrap_or(13.3);
                let baseline = font_size * 0.8;
                let line_id = tree.next_id();
                let line_node = RenderNode::new(
                    line_id,
                    RenderNodeType::TextLine(TextLineNode::new(line_height, font_size)),
                    BoundingBox::new(wrap_text_x, table_y_start, font_size, line_height),
                );
                let run_id = tree.next_id();
                let run_node = RenderNode::new(
                    run_id,
                    RenderNodeType::TextRun(TextRunNode {
                        text: String::new(),
                        style: TextStyle {
                            font_family: "바탕".to_string(),
                            font_size,
                            color: 0x000000,
                            ..Default::default()
                        },
                        char_shape_id: None,
                        para_shape_id: None,
                        section_index: None,
                        para_index: Some(table_para_index),
                        char_start: None,
                        cell_context: None,
                        is_para_end: true,
                        is_line_break_end: false,
                        rotation: 0.0,
                        is_vertical: false,
                        char_overlap: None,
                        border_fill_id: 0,
                        baseline,
                        field_marker: FieldMarkerType::None,
                        layout_positions: None,
                        display_text: None,
                    }),
                    BoundingBox::new(wrap_text_x, table_y_start, 0.0, line_height),
                );
                let mut line_container = line_node;
                line_container.children.push(run_node);
                col_node.children.push(line_container);
            }
        }

        if related.is_empty() {
            return;
        }
        let Some(table_base_vpos) = table_base_vpos else {
            return;
        };

        // 어울림 텍스트 영역: col_area를 cs/sw 기반으로 조정
        let wrap_area = LayoutRect {
            x: wrap_text_x,
            y: col_area.y,
            width: wrap_text_width,
            height: col_area.height,
        };

        for wp in &related {
            let para = match paragraphs.get(wp.para_index) {
                Some(p) => p,
                None => continue,
            };
            let seg = match para.line_segs.first() {
                Some(s) => s,
                None => continue,
            };
            // 어울림 문단의 표 내 vpos 오프셋 → px
            let vpos_offset = seg.vertical_pos - table_base_vpos;
            let abs_y_in_table = crate::renderer::hwpunit_to_px(vpos_offset, self.dpi);

            // 현재 페이지에서의 y
            let para_y = table_y_start + (abs_y_in_table - table_content_offset);

            // 명시적 prefix 컷은 typeset이 이 단에 소유시킨 텍스트다. 마지막
            // prefix 줄이 실제 표 밴드 바로 아래에 있어도 버리면 suffix가 그 줄을
            // 다시 그리지 않아 내용이 누락된다. 전체/후속 fragment의 범위 필터는
            // 유지하고, 첫 fragment가 소유하는 유한 prefix만 배치한다.
            let owns_prefix =
                wp.has_text && wp.end_line != usize::MAX && table_content_offset == 0.0;
            if para_y < table_y_start - 1.0 || (!owns_prefix && para_y >= table_y_end) {
                continue;
            }

            if wp.has_text {
                // 텍스트 문단: composed paragraph를 사용하여 어울림 영역에 렌더링
                let comp = composed.get(wp.para_index);
                // 표 옆 띠에 기록된 줄 구간만 렌더링한다. 일반 어울림 문단의
                // `end_line=usize::MAX`는 전체 줄이라는 기존 의미를 유지한다.
                let line_count = comp.map(|c| c.lines.len()).unwrap_or(1);
                let start_line = wp.start_line.min(line_count);
                let end_line = wp.end_line.min(line_count).max(start_line);
                if start_line == end_line {
                    continue;
                }
                self.layout_partial_paragraph(
                    tree,
                    col_node,
                    para,
                    comp,
                    styles,
                    styles.hwp3_variant && self.endnote_para_source_for(wp.para_index).is_none(),
                    &strip_area,
                    para_y,
                    start_line,
                    end_line,
                    section_index,
                    wp.para_index,
                    None,
                    Some(bin_data_content),
                    None, // 표 호스트 어울림 문단 — 별도 wrap_anchor 메커니즘
                );
                // 어울림 문단은 항상 ↵ 표시 필요
                force_para_end_on_last_run(col_node);
            } else {
                // 빈 리턴 문단: ↵ 마크 렌더링
                let line_height = crate::renderer::hwpunit_to_px(seg.line_height, self.dpi);
                // 문단의 글자 모양에서 실제 폰트 크기 추출
                let font_size = {
                    let cs_id = para
                        .char_shapes
                        .first()
                        .map(|cs| cs.char_shape_id)
                        .unwrap_or(0);
                    styles
                        .char_styles
                        .get(cs_id as usize)
                        .map(|cs| cs.font_size)
                        .filter(|fs| *fs > 0.0)
                        .unwrap_or(13.3)
                };
                let mark_x = strip_x;

                let line_id = tree.next_id();
                let line_node = RenderNode::new(
                    line_id,
                    RenderNodeType::TextLine(TextLineNode::new(line_height, font_size)),
                    BoundingBox::new(mark_x, para_y, font_size, line_height),
                );

                let run_id = tree.next_id();
                let baseline = font_size * 0.8;
                let run_node = RenderNode::new(
                    run_id,
                    RenderNodeType::TextRun(TextRunNode {
                        text: String::new(),
                        style: TextStyle {
                            font_family: "바탕".to_string(),
                            font_size,
                            color: 0x000000,
                            ..Default::default()
                        },
                        char_shape_id: None,
                        para_shape_id: None,
                        section_index: None,
                        para_index: Some(wp.para_index),
                        char_start: None,
                        cell_context: None,
                        is_para_end: true,
                        is_line_break_end: false,
                        rotation: 0.0,
                        is_vertical: false,
                        char_overlap: None,
                        border_fill_id: 0,
                        baseline,
                        field_marker: FieldMarkerType::None,
                        layout_positions: None,
                        display_text: None,
                    }),
                    BoundingBox::new(mark_x, para_y, 0.0, line_height),
                );

                let mut line_container = line_node;
                line_container.children.push(run_node);
                col_node.children.push(line_container);
            }
        }
    }

    /// 글상자(Shape) 2차 패스: z-order 정렬 후 렌더링.
    #[allow(clippy::too_many_arguments)]
    fn layout_column_shapes_pass(
        &self,
        tree: &mut PageLayoutContext,
        col_node: &mut RenderNode,
        paper_images: &mut Vec<RenderNode>,
        col_content: &ColumnContent,
        page_content: &PageContent,
        paragraphs: &[Paragraph],
        composed: &[ComposedParagraph],
        styles: &ResolvedStyleSet,
        bin_data_content: &[BinDataContent],
        layout: &PageLayoutInfo,
        col_area: &LayoutRect,
        para_start_y: &std::collections::HashMap<usize, f64>,
        mut fixed_exclusions: Option<&mut Vec<VisibleFloatExclusion>>,
    ) {
        let mut shape_render_items: Vec<(i32, usize, usize, f64, Alignment)> = Vec::new();
        for item in &col_content.items {
            if let PageItem::Shape {
                para_index,
                control_index,
            } = item
            {
                let para_y = para_start_y.get(para_index).copied().unwrap_or(col_area.y);
                // [#6134] 같은 문단에 앞선 자리차지(TopAndBottom) 개체가 있으면 문단의
                // 글줄은 그 밴드 **아래**로 내려간다. "문단 기준" 세로 오프셋을 가진
                // 뒤 개체의 기준점도 문단 상단(=밴드 상단)이 아니라 그 글줄이다.
                let para_y = para_y
                    + paragraphs
                        .get(*para_index)
                        .map(|para| {
                            preceding_topbottom_band_height_px(para, *control_index, self.dpi)
                        })
                        .unwrap_or(0.0);
                let comp = composed.get(*para_index);
                let para_style_id = if let Some(para) = paragraphs.get(*para_index) {
                    comp.map(|c| c.para_style_id as usize)
                        .unwrap_or(para.para_shape_id as usize)
                } else {
                    0
                };
                let alignment = styles
                    .para_styles
                    .get(para_style_id)
                    .map(|s| s.alignment)
                    .unwrap_or(Alignment::Left);
                let z_order = paragraphs
                    .get(*para_index)
                    .and_then(|p| p.controls.get(*control_index))
                    .map(|ctrl| match ctrl {
                        Control::Shape(shape) => shape.z_order(),
                        Control::Table(table) => table.common.z_order,
                        Control::Form(form) => form.common.z_order,
                        _ => 0,
                    })
                    .unwrap_or(0);
                shape_render_items.push((z_order, *para_index, *control_index, para_y, alignment));
            }
        }
        shape_render_items.sort_by_key(|item| item.0);

        let overflow_map = self.scan_textbox_overflow(paragraphs, &shape_render_items);

        for (_, para_index, control_index, para_y, alignment) in shape_render_items {
            let ctrl = paragraphs
                .get(para_index)
                .and_then(|p| p.controls.get(control_index));
            let fixed_textbox = ctrl.is_some_and(fixed_textbox_flow::is_fixed_flow_textbox);
            if fixed_textbox != fixed_exclusions.is_some() {
                continue;
            }
            let is_paper_based = ctrl
                .map(|ctrl| {
                    let common = match ctrl {
                        Control::Shape(s) => Some(s.common()),
                        Control::Table(t) => Some(&t.common),
                        // [#6266] 양식 개체도 용지/쪽 기준 배치를 가질 수 있다.
                        Control::Form(f) => Some(&f.common),
                        _ => None,
                    };
                    common
                        .map(|c| {
                            matches!(c.horz_rel_to, HorzRelTo::Paper | HorzRelTo::Page)
                                || matches!(c.vert_rel_to, VertRelTo::Paper | VertRelTo::Page)
                        })
                        .unwrap_or(false)
                })
                .unwrap_or(false);
            let is_table_control = ctrl
                .map(|c| matches!(c, Control::Table(_)))
                .unwrap_or(false);
            let is_tac_picture_shape = matches!(
                ctrl,
                Some(Control::Shape(shape))
                    if shape.common().treat_as_char
                        && matches!(shape.as_ref(), ShapeObject::Picture(_))
            );

            let paper_area = LayoutRect {
                x: 0.0,
                y: 0.0,
                width: layout.page_width,
                height: layout.page_height,
            };

            if is_table_control {
                // InFrontOfText/BehindText 표: paper 기준 절대 위치에 렌더링
                if let Some(Control::Table(table)) = paragraphs
                    .get(para_index)
                    .and_then(|p| p.controls.get(control_index))
                {
                    let mut temp_parent = RenderNode::new(
                        tree.next_id(),
                        RenderNodeType::Column(0),
                        BoundingBox::new(0.0, 0.0, layout.page_width, layout.page_height),
                    );
                    // [#4568] 잔여 행을 다음 쪽에 넘긴 표는 앵커 쪽에서 그 행을 그리지
                    // 않는다. 넘긴 행까지 전부 그리면(bleed) 시각적으로는 쪽 경계에서
                    // 클립되지만 render tree 에 쪽 밖 줄이 남아
                    // `overflow_cell_baseline` 래칫에 계상된다. 컷의 권위는 typeset 이다
                    // — 여기서 재계산하면 다음 쪽 페인트와 어긋나 행이 소실되거나
                    // 중복될 수 있다.
                    let overlay_cut = col_content
                        .overlay_cuts
                        .iter()
                        .find(|(pi, ci, _)| *pi == para_index && *ci == control_index)
                        .map(
                            |(_, _, end_row)| super::layout::table_layout::NestedTableSplit {
                                start_row: 0,
                                end_row: *end_row,
                                visible_height: 0.0,
                                flow_height: 0.0,
                                offset_within_start: 0.0,
                                content_offset: 0.0,
                                force_source_start_cut: false,
                                replay_terminal_boundary_unit: false,
                                terminal: false,
                                recursive_cut: None,
                            },
                        );
                    self.layout_table(
                        tree,
                        &mut temp_parent,
                        table,
                        page_content.section_index,
                        styles,
                        0,
                        col_area,
                        para_y,
                        bin_data_content,
                        None,
                        0,
                        Some((para_index, control_index)),
                        alignment,
                        None,
                        0.0,
                        0.0,
                        None,
                        overlay_cut.as_ref(),
                        None,
                        None,
                        false,
                        false,
                        0.0,
                        None,
                        Self::standalone_table_char_border_fill(
                            paragraphs.get(para_index),
                            table,
                            styles,
                        ),
                    );
                    let layer =
                        Self::render_layer_from_common(&table.common, para_index, control_index);
                    Self::push_layered_paper_children(paper_images, &mut temp_parent, layer);
                }
            } else if is_tac_picture_shape {
                let mut temp_parent = RenderNode::new(
                    tree.next_id(),
                    RenderNodeType::Column(0),
                    col_node.bbox.clone(),
                );
                if let (Some(para), Some(Control::Shape(shape))) =
                    (paragraphs.get(para_index), ctrl)
                {
                    let common = shape.common();
                    let comp = composed.get(para_index);
                    let base_x =
                        self.compute_tac_pic_x(para, comp, styles, col_area, control_index);
                    let inline_x =
                        base_x + hwpunit_to_px(signed_hwpunit(common.horizontal_offset), self.dpi);
                    let shape_h = hwpunit_to_px(shape.flow_height_hu(), self.dpi);
                    let inline_y = self
                        .compute_tac_picture_shape_y(para, comp, styles, para_y, shape_h)
                        + hwpunit_to_px(signed_hwpunit(common.vertical_offset), self.dpi);
                    // comp 줄 누적은 통짜 배치 가정이다 — host 표가 분할 이월된
                    // 쪽에서는 표 줄 전체 높이가 누적되어 y 가 단 밖으로 나간다
                    // (재현 문서 A 셀 Enter: 로고 1196px > 단 하단). 그때는 텍스트
                    // 줄 렌더가 실제 줄 위치로 등록해 둔 기존 좌표를 존중한다.
                    let stale_computed = inline_y > col_area.y + col_area.height + 60.0
                        && tree
                            .get_inline_shape_position(
                                page_content.section_index,
                                para_index,
                                control_index,
                                None,
                            )
                            .is_some();
                    if !stale_computed {
                        tree.set_inline_shape_position(
                            page_content.section_index,
                            para_index,
                            control_index,
                            None,
                            inline_x,
                            inline_y,
                        );
                    }
                }
                self.layout_shape(
                    tree,
                    &mut temp_parent,
                    paragraphs,
                    para_index,
                    control_index,
                    page_content.section_index,
                    styles,
                    col_area,
                    &layout.body_area,
                    &paper_area,
                    para_y,
                    alignment,
                    bin_data_content,
                    &overflow_map,
                    false,
                );
                insert_before_para_text(
                    col_node,
                    para_index,
                    temp_parent.children.drain(..).collect(),
                );
            } else if is_paper_based {
                let mut temp_parent = RenderNode::new(
                    tree.next_id(),
                    RenderNodeType::Column(0),
                    BoundingBox::new(0.0, 0.0, layout.page_width, layout.page_height),
                );
                self.layout_shape(
                    tree,
                    &mut temp_parent,
                    paragraphs,
                    para_index,
                    control_index,
                    page_content.section_index,
                    styles,
                    col_area,
                    &layout.body_area,
                    &paper_area,
                    para_y,
                    alignment,
                    bin_data_content,
                    &overflow_map,
                    false,
                );
                if let (Some(exclusions), Some(Control::Shape(shape))) =
                    (fixed_exclusions.as_deref_mut(), ctrl)
                {
                    fixed_textbox_flow::reserve_painted_bounds(
                        exclusions,
                        &temp_parent,
                        shape.common(),
                        para_index,
                        col_area,
                        self.dpi,
                    );
                }
                if let Some(layer) = ctrl.and_then(|ctrl| match ctrl {
                    Control::Shape(shape) => Some(Self::render_layer_from_common(
                        shape.common(),
                        para_index,
                        control_index,
                    )),
                    Control::Table(table) => Some(Self::render_layer_from_common(
                        &table.common,
                        para_index,
                        control_index,
                    )),
                    Control::Form(form) => Some(Self::render_layer_from_common(
                        &form.common,
                        para_index,
                        control_index,
                    )),
                    _ => None,
                }) {
                    Self::push_layered_paper_children(paper_images, &mut temp_parent, layer);
                } else {
                    paper_images.append(&mut temp_parent.children);
                }
            } else {
                self.layout_shape(
                    tree,
                    col_node,
                    paragraphs,
                    para_index,
                    control_index,
                    page_content.section_index,
                    styles,
                    col_area,
                    &layout.body_area,
                    &paper_area,
                    para_y,
                    alignment,
                    bin_data_content,
                    &overflow_map,
                    false,
                );
            }
            // [Task #525] 비-TAC Picture/Shape Square wrap 의 어울림 문단 렌더링은
            // layout_shape_item:3106 (PageItem::Shape 처리 시) 에서 수행. 본 패스에서
            // 별도 호출은 동일 paragraph 의 wrap-around 텍스트가 두 다른 col_w 정렬로
            // distinct x 위치에 중복 emit 되어 (광범위 시각 결함, 7 샘플 37 페이지 영향)
            // 제거. Task #604 Stage 2 의 wrap_anchors 메타데이터 채널로 FullParagraph
            // path 가 cs offset 을 정확히 적용하므로 별도 호출 불필요.
        }
    }

    /// `Control::Shape(ShapeObject::Picture)` 형태의 글자처럼 취급 그림은
    /// paragraph_layout 이 직접 ImageNode 를 만들지 않고 shape pass 에서 그린다.
    /// 한컴은 라벨 텍스트와 그림 높이가 같은 LINE_SEG에 있을 때 라벨 한 줄을 먼저
    /// 배치한 뒤 그림을 아래에 둔다. raw line y 그대로 배치하면 라벨이 그림에 가려진다.
    fn compute_tac_picture_shape_y(
        &self,
        _para: &Paragraph,
        comp: Option<&ComposedParagraph>,
        styles: &ResolvedStyleSet,
        para_y: f64,
        shape_height_px: f64,
    ) -> f64 {
        let Some(comp) = comp else {
            return para_y;
        };
        let mut offset_y = 0.0;
        for line in &comp.lines {
            let raw_lh = hwpunit_to_px(line.line_height, self.dpi);
            let line_spacing_px = hwpunit_to_px(line.line_spacing, self.dpi);
            let max_fs = line
                .runs
                .iter()
                .map(|r| r.line_box_font_size(styles))
                .fold(0.0f64, f64::max);
            if (raw_lh - shape_height_px).abs() <= 4.0 && raw_lh > max_fs * 2.0 {
                let runs_all_whitespace = line.runs.iter().all(|r| r.text.trim().is_empty());
                let label_extra = if !runs_all_whitespace {
                    max_fs + line_spacing_px.max(0.0)
                } else {
                    0.0
                };
                return para_y + offset_y + label_extra;
            }
            offset_y += raw_lh + line_spacing_px;
        }
        para_y
    }

    /// treat_as_char 이미지의 x 좌표를 텍스트 위치 기반으로 계산한다.
    ///
    /// h_offset=0인 HWP 파일에서 올바른 인라인 이미지 위치를 결정하기 위해
    /// 문단의 텍스트 시뮬레이션으로 해당 제어 문자 위치의 x를 계산한다.
    fn compute_tac_pic_x(
        &self,
        para: &Paragraph,
        comp: Option<&ComposedParagraph>,
        styles: &ResolvedStyleSet,
        col_area: &LayoutRect,
        control_index: usize,
    ) -> f64 {
        let positions = para.control_text_positions();
        let ctrl_text_pos = positions.get(control_index).copied().unwrap_or(0);

        // margin_left를 미리 계산 (text_pos=0 early return에도 사용)
        let para_style_id_for_ml = comp.map(|c| c.para_style_id as usize).unwrap_or(0);
        let margin_left = styles
            .para_styles
            .get(para_style_id_for_ml)
            .map(|s| s.margin_left)
            .unwrap_or(0.0);
        // x_base: 텍스트가 시작되는 절대 x 위치 (문단 첫 글자 위치)
        let x_base = col_area.x + margin_left;

        // text_pos=0 이면 문단 첫 글자 위치(margin_left 포함)에서 시작
        if ctrl_text_pos == 0 {
            return x_base;
        }

        let comp = match comp {
            Some(c) => c,
            None => return x_base,
        };
        let para_style = styles.para_styles.get(comp.para_style_id as usize);
        let tab_width = para_style.map(|s| s.default_tab_width).unwrap_or(48.0);
        let tab_stops = para_style.map(|s| s.tab_stops.clone()).unwrap_or_default();
        let auto_tab_right = para_style.map(|s| s.auto_tab_right).unwrap_or(false);
        let available_width = col_area.width - margin_left;

        // ctrl_text_pos 이전에 있는 treat_as_char 컨트롤(text_pos > 0)의 너비 목록
        let mut preceding_tac: Vec<(usize, f64)> = para
            .controls
            .iter()
            .enumerate()
            .filter_map(|(ci, ctrl)| {
                if ci >= control_index {
                    return None;
                }
                let tp = positions.get(ci).copied().unwrap_or(0);
                if tp == 0 || tp >= ctrl_text_pos {
                    return None;
                }
                let w = match ctrl {
                    Control::Picture(p) if p.common.treat_as_char => {
                        hwpunit_to_px(p.common.width as i32, self.dpi)
                    }
                    Control::Shape(s) if s.common().treat_as_char => {
                        hwpunit_to_px(s.common().width as i32, self.dpi)
                    }
                    _ => return None,
                };
                Some((tp, w))
            })
            .collect();
        preceding_tac.sort_by_key(|(tp, _)| *tp);

        // 첫 번째 줄의 텍스트 런을 순회하며 ctrl_text_pos까지의 x 누적
        let first_line = match comp.lines.first() {
            Some(l) => l,
            None => return x_base,
        };

        let mut est_x = 0.0f64; // x_base로부터의 상대 오프셋
        let mut char_idx: usize = 0;
        let mut tac_pos = 0usize;

        'outer: for run in &first_line.runs {
            let mut ts = run.text_style(styles);
            ts.default_tab_width = tab_width;
            ts.tab_stops = tab_stops.clone();
            ts.auto_tab_right = auto_tab_right;
            ts.available_width = available_width;

            for ch in run.text.chars() {
                // 현재 char_idx 위치에 삽입된 preceding tac 컨트롤 너비 추가
                while tac_pos < preceding_tac.len() && preceding_tac[tac_pos].0 <= char_idx {
                    est_x += preceding_tac[tac_pos].1;
                    tac_pos += 1;
                }
                if char_idx >= ctrl_text_pos {
                    break 'outer;
                }
                ts.line_x_offset = est_x;
                if ch == '\t' {
                    let (tp, _, _) = find_next_tab_stop(
                        est_x,
                        &ts.tab_stops,
                        ts.default_tab_width,
                        ts.auto_tab_right,
                        ts.available_width,
                    );
                    est_x = tp;
                } else {
                    // [Task #555] PUA 옛한글 char 은 자모 시퀀스 폭으로 측정.
                    use super::pua_oldhangul::map_pua_old_hangul;
                    let metric_str: String = if let Some(jamos) = map_pua_old_hangul(ch) {
                        jamos.iter().copied().collect()
                    } else {
                        ch.to_string()
                    };
                    est_x += estimate_text_width(&metric_str, &ts);
                }
                char_idx += 1;
            }
        }

        x_base + est_x
    }
}

/// TAC 표 앞의 선행 텍스트(주로 공백) 폭을 계산한다.
///
/// `composed.lines[0]` 의 runs 중 target TAC 이전 문자 범위의 폭을 합산.
/// TAC 문단에 `PageItem::FullParagraph` 가 발행되지 않아 `paragraph_layout`
/// 가 호출되지 않는 경우(선행 공백만 있는 TAC 표 등)에 `layout_table_item`
/// 에서 표 inline x 좌표를 복원하기 위해 사용한다.
/// Task #463: 인라인 wrap=Square floating 표의 우측 끝 x 좌표 계산.
/// `table_layout::compute_table_x_position` 의 depth=0 + Column-relative
/// 경로와 동일한 공식을 사용하여, paragraph border box 가 표를 둘러쌀 수
/// 있도록 한다. 인용 따옴표 ｢｣ 처럼 col_area 우측을 horizontal_offset 만큼
/// 넘는 표를 정확히 처리한다.
fn compute_square_wrap_tbl_x_right(
    t: &crate::model::table::Table,
    col_area: &LayoutRect,
    dpi: f64,
) -> f64 {
    use crate::model::shape::HorzAlign;
    let tbl_w = crate::renderer::hwpunit_to_px(t.common.width as i32, dpi);
    let h_offset = crate::renderer::hwpunit_to_px(t.common.horizontal_offset as i32, dpi);
    let tbl_x = match t.common.horz_align {
        // table_layout.rs:966 와 동일: ref_x + (ref_w - table_width) - h_offset.
        // 이후 inline_x_override 경로(line 924-925)에서 +h_offset 가산되어
        // 최종 x = ref_x + (ref_w - table_width). h_offset 효과는 상쇄됨.
        // 그러나 실제 렌더된 좌표(empirical: 526.93) 는 ref_x+(ref_w-tw)+h_offset 임.
        // 여기서는 tbl_inline_x(line 2218)와 일관되게 단순 우측정렬 후
        // h_offset 가산식을 사용한다.
        HorzAlign::Right | HorzAlign::Outside => col_area.x + col_area.width - tbl_w + h_offset,
        HorzAlign::Center => col_area.x + (col_area.width - tbl_w) / 2.0 + h_offset,
        _ => col_area.x + h_offset,
    };
    tbl_x + tbl_w
}

/// [Issue #6167] 저장 사다리가 자리차지(TAC) 표에 **자기 줄**을 준 문단인지.
///
/// 한글이 `linesegarray` 에 `textpos = 표의 char 위치` · `horzpos = 0` 인 줄을 적어
/// 두었다면, 그 표는 **그 줄 머리**에서 시작한다 — 앞 줄에 있던 공백은 표의 x 에
/// 실리지 않는다. 이 증거가 없으면 종전대로 선행 텍스트 폭을 leading 으로 쓴다.
///
/// **통제군(`samples/복학원서.hwp` pi=16)** 과 값으로 갈린다:
///
/// | | 표 char 위치 | `ls[1].text_start` | 판정 |
/// |---|---|---|---|
/// | 113424 pi=441 | 18 | **18** (`col_start=0`) | 자기 줄 → leading 0 |
/// | 복학원서 pi=16 | 99 | 198 | 표가 `ls[0]` **안** → 종전 leading |
///
/// 복학원서는 한컴이 표 폭만큼 필러(U+F081C)를 채워 줄바꿈시킨 형상이라 표가 첫 줄
/// 안에 있고, `#1195` 로 보정된 leading 축이 그대로 유효하다.
fn stored_ladder_gives_tac_table_its_own_line(para: &Paragraph, control_index: usize) -> bool {
    let Some(&ctrl_pos) = para.control_text_positions().get(control_index) else {
        return false;
    };
    para.line_segs.iter().enumerate().skip(1).any(|(idx, seg)| {
        seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0
            && seg.column_start == 0
            && para.line_seg_text_start(idx) as usize == ctrl_pos
    })
}

fn compute_tac_leading_width(
    composed: &ComposedParagraph,
    target_control_index: usize,
    styles: &ResolvedStyleSet,
    // [#6298] 블록 취급 TAC 표의 문단 내 char 위치. `composed.tac_controls` 에 없는
    // 표(폭이 줄폭에 육박해 인라인으로 안 세는 표)도 **자기 앞** 텍스트까지만
    // leading 으로 세게 하는 정지점이다.
    block_tac_char_pos: Option<usize>,
) -> f64 {
    let target_position = composed
        .tac_controls
        .iter()
        .find(|(_, _, ci)| *ci == target_control_index)
        .map(|(position, _, _)| *position)
        .or(block_tac_char_pos);
    let owner_line = target_position
        .and_then(|position| {
            composed
                .lines
                .iter()
                .rfind(|line| line.char_start <= position)
        })
        .or_else(|| composed.lines.first());
    let Some(first_line) = owner_line else {
        return 0.0;
    };

    // target TAC 이 composed.tac_controls 에 있으면 해당 위치까지 합산.
    // 없으면(블록 취급: 너비 ≥ 90% seg_width 등 is_tac_table_inline 이 false 인 경우)
    // 선행 텍스트는 line 0 전체로 간주하고 모든 run 폭 합산.
    let tac_pos_opt = composed
        .tac_controls
        .iter()
        .find(|(_, _, ci)| *ci == target_control_index)
        .map(|(pos, _, _)| *pos);

    // [SBS 제출서류 표 오른쪽 밀림] 블록 취급 TAC 표(tac_pos_opt=None) 앞 텍스트가
    // 탭(U+0009)뿐이면 그 폭을 leading 으로 합산하지 않는다. 스페이스는 일반 문자
    // 처럼 고정폭 없이 실측 폭만큼 흐름에 남는 반면(Task #146 v3 text-align.hwp
    // 문단 0.2 — 스페이스 4개 실측 leading 36.8px, 아래 단위 테스트로 고정),
    // 탭은 "다음 탭 위치로 점프"라는 그리드 스냅 의미라 뒤에 오는 내용이 곧바로
    // 자기 줄을 차지하는 block 표일 때는 그 점프 목표 자체가 무의미해진다 — 한글도
    // 이런 표를 자기 줄 좌단에 그린다. SBS미디어넷 참여기업 모집공고 10쪽 "제출서류"
    // 표(문단 텍스트가 탭 한 글자뿐)가 탭 폭만큼 밀려 용지 오른쪽 끝을 넘어가던
    // 결함의 근본 원인 — `복학원서.hwp` pi=16(PUA 필러 U+F081C 기반 leading)이나
    // 스페이스 기반 leading 은 이 조건에 해당하지 않아 그대로 보존된다.
    if tac_pos_opt.is_none() {
        let only_tabs = first_line
            .runs
            .iter()
            .flat_map(|run| run.text.chars())
            .all(|ch| ch == '\t');
        if only_tabs {
            return 0.0;
        }
    }

    let mut char_pos = first_line.char_start;
    let mut width = 0.0;
    for run in &first_line.runs {
        let run_len = run.text.chars().count();
        let style = run.text_style(styles);
        // [Task #555] PUA 옛한글 변환 후 폰트 매트릭스는 자모 시퀀스 기준.
        let effective_full = effective_text_for_metrics(run);
        match tac_pos_opt {
            Some(tac_pos) if char_pos + run_len <= tac_pos => {
                width += estimate_text_width(effective_full, &style);
                char_pos += run_len;
            }
            Some(tac_pos) if char_pos < tac_pos => {
                let partial_len = tac_pos - char_pos;
                // partial 추출은 run.text 기준 (인덱싱 불변성). 이후 PUA 변환 적용.
                let partial: String = run.text.chars().take(partial_len).collect();
                let partial_display: String = partial
                    .chars()
                    .flat_map(|ch| {
                        use super::pua_oldhangul::map_pua_old_hangul;
                        if let Some(jamos) = map_pua_old_hangul(ch) {
                            jamos.iter().copied().collect::<Vec<_>>()
                        } else {
                            vec![ch]
                        }
                    })
                    .collect();
                width += estimate_text_width(&partial_display, &style);
                break;
            }
            Some(_) => break,
            None => {
                // [#6298] block 취급 TAC 도 **표 앞** 텍스트만 leading 이다.
                //
                // 종전에는 줄 0 의 run 을 전부 합산해, 표 **뒤**에 붙은 공백까지
                // 표의 x 로 실렸다 — 그래서 같은 선언의 두 표가 어긋나고(156586318
                // 12쪽: 58.10 vs 70.94pt) 공백을 표 앞에 두나 뒤에 두나 결과가 같은
                // "순서 무관"이 나왔다. leading 은 정의상 **앞**에 있는 것이므로,
                // 표 위치를 알 수 있으면 거기서 멈춘다.
                match block_tac_char_pos {
                    Some(stop) if char_pos >= stop => break,
                    Some(stop) if char_pos + run_len > stop => {
                        let partial_len = stop - char_pos;
                        let partial: String = run.text.chars().take(partial_len).collect();
                        let partial_display: String = partial
                            .chars()
                            .flat_map(|ch| {
                                use super::pua_oldhangul::map_pua_old_hangul;
                                if let Some(jamos) = map_pua_old_hangul(ch) {
                                    jamos.iter().copied().collect::<Vec<_>>()
                                } else {
                                    vec![ch]
                                }
                            })
                            .collect();
                        width += estimate_text_width(&partial_display, &style);
                        break;
                    }
                    _ => {
                        width += estimate_text_width(effective_full, &style);
                        char_pos += run_len;
                    }
                }
            }
        }
    }
    width
}

#[cfg(test)]
mod jueony_duplicated_nonflow_prefix_band_tests {
    use super::*;
    use crate::model::paragraph::LineSeg;
    use crate::model::shape::EllipseShape;
    fn fixture() -> Paragraph {
        let mut p = Paragraph { char_count: 17, ..Paragraph::default() };
        let mut ellipse = EllipseShape::default();
        ellipse.common.text_wrap = TextWrap::InFrontOfText;
        ellipse.common.allow_overlap = true;
        let mut table = crate::model::table::Table::default();
        table.common.treat_as_char = true;
        table.common.flow_with_text = true;
        table.common.text_wrap = TextWrap::TopAndBottom;
        table.common.vert_rel_to = VertRelTo::Para;
        table.common.horz_rel_to = HorzRelTo::Para;
        table.common.height = 64199;
        table.page_break = TablePageBreak::RowBreak;
        table.outer_margin_top = 283;
        table.outer_margin_bottom = 283;
        p.controls = vec![Control::Shape(Box::new(ShapeObject::Ellipse(ellipse))), Control::Table(Box::new(table))];
        p.line_segs = vec![
            LineSeg { text_start: 0, vertical_pos: 2720, line_height: 64765,
                text_height: 1000, baseline_distance: 850, line_spacing: 600,
                column_start: 0, segment_width: 48188, tag: 393216 },
            LineSeg { text_start: 8, vertical_pos: 4320, line_height: 64765,
                text_height: 64765, baseline_distance: 55050, line_spacing: 600,
                column_start: 0, segment_width: 48188, tag: 393216 },
        ]; p
    }
    fn probe(p: &Paragraph) -> Option<i32> {
        let Control::Table(t) = &p.controls[1] else { return None; };
        duplicated_nonflow_prefix_band_origin(p, 1, t)
    }
    #[test]
    fn exact_prefix_uses_first_band_without_mutation() {
        let p = fixture();
        let before = serde_json::to_value(&p).unwrap();
        assert_eq!(probe(&p), Some(2720));
        assert_eq!(serde_json::to_value(&p).unwrap(), before);
        let Control::Table(t) = &p.controls[1] else { panic!(); };
        let area = LayoutRect { x: 0.0, y: 94.5, width: 650.0, height: 1000.0 };
        let top = stored_empty_full_band_tac_table_top(&p, 1, t, &area, 96.0).unwrap();
        assert!((top - (94.5 + 3003.0 / 75.0)).abs() < 1e-9);
    }
    #[test]
    fn ambiguous_or_real_prefix_lines_keep_original_owner() {
        let changes: Vec<fn(&mut Paragraph)> = vec![
            |p| p.text = "visible".into(),
            |p| if let Control::Table(t) = &mut p.controls[1] { t.page_break = TablePageBreak::CellBreak; },
            |p| if let Control::Table(t) = &mut p.controls[1] { t.caption = Some(Caption::default()); },
            |p| p.char_count += 1,
            |p| p.line_segs[0].line_height = 1000,
            |p| p.line_segs[1].vertical_pos += 1,
            |p| p.line_segs[1].text_start = 0,
            |p| p.line_segs[0].tag |= LineSeg::TAG_IMPLEMENTATION_PROPERTY,
            |p| p.line_segs[0].column_start = 1,
            |p| p.line_segs[1].segment_width -= 1,
            |p| p.line_segs.push(p.line_segs[1].clone()),
            |p| p.stored_text_partition_dirty = true,
            |p| if let Control::Shape(s) = &mut p.controls[0] { if let ShapeObject::Ellipse(e) = s.as_mut() { e.common.affect_line_spacing = true; } },
            |p| if let Control::Shape(s) = &mut p.controls[0] { if let ShapeObject::Ellipse(e) = s.as_mut() { e.common.vert_rel_to = VertRelTo::Para; } },
            |p| if let Control::Table(t) = &mut p.controls[1] { t.common.vertical_offset = 1; },
        ];
        for (i, change) in changes.into_iter().enumerate() {
            let mut p = fixture(); change(&mut p);
            assert_eq!(probe(&p), None, "negative {i}");
        }
    }
}

#[cfg(test)]
mod jueony_unresolved_single_table_origin_tests {
    use super::*;
    use crate::model::paragraph::LineSeg;
    use crate::model::table::{Cell, Table};
    fn fixture() -> Vec<Paragraph> {
        let line = |y, width| LineSeg { text_start: 0, vertical_pos: y,
            line_height: 1000, text_height: 1000, baseline_distance: 850,
            line_spacing: 600, column_start: 0, segment_width: width, tag: 0x60000 };
        let mut t=Table::default();
        t.common.treat_as_char=false; t.common.text_wrap=TextWrap::TopAndBottom;
        t.common.vert_rel_to=VertRelTo::Para; t.common.vert_align=VertAlign::Top;
        t.common.horz_rel_to=HorzRelTo::Para; t.common.horz_align=HorzAlign::Left;
        t.common.width=41954; t.common.height=3846;
        t.outer_margin_left=567; t.outer_margin_right=850;
        t.outer_margin_top=1134; t.outer_margin_bottom=1417;
        t.row_count=3;t.col_count=2;
        t.cells=(0..6).map(|i| Cell {row:i/2,col:i%2,row_span:1,col_span:1,
            width:20977,height:1282,paragraphs:vec![Paragraph {text:"cell".into(),..Paragraph::default()}],..Cell::default()}).collect();
        vec![Paragraph {text:"before".into(),line_segs:vec![line(0,42520)],..Paragraph::default()},
            Paragraph {controls:vec![Control::Table(Box::new(t))],line_segs:vec![line(1600,0)],..Paragraph::default()},
            Paragraph {line_segs:vec![line(3200,42520)],..Paragraph::default()}]
    }
    fn probe(p:&[Paragraph],native:bool,columns:usize,measured:f64)->Option<i32>{
        let Control::Table(t)=&p[1].controls[0] else{panic!()};
        unresolved_single_table_placeholder_origin_hu(native,columns,p,1,t,Some(measured),96.0)
    }
    fn edit_table(p:&mut [Paragraph],f:impl FnOnce(&mut Table)){
        let Control::Table(t)=&mut p[1].controls[0] else{panic!()}; f(t);
    }
    #[test]fn g048_runtime_real_core_matches_hancom_origin(){
        let root=std::env::var("JUEONY_OUTER_FIXTURES").expect("absolute own fixtures");
        for name in ["outer-hwp.hwp","outer-hwp-hancom.hwp","outer-hwpx.hwpx","outer-hwpx-hancom.hwpx"] {
            let bytes=std::fs::read(std::path::Path::new(&root).join(name)).unwrap();
            let mut core=crate::document_core::DocumentCore::from_bytes(&bytes).unwrap();core.paginate();
            let layout:serde_json::Value=serde_json::from_str(&core.get_page_control_layout_native(0).unwrap()).unwrap();
            let y=layout["controls"][0]["y"].as_f64().unwrap();
            assert!((y-153.6).abs()<=0.2,"{name}: actual runtime y={y}");
        }
    }
    #[test]fn g048_converted_hwp_preserves_the_same_runtime_contract(){
        let root=std::env::var("JUEONY_OUTER_FIXTURES").unwrap();
        let bytes=std::fs::read(std::path::Path::new(&root).join("outer-hwpx.hwpx")).unwrap();
        let mut live=crate::document_core::DocumentCore::from_bytes(&bytes).unwrap();live.paginate();
        let saved=live.export_hwp_with_adapter_snapshot().unwrap();
        let document=crate::parser::parse_hwp(&saved).unwrap();
        assert!(document.layout_profile().hwp5_stored_pagination_layout());
        assert!(!document.extra_streams.iter().any(|(p,_)|p==crate::model::document::HWPX_ORIGIN_STREAM_PATH));
        let mut core=crate::document_core::DocumentCore::from_bytes(&saved).unwrap();core.paginate();
        let layout:serde_json::Value=serde_json::from_str(&core.get_page_control_layout_native(0).unwrap()).unwrap();
        let y=layout["controls"][0]["y"].as_f64().unwrap();assert!((y-153.6).abs()<=0.2,"converted actual runtime y={y}");
        let text:serde_json::Value=serde_json::from_str(&core.get_page_text_layout_native(0).unwrap()).unwrap();
        assert!((text["runs"][13]["y"].as_f64().unwrap()-153.6).abs()<=0.2);
    }
    #[test]fn g050_owned_generated_raw_six_requires_unsealed_matching_margin_copies(){
        let mut p=fixture();edit_table(&mut p,|t|{t.raw_table_record_attr=6;t.common.margin.left=t.outer_margin_left;t.common.margin.right=t.outer_margin_right;t.common.margin.top=t.outer_margin_top;t.common.margin.bottom=t.outer_margin_bottom;});
        assert_eq!(probe(&p,true,1,51.28),Some(1600));
        let mut sealed=p.clone();edit_table(&mut sealed,|t|t.raw_ctrl_seal=Some([0;32]));assert_eq!(probe(&sealed,true,1,51.28),None);
        let mut mismatch=p.clone();edit_table(&mut mismatch,|t|t.common.margin.top+=1);assert_eq!(probe(&mismatch,true,1,51.28),None);
        for raw in [1,2,3,4,5,7,8,14,0x4000_0000]{let mut bad=p.clone();edit_table(&mut bad,|t|t.raw_table_record_attr=raw);assert_eq!(probe(&bad,true,1,51.28),None,"raw{raw}");}
    }
    #[test]fn g050_missing_stored_origin_requires_edited_native_and_exact_existing_flow(){
        use crate::renderer::float_placement::{ParagraphFloatFlow,ParagraphFloatPlacement};
        let p=fixture();let Control::Table(t)=&p[1].controls[0] else{panic!()};
        let plan=ParagraphFloatPlacement{flow:ParagraphFloatFlow::Exclusion,anchor_y:1600.0/75.0,stored_host_origin:None,stored_successor_line_origin:None,table_left:None,table_top:2734.0/75.0,occupied_bottom:7997.0/75.0};
        let check=|native,edited,plan:&ParagraphFloatPlacement|unresolved_single_table_placeholder_paint_origin_hu(native,1,&p,1,t,Some(51.28),96.0,edited,Some(plan));
        assert_eq!(check(true,true,&plan),Some(1600));assert_eq!(check(true,false,&plan),None);assert_eq!(check(false,true,&plan),None);
        let mut mismatch=plan.clone();mismatch.anchor_y+=0.1;assert_eq!(check(true,true,&mismatch),None);
        let mut mismatch=plan.clone();mismatch.table_top+=0.1;assert_eq!(check(true,true,&mismatch),None);
        let mut mismatch=plan.clone();mismatch.occupied_bottom+=0.1;assert_eq!(check(true,true,&mismatch),None);
        let mut mismatch=plan.clone();mismatch.stored_host_origin=Some(20.0);assert_eq!(check(true,true,&mismatch),None);
    }
    #[test]fn g048_actual_owned_source_and_hancom_pairs_take_distinct_contracts(){
        let root=std::env::var("JUEONY_OUTER_FIXTURES").expect("absolute own fixture root required");
        for (name, expected) in [("outer-hwp.hwp",Some(1600)),("outer-hwp-hancom.hwp",None),
            ("outer-hwpx.hwpx",Some(1600)),("outer-hwpx-hancom.hwpx",None)] {
            let bytes=std::fs::read(std::path::Path::new(&root).join(name)).unwrap();
            let document=if name.ends_with(".hwpx") {crate::parser::hwpx::parse_hwpx(&bytes).unwrap()}
                else {crate::parser::parse_hwp(&bytes).unwrap()};
            let p=&document.sections[0].paragraphs;
            assert_eq!(probe(p,true,1,51.28),expected,"{name}");
        }
    }
    #[test]fn g048_exact_unresolved_native_and_marked_origin_is_read_only(){
        let p=fixture();let before=serde_json::to_string(&p).unwrap();
        assert_eq!(probe(&p,true,1,51.28),Some(1600));
        assert_eq!(serde_json::to_string(&p).unwrap(),before);
        let mut marked=fixture();edit_table(&mut marked,|t|t.raw_table_record_attr=0x0400_0000);
        assert_eq!(probe(&marked,true,1,51.28),Some(1600));
    }
    #[test]fn g048_hancom_resolved_band_and_other_geometry_stay_on_old_path(){
        let mut p=fixture();p[2].line_segs[0].vertical_pos=7997;
        assert_eq!(probe(&p,true,1,51.28),None);
        p[2].line_segs[0].vertical_pos=3201;assert_eq!(probe(&p,true,1,51.28),None);
        let p=fixture();assert_eq!(probe(&p,false,1,51.28),None);assert_eq!(probe(&p,true,2,51.28),None);
        assert_eq!(probe(&p,true,1,51.5),None);
    }
    #[test]fn g048_offsets_lock_caption_and_symmetric_margins_are_excluded(){
        for which in 0..7 {let mut p=fixture();edit_table(&mut p,|t|match which{
            0=>t.common.vertical_offset=1,1=>t.common.horizontal_offset=1,
            2=>t.common.locked=true,3=>t.common.size_protect=true,
            4=>t.caption=Some(crate::model::shape::Caption::default()),
            5=>{t.outer_margin_left=283;t.outer_margin_right=283;t.outer_margin_top=283;t.outer_margin_bottom=283;},
            _=>t.page_break=TablePageBreak::RowBreak});assert_eq!(probe(&p,true,1,51.28),None);}
    }
    #[test]fn g048_cells_protection_field_nested_and_merge_are_excluded(){
        for which in 0..6 {let mut p=fixture();edit_table(&mut p,|t|match which{
            0=>t.cells[0].set_cell_protect(true),1=>t.cells[0].field_name=Some("field".into()),
            2=>t.cells[0].row_span=2,3=>t.cells[0].paragraphs.push(Paragraph::default()),
            4=>t.cells[0].paragraphs[0].controls.push(Control::Table(Box::default())),
            _=>t.cells[0].col=1});assert_eq!(probe(&p,true,1,51.28),None);}
    }
    #[test]fn g048_host_text_dirty_stored_or_extra_control_are_excluded(){
        for which in 0..5 {let mut p=fixture();match which{
            0=>p[1].text="visible".into(),1=>p[1].stored_text_partition_dirty=true,
            2=>p[1].line_segs[0].segment_width=1,
            3=>p[1].line_segs[0].tag|=LineSeg::TAG_IMPLEMENTATION_PROPERTY,
            _=>p[1].controls.push(Control::Table(Box::default()))};assert_eq!(probe(&p,true,1,51.28),None);}
    }
    #[test]fn g048_all_side_channels_and_noadjust_are_rejected_in_every_owner(){
        use crate::model::paragraph::{FieldRange,OrphanFieldEnd,RangeTag,TitleMark,MarkpenMark};
        fn side(p:&mut Paragraph,i:usize){match i{
            0=>p.field_ranges.push(FieldRange::default()),1=>p.orphan_field_ends.push(OrphanFieldEnd::default()),
            2=>p.range_tags.push(RangeTag::default()),3=>p.title_marks.push(TitleMark::default()),
            4=>p.markpen_marks.push(MarkpenMark::default()),5=>p.ctrl_data_records.push(Some(vec![])),
            6=>p.tab_extended.push([0;7]),_=>p.layout_only_fill_lines=1}}
        for owner in 0..4 {for i in 0..8 {let mut p=fixture();
            if owner<3 {side(&mut p[owner],i);}else {edit_table(&mut p,|t|side(&mut t.cells[0].paragraphs[0],i));}
            assert_eq!(probe(&p,true,1,51.28),None,"owner={owner}, channel={i}");
        }}
        for which in 0..10 {let mut p=fixture();edit_table(&mut p,|t|match which{
            0=>t.raw_table_record_attr|=0x08,1=>t.common.attr|=1<<30,2=>t.attr|=1<<30,
            3=>t.common.height_criterion=crate::model::shape::SizeCriterion::Page,
            4=>t.common.width=u32::MAX,5=>t.common.height=u32::MAX,
            6=>t.cells[0].text_direction=1,7=>t.cells[0].line_wrap=1,
            8=>t.raw_table_record_attr|=0x0800_0000,
            _=>t.common.width_criterion=crate::model::shape::SizeCriterion::Column});
            assert_eq!(probe(&p,true,1,51.28),None,"unsafe attr={which}");}
    }
    #[test]fn g048_prefix_and_following_template_witness_must_be_exact(){
        for which in 0..6 {let mut p=fixture();match which{
            0=>p[0].text.clear(),1=>p[2].text="visible".into(),2=>p[2].stored_text_partition_dirty=true,
            3=>p[2].line_segs[0].line_spacing+=1,4=>p[0].line_segs[0].baseline_distance+=1,
            _=>p[2].controls.push(Control::Table(Box::default()))};assert_eq!(probe(&p,true,1,51.28),None);}
    }
}

#[cfg(test)]
mod jueony_live_outer_contract_tests {
    use super::*;
    #[test]
    fn g050_live_outer_four_command_paths_match_saved_reopen() {
        use crate::document_core::DocumentCore;
        let mut failures=Vec::new();
        for format in ["hwp","hwpx"] {for loaded in [false,true] {
            let mut core=DocumentCore::new_empty();core.create_blank_document_native().unwrap();
            core.insert_text_native(0,0,0,"앞 본문").unwrap();core.split_paragraph_native(0,0,4,None).unwrap();
            let t:serde_json::Value=serde_json::from_str(&core.create_table_native(0,1,0,3,2).unwrap()).unwrap();
            let ci=t["controlIdx"].as_u64().unwrap() as usize;
            for i in 0..6 {core.insert_text_in_cell_native(0,1,ci,i,0,0,&format!("내용 {i}")).unwrap();}
            if loaded {let b=if format=="hwp" {core.export_hwp_with_adapter_snapshot().unwrap()}else{core.export_hwpx_native().unwrap()};core=DocumentCore::from_bytes(&b).unwrap();}
            core.set_table_properties_native(0,1,ci,r#"{"outerLeft":567,"outerRight":850,"outerTop":1134,"outerBottom":1417}"#).unwrap();core.paginate();

            let stem=format!("{format}-{}",if loaded{"loaded"}else{"fresh"});

            let before:serde_json::Value=serde_json::from_str(&core.get_page_control_layout_native(0).unwrap()).unwrap();
            let b=if format=="hwp" {core.export_hwp_with_adapter_snapshot().unwrap()}else{core.export_hwpx_native().unwrap()};let mut read=DocumentCore::from_bytes(&b).unwrap();read.paginate();
            let after:serde_json::Value=serde_json::from_str(&read.get_page_control_layout_native(0).unwrap()).unwrap();
            let before_text:serde_json::Value=serde_json::from_str(&core.get_page_text_layout_native(0).unwrap()).unwrap();
            let after_text:serde_json::Value=serde_json::from_str(&read.get_page_text_layout_native(0).unwrap()).unwrap();
            fn same(a:&serde_json::Value,b:&serde_json::Value)->bool{match(a,b){
                (serde_json::Value::Number(a),serde_json::Value::Number(b))=>(a.as_f64().unwrap()-b.as_f64().unwrap()).abs()<=0.2,
                (serde_json::Value::Array(a),serde_json::Value::Array(b))=>a.len()==b.len()&&a.iter().zip(b).all(|(a,b)|same(a,b)),
                (serde_json::Value::Object(a),serde_json::Value::Object(b))=>a.len()==b.len()&&a.iter().all(|(k,a)|b.get(k).is_some_and(|b|same(a,b))),
                _=>a==b}}
            if !same(&before,&after)||!same(&before_text,&after_text){failures.push(format!("{stem}: whole control/text geometry differs"));}
        }}
        assert!(failures.is_empty(),"{}",failures.join("; "));
    }
}
#[cfg(test)]
mod current_stored_margin_frame_tests {
    use super::*;
    use crate::model::paragraph::{ColumnBreakType, LineSeg};
    use crate::model::table::{Cell, Table};
    use crate::renderer::style_resolver::ResolvedParaStyle;
    pub(super) fn fixture()->(Paragraph,Paragraph,ResolvedStyleSet){
        let line=|y,h,s,left,width|LineSeg{text_start:0,vertical_pos:y,line_height:h,text_height:h,baseline_distance:h*3/4,line_spacing:s,column_start:left,segment_width:width,tag:0x60000};
        let first=Paragraph{text:"source body".into(),char_offsets:(0..11).collect(),char_count:12,line_segs:vec![line(100,100,60,0,1000)],..Paragraph::default()};
        let mut t=Table::default();t.common.treat_as_char=true;t.common.height=1000;t.outer_margin_top=10;t.outer_margin_bottom=20;
        t.cells=vec![Cell{paragraphs:vec![Paragraph::default()],..Cell::default()}];
        t.raw_ctrl_seal=Some(crate::model::raw_provenance::record_digest(&t.common));
        let next=Paragraph{line_segs:vec![line(360,1030,60,50,950)],controls:vec![Control::Table(Box::new(t))],..Paragraph::default()};
        let styles=ResolvedStyleSet{para_styles:vec![ResolvedParaStyle{spacing_before:100.0/75.0,..ResolvedParaStyle::default()}],..ResolvedStyleSet::default()};
        (first,next,styles)
    }
    #[test]fn intact_original_frame_is_a_readonly_current_owner(){let(a,b,s)=fixture();let before=serde_json::to_value((&a,&b)).unwrap();assert!(current_stored_margin_frame(&a,Some(&b),1000,10000,&s,96.0));assert!(current_stored_margin_frame(&a,Some(&b),1002,10000,&s,96.0));assert!(!current_stored_margin_frame(&a,Some(&b),999,10000,&s,96.0));assert_eq!(serde_json::to_value((&a,&b)).unwrap(),before);}
    #[test]fn changed_cut_and_unowned_frames_are_not_source_authority(){for i in 0..10{let(mut a,mut b,s)=fixture();match i{0=>a.stored_text_partition_dirty=true,1=>b.stored_text_partition_dirty=true,2=>a.hwpx_axis_shift=8,3=>a.column_type=ColumnBreakType::Page,4=>b.line_segs[0].segment_width-=1,5=>a.line_segs[0].tag|=LineSeg::TAG_IMPLEMENTATION_PROPERTY,6=>a.source_line_seg_vertical_pos=Some(vec![0]),7=>if let Control::Table(t)=&mut b.controls[0]{t.raw_ctrl_seal=None},8=>if let Control::Table(t)=&mut b.controls[0]{t.common.height+=1},_=>if let Control::Table(t)=&mut b.controls[0]{t.cells[0].dirty_flag=true}}assert!(!current_stored_margin_frame(&a,Some(&b),1000,10000,&s,96.0),"mutation {i}");}}
    #[test]fn malformed_row_extremes_are_rejected_without_overflow(){for i in 0..6{let(mut a,mut b,s)=fixture();match i{0=>a.line_segs[0].line_height=i32::MAX,1=>a.line_segs[0].line_spacing=i32::MAX,2=>a.line_segs[0].vertical_pos=i32::MIN,3=>b.line_segs[0].vertical_pos=i32::MAX,4=>b.line_segs[0].column_start=i32::MAX,_=>b.line_segs[0].line_height=i32::MAX}assert!(!current_stored_margin_frame(&a,Some(&b),1000,10000,&s,96.0),"extreme {i}");}}
    #[test]fn legacy_leading_margin_delta_is_checked_without_tolerance_change(){let(a,b,s)=fixture();assert!(stored_first_margin_is_page_relative(&a,Some(&b),&s,96.0));for i in 0..3{let mut a=a.clone();let mut b=b.clone();match i{0=>a.line_segs[0].line_height=i32::MAX,1=>a.line_segs[0].line_spacing=i32::MAX,_=>{a.line_segs[0].vertical_pos=i32::MIN;b.line_segs[0].vertical_pos=i32::MAX;}}assert!(!stored_first_margin_is_page_relative(&a,Some(&b),&s,96.0),"extreme {i}");}let mut b=b.clone();b.line_segs[0].vertical_pos-=10;assert!(stored_first_margin_is_page_relative(&a,Some(&b),&s,96.0));}
}

#[cfg(test)]mod current_stored_margin_frame_bounds_tests{use super::*;
    #[test]fn invalid_tail_end_cannot_inherit_the_leading_origin(){
        use crate::model::paragraph::LineSeg;use crate::model::table::{Table,Cell};use crate::renderer::style_resolver::ResolvedParaStyle;
        let row=|y,h,sp|LineSeg{text_start:0,vertical_pos:y,line_height:h,text_height:1,baseline_distance:1,line_spacing:sp,column_start:0,segment_width:1000,tag:0x60000};
        let mut t=Table::default();t.common.treat_as_char=true;t.common.height=1030;t.raw_ctrl_seal=Some(crate::model::raw_provenance::record_digest(&t.common));t.cells=vec![Cell{paragraphs:vec![Paragraph::default()],..Cell::default()}];
        let a=Paragraph{text:"body".into(),char_offsets:(0..4).collect(),char_count:5,line_segs:vec![row(100,100,60)],..Paragraph::default()};let b=Paragraph{line_segs:vec![row(360,1030,60)],controls:vec![Control::Table(Box::new(t))],..Paragraph::default()};
        let s=ResolvedStyleSet{para_styles:vec![ResolvedParaStyle{spacing_before:100.0/75.0,..ResolvedParaStyle::default()}],..ResolvedStyleSet::default()};
        assert!(current_stored_margin_frame(&a,Some(&b),1000,1450,&s,96.0));assert!(!current_stored_margin_frame(&a,Some(&b),1000,1449,&s,96.0));assert!(!current_stored_margin_frame(&a,Some(&b),1000,0,&s,96.0));
        let mut a=a;let mut b=b;a.line_segs[0].line_height=i32::MAX-260;b.line_segs[0].vertical_pos=i32::MAX;
        assert!(!current_stored_margin_frame(&a,Some(&b),1000,i32::MAX,&s,96.0));
    }}

#[cfg(test)]mod current_stored_margin_frame_plain_tests{use super::*;
    #[test]fn exact_multiline_plain_source_frame_requires_complete_text_coverage(){
        let(a,mut b,s)=super::current_stored_margin_frame_tests::fixture();b.controls.clear();b.text="abcdefghijklmnopqrst".into();b.char_offsets=(0..20).collect();b.char_count=21;
        let mut first=b.line_segs[0].clone();first.line_height=100;first.text_height=100;first.baseline_distance=80;first.line_spacing=60;first.column_start=0;first.segment_width=1000;
        let mut second=first.clone();second.text_start=10;second.vertical_pos=520;b.line_segs=vec![first,second];
        let before=serde_json::to_value((&a,&b)).unwrap();assert!(current_stored_margin_frame(&a,Some(&b),1002,10000,&s,96.0));assert_eq!(serde_json::to_value((&a,&b)).unwrap(),before);
        for i in 0..5{let mut b=b.clone();match i{0=>b.char_offsets.pop().map(|_|()).unwrap(),1=>b.line_segs[1].text_start=21,2=>b.line_segs[1].vertical_pos+=1,3=>b.line_segs[1].segment_width-=1,_=>b.line_segs[1].tag|=crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY}assert!(!current_stored_margin_frame(&a,Some(&b),1002,10000,&s,96.0),"plain negative {i}");}
    }}

#[cfg(test)]mod current_stored_margin_frame_mixed_tests{use super::*;
    fn fixture(prefix:bool)->(Paragraph,Paragraph,ResolvedStyleSet){
        let(a,mut b,s)=super::current_stored_margin_frame_tests::fixture();b.text=if prefix{"가 ".into()}else{" 가".into()};b.char_offsets=if prefix{vec![0,9]}else{vec![8,9]};b.char_count=11;
        if prefix{let mut row=b.line_segs[0].clone();row.line_height=100;row.text_height=100;row.baseline_distance=80;row.line_spacing=60;let mut tail=b.line_segs[0].clone();tail.text_start=9;tail.vertical_pos=520;b.line_segs=vec![row,tail];}
        (a,b,s)
    }
    #[test]fn current_prefix_and_suffix_bind_their_actual_control_row(){for prefix in[false,true]{let(a,b,s)=fixture(prefix);let before=serde_json::to_value((&a,&b)).unwrap();assert_eq!(current_mixed_tac_row(&b),Some(usize::from(prefix)));assert!(current_stored_margin_frame(&a,Some(&b),1002,10000,&s,96.0));assert_eq!(serde_json::to_value((&a,&b)).unwrap(),before);}}
    #[test]fn ambiguous_control_coverage_and_changed_box_never_borrow_a_row(){for i in 0..7{let(a,mut b,s)=fixture(true);match i{0=>b.char_offsets[1]=8,1=>b.char_count+=1,2=>b.line_segs[1].text_start=8,3=>b.line_segs[1].line_height-=1,4=>b.controls.push(Control::Table(Box::default())),5=>b.stored_text_partition_dirty=true,_=>if let Control::Table(t)=&mut b.controls[0]{t.raw_ctrl_seal=None}}assert!(!current_stored_margin_frame(&a,Some(&b),1002,10000,&s,96.0),"mixed negative {i}");}}
}

#[cfg(test)]mod current_stored_margin_frame_plain_coverage_tests{use super::*;
    #[test]fn hidden_offset_gap_is_not_plain_text_authority(){let(mut a,b,s)=super::current_stored_margin_frame_tests::fixture();assert!(current_stored_margin_frame(&a,Some(&b),1002,10000,&s,96.0));for offset in &mut a.char_offsets[5..]{*offset+=7;}a.char_count+=7;assert!(!current_stored_margin_frame(&a,Some(&b),1002,10000,&s,96.0));}
    #[test]fn supplementary_unicode_keeps_its_exact_utf16_boundaries(){let(mut a,b,s)=super::current_stored_margin_frame_tests::fixture();a.text="𐐀abc".into();a.char_offsets=vec![0,2,3,4];a.char_count=6;assert!(current_stored_margin_frame(&a,Some(&b),1002,10000,&s,96.0));a.char_offsets[1]=1;assert!(!current_stored_margin_frame(&a,Some(&b),1002,10000,&s,96.0));}
}

#[cfg(test)]mod current_stored_margin_frame_tab_tests{use super::*;
    #[test]fn unowned_tab_is_never_inferred_as_one_utf16_unit(){
        let(mut a,b,s)=super::current_stored_margin_frame_tests::fixture();a.text="a\tb".into();a.char_offsets=vec![0,1,2];a.char_count=4;assert!(!current_stored_margin_frame(&a,Some(&b),1002,10000,&s,96.0));
        let(a,mut b,s)=super::current_stored_margin_frame_tests::fixture();b.text="가\t ".into();b.char_offsets=vec![0,9,10];b.char_count=12;let mut row=b.line_segs[0].clone();row.line_height=100;row.text_height=100;row.baseline_distance=80;row.line_spacing=60;let mut tail=b.line_segs[0].clone();tail.vertical_pos=520;tail.text_start=9;b.line_segs=vec![row,tail];assert!(!current_stored_margin_frame(&a,Some(&b),1002,10000,&s,96.0));
    }}

#[cfg(test)]
mod coanchored_outer_bottom102_tests {
    use super::*;
    fn fixture()->Paragraph {
        let mut p=Paragraph::default();
        let mut square=crate::model::table::Table::default();
        square.common.text_wrap=TextWrap::Square;square.common.vert_rel_to=VertRelTo::Paper;
        square.common.horz_rel_to=HorzRelTo::Paper;
        let mut float=crate::model::table::Table::default();float.row_count=1;float.col_count=1;
        float.cells.push(Default::default());float.page_break=TablePageBreak::RowBreak;
        float.common.text_wrap=TextWrap::TopAndBottom;float.common.vert_rel_to=VertRelTo::Para;
        float.common.vert_align=VertAlign::Top;float.common.height=1000;float.outer_margin_bottom=30;
        let mut inline=crate::model::table::Table::default();inline.common.treat_as_char=true;
        inline.common.height=100;inline.outer_margin_top=10;inline.outer_margin_bottom=10;
        p.controls=vec![Control::Table(Box::new(square)),Control::Table(Box::new(float)),Control::Table(Box::new(inline))];
        p.line_segs.push(crate::model::paragraph::LineSeg{vertical_pos:500,line_height:120,line_spacing:20,..Default::default()});p
    }
    fn eligible(p:&Paragraph)->bool{stored_column_top_coanchored_float_box(p,1,50.0,50.0,1000.0/75.0,96.0)}
    #[test]fn coanchored_outer_bottom102_requires_independent_exact_inline_row_and_float_box(){
        let mut p=fixture();assert!(eligible(&p));
        if let Control::Table(t)=&mut p.controls[1]{
            let mut text=Paragraph::default();text.controls.push(Control::Field(Default::default()));
            t.cells[0].paragraphs.push(text);
        }
        assert!(eligible(&p),"an inline field cannot erase the float's outer margin");
        assert!(!stored_column_top_coanchored_float_box(&p,0,50.0,50.0,1000.0/75.0,96.0));
        assert!(!stored_column_top_coanchored_float_box(&p,1,51.0,50.0,1000.0/75.0,96.0));
        assert!(!stored_column_top_coanchored_float_box(&p,1,50.0,50.0,1001.1/75.0,96.0));
    }
    #[test]fn coanchored_outer_bottom103_checks_page_band_descendants_and_memo_context(){
        fn carrier(control:Control)->Paragraph {
            let mut p=Paragraph::default();p.controls.push(control);p
        }
        fn with_control(control:Control)->Paragraph {
            let mut p=fixture();let Control::Table(t)=&mut p.controls[1] else{panic!()};
            t.cells[0].paragraphs.push(carrier(control));p
        }
        let mut nested=crate::model::table::Table::default();
        nested.cells.push(Default::default());
        nested.cells[0].paragraphs.push(carrier(Control::Field(Default::default())));
        let mut header=crate::model::header_footer::Header::default();
        header.paragraphs.push(carrier(Control::Table(Box::new(nested.clone()))));
        assert!(eligible(&with_control(Control::Header(Box::new(header.clone())))));
        let mut memo=crate::model::control::Field::default();
        memo.memo_paragraphs.push(carrier(Control::Table(Box::new(nested.clone()))));
        assert!(!eligible(&with_control(Control::Field(memo))));
        nested.cells[0].paragraphs[0].controls.push(Control::Footnote(Box::default()));
        header.paragraphs=vec![carrier(Control::Table(Box::new(nested)))];
        assert!(!eligible(&with_control(Control::Header(Box::new(header)))));
        let mut control=Control::Header(Box::default());
        for _ in 0..34 {
            let mut h=crate::model::header_footer::Header::default();
            h.paragraphs.push(carrier(control));control=Control::Header(Box::new(h));
        }
        assert!(!eligible(&with_control(control)),"deep page bands retain general path");
        let mut h=crate::model::header_footer::Header::default();
        h.paragraphs=vec![Paragraph::default();4097];
        assert!(!eligible(&with_control(Control::Header(Box::new(h)))));
    }
    #[test]fn coanchored_outer_bottom102_rejects_unowned_changed_or_other_placement(){
        for n in 0..20{let mut p=fixture();match n {
            0=>p.stored_text_partition_dirty=true,1=>p.cell_format_vpos_dirty=true,
            2=>p.line_segs[0].tag=crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY,
            3=>p.text="가".into(),4=>{p.controls.pop();},
            5=>if let Control::Table(t)=&mut p.controls[1]{t.common.vertical_offset=1;},
            6=>if let Control::Table(t)=&mut p.controls[1]{t.outer_margin_top=1;},
            7=>if let Control::Table(t)=&mut p.controls[1]{t.row_count=2;},
            8=>if let Control::Table(t)=&mut p.controls[1]{t.common.allow_overlap=true;},
            9=>if let Control::Table(t)=&mut p.controls[2]{t.common.height=101;},
            10=>if let Control::Table(t)=&mut p.controls[0]{t.common.vert_rel_to=VertRelTo::Para;},
            11=>p.controls.push(p.controls[2].clone()),
            12=>p.line_segs[0].line_spacing=-1,
            13=>p.line_segs[0].vertical_pos=i32::MAX,
            14=>p.line_segs[0].vertical_pos=-1,
            15 | 16=>if let Control::Table(t)=&mut p.controls[1]{
                let mut text=Paragraph::default();text.controls.push(if n==15 {
                    Control::Footnote(Box::default())
                }else{Control::Table(Box::default())});t.cells[0].paragraphs.push(text);
            },
            17=>if let Control::Table(t)=&mut p.controls[1]{t.outer_margin_bottom=-1;},
            18=>if let Control::Table(t)=&mut p.controls[2]{t.outer_margin_top=-1;t.common.height=111;},
            19=>if let Control::Table(t)=&mut p.controls[2]{t.outer_margin_bottom=-1;t.common.height=111;},
            _=>unreachable!(),
        }assert!(!eligible(&p),"case {n}");}
    }
}

mod current_body_stack;
pub(crate) use current_body_stack::{CurrentWholeStackPlan,CurrentStackHost};

impl LayoutEngine {
    /// Read-only current-format proof. The caller must pass the actual current
    /// page, composition, styles and measurements. No imported row lease is
    /// minted or copied; renderer flow admission remains a separate check.
    #[allow(clippy::too_many_arguments)]
    pub(crate) fn current_whole_stack_export_plan(&self,
        profile:crate::model::provenance::LayoutCompatibilityProfile,
        page:&PageContent, paragraphs:&[Paragraph], composed:&[ComposedParagraph],
        styles:&ResolvedStyleSet, measured:&[MeasuredTable], dpi:f64,
    )->Option<CurrentWholeStackPlan> {
        let (slots,sources,_,_)=self.exact_font_source_registry_counts();
        if !profile.hwp5_origin_hwpx() || profile.hwp3_layout() || profile.hangul2024_layout()
            || slots!=0 || sources!=0 || !dpi.is_finite() || dpi<=0.0 || dpi!=self.dpi {return None;}
        let col=page.column_contents.first()?;
        let ctx=ColumnItemCtx{page_content:page,paragraphs,composed,styles,bin_data_content:&[],
            measured_tables:measured,layout:&page.layout,col_area:page.layout.column_areas.first()?,
            zone_column_count:page.layout.column_areas.len(),outline_numbering_id:0,multi_col_width:None,
            prev_tac_seg_applied:false,wrap_around_paras:&col.wrap_around_paras,wrap_anchors:&col.wrap_anchors,
            inline_placements:&col.inline_placements,inline_flow_plans:&col.inline_flow_plans,
            paragraph_float_placements:&col.paragraph_float_placements};
        current_body_stack::current_whole_stack(&ctx,dpi)
    }
}


impl LayoutEngine {
    /// Separate Native-container export producer. This neither changes Native
    /// painting nor pretends that the document was read from HWPX. Every current
    /// row, composition and physical allocation must close under the same proof.
    #[allow(clippy::too_many_arguments)]
    pub(crate) fn current_native_whole_stack_export_plan(&self,
        profile:crate::model::provenance::LayoutCompatibilityProfile,
        page:&PageContent, paragraphs:&[Paragraph], composed:&[ComposedParagraph],
        styles:&ResolvedStyleSet, measured:&[MeasuredTable], dpi:f64,
    )->Option<CurrentWholeStackPlan> {
        let (slots,sources,_,_)=self.exact_font_source_registry_counts();
        if !profile.native_hwp5_layout() || profile.hwp5_origin_hwpx() || profile.hwpx_container()
            || profile.hwpx_stored_layout() || profile.legacy_hwp3_stored_geometry()
            || profile.hwp3_password_layout() || profile.hangul2024_layout()
            || slots!=0 || sources!=0 || !dpi.is_finite() || dpi<=0.0 || dpi!=self.dpi {return None;}
        let col=page.column_contents.first()?;
        let ctx=ColumnItemCtx{page_content:page,paragraphs,composed,styles,bin_data_content:&[],
            measured_tables:measured,layout:&page.layout,col_area:page.layout.column_areas.first()?,
            zone_column_count:page.layout.column_areas.len(),outline_numbering_id:0,multi_col_width:None,
            prev_tac_seg_applied:false,wrap_around_paras:&col.wrap_around_paras,wrap_anchors:&col.wrap_anchors,
            inline_placements:&col.inline_placements,inline_flow_plans:&col.inline_flow_plans,
            paragraph_float_placements:&col.paragraph_float_placements};
        current_body_stack::current_native_whole_stack(&ctx,dpi)
    }
}
