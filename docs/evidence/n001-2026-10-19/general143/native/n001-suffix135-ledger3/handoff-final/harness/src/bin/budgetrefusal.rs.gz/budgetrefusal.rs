use rhwp::DocumentCore;
use serde_json::{Value,json};
use sha2::{Sha256,Digest};
use std::path::PathBuf;
fn hash(b:&[u8])->String{Sha256::digest(b).iter().map(|v|format!("{v:02x}")).collect()}
fn layout(d:&DocumentCore)->Value{json!({"pages":d.page_count(),"layout":(0..d.page_count()).map(|p|json!({"text":serde_json::from_str::<Value>(&d.get_page_text_layout_native(p).unwrap()).unwrap(),"controls":serde_json::from_str::<Value>(&d.get_page_control_layout_native(p).unwrap()).unwrap()})).collect::<Vec<_>>()})}
fn coverage(d:&DocumentCore)->Value{
 let mut all=vec![];
 for(si,s)in d.document().sections.iter().enumerate(){for(pi,p)in s.paragraphs.iter().enumerate(){let chars=p.text.chars().collect::<Vec<_>>();let mut counts=vec![0usize;chars.len()];let mut cursor=0usize;let mut errors=vec![];
  for page in 0..d.page_count(){let v:Value=serde_json::from_str(&d.get_page_text_layout_native(page).unwrap()).unwrap();for run in v["runs"].as_array().unwrap(){
   if run.get("cellPath").is_some()||run.get("parentParaIdx").is_some(){continue;}if run["secIdx"]!=si||run["paraIdx"]!=pi{continue;}
   let text=run["text"].as_str().unwrap().chars().collect::<Vec<_>>();let start=run["charStart"].as_u64().unwrap()as usize;let end=start+text.len();
   if start!=cursor||end>chars.len()||chars.get(start..end)!=Some(text.as_slice()){errors.push(json!({"kind":"partition","page":page,"expected":cursor,"start":start,"end":end}));}
   if run["charX"].as_array().map(|x|x.len())!=Some(text.len()+1){errors.push(json!({"kind":"charX"}));}
   for n in counts.iter_mut().take(end).skip(start){*n+=1;}cursor=end;
  }}
  let missing=counts.iter().filter(|&&v|v==0).count();let duplicate=counts.iter().filter(|&&v|v>1).count();if missing>0||duplicate>0||cursor!=chars.len(){errors.push(json!({"kind":"coverage","missing":missing,"duplicate":duplicate,"end":cursor,"source":chars.len()}));}
  if !errors.is_empty(){all.push(json!({"section":si,"paragraph":pi,"errors":errors}));}
 }}json!({"passed":all.is_empty(),"errors":all})
}
fn diff(a:&Value,b:&Value,n:&mut usize){match(a,b){(Value::Object(a),Value::Object(b))=>for k in a.keys().chain(b.keys()).collect::<std::collections::BTreeSet<_>>(){match(a.get(k),b.get(k)){(Some(a),Some(b))=>diff(a,b,n),_=>*n+=1}},(Value::Array(a),Value::Array(b))=>{if a.len()!=b.len(){*n+=1;}for(a,b)in a.iter().zip(b){diff(a,b,n)}},(Value::Number(a),Value::Number(b))=>if(a.as_f64().unwrap()-b.as_f64().unwrap()).abs()>0.2{*n+=1},_=>if a!=b{*n+=1}}}
fn main(){let root=PathBuf::from(std::env::var("N001_ROOT").unwrap());let out=PathBuf::from(std::env::var("N001_OUT").unwrap());std::fs::create_dir_all(&out).unwrap();let bytes=std::fs::read(root.join("apps/editor/tests/fixtures/n001-general125-own/unequal-three-offset.hwp")).unwrap();let mut d=DocumentCore::from_bytes(&bytes).unwrap();let n=d.document().sections[0].paragraphs[0].text.chars().count();d.insert_text_native(0,0,n,&"현재😀 𠮷 supplementary plain body reflows across columns. ".repeat(15)).unwrap();assert_eq!(coverage(&d)["passed"],true);let count=d.document().sections[0].paragraphs.len();d.insert_paragraph_native(0,count).unwrap();d.insert_text_native(0,count,0,&"\n".repeat(4100)).unwrap();let before=hash(format!("{:?}",d.document()).as_bytes());let events=d.serialize_event_log();let result=d.get_page_text_layout_native(0);assert!(result.is_err(),"unknown remainder formatter set must refuse, never publish partial source characters");assert_eq!(before,hash(format!("{:?}",d.document()).as_bytes()));assert_eq!(events,d.serialize_event_log());std::fs::write(out.join("result.json"),serde_json::to_vec_pretty(&json!({"passed":true,"pages":d.page_count(),"explicitRenderError":result.err().map(|e|format!("{e}")),"fullTracePresent":rhwp::private_selected_trace135(&d).as_array().unwrap().iter().any(|x|!x.is_null()),"owner":rhwp::private_required_info135(&d),"sourceUnchanged":true,"eventsUnchanged":true,"scope":"Actual public append+4100 explicit newlines; over-row-budget documents explicitly unsupported, not partial geometry success; Node OS-write guard not yet executed"})).unwrap()).unwrap();}
