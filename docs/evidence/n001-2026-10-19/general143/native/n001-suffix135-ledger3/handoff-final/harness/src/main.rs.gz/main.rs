use rhwp::DocumentCore;
use serde_json::{Value,json};
use sha2::{Sha256,Digest};
use std::path::PathBuf;
fn hash(b:&[u8])->String{Sha256::digest(b).iter().map(|v|format!("{v:02x}")).collect()}
fn layout(d:&DocumentCore)->Value{json!({"pages":d.page_count(),"layout":(0..d.page_count()).map(|p|json!({"text":serde_json::from_str::<Value>(&d.get_page_text_layout_native(p).unwrap()).unwrap(),"controls":serde_json::from_str::<Value>(&d.get_page_control_layout_native(p).unwrap()).unwrap()})).collect::<Vec<_>>()})}
fn coverage(d:&DocumentCore)->Value{
 let mut all=vec![];
 for(si,s)in d.document().sections.iter().enumerate(){for(pi,p)in s.paragraphs.iter().enumerate(){let chars=p.text.chars().collect::<Vec<_>>();let mut counts=vec![0usize;chars.len()];let mut cursor=0usize;let mut errors=vec![];
  for page in 0..d.page_count(){let v:Value=serde_json::from_str(&d.get_page_text_layout_native(page).unwrap()).unwrap();for run in v["runs"].as_array().unwrap(){
   if run.get("cellPath").is_some()||run.get("parentParaIdx").is_some(){continue;}if run["secIdx"]!=si||run["paraIdx"]!=pi{continue;}
   let text=run["text"].as_str().unwrap().chars().collect::<Vec<_>>();let start=run["charStart"].as_u64().unwrap()as usize;let end=start+text.len();
   if start!=cursor||end>chars.len()||chars.get(start..end)!=Some(text.as_slice()){errors.push(json!({"kind":"partition","page":page,"expected":cursor,"start":start,"end":end}));}
   if run["charX"].as_array().map(|x|x.len())!=Some(text.len()+1){errors.push(json!({"kind":"charX"}));}
   for n in counts.iter_mut().take(end).skip(start){*n+=1;}cursor=end;
  }}
  let missing=counts.iter().filter(|&&v|v==0).count();let duplicate=counts.iter().filter(|&&v|v>1).count();if missing>0||duplicate>0||cursor!=chars.len(){errors.push(json!({"kind":"coverage","missing":missing,"duplicate":duplicate,"end":cursor,"source":chars.len()}));}
  if !errors.is_empty(){all.push(json!({"section":si,"paragraph":pi,"errors":errors}));}
 }}json!({"passed":all.is_empty(),"errors":all})
}
fn diff(a:&Value,b:&Value,n:&mut usize){match(a,b){(Value::Object(a),Value::Object(b))=>for k in a.keys().chain(b.keys()).collect::<std::collections::BTreeSet<_>>(){match(a.get(k),b.get(k)){(Some(a),Some(b))=>diff(a,b,n),_=>*n+=1}},(Value::Array(a),Value::Array(b))=>{if a.len()!=b.len(){*n+=1;}for(a,b)in a.iter().zip(b){diff(a,b,n)}},(Value::Number(a),Value::Number(b))=>if(a.as_f64().unwrap()-b.as_f64().unwrap()).abs()>0.2{*n+=1},_=>if a!=b{*n+=1}}}
fn main(){let r=PathBuf::from(std::env::var("N001_ROOT").unwrap());let out=PathBuf::from(std::env::var("N001_OUT").unwrap());std::fs::create_dir_all(&out).unwrap();let dir=r.join("apps/editor/tests/fixtures/n001-general125-own");let manifest:Value=serde_json::from_slice(&std::fs::read(dir.join("manifest.json")).unwrap()).unwrap();let mut rows=vec![];
for name in ["two-columns","three-columns","unequal-two","unequal-three","two-columns-multipage","unequal-three-offset"]{let f=manifest["fixtures"].as_array().unwrap().iter().find(|f|f["file"]==format!("{name}.hwp")).unwrap();for origin in ["native","xml"]{for astral in if name=="unequal-three-offset"{vec![false,true]}else{vec![false]}{
 let input=std::fs::read(dir.join(f[if origin=="native"{"file"}else{"xmlFile"}].as_str().unwrap())).unwrap();assert_eq!(hash(&input),f[if origin=="native"{"sha256"}else{"xmlSha256"}].as_str().unwrap());let mut d=DocumentCore::from_bytes(&input).unwrap();let n=d.document().sections[0].paragraphs[0].text.chars().count();d.insert_text_native(0,0,n,&(if astral{"현재😀 𠮷 supplementary plain body reflows across columns. "}else{"Retained current prefix editing causes line reflow. "}).repeat(if f["shortPage"]==true{15}else{7})).unwrap();
 let id=format!("{name}-{origin}-{}",if astral{"astral"}else{"ascii"});let source=hash(format!("{:?}",d.document()).as_bytes());let events=d.serialize_event_log();let before=layout(&d);let live=coverage(&d);std::fs::write(out.join(format!("{id}-current-layout.json")),serde_json::to_vec(&before).unwrap()).unwrap();let mut exports=vec![];
 for format in ["hwp","hwpx"]{let a=if format=="hwp"{d.export_hwp_with_adapter_snapshot_with_report()}else{d.export_hwpx_native_with_report()}.unwrap();std::fs::write(out.join(format!("{id}.{format}")),a.bytes()).unwrap();let next=DocumentCore::from_bytes(a.bytes()).unwrap();let mut changes=0;diff(&before,&layout(&next),&mut changes);exports.push(json!({"format":format,"geometryDifferences":changes,"loss":a.content_loss().len(),"coverage":coverage(&next),"sha256":hash(a.bytes())}));}
 assert_eq!(source,hash(format!("{:?}",d.document()).as_bytes()));assert_eq!(events,d.serialize_event_log());let id=format!("{name}-{origin}-{}",if astral{"astral"}else{"ascii"});if astral{let trace=rhwp::private_selected_trace135(&d);std::fs::write(out.join(format!("{id}-trace.json")),serde_json::to_vec_pretty(&trace).unwrap()).unwrap();}
 rows.push(json!({"case":id,"live":live,"exports":exports,"sourceUnchanged":true}));
 }}}
let pass=rows.iter().filter(|r|r["live"]["passed"]==true&&r["exports"].as_array().unwrap().iter().all(|e|e["coverage"]["passed"]==true)).count();std::fs::write(out.join("result.json"),serde_json::to_vec_pretty(&json!({"cases":rows,"coveragePass":pass,"total":rows.len(),"scope":"All body paragraphs, exact scalar/UTF16 text ownership; geometry0.2 separate, no guard result fabricated. Public Native edits and actual ordinary exports, source/event immutable."})).unwrap()).unwrap();println!("COVERAGE {pass}/{}",rows.len());}
