
// EXCLUDED private Native trace wrapper, no runtime authority.
#[cfg(not(target_arch="wasm32"))]
pub fn private_selected_trace135(d:&DocumentCore)->serde_json::Value {serde_json::Value::Array(d.pagination.iter().map(|r|r.selected_composition_trace.as_ref().map_or(serde_json::Value::Null,|t|serde_json::json!({"generation":t.generation(),"formats":t.formats(),"commits":t.commits()}))).collect())}

#[cfg(not(target_arch="wasm32"))]
pub fn private_accept_diagnostic135(d:&DocumentCore)->serde_json::Value {
 serde_json::Value::Array(d.pagination.iter().enumerate().map(|(i,r)|{
  let Some(t)=r.selected_composition_trace.as_ref()else{return serde_json::json!({"trace":false});};
  let live=&d.document.sections[i].paragraphs;let styles=d.styles.for_section(i);
  let normalized=d.render_normalization.sections.get(i).and_then(|n|n.as_ref());
  let mut without=live.clone();for p in &mut without{p.completed_native_rows=None;}

  serde_json::json!({"withoutCompletedSource":t.matches_source(&without,styles.reset_flow_context,d.effective_layout_profile(),d.dpi),"liveSource":t.matches_source(live,styles.reset_flow_context,d.effective_layout_profile(),d.dpi),
   "normalizedSource":normalized.map(|n|t.matches_source(&n.paragraphs,styles.reset_flow_context,d.effective_layout_profile(),d.dpi)),
   "frame":t.matches_finalized_result(r),"livePtr":live.as_ptr() as usize,
   "normalizedPtr":normalized.map(|n|n.paragraphs.as_ptr() as usize),"tracePtr":t.formats().first().map(|f|f.paragraph_token),
   "liveCompleted":live.iter().filter(|p|p.completed_native_rows.is_some()).count(),
   "normalizedCompleted":normalized.map(|n|n.paragraphs.iter().filter(|p|p.completed_native_rows.is_some()).count()),
   "profile":format!("{:?}",d.effective_layout_profile()),"context":styles.reset_flow_context})
 }).collect())
}

// EXCLUDED Native adversarial tests; no methods exported to Wasm/production.
#[cfg(not(target_arch="wasm32"))]
pub fn private_required_info135(d:&DocumentCore)->serde_json::Value{
 serde_json::json!({"resource":crate::model::native_computed_resource::RESOURCE,"sections":d.pagination.iter().enumerate().map(|(i,r)|{
  let q=r.required_plain_paint.as_ref();let t=q.and_then(|q|q.paint_trace());let styles=d.styles.for_section(i);
  serde_json::json!({"required":q.is_some(),"trace":t.is_some(),"source":t.map(|t|t.matches_paint_source(&d.document.sections[i].paragraphs,styles.reset_flow_context,d.effective_layout_profile(),d.dpi)),
  "exportScope":t.map(|t|t.matches_source(&d.document.sections[i].paragraphs,styles.reset_flow_context,d.effective_layout_profile(),d.dpi)),"frame":t.map(|t|t.matches_finalized_result(r)),"paragraphs":q.map(|q|q.paragraph_bindings().len())})
 }).collect::<Vec<_>>()})
}
#[cfg(not(target_arch="wasm32"))]
pub fn private_tamper_required135(d:&mut DocumentCore,case:&str){
 match case{
  "clearFullTrace"=>for r in &mut d.pagination{r.selected_composition_trace=None;},
  "source"=>d.document.sections[0].paragraphs[12].raw_header_extra.push(37),
  "pointer"=>d.document=d.document.clone(),
  "width"=>d.pagination[0].pages[3].layout.column_areas[0].width-=1.0,
  "span"=>{if let crate::renderer::pagination::PageItem::PartialParagraph{start_line,..}=&mut d.pagination[0].pages[3].column_contents[0].items[0]{*start_line+=1;}else{panic!("expected actual p12 fragment");}},
  _=>panic!("unknown excluded test mutation")
 }
 d.invalidate_page_tree_cache();
}
