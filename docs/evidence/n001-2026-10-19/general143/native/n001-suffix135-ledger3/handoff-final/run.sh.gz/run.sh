#!/usr/bin/env bash
set -euo pipefail
repo=/mnt/c/Users/jjome/Documents/work/jueony
export RUSTUP_HOME="$repo/.tools/linux-rustup"
export CARGO_HOME="$repo/.tools/linux-cargo"
export PATH="$CARGO_HOME/bin:$PATH"
export CARGO_TARGET_DIR=/tmp/jueony-n001-suffix135-ledger3-ONLY
export N001_ROOT="$repo"
export N001_OUT="$repo/build/n001-suffix135-ledger3/${1:?output stage required}"
cd "$repo/build/n001-suffix135-ledger3/harness"
cargo run --release --offline --locked --bin "${2:-n001-suffix135}"
