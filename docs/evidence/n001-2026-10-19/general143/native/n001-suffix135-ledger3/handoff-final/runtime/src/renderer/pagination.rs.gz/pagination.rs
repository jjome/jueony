//! 페이지 분할 (Pagination)
//!
//! IR(Document Model)의 문단 목록을 페이지 단위로 분할한다.
//! 각 페이지에 어떤 문단(또는 문단의 일부)이 배치되는지 결정한다.
//!
//! 2-패스 페이지네이션:
//! 1. HeightMeasurer로 모든 콘텐츠의 실제 렌더링 높이를 측정
//! 2. 측정된 높이를 기반으로 정확한 페이지 분할 수행

use super::composer::ComposedParagraph;
use super::height_measurer::{HeightMeasurer, MeasuredSection};
use super::page_layout::PageLayoutInfo;
use super::style_resolver::ResolvedStyleSet;
use crate::model::control::Control;
use crate::model::footnote::{Footnote, FootnoteShape};
use crate::model::header_footer::HeaderFooterApply;
use crate::model::page::{ColumnDef, PageDef};
use crate::model::paragraph::Paragraph;

pub fn estimate_footnote_note_height(footnote: &Footnote, dpi: f64) -> f64 {
    let mut height = 0.0;
    for para in &footnote.paragraphs {
        if para.line_segs.is_empty() {
            height += super::hwpunit_to_px(400, dpi);
        } else {
            for seg in &para.line_segs {
                height += super::hwpunit_to_px(seg.line_height, dpi);
            }
        }
    }
    if height <= 0.0 {
        super::hwpunit_to_px(400, dpi)
    } else {
        height
    }
}

pub fn footnote_separator_overhead_px(shape: &FootnoteShape, dpi: f64) -> f64 {
    super::hwpunit_to_px(shape.separator_above_margin_hu() as i32, dpi)
        + super::layout::border_width_to_px(shape.separator_line_width).max(0.5)
        + super::hwpunit_to_px(shape.separator_below_margin_hu() as i32, dpi)
}

pub fn footnote_between_notes_margin_px(shape: &FootnoteShape, dpi: f64) -> f64 {
    super::hwpunit_to_px(shape.between_notes_margin_hu() as i32, dpi)
}

/// Infer the source fragment boundary for a visible paragraph whose stored
/// LineSegs disappeared during conversion.
///
/// Both pagination engines call this function. Geometry proximity alone is
/// insufficient: the source-format reset provenance is what permits turning a
/// near-page-end fit into a physical fragment boundary.
pub(crate) fn missing_lineseg_fragment_boundary(
    para: &Paragraph,
    line_count: usize,
    current_height: f64,
    available: f64,
    trailing_line_spacing: f64,
    source_uses_inline_field_reset: bool,
    hwp3_converted_missing_lineseg: bool,
) -> Option<usize> {
    let minimum_fill_ratio = if hwp3_converted_missing_lineseg {
        1.0 - 1.0 / line_count as f64
    } else {
        0.75
    };
    let fill_height = if hwp3_converted_missing_lineseg {
        current_height + trailing_line_spacing.max(0.0)
    } else {
        current_height
    };
    let has_visible_text = para
        .text
        .chars()
        .any(|ch| ch > '\u{001F}' && ch != '\u{FFFC}');
    let controls_are_inline_text_metadata = para
        .controls
        .iter()
        .all(|control| matches!(control, Control::Field(_) | Control::Hyperlink(_)));
    if !para.line_segs.is_empty()
        || line_count < 4
        || fill_height < available * minimum_fill_ratio
        || !has_visible_text
        || !source_uses_inline_field_reset
        || !controls_are_inline_text_metadata
    {
        return None;
    }

    if hwp3_converted_missing_lineseg {
        Some((line_count + 1) / 2)
    } else {
        Some(line_count - 1)
    }
}

/// 미주 참조
#[derive(Debug, Clone)]
pub struct EndnoteRef {
    /// 미주 번호 (1-based)
    pub number: u16,
    /// 소속 구역 인덱스
    pub section_index: usize,
    /// 본문 문단 인덱스
    pub para_index: usize,
    /// 문단 내 컨트롤 인덱스
    pub control_index: usize,
}

/// [미주 배치 — END_OF_DOCUMENT] 문서 끝으로 미룬, 앞선 구역의 미주 하나.
/// Hancom 의 `EndnoteEndOfDocument` 배치를 정합: 참조 표시(위첨자 번호)는 원래
/// 구역 본문 흐름에 남고, 본문(body)만 마지막 구역 끝(=문서 끝)에서 렌더된다.
/// `reff` 는 원래 참조 위치(문서 순서·번호 보존), `endnote` 는 문서 끝에서 렌더할
/// 미주 본문(앞선 구역 paragraphs 에서 복제).
#[derive(Debug, Clone)]
pub struct DeferredEndnote {
    pub reff: EndnoteRef,
    pub endnote: crate::model::footnote::Endnote,
}

/// 이 구역의 미주를 어떻게 배치할지 (Hancom: EndnoteEndOfSection vs EndnoteEndOfDocument).
pub enum EndnoteDeferral<'a> {
    /// 기본: 이 구역 미주를 구역 끝에 렌더 (END_OF_SECTION, 그리고 단일 구역
    /// END_OF_DOCUMENT — 구역 끝 ≡ 문서 끝이라 결과 동일).
    None,
    /// END_OF_DOCUMENT, 마지막이 아닌 구역: 본문 렌더를 억제(참조 표시는 인라인
    /// 유지)하고 미주 본문은 문서 끝으로 미룬다.
    Suppress,
    /// END_OF_DOCUMENT, 마지막 구역: 앞선 구역들의 미주 본문(문서 순서)에 이어
    /// 이 구역 미주를 모두 문서 끝에 렌더한다.
    RenderAll(&'a [DeferredEndnote]),
}

/// 렌더용으로 가상 삽입된 미주 문단의 원본 위치.
#[derive(Debug, Clone)]
pub struct EndnoteParaSource {
    /// 소속 구역 인덱스
    pub section_index: usize,
    /// 원본 Endnote 컨트롤이 있는 본문 문단 인덱스
    pub para_index: usize,
    /// 본문 문단 내 Endnote 컨트롤 인덱스
    pub control_index: usize,
    /// Endnote 내부 문단 인덱스
    pub note_para_index: usize,
}

/// 페이지 분할 결과: 페이지별 콘텐츠 참조
#[derive(Debug)]
pub struct PaginationResult {
    /// Actual selected-composition facts from this allocator pass; no export permission.
    pub(crate) selected_composition_trace: Option<std::sync::Arc<super::selected_composition_observer127::FinalizedSelectedCompositionTrace>>,
    /// Actual formatter objects required by a current remapped fragment; no export permission.
    pub(crate) required_plain_paint: Option<std::sync::Arc<super::selected_composition_observer127::RequiredPlainPaint>>,
    /// 페이지별 콘텐츠 목록
    pub pages: Vec<PageContent>,
    /// 어울림 배치 표와 나란히 배치되는 빈 리턴 문단 목록 (전체)
    pub wrap_around_paras: Vec<WrapAroundPara>,
    /// 빈 줄 감추기로 높이 0 처리된 문단 인덱스 집합
    pub hidden_empty_paras: std::collections::HashSet<usize>,
    /// [Task #1755] 지연 이월 표의 host 텍스트 줄이 typeset 에서 이월 전 쪽에
    /// PartialParagraph 로 pre-emit 된 문단 집합 — layout 의 마지막 fragment 뒤
    /// host 렌더(`render_deferred_rowbreak_host_text_after`) 이중 렌더 억제용.
    pub pre_emitted_host_paras: std::collections::HashSet<usize>,
    /// [#2015] pre-emit 한 host 텍스트 높이(px). layout 이 vert_offset 이중계상을 보정할 때 사용.
    pub pre_emitted_host_heights: std::collections::HashMap<usize, f64>,
    /// [#7418] pre-emit 한 host 글의 내용 높이(px, 마지막 줄간격 제외).
    pub pre_emitted_host_content_heights: std::collections::HashMap<usize, f64>,
    /// 섹션별 미주 목록 (문서 끝 또는 섹션 끝에 렌더)
    pub endnotes: Vec<EndnoteRef>,
    /// [Task #836] 미주 paragraphs (endnote_para_base + idx 로 lookup)
    pub endnote_paragraphs: Vec<crate::model::paragraph::Paragraph>,
    /// `endnote_paragraphs` 각 항목의 원본 Endnote 내부 위치.
    pub endnote_para_sources: Vec<EndnoteParaSource>,
    /// [Task #1246] 현재 섹션 미주의 between-notes 마진(HU, 0=미적용). HeightCursor 가 미주 사이
    /// min-gap 보정에 사용.
    pub endnote_between_notes_hu: i32,
    /// 현재 섹션 미주의 정규화된 "구분선 위" 마진(HU).
    pub endnote_separator_above_hu: i32,
    /// 현재 섹션 미주의 정규화된 "구분선 아래" 마진(HU).
    pub endnote_separator_below_hu: i32,
}

/// 한 페이지에 배치될 콘텐츠
#[derive(Debug, Clone)]
pub struct PageContent {
    /// 페이지 인덱스 (0-based)
    pub page_index: u32,
    /// 실제 쪽 번호 (NewNumber 반영, 1-based)
    pub page_number: u32,
    /// 소속 구역 인덱스
    pub section_index: usize,
    /// 페이지 레이아웃 정보
    pub layout: PageLayoutInfo,
    /// 단별 콘텐츠
    pub column_contents: Vec<ColumnContent>,
    /// 이 페이지에 적용할 머리말 (None이면 머리말 없음)
    pub active_header: Option<HeaderFooterRef>,
    /// 이 페이지에 적용할 꼬리말 (None이면 꼬리말 없음)
    pub active_footer: Option<HeaderFooterRef>,
    /// 이 페이지에서 `새 번호로 시작`(NewNumber)이 발화해 `page_number` 가 재설정됐는지.
    ///
    /// 재시작 값은 절대값이므로 이 페이지부터는 구역 간 쪽번호 carry 를 더하면 안 된다
    /// (Issue #6206 — 표 셀 안 `newNum` 이 carry 판정에서도 누락돼 재시작 값에 carry 가
    /// 얹혔다).
    pub page_number_restarted: bool,
    /// 쪽 번호 위치 (None이면 쪽 번호 표시 안 함)
    pub page_number_pos: Option<crate::model::control::PageNumberPos>,
    /// 감추기 설정 (None이면 감추기 없음)
    pub page_hide: Option<crate::model::control::PageHide>,
    /// 이 페이지에 배치될 각주 목록
    pub footnotes: Vec<FootnoteRef>,
    /// 이 페이지에 적용할 바탕쪽 (None이면 바탕쪽 없음)
    pub active_master_page: Option<MasterPageRef>,
    /// 확장 바탕쪽 (임의 쪽 등, 기본 바탕쪽에 추가로 적용)
    pub extra_master_pages: Vec<MasterPageRef>,
    /// [#5699 H1] 이 쪽에서 typeset 이 "사다리-미계상 표 밴드" 자기모순을 판별해
    /// 실높이로 교정한 표들 `(para_index, control_index)`. 렌더러는 이 표들 뒤의
    /// 저장 vpos 후방 스냅을 페인트된 밴드 아래로 막는다 — typeset 판정과 렌더
    /// 판정이 갈라지지 않도록 신호를 명시 전달한다(tac-img-02 비대칭 발동 실측).
    pub ladder_band_tables: Vec<(usize, usize)>,
}

/// 바탕쪽 참조
#[derive(Debug, Clone)]
pub struct MasterPageRef {
    /// 구역 인덱스
    pub section_index: usize,
    /// master_pages 배열 내 인덱스
    pub master_page_index: usize,
}

/// 표 셀 안에 중첩된 머리말/꼬리말 컨트롤로 내려가는 경로 한 단계.
///
/// 최상위 문단 → 표 → 셀 → 셀 문단 순으로 내려간다. 여러 단계가 쌓이면
/// 표 안의 표처럼 다중 중첩도 표현할 수 있다.
#[derive(Debug, Clone)]
pub struct HeaderFooterTableStep {
    /// 바깥 controls 리스트에서 Table 컨트롤의 인덱스
    pub table_control_index: usize,
    /// 표 셀 인덱스
    pub cell_index: usize,
    /// 셀 내부 문단 인덱스
    pub cell_para_index: usize,
}

/// 머리말/꼬리말 참조
#[derive(Debug, Clone)]
pub struct HeaderFooterRef {
    /// Header/Footer 컨트롤이 있는 (최상위) 문단 인덱스
    pub para_index: usize,
    /// Header/Footer 컨트롤이 위치한 (가장 안쪽) controls 리스트 내 인덱스
    pub control_index: usize,
    /// Header/Footer 컨트롤이 속한 구역 인덱스 (구역 간 상속 시 원본 구역 추적용)
    pub source_section_index: usize,
    /// 표 셀 안에 중첩된 경우의 경로. 비어 있으면 최상위 문단 직속 컨트롤.
    ///
    /// HWP 시험지(예: 수능 수학 선택과목 소책자)는 4쪽짜리 소책자의 4쪽 머리말을
    /// 제목표(1x1 표) 셀 안에 정의하기도 한다. 이 경로가 없으면 그 머리말이
    /// 수집되지 않아 4쪽 쪽번호가 2쪽 머리말로 대체돼 잘못 표시된다.
    pub table_path: Vec<HeaderFooterTableStep>,
}

/// 표 셀 안에 중첩된 Header/Footer 컨트롤을 재귀적으로 수집한다.
///
/// `base_path` 는 바깥 문단에서 `table` 까지 내려온 경로(마지막 단계의 셀/문단은
/// 이 함수 안에서 채운다). 수집된 항목은 최상위 문단 인덱스 `pi` 를 그대로 써서
/// 페이지 매핑 정합성을 유지한다(PageHide 수집과 동일 규약).
pub(crate) fn collect_nested_header_footer_controls(
    table: &crate::model::table::Table,
    pi: usize,
    section_index: usize,
    table_control_index: usize,
    base_path: &[HeaderFooterTableStep],
    hf_entries: &mut Vec<(usize, HeaderFooterRef, bool, HeaderFooterApply)>,
) {
    for (cell_idx, cell) in table.cells.iter().enumerate() {
        for (cpi, cp) in cell.paragraphs.iter().enumerate() {
            let mut path = base_path.to_vec();
            path.push(HeaderFooterTableStep {
                table_control_index,
                cell_index: cell_idx,
                cell_para_index: cpi,
            });
            for (cci, ctrl) in cp.controls.iter().enumerate() {
                match ctrl {
                    Control::Header(h) => {
                        hf_entries.push((
                            pi,
                            HeaderFooterRef {
                                para_index: pi,
                                control_index: cci,
                                source_section_index: section_index,
                                table_path: path.clone(),
                            },
                            true,
                            h.apply_to,
                        ));
                    }
                    Control::Footer(f) => {
                        hf_entries.push((
                            pi,
                            HeaderFooterRef {
                                para_index: pi,
                                control_index: cci,
                                source_section_index: section_index,
                                table_path: path.clone(),
                            },
                            false,
                            f.apply_to,
                        ));
                    }
                    Control::Table(inner) => {
                        collect_nested_header_footer_controls(
                            inner,
                            pi,
                            section_index,
                            cci,
                            &path,
                            hf_entries,
                        );
                    }
                    _ => {}
                }
            }
        }
    }
}

/// `HeaderFooterRef` 가 가리키는 Header/Footer 컨트롤을 원본 문단 슬라이스에서 해석한다.
/// `table_path` 를 따라 표 셀 안까지 내려간다.
pub(crate) fn resolve_header_footer_control<'a>(
    paragraphs: &'a [Paragraph],
    hf_ref: &HeaderFooterRef,
) -> Option<&'a Control> {
    let mut para = paragraphs.get(hf_ref.para_index)?;
    for step in &hf_ref.table_path {
        let Control::Table(table) = para.controls.get(step.table_control_index)? else {
            return None;
        };
        para = table
            .cells
            .get(step.cell_index)?
            .paragraphs
            .get(step.cell_para_index)?;
    }
    para.controls.get(hf_ref.control_index)
}

/// 쪽별 활성 머리말/꼬리말 선택기.
///
/// 등장한 컨트롤을 **종류별 칸에 나눠** 누적하고, 쓸 때 쪽 홀짝에 맞춰 고른다. 홀수/짝수
/// 전용이 양 쪽보다 **더 구체적**이므로 우선한다 — 문서 안에서 어느 컨트롤이 먼저
/// 등장했는지와 무관해야 한다.
///
/// 한 변수에 덮어쓰며 누적하면 "마지막에 일치한 것" 이 이기고, 그러면 양 쪽 머리말을
/// 나중에 추가했다는 이유만으로 홀수 전용 머리말이 홀수 쪽에서 사라진다 (Task #3234).
#[derive(Debug, Default, Clone)]
pub struct ActiveHeaderFooter {
    header_both: Option<HeaderFooterRef>,
    header_even: Option<HeaderFooterRef>,
    header_odd: Option<HeaderFooterRef>,
    footer_both: Option<HeaderFooterRef>,
    footer_even: Option<HeaderFooterRef>,
    footer_odd: Option<HeaderFooterRef>,
}

impl ActiveHeaderFooter {
    /// `page_last_para` 까지 등장한 컨트롤을 누적한다.
    ///
    /// 누적은 쪽을 넘어가며 유지된다 — 머리말은 정의된 문단이 나온 쪽부터 이후 쪽에도
    /// 계속 적용되기 때문이다.
    pub fn accumulate(
        &mut self,
        entries: &[(usize, HeaderFooterRef, bool, HeaderFooterApply)],
        page_last_para: usize,
    ) {
        for (para_idx, hf_ref, is_header, apply_to) in entries {
            if *para_idx > page_last_para {
                continue;
            }
            let slot = match (is_header, apply_to) {
                (true, HeaderFooterApply::Both) => &mut self.header_both,
                (true, HeaderFooterApply::Even) => &mut self.header_even,
                (true, HeaderFooterApply::Odd) => &mut self.header_odd,
                (false, HeaderFooterApply::Both) => &mut self.footer_both,
                (false, HeaderFooterApply::Even) => &mut self.footer_even,
                (false, HeaderFooterApply::Odd) => &mut self.footer_odd,
            };
            *slot = Some(hf_ref.clone());
        }
    }

    /// 쪽 번호에 대한 활성 (머리말, 꼬리말).
    pub fn active(&self, page_number: u32) -> (Option<HeaderFooterRef>, Option<HeaderFooterRef>) {
        let is_odd = page_number % 2 == 1;
        let pick = |odd: &Option<HeaderFooterRef>,
                    even: &Option<HeaderFooterRef>,
                    both: &Option<HeaderFooterRef>| {
            if is_odd {
                odd.clone().or_else(|| both.clone())
            } else {
                even.clone().or_else(|| both.clone())
            }
        };
        (
            pick(&self.header_odd, &self.header_even, &self.header_both),
            pick(&self.footer_odd, &self.footer_even, &self.footer_both),
        )
    }
}

/// 각주 출처 (본문 문단 또는 표 셀 내)
#[derive(Debug, Clone)]
pub enum FootnoteSource {
    /// 본문 문단 내 각주
    Body {
        para_index: usize,
        control_index: usize,
    },
    /// 표 셀 내 각주
    TableCell {
        para_index: usize,
        table_control_index: usize,
        cell_index: usize,
        cell_para_index: usize,
        cell_control_index: usize,
    },
    /// 글상자(Shape TextBox) 내 각주
    ShapeTextBox {
        para_index: usize,
        shape_control_index: usize,
        tb_para_index: usize,
        tb_control_index: usize,
    },
}

/// 한 각주를 물리 페이지 경계에서 나눈 line fragment.
///
/// `start_line..end_line`은 각주 안의 문단을 순서대로 compose한 뒤의 평탄 line index다.
/// `end_line`은 끝 줄을 포함하지 않는다. 번호는 첫 조각에만 표시하며,
/// 물리 쪽의 각주 구분선 표시는 번호와 별도로 결정한다.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct FootnoteFragment {
    pub start_line: usize,
    pub end_line: usize,
    pub draw_separator: bool,
    pub draw_number: bool,
}

/// 페이지에 배치되는 각주 참조
#[derive(Debug, Clone)]
pub struct FootnoteRef {
    /// 각주 번호 (1-based)
    pub number: u16,
    /// 출처
    pub source: FootnoteSource,
    /// `None`이면 각주 전체를 그린다.
    pub fragment: Option<FootnoteFragment>,
}

/// 한 단(Column)에 배치될 콘텐츠
#[derive(Debug, Clone)]
pub struct ColumnContent {
    /// 문단 텍스트 앞/뒤 관계로 확정한 자리차지 표 배치(단 상대 좌표).
    pub paragraph_float_placements:
        std::collections::HashMap<(usize, usize), super::float_placement::ParagraphFloatPlacement>,
    /// #6812: 텍스트와 TAC 표가 공유하는 확정 줄 결과(단 상대 좌표).
    pub inline_flow_plans: std::collections::HashMap<usize, super::inline_flow::InlineFlowPlan>,
    /// #6812: 분할기에서 확정한 단 기준 TAC 배치. 그림 paint 순서와 무관하다.
    pub inline_placements:
        std::collections::HashMap<(usize, usize), super::float_placement::InlineBoxPlacement>,
    /// 단 인덱스 (0-based)
    pub column_index: u16,
    /// 단 시작 시점의 논리 높이(px).
    ///
    /// 미주 vpos 되감김 보정은 다음 단/쪽을 음수 높이에서 시작시켜
    /// 페이지 수를 한컴과 맞춘다. 렌더러도 같은 시작 높이를 알아야
    /// typeset에서 허용한 항목들이 실제 그림에서 하단을 넘지 않는다.
    pub start_height: f64,
    /// 이 단이 미주 흐름을 포함하는지 여부.
    ///
    /// 미주 본문은 일반 본문과 달리 한 단 안에서도 LINE_SEG vpos가 크게
    /// 되감길 수 있으므로, 렌더러의 vpos 보정 가드에서 별도 취급한다.
    pub endnote_flow: bool,
    /// 배치될 문단 슬라이스 정보
    pub items: Vec<PageItem>,
    /// 이 존의 레이아웃 (None이면 page.layout 사용). 다단 설정 나누기로 같은 페이지 내 단 수 변경 시 사용.
    pub zone_layout: Option<PageLayoutInfo>,
    /// 이 존의 body_area 내 y 시작 오프셋 (px). 이전 존의 높이만큼 아래로 밀림.
    pub zone_y_offset: f64,
    /// 어울림 배치 표와 나란히 배치되는 빈 리턴 문단 인덱스 목록
    /// (표 오른쪽에 문단 부호를 표시하기 위해 사용)
    pub wrap_around_paras: Vec<WrapAroundPara>,
    /// 단을 닫을 시점의 누적 사용 높이 (px). 진단/측정 도구용.
    pub used_height: f64,
    /// [Task #604 R3] anchor 그림/표 옆 wrap text 문단의 wrap context 메타데이터.
    /// typeset.rs 의 wrap_around state machine 매칭 결과 (anchor cs/sw 일치) 를
    /// layout 시점까지 보존. layout 이 본 메타데이터로 wrap zone 판정 + LineSeg cs/sw
    /// 정합 렌더 (PR #589 wrap_precomputed 메커니즘 대체).
    pub wrap_anchors: std::collections::HashMap<usize, WrapAnchorRef>,
    /// [#4568] 앞 쪽에서 쪽 하단에 잘린 overlay 표의 **잔여 행**을 이 단 최상단에
    /// 이어 그리기 위한 목록.
    ///
    /// `items` 에 섞지 않는 이유는 소유 의미가 다르기 때문이다 — 잔여 행은 흐름을
    /// 소비하지 않는 z-layer 장식이고 이 단이 그 문단을 소유하지도 않는다. 항목으로
    /// 넣으면 이 조각이 단의 **첫 항목**이 되어 `items.first()` 를 보는 휴리스틱들이
    /// 조각을 본문으로 읽는다(실측: `overflow_cell_baseline` 래칫 62 → 63줄).
    pub overlay_continuations: Vec<OverlayContinuation>,
    /// [#4568] 이 단에서 잔여 행을 다음 쪽에 넘긴 overlay 표의 **앵커 쪽 컷**.
    /// `(para_index, control_index, end_row)` — 앵커 그리기는 `0..end_row` 만 그린다.
    /// 넘긴 행을 앵커 쪽에서도 전부 그리면(bleed) 시각적으로는 클립돼 안 보이지만
    /// render tree 에 쪽 밖 줄이 남아 `overflow_cell_baseline` 래칫에 계상된다.
    pub overlay_cuts: Vec<(usize, usize, usize)>,
}

/// [#4568] 쪽을 넘긴 overlay 표의 잔여 행 조각.
#[derive(Debug, Clone)]
pub struct OverlayContinuation {
    /// 표 컨트롤이 있는 원본 문단 인덱스
    pub para_index: usize,
    /// 문단 내 컨트롤 인덱스
    pub control_index: usize,
    /// 이 단에서 그릴 첫 행 (inclusive). 앞 쪽이 이미 그린 행 수와 같다.
    pub start_row: usize,
    /// [#5792] 이 단 최상단에 잔여 행이 차지하는 높이(px). 0 이면 예약하지 않는다.
    ///
    /// 뒤따르는 흐름이 잔여 행의 자리를 스스로 만드는 형상(#4514 필러 문단)에서는
    /// 0 이어야 이중 계상이 없다. 판정은 typeset 한 곳에서만 한다.
    pub reserve_px: f64,
}

/// 어울림 배치 표 옆에 배치되는 빈 리턴 문단 정보
#[derive(Debug, Clone)]
pub struct WrapAroundPara {
    /// 어울림 문단의 인덱스
    pub para_index: usize,
    /// 연관된 표의 문단 인덱스
    pub table_para_index: usize,
    /// 텍스트가 있는 문단인지 (false면 빈 리턴)
    pub has_text: bool,
    /// 표 옆 띠에서 렌더할 첫 줄(포함).
    pub start_line: usize,
    /// 표 옆 띠에서 렌더할 끝 줄(제외). `usize::MAX`는 전체 줄을 뜻한다.
    pub end_line: usize,
}

/// [Task #604 R3] anchor 그림/표 ↔ wrap text 문단 매칭 메타데이터.
///
/// typeset.rs 의 wrap_around state machine 이 본 문단의 LineSeg cs/sw 가 anchor
/// 의 cs/sw 와 매칭됨을 검출 시 ColumnContent.wrap_anchors 에 등록. layout 단계가
/// 본 메타데이터로 wrap zone 정합 렌더 (LineSeg cs/sw 그대로 사용 — 현 보완6 효과).
#[derive(Debug, Clone)]
pub struct WrapAnchorRef {
    /// anchor 문단 인덱스 (그림/표 보유)
    pub anchor_para_index: usize,
    /// anchor wrap zone column_start (HWPUNIT)
    pub anchor_cs: i32,
    /// anchor wrap zone segment_width (HWPUNIT)
    pub anchor_sw: i32,
    /// [Task #722] anchor image 의 outer margin_right (HWPUNIT).
    /// 한컴 viewer 는 inter-image-text gap 으로 image margin_right 를 추가 적용.
    /// paragraph_layout 의 wrap_anchor 처리에서 cs px 에 +margin_right_px,
    /// sw px 에서 -margin_right_px 보정 (text 시작 위치와 가용 폭 정합).
    pub anchor_image_margin_right: i32,
    /// 줄 단위 배제 밴드 — Some((top, bottom)) 이면 문단 시작 기준 상대 y(px)가
    /// 이 구간과 교차하는 줄에만 anchor cs/sw 를 적용한다(출석부 형상). None 이면
    /// 기존처럼 문단 전체에 적용.
    pub band_y_range: Option<(f64, f64)>,
}

/// 페이지에 배치되는 개별 항목
#[derive(Debug, Clone)]
pub enum PageItem {
    /// 문단 전체가 배치됨
    FullParagraph {
        /// 원본 문단 인덱스
        para_index: usize,
    },
    /// 문단 일부가 배치됨 (페이지 넘김)
    PartialParagraph {
        /// 원본 문단 인덱스
        para_index: usize,
        /// 시작 줄 인덱스 (LineSeg 인덱스)
        start_line: usize,
        /// 끝 줄 인덱스 (exclusive)
        end_line: usize,
    },
    /// 표 전체
    Table {
        /// 원본 문단 내 컨트롤 인덱스
        para_index: usize,
        control_index: usize,
    },
    /// 표의 일부 행만 배치 (페이지 분할)
    PartialTable {
        /// 원본 문단 인덱스
        para_index: usize,
        /// 컨트롤 인덱스
        control_index: usize,
        /// 시작 행 (inclusive)
        start_row: usize,
        /// 끝 행 (exclusive)
        end_row: usize,
        /// 연속 페이지 여부 (true면 제목행 반복)
        is_continuation: bool,
        /// [Task #993] `start_row`의 시작 컷 — 셀별(col 오름차순 `row_span==1`
        /// 셀) 이전 페이지까지 소비한 콘텐츠 유닛 수. 빈 Vec = 처음부터.
        start_cut: Vec<usize>,
        /// [Task #993] `end_row-1`행의 끝 컷 — 이 페이지에서 보일 마지막 유닛
        /// 까지의 셀별 소비 유닛 수. 빈 Vec = 끝까지.
        end_cut: Vec<usize>,
        /// [Task #1025] 기존 블록 조각 게이트: 시작 또는 끝 분할이 rowspan 블록
        /// 경로를 사용했으면 true다. 끝 컷 소비 지점은 이 legacy 게이트와 행-지역
        /// fallback을 유지한다. 끝 컷만의 인덱스 공간이라고 해석하면 안 된다.
        ///
        /// [#6935] 시작 컷은 `start_cut_is_block`이 명시한 공간으로만 해석한다.
        /// 시작이 행 공간이고 끝이 블록 공간인 조각에서 이 게이트를 시작 쪽에도
        /// 적용하면 앞 조각 내용을 다시 소비한다. 반대 방향의 끝 컷 전용 전환은
        /// block→row 예약/배치 계약과 함께 검증해야 하므로 이 변경에 포함하지 않는다.
        is_block_split: bool,
        /// [#6935] true 이면 **`start_cut`** 이 블록-셀 `(row,col)` 인덱스다.
        ///
        /// 종전에는 `is_block_split` 하나가 두 사실을 OR 로 합쳐, 시작이 행 공간인데
        /// 끝이 블록 공간인 조각에서 시작 쪽이 블록 서수로 읽혔다. 걸친 rowspan 셀은
        /// 행 공간에 자리가 없어 `su = 0` 으로 떨어져 **앞 조각이 그린 내용을 처음부터
        /// 다시 그렸다**(같은 문서 2쪽 +341자, 본문 +232.3px).
        start_cut_is_block: bool,
        /// [Issue #4326] `start_row`/`end_row`/`start_cut`/`end_cut`이 가리키는 좌표계.
        /// true면 투명 1×1 래퍼를 벗긴 중첩 표(측정기·`row_geometry_table`이 실제로 쓰는
        /// 표) 기준이고, false면 이 항목이 참조하는 바깥 `para_index`/`control_index`
        /// 표 자신의 행 도메인 기준이다. 렌더러가 값(`end_row <= table.row_count`)으로
        /// 되추론하던 것을 페이지네이션 결정 시점에 데이터로 고정한다.
        row_cursor_is_nested: bool,
        /// RowBreak 표에서 이전 rowspan이 닿는 마지막 행을 현재 조각의 남은
        /// 물리 높이에 맞춰 배치해야 할 때의 마지막 행 높이 상한(px).
        ///
        /// 내용은 이미 이 조각에 모두 소비됐지만 선언 행 높이만 남은 공간보다
        /// 큰 경우에만 사용한다. 다음 조각은 끝행의 full cut으로 재진입해 남은
        /// 빈 밴드만 소비하므로, 이 값은 cursor/cut 계약과 짝을 이룬다.
        end_row_height_override: Option<f64>,
        /// 직전 조각에서 내용이 모두 소비된 시작 행의 남은 빈 물리 밴드 높이(px).
        /// `start_cut`은 해당 셀 내용을 숨기고 이 값은 테두리/셀 기하만 보존한다.
        start_row_height_override: Option<f64>,
    },
    /// 그리기 개체
    Shape {
        /// 원본 문단 내 컨트롤 인덱스
        para_index: usize,
        control_index: usize,
    },
    /// 미주 영역 시작 구분선
    EndnoteSeparator {
        /// 구분선 길이 (HWP 단위). 한컴 전폭 sentinel(14692344)이 i16을 넘으므로 i32.
        separator_length: i32,
        /// 구분선 위 여백 (HWP 단위)
        margin_above: i16,
        /// 구분선 아래 여백 (HWP 단위)
        margin_below: i16,
        /// 구분선 종류
        line_type: u8,
        /// 구분선 굵기
        line_width: u8,
        /// 구분선 색상
        color: crate::model::ColorRef,
    },
}

/// [Issue #476] 인라인(treat_as_char) 컨트롤이 라우팅된 페이지/단을 찾는다.
///
/// `pages`: 이미 finalize 된 이전 페이지들의 ColumnContent(items 포함).
/// `current_items`: 현재(마지막) 페이지의 진행 중 항목 목록 (아직 flush 안 된 상태).
///
/// 박스의 char 위치 → line index → 그 line 을 포함하는 PartialParagraph 가 들어있는
/// `(page_idx, column_idx)` 를 반환. 마지막 페이지(현재 처리 중)에 들어있으면 `None` (= 현재).
/// 어디에도 없거나 페이지 분할이 없으면 `None`.
pub fn find_inline_control_target_page(
    pages: &[PageContent],
    current_items: &[PageItem],
    para_idx: usize,
    ctrl_idx: usize,
    para: &Paragraph,
) -> Option<(usize, usize)> {
    let target_line = tac_object_owning_line_seg_index(para, ctrl_idx)
        .or_else(|| crate::renderer::layout::control_line_seg_index(para, ctrl_idx))?;

    // 1) 현재(마지막) 페이지의 current_items 검사 — 박스 line 이 여기 있으면 None (= 현재)
    let in_current = current_items.iter().any(|item| match item {
        PageItem::FullParagraph { para_index } if *para_index == para_idx => true,
        PageItem::PartialParagraph {
            para_index,
            start_line,
            end_line,
        } if *para_index == para_idx && (*start_line..*end_line).contains(&target_line) => true,
        _ => false,
    });
    if in_current {
        return None;
    }

    // 2) 이전 페이지/단 검색
    for (page_idx, page) in pages.iter().enumerate() {
        for (col_idx, col) in page.column_contents.iter().enumerate() {
            let hit = col.items.iter().any(|item| match item {
                PageItem::FullParagraph { para_index } if *para_index == para_idx => true,
                PageItem::PartialParagraph {
                    para_index,
                    start_line,
                    end_line,
                } if *para_index == para_idx && (*start_line..*end_line).contains(&target_line) => {
                    true
                }
                _ => false,
            });
            if hit {
                return Some((page_idx, col_idx));
            }
        }
    }
    None
}

/// TAC 개체가 소유한 저장 줄을 **기하**로 짚는다 — 저장 `line_height` 가 개체의 흐름
/// 높이와 같은 줄이 그 개체의 줄이다.
///
/// [#6972] 글자 위치 투영(`control_line_seg_index`)은 개체가 문단의 모든 글자 **앞**에
/// 있을 때 첫 글자의 줄, 곧 개체 줄의 **다음** 줄을 돌려준다(컨트롤 문자 0, 첫 글자
/// offset 0 이면 `p >= start_txt` 가 `0 >= 0` 으로 참). 그러면 문단이 쪽으로 갈릴 때
/// 전면 크기 TAC 그림이 자기 줄이 없는 뒤 조각으로 라우팅돼 **두 쪽에 그려진다**
/// (56288 1쪽 표지 그림). 같은 quirk 를 #6078 도 기하로 피해 갔다.
///
/// 같은 높이의 줄이 둘 이상이면(#2004 이미지 스택) 모호하므로 쓰지 않는다 — 그때는
/// 종전 글자 위치 투영으로 되돌아간다.
fn tac_object_owning_line_seg_index(para: &Paragraph, ctrl_idx: usize) -> Option<usize> {
    /// 8px @96dpi. `line_owning_tac_object_height_px` 의 하한과 같은 자리다.
    const MIN_OBJECT_LINE_HU: i32 = 600;

    if para.line_segs.len() < 2 {
        return None;
    }
    let ctrl = para.controls.get(ctrl_idx)?;
    if !is_routable_treat_as_char_picture_or_shape(ctrl) {
        return None;
    }
    let height_hu = crate::renderer::tac_object_flow_height_hu(ctrl)?;
    if height_hu < MIN_OBJECT_LINE_HU {
        return None;
    }
    let mut owner = None;
    for (idx, seg) in para.line_segs.iter().enumerate() {
        if seg.line_height == height_hu {
            if owner.is_some() {
                return None;
            }
            owner = Some(idx);
        }
    }
    owner
}

/// 페이지로 분할된 문단에서 해당 줄을 소유한 쪽으로 다시 배치해야 하는 인라인 개체인가.
///
/// `PageItem::Shape`는 개체 종류를 함께 담지만, 실제 그림/도형의 인라인 좌표는 문단의
/// 일부 줄만 렌더한 쪽에 등록된다. 문단 끝에서 일괄 추가하면 모든 TAC 그림이 마지막
/// 조각으로 몰린다. 표·수식은 별도 조판 경로와 소유 규칙을 가지므로 여기서 넓히지 않는다.
/// [#5941] 앵커 줄이 앞 쪽에 남은 그림/도형을 그 쪽으로 라우팅할 대상인지.
///
/// `is_routable_treat_as_char_picture_or_shape` 는 `treat_as_char` 만 받는다. 그런데
/// "문단이 쪽 분할되면 개체가 마지막 쪽에 붙는다" 는 문제는 TAC 여부와 무관하다.
/// 비-TAC 자리차지/어울림 개체도 같은 라우팅이 필요하다 — 목적지 판정은
/// `find_inline_control_target_page` 가 하고, 제자리 개체에는 `None` 을 돌려준다.
pub(crate) fn is_routable_anchored_picture_or_shape(control: &Control) -> bool {
    let common = match control {
        Control::Picture(picture) => &picture.common,
        Control::Shape(shape) => shape.common(),
        _ => return false,
    };
    // 종전 대상(글자처럼)은 그대로 두고, **용지 기준** 개체를 더한다.
    //
    // 용지 기준 개체는 세로 오프셋이 그 쪽 안의 절대 위치다 — 어느 쪽에 얹히느냐가
    // 정해져야 그 값이 뜻을 갖는다. 그래서 앵커 줄이 있는 쪽으로 보내야 한다.
    //
    // ⚠ **문단 기준까지 넓히면 안 된다.** `#2814` 의 절반쪽 그림 6장은 한 문단에
    // 공동 앵커돼 쪽마다 2장씩 분배되는데, 문단 기준까지 라우팅하면 5장이 첫 쪽으로
    // 몰려 `[5, 1]` 이 된다(실측). 그 개체들은 흐름이 자리를 정하는 쪽이다.
    common.treat_as_char || matches!(common.vert_rel_to, crate::model::shape::VertRelTo::Paper)
}

pub(crate) fn is_routable_treat_as_char_picture_or_shape(control: &Control) -> bool {
    match control {
        Control::Picture(picture) => picture.common.treat_as_char,
        Control::Shape(shape) => shape.common().treat_as_char,
        _ => false,
    }
}

impl PageItem {
    /// 항목의 para_index를 반환한다.
    pub fn para_index(&self) -> usize {
        match self {
            PageItem::FullParagraph { para_index } => *para_index,
            PageItem::PartialParagraph { para_index, .. } => *para_index,
            PageItem::Table { para_index, .. } => *para_index,
            PageItem::PartialTable { para_index, .. } => *para_index,
            PageItem::Shape { para_index, .. } => *para_index,
            PageItem::EndnoteSeparator { .. } => usize::MAX,
        }
    }

    /// para_index를 offset만큼 조정한 새 항목을 반환한다.
    pub fn with_offset(&self, offset: i32) -> Self {
        let adjust = |pi: usize| (pi as i64 + offset as i64).max(0) as usize;
        match self {
            PageItem::FullParagraph { para_index } => PageItem::FullParagraph {
                para_index: adjust(*para_index),
            },
            PageItem::PartialParagraph {
                para_index,
                start_line,
                end_line,
            } => PageItem::PartialParagraph {
                para_index: adjust(*para_index),
                start_line: *start_line,
                end_line: *end_line,
            },
            PageItem::Table {
                para_index,
                control_index,
            } => PageItem::Table {
                para_index: adjust(*para_index),
                control_index: *control_index,
            },
            PageItem::PartialTable {
                para_index,
                control_index,
                start_row,
                end_row,
                is_continuation,
                start_cut,
                end_cut,
                is_block_split,
                start_cut_is_block,
                row_cursor_is_nested,
                end_row_height_override,
                start_row_height_override,
            } => PageItem::PartialTable {
                para_index: adjust(*para_index),
                control_index: *control_index,
                start_row: *start_row,
                end_row: *end_row,
                is_continuation: *is_continuation,
                start_cut: start_cut.clone(),
                end_cut: end_cut.clone(),
                is_block_split: *is_block_split,
                start_cut_is_block: *start_cut_is_block,
                row_cursor_is_nested: *row_cursor_is_nested,
                end_row_height_override: *end_row_height_override,
                start_row_height_override: *start_row_height_override,
            },
            PageItem::Shape {
                para_index,
                control_index,
            } => PageItem::Shape {
                para_index: adjust(*para_index),
                control_index: *control_index,
            },
            PageItem::EndnoteSeparator {
                separator_length,
                margin_above,
                margin_below,
                line_type,
                line_width,
                color,
            } => PageItem::EndnoteSeparator {
                separator_length: *separator_length,
                margin_above: *margin_above,
                margin_below: *margin_below,
                line_type: *line_type,
                line_width: *line_width,
                color: *color,
            },
        }
    }

    /// 두 항목이 구조적으로 동일한지 비교 (para_index offset 적용).
    fn matches_with_offset(&self, other: &PageItem, offset: i32) -> bool {
        let adj = |pi: usize| (pi as i64 + offset as i64) as usize;
        match (self, other) {
            (
                PageItem::FullParagraph { para_index: a },
                PageItem::FullParagraph { para_index: b },
            ) => *a == adj(*b),
            (
                PageItem::PartialParagraph {
                    para_index: a,
                    start_line: s1,
                    end_line: e1,
                },
                PageItem::PartialParagraph {
                    para_index: b,
                    start_line: s2,
                    end_line: e2,
                },
            ) => *a == adj(*b) && s1 == s2 && e1 == e2,
            (
                PageItem::Table {
                    para_index: a,
                    control_index: c1,
                },
                PageItem::Table {
                    para_index: b,
                    control_index: c2,
                },
            ) => *a == adj(*b) && c1 == c2,
            (
                PageItem::PartialTable {
                    para_index: a,
                    control_index: c1,
                    start_row: sr1,
                    end_row: er1,
                    ..
                },
                PageItem::PartialTable {
                    para_index: b,
                    control_index: c2,
                    start_row: sr2,
                    end_row: er2,
                    ..
                },
            ) => *a == adj(*b) && c1 == c2 && sr1 == sr2 && er1 == er2,
            (
                PageItem::Shape {
                    para_index: a,
                    control_index: c1,
                },
                PageItem::Shape {
                    para_index: b,
                    control_index: c2,
                },
            ) => *a == adj(*b) && c1 == c2,
            (PageItem::EndnoteSeparator { .. }, PageItem::EndnoteSeparator { .. }) => true,
            _ => false,
        }
    }
}

impl PaginationResult {
    /// 이전 결과와 비교하여 수렴 페이지를 찾는다.
    /// offset: 문단 인덱스 변화량 (삽입=+1, 삭제=-1)
    /// 반환: 수렴 시작 페이지 인덱스 (None이면 수렴 없음)
    pub fn find_convergence(&self, old: &PaginationResult, offset: i32) -> Option<usize> {
        if offset == 0 {
            return Some(0);
        }
        for page_idx in 0..self.pages.len().min(old.pages.len()) {
            let new_page = &self.pages[page_idx];
            let old_page = &old.pages[page_idx];
            if new_page.column_contents.len() != old_page.column_contents.len() {
                continue;
            }
            let matched = new_page
                .column_contents
                .iter()
                .zip(old_page.column_contents.iter())
                .all(|(nc, oc)| {
                    nc.inline_flow_plans.len() == oc.inline_flow_plans.len()
                        && oc.inline_flow_plans.iter().all(|(&pi, plan)| {
                            let new_pi = (pi as i64 + offset as i64).max(0) as usize;
                            nc.inline_flow_plans.get(&new_pi) == Some(plan)
                        })
                        && nc.inline_placements.len() == oc.inline_placements.len()
                        && oc.inline_placements.iter().all(|(&(pi, ci), placement)| {
                            let new_pi = (pi as i64 + offset as i64).max(0) as usize;
                            nc.inline_placements.get(&(new_pi, ci)) == Some(placement)
                        })
                        && nc.items.len() == oc.items.len()
                        && nc
                            .items
                            .iter()
                            .zip(oc.items.iter())
                            .all(|(ni, oi)| ni.matches_with_offset(oi, offset))
                });
            if matched {
                return Some(page_idx);
            }
        }
        None
    }

    /// 수렴 이후 페이지를 이전 결과에서 복사한다 (para_index offset 적용).
    pub fn copy_converged_pages(
        &mut self,
        old: &PaginationResult,
        converge_page: usize,
        offset: i32,
    ) {
        // 수렴 페이지 이후를 이전 결과에서 복사
        self.pages.truncate(converge_page);
        for old_page in &old.pages[converge_page..] {
            let new_page = PageContent {
                page_index: old_page.page_index,
                page_number: old_page.page_number,
                page_number_restarted: old_page.page_number_restarted,
                section_index: old_page.section_index,
                layout: old_page.layout.clone(),
                column_contents: old_page
                    .column_contents
                    .iter()
                    .map(|cc| ColumnContent {
                        column_index: cc.column_index,
                        start_height: cc.start_height,
                        endnote_flow: cc.endnote_flow,
                        items: cc.items.iter().map(|it| it.with_offset(offset)).collect(),
                        overlay_continuations: cc.overlay_continuations.clone(),
                        overlay_cuts: cc.overlay_cuts.clone(),
                        inline_placements: cc
                            .inline_placements
                            .iter()
                            .map(|(&(pi, ci), &placement)| {
                                (((pi as i64 + offset as i64).max(0) as usize, ci), placement)
                            })
                            .collect(),
                        inline_flow_plans: cc
                            .inline_flow_plans
                            .iter()
                            .map(|(&pi, plan)| {
                                ((pi as i64 + offset as i64).max(0) as usize, plan.clone())
                            })
                            .collect(),
                        paragraph_float_placements: cc
                            .paragraph_float_placements
                            .iter()
                            .map(|(&(pi, ci), &placement)| {
                                (((pi as i64 + offset as i64).max(0) as usize, ci), placement)
                            })
                            .collect(),
                        zone_layout: cc.zone_layout.clone(),
                        zone_y_offset: cc.zone_y_offset,
                        wrap_around_paras: cc
                            .wrap_around_paras
                            .iter()
                            .map(|w| WrapAroundPara {
                                para_index: (w.para_index as i64 + offset as i64).max(0) as usize,
                                table_para_index: (w.table_para_index as i64 + offset as i64).max(0)
                                    as usize,
                                has_text: w.has_text,
                                start_line: w.start_line,
                                end_line: w.end_line,
                            })
                            .collect(),
                        used_height: cc.used_height,
                        wrap_anchors: cc
                            .wrap_anchors
                            .iter()
                            .map(|(k, v)| {
                                (
                                    (*k as i64 + offset as i64).max(0) as usize,
                                    WrapAnchorRef {
                                        anchor_para_index: (v.anchor_para_index as i64
                                            + offset as i64)
                                            .max(0)
                                            as usize,
                                        anchor_cs: v.anchor_cs,
                                        anchor_sw: v.anchor_sw,
                                        anchor_image_margin_right: v.anchor_image_margin_right,
                                        band_y_range: v.band_y_range,
                                    },
                                )
                            })
                            .collect(),
                    })
                    .collect(),
                active_header: old_page.active_header.clone(),
                active_footer: old_page.active_footer.clone(),
                page_number_pos: old_page.page_number_pos.clone(),
                page_hide: old_page.page_hide.clone(),
                footnotes: old_page
                    .footnotes
                    .iter()
                    .map(|f| {
                        let source = match &f.source {
                            FootnoteSource::Body {
                                para_index,
                                control_index,
                            } => FootnoteSource::Body {
                                para_index: (*para_index as i64 + offset as i64).max(0) as usize,
                                control_index: *control_index,
                            },
                            FootnoteSource::TableCell {
                                para_index,
                                table_control_index,
                                cell_index,
                                cell_para_index,
                                cell_control_index,
                            } => FootnoteSource::TableCell {
                                para_index: (*para_index as i64 + offset as i64).max(0) as usize,
                                table_control_index: *table_control_index,
                                cell_index: *cell_index,
                                cell_para_index: *cell_para_index,
                                cell_control_index: *cell_control_index,
                            },
                            FootnoteSource::ShapeTextBox {
                                para_index,
                                shape_control_index,
                                tb_para_index,
                                tb_control_index,
                            } => FootnoteSource::ShapeTextBox {
                                para_index: (*para_index as i64 + offset as i64).max(0) as usize,
                                shape_control_index: *shape_control_index,
                                tb_para_index: *tb_para_index,
                                tb_control_index: *tb_control_index,
                            },
                        };
                        FootnoteRef {
                            number: f.number,
                            source,
                            fragment: f.fragment,
                        }
                    })
                    .collect(),
                active_master_page: old_page.active_master_page.clone(),
                extra_master_pages: old_page.extra_master_pages.clone(),
                ladder_band_tables: old_page.ladder_band_tables.clone(),
            };
            // hidden_empty_paras는 별도 처리
            self.pages.push(new_page);
        }
        // wrap_around_paras도 복사
        for w in &old.wrap_around_paras {
            let shifted_pi = (w.para_index as i64 + offset as i64).max(0) as usize;
            let shifted_tpi = (w.table_para_index as i64 + offset as i64).max(0) as usize;
            if !self
                .wrap_around_paras
                .iter()
                .any(|e| e.para_index == shifted_pi)
            {
                self.wrap_around_paras.push(WrapAroundPara {
                    para_index: shifted_pi,
                    table_para_index: shifted_tpi,
                    has_text: w.has_text,
                    start_line: w.start_line,
                    end_line: w.end_line,
                });
            }
        }
        // hidden_empty_paras offset
        let mut new_hidden = std::collections::HashSet::new();
        for &pi in &old.hidden_empty_paras {
            new_hidden.insert((pi as i64 + offset as i64).max(0) as usize);
        }
        self.hidden_empty_paras = new_hidden;
    }
}

/// 페이지 분할 옵션
#[derive(Debug, Clone, Default)]
pub struct PaginationOpts {
    /// 빈 줄 숨김 (SectionDef.hide_empty_line)
    pub hide_empty_line: bool,
    /// LINE_SEG vpos-reset (vertical_pos==0, line>0) 위치를 강제 단/페이지 경계로 처리
    pub respect_vpos_reset: bool,
    /// [Task #1007] HWP3 → HWP5 변환본 (한컴 변환 산출물).
    /// 변환본의 cross-paragraph vpos reset (이전 paragraph 의 last_line vpos 가
    /// 페이지 절반 이상 + 현재 paragraph 의 first_line vpos 가 페이지 1/4 이내)
    /// 시 강제 page break — 한컴 변환 시 인코딩한 page break 시그널 인식.
    pub is_hwp3_variant: bool,
    /// 현재 구역의 각주 모양. 각주 예약 영역을 렌더 영역과 같은 metric으로 계산한다.
    pub footnote_shape: Option<FootnoteShape>,
}

#[derive(Debug, Clone, Copy, Default)]
struct PaginationSourceContext {
    source_uses_inline_field_reset: bool,
    hwp3_converted_missing_lineseg: bool,
    legacy_hwp3_stored_geometry: bool,
}

impl PaginationSourceContext {
    fn from_profile(profile: crate::model::provenance::LayoutCompatibilityProfile) -> Self {
        let hwp3_converted_missing_lineseg =
            profile.hwp3_layout() && !profile.hwp3_native_layout() && !profile.hwpx_container();
        Self {
            source_uses_inline_field_reset: profile.hwpx_stored_layout()
                || hwp3_converted_missing_lineseg,
            hwp3_converted_missing_lineseg,
            legacy_hwp3_stored_geometry: profile.legacy_hwp3_stored_geometry(),
        }
    }

    fn from_public_variant(is_hwp3_variant: bool) -> Self {
        Self {
            source_uses_inline_field_reset: is_hwp3_variant,
            hwp3_converted_missing_lineseg: is_hwp3_variant,
            legacy_hwp3_stored_geometry: is_hwp3_variant,
        }
    }
}

/// 페이지 분할 엔진
pub struct Paginator {
    /// DPI
    dpi: f64,
}

impl Paginator {
    pub fn new(dpi: f64) -> Self {
        Self { dpi }
    }

    /// 기본 DPI(96)로 생성
    pub fn with_default_dpi() -> Self {
        Self::new(super::DEFAULT_DPI)
    }

    /// 문단 내 단 경계를 감지한다.
    /// HWP에서 같은 너비 다단 레이아웃의 문단은 한 문단이 여러 단에 걸칠 수 있다.
    /// LineSeg의 vertical_pos가 급격히 감소(이전 줄의 vpos보다 작아짐)하면 단이 변경된 것.
    /// 반환: 각 단의 시작 줄 인덱스 목록 (첫 번째는 항상 0)
    fn detect_column_breaks_in_paragraph(para: &Paragraph) -> Vec<usize> {
        let mut breaks = vec![0usize];
        if para.line_segs.len() <= 1 {
            return breaks;
        }
        for i in 1..para.line_segs.len() {
            let prev_vpos = para.line_segs[i - 1].vertical_pos;
            let curr_vpos = para.line_segs[i].vertical_pos;
            // vpos가 이전보다 작아지면 단 경계
            if curr_vpos < prev_vpos {
                breaks.push(i);
            }
        }
        breaks
    }

    /// 구역의 문단 목록을 페이지로 분할한다.
    ///
    /// 2-패스 페이지네이션:
    /// 1. HeightMeasurer로 모든 콘텐츠의 실제 렌더링 높이를 사전 측정
    /// 2. 측정된 높이를 기반으로 정확한 페이지 분할 수행
    ///
    /// - 본문 영역 높이를 초과하면 새 페이지 시작
    /// - ColumnBreakType::Page이면 강제 페이지 넘김
    pub fn paginate(
        &self,
        paragraphs: &[Paragraph],
        composed: &[ComposedParagraph],
        styles: &ResolvedStyleSet,
        page_def: &PageDef,
        column_def: &ColumnDef,
        section_index: usize,
    ) -> (PaginationResult, MeasuredSection) {
        // === 1-패스: 높이 사전 측정 ===
        let measurer = HeightMeasurer::new(self.dpi);
        let layout = crate::renderer::page_layout::PageLayoutInfo::from_page_def(
            page_def, column_def, self.dpi,
        );
        let col_w = layout
            .column_areas
            .first()
            .map(|a| a.width)
            .unwrap_or(layout.body_area.width);
        let measured = measurer.measure_section(paragraphs, composed, styles, Some(col_w));

        // === 2-패스: 측정된 높이로 페이지 분할 ===
        let result = self.paginate_with_measured(
            paragraphs,
            &measured,
            page_def,
            column_def,
            section_index,
            &styles.para_styles,
        );
        (result, measured)
    }
}

mod engine;
mod state;

#[cfg(test)]
mod tests;
