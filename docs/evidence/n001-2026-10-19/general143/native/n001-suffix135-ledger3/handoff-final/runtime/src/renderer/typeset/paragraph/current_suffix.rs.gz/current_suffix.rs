//! Actual narrow-frame continuation of plain body text. This never reads saved
//! row positions as allocation authority and never rewrites prior commits.
use crate::model::paragraph::{Paragraph,ColumnBreakType};
use crate::renderer::{hwpunit_to_px,px_to_hwpunit,selected_composition_observer127 as observation};
use crate::renderer::style_resolver::ResolvedStyleSet;
use super::super::{TypesetEngine,TypesetState};
use super::metrics::FormattedParagraph;

fn plain(para:&Paragraph,styles:&ResolvedStyleSet)->Option<usize>{
 if !para.controls.is_empty()||para.column_type!=ColumnBreakType::None||!para.field_ranges.is_empty()
  ||!para.range_tags.is_empty()||!para.orphan_field_ends.is_empty()||!para.tab_extended.is_empty()
  ||para.numbering_restart.is_some()||!para.title_marks.is_empty()||!para.markpen_marks.is_empty()
  ||para.text.contains(['\t','\n','\r','\u{fffc}'])||para.text.len()>2*1024*1024{return None;}
 let style=styles.para_styles.get(usize::from(para.para_shape_id))?;
 if style.margin_left!=0.0||style.margin_right!=0.0||style.indent!=0.0||style.spacing_before!=0.0||style.spacing_after!=0.0
  ||!matches!(style.head_type,crate::model::style::HeadType::None)||styles.supplemental_metrics.is_some()
  ||styles.kerning_measurement_context.is_some()||styles.horizontal_shaping_context.is_some(){return None;}
 let mut units=0u32;let mut count=0usize;
 for (ch,offset) in para.text.chars().zip(&para.char_offsets){if *offset!=units{return None;}units=units.checked_add(ch.len_utf16() as u32)?;count+=1;}
 (count>0&&count==para.text.chars().count()&&count==para.char_offsets.len()&&para.char_count==units.checked_add(1)?).then_some(count)
}
fn exact_format(f:&observation::SelectedFormatFact,fmt:&FormattedParagraph,para:&Paragraph,dpi:f64)->Option<()>{
 if f.source_text!=para.text||f.source_char_offsets!=para.char_offsets||f.dpi!=dpi||f.known_square_band
  ||f.has_numbering||f.has_horizontal_shaping||!f.inline_controls.is_empty()||!f.tac_controls.is_empty()
  ||!f.footnote_positions.is_empty()||!f.tab_extended.is_empty()||f.lines.is_empty()||f.lines.len()>4096
  ||f.before!=0.0||f.after!=0.0||f.actual_heights!=fmt.line_heights||f.actual_spacings!=fmt.line_spacings
  ||f.lines.len()!=fmt.line_count(){return None;}
 let mut scalar=0usize;let mut units=0u32;
 for (i,l) in f.lines.iter().enumerate(){
  if l.scalar_start!=scalar||l.unicode_utf16_start!=Some(units)||!l.exact_source_text_span||l.has_line_break
   ||l.height_hu<=0||l.spacing_hu<0||l.baseline_hu<0||l.baseline_hu>l.height_hu||l.column_start_hu!=0
   ||fmt.line_heights[i]!=hwpunit_to_px(l.height_hu,dpi)||fmt.line_spacings[i]!=hwpunit_to_px(l.spacing_hu,dpi)
   ||l.original_hwp_char_offset!=para.char_offsets.get(scalar).copied(){return None;}
  for run in &l.runs{if run.inserted_control_text||run.display_text.is_some()||run.overlap.is_some()||run.footnote_marker.is_some(){return None;}
   units=units.checked_add(u32::try_from(run.utf16_units).ok()?)?;}
  let end=l.scalar_end?;if end<=scalar{return None;}scalar=end;if l.unicode_utf16_end!=Some(units){return None;}
 }
 (scalar==para.text.chars().count()).then_some(())
}
/// Only a continuation at an empty ordinary column can choose a new formatter.
/// Its exact consumed scalar must already be a real line start in that actual
/// formatter; no row is fabricated, retagged, relabelled, or retroactively moved.
pub(super) fn reformat(engine:&TypesetEngine,st:&TypesetState,para:&Paragraph,old:&FormattedParagraph,
 cursor:usize,styles:&ResolvedStyleSet,dpi:f64)->Option<(FormattedParagraph,usize)>{
 if cursor==0||dpi!=crate::renderer::DEFAULT_DPI||st.col_count<=1||!st.current_items.is_empty()||st.current_height!=0.0
  ||st.current_endnote_flow||st.current_footnote_height!=0.0||st.current_bottom_fixed_exclusion!=0.0||st.current_zone_y_offset!=0.0
  ||st.current_zone_layout.is_some()||st.wrap_around_cs>=0||!st.current_column_wrap_anchors.is_empty()
  ||!st.current_column_wrap_around_paras.is_empty()||!st.side_wrap_exclusions.is_empty()||!st.visible_float_exclusions.is_empty(){return None;}
 plain(para,styles)?;
 let width=st.layout.column_areas.get(usize::from(st.current_column))?.width;
 let (composition,fact)=observation::current_for_flow(old.selected_observation127?,para)?;
 exact_format(&fact,old,para,dpi)?;
 let previous_width=fact.actual_input_width_px?;
 if !width.is_finite()||width<=0.0||!previous_width.is_finite()||width>=previous_width{return None;}
 let bound=px_to_hwpunit(width,dpi);if bound<=0||!fact.lines.get(cursor..)?.iter().any(|l|l.width_hu>bound){return None;}
 let consumed=fact.lines.get(cursor)?.scalar_start;
 let fmt=engine.format_paragraph_with_known_square_band(para,Some(&composition),styles,Some(width),false);
 let (_,fresh)=observation::current_for_flow(fmt.selected_observation127?,para)?;
 exact_format(&fresh,&fmt,para,dpi)?;
 if !fresh.selected_recomposition||fresh.actual_input_width_px!=Some(width)||fresh.lines.iter().any(|l|l.width_hu<=0||l.width_hu>bound){return None;}
 let row=fresh.lines.iter().position(|l|l.scalar_start==consumed)?;
 if row==0||fresh.lines[row].unicode_utf16_start!=fact.lines[cursor].unicode_utf16_start{return None;}
 if !observation::require_plain_paint(old.selected_observation127?,fmt.selected_observation127?,para){return None;}
 Some((fmt,row))
}
/// This branch scans actual new rows only. Saved row indices refer to another
/// composition and must not be applied to the remapped continuation.
pub(super) fn scan(fmt:&FormattedParagraph,start:usize,available:f64)->Option<super::scan::LineScanResult>{
 if !available.is_finite()||available<0.0||start>=fmt.line_count(){return None;}
 let mut end=start;let mut cumulative=0.0;
 for i in start..fmt.line_count(){let h=fmt.line_heights[i];let step=fmt.line_advance(i);
  if !h.is_finite()||h<=0.0||!step.is_finite()||step<h{return None;}
  if end>start&&cumulative+h>available{break;}cumulative+=step;end=i+1;
 }
 Some(super::scan::LineScanResult{end_line:end,cumulative,used_saved_tail_vpos_fit:false})
}
