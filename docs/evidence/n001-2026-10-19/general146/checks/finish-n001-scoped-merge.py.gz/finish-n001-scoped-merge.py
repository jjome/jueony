from pathlib import Path
import sys,json
r=Path(__file__).resolve().parents[1];mode=sys.argv[1];stage=r/('build/n001-'+mode+'-merged')
script=(r/'build/merge-n001-scoped-delta.py').read_text(encoding='utf8');tail=script[script.index('resource=lf('):];prefix=script[:script.index('records=[];')]
resume='''
records=json.loads((stage/'initial-merge-proof.json').read_bytes())['records'];changes={}
extra=json.loads((stage/'extra-files.json').read_bytes())if(stage/'extra-files.json').exists()else[]
for p in extra:
 records.append({'path':p,'method':'explicit companion initializer adaptation','current':sha(lf((current/p).read_bytes()))})
for record in records:
 p=record['path'];b=lf((stage/p).read_bytes());assert b'<<<<<<<'not in b and not re.search(rb'\bPLACEHOLDER\b',b)
 record['merged']=sha(b);record['explicitResolution']=record['path']in json.loads((stage/'initial-merge-proof.json').read_bytes())['conflicts']
 before=lf((current/p).read_bytes())if(current/p).is_file()else b''
 if b!=before:changes[p]=b
'''
exec(compile(prefix+resume+tail,str(r/'build/merge-n001-scoped-delta.py'),'exec'))
