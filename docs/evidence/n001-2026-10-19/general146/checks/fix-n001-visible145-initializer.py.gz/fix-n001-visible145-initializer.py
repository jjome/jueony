from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parents[1];area=r/'build/n001-visible145-merged';proof=json.loads((area/'merge-proof.json').read_bytes());p=r/proof['patch'];assert hashlib.sha256(p.read_bytes()).hexdigest()==proof['patchSha256']=='7f14815bf6b100bd9e56f171b93a2b6ceee4ba7e0c6b0f7939a78e0366c204cd'
(area/'invalid-duplicate-initializer.patch').write_bytes(p.read_bytes());(area/'invalid-duplicate-initializer-proof.json').write_bytes((area/'merge-proof.json').read_bytes())
assert p.resolve().is_relative_to((r/'engine/patches').resolve());p.unlink()
f=area/'src/renderer/current_visible_host142.rs';s=f.read_text(encoding='utf8');needle='additional_frames:Vec::new(),additional_frames:Vec::new()';assert s.count(needle)==1;s=s.replace(needle,'additional_frames:Vec::new()');f.write_text(s,encoding='utf8',newline='\n')
print('Removed one duplicated constructor field; invalid patch and source proof preserved.')
