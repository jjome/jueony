from pathlib import Path
import re,json
r=Path(__file__).resolve().parents[1];stage=r/'build/n001-empty144-merged';p=stage/'src/renderer/current_frame_rows_plan.rs';s=p.read_text(encoding='utf8')
pattern=r'<<<<<<<[^\n]*\n(.*?)\|\|\|\|\|\|\|[^\n]*\n.*?=======\n(.*?)>>>>>>>[^\n]*\n'
s,n=re.subn(pattern,lambda m:m[1]+m[2],s,flags=re.S);assert n==1
old='rect,tables:Vec::new()};';assert s.count(old)==1;s=s.replace(old,'rect,tables:Vec::new(),additional_frames:Vec::new()};')
p.write_text(s,encoding='utf8',newline='\n')
(stage/'resolution.json').write_text(json.dumps({'conflict':'append both independent explicit-column and unequal-prefix modules','companion':'initialize new unequal prefix paint plan additional_frames empty; no coordinate or proof changes'},indent=2)+'\n',encoding='utf8')
