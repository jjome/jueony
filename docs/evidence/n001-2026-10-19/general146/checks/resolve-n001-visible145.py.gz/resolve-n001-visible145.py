from pathlib import Path
import re,json
r=Path(__file__).resolve().parents[1];stage=r/'build/n001-visible145-merged'
pattern=r'<<<<<<<[^\n]*\n(.*?)\|\|\|\|\|\|\|[^\n]*\n.*?=======\n(.*?)>>>>>>>[^\n]*\n'
for name in ['src/renderer/current_frame_rows_plan.rs','src/document_core/commands/document.rs','src/document_core/queries/rendering.rs']:
 p=stage/name;s=p.read_text(encoding='utf8')
 def resolve(m):
  current,incoming=m[1],m[2]
  if name.endswith('current_frame_rows_plan.rs'):return current+incoming
  if name.endswith('commands/document.rs'):
   head=incoming.removesuffix('        }else{return Ok(None);};\n')
   assert head!=incoming and current.startswith('        }else if let Some(candidate)={')
   return head+current
  assert '.or(explicit_column_paint).or_else' in current
  return current.replace('.or(explicit_column_paint).or_else','.or(explicit_column_paint).or(visible_host_paint).or_else')
 s,n=re.subn(pattern,resolve,s,flags=re.S);assert n==1,name;p.write_text(s,encoding='utf8',newline='\n')
p=stage/'src/renderer/current_visible_host142.rs';s=p.read_text(encoding='utf8');old='tables:Vec::new()';assert s.count(old)==1;s=s.replace(old,old+',additional_frames:Vec::new()');p.write_text(s,encoding='utf8',newline='\n')
(stage/'resolution.json').write_text(json.dumps({'modules':'retain unequal and explicit; append visible host','export':'visible-host branch before equal-stack; retain whole source admission and hard binding failure','paint':'retain suffix required/full-empty lanes; append visible-host receipt-only plan before equal stack','initializer':'new receipt-only plan additional_frames empty','coordinateChanges':False},indent=2)+'\n',encoding='utf8')
