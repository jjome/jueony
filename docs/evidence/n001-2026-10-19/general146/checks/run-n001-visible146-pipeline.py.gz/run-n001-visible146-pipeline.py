from pathlib import Path
import subprocess,concurrent.futures,json,time,shutil
r=Path(__file__).resolve().parents[1];pkg=r/'build/rhwp-engine/source-71d8247a5752c0cd/pkg';mirror=r/'build/n001-review132-clean'
deadline=time.monotonic()+1800
while not(r/'build/n001-empty144-verified-established-workflows/result.json').is_file():
 assert time.monotonic()<deadline;time.sleep(3)
while not(pkg/'jueony-engine-build.json').exists():
 assert time.monotonic()<deadline;time.sleep(3)
metadata=json.loads((pkg/'jueony-engine-build.json').read_bytes());expected={x['name']for x in metadata['patches']}
quarantine=r/'build/n001-visible146-mirror-later-patches';quarantine.mkdir(exist_ok=True)
for p in(mirror/'engine/patches').glob('*.patch'):
 if p.name in expected:continue
 assert p.resolve().is_relative_to((mirror/'engine/patches').resolve())and p.read_bytes()==(r/'engine/patches'/p.name).read_bytes()
 shutil.copy2(p,quarantine/p.name);assert(quarantine/p.name).read_bytes()==p.read_bytes();p.unlink()
for name in expected:shutil.copy2(r/'engine/patches'/name,mirror/'engine/patches'/name)
script=(r/'build/run-n001-visible146-checks.py').read_text(encoding='utf8').replace('n001-visible146','n001-visible146').replace("'4414'","'4432'")
(r/'build/run-n001-visible146-checks.py').write_text(script,encoding='utf8')
records=[]
def run(mode):
 t=time.monotonic();p=subprocess.run(['C:/Python314/python.exe','-X','utf8',str(r/'build/run-n001-visible146-checks.py'),mode,str(pkg)],cwd=r,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
 record={'mode':mode,'exit':p.returncode,'seconds':round(time.monotonic()-t,2)};print(json.dumps(record),flush=True);return record
records.append(run('build'));assert records[-1]['exit']==0
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:
 established=pool.submit(run,'established')
 jobs=[pool.submit(run,m)for m in ['public','corpus','live-audit','composition','unit','typecheck','boundaries','general-ui']]
 records.extend(job.result()for job in jobs);records.append(established.result())
(r/'build/n001-visible146-pipeline-result.json').write_text(json.dumps({'results':records},indent=2)+'\n',encoding='utf8')
