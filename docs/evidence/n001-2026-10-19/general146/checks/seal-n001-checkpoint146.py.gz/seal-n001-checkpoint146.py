from pathlib import Path
import json,hashlib,gzip,re,shutil
r=Path(__file__).resolve().parents[1];a=r/'build';out=r/'docs/evidence/n001-2026-10-19/general146';mirror=a/'n001-review132-clean';pkg=a/'rhwp-engine/source-71d8247a5752c0cd/pkg'
read=lambda p:json.loads(p.read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest()
engine=read(pkg/'jueony-engine-build.json');assert engine['sourceId']=='71d8247a5752c0cd'and len(engine['patches'])==140
w=read(a/'n001-visible146-established-workflows/result.json');assert w['passedCases']==w['totalCases']==501 and not w['failures']and len(w['suites'])==41
p=read(a/'n001-visible146-public/result.json');c=read(a/'n001-visible146-corpus/result.json');ui=read(a/'n001-visible146-general-ui/result.json');expanded=read(a/'n001-visible146-expanded/result.json')
assert len(p['results'])==56 and not p['failures'];assert len(c['results'])==88 and len(c['failures'])==5
assert len(ui['results'])==29 and sum(x['status']=='PASS'for x in ui['results'])==28 and len(ui['failures'])==1 and ui['fullMatrix'];assert not ui['pageErrors']and not ui['externalRequests']and not ui['consoleErrors']
assert len(expanded['results'])==24 and len(expanded['failures'])==12
unit=(a/'n001-visible146-unit.log').read_text(encoding='utf8');assert '# pass 1036'in unit and '# fail 0'in unit and '# skipped 0'in unit
assert not(a/'n001-visible146-typecheck.log').read_text().strip();assert read(a/'n001-visible146-boundaries.log')['diagnostics']==[]
native=(a/'n001-visible146-native.log').read_text(encoding='utf8');assert re.findall(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored',native)==['29','2','1']
whole=read(a/'n001-visible146-whole-body/result.json');assert whole['pass']==14 and whole['fail']==0
unequal=read(a/'n001-visible146-unequal/result.json');assert len(unequal['results'])==16 and not unequal['failures']and len(unequal['observations'])==64 and unequal['histories']==16 and unequal['passwordRefusals']==32
budget=read(a/'n001-visible146-budget/result.json');assert budget['status']=='PASS'and budget['pages']==128 and budget['sourceAndEventsUnchanged']
audit=read(a/'n001-visible146-live-audit/result.json');assert len(audit['observations'])==93 and not audit['failures']and sum(x['stableGeometryRequired']for x in audit['observations'])==37
extras=read(a/'n001-extra146/summary.json');assert len(extras['results'])==5 and not extras['failures']and all(x['status']=='PASS'for x in extras['results'])
bundle=read(a/'n001-visible146-bundle-check/result.json');assert bundle['passed']==7 and bundle['failed']==0 and bundle['build']['engineWasmSha256']==engine['wasmSha256']
negative=read(a/'n001-visible146-negative/result.json');assert negative['positive']and len(negative['cases'])==28
assert negative['runtimeResource']=='07a1ca092a83158621ddd7053723b0ab8dfbfb1ee6074b0ff8e26d1791ea2516'
for d in [w.get('engine'),p.get('engine'),c.get('engine'),expanded.get('engine'),unequal.get('engine'),whole.get('metadata'),budget.get('metadata')]:assert d['sourceId']==engine['sourceId']
preserved=[]
for name,expected in read(a/'n001-general125-unrelated-initial.json').items():
 if name=='README.md':continue
 assert sha((r/name).read_bytes())==expected,name;preserved.append({'path':name,'sha256':expected})
assert len(preserved)==45;assert not out.exists();out.mkdir(parents=True)
def copy(src,target,compress=True):
 src=Path(src);b=src.read_bytes();dest=out/(target+'.gz'if compress else target);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(b,mtime=0)if compress else b)
copy(pkg/'jueony-engine-build.json','source/engine-build.json',False)
copy(a/'n001-visible146-established-workflows/result.json','workflows/result.json',False)
for suite in w['suites']:
 name=suite['name'];script=mirror/'apps/editor/scripts'/('verify-'+name+'.mjs');assert sha(script.read_bytes())==suite['verifierSHA256']
 copy(a/'n001-visible146-established-workflows'/name/'result.json','workflows/'+name+'/result.json');copy(a/'n001-visible146-established-workflows/logs'/(name+'.log'),'workflows/logs/'+name+'.log');copy(script,'verifiers/'+script.name)
for mode in ['public','corpus','general-ui','expanded','whole-body','unequal','budget','composition','live-audit']:
 copy(a/('n001-visible146-'+mode)/'result.json','general/'+mode+'/result.json');log=a/('n001-visible146-'+mode+'.log')
 if log.is_file():copy(log,'checks/'+mode+'.log')
for mode in ['build','unit','typecheck','boundaries','official-build','native','bundle-build','bundle-check','established']:
 copy(a/('n001-visible146-'+mode+'.log'),'checks/'+mode+'.log')
for name in ['verify-unequal-storage144.mjs','verify-visible-host-storage146.mjs','verify-whole-body-composition142.mjs','verify-current-suffix-budget142.mjs']:copy(r/'apps/editor/scripts'/name,'verifiers/'+name)
for e in engine['patches'][138:]:
 src=r/'engine/patches'/e['name'];assert sha(src.read_bytes())==e['sha256'];copy(src,'patches/'+e['name'])
for folder in ['n001-empty144-merged','n001-visible145-merged']:
 for name in ['merge-proof.json','initial-merge-proof.json','resolution.json','invalid-duplicate-initializer-proof.json']:
  if(a/folder/name).is_file():copy(a/folder/name,'source/'+folder+'/'+name)
for folder in ['n001-empty143/handoff-r4','n001-visible-host142/handoff-final']:
 for f in(a/folder).rglob('*'):
  if f.is_file():copy(f,'native/'+folder+'/'+f.relative_to(a/folder).as_posix())
for folder in ['n001-visible146-negative']:
 for name in ['preparation.json','result.json','run.sh']:
  copy(a/folder/name,'native/'+folder+'/'+name)
copy(a/'n001-visible146-negative.log','native/negative146.log');copy(a/'n001-visible146-native/preparation.json','source/native-identical-source.json')
copy(a/'n001-general132-clean-source-proof.json','source/application-archive.json');copy(mirror/'apps/editor/evidence/dist-n001-visible146/build-evidence.json','source/application-build.json')
copy(a/'n001-extra146/summary.json','extras/summary.json',False)
for e in extras['results']:
 copy(a/'n001-extra146'/e['name']/'result.json','extras/'+e['name']+'/result.json');copy(a/'n001-extra146'/(e['name']+'.log'),'extras/'+e['name']+'/run.log')
copy(a/'n001-visible146-bundle-check/result.json','bundle/result.json',False)
# Preserve the failed sandbox invocation and duplicate-field compile attempt as failures.
for name in ['n001-empty144-established.log','n001-empty144-general-ui.log','n001-visible145-official-build.log','n001-visible145-native.log','n001-visible145-fixed-prepare.log']:
 if(a/name).is_file():copy(a/name,'before/'+name)
for name in ['xml-documents-integrated','native-row-preservation']:
 copy(a/'n001-empty144-established-workflows/logs'/(name+'.log'),'before/sandbox/'+name+'.log')
copy(a/'n001-empty144-verified-established-workflows/result.json','before/verified144-workflows.json')
for name in ['seal-n001-checkpoint146.py','run-n001-visible146-checks.py','run-n001-visible146-pipeline.py','run-n001-visible146-additional.py','prepare-n001-visible146-native.py','n001-visible146-native.sh','merge-n001-scoped-delta.py','finish-n001-scoped-merge.py','resolve-n001-empty144.py','resolve-n001-visible145.py','fix-n001-visible145-initializer.py']:copy(a/name,'checks/'+name)
summary={'engine':engine,'workflowCases':501,'workflowSuites':41,'unitTests':1036,'unitSkipped':0,'nativeTests':32,'resourceInputs':266,'public':{'passed':56,'total':56,'failed':0},'corpus':{'passed':83,'total':88,'failed':5},'app':{'passed':28,'total':29,'failed':1,'browserExceptions':0,'externalRequests':0,'consoleErrors':0},'expandedVisibleHost':{'passed':12,'total':24,'failed':12,'remaining':'Native→XML6 and XML→Native6; retained as failures'},'wholeBody':{'passed':14,'total':14,'bothFormatDiskReopens':28},'unequalLifecycle':{'passed':16,'total':16,'diskReopens':64,'historyPairs':16,'wrongPasswordRefusals':32},'actualBudget':{'pages':128,'explicitRefusal':True,'sourceEventsUnchanged':True,'largeDocumentSupport':False},'independentReaders':{'observations':93,'requiredStable':37,'requiredStableDifferences':0},'bundleChecks':7,'extras':extras['results'],'unrelated45Unchanged':preserved,'remainingCorpus':c['failures'],'remainingApp':ui['failures'],'remainingExpanded':expanded['failures'],'complete':False,'parentEvidence':'../general143/SHA256-MANIFEST.json','scope':'N001 only; Rust runtime, Hancom deferred; no providers, credentials, user documents or user windows'}
(out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(out/'README.md').write_text('''# N001 checkpoint146: unequal empty lines and visible XML table hosts

Exact official Rust source71d8247a5752c0cd,140 patches,266 resource inputs.
Existing41-suite501 cases,1036 unit tests,32 Native tests, separate75 checks
and7 packaged checks pass. Same inputs: public56/56, fixed83/88, full headless
app28/29. Expanded visible-host24 cases retain12 mixed-format failures. This
is not N001 completion. Hancom comparison is deferred.

Current empty lines bind real accepted FullParagraph/fresh/physical owners;
original width guard and export authority are unchanged. Initial r3 offset
regressions were fixed before integration. The new XML visible-host proof
binds actual selected composition, table flow and physical frame, never old
row authority. The same/mixed-format failures remain in their original reports.

Unequal lifecycle16 cases include64 real disk reopens,16 undo/redo pairs and32
wrong-password refusals; source/events and complete production0.2 geometry
guards stay unchanged. All-body14 cases include28 disk reopens. Actual128-page
budget test is an explicit refusal with unchanged source/events, not support.
The sandbox process-launch failures and duplicate-field merge compile failure
are preserved and are not counted as passes. Successful reruns are separate.

No GUI/Hancom, user files/windows, credentials or model calls.45 unrelated
working files stayed exact. Original44 fixed inputs were never regenerated.
Parent143 evidence remains immutable. Run python verify.py for hashes.
''',encoding='utf8')
shutil.copy2(r/'docs/evidence/n001-2026-10-19/general143/verify.py',out/'verify.py')
files=[{'path':f.relative_to(out).as_posix(),'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())}for f in sorted(out.rglob('*'))if f.is_file()]
(out/'SHA256-MANIFEST.json').write_text(json.dumps({'files':files},indent=2)+'\n',encoding='utf8');print('sealed',len(files),'files')
