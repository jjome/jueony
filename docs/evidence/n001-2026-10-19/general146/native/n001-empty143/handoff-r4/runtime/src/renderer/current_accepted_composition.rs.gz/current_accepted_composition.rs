//! Consume the exact plain-body composition accepted by the current allocator.
//! No source/cache rows are reconstructed and no lease/export authority is issued.
use std::sync::Arc;
use crate::model::{paragraph::Paragraph,provenance::LayoutCompatibilityProfile,control::Control};
use super::{composer::ComposedParagraph,pagination::PaginationResult,selected_composition_observer127::FinalizedSelectedCompositionTrace,
 style_resolver::ResolvedStyleSet};
#[derive(Debug,Clone)]
pub(crate) struct CurrentAcceptedCompositionView {trace:Option<Arc<FinalizedSelectedCompositionTrace>>,
 required:Option<Arc<FinalizedSelectedCompositionTrace>>,required_tokens:Vec<usize>,full_empty_tokens:Vec<usize>,empty_frames:Vec<(u32,u16,super::page_layout::LayoutRect)>}
pub(crate) struct AcceptedPlainPaint {pub composition:Arc<ComposedParagraph>,pub line_box_width:f64}
impl CurrentAcceptedCompositionView {
 pub(crate) fn from_current(result:&PaginationResult,paras:&[Paragraph],styles:&ResolvedStyleSet,profile:LayoutCompatibilityProfile,dpi:f64)->Option<Self>{
  if dpi!=super::DEFAULT_DPI||styles.supplemental_metrics.is_some()||styles.kerning_measurement_context.is_some()||styles.horizontal_shaping_context.is_some(){return None;}
  let trace=result.selected_composition_trace.as_ref()?;
  if !trace.matches_source(paras,styles.reset_flow_context,profile,dpi)||!trace.matches_finalized_result(result){return None;}
  Some(Self{trace:Some(Arc::clone(trace)),required:None,required_tokens:vec![],full_empty_tokens:vec![],empty_frames:vec![]})
 }
 /// Attach the allocator's required formatter objects without publishing them
 /// as the optional full fact trace or an export/standard-row permission.
 pub(crate) fn attach_required(current:Option<Self>,result:&PaginationResult,paras:&[Paragraph],styles:&ResolvedStyleSet,
 profile:LayoutCompatibilityProfile,dpi:f64)->Result<Option<Self>,&'static str>{
  let Some(required)=result.required_plain_paint.as_ref()else{return Ok(current);};
  // Other paragraphs may also rely on the original complete formatter set.
  // A remapped paragraph is not permission to publish their legacy fallback
  // after a report budget or unsupported path removed that complete set.
  if current.is_none(){return Err("complete current formatter set unavailable or exceeds supported budgets");}
  let trace=required.paint_trace().ok_or("current suffix allocation has no valid source/frame binding")?;
  if dpi!=super::DEFAULT_DPI||styles.supplemental_metrics.is_some()||styles.kerning_measurement_context.is_some()||styles.horizontal_shaping_context.is_some()
   ||!trace.matches_paint_source(paras,styles.reset_flow_context,profile,dpi)||!trace.matches_finalized_result(result)
   ||required.paragraph_bindings().iter().any(|(i,token)|paras.get(*i).map(|p|p as *const Paragraph as usize)!=Some(*token)){
   return Err("current suffix formatter belongs to a different source or allocation");
  }
  let mut view=current.unwrap_or(Self{trace:None,required:None,required_tokens:vec![],full_empty_tokens:vec![],empty_frames:vec![]});
  view.full_empty_tokens=required.full_empty_tokens().to_vec();
  for p in &result.pages{for c in &p.column_contents{if !c.endnote_flow&&c.zone_layout.is_none()&&c.zone_y_offset==0.0{if let Some(rect)=p.layout.column_areas.get(usize::from(c.column_index)){view.empty_frames.push((p.page_index,c.column_index,*rect));}}}}
  view.required=Some(Arc::clone(trace));view.required_tokens=required.paragraph_bindings().iter().map(|(_,token)|*token).collect();Ok(Some(view))
 }
 pub(crate) fn requires_para(&self,para:&Paragraph)->bool{self.required_tokens.contains(&(para as *const Paragraph as usize))&&!self.requires_full_empty(para)}
 pub(crate) fn requires_full_empty(&self,para:&Paragraph)->bool{self.full_empty_tokens.contains(&(para as *const Paragraph as usize))}
 pub(crate) fn full_empty_paint(&self,para:&Paragraph,index:usize,section:usize,page:u32,column:u16,rect:&super::page_layout::LayoutRect,
 y:f64,styles:&ResolvedStyleSet,dpi:f64)->Option<AcceptedPlainPaint>{
  if !self.requires_full_empty(para)||!y.is_finite()||y<rect.y{return None;}
  let trace=self.required.as_ref()?;if section!=trace.section(){return None;}
  let mut frames=self.empty_frames.iter().filter(|(p,c,r)|*p==page&&*c==column&&r.x==rect.x&&r.y==rect.y&&r.width==rect.width&&r.height==rect.height);
  frames.next()?;if frames.next().is_some(){return None;}
  let token=para as *const Paragraph as usize;let mut commits=trace.commits().iter().filter(|c|c.paragraph==index);
  let c=commits.next()?;if commits.next().is_some()||c.section!=section||c.page!=Some(page)||c.column!=column||c.row_start!=0||c.row_end!=1
   ||c.final_membership!=Some(true)||!c.paragraph_token_matches||!c.metrics_still_match_selected_format||!c.range_inside_selected_composition
   ||c.actual_column_width_px!=rect.width||c.trimmed_before!=0.0{return None;}
  let f=trace.format(c.format_id)?;let composition=trace.selected_composition(c.format_id)?;
  if f.paragraph_token!=token||!f.selected_recomposition||f.source_text!=para.text||f.source_char_offsets!=para.char_offsets
   ||f.actual_input_width_px.is_none()||f.before!=0.0||f.after!=0.0||f.known_square_band||f.has_numbering||f.has_horizontal_shaping
   ||!f.inline_controls.is_empty()||!f.tac_controls.is_empty()||!f.footnote_positions.is_empty()||!f.tab_extended.is_empty(){return None;}
  // Empty lines consume no scalar/text advance. Keep the actual formatter
  // input width distinct from the later physical column. Both independently
  // fresh boxes must have exactly the same height/baseline/spacing; neither
  // source rows nor the first width become a physical-frame permission.
  let fresh=super::current_empty_body143::fresh_current_empty(para,styles,f.actual_input_width_px?,dpi)?;
  let physical=super::current_empty_body143::fresh_current_empty(para,styles,rect.width,dpi)?;
  let [physical_line]=physical.lines.as_slice()else{return None;};
  let [a]=fresh.lines.as_slice()else{return None;};let [b]=composition.lines.as_slice()else{return None;};let [r]=f.lines.as_slice()else{return None;};
  if physical_line.line_height!=a.line_height||physical_line.baseline_distance!=a.baseline_distance||physical_line.line_spacing!=a.line_spacing
   ||!physical_line.runs.is_empty()||physical_line.char_start!=0||physical_line.has_line_break
   ||fresh.para_style_id!=composition.para_style_id||a.char_start!=0||b.char_start!=0||!a.runs.is_empty()||!b.runs.is_empty()
   ||a.line_height!=b.line_height||a.baseline_distance!=b.baseline_distance||a.segment_width!=b.segment_width||a.column_start!=b.column_start
   ||a.line_spacing!=b.line_spacing||a.has_line_break||b.has_line_break||r.scalar_start!=0||r.scalar_end!=Some(0)||r.unicode_utf16_start!=Some(0)
   ||r.unicode_utf16_end!=Some(0)||!r.exact_source_text_span||!r.runs.is_empty()||r.width_hu!=a.segment_width||r.height_hu!=a.line_height
   ||r.baseline_hu!=a.baseline_distance||r.spacing_hu!=a.line_spacing||r.column_start_hu!=0||r.has_line_break{return None;}
  let height=super::hwpunit_to_px(a.line_height,dpi);let spacing=super::hwpunit_to_px(a.line_spacing,dpi);let advance=height+spacing;
  let close=|a:f64,b:f64|a.is_finite()&&b.is_finite()&&(a-b).abs()<=f64::EPSILON*a.abs().max(b.abs()).max(1.0)*16.0;
  if f.actual_heights!=[height]||f.actual_spacings!=[spacing]||!close(f.total,advance)||!close(c.advance,advance)||!close(c.flow_after,c.flow_before+advance)
   ||y+advance>rect.y+rect.height{return None;}
  Some(AcceptedPlainPaint{composition,line_box_width:rect.width})
 }
 pub(crate) fn plain_paint(&self,para:&Paragraph,section:usize,page:u32,column:u16,start:usize,end:usize,physical_width:f64,styles:&ResolvedStyleSet,dpi:f64)->Option<AcceptedPlainPaint>{
  let trace=if self.requires_para(para){self.required.as_ref()?}else{self.trace.as_ref()?};
  if section!=trace.section()||!physical_width.is_finite()||physical_width<=0.0||dpi!=super::DEFAULT_DPI
   ||!para.field_ranges.is_empty()||!para.range_tags.is_empty()||!para.orphan_field_ends.is_empty()||!para.tab_extended.is_empty()
   ||para.numbering_restart.is_some()||!para.title_marks.is_empty()||!para.markpen_marks.is_empty()
   ||para.text.contains(['\t','\n','\r','\u{fffc}'])||para.controls.iter().any(|c|!matches!(c,Control::SectionDef(_)|Control::ColumnDef(_))){return None;}
  // Source char_offsets are HWP UTF16 units, while ComposedLine.char_start and
  // published charStart are Unicode scalar indices. Structural controls occupy
  // their own 16-unit prefix and must never be counted as source characters.
  let mut source_offset=match para.controls.as_slice(){[]=>0u32,[Control::SectionDef(_),Control::ColumnDef(_)]=>16u32,_=>return None};
  if para.char_offsets.len()!=para.text.chars().count(){return None;}
  for (ch,at) in para.text.chars().zip(&para.char_offsets){if *at!=source_offset{return None;}source_offset=source_offset.checked_add(ch.len_utf16() as u32)?;}
  if para.char_count!=source_offset.checked_add(1)?{return None;}
  let token=para as *const Paragraph as usize;
  let mut candidates=trace.commits().iter().filter(|c|c.section==section&&c.page==Some(page)&&c.column==column&&c.row_start==start&&c.row_end==end&&c.paragraph_token_matches);
  let commit=candidates.find(|c|trace.format(c.format_id).is_some_and(|f|f.paragraph_token==token))?;
  if candidates.any(|c|trace.format(c.format_id).is_some_and(|f|f.paragraph_token==token)){return None;}
  let format=trace.format(commit.format_id)?;
  if format.source_text!=para.text||format.source_char_offsets!=para.char_offsets{return None;}
  if format.has_numbering||format.has_horizontal_shaping||format.known_square_band
   ||format.before!=0.0||format.after!=0.0||format.lines.is_empty()||format.lines.len()>4096
   ||start>=end||end>format.lines.len(){return None;}
  let style=styles.para_styles.get(usize::from(para.para_shape_id))?;
  if style.margin_left!=0.0||style.margin_right!=0.0||style.indent!=0.0||style.spacing_before!=0.0||style.spacing_after!=0.0
   ||!matches!(style.head_type,crate::model::style::HeadType::None){return None;}
  let input_width=format.actual_input_width_px?;if !input_width.is_finite()||input_width<=0.0{return None;}
  // Both global-current reuse and local recomposition are actual formatter
  // selections. This does not relabel either selection as freshly recomposed.
  // This corrects only actual reuse across different physical column widths.
  // A narrow row remains the exact accepted row in a wider frame. It is NOT a
  // claim that this composition was recomputed at that later physical width.
  let commits=trace.commits().iter().filter(|c|c.paragraph==commit.paragraph).collect::<Vec<_>>();
  if commits.len()<2||!commits.iter().any(|c|c.actual_column_width_px!=input_width){return None;}
  // Each committed fragment keeps its own actual formatter identity. A later
  // narrower-frame formatter can use a different row index, but must begin at
  // exactly the next full-paragraph scalar/UTF16 boundary. Old commits are not
  // rewritten and unused prefix rows of a new full composition are not painted.
  let mut next_scalar=0usize;let mut next_utf16=0u32;
  let mut validated=std::collections::BTreeSet::new();
  for c in &commits{
   let f=trace.format(c.format_id)?;
   if f.paragraph_token!=token||c.section!=section||!c.paragraph_token_matches||c.final_membership!=Some(true)
    ||!c.metrics_still_match_selected_format||!c.range_inside_selected_composition||c.row_start>=c.row_end||c.row_end>f.lines.len()
    ||!c.actual_column_width_px.is_finite()||c.actual_column_width_px<=0.0{return None;}
   if validated.insert(c.format_id)&&!exact_plain_format(para,f,dpi){return None;}
   let first=&f.lines[c.row_start];let last=&f.lines[c.row_end-1];
   if first.scalar_start!=next_scalar||first.unicode_utf16_start!=Some(next_utf16){return None;}
   next_scalar=last.scalar_end?;next_utf16=last.unicode_utf16_end?;
   let width=f.actual_input_width_px?.min(c.actual_column_width_px);
   let bound=super::px_to_hwpunit(width,dpi);
   if bound<=0||f.lines[c.row_start..c.row_end].iter().any(|l|l.width_hu<=0||l.width_hu>bound){return None;}
  }
  if next_scalar!=para.text.chars().count()||next_utf16!=para.text.encode_utf16().count() as u32{return None;}
  let line_box_width=input_width.min(physical_width);let bound=super::px_to_hwpunit(line_box_width,dpi);
  if bound<=0||format.lines[start..end].iter().any(|l|l.width_hu<=0||l.width_hu>bound){return None;}
  let composition=trace.selected_composition(commit.format_id)?;
  Some(AcceptedPlainPaint{composition,line_box_width})
 }
}

/// Validate every actual selected composition in full, including unused prefix
/// rows. Scalar positions and Unicode UTF16 offsets are independent of row IDs.
fn exact_plain_format(para:&Paragraph,f:&super::selected_composition_observer127::SelectedFormatFact,dpi:f64)->bool{
 (||->Option<()>{
  if f.source_text!=para.text||f.source_char_offsets!=para.char_offsets||f.dpi!=dpi||f.has_numbering||f.has_horizontal_shaping||f.known_square_band
   ||f.before!=0.0||f.after!=0.0||f.lines.is_empty()||f.lines.len()>4096
   ||f.actual_heights.len()!=f.lines.len()||f.actual_spacings.len()!=f.lines.len(){return None;}
  let width=f.actual_input_width_px?;if !width.is_finite()||width<=0.0{return None;}
  let mut scalar=0usize;let mut utf16=0u32;
  for (i,l) in f.lines.iter().enumerate(){
   if l.scalar_start!=scalar||l.unicode_utf16_start!=Some(utf16)||!l.exact_source_text_span||l.has_line_break||l.height_hu<=0||l.spacing_hu<0
    ||l.baseline_hu<0||l.baseline_hu>l.height_hu||l.column_start_hu!=0
    ||f.actual_heights[i]!=super::hwpunit_to_px(l.height_hu,dpi)||f.actual_spacings[i]!=super::hwpunit_to_px(l.spacing_hu,dpi)
    ||l.original_hwp_char_offset!=para.char_offsets.get(scalar).copied(){return None;}
   for r in &l.runs{utf16=utf16.checked_add(u32::try_from(r.utf16_units).ok()?)?;}
   if l.unicode_utf16_end!=Some(utf16){return None;}let end=l.scalar_end?;if end<=scalar{return None;}scalar=end;
  }
  (scalar==para.text.chars().count()).then_some(())
 })().is_some()
}
