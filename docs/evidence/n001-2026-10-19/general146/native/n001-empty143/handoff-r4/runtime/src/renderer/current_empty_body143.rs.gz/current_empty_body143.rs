//! Current plain empty-line selection. No input/source rows are mutated.
//! A stale synthetic width is not permission to drop a real allocated line.
use crate::model::paragraph::{Paragraph,LineSeg};
use super::{composer::{ComposedParagraph,ParagraphBox,reflow_line_segs,compose_paragraph_in_context},style_resolver::ResolvedStyleSet};
/// This selector has no physical authority for independently positioned floats.
/// Admit only an actual ordinary 2/3-column body with structural first controls,
/// plain paragraphs and non-captioned inline tables whose child stories are plain.
/// Other section controls/notes/float tables keep the pre-existing formatter.
pub(crate) fn plain_inline_section(ps:&[Paragraph])->bool{
 use crate::model::control::Control;
 if ps.is_empty()||ps.len()>4096{return false;}
 let [Control::SectionDef(section),Control::ColumnDef(columns)]=ps[0].controls.as_slice()else{return false;};
 if !matches!(columns.column_count,2|3)||columns.column_type!=crate::model::page::ColumnType::Normal
  ||columns.direction!=crate::model::page::ColumnDirection::LeftToRight||!section.master_pages.is_empty()||!section.extra_child_records.is_empty(){return false;}
 ps.iter().skip(1).all(|p|p.controls.is_empty()||matches!(p.controls.as_slice(),[Control::Table(t)]
  if t.common.treat_as_char&&t.caption.is_none()&&t.cells.len()<=4096&&t.cells.iter().all(|c|c.paragraphs.len()<=4096&&c.paragraphs.iter().all(|p|p.controls.is_empty()
   &&p.field_ranges.is_empty()&&p.orphan_field_ends.is_empty()&&p.range_tags.is_empty()&&p.tab_extended.is_empty()))))
}
pub(crate) fn fresh_current_empty(p:&Paragraph,styles:&ResolvedStyleSet,width:f64,dpi:f64)->Option<ComposedParagraph>{
 if dpi!=super::DEFAULT_DPI||!width.is_finite()||width<=0.0||!p.text.is_empty()||p.char_count!=1||!p.char_offsets.is_empty()
 ||!p.controls.is_empty()||p.char_shapes.len()!=1||p.char_shapes[0].start_pos!=0||!p.field_ranges.is_empty()||!p.range_tags.is_empty()
 ||!p.orphan_field_ends.is_empty()||!p.tab_extended.is_empty()||p.numbering_restart.is_some()||!p.title_marks.is_empty()||!p.markpen_marks.is_empty()
 ||p.layout_only_fill_lines!=0||p.cell_format_vpos_dirty||p.ctrl_data_records.iter().any(Option::is_some)
 ||p.column_type!=crate::model::paragraph::ColumnBreakType::None
 ||styles.supplemental_metrics.is_some()||styles.kerning_measurement_context.is_some()||styles.horizontal_shaping_context.is_some(){return None;}
 let [old]=p.line_segs.as_slice()else{return None;};
 if old.tag!=(LineSeg::TAG_SINGLE_SEGMENT_LINE|LineSeg::TAG_IMPLEMENTATION_PROPERTY)||old.text_start!=0||old.column_start!=0
 ||old.vertical_pos<0||old.vertical_pos.checked_add(old.line_height).and_then(|v|v.checked_add(old.line_spacing)).is_none()
 ||p.hwpx_axis_shift!=0||p.source_line_seg_vertical_pos.is_some()
 ||old.segment_width<=0||old.line_height<=0||old.text_height!=old.line_height||old.line_spacing<0
 ||old.baseline_distance<0||old.baseline_distance>old.line_height{return None;}
 let st=styles.para_styles.get(usize::from(p.para_shape_id))?;
 if st.margin_left!=0.0||st.margin_right!=0.0||st.indent!=0.0||st.spacing_before!=0.0||st.spacing_after!=0.0
 ||st.keep_lines||st.keep_with_next||st.page_break_before||!matches!(st.head_type,crate::model::style::HeadType::None)
 ||st.border_connect||st.border_spacing.iter().any(|v|*v!=0.0)||!st.line_spacing.is_finite()||st.line_spacing<0.0{return None;}
 if st.border_fill_id!=0{let border=styles.border_styles.get(usize::from(st.border_fill_id.checked_sub(1)?))?;
  if border.borders.iter().any(|b|!matches!(b.line_type,crate::model::style::BorderLineType::None))||border.fill_color.is_some()
  ||border.pattern.is_some()||border.gradient.is_some()||border.image_fill.is_some()||border.diagonal_attr!=0
  ||!matches!(border.center_line,crate::model::style::CenterLine::None){return None;}}
 let cs=styles.char_styles.get(p.char_shapes[0].char_shape_id as usize)?;let hu=cs.font_size*7200.0/dpi;
 let upper=hu*(2.0+st.line_spacing.abs())+st.line_spacing.abs()*7200.0/dpi;
 if !hu.is_finite()||hu<=0.0||!upper.is_finite()||upper>f64::from(i32::MAX)/4.0{return None;}
 let mut q=p.clone();q.line_segs.clear();q.layout_space_metrics.clear();q.source_line_seg_vertical_pos=None;q.hwpx_axis_shift=0;
 q.native_source_synthetic_seal=None;q.native_source_synthetic_context=None;q.completed_native_rows=None;q.native_frame_observation.set(None);
 reflow_line_segs(&mut q,ParagraphBox::body_for_style(width,Some(st),dpi),styles,dpi);
 let [row]=q.line_segs.as_slice()else{return None;};
 if row.segment_width.abs_diff(old.segment_width)<=200||row.vertical_pos!=0||row.text_start!=0||row.column_start!=0||row.segment_width<=0
 ||row.tag!=old.tag||row.line_height!=old.line_height||row.text_height!=old.text_height
 ||row.baseline_distance!=old.baseline_distance||row.line_spacing!=old.line_spacing{return None;}
 let c=compose_paragraph_in_context(&q,styles);let [l]=c.lines.as_slice()else{return None;};
 if !l.runs.is_empty()||l.char_start!=0||l.has_line_break||c.numbering_text.is_some()||!c.inline_controls.is_empty()
 ||!c.tac_controls.is_empty()||!c.footnote_positions.is_empty()||!c.tab_extended.is_empty()||c.horizontal_shaping.is_some(){return None;}
 Some(c)
}
