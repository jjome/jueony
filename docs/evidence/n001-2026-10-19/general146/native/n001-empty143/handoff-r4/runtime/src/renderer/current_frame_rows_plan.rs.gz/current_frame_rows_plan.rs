//! Private general current-frame export plan. Construction is owned by this
//! module's current fresh-composition/allocation/physical-frame proof, never by
//! a file descriptor, external JSON, old row lease, or arbitrary caller rows.
//! The producer is limited to exact current single-column whole body/table frames.
use crate::model::{document::Document,paragraph::LineSeg};
pub(crate) struct CurrentFrameRowsPlan<'doc>{
 source:&'doc Document,
 resource:[u8;32],
 allocation_generation:[u8;32],
 paragraphs:Vec<CurrentFrameParagraphRows>,
}
#[derive(Clone,Copy,Debug,PartialEq,Eq)]pub(crate) enum CurrentFrameRowKind{FreshBody,StructuralObjectAnchor}
pub(crate) struct CurrentFrameParagraphRows{
 kind:CurrentFrameRowKind,
 section:usize,
 paragraph:usize,
 rows:Vec<LineSeg>,
}
impl CurrentFrameRowsPlan<'_>{
 pub(crate) fn owns_document(&self,source:&Document)->bool{std::ptr::eq(self.source,source)}
 pub(crate) fn resource(&self)->[u8;32]{self.resource}
 pub(crate) fn allocation_generation(&self)->[u8;32]{self.allocation_generation}
 pub(crate) fn paragraph_rows(&self)->&[CurrentFrameParagraphRows]{&self.paragraphs}
}
impl CurrentFrameParagraphRows{
 pub(crate) fn row_kind(&self)->CurrentFrameRowKind{self.kind}
 pub(crate) fn section_index(&self)->usize{self.section}
 pub(crate) fn paragraph_index(&self)->usize{self.paragraph}
 pub(crate) fn rows(&self)->&[LineSeg]{&self.rows}
}


/// Generic fresh standard rows for one actual body frame. This helper is not a
/// plan constructor: accepted allocator and complete physical closure remain
/// mandatory at the caller. It never reads a source row as output geometry.
struct FreshBodyRows { rows:Vec<LineSeg>, composition:super::composer::ComposedParagraph }
fn fresh_body_rows(p:&crate::model::paragraph::Paragraph,styles:&super::style_resolver::ResolvedStyleSet,
 width:f64,dpi:f64)->Option<FreshBodyRows>{
 use crate::model::control::Control;
 use super::composer::{compose_paragraph_in_context,reflow_line_segs,ParagraphBox};
 if p.text.len()>64*1024 || p.char_shapes.is_empty() || p.char_shapes.len()>128
  || p.char_shapes.windows(2).any(|s|s[0].start_pos>=s[1].start_pos)
  || p.char_shapes.iter().any(|s|s.char_shape_id as usize>=styles.char_styles.len()) || p.char_offsets.len()>64*1024
  || p.text.contains(['\t','\n','\r','\u{fffc}']) || !width.is_finite() || width<=0.0
  || dpi!=super::DEFAULT_DPI || !p.field_ranges.is_empty() || !p.range_tags.is_empty()
  || !p.orphan_field_ends.is_empty() || !p.tab_extended.is_empty() || p.numbering_restart.is_some()
  || p.layout_only_fill_lines!=0 || p.cell_format_vpos_dirty
  || !p.markpen_marks.is_empty() || !p.title_marks.is_empty()
  || p.controls.iter().any(|c|!matches!(c,Control::SectionDef(_)|Control::ColumnDef(_)))
  || p.ctrl_data_records.iter().any(Option::is_some) {return None;}
 let start=match p.controls.as_slice(){[]=>0u32,[Control::SectionDef(_),Control::ColumnDef(_)]=>16u32,_=>return None};
 let mut offset=start;
 if p.char_offsets.len()!=p.text.chars().count(){return None;}
 for (ch,at) in p.text.chars().zip(&p.char_offsets){if *at!=offset{return None;}offset=offset.checked_add(ch.len_utf16() as u32)?;}
 if p.char_count!=offset.checked_add(1)? {return None;}
 let style=styles.para_styles.get(usize::from(p.para_shape_id))?;
 if style.margin_left!=0.0 || style.margin_right!=0.0 || style.indent!=0.0 || style.spacing_before!=0.0
  || style.spacing_after!=0.0 || style.keep_lines || style.keep_with_next || style.page_break_before
  || !matches!(style.head_type,crate::model::style::HeadType::None)
  || style.border_connect || style.border_spacing.iter().any(|v|*v!=0.0) {return None;}
 if style.border_fill_id!=0 {let border=styles.border_styles.get(usize::from(style.border_fill_id.checked_sub(1)?))?;
  if border.borders.iter().any(|b|!matches!(b.line_type,crate::model::style::BorderLineType::None))
   || border.fill_color.is_some() || border.pattern.is_some() || border.gradient.is_some() || border.image_fill.is_some()
   || border.diagonal_attr!=0 || !matches!(border.center_line,crate::model::style::CenterLine::None){return None;}}
 if styles.supplemental_metrics.is_some() || styles.kerning_measurement_context.is_some()
  || styles.horizontal_shaping_context.is_some(){return None;}
 // Prove the existing generic breaker's i32 metric arithmetic cannot overflow
 // before invoking it; this is not a layout tolerance or a font substitution.
 if !style.line_spacing.is_finite()||style.line_spacing<0.0{return None;}
 for shape in &p.char_shapes {let cs=styles.char_styles.get(shape.char_shape_id as usize)?;
  let hu=cs.font_size*7200.0/dpi;
  let upper=hu*(2.0+style.line_spacing.abs())+style.line_spacing.abs()*7200.0/dpi;
  if !hu.is_finite()||hu<=0.0||!upper.is_finite()||upper>f64::from(i32::MAX)/8.0{return None;}}
 let mut fresh=p.clone();fresh.line_segs.clear();fresh.layout_space_metrics.clear();
 fresh.source_line_seg_vertical_pos=None;fresh.hwpx_axis_shift=0;
 fresh.native_source_synthetic_seal=None;fresh.native_source_synthetic_context=None;
 fresh.completed_native_rows=None;fresh.native_frame_observation.set(None);
 let frame=ParagraphBox::content_for_style(width,Some(style),dpi);
 reflow_line_segs(&mut fresh,frame,styles,dpi);
 if fresh.line_segs.is_empty() || fresh.line_segs.len()>4096{return None;}
 let mut end=0i32;
 for row in &fresh.line_segs {if row.vertical_pos!=end || row.line_height<=0 || row.text_height!=row.line_height
  || row.line_spacing<0 || row.baseline_distance<0 || row.baseline_distance>row.line_height
  || row.column_start!=0 || row.tag!=(LineSeg::TAG_SINGLE_SEGMENT_LINE|LineSeg::TAG_IMPLEMENTATION_PROPERTY) {return None;}
  end=end.checked_add(row.line_height)?.checked_add(row.line_spacing)?;}
 let composition=compose_paragraph_in_context(&fresh,styles);
 if composition.numbering_text.is_some() || !composition.tac_controls.is_empty() || !composition.footnote_positions.is_empty()
  || !composition.tab_extended.is_empty() || composition.horizontal_shaping.is_some(){return None;}
 Some(FreshBodyRows{rows:fresh.line_segs,composition})
}

/// An already exact ordinary standard cache keeps its existing serialization.
/// This is an omission from the new projection, never a source-row capability:
/// full fresh allocation and physical closure still run for this paragraph.
/// Generated implementation-property rows are never retagged or masked.
fn retains_ordinary_standard_body(p:&crate::model::paragraph::Paragraph,rows:&[LineSeg])->bool{
 if p.text.is_empty()||p.stored_text_partition_is_dirty()||p.layout_only_fill_lines!=0
  ||p.cell_format_vpos_dirty||p.completed_native_rows.is_some()||p.line_segs.len()!=rows.len()||rows.is_empty(){return false;}
 if let Some(v)=p.source_line_seg_vertical_pos.as_ref(){
  if v.len()==rows.len()&&!v.iter().zip(rows).all(|(y,r)|*y==r.vertical_pos){return false;}}
 p.line_segs.iter().zip(rows).all(|(a,b)|a.tag==LineSeg::TAG_SINGLE_SEGMENT_LINE
  &&b.tag==(LineSeg::TAG_SINGLE_SEGMENT_LINE|LineSeg::TAG_IMPLEMENTATION_PROPERTY)
  &&a.text_start==b.text_start&&a.vertical_pos==b.vertical_pos&&a.line_height==b.line_height
  &&a.text_height==b.text_height&&a.baseline_distance==b.baseline_distance&&a.line_spacing==b.line_spacing
  &&a.column_start==b.column_start&&a.segment_width==b.segment_width)
}
fn same_selected_line(a:&super::composer::ComposedLine,b:&super::composer::ComposedLine)->bool{
 a.char_start==b.char_start && a.line_height==b.line_height && a.baseline_distance==b.baseline_distance
 && a.segment_width==b.segment_width && a.column_start==b.column_start && a.line_spacing==b.line_spacing
 && !a.has_line_break && !b.has_line_break && a.runs.len()==b.runs.len()
 && a.runs.iter().zip(&b.runs).all(|(a,b)|a.text==b.text && a.char_style_id==b.char_style_id
  && a.lang_index==b.lang_index && a.char_overlap.is_none() && b.char_overlap.is_none()
  && a.footnote_marker.is_none() && b.footnote_marker.is_none() && a.display_text.is_none() && b.display_text.is_none()
  && a.supplemental_metrics_blocked==b.supplemental_metrics_blocked && !a.inserted_control_text && !b.inserted_control_text
  && a.space_metric==b.space_metric)
}

/// Candidate from this completed allocator pass, before any paint receipt.
/// Neither this type nor its paint facade is a serialized cache/row authority.
struct CandidateBody { paragraph:usize,physical_y:f64,fresh:FreshBodyRows,allow_empty_unused_width:bool }
#[derive(Debug,Clone)]struct CandidateTable {paragraph:usize,control:usize,incoming:f64,top:f64,before:f64,body:f64,after:f64,object_anchor:Option<(f64,f64,f64)>,standard_anchor:Option<f64>}
#[derive(Clone,Copy,Debug)]pub(crate) struct CurrentFrameTablePaint{pub(crate) paragraph_y:f64,pub(crate) table_top:f64}
#[derive(Debug,Clone)]pub(crate) struct CurrentFramePaintPlan { source_paragraphs:usize,generation:[u8;32],section:usize,page:u32,column:u16,
 rect:super::page_layout::LayoutRect,tables:Vec<CandidateTable> }
impl CurrentFramePaintPlan {
 pub(crate) fn receipt_binding(&self)->(usize,[u8;32]){(self.source_paragraphs,self.generation)}
 pub(crate) fn table_top(&self,paragraphs:&[crate::model::paragraph::Paragraph],section:usize,page:u32,column:u16,
 rect:&super::page_layout::LayoutRect,paragraph:usize,control:usize,flow:f64)->Option<CurrentFrameTablePaint>{
  if paragraphs.as_ptr() as usize!=self.source_paragraphs || section!=self.section || page!=self.page || column!=self.column
   || self.rect.x!=rect.x || self.rect.y!=rect.y || self.rect.width!=rect.width || self.rect.height!=rect.height {return None;}
  let host=self.tables.iter().find(|h|h.paragraph==paragraph&&h.control==control&&h.object_anchor.is_none())?;
  arithmetic_equal(flow,host.incoming).then_some(CurrentFrameTablePaint{paragraph_y:host.standard_anchor.unwrap_or(host.incoming),table_top:host.top})
 }
}
pub(crate) struct CurrentFrameCandidate<'doc> {source:&'doc Document,paint:CurrentFramePaintPlan,
 bodies:Vec<CandidateBody>,tables:Vec<CandidateTable>,rows:Vec<CurrentFrameParagraphRows>,generation:[u8;32]}
fn arithmetic_equal(a:f64,b:f64)->bool{a.is_finite()&&b.is_finite()&&(a-b).abs()<=f64::EPSILON*a.abs().max(b.abs()).max(1.0)*16.0}
fn integer_hu(px:f64,dpi:f64)->Option<i32>{if !px.is_finite()||!dpi.is_finite()||dpi<=0.0{return None;}let v=px*7200.0/dpi;
 let n=v.round();if n<i32::MIN as f64||n>i32::MAX as f64||!arithmetic_equal(v,n){return None;}Some(n as i32)}
fn same_empty_line_ignoring_unused_width(a:&super::composer::ComposedLine,b:&super::composer::ComposedLine)->bool{
 a.runs.iter().all(|r|r.text.is_empty()&&r.display_text.is_none()&&!r.inserted_control_text)
 && b.runs.iter().all(|r|r.text.is_empty()&&r.display_text.is_none()&&!r.inserted_control_text)
 && a.char_start==b.char_start && a.line_height==b.line_height && a.baseline_distance==b.baseline_distance
 && a.column_start==b.column_start && a.line_spacing==b.line_spacing && !a.has_line_break && !b.has_line_break
 && a.runs.len()==b.runs.len() && a.runs.iter().zip(&b.runs).all(|(a,b)|a.char_style_id==b.char_style_id&&a.lang_index==b.lang_index
 &&a.space_metric==b.space_metric&&a.supplemental_metrics_blocked==b.supplemental_metrics_blocked
 &&a.char_overlap.is_none()&&b.char_overlap.is_none()&&a.footnote_marker.is_none()&&b.footnote_marker.is_none())
}
fn fact_line_matches(f:&super::selected_composition_observer127::LineFact,l:&super::composer::ComposedLine,empty_width:bool)->bool{
 use super::composer::SpaceMetric;
 f.exact_source_text_span && f.scalar_start==l.char_start && f.height_hu==l.line_height && f.baseline_hu==l.baseline_distance
 && (f.width_hu==l.segment_width||empty_width) && f.column_start_hu==l.column_start && f.spacing_hu==l.line_spacing
 && !f.has_line_break && !l.has_line_break && f.runs.len()==l.runs.len()
 && f.runs.iter().zip(&l.runs).all(|(a,b)|a.text==b.text&&a.display_text.is_none()&&b.display_text.is_none()
  &&a.char_style_id==b.char_style_id&&a.language==b.lang_index&&a.overlap.is_none()&&b.char_overlap.is_none()
  &&a.footnote_marker.is_none()&&b.footnote_marker.is_none()&&a.supplemental_metrics_blocked==b.supplemental_metrics_blocked
  &&!a.inserted_control_text&&!b.inserted_control_text&&a.space_metric==match b.space_metric{SpaceMetric::Stored=>"Stored",
   SpaceMetric::HancomRegenerated=>"HancomRegenerated",SpaceMetric::HalfCell=>"HalfCell",SpaceMetric::KoPubJustified=>"KoPubJustified"})
}
fn clear_fresh_input(p:&mut crate::model::paragraph::Paragraph){p.line_segs.clear();p.layout_space_metrics.clear();p.source_line_seg_vertical_pos=None;
 p.hwpx_axis_shift=0;p.native_source_synthetic_seal=None;p.native_source_synthetic_context=None;p.completed_native_rows=None;p.native_frame_observation.set(None);}
fn native_table_common_exact(table:&crate::model::table::Table)->bool{
 let c=&table.common;if !matches!(table.raw_ctrl_data.len(),38|42)||!c.description.is_empty()||!c.raw_extra.is_empty()
 ||c.attr!=crate::serializer::control::pack_common_attr_bits(c)||c.ctrl_id!=0||c.z_order!=0||c.prevent_page_break!=0
 ||!matches!(c.numbering_type,crate::model::shape::ObjectNumberingType::None)||!matches!(c.drop_cap_style,crate::model::shape::DropCapStyle::None)
 ||c.margin.left!=table.outer_margin_left||c.margin.right!=table.outer_margin_right||c.margin.top!=table.outer_margin_top||c.margin.bottom!=table.outer_margin_bottom{return false;}
 let mut bytes=Vec::with_capacity(42);for v in[c.attr,c.vertical_offset,c.horizontal_offset,c.width,c.height]{bytes.extend(v.to_le_bytes());}
 bytes.extend(c.z_order.to_le_bytes());for v in[c.margin.left,c.margin.right,c.margin.top,c.margin.bottom]{bytes.extend(v.to_le_bytes());}
 bytes.extend(c.instance_id.to_le_bytes());if table.raw_ctrl_data.len()==42{bytes.extend(c.prevent_page_break.to_le_bytes());}bytes.extend(0u16.to_le_bytes());bytes==table.raw_ctrl_data
}
impl<'doc> CurrentFrameCandidate<'doc>{
 pub(crate) fn from_current(source:&'doc Document,format:crate::parser::FileFormat,result:&super::pagination::PaginationResult,
 styles:&super::style_resolver::ResolvedStyleSet,measured:&[super::height_measurer::MeasuredTable],
 profile:crate::model::provenance::LayoutCompatibilityProfile,dpi:f64)->Option<Self>{
 use super::pagination::PageItem;use crate::model::{control::Control,paragraph::ColumnBreakType};
 if source.sections.len()!=1||source.provenance.hwp3_lineage||!source.bin_data_content.is_empty()||result.pages.len()!=1
 ||!result.hidden_empty_paras.is_empty()||!result.pre_emitted_host_paras.is_empty()||!result.wrap_around_paras.is_empty()
 ||!result.endnotes.is_empty()||!result.endnote_paragraphs.is_empty()||dpi!=super::DEFAULT_DPI{return None;}
 match format{crate::parser::FileFormat::Hwp if profile.native_hwp5_layout()=>{},crate::parser::FileFormat::Hwpx if profile.hwp5_origin_hwpx()=>{},_=>return None}
 let section=&source.sections[0].section_def;
 if section.line_grid!=0||section.char_grid!=0||section.text_direction!=0||!section.master_pages.is_empty()||!section.extra_child_records.is_empty(){return None;}
 let ps=&source.sections[0].paragraphs;if ps.is_empty()||ps.len()>128||ps.iter().any(|p|p.completed_native_rows.is_some()){return None;}
 let [Control::SectionDef(_),Control::ColumnDef(columns)]=ps.first()?.controls.as_slice()else{return None;};
 if columns.column_count!=1||!columns.same_width||!columns.widths.is_empty()||!columns.gaps.is_empty()
 ||columns.column_type!=crate::model::page::ColumnType::Normal||columns.direction!=crate::model::page::ColumnDirection::LeftToRight{return None;}
 match format{crate::parser::FileFormat::Hwp=>if columns.raw_attr!=0x1004{return None;},crate::parser::FileFormat::Hwpx=>if columns.raw_attr!=0{return None;},_=>return None}
 let definition_context=source.reset_flow_contexts().first().copied().flatten()?;
 if styles.reset_flow_contexts.first().copied().flatten()!=Some(definition_context){return None;}
 let trace=result.selected_composition_trace.as_ref()?;
 if trace.section()!=0||trace.resource()!=crate::model::native_computed_resource::RESOURCE
 ||!trace.matches_source(ps,Some(definition_context),profile,dpi)||!trace.matches_finalized_result(result){return None;}
 let page=&result.pages[0];if page.page_index!=0||page.section_index!=0||page.column_contents.len()!=1||page.layout.column_areas.len()!=1
 ||!page.footnotes.is_empty()||page.active_header.is_some()||page.active_footer.is_some()||page.active_master_page.is_some()||!page.extra_master_pages.is_empty(){return None;}
 let col=&page.column_contents[0];let rect=page.layout.column_areas[0];
 if rect.width!=page.layout.body_area.width||col.column_index!=0||col.start_height!=0.0||col.endnote_flow||col.zone_layout.is_some()||col.zone_y_offset!=0.0
 ||!col.wrap_anchors.is_empty()||!col.wrap_around_paras.is_empty()||!col.inline_placements.is_empty()||!col.inline_flow_plans.is_empty()
 ||!col.overlay_continuations.is_empty()||!col.overlay_cuts.is_empty()||col.items.len()!=ps.len()
 ||trace.commits().len()+trace.whole_tables().len()!=col.items.len()||!trace.tables().is_empty(){return None;}
 let mut flow=0.0;let mut unpainted=0.0;let mut bodies=vec![];let mut tables=vec![];let mut rows=vec![];
 for (slot,item) in col.items.iter().enumerate(){match item{
 PageItem::FullParagraph{para_index:pi}=>{
  if *pi!=slot{return None;}let p=ps.get(*pi)?;let fresh=fresh_body_rows(p,styles,rect.width,dpi)?;
  if *pi==0 {if p.column_type!=ColumnBreakType::Section{return None;}}else if p.column_type!=ColumnBreakType::None||!p.controls.is_empty(){return None;}
  let mut cs=trace.commits().iter().filter(|c|c.paragraph==*pi);let c=cs.next()?;if cs.next().is_some(){return None;}
  let f=trace.format(c.format_id)?;let empty=p.text.is_empty()&&p.controls.is_empty()&&fresh.composition.lines.len()==1;
  if c.page!=Some(0)||c.column!=0||c.committed_item_index!=Some(slot)||c.final_membership!=Some(true)||c.row_start!=0||c.row_end!=fresh.rows.len()
  ||c.reused_multicolumn_format||c.same_format_reused_after_slot_change||c.trimmed_before!=0.0||c.actual_column_width_px!=rect.width
  ||!arithmetic_equal(c.flow_before,flow)||!c.metrics_still_match_selected_format||!c.range_inside_selected_composition
  ||f.source_text!=p.text||f.source_char_offsets!=p.char_offsets||f.paragraph_style!=fresh.composition.para_style_id
  ||(!empty&&f.actual_input_width_px!=Some(rect.width))||f.known_square_band||f.has_numbering||f.has_horizontal_shaping
  ||!f.tac_controls.is_empty()||!f.footnote_positions.is_empty()||!f.tab_extended.is_empty()
  ||f.inline_controls.len()!=fresh.composition.inline_controls.len()
  ||!f.inline_controls.iter().zip(&fresh.composition.inline_controls).all(|((line,index,kind),c)|*line==c.line_index&&*index==c.control_index&&*kind==format!("{:?}",c.control_type))
  ||f.before!=0.0||f.after!=0.0||f.lines.len()!=fresh.composition.lines.len()
  ||!f.lines.iter().zip(&fresh.composition.lines).all(|(a,b)|fact_line_matches(a,b,empty)){return None;}
  let total:f64=fresh.rows.iter().map(|r|super::hwpunit_to_px(r.line_height+r.line_spacing,dpi)).sum();
  if !arithmetic_equal(c.advance,total)||!arithmetic_equal(c.flow_after,c.flow_before+total)||c.flow_after>rect.height{return None;}
  let y=rect.y+c.flow_before-unpainted;let mut projected=fresh.rows.clone();let mut offset=0.0;
  for row in &mut projected{row.vertical_pos=integer_hu(y-rect.y+offset,dpi)?;offset+=super::hwpunit_to_px(row.line_height+row.line_spacing,dpi);}
  if !retains_ordinary_standard_body(p,&projected){rows.push(CurrentFrameParagraphRows{kind:CurrentFrameRowKind::FreshBody,section:0,paragraph:*pi,rows:projected});}bodies.push(CandidateBody{paragraph:*pi,physical_y:y,fresh,allow_empty_unused_width:empty});flow=c.flow_after;
 },PageItem::Table{para_index:pi,control_index:ci}=>{
  if *pi!=slot||*ci!=0{return None;}let p=ps.get(*pi)?;let [Control::Table(table)]=p.controls.as_slice()else{return None;};
  if !p.text.is_empty()||p.char_count!=9||!p.char_offsets.is_empty()||p.column_type!=ColumnBreakType::None
  ||p.completed_native_rows.is_some()||p.stored_text_partition_is_dirty()||p.cell_format_vpos_dirty||!p.field_ranges.is_empty()||!p.range_tags.is_empty()
  ||!p.tab_extended.is_empty()||p.layout_only_fill_lines!=0
  ||!table.common.raw_extra.is_empty()||table.raw_table_record_extra.iter().any(|b|*b!=0)
 ||i32::try_from(table.common.width).ok()?.checked_add(i32::from(table.outer_margin_left))?.checked_add(i32::from(table.outer_margin_right))?!=integer_hu(rect.width,dpi)?{return None;}
  let plain_cell=|q:&crate::model::paragraph::Paragraph|q.controls.is_empty()&&q.field_ranges.is_empty()&&q.range_tags.is_empty()&&q.tab_extended.is_empty();
  let offset=if table.common.vertical_offset!=0{
   Some(super::current_offset_frame::CurrentOffsetTableShape::from_current(table,plain_cell)?)
  }else{if !crate::renderer::generated_column_stack::plain_table(table,plain_cell){return None;}None};
  match format{crate::parser::FileFormat::Hwp=>if !native_table_common_exact(table){return None;},crate::parser::FileFormat::Hwpx=>if !table.raw_ctrl_data.is_empty(){return None;},_=>return None}
  let mut ms=measured.iter().filter(|m|m.para_index==*pi&&m.control_index==0);let m=ms.next()?;if ms.next().is_some()||m.caption_height!=0.0||m.total_height<=0.0||!m.total_height.is_finite()
  ||integer_hu(m.total_height,dpi)?!=i32::try_from(table.common.height).ok()?{return None;}
  let mut ts=trace.whole_tables().iter().filter(|t|t.paragraph==*pi&&t.control==0);let t=ts.next()?;if ts.next().is_some(){return None;}
  if t.page!=Some(0)||t.column!=0||t.post_page!=Some(0)||t.post_column!=0||t.committed_item_index!=slot||t.final_membership!=Some(true)
  ||t.pre_text_height!=0.0||t.pre_text_end!=0||!arithmetic_equal(t.flow_before,flow)||t.before<0.0||t.after_for_fit<0.0
  ||t.body_height!=m.total_height||!arithmetic_equal(t.table_total_height,t.before+t.body_height+t.after_for_fit)
  ||t.flow_after>rect.height
  ||integer_hu(t.before,dpi)?!=i32::from(table.outer_margin_top){return None;}
  let object_anchor=if let Some(placement)=t.resolved.as_ref(){
   if offset.is_some(){return None;}
   let current=col.paragraph_float_placements.get(&(*pi,0))?;
   if placement.flow!="Exclusion"||placement.next_flow_y.is_some()||placement.stored_host_origin.is_some()
    ||placement.stored_successor_origin.is_some()||placement.table_left.is_some()
    ||current.flow!=crate::renderer::float_placement::ParagraphFloatFlow::Exclusion
    ||current.anchor_y!=placement.anchor_y||current.table_top!=placement.table_top||current.occupied_bottom!=placement.occupied_bottom
    ||current.stored_host_origin.is_some()||current.stored_successor_line_origin.is_some()||current.table_left.is_some()
    ||!arithmetic_equal(placement.anchor_y,t.flow_before)||!arithmetic_equal(placement.table_top,t.flow_before+t.before)
    ||t.full_after<0.0||integer_hu(t.full_after-t.after_for_fit,dpi)?!=i32::from(table.outer_margin_bottom)
    ||!arithmetic_equal(placement.occupied_bottom,placement.table_top+t.body_height+t.full_after)
    ||!arithmetic_equal(t.flow_after,placement.occupied_bottom){return None;}
   Some((placement.anchor_y,placement.occupied_bottom,rect.y+t.flow_before-unpainted))
  }else{if col.paragraph_float_placements.contains_key(&(*pi,0))||!arithmetic_equal(t.flow_after,t.flow_before+t.table_total_height){return None;}None};
  let incoming=rect.y+t.flow_before-unpainted;
  let top=if object_anchor.is_some(){rect.y+t.flow_before+t.before}else{match offset{Some(current)=>current.paint_edge(incoming,dpi)?,None=>incoming}};
  if top<rect.y||top+t.body_height>rect.y+rect.height{return None;}
  // The structural object row owns no text ink, but its paragraph/font style
  // context must remain within the same explicit plain frame contract.
  let mut style_probe=p.clone();style_probe.controls.clear();style_probe.char_count=1;
  fresh_body_rows(&style_probe,styles,rect.width,dpi)?;
  let mut host=p.clone();clear_fresh_input(&mut host);
  if object_anchor.is_some(){host.line_segs=vec![crate::model::object_anchor::structural_table_anchor_row()];}else{super::composer::reflow_line_segs(&mut host,super::composer::ParagraphBox::content_for_style(rect.width,styles.para_styles.get(usize::from(p.para_shape_id)),dpi),styles,dpi);}
  if host.line_segs.len()!=1{return None;}
  let selected=trace.format(t.selected_format_id?)?;let fresh_host=super::composer::compose_paragraph_in_context(&host,styles);
  if selected.source_text!=p.text||selected.source_char_offsets!=p.char_offsets||selected.paragraph_style!=fresh_host.para_style_id
   ||selected.has_numbering||selected.has_horizontal_shaping||selected.known_square_band
   ||!selected.tac_controls.is_empty()||!selected.footnote_positions.is_empty()||!selected.tab_extended.is_empty()
   ||selected.lines.len()!=1||fresh_host.lines.len()!=1||t.selected_line_count!=1
   ||!fact_line_matches(&selected.lines[0],&fresh_host.lines[0],true)
   ||selected.inline_controls.len()!=fresh_host.inline_controls.len()
   ||!selected.inline_controls.iter().zip(&fresh_host.inline_controls).all(|((line,index,kind),c)|*line==c.line_index&&*index==c.control_index&&*kind==format!("{:?}",c.control_type)){return None;}
  let generated=&host.line_segs[0];if (object_anchor.is_none()&&generated.tag!=0x80060000)||(object_anchor.is_some()&&!crate::model::object_anchor::is_canonical_structural_table_anchor(generated))||generated.vertical_pos!=0||generated.text_start!=0
   ||generated.line_height<=0||generated.text_height!=generated.line_height||generated.line_spacing<0
   ||generated.baseline_distance<0||generated.baseline_distance>generated.line_height||generated.column_start!=0
   ||generated.segment_width!=if object_anchor.is_some(){0}else{integer_hu(rect.width,dpi)?}{return None;}
  host.line_segs[0].vertical_pos=integer_hu(object_anchor.map_or(incoming-rect.y-t.before,|v|v.0),dpi)?;
  if host.line_segs[0].vertical_pos<0{return None;}
  rows.push(CurrentFrameParagraphRows{kind:if object_anchor.is_some(){CurrentFrameRowKind::StructuralObjectAnchor}else{CurrentFrameRowKind::FreshBody},section:0,paragraph:*pi,rows:host.line_segs});tables.push(CandidateTable{paragraph:*pi,control:0,incoming,top,before:t.before,body:t.body_height,after:t.after_for_fit,object_anchor,standard_anchor:None});
  if object_anchor.is_some(){unpainted=0.0;}else{unpainted+=t.before;}flow=t.flow_after;
 },_=>return None}}
 if tables.is_empty()||measured.len()!=tables.len()||col.paragraph_float_placements.len()!=tables.iter().filter(|t|t.object_anchor.is_some()).count()||!arithmetic_equal(flow,col.used_height){return None;}
 let mut h=blake3::Hasher::new();h.update(b"current-whole-frame-proof-1\0");h.update(&trace.resource());h.update(&trace.generation().to_le_bytes());
 for t in &tables{h.update(&(t.paragraph as u64).to_le_bytes());for v in[t.incoming,t.top,t.before,t.body,t.after]{h.update(&v.to_bits().to_le_bytes());}match t.object_anchor{Some((a,b,c))=>{h.update(&[1]);h.update(&a.to_bits().to_le_bytes());h.update(&b.to_bits().to_le_bytes());h.update(&c.to_bits().to_le_bytes());},None=>{h.update(&[0]);}}}
 let generation=*h.finalize().as_bytes();let paint=CurrentFramePaintPlan{source_paragraphs:ps.as_ptr()as usize,generation,section:0,page:0,column:0,rect,tables:tables.clone()};
 Some(Self{source,paint,bodies,tables,rows,generation})
 }
 pub(crate) fn paint_plan(&self)->CurrentFramePaintPlan{self.paint.clone()}
 pub(crate) fn finalize(self,physical:&super::current_physical_selections::CurrentPhysicalSelections)->Option<CurrentFrameRowsPlan<'doc>>{
  if !physical.matches_current_plan(&self.paint){return None;}
  let frames=physical.frames()?;let [frame]=frames else{return None;};if frame.section!=0||frame.page!=0||frame.column!=0||frame.column_ordinal!=0||frame.has_zone||frame.zone_y!=0.0
  ||frame.rect.x!=self.paint.rect.x||frame.rect.y!=self.paint.rect.y||frame.rect.width!=self.paint.rect.width||frame.rect.height!=self.paint.rect.height{return None;}
  let painted=physical.rows()?;let actual_tables=physical.tables()?;if actual_tables.len()!=self.tables.len(){return None;}
  let expected_count:usize=self.bodies.iter().map(|b|b.fresh.rows.len()).sum();if painted.len()!=expected_count{return None;}
  for body in &self.bodies{let selected=painted.iter().filter(|r|r.frame.paragraph==body.paragraph).collect::<Vec<_>>();if selected.len()!=body.fresh.rows.len(){return None;}
   let mut offset=0.0;for (i,(fresh,row))in body.fresh.composition.lines.iter().zip(selected).enumerate(){
    let f=&row.frame;if f.node!=frame.node||f.line!=i||f.equation_adjusted||f.has_wrap_anchor||f.physical_frame_rows||f.stored_horizontal_span_used
    ||f.effective_column_x!=frame.rect.x||f.effective_column_width!=frame.rect.width||f.available_width!=frame.rect.width
    ||f.margin_left!=0.0||f.margin_right!=0.0||f.inline_offset!=0.0||f.numbering_offset!=0.0
    ||!arithmetic_equal(f.physical_text_y,body.physical_y+offset)||f.final_line_box_height!=super::hwpunit_to_px(fresh.line_height,super::DEFAULT_DPI)
    ||(!same_selected_line(fresh,&row.selected)&&!(body.allow_empty_unused_width&&same_empty_line_ignoring_unused_width(fresh,&row.selected))){return None;}
    offset+=super::hwpunit_to_px(fresh.line_height+fresh.line_spacing,super::DEFAULT_DPI);
   }}
  for table in &self.tables{let mut actual=actual_tables.iter().filter(|t|t.paragraph==table.paragraph&&t.control==table.control);let t=actual.next()?;
   if actual.next().is_some()||t.node!=frame.node||t.typed_float!=table.object_anchor.is_some()||t.inline||t.treat_as_char||t.selected_outer_inset!=0.0
   ||!arithmetic_equal(t.incoming_y,table.incoming)||!arithmetic_equal(t.selected_y,table.top)||t.visual_height!=table.body||!arithmetic_equal(t.visual_end,table.top+table.body)
   ||!arithmetic_equal(t.flow_end,table.top+table.body){return None;}
   if table.object_anchor.is_none()&&!arithmetic_equal(t.paragraph_y,table.incoming){return None;}
   if let Some((anchor,_,incoming))=table.object_anchor{
    if !arithmetic_equal(t.incoming_y,incoming)||!arithmetic_equal(t.paragraph_y,frame.rect.y+anchor){return None;}}}
  Some(CurrentFrameRowsPlan{source:self.source,resource:crate::model::native_computed_resource::RESOURCE,allocation_generation:self.generation,paragraphs:self.rows})
 }
}


#[cfg(test)]
#[path="current_frame_rows_plan_tests.rs"]
mod tests;

/// A provisional prefix-only output candidate. The physical collector is bound
/// to its exact source/pass and must close actual paint before rows are exposed
/// through the existing whole-document output binder.
pub(crate) struct CurrentPrefixFrameCandidate<'doc>{
 prefix:super::current_equal_column_prefix::CurrentEqualColumnPrefixCandidate<'doc>,
 paint:CurrentFramePaintPlan,columns:Vec<(usize,u16,super::page_layout::LayoutRect)>,
}
impl<'doc> CurrentPrefixFrameCandidate<'doc>{
 pub(crate) fn from_current(source:&'doc Document,result:&super::pagination::PaginationResult,styles:&super::style_resolver::ResolvedStyleSet,
  profile:crate::model::provenance::LayoutCompatibilityProfile,dpi:f64)->Option<Self>{
  let prefix=super::current_equal_column_prefix::CurrentEqualColumnPrefixCandidate::from_current(source,result,styles,profile,dpi)?;
  let rect=prefix.frame();let mut h=blake3::Hasher::new();h.update(b"current-equal-column-prefix-capture-1\0");
  h.update(&crate::model::native_computed_resource::RESOURCE);h.update(&prefix.generation().to_le_bytes());
  for v in[rect.x,rect.y,rect.width,rect.height,prefix.flow_after()]{h.update(&v.to_bits().to_le_bytes());}
  let generation=*h.finalize().as_bytes();
  let paint=CurrentFramePaintPlan{source_paragraphs:source.sections[0].paragraphs.as_ptr()as usize,generation,section:0,page:0,column:0,rect,tables:Vec::new()};
  let page=&result.pages[0];let columns=page.column_contents.iter().enumerate().map(|(ordinal,c)|(ordinal,c.column_index,page.layout.column_areas[usize::from(c.column_index)])).collect();
  Some(Self{prefix,paint,columns})
 }
 pub(crate) fn matches_current(&self,source:&Document,result:&super::pagination::PaginationResult,styles:&super::style_resolver::ResolvedStyleSet,
  profile:crate::model::provenance::LayoutCompatibilityProfile,dpi:f64)->bool{self.prefix.matches_current(source,result,styles,profile,dpi)}
 pub(crate) fn paint_plan(&self)->CurrentFramePaintPlan{self.paint.clone()}
 pub(crate) fn finalize(self,physical:&super::current_physical_selections::CurrentPhysicalSelections)->Option<CurrentFrameRowsPlan<'doc>>{
  if !physical.matches_current_plan(&self.paint){return None;}
  let frames=physical.frames()?;if frames.len()!=self.columns.len(){return None;}
  for (frame,(ordinal,column,rect))in frames.iter().zip(&self.columns){if frame.section!=0||frame.page!=0||frame.column_ordinal!=*ordinal||frame.column!=*column
   ||frame.has_zone||frame.zone_y!=0.0||frame.rect.x!=rect.x||frame.rect.y!=rect.y||frame.rect.width!=rect.width||frame.rect.height!=rect.height{return None;}}
  let frame=frames.first()?;if !matches!(frame.items.first(),Some(super::pagination::PageItem::FullParagraph{para_index:0})){return None;}
  let actual=physical.rows()?.iter().filter(|r|r.frame.paragraph==0).collect::<Vec<_>>();
  let fresh=self.prefix.fresh_rows();if actual.len()!=fresh.len(){return None;}
  let mut offset=0.0;
  for(i,(row,standard))in actual.iter().zip(fresh).enumerate(){let f=&row.frame;
   // Both the physical column and the effective painted inline span remain
   // separate facts. A stored-span branch is accepted only when its value is
   // independently the exact generic current standard row's inline extent.
   let effective_width=if f.stored_horizontal_span_used{super::hwpunit_to_px(standard.segment_width,super::DEFAULT_DPI)}else{frame.rect.width};
   if f.node!=frame.node||f.line!=i||f.equation_adjusted||f.has_wrap_anchor
    ||f.effective_column_x!=frame.rect.x||f.effective_column_width!=effective_width||f.available_width!=effective_width
    ||f.margin_left!=0.0||f.margin_right!=0.0||f.inline_offset!=0.0||f.numbering_offset!=0.0
    ||!arithmetic_equal(f.physical_text_y,frame.rect.y+offset)
    ||f.final_line_box_height!=super::hwpunit_to_px(standard.line_height,super::DEFAULT_DPI)
    ||f.baseline!=super::hwpunit_to_px(standard.baseline_distance,super::DEFAULT_DPI)
    ||!self.prefix.matches_selected_line(i,&row.selected){return None;}
   offset+=super::hwpunit_to_px(standard.line_height.checked_add(standard.line_spacing)?,super::DEFAULT_DPI);
  }
  if !arithmetic_equal(offset,self.prefix.flow_after()){return None;}
  if retains_ordinary_standard_body(&self.prefix.source().sections[0].paragraphs[0],fresh){return None;}
  let rows=fresh.to_vec();Some(CurrentFrameRowsPlan{source:self.prefix.source(),resource:crate::model::native_computed_resource::RESOURCE,
   allocation_generation:self.paint.generation,paragraphs:vec![CurrentFrameParagraphRows{kind:CurrentFrameRowKind::FreshBody,section:0,paragraph:0,rows}]})
 }
}

#[path="current_page_frames135.rs"]
mod explicit_pages;
pub(crate) use explicit_pages::{CurrentPageFramesCandidate,CurrentDocumentFramesCandidate};

#[path="current_equal_column_stack137.rs"]
mod current_equal_column_stack137;
pub(crate) use current_equal_column_stack137::CurrentEqualColumnStackCandidate;

pub(crate) struct CurrentUnequalPrefixFrameCandidate<'doc>{
 prefix:super::current_unequal_column_prefix139::CurrentUnequalColumnPrefixCandidate<'doc>,
 paint:CurrentFramePaintPlan,columns:Vec<(usize,u16,super::page_layout::LayoutRect)>,
}
impl<'doc> CurrentUnequalPrefixFrameCandidate<'doc>{
 pub(crate) fn from_current(source:&'doc Document,result:&super::pagination::PaginationResult,styles:&super::style_resolver::ResolvedStyleSet,
  profile:crate::model::provenance::LayoutCompatibilityProfile,dpi:f64)->Option<Self>{
  let prefix=super::current_unequal_column_prefix139::CurrentUnequalColumnPrefixCandidate::from_current(source,result,styles,profile,dpi)?;
  let rect=prefix.frame();let mut h=blake3::Hasher::new();h.update(b"current-unequal-column-prefix-capture-1\0");
  h.update(&crate::model::native_computed_resource::RESOURCE);h.update(&prefix.generation().to_le_bytes());
  for v in[rect.x,rect.y,rect.width,rect.height,prefix.flow_after()]{h.update(&v.to_bits().to_le_bytes());}
  let generation=*h.finalize().as_bytes();
  let paint=CurrentFramePaintPlan{source_paragraphs:source.sections[0].paragraphs.as_ptr()as usize,generation,section:0,page:0,column:0,rect,tables:Vec::new()};
  let page=&result.pages[0];let columns=page.column_contents.iter().enumerate().map(|(ordinal,c)|(ordinal,c.column_index,page.layout.column_areas[usize::from(c.column_index)])).collect();
  Some(Self{prefix,paint,columns})
 }
 pub(crate) fn matches_current(&self,source:&Document,result:&super::pagination::PaginationResult,styles:&super::style_resolver::ResolvedStyleSet,
  profile:crate::model::provenance::LayoutCompatibilityProfile,dpi:f64)->bool{self.prefix.matches_current(source,result,styles,profile,dpi)}
 pub(crate) fn paint_plan(&self)->CurrentFramePaintPlan{self.paint.clone()}
 pub(crate) fn finalize(self,physical:&super::current_physical_selections::CurrentPhysicalSelections)->Option<CurrentFrameRowsPlan<'doc>>{
  if !physical.matches_current_plan(&self.paint){return None;}
  let frames=physical.frames()?;if frames.len()!=self.columns.len(){return None;}
  for (frame,(ordinal,column,rect))in frames.iter().zip(&self.columns){if frame.section!=0||frame.page!=0||frame.column_ordinal!=*ordinal||frame.column!=*column
   ||frame.has_zone||frame.zone_y!=0.0||frame.rect.x!=rect.x||frame.rect.y!=rect.y||frame.rect.width!=rect.width||frame.rect.height!=rect.height{return None;}}
  let frame=frames.first()?;if !matches!(frame.items.first(),Some(super::pagination::PageItem::FullParagraph{para_index:0})){return None;}
  let actual=physical.rows()?.iter().filter(|r|r.frame.paragraph==0).collect::<Vec<_>>();
  let fresh=self.prefix.fresh_rows();if actual.len()!=fresh.len(){return None;}
  let mut offset=0.0;
  for(i,(row,standard))in actual.iter().zip(fresh).enumerate(){let f=&row.frame;
   // Both the physical column and the effective painted inline span remain
   // separate facts. A stored-span branch is accepted only when its value is
   // independently the exact generic current standard row's inline extent.
   let effective_width=if f.stored_horizontal_span_used{super::hwpunit_to_px(standard.segment_width,super::DEFAULT_DPI)}else{frame.rect.width};
   if f.node!=frame.node||f.line!=i||f.equation_adjusted||f.has_wrap_anchor
    ||f.effective_column_x!=frame.rect.x||f.effective_column_width!=effective_width||f.available_width!=effective_width
    ||f.margin_left!=0.0||f.margin_right!=0.0||f.inline_offset!=0.0||f.numbering_offset!=0.0
    ||!arithmetic_equal(f.physical_text_y,frame.rect.y+offset)
    ||f.final_line_box_height!=super::hwpunit_to_px(standard.line_height,super::DEFAULT_DPI)
    ||f.baseline!=super::hwpunit_to_px(standard.baseline_distance,super::DEFAULT_DPI)
    ||!self.prefix.matches_selected_line(i,&row.selected){return None;}
   offset+=super::hwpunit_to_px(standard.line_height.checked_add(standard.line_spacing)?,super::DEFAULT_DPI);
  }
  if !arithmetic_equal(offset,self.prefix.flow_after()){return None;}
  if retains_ordinary_standard_body(&self.prefix.source().sections[0].paragraphs[0],fresh){return None;}
  let rows=fresh.to_vec();Some(CurrentFrameRowsPlan{source:self.prefix.source(),resource:crate::model::native_computed_resource::RESOURCE,
   allocation_generation:self.paint.generation,paragraphs:vec![CurrentFrameParagraphRows{kind:CurrentFrameRowKind::FreshBody,section:0,paragraph:0,rows}]})
 }
}
