//! 렌더링 엔진 모듈
//!
//! IR(Document Model) → 렌더 트리 → 백엔드 렌더링 파이프라인을 구현한다.
//! Renderer Trait으로 추상화하여 Canvas/SVG/HTML 백엔드를 선택할 수 있다.

use serde::Serialize;

use crate::model::control::Control;
use crate::model::paragraph::LineSeg;
use crate::model::style::{LineSpacingType, UnderlineType};

pub mod canvas;
pub mod canvas_text_font;
pub mod canvaskit_policy;
pub mod composer;
pub mod equation;
pub(crate) mod equation_tac_flow;
pub mod float_placement;
pub(crate) mod generated_column_stack;
pub(crate) mod font_decision;
pub mod font_environment;
pub mod font_metrics_data;
#[cfg(not(target_arch = "wasm32"))]
pub mod font_paths;
#[path = "font_rule_projections/layout_metric.rs"]
pub(crate) mod font_rule_layout_metric_projection;
#[path = "font_rule_projections/layout_name.rs"]
pub(crate) mod font_rule_layout_name_projection;
pub mod form_appearance;
pub(crate) mod form_caption;
pub mod hyperlinks;
// [gym_gpu_raster] GPU 가속 SVG 래스터화(vello/wgpu). 네이티브 + gpu feature 전용 —
// native-skia 와 같은 방식으로 선택적 게이팅해 CI는 GPU 없이도 컴파일된다.
#[cfg(all(not(target_arch = "wasm32"), feature = "gpu"))]
pub mod gpu;
pub(crate) mod hancom_pua;
pub mod height_cursor;
pub mod height_measurer;
pub(crate) mod hft_ascii_evidence;
pub mod html;
pub(crate) mod image_header;
pub mod image_resolver;
pub mod inline_flow;
pub(crate) mod kerning;
pub mod layer_renderer;
pub mod layout;
pub(crate) mod layout_frame;
pub mod page_layout;
pub mod page_number;
pub mod pagination;
#[cfg(any(target_arch = "wasm32", test))]
pub(crate) mod partial_replay;
#[cfg(not(target_arch = "wasm32"))]
pub mod pdf;
#[cfg(not(target_arch = "wasm32"))]
pub mod pdf_raster_fidelity;
pub mod pua_oldhangul;
pub mod render_normalization;
pub mod render_tree;
pub mod scheduler;
pub(crate) mod shaping;
pub(crate) mod shaping_composition;
pub(crate) mod shaping_context;
pub(crate) mod shaping_paragraph;
pub(crate) mod shaping_publication;
// Q4-D1 registers the exact-source-bound vertical owner while all product
// layout/publication callers remain closed until their own approved slices.
#[allow(dead_code)]
pub(crate) mod shaping_vertical;
#[cfg(all(not(target_arch = "wasm32"), feature = "native-skia"))]
pub mod skia;
pub(crate) mod static_svg;
pub(crate) mod stored_float_anchor;
pub mod style_resolver;
pub mod supplemental_metrics;
pub mod svg;
pub mod svg_fragment;
pub mod svg_layer;
pub(crate) mod text_decoration;
pub mod typeset;
#[cfg(target_arch = "wasm32")]
pub mod web_canvas;

use crate::model::ColorRef;

/// 렌더링 백엔드 종류
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum RenderBackend {
    /// Canvas 2D API (1차)
    Canvas,
    /// SVG 엘리먼트 생성 (2차)
    Svg,
    /// HTML DOM 생성 (3차)
    Html,
}

impl RenderBackend {
    /// 문자열로부터 백엔드 파싱
    pub fn from_str(s: &str) -> Option<Self> {
        match s {
            "canvas" => Some(RenderBackend::Canvas),
            "svg" => Some(RenderBackend::Svg),
            "html" => Some(RenderBackend::Html),
            _ => None,
        }
    }
}

/// 탭 정지 (렌더링용)
#[derive(Debug, Clone, PartialEq, Serialize)]
pub struct TabStop {
    /// 절대 위치 (px, 단 시작 기준)
    pub position: f64,
    /// 탭 종류 (0=왼쪽, 1=오른쪽, 2=가운데, 3=소수점)
    pub tab_type: u8,
    /// 채움 종류 (0=없음, 1=실선, 2=파선, 3=점선)
    pub fill_type: u8,
}

/// 탭 리더(채움 기호) 렌더링 정보
#[derive(Debug, Clone, PartialEq, Serialize)]
pub struct TabLeaderInfo {
    /// 리더 시작 x (run 내 상대 좌표)
    pub start_x: f64,
    /// 리더 끝 x (run 내 상대 좌표)
    pub end_x: f64,
    /// 채움 종류 (1=실선, 2=파선, 3=점선)
    pub fill_type: u8,
}

pub(crate) fn clamp_tab_leader_end_x(
    text: &str,
    char_positions: &[f64],
    leader: &TabLeaderInfo,
    font_size: f64,
) -> f64 {
    let content_stop = text.chars().enumerate().find_map(|(i, ch)| {
        if ch != '\t'
            && !ch.is_whitespace()
            && i < char_positions.len()
            && char_positions[i] > leader.start_x + 0.5
        {
            Some(char_positions[i] - font_size * 0.25)
        } else {
            None
        }
    });
    content_stop
        .map(|stop| stop.min(leader.end_x).max(leader.start_x))
        .unwrap_or(leader.end_x)
}

/// 글꼴 원래 하이픈 폭이 저장 글자 간격보다 커서 연속 하이픈이 실선으로
/// 겹칠 때만, 각 글자의 짧은 획을 그릴 공통 기하를 돌려준다.
/// 글자마다 별도 획을 남겨 한컴 출력의 파선과 문자 소유를 보존한다.
pub(crate) fn overlapping_dash_leader_segment(
    text: &str,
    style: &TextStyle,
    char_index: usize,
    positions: &[f64],
    font_size: f64,
) -> Option<(f64, f64, f64, f64)> {
    if style.shadow_type > 0 || style.outline_type > 0 || style.emboss || style.engrave {
        return None;
    }
    let face = style
        .font_family
        .split(',')
        .next()?
        .trim()
        .trim_matches(['\'', '"']);
    if face != "한양신명조" || positions.len() <= char_index + 1 {
        return None;
    }
    let chars: Vec<char> = text.chars().collect();
    if chars.get(char_index) != Some(&'-') {
        return None;
    }
    let left = chars[..char_index]
        .iter()
        .rev()
        .take_while(|ch| **ch == '-')
        .count();
    let right = chars[char_index + 1..]
        .iter()
        .take_while(|ch| **ch == '-')
        .count();
    if left + right + 1 < 3 {
        return None;
    }
    let advance = positions[char_index + 1] - positions[char_index];
    // 저장 폭 표는 좁은 획(588/1024em)을 쓰지만 실제 SVG 글꼴은
    // H2MJSM의 넓은 하이픈(853/1024em)을 칠한다. 겹침 판정은 칠할
    // 글꼴의 폭으로 해야 한다.
    let metric =
        font_metrics_data::find_metric_decision("HYSinMyeongJo-Medium", style.bold, style.italic)?;
    let natural_width =
        f64::from(metric.metric.get_width('-')?) * font_size / f64::from(metric.metric.em_size);
    if advance <= 0.0 || natural_width <= advance + 0.25 {
        return None;
    }
    // 한컴 출력의 하이픈 획은 저장 글자 원점에서 시작하며 기준선보다
    // 0.43em 위에 있다. 길이는 저장 advance 안에서만 남긴다.
    let end = (font_size * 0.38).min(advance * 0.7);
    Some((0.0, end, -font_size * 0.43, font_size * 0.054))
}

/// Backend replay 직전의 optional scalar positions를 한 번 더 검증한다.
///
/// `TextRunNode` accessor와 positioned `Renderer` 직접 호출이 같은 bounded
/// 계약을 소비하도록 하는 단일 판정이다. 문자열 projection으로 scalar 수가
/// 달라지거나 payload가 손상되면 해당 run 전체를 K0로 되돌린다.
pub(crate) fn validated_replay_positions<'a>(
    replay_text: &str,
    positions: Option<&'a [f64]>,
) -> Option<&'a [f64]> {
    let positions = positions?;
    let max_scalars = kerning::MAX_KERNING_RUN_CODE_POINTS;
    if positions.len() > max_scalars.saturating_add(1) {
        return None;
    }
    let scalar_count = replay_text.chars().take(max_scalars + 1).count();
    if scalar_count > max_scalars || positions.len() != scalar_count.saturating_add(1) {
        return None;
    }
    if positions.first().copied() != Some(0.0)
        || positions
            .iter()
            .any(|position| !position.is_finite() || *position < 0.0)
        || positions.windows(2).any(|pair| pair[0] > pair[1])
    {
        return None;
    }
    Some(positions)
}

pub(crate) fn replay_positions_or_compute<'a>(
    replay_text: &str,
    style: &TextStyle,
    positions: Option<&'a [f64]>,
) -> std::borrow::Cow<'a, [f64]> {
    validated_replay_positions(replay_text, positions)
        .map(std::borrow::Cow::Borrowed)
        .unwrap_or_else(|| {
            std::borrow::Cow::Owned(layout::compute_char_positions(replay_text, style))
        })
}

/// 글리프 폭 맞춤(SVG `textLength`, Canvas `scaleX`)에 쓸 문자 경계를 돌려준다.
///
/// 커닝은 글자 사이만 좁힌다. 커닝한 경계로 폭을 맞추면 쌍의 앞 글자가 커닝만큼
/// 눌린다. 커닝을 요청한 run이 layout positions로 그려지면 커닝 전 경계로 폭을
/// 맞추고, 그리는 자리는 호출자의 layout positions를 그대로 쓴다.
pub(crate) fn glyph_fit_positions<'a>(
    replay_text: &str,
    style: &TextStyle,
    layout_positions: Option<&[f64]>,
    char_positions: &'a [f64],
) -> std::borrow::Cow<'a, [f64]> {
    if style.kerning && validated_replay_positions(replay_text, layout_positions).is_some() {
        std::borrow::Cow::Owned(layout::compute_char_positions(replay_text, style))
    } else {
        std::borrow::Cow::Borrowed(char_positions)
    }
}

/// 텍스트 렌더링 스타일
#[derive(Debug, Clone, PartialEq, Serialize)]
pub struct TextStyle {
    /// Session-only glyph metrics; never part of document/style serialization.
    #[serde(skip)]
    pub supplemental_metrics:
        Option<std::sync::Arc<supplemental_metrics::SupplementalMetricSnapshot>>,
    /// 글꼴 이름
    pub font_family: String,
    /// 글꼴 크기 (px)
    pub font_size: f64,
    /// 글자 색상
    pub color: ColorRef,
    /// 진하게
    pub bold: bool,
    /// 기울임
    pub italic: bool,
    /// 밑줄 위치 (None/Bottom/Top)
    pub underline: UnderlineType,
    /// 취소선
    pub strikethrough: bool,
    /// 문서가 kerning pair positioning을 요청했는지 여부.
    ///
    /// `false`는 기존 layer-tree 직렬화에서 생략해 kerning-off schema와
    /// byte baseline을 보존한다. 실제 pair adjustment는 공통 measurement
    /// decision이 exact font capability를 확인한 뒤 별도로 결정한다.
    #[serde(skip_serializing_if = "std::ops::Not::not")]
    pub kerning: bool,
    /// 자간 (px)
    pub letter_spacing: f64,
    /// 장평 비율 (1.0 = 100%, 0.8 = 80%)
    pub ratio: f64,
    /// 기본 탭 간격 (px, 0이면 font_size 기반 fallback)
    pub default_tab_width: f64,
    /// 커스텀 탭 정지 목록 (position 오름차순)
    pub tab_stops: Vec<TabStop>,
    /// 문단 오른쪽 끝 자동 탭 여부
    pub auto_tab_right: bool,
    /// 사용 가능 너비 (px, auto_tab_right 계산용)
    pub available_width: f64,
    /// 단 시작으로부터 run 시작 위치 (탭 절대좌표 변환용)
    pub line_x_offset: f64,
    /// 단 시작으로부터 텍스트 영역 시작 위치 (effective_margin_left, px).
    /// auto_tab_right 의 col-relative 위치 = text_start_offset + available_width.
    /// [Task #874] 종전 find_next_tab_stop 의 auto_right 반환값(=available_width) 은
    /// 텍스트-시작-상대 좌표였으나, 호출자(compute_char_positions / pending_right_tab)
    /// 가 col-relative 로 해석해 effective_margin_left 만큼 좌측으로 밀린 정렬 발생.
    /// 본 필드로 변환 보정.
    pub text_start_offset: f64,
    /// auto_tab_right + 다음 run-경계 cross 시 우측 정렬 블록의 총 폭 (px).
    /// composer 가 lang/script 경계로 run 을 쪼개면 (예: "F3→Alt+I" → "F3"/"→"/"Alt+I")
    /// `measure_segment_from` 이 현재 run 의 post-tab chars 만 측정하여 seg_w 가
    /// 과소되고, 우측 정렬이 무너진다. paragraph_layout 에서 line 내 후속 runs 합산
    /// 을 미리 계산해 주입한다. None 이면 기존 동작 (현재 run 내부 측정).
    pub right_tab_block_width_override: Option<f64>,
    /// 탭 리더 정보 (compute_char_positions 후 채움)
    pub tab_leaders: Vec<TabLeaderInfo>,
    /// HWPX 인라인 탭 확장 데이터 ([width, leader, type, ...])
    pub inline_tabs: Vec<[u16; 7]>,
    /// 양쪽 정렬용: 공백 문자당 추가 간격 (px)
    pub extra_word_spacing: f64,
    /// 배분/나눔 정렬용: 글자당 추가 간격 (px)
    pub extra_char_spacing: f64,
    /// Task #352: dash leader (3+ 연속 '-') 시퀀스의 글자당 추가 간격 (px).
    /// PDF 와 같이 라인 슬랙을 dash leader 가 흡수하도록 하여, 공백 분배
    /// 부담을 줄이고 자연스러운 단어 간격을 유지한다. 0 이면 미적용.
    pub extra_dash_advance: f64,
    /// 외곽선 종류 (0=없음, 1~6=종류)
    pub outline_type: u8,
    /// 그림자 종류 (0=없음, 1=비연속, 2=연속)
    pub shadow_type: u8,
    /// 그림자 색
    pub shadow_color: ColorRef,
    /// 그림자 X 오프셋 (px)
    pub shadow_offset_x: f64,
    /// 그림자 Y 오프셋 (px)
    pub shadow_offset_y: f64,
    /// 양각
    pub emboss: bool,
    /// 음각
    pub engrave: bool,
    /// 위 첨자
    pub superscript: bool,
    /// 아래 첨자
    pub subscript: bool,
    /// 강조점 종류 (0=없음, 1~6)
    pub emphasis_dot: u8,
    /// 밑줄 모양 (표 27 선 종류, 0=실선 ~ 10=삼중선)
    pub underline_shape: u8,
    /// 취소선 모양 (표 27 선 종류, 0=실선 ~ 10=삼중선)
    pub strike_shape: u8,
    /// 밑줄 색상
    pub underline_color: ColorRef,
    /// 취소선 색상
    pub strike_color: ColorRef,
    /// 음영 색 (형광펜, 0xFFFFFF = 없음)
    pub shade_color: ColorRef,
    /// [#7092] 이 run 의 메트릭 표를 그 글꼴 자신의 폭으로 믿을 수 있는지
    /// (TTF 선언 · 대체 없음). 모르면 거짓 — 종전의 보수적 측정을 따른다.
    ///
    /// 측정 결정에만 쓴다 — 레이어 트리 직렬화 바이트를 보존하려고 직렬화에서 뺀다.
    #[serde(skip_serializing)]
    pub font_metric_trusted: bool,
    /// [#7391] 폭을 잴 때만 `font_family` 대신 쓸 face 이름.
    ///
    /// legacy-latin 폴백은 표시할 글꼴이 없는 환경을 위해 라틴 face 를 한글 face 로
    /// 보낸다(`AmeriGarmnd BT` → `HY견명조`). 표시로는 뜻이 있어도 폭은 범주가 다르다.
    /// rhwp 가 선언 face 자신의 표를 이미 가진 경우에만 그 이름이 들어오며, 근거는
    /// [`crate::renderer::style_resolver::ResolvedCharStyle::font_families_metric_face`] 에 있다.
    ///
    /// 측정 결정에만 쓴다 — 레이어 트리 직렬화 바이트를 보존하려고 직렬화에서 뺀다.
    #[serde(skip_serializing)]
    pub metric_font_family: Option<String>,
    /// [#7387] 명시적으로 확인한 공백 전진폭(em). 주로
    /// `CharShape.use_font_space`가 켜진 run의 **영문 슬롯** 글꼴 폭이며,
    /// 저장 문서의 독립 출력에서 다른 폭이 확인되면 프로필이 덮어쓸 수 있다.
    /// `None`이면 아래 일반 글꼴 측정 규칙을 따른다.
    ///
    /// 한/글은 이 속성이 켜지면 공백을 반각이 아니라 영문 슬롯 글꼴의 제 공백
    /// 글리프 전진폭으로 전진시킨다. `1382000_domestic_violence_survey` 정본
    /// (`Hwp 2018 11.0.0.1623`)의 같은 문서·같은 쪽 대조가 값을 말한다 —
    /// 미정렬 줄만 골라 charPr 에 붙여 재면:
    ///
    /// ```text
    ///   ufs=0  charPr 12  자간 0   n=37   0.500 em   (반각 그대로)
    ///   ufs=0  charPr 6·33 자간 -5 n=729  0.469 em   (0.5 x 0.95)
    ///   ufs=1  charPr 65·54·53·59  자간 0 n=763  0.337 em
    ///   ufs=1  charPr 24  자간 0   n=18   0.337 em
    ///   ufs=1  charPr 26  자간 0   n=38   0.489 em  <- 영문 슬롯이 휴먼명조
    /// ```
    ///
    /// 마지막 줄이 상수가 아님을 말한다: 같은 `ufs=1` 이라도 영문 슬롯이 대체 없이
    /// 쓰인 휴먼명조면 그 글꼴의 제 공백 0.5 em 이 나오고, Batang 으로 대체된
    /// 슬롯이면 0.333 em(341/1024)이 나온다.
    ///
    /// 측정 결정에만 쓴다 — 레이어 트리 직렬화 바이트를 보존하려고 직렬화에서 뺀다.
    #[serde(skip_serializing)]
    pub font_space_em: Option<f64>,
    /// 줄 구성에서 선택한 반각 공백 규칙. 원문의 useFontSpace와 구별한다.
    #[serde(skip_serializing)]
    pub layout_half_space: bool,
    /// [#7051] 이 run 의 글꼴이 **HFT 한글 전용 face** 라서 대체됐는지
    /// (`FontSubstitutionBoundary::Hft`). 그런 글꼴의 ASCII 는 한컴이 반각(`em/2`)으로
    /// 전진시키므로 대체 글꼴의 비례 폭을 그대로 쓰면 안 된다. 진짜 영문 HFT
    /// (`LegacyLatin` 경계 — HCI Poppy·BT 계열·영문 안상수체)는 여기 들어오지 않는다.
    ///
    /// 측정 결정에만 쓴다 — 레이어 트리 직렬화 바이트를 보존하려고 직렬화에서 뺀다.
    #[serde(skip_serializing)]
    pub hft_hangul_face: bool,
    /// 원본 한글 HFT 기호 슬롯의 전각 폭 보존 여부. ASCII 반각 판정과 별개다.
    #[serde(skip_serializing)]
    pub hft_fullwidth_dot: bool,
    /// [#7418] 이 run 이 한글 슬롯이고 글자 모양이 `ascii_punct_latin_slot` 이면, ASCII
    /// 구두점을 잴 때 쓸 **영문 슬롯**의 기본 메트릭. run 을 쪼개지 않고 글자 단위로 폭만
    /// 영문 슬롯으로 잰다(#7051 HFT 반각 ASCII 와 같은 자리). 양쪽 정렬 여분 등 배치가 얹는
    /// 값은 run 의 것을 그대로 쓴다.
    ///
    /// 측정 결정에만 쓴다 — 레이어 트리 직렬화 바이트를 보존하려고 직렬화에서 뺀다.
    #[serde(skip_serializing)]
    pub ascii_punct_latin: Option<Box<LatinSlotMetrics>>,
}

/// [#7418] 영문 슬롯의 기본 메트릭 — [`TextStyle::ascii_punct_latin`] 참조.
#[derive(Debug, Clone, PartialEq)]
pub struct LatinSlotMetrics {
    pub font_family: String,
    pub metric_font_family: Option<String>,
    pub font_metric_trusted: bool,
    pub letter_spacing: f64,
    pub ratio: f64,
}

/// 위첨자/아래첨자 글리프를 그릴 때 적용하는 본문 대비 글꼴 크기 배율.
pub const SCRIPT_FONT_SCALE: f64 = 0.7;
/// 위첨자 baseline 상향 이동량 (본문 글꼴 크기 대비 em).
pub const SUPERSCRIPT_RISE_EM: f64 = 0.3;
/// 아래첨자 baseline 하향 이동량 (본문 글꼴 크기 대비 em).
pub const SUBSCRIPT_DROP_EM: f64 = 0.15;

impl TextStyle {
    /// 위첨자/아래첨자 run 의 **그리기** 글꼴 크기와 baseline 을 계산한다.
    ///
    /// SVG·Canvas·HTML·Skia·paint JSON 이 각자 하드코딩하던 동일 상수를 한곳으로
    /// 모은 것이다 (#2771). 레이아웃 advance 는 본문 run 기준을 유지하고 실제
    /// 글리프 크기와 baseline 만 조정한다는 계약은 종전과 같다.
    ///
    /// HY신명조의 그리기 기준선은 한컴 PDF와 비교한 글꼴 메트릭 차이를 반영한다.
    pub fn script_draw_metrics(&self, base_font_size: f64, baseline_y: f64) -> (f64, f64) {
        // exam_kor 한컴 PDF 17쪽 T5와 동일 글자 79개의 가로 원점을 맞춰 대조하면
        // SVG의 HY신명조 기준선이 1.43~1.56px 낮다(글꼴 크기 약 15px).
        // 줄 상자와 전진폭은 유지하고 표시 기준선만 글꼴 크기의 0.1em 올린다.
        let primary_font = self
            .font_family
            .split(',')
            .next()
            .unwrap_or(&self.font_family)
            .trim()
            .trim_matches(['\'', '"']);
        let baseline_y = if primary_font == "HY신명조" {
            baseline_y - base_font_size * 0.1
        } else {
            baseline_y
        };
        if self.superscript {
            (
                base_font_size * SCRIPT_FONT_SCALE,
                baseline_y - base_font_size * SUPERSCRIPT_RISE_EM,
            )
        } else if self.subscript {
            (
                base_font_size * SCRIPT_FONT_SCALE,
                baseline_y + base_font_size * SUBSCRIPT_DROP_EM,
            )
        } else {
            (base_font_size, baseline_y)
        }
    }

    /// 글자폭 맞춤(fit) 대상 advance 에 적용할 배율 (#2771, #5756).
    ///
    /// SVG `textLength` 와 Canvas `fit_scale` 은 "레이아웃 advance 에 글리프 폭을
    /// 맞춘다". [#5756] 이후 첨자 run 의 **레이아웃 advance 자체**가 그리기
    /// 배율(0.7)로 측정되므로(`text_measurement::style_params`), 대상 advance 는
    /// 이미 축소 글리프의 자연 폭과 일치한다 — 여기서 또 줄이면 이중 축소로
    /// 글리프가 0.49 배까지 눌린다. 항상 1.0(항등)을 돌려준다.
    pub fn script_advance_scale(&self) -> f64 {
        1.0
    }

    /// 브라우저 렌더러가 실제 glyph 폭을 맞출 때 사용할 advance 를 반환한다.
    ///
    /// `extra_char_spacing` 의 양수 값은 배분/나눔 정렬에서 다음 cluster 의 시작
    /// 위치를 옮기는 간격이다. 이를 SVG `textLength` 또는 Canvas `scaleX`의 목표
    /// 폭에 포함하면 영문·숫자 glyph 자체가 가로로 늘어난다. 문자 위치 계산은
    /// 그대로 두고, glyph 맞춤 단계에서만 이 간격을 제외한다.
    ///
    /// 음수 값은 셀 오버플로우 보정(#2189)에서 glyph까지 layout advance에
    /// 맞추는 기존 계약이므로 그대로 유지한다. 최소 advance clamp 때문에
    /// intrinsic 폭을 안전하게 역산할 수도 없다. 따라서 양수 간격만 제외한다.
    pub(crate) fn glyph_fit_advance(&self, layout_cluster_advance: f64) -> Option<f64> {
        if !layout_cluster_advance.is_finite() || !self.extra_char_spacing.is_finite() {
            return None;
        }
        if self.extra_char_spacing > 0.0 {
            Some((layout_cluster_advance - self.extra_char_spacing).max(0.0))
        } else {
            Some(layout_cluster_advance)
        }
    }

    /// 시각적 bold 여부.
    ///
    /// CharShape.bold=true 외에도 HY헤드라인M 같은 heavy display face 를
    /// 사용할 때 true 를 반환. 해당 face 가 fallback 으로 대체될 때 발생하는
    /// 시각 bold 소실을 보완하기 위해 SVG 출력 시 font-weight="bold" 강제에
    /// 사용된다.
    pub fn is_visually_bold(&self) -> bool {
        self.bold
            || crate::renderer::style_resolver::is_heavy_display_face(&self.font_family)
            || crate::renderer::style_resolver::is_bold_weight_face(&self.font_family)
    }

    /// 중고딕 계열(font-weight 500) 여부. SVG/HTML 출력 시 `font-weight: 500` 힌트 삽입에 사용.
    pub fn is_medium_weight(&self) -> bool {
        !self.bold && crate::renderer::style_resolver::is_medium_weight_face(&self.font_family)
    }

    /// CSS/SVG font-weight hint for fallback rendering.
    pub fn css_font_weight(&self) -> Option<&'static str> {
        if self.is_visually_bold() {
            Some("bold")
        } else if crate::renderer::style_resolver::is_light_weight_face(&self.font_family) {
            Some("300")
        } else if self.is_medium_weight() {
            Some("500")
        } else {
            None
        }
    }
}

/// Canvas 폰트의 실측 폭을 레이아웃 advance에 맞출 때 적용할 배율을 계산한다.
///
/// 양수 문자 간격은 다음 cluster의 시작 위치를 바꾸는 값이므로 glyph 폭 맞춤과
/// 분리한다. 음수 간격은 #2189 셀 오버플로우 보정의 기존 glyph-fit 계약을
/// 유지하고, 양수 배분 간격만 `glyph_fit_advance`로 제외한다.
pub(crate) fn canvas_cluster_fit_scale(
    style: &TextStyle,
    layout_cluster_advance: f64,
    visual_width: f64,
    pin_ascii_advance: bool,
) -> Option<f64> {
    let cluster_advance =
        style.glyph_fit_advance(layout_cluster_advance)? * style.script_advance_scale();
    if cluster_advance <= 0.0 || visual_width <= 0.0 || style.letter_spacing < 0.0 {
        return None;
    }
    if pin_ascii_advance {
        return Some((cluster_advance / visual_width).clamp(0.1, 2.0));
    }
    if visual_width > cluster_advance + 0.25 {
        return Some((cluster_advance / visual_width).clamp(0.1, 1.0));
    }
    None
}

impl Default for TextStyle {
    fn default() -> Self {
        Self {
            supplemental_metrics: None,
            font_family: String::new(),
            font_size: 0.0,
            color: 0,
            bold: false,
            italic: false,
            underline: UnderlineType::None,
            strikethrough: false,
            kerning: false,
            letter_spacing: 0.0,
            ratio: 1.0,
            default_tab_width: 0.0,
            tab_stops: Vec::new(),
            auto_tab_right: false,
            available_width: 0.0,
            line_x_offset: 0.0,
            text_start_offset: 0.0,
            right_tab_block_width_override: None,
            tab_leaders: Vec::new(),
            inline_tabs: Vec::new(),
            extra_word_spacing: 0.0,
            extra_char_spacing: 0.0,
            extra_dash_advance: 0.0,
            outline_type: 0,
            shadow_type: 0,
            shadow_color: 0x00B2B2B2,
            shadow_offset_x: 0.0,
            shadow_offset_y: 0.0,
            emboss: false,
            engrave: false,
            superscript: false,
            subscript: false,
            emphasis_dot: 0,
            underline_shape: 0,
            strike_shape: 0,
            underline_color: 0,
            strike_color: 0,
            shade_color: 0x00FFFFFF,
            font_metric_trusted: false,
            metric_font_family: None,
            font_space_em: None,
            layout_half_space: false,
            hft_hangul_face: false,
            hft_fullwidth_dot: false,
            ascii_punct_latin: None,
        }
    }
}

/// 패턴 채우기 정보 (HWP pattern_type 1~6)
#[derive(Debug, Clone, Copy, Serialize)]
pub struct PatternFillInfo {
    /// 패턴 종류 (1=가로줄, 2=세로줄, 3=역대각선, 4=대각선, 5=십자, 6=격자)
    pub pattern_type: i32,
    /// 무늬색
    pub pattern_color: ColorRef,
    /// 배경색
    pub background_color: ColorRef,
}

/// 도형 렌더링 스타일
#[derive(Debug, Clone, Serialize)]
pub struct ShapeStyle {
    /// 채우기 색상 (None이면 채우기 없음)
    pub fill_color: Option<ColorRef>,
    /// 패턴 채우기 (pattern_type > 0일 때)
    pub pattern: Option<PatternFillInfo>,
    /// 테두리 색상
    pub stroke_color: Option<ColorRef>,
    /// 테두리 두께 (px)
    pub stroke_width: f64,
    /// 테두리 종류
    pub stroke_dash: StrokeDash,
    /// 투명도 (0.0=완전투명, 1.0=불투명)
    pub opacity: f64,
    /// 그림자 (None이면 그림자 없음)
    pub shadow: Option<ShadowStyle>,
}

/// 도형 그림자 스타일
#[derive(Debug, Clone, Serialize)]
pub struct ShadowStyle {
    /// 그림자 종류 (1~8)
    pub shadow_type: u32,
    /// 그림자 색상
    pub color: ColorRef,
    /// X 오프셋 (px)
    pub offset_x: f64,
    /// Y 오프셋 (px)
    pub offset_y: f64,
    /// 투명도 (0~255, 0=불투명)
    pub alpha: u8,
}

impl Default for ShapeStyle {
    fn default() -> Self {
        Self {
            fill_color: None,
            pattern: None,
            stroke_color: None,
            stroke_width: 0.0,
            stroke_dash: StrokeDash::default(),
            opacity: 1.0,
            shadow: None,
        }
    }
}

/// 그라데이션 채우기 렌더링 정보
#[derive(Debug, Clone, Serialize)]
pub struct GradientFillInfo {
    /// 유형 (1: 줄무늬/선형, 2: 원형, 3: 원뿔형, 4: 사각형)
    pub gradient_type: i16,
    /// 기울임 각도 (도)
    pub angle: i16,
    /// 가로 중심 (%)
    pub center_x: i16,
    /// 세로 중심 (%)
    pub center_y: i16,
    /// 색상 목록 (ColorRef)
    ///
    /// [`expand_gradient_steps`] 가 편 **띠 단위 stop** 이다 — 모델의 색 목록과 1:1 이
    /// 아니다. `positions` 와 길이가 같고, 같은 offset 이 두 번 나오면 하드 경계다.
    pub colors: Vec<ColorRef>,
    /// 색상 위치 (0.0~1.0 정규화)
    pub positions: Vec<f64>,
}

/// 두 색 사이를 채널별로 선형 보간한다.
fn lerp_color(from: ColorRef, to: ColorRef, t: f64) -> ColorRef {
    let t = t.clamp(0.0, 1.0);
    let mut out = 0u32;
    for shift in [0, 8, 16] {
        let a = ((from >> shift) & 0xff) as f64;
        let b = ((to >> shift) & 0xff) as f64;
        let v = (a + (b - a) * t).round().clamp(0.0, 255.0) as u32;
        out |= v << shift;
    }
    out
}

/// `(colors, positions)` 가 이루는 색 램프를 `t`(0~1) 에서 표집한다.
fn sample_ramp(colors: &[ColorRef], positions: &[f64], t: f64) -> ColorRef {
    match colors.len() {
        0 => 0,
        1 => colors[0],
        n => {
            let at = |i: usize| -> f64 {
                positions
                    .get(i)
                    .copied()
                    .unwrap_or(i as f64 / (n - 1) as f64)
            };
            let t = t.clamp(0.0, 1.0);
            for i in 1..n {
                let (p0, p1) = (at(i - 1), at(i));
                if t <= p1 || i == n - 1 {
                    let span = p1 - p0;
                    let local = if span.abs() < f64::EPSILON {
                        0.0
                    } else {
                        (t - p0) / span
                    };
                    return lerp_color(colors[i - 1], colors[i], local);
                }
            }
            colors[n - 1]
        }
    }
}

/// HWP 그러데이션의 `step`(띠 개수)·`step_center`(전이 위치 %)를 렌더 stop 목록으로 편다.
///
/// [#6822] 한/글은 그러데이션 축을 **`step` 개의 띠**로 잘라 각 띠를 단색으로 칠하고,
/// 띠 경계들의 가운데를 `step_center`% 지점에 놓는다. 렌더 IR 은 이 두 값을 담지 않아
/// 전이가 언제나 50% 에 고정됐다.
///
/// 실측(`samples/issue6551/113424_evaluation_guideline.hwpx`, 한/글 2024 정본):
///
/// ```text
///   step=2  stepCenter=8   장 제목 막대  초록→흰색 하드 경계가 축의 8% 지점
///   step=50 stepCenter=50  구분 막대     균등한 50개 띠 (사실상 매끄러운 램프)
/// ```
///
/// `step <= 1` 이거나 색이 둘 미만이면 띠를 만들지 않고 원본을 그대로 돌려준다 —
/// 값이 없는 문서의 현행 동작을 바꾸지 않기 위해서다.
pub fn expand_gradient_steps(
    colors: &[ColorRef],
    positions: &[f64],
    step: i16,
    step_center: u8,
) -> (Vec<ColorRef>, Vec<f64>) {
    let bands = step.max(0) as usize;
    if bands <= 1 || colors.len() < 2 {
        return (colors.to_vec(), positions.to_vec());
    }

    // 띠 경계는 균등 위치 `m` 을 두 구간 선형으로 옮겨 가운데(m=0.5)가 `c` 에 오게 한다.
    // `c == 0.5` 면 항등이므로 기본값 문서는 지금 그리는 것과 같은 균등 띠가 된다.
    let c = (step_center as f64 / 100.0).clamp(0.0, 1.0);
    let warp = |m: f64| -> f64 {
        if m <= 0.5 {
            2.0 * m * c
        } else {
            c + (m - 0.5) * 2.0 * (1.0 - c)
        }
    };

    let mut out_colors = Vec::with_capacity(bands * 2);
    let mut out_positions = Vec::with_capacity(bands * 2);
    for i in 0..bands {
        let color = sample_ramp(colors, positions, i as f64 / (bands - 1) as f64);
        let start = warp(i as f64 / bands as f64);
        let end = warp((i + 1) as f64 / bands as f64);
        out_colors.push(color);
        out_positions.push(start.clamp(0.0, 1.0));
        out_colors.push(color);
        out_positions.push(end.clamp(0.0, 1.0));
    }
    (out_colors, out_positions)
}

/// [#6845] HWP 그러데이션 각도를 **사용자 좌표계**의 축 양 끝점으로 옮긴다.
///
/// 종전 두 렌더러는 각도를 상자 정규화 공간에서 다뤄 **가로세로비만큼 축이 눕는** 결함이
/// 있었다 — SVG 는 `objectBoundingBox` 백분율을 그대로 냈고, canvas 는 방향을
/// `(sin·w/2, cos·h/2)` 로 축별 배율했다. 둘 다 정사각형 상자에서만 옳다.
///
/// ## 축 방향은 `(sin a, −cos a)` 다
///
/// 한/글 2024 정본(`pdf/113424_evaluation_guideline-2024.pdf`)에서 두 각도로 확정했다.
///
/// ```text
///   angle=0    5쪽 목차 막대 `#C8EDFF → #FFFFFF`
///              정본은 아래가 `#C8EDFF`, 위가 흰색 → 축은 **위쪽**       (0, −1)
///   angle=90   29쪽 구분 막대 `#000080 → #99CCFF`  → 축은 오른쪽        (1, 0)
///   angle=110  7쪽 장 제목 막대, 등색선 기울기 dx/dy = −0.365
///              → 축 (0.939, 0.343) = (sin 110°, −cos 110°)
/// ```
///
/// SVG·canvas 는 y 가 아래로 자라므로 `cos` 의 부호를 뒤집어야 한다. 종전 코드는 `+cos`
/// 라 `angle=0` 에서 위아래가 반대였다.
///
/// ## 끝점은 상자를 덮도록 잡는다
///
/// 상자를 축 방향으로 정사영한 길이의 절반이 `(|dx|·w + |dy|·h) / 2` 이므로, 중심에서
/// 그만큼 양쪽으로 벌리면 어떤 각도에서도 상자 전체가 램프 안에 들어온다.
pub fn linear_gradient_axis(angle: i16, x: f64, y: f64, w: f64, h: f64) -> (f64, f64, f64, f64) {
    let a = ((angle % 360 + 360) % 360) as f64;
    let rad = a.to_radians();
    let (dx, dy) = (rad.sin(), -rad.cos());
    let (cx, cy) = (x + w / 2.0, y + h / 2.0);
    let half = (dx.abs() * w + dy.abs() * h) / 2.0;
    (
        cx - dx * half,
        cy - dy * half,
        cx + dx * half,
        cy + dy * half,
    )
}

/// 선 렌더링 스타일
#[derive(Debug, Clone, Default, Serialize)]
pub struct LineStyle {
    /// 선 색상
    pub color: ColorRef,
    /// 선 두께 (px)
    pub width: f64,
    /// 선 종류
    pub dash: StrokeDash,
    /// 선 렌더링 종류 (이중선/삼중선 등)
    pub line_type: LineRenderType,
    /// 시작 화살표
    pub start_arrow: ArrowStyle,
    /// 끝 화살표
    pub end_arrow: ArrowStyle,
    /// 시작 화살표 크기 (HWP bits 22-25: 0=작은-작은 ~ 8=큰-큰)
    pub start_arrow_size: u8,
    /// 끝 화살표 크기 (HWP bits 26-29)
    pub end_arrow_size: u8,
    /// 그림자
    pub shadow: Option<ShadowStyle>,
}

/// 테두리 점선 종류
#[derive(Debug, Clone, Copy, Default, PartialEq, Serialize)]
pub enum StrokeDash {
    #[default]
    Solid,
    Dash,
    Dot,
    DashDot,
    DashDotDot,
}

/// 선 렌더링 종류 (이중선/삼중선)
#[derive(Debug, Clone, Copy, Default, PartialEq, Serialize)]
pub enum LineRenderType {
    #[default]
    Single,
    /// 이중선 (같은 굵기)
    Double,
    /// 가는선-굵은선 이중선
    ThinThickDouble,
    /// 굵은선-가는선 이중선
    ThickThinDouble,
    /// 가는선-굵은선-가는선 삼중선
    ThinThickThinTriple,
}

/// 화살표 스타일
#[derive(Debug, Clone, Copy, Default, PartialEq, Serialize)]
pub enum ArrowStyle {
    #[default]
    None,
    /// 화살 모양 (채움)
    Arrow,
    /// 오목한 화살 모양 (채움)
    ConcaveArrow,
    /// 속이 빈 다이아몬드
    OpenDiamond,
    /// 속이 빈 원
    OpenCircle,
    /// 속이 빈 사각
    OpenSquare,
    /// 속이 채운 다이아몬드
    Diamond,
    /// 속이 채운 원
    Circle,
    /// 속이 채운 사각
    Square,
}

/// 패스 커맨드 (벡터 도형용)
#[derive(Debug, Clone, Copy, Serialize)]
pub enum PathCommand {
    MoveTo(f64, f64),
    LineTo(f64, f64),
    CurveTo(f64, f64, f64, f64, f64, f64),
    /// SVG arc: (rx, ry, x_rotation, large_arc_flag, sweep_flag, x, y)
    ArcTo(f64, f64, f64, bool, bool, f64, f64),
    ClosePath,
}

/// SVG arc(endpoint parameterization)를 cubic bezier 곡선으로 변환
///
/// SVG spec: Implementation Notes - Arc Conversion
/// (x1, y1): 시작점, (x2, y2): 끝점, rx/ry: 반지름,
/// phi: x축 회전(도), large_arc/sweep: 플래그
pub fn svg_arc_to_beziers(
    x1: f64,
    y1: f64,
    mut rx: f64,
    mut ry: f64,
    phi_deg: f64,
    large_arc: bool,
    sweep: bool,
    x2: f64,
    y2: f64,
) -> Vec<PathCommand> {
    use std::f64::consts::PI;

    let mut result = Vec::new();

    // 퇴화 케이스: 시작점 == 끝점
    if (x1 - x2).abs() < 1e-6 && (y1 - y2).abs() < 1e-6 {
        return result;
    }
    // 퇴화 케이스: 반지름 0
    rx = rx.abs();
    ry = ry.abs();
    if rx < 1e-6 || ry < 1e-6 {
        result.push(PathCommand::LineTo(x2, y2));
        return result;
    }

    let phi = phi_deg.to_radians();
    let cos_phi = phi.cos();
    let sin_phi = phi.sin();

    // Step 1: (x1', y1') 계산
    let dx = (x1 - x2) / 2.0;
    let dy = (y1 - y2) / 2.0;
    let x1p = cos_phi * dx + sin_phi * dy;
    let y1p = -sin_phi * dx + cos_phi * dy;

    // Step 2: 반지름 보정 (너무 작은 경우 확대)
    let x1p2 = x1p * x1p;
    let y1p2 = y1p * y1p;
    let lambda = x1p2 / (rx * rx) + y1p2 / (ry * ry);
    if lambda > 1.0 {
        let s = lambda.sqrt();
        rx *= s;
        ry *= s;
    }
    let rx2 = rx * rx;
    let ry2 = ry * ry;

    // Step 3: 중심점' (cx', cy') 계산
    let num = (rx2 * ry2 - rx2 * y1p2 - ry2 * x1p2).max(0.0);
    let den = rx2 * y1p2 + ry2 * x1p2;
    let sq = if den > 1e-10 { (num / den).sqrt() } else { 0.0 };
    let sign = if large_arc == sweep { -1.0 } else { 1.0 };
    let cxp = sign * sq * rx * y1p / ry;
    let cyp = sign * sq * (-ry * x1p) / rx;

    // Step 4: 중심점 (cx, cy) 계산
    let cx = cos_phi * cxp - sin_phi * cyp + (x1 + x2) / 2.0;
    let cy = sin_phi * cxp + cos_phi * cyp + (y1 + y2) / 2.0;

    // Step 5: θ1 (시작 각도), dθ (호 각도) 계산
    let theta1 = ((y1p - cyp) / ry).atan2((x1p - cxp) / rx);
    let theta2 = ((-y1p - cyp) / ry).atan2((-x1p - cxp) / rx);
    let mut dtheta = theta2 - theta1;

    if !sweep && dtheta > 0.0 {
        dtheta -= 2.0 * PI;
    }
    if sweep && dtheta < 0.0 {
        dtheta += 2.0 * PI;
    }

    // 호를 최대 90° 세그먼트로 분할하여 bezier 근사
    let n_segs = (dtheta.abs() / (PI / 2.0 + 0.001)).ceil().max(1.0) as usize;
    let seg_angle = dtheta / n_segs as f64;

    for i in 0..n_segs {
        let t1 = theta1 + seg_angle * i as f64;
        let t2 = theta1 + seg_angle * (i + 1) as f64;

        // 호 세그먼트의 bezier 제어점 계산
        // alpha = 4/3 * tan(segment_angle / 4)
        let alpha = 4.0 / 3.0 * (seg_angle / 4.0).tan();

        let cos_t1 = t1.cos();
        let sin_t1 = t1.sin();
        let cos_t2 = t2.cos();
        let sin_t2 = t2.sin();

        // 단위 원 위의 제어점 (반지름 적용 전)
        let ep1x = cos_t1 - alpha * sin_t1;
        let ep1y = sin_t1 + alpha * cos_t1;
        let ep2x = cos_t2 + alpha * sin_t2;
        let ep2y = sin_t2 - alpha * cos_t2;

        // 반지름 적용
        let cp1x = rx * ep1x;
        let cp1y = ry * ep1y;
        let cp2x = rx * ep2x;
        let cp2y = ry * ep2y;
        let endx = rx * cos_t2;
        let endy = ry * sin_t2;

        // 회전(phi) + 이동(cx, cy) 적용
        result.push(PathCommand::CurveTo(
            cos_phi * cp1x - sin_phi * cp1y + cx,
            sin_phi * cp1x + cos_phi * cp1y + cy,
            cos_phi * cp2x - sin_phi * cp2y + cx,
            sin_phi * cp2x + cos_phi * cp2y + cy,
            cos_phi * endx - sin_phi * endy + cx,
            sin_phi * endx + cos_phi * endy + cy,
        ));
    }

    result
}

/// 한양 HFT 불릿의 원 윤곽을 대체 TTF의 작은 수학 점과 구분한다.
/// 한컴 PDF Type3 /HFT8: 중심 (500,352), 가로 반지름123.75, 세로123 /1000em.
/// 명시적으로 검증된 TrueType face와 다른 기호·글꼴은 원 글리프를 유지한다.
pub(crate) fn legacy_hft_bullet_geometry(
    text: &str,
    style: &TextStyle,
) -> Option<(f64, f64, f64, f64)> {
    let face = style.font_family.split(',').next().unwrap_or("").trim();
    if text != "∙"
        || style.font_metric_trusted
        || !matches!(face, "한양신명조" | "HanyangSinMyeongJo")
    {
        return None;
    }
    let size = style.font_size
        * if style.superscript || style.subscript {
            SCRIPT_FONT_SCALE
        } else {
            1.0
        };
    let ratio = if style.ratio > 0.0 { style.ratio } else { 1.0 };
    Some((
        size * ratio * 0.5,
        -size * 0.352,
        size * ratio * 0.12375,
        size * 0.123,
    ))
}

/// 렌더러 트레이트 (모든 백엔드가 구현)
pub trait Renderer {
    /// 페이지 렌더링 시작
    fn begin_page(&mut self, width: f64, height: f64);
    /// 페이지 렌더링 종료
    fn end_page(&mut self);

    /// 텍스트 그리기
    fn draw_text(&mut self, text: &str, x: f64, y: f64, style: &TextStyle);
    /// Layout owner가 확정한 run-relative 문자 경계값으로 텍스트를 그린다.
    ///
    /// K0와 positioned replay를 지원하지 않는 보조 renderer는 기존 `draw_text`를
    /// 그대로 쓴다. K1 visual backend만 이 메서드를 override하며 font lookup이나
    /// shaping을 다시 수행하지 않는다.
    fn draw_text_positioned(
        &mut self,
        text: &str,
        x: f64,
        y: f64,
        style: &TextStyle,
        _positions: Option<&[f64]>,
    ) {
        self.draw_text(text, x, y, style);
    }
    /// 사각형 그리기 (corner_radius > 0이면 둥근 모서리)
    fn draw_rect(&mut self, x: f64, y: f64, w: f64, h: f64, corner_radius: f64, style: &ShapeStyle);
    /// 선 그리기
    fn draw_line(&mut self, x1: f64, y1: f64, x2: f64, y2: f64, style: &LineStyle);
    /// 타원 그리기
    fn draw_ellipse(&mut self, cx: f64, cy: f64, rx: f64, ry: f64, style: &ShapeStyle);
    /// 이미지 그리기
    fn draw_image(&mut self, data: &[u8], x: f64, y: f64, w: f64, h: f64);
    /// 패스 그리기 (벡터 도형)
    fn draw_path(&mut self, commands: &[PathCommand], style: &ShapeStyle);
}

/// HWPUNIT → 픽셀 변환 (96 DPI 기준)
pub const DEFAULT_DPI: f64 = 96.0;
pub const HWPUNIT_PER_INCH: f64 = 7200.0;

/// LINE_SEG line_height가 줄의 최대 글자 크기보다 작으면
/// ParaShape의 줄간격 설정으로 재계산한다.
/// height_measurer와 layout 양쪽에서 동일 로직을 사용해야 한다.
#[inline]
pub fn corrected_line_height(
    raw_lh: f64,
    max_fs: f64,
    ls_type: LineSpacingType,
    ls_val: f64,
) -> f64 {
    if max_fs > 0.0 && raw_lh < max_fs {
        match ls_type {
            LineSpacingType::Percent => max_fs * ls_val / 100.0,
            LineSpacingType::Fixed => ls_val.max(max_fs),
            LineSpacingType::SpaceOnly => max_fs + ls_val,
            LineSpacingType::Minimum => ls_val.max(max_fs),
        }
    } else {
        raw_lh
    }
}

/// LINE_SEG의 line_height/line_spacing 의미를 보존하면서 폴백 line_height를 보정한다.
///
/// raw line_height가 글자 크기보다 작은 합성 줄은 한컴의
/// `(line_height=base, line_spacing=extra)` 모델에 맞춰 분해한다.
#[inline]
pub fn corrected_line_metrics(
    raw_lh: f64,
    raw_ls: f64,
    max_fs: f64,
    ls_type: LineSpacingType,
    ls_val: f64,
) -> (f64, f64) {
    if max_fs > 0.0 && raw_lh < max_fs {
        match ls_type {
            LineSpacingType::Percent => {
                // [#2279] sub-100% 퍼센트 음수 gap 존중 (line_breaking 정합)
                // 0% 는 실값이다 — line_breaking 과 같은 계약(>=)으로 맞춘다.
                let extra = if ls_val >= 0.0 {
                    max_fs * (ls_val - 100.0) / 100.0
                } else {
                    0.0
                };
                (max_fs, extra)
            }
            LineSpacingType::Fixed => (ls_val.max(max_fs), 0.0),
            LineSpacingType::SpaceOnly => (max_fs, ls_val.max(0.0)),
            LineSpacingType::Minimum => (ls_val.max(max_fs), 0.0),
        }
    } else {
        (raw_lh, raw_ls)
    }
}

/// 구역 첫 문단의 저장 줄 metrics를 재조판할 수 있는 구조인가.
///
/// `SectionDef`와 `ColumnDef`가 함께 들어 있는 문단은 본문 첫 줄을 선언하는
/// HWPX 구조다. task2093처럼 해당 첫 줄의 저장 좌표계 전체가 오래된 경우에만
/// 줄 높이와 baseline을 글꼴 기준으로 다시 계산한다. 일반 본문/미주 문단의 큰
/// 줄 높이는 의도된 조판일 수 있으므로 이 보정 대상이 아니다.
#[inline]
pub(crate) fn controls_mark_section_start(controls: &[Control]) -> bool {
    let mut has_section_def = false;
    let mut has_column_def = false;

    for control in controls {
        match control {
            Control::SectionDef(_) => has_section_def = true,
            Control::ColumnDef(_) => has_column_def = true,
            Control::Bookmark(_) => {}
            _ => return false,
        }
    }

    has_section_def && has_column_def
}

const STALE_SOURCE_LINE_ADVANCE_MULTIPLIER: f64 = 40.0;

/// 조합 줄의 최대 글꼴 크기를 구한다.
///
/// 문단 선두의 구역/단 정의처럼 가시 문자가 아닌 control이 UTF-16 stream offset을
/// 앞당기면, 조합 과정에서 줄 run의 글자 모양을 해소하지 못하는 문서가 있다. 이때도
/// 해당 줄 시작 위치의 `CharShapeRef`는 원본 문단에 남아 있으므로 이를 보조 근거로
/// 사용한다. run에서 얻은 유효한 크기가 있으면 그것을 항상 우선한다.
pub(crate) fn composed_line_max_font_size(
    line: &composer::ComposedLine,
    para: &crate::model::paragraph::Paragraph,
    styles: &style_resolver::ResolvedStyleSet,
) -> f64 {
    let run_max = line
        .runs
        .iter()
        .filter(|run| composed_run_reserves_font_height(run))
        .filter_map(|run| {
            styles
                .char_styles
                .get(run.char_style_id as usize)
                .map(|style| style.font_size)
        })
        .fold(0.0f64, f64::max);

    if run_max > 0.0 {
        return run_max;
    }

    // 개체 마커만 있는 줄은 개체/저장 줄 상자가 높이를 소유한다.
    // 빈 문단의 글꼴 폴백과 달리 U+FFFC 자체의 글자 크기를 예약하지 않는다.
    if !line.runs.is_empty()
        && line
            .runs
            .iter()
            .all(|run| !composed_run_reserves_font_height(run))
    {
        return 0.0;
    }

    para.char_shape_id_at(line.char_start)
        .or_else(|| para.char_shapes.first().map(|shape| shape.char_shape_id))
        .and_then(|shape_id| styles.char_styles.get(shape_id as usize))
        .map(|style| style.font_size)
        .unwrap_or(0.0)
}

/// 공백도 글꼴 줄 상자를 가지지만 개체 대체 문자와 제어 문자에는 가시 글꼴이 없다.
pub(crate) fn composed_run_reserves_font_height(run: &composer::ComposedTextRun) -> bool {
    run.text.chars().any(|c| c != '\u{FFFC}' && !c.is_control())
}

/// 유효 저장 빈 문단 하나만 가진 각주는 본문 없는 인라인 참조다.
/// 공백·개체·명시 번호와 무효/합성 줄은 기존 각주 본문 계약으로 남긴다.
pub(crate) fn stored_footnote_is_bodyless(footnote: &crate::model::footnote::Footnote) -> bool {
    let [paragraph] = footnote.paragraphs.as_slice() else {
        return false;
    };
    let [line] = paragraph.line_segs.as_slice() else {
        return false;
    };
    paragraph.text.is_empty()
        && paragraph.controls.is_empty()
        && line.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0
        && line.vertical_pos == 0
        && line.line_height > 0
        && line.segment_width > 0
}

/// 순수 텍스트 줄의 저장 metrics가 글자와 문단 스타일로부터 가능한 줄 advance보다
/// 현저히 크면 한컴처럼 재조판한다. 개체가 없는 줄에서 `line_height`와
/// `text_height`가 모두 비정상적으로 큰 값이면 저장 조판 정보가 현재 텍스트와 맞지
/// 않는다. 원본 IR은 보존하고 렌더/조판용 metrics만 바꾼다.
///
/// 40배는 10pt/160% 줄이 A4 본문 한 쪽에 가까운 높이를 단일 줄에 기록한 경우만
/// 잡는다. 이보다 작은 큰 줄은 하단 고정 틀의 fit 경계처럼 의도된 저장 조판일 수 있다.
#[inline]
pub(crate) fn source_line_metrics_need_reflow(
    raw_lh: f64,
    raw_text_height: f64,
    max_fs: f64,
    ls_type: LineSpacingType,
    ls_val: f64,
    source_metrics_reflow_eligible: bool,
) -> bool {
    if !source_metrics_reflow_eligible || max_fs <= 0.0 || raw_lh <= 0.0 || raw_text_height <= 0.0 {
        return false;
    }

    let (expected_lh, expected_ls) = corrected_line_metrics(0.0, 0.0, max_fs, ls_type, ls_val);
    let expected_advance = (expected_lh + expected_ls).max(max_fs);

    raw_lh > expected_advance * STALE_SOURCE_LINE_ADVANCE_MULTIPLIER
        && raw_text_height > expected_advance * STALE_SOURCE_LINE_ADVANCE_MULTIPLIER
}

/// 저장된 다음 줄 좌표를 현재 줄의 흐름 높이로 쓸 수 있으면 그 콘텐츠 높이를 반환한다.
///
/// `LINE_SEG.line_height`는 그림·표를 덮는 상자일 수 있지만, 한/글의 다음 줄 위치는
/// 저장 사다리(`next.vertical_pos - current.vertical_pos`)가 정한다. 다만 재조판된
/// 상자, 역행·동일 좌표, 글자 또는 글자처럼 취급되는 개체보다 작은 advance에는 저장
/// 좌표를 섞지 않는다. layout과 fallback measurement가 이 판별자를 공유한다.
#[inline]
pub(crate) fn stored_line_flow_height(
    current: &LineSeg,
    next: &LineSeg,
    rendered_line_height: f64,
    line_spacing: f64,
    flow_floor: f64,
    dpi: f64,
    source_metrics_reflowed: bool,
) -> Option<f64> {
    if source_metrics_reflowed
        || (hwpunit_to_px(current.line_height, dpi) - rendered_line_height).abs() >= 0.5
        || current.vertical_pos < 0
        || next.vertical_pos <= current.vertical_pos
    {
        return None;
    }

    let step = hwpunit_to_px(next.vertical_pos - current.vertical_pos, dpi) - line_spacing;
    (step > 0.0 && step < rendered_line_height && (flow_floor <= 0.0 || step + 0.5 >= flow_floor))
        .then_some(step)
}

/// [#5821] 압축 장평(ratio r < 1) 글자의 그리기 파라미터.
///
/// 한글 2022 는 장평을 가로만 줄이는 게 아니라 **세로도 √r 로** 줄인다 —
/// 156601658 제목 실측: 선언 25pt·ratio 90% → PDF `Tf 23.706` = 25×√0.90
/// (오차 0.05%), 총 폭은 선언×0.90 유지(한글 630.1px ↔ rhwp 634.0px).
/// 따라서 glyph 크기 = fs×√r, 가로 스케일 = √r (곱하면 폭 ×r 로 종전과 동일 —
/// advance/char_positions 는 불변). 확대(r > 1)는 실측이 없어 종전(크기 불변·
/// 가로 ×r) 유지.
#[inline]
pub(crate) fn condensed_ratio_draw_params(font_size: f64, ratio: f64) -> (f64, f64) {
    if ratio > 0.0 && ratio < 0.999 {
        let s = ratio.sqrt();
        (font_size * s, s)
    } else {
        (font_size, if ratio > 0.0 { ratio } else { 1.0 })
    }
}

/// 저장 줄 metrics를 재조판하는 경우의 baseline을 글꼴 기준으로 복원한다.
///
/// 원본 `baseline_distance`도 손상된 `line_height` 좌표계에 기록되므로, 줄 높이만
/// 낮추고 baseline을 그대로 두면 SVG/Canvas 텍스트가 페이지 하단으로 이탈한다.
#[inline]
pub(crate) fn corrected_line_baseline_for_source(
    raw_baseline: f64,
    max_fs: f64,
    source_metrics_reflowed: bool,
) -> f64 {
    if source_metrics_reflowed {
        max_fs * 0.85
    } else {
        raw_baseline
    }
}

/// 문단의 단일 저장 줄이 현재 글꼴/문단 스타일 기준으로 재조판 대상인지 판별한다.
///
/// 이 판정은 HWPX의 손상된 첫 줄이 이후 문단의 `vertical_pos`까지 크게 밀어 둔
/// 경우에만 사용한다. 원본 줄 배열은 바꾸지 않고, 페이지네이터와 렌더러가 같은
/// 조판 커서 보정 여부를 결정하는 데 쓴다.
pub(crate) fn paragraph_source_line_metrics_need_reflow(
    para: &crate::model::paragraph::Paragraph,
    styles: &style_resolver::ResolvedStyleSet,
    dpi: f64,
) -> bool {
    if !controls_mark_section_start(&para.controls)
        || !para
            .text
            .chars()
            .any(|ch| ch > '\u{001F}' && ch != '\u{FFFC}')
    {
        return false;
    }

    let [line] = para.line_segs.as_slice() else {
        return false;
    };
    let max_fs = para
        .char_shape_id_at(0)
        .or_else(|| para.char_shapes.first().map(|shape| shape.char_shape_id))
        .and_then(|shape_id| styles.char_styles.get(shape_id as usize))
        .map(|style| style.font_size)
        .unwrap_or(0.0);
    let (ls_type, ls_val) = styles
        .para_styles
        .get(para.para_shape_id as usize)
        .map(|style| (style.line_spacing_type, style.line_spacing))
        .unwrap_or((LineSpacingType::Percent, 160.0));

    source_line_metrics_need_reflow(
        hwpunit_to_px(line.line_height, dpi),
        hwpunit_to_px(line.text_height, dpi),
        max_fs,
        ls_type,
        ls_val,
        true,
    )
}

/// 구역의 저장 LINE_SEG 사다리가 "통짜 합성값"인지 판정한다 (#5854).
///
/// 한컴이 실제로 조판한 문서의 LINE_SEG 는 줄마다 그 줄의 글자 크기·줄간격을
/// 담고, 여러 줄로 접힌 문단은 줄 수만큼 세그먼트를 갖는다. 반면 일부 생성기는
/// 그 자리에 **문단 하나당 세그먼트 하나 · 전 문단 동일 튜플 · `vertical_pos` 는
/// 그 튜플의 advance 만큼 일정하게 증가**하는 사다리를 채워 넣는다. 그런 사다리는
/// 문서의 실제 글자 크기와 무관한 상수라서 조판 근거가 될 수 없다.
///
/// 실측 (`samples/hwpx/hwpx-02.hwpx`): 122 문단 전부
/// `vertsize=1000 textheight=1000 baseline=850 spacing=600`,
/// `vertpos` 는 처음부터 끝까지 정확히 1600 씩 증가한다. 그런데 문단들의 실제
/// 글자 크기는 2pt~15pt 로 갈려 82 문단이 저장 `vertsize`(10pt) 와 어긋난다.
///
/// 판정이 참이면 호출자는 (1) 줄 metrics 를 저장값이 아니라 글꼴·문단 스타일에서
/// 다시 뽑고, (2) `vertical_pos` 앵커 스냅을 끈다. 원본 IR 은 건드리지 않는다.
pub(crate) fn stored_line_ladder_is_uniform_filler(
    paragraphs: &[crate::model::paragraph::Paragraph],
    styles: &style_resolver::ResolvedStyleSet,
) -> bool {
    /// 사다리 하나로 단정하기 위한 최소 문단 수.
    const MIN_PARAGRAPHS: usize = 8;
    /// 저장 advance 와 글꼴 advance 가 어긋나야 하는 최소 비율의 역수 (1/4).
    const CONTRADICTION_RATIO_DIVISOR: usize = 4;

    if paragraphs.len() < MIN_PARAGRAPHS {
        return false;
    }

    let mut tuple: Option<(i32, i32, i32, i32)> = None;
    let mut prev_vpos: Option<i32> = None;
    let mut contradicting = 0usize;

    for para in paragraphs {
        let [seg] = para.line_segs.as_slice() else {
            return false;
        };
        if seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY != 0
            || seg.line_height <= 0
            || seg.text_height <= 0
        {
            return false;
        }
        let current = (
            seg.line_height,
            seg.text_height,
            seg.baseline_distance,
            seg.line_spacing,
        );
        match tuple {
            None => tuple = Some(current),
            Some(first) if first != current => return false,
            _ => {}
        }
        // 사다리 걸음은 그 튜플의 advance 와 같아야 한다 — 실측 조판이면 문단마다
        // 다른 값이 나온다.
        let step = seg.line_height.saturating_add(seg.line_spacing);
        if let Some(previous) = prev_vpos {
            if seg.vertical_pos.saturating_sub(previous) != step {
                return false;
            }
        }
        prev_vpos = Some(seg.vertical_pos);

        let max_fs = para
            .char_shapes
            .iter()
            .filter_map(|shape| styles.char_styles.get(shape.char_shape_id as usize))
            .map(|style| style.font_size)
            .fold(0.0f64, f64::max);
        if max_fs <= 0.0 {
            continue;
        }
        let (ls_type, ls_val) = styles
            .para_styles
            .get(para.para_shape_id as usize)
            .map(|style| (style.line_spacing_type, style.line_spacing))
            .unwrap_or((LineSpacingType::Percent, 160.0));
        let (font_lh, font_ls) = corrected_line_metrics(0.0, 0.0, max_fs, ls_type, ls_val);
        let stored_advance = hwpunit_to_px(step, DEFAULT_DPI);
        if (font_lh + font_ls - stored_advance).abs() > 0.5 {
            contradicting += 1;
        }
    }

    contradicting * CONTRADICTION_RATIO_DIVISOR >= paragraphs.len()
}

/// 저장된 순수 텍스트 줄은 `vertsize`에 내부 여백이 포함되어도 한컴의 줄 진행이
/// `textheight + spacing`에 맞춰지는 사례가 있다. IR 값은 보존하고 렌더/조판용
/// line height만 낮춘다.
#[inline]
pub fn corrected_line_metrics_for_source(
    raw_lh: f64,
    raw_text_height: f64,
    raw_ls: f64,
    max_fs: f64,
    ls_type: LineSpacingType,
    ls_val: f64,
    use_stored_text_height: bool,
    source_metrics_reflow_eligible: bool,
) -> (f64, f64) {
    if source_line_metrics_need_reflow(
        raw_lh,
        raw_text_height,
        max_fs,
        ls_type,
        ls_val,
        source_metrics_reflow_eligible,
    ) {
        return corrected_line_metrics(0.0, 0.0, max_fs, ls_type, ls_val);
    }

    let (lh, ls) = corrected_line_metrics(raw_lh, raw_ls, max_fs, ls_type, ls_val);
    if use_stored_text_height
        && raw_text_height > 0.0
        && raw_text_height < lh
        && (max_fs <= 0.0 || raw_text_height + 0.5 >= max_fs * 0.8)
    {
        (raw_text_height, ls)
    } else {
        (lh, ls)
    }
}

/// HWP3-origin HWP5 conversions may omit PARA_LINE_SEG for body paragraphs.
/// The composer then emits synthetic lines with a tiny raw line height. For
/// those synthetic lines, applying ParaShape's percent line spacing again makes
/// the paragraph too tall compared with Hancom's converted layout.
#[inline]
pub fn corrected_line_height_for_variant_synthetic(
    raw_lh: f64,
    max_fs: f64,
    ls_type: LineSpacingType,
    ls_val: f64,
    hwp3_variant_synthetic: bool,
) -> f64 {
    if hwp3_variant_synthetic && max_fs > 0.0 && raw_lh < max_fs {
        max_fs
    } else {
        corrected_line_height(raw_lh, max_fs, ls_type, ls_val)
    }
}

/// [Task #1116] HWP3-origin HWP5 변환본의 문단 앞 간격 보정.
///
/// 기존 style resolver는 변환본의 ParaShape spacing 계열을 절반으로 줄인다.
/// 이는 페이지 수 회귀를 막기 위해 유지하되, 본문 흐름에서 다음 문단을
/// 배치할 때 쓰는 `spacing_before`는 한컴 PDF의 3mm 격자와 같이 원래 값을 쓴다.
#[inline]
pub(crate) fn hwp3_variant_flow_spacing_before(base: f64, is_hwp3_variant: bool) -> f64 {
    if is_hwp3_variant {
        base * 2.0
    } else {
        base
    }
}

/// [#6630] 셀 첫 문단의 위 여백(px) — 저장 첫 줄 `LINE_SEG.vertical_pos` 를 상한으로 둔 값.
///
/// 한/글은 셀 맨 위 문단의 "문단 위 여백"을 저장 vpos 만큼 둔다 (exam_eng 바탕쪽 머리 표:
/// 위 여백 1136HU 인데 vpos=568HU=7.57px, 그림이 그만큼 아래·셀 내용 높이도 그만큼 큼).
/// 본문 column-top 문단의 증거 기반 클램프(#853·#1811)와 같은 규칙을 셀 첫 문단에 쓴다.
/// 내용 높이 측정(`calc_para_lines_height`·`height_measurer`)과 셀 배치가 같은 값을 써야
/// 세로 정렬이 어긋나지 않는다. 저장 줄이 없거나 vpos ≤ 0 이면 0 (종전과 같다).
pub(crate) fn cell_first_para_stored_lead(
    para: &crate::model::paragraph::Paragraph,
    spacing_before_px: f64,
    dpi: f64,
) -> f64 {
    if spacing_before_px <= 0.0 {
        return 0.0;
    }
    let vpos = para
        .line_segs
        .first()
        .map(|ls| hwpunit_to_px(ls.vertical_pos, dpi))
        .unwrap_or(0.0);
    if vpos <= 0.0 {
        return 0.0;
    }
    spacing_before_px.min(vpos)
}

/// Stored cell starts already express their lead in the saved frame. Reflow
/// starts have no such frame and own the paragraph's declared before-space.
/// Later paragraphs own that space in both paths.
pub(crate) fn cell_paragraph_spacing_before(
    para: &crate::model::paragraph::Paragraph,
    para_index: usize,
    spacing_before: f64,
) -> f64 {
    if para_index > 0 || para_has_no_stored_line_segs(para) {
        spacing_before
    } else {
        0.0
    }
}

/// [#2169] 저장 LINE_SEG 부재 판별 — 원본 NO_LS 와 자기-export HWPX 재파싱본
/// (전부 synthetic, tag 0x8000_0000)을 동일 취급해 왕복 시멘틱을 정합한다
/// (#1770 계열: 국소 문맥 판별).
#[inline]
pub(crate) fn para_has_no_stored_line_segs(p: &crate::model::paragraph::Paragraph) -> bool {
    p.line_segs.is_empty() || p.line_segs.iter().all(|s| s.tag & 0x8000_0000 != 0)
}

/// These controls do not replace the empty host paragraph's own text line.
/// Square tables have a separate exclusion/flow owner and are not included.
pub(crate) fn empty_host_controls_are_flow_neutral(
    para: &crate::model::paragraph::Paragraph,
) -> bool {
    use crate::model::{control::Control, shape::TextWrap};
    para.controls.iter().all(|control| {
        let common = match control {
            Control::Picture(picture) => &picture.common,
            Control::Shape(shape) => shape.common(),
            Control::Table(table) => {
                return !table.common.treat_as_char
                    && matches!(
                        table.common.text_wrap,
                        TextWrap::InFrontOfText | TextWrap::BehindText
                    );
            }
            marker => return composer::control_is_width_neutral_marker(marker),
        };
        !common.treat_as_char
            && matches!(
                common.text_wrap,
                TextWrap::InFrontOfText | TextWrap::BehindText | TextWrap::Square
            )
    })
}

/// 합성 Square 구간은 시작 위치까지의 왼쪽 여백을 이미 차지한다.
/// 이를 본문 상자의 폭으로 환산해 측정과 배치가 같은 프레임을 사용하게 하며,
/// 글꼴별 임의 허용 폭은 더하지 않는다.
pub(crate) fn synthetic_wrap_column_width(
    column_width: f64,
    margin_left: f64,
    anchor: Option<&pagination::WrapAnchorRef>,
    dpi: f64,
) -> f64 {
    let Some(anchor) = anchor.filter(|a| a.band_y_range.is_none() && a.anchor_sw > 0) else {
        return column_width;
    };
    let start = hwpunit_to_px(anchor.anchor_cs + anchor.anchor_image_margin_right, dpi);
    let width = hwpunit_to_px(
        (anchor.anchor_sw - anchor.anchor_image_margin_right).max(0),
        dpi,
    );
    column_width.min(width + margin_left.min(start))
}

/// 셀 문단의 저장 `LINE_SEG.vertical_pos` 를 절대 앵커로 신뢰할 수 있는지 판정한다.
///
/// `vertical_pos == 0` 은 "셀 상단"이라는 유효한 값이면서 동시에 "앵커 없음"의
/// 센티널이기도 하다. 첫 문단은 0 이 곧 셀 상단이라 그대로 신뢰하고, 두 번째 이후
/// 문단은 양수 vpos 가 저장돼 있을 때만 앵커로 쓴다.
#[inline]
pub(crate) fn first_seg_vpos_is_anchor(
    para: &crate::model::paragraph::Paragraph,
    cell_para_index: usize,
) -> bool {
    para.line_segs
        .first()
        .is_some_and(|seg| cell_para_index == 0 || seg.vertical_pos > 0)
}

/// 글자처럼 취급되는(`treat_as_char`) 그림·도형이 줄 흐름에서 차지하는 높이(px).
///
/// 조판(`typeset`)과 렌더(`layout`)가 각자 이 식을 들고 있었고, 도형 쪽 정의가
/// 서로 달랐다 — 렌더는 [`ShapeObject::flow_height_hu`], 조판은 저장 프레임만.
/// 같은 속성의 정의는 하나여야 하므로(#4333) 두 경로가 이 함수를 공유한다.
#[inline]
pub(crate) fn tac_object_flow_height_px(
    ctrl: &crate::model::control::Control,
    dpi: f64,
) -> Option<f64> {
    tac_object_flow_height_hu(ctrl).map(|height_hu| hwpunit_to_px(height_hu, dpi))
}

/// [`tac_object_flow_height_px`] 와 같은 값의 HWPUNIT 판. 저장 `LineSeg.line_height`
/// 와 직접 견주는 자리는 dpi 를 거치지 않아야 반올림 없이 같은 줄을 짚는다.
#[inline]
pub(crate) fn tac_object_flow_height_hu(ctrl: &crate::model::control::Control) -> Option<i32> {
    use crate::model::control::Control;
    match ctrl {
        Control::Picture(pic) if pic.common.treat_as_char => Some(pic.common.height as i32),
        Control::Shape(shape) if shape.common().treat_as_char => Some(shape.flow_height_hu()),
        _ => None,
    }
}

/// 저장 줄 높이가 문단의 인라인 개체 하나로 설명될 때, 그 개체의 흐름 높이(px).
///
/// "이 줄은 인라인 개체가 소유한 줄인가" 를 묻는 술어다. 조판과 렌더가 같은 줄에
/// 같은 답을 내지 않으면 그 줄의 예약 높이가 갈리므로(#4333) 정의는 하나다.
pub(crate) fn line_owning_tac_object_height_px(
    para: &crate::model::paragraph::Paragraph,
    raw_line_height: f64,
    dpi: f64,
) -> Option<f64> {
    para.controls
        .iter()
        .filter_map(|ctrl| tac_object_flow_height_px(ctrl, dpi))
        .find(|height| {
            *height > 8.0 && raw_line_height + 4.0 >= *height && raw_line_height <= *height + 8.0
        })
}

fn para_text_is_picture_only_host(para: &crate::model::paragraph::Paragraph) -> bool {
    para.text.chars().all(|ch| {
        ch.is_whitespace()
            || ch == '\u{FFFC}'
            || ch <= '\u{001F}'
            || ('\u{E000}'..='\u{F8FF}').contains(&ch)
    })
}

/// 쪽 분할 칸의 그림-only 문단에서, 합성 줄이 담은 TAC 그림의 흐름 높이.
///
/// 저장 LINE_SEG 가 글줄만 담아도 그 줄의 TAC 그림은 자기 높이만큼 칸 조각
/// 회계에 들어가야 한다 (#6114: 312px 차트가 26px 만 전진해 아래 표가 겹침).
/// 본문과 섞인 줄에는 쓰지 않는다 — 일반 칸 글줄까지 그림 높이로 키우면
/// 칸 상자 밖으로 글이 밀려 text-overlap 이 는다.
pub(crate) fn composed_line_tac_object_height_px(
    para: &crate::model::paragraph::Paragraph,
    composed: &composer::ComposedParagraph,
    line_idx: usize,
    dpi: f64,
) -> Option<f64> {
    if !para_text_is_picture_only_host(para) {
        return None;
    }
    let line = composed.lines.get(line_idx)?;
    let start = line.char_start;
    let end = composed
        .lines
        .get(line_idx + 1)
        .map(|next| next.char_start)
        .unwrap_or_else(|| para.text.chars().count().saturating_add(1))
        .max(start.saturating_add(1));

    let mut max_h = 0.0f64;
    for &(pos, _, ci) in &composed.tac_controls {
        if pos < start || pos >= end {
            continue;
        }
        if let Some(height) = para
            .controls
            .get(ci)
            .and_then(|ctrl| tac_object_flow_height_px(ctrl, dpi))
        {
            max_h = max_h.max(height);
        }
    }

    if max_h <= 0.5 && para_text_is_picture_only_host(para) {
        let heights: Vec<f64> = para
            .controls
            .iter()
            .filter_map(|ctrl| tac_object_flow_height_px(ctrl, dpi))
            .filter(|height| *height > 0.5)
            .collect();
        if heights.len() == 1 && line_idx == 0 {
            max_h = heights[0];
        } else if heights.len() > 1
            && line_idx < heights.len()
            && composed.lines.len() == heights.len()
        {
            max_h = heights[line_idx];
        } else if line_idx == 0 && composed.lines.len() <= 1 {
            max_h = heights.into_iter().fold(0.0, f64::max);
        }
    }

    (max_h > 0.5).then_some(max_h)
}

/// 셀의 저장 vpos 흐름이 문단 위치를 구분해 담고 있는지 ("사다리" 온전성).
///
/// 셀 안 문단이 전부 `vpos == 0` 으로 저장된 문서(중첩 표 안쪽 셀에서 흔하다)에서는
/// 저장 흐름이 문단 위치를 구분하지 못한다. 이 경우 다음 세 가지가 모두 성립하지
/// 않으므로 저장 지오메트리를 신뢰해선 안 된다.
///
/// - 문단별 절대 배치 — 전 문단이 셀 상단 한 y 로 리셋된다
/// - `max(vpos + lh)` 기반 셀 높이 — 1문단분으로 붕괴한다
/// - `para_top + 중첩표 높이` 의 max 합성 — 텍스트와 중첩 표가 서로를 가린다
#[inline]
pub(crate) fn cell_vpos_ladder_is_intact(
    paragraphs: &[crate::model::paragraph::Paragraph],
) -> bool {
    paragraphs.iter().enumerate().all(|(idx, para)| {
        // 0 위치 자체는 유효하다. 텍스트가 전진하는 연속 줄의 위치가 모두 0이고
        // 같은 줄의 가로 조각이나 page/column 전환이 아닐 때만 앵커 부재로 본다.
        // 같은 text_start의 중복과 양수 위치에서 0으로 돌아오는 저장 리셋은 보존한다.
        first_seg_vpos_is_anchor(para, idx)
            && !para.line_segs.windows(2).enumerate().any(|(i, pair)| {
                let (prev, seg) = (&pair[0], &pair[1]);
                prev.vertical_pos == 0
                    && seg.vertical_pos == 0
                    && seg.text_start > prev.text_start
                    && !seg.is_first_line_of_page()
                    && !seg.is_first_line_of_column()
                    && !height_measurer::stored_seg_is_row_fragment(para, i + 1)
            })
    })
}

/// [#6923] 이 칸의 저장 사다리가 **줄 상자를 계통적으로 겹쳐** 적었는가.
///
/// 줄 전진(`다음 vpos − 이 vpos`)이 줄 높이보다 작은 걸음이 셋 이상이면 그 사다리의
/// 서명이다(한두 건은 우연). `line_spacing` 이 음수인 옛 문서에서 나온다 —
/// `148738070` 1쪽 감싼 칸: `p2 vpos 9800 lh 1400 ls −560 → p3 vpos 10640`.
pub(crate) fn cell_uses_overlapping_line_boxes(
    paragraphs: &[crate::model::paragraph::Paragraph],
) -> bool {
    let segs: Vec<&crate::model::paragraph::LineSeg> = paragraphs
        .iter()
        .flat_map(|para| para.line_segs.iter())
        .filter(|seg| seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0)
        .collect();
    segs.windows(2)
        .filter(|w| {
            let prev_end = w[0].vertical_pos.saturating_add(w[0].line_height);
            w[1].vertical_pos >= w[0].vertical_pos && w[1].vertical_pos < prev_end
        })
        .count()
        >= 3
}

/// [#6923] 겹침 걸음 사다리에서 **빈 줄 문단이 실제로 점유하는 전진(HWPUNIT)**.
///
/// 저장 사다리가 이 줄의 점유를 직접 말한다 — 다음 문단의 저장 `vpos` 까지의 거리다.
/// 겹침 사다리에서는 줄 높이(`lh`)가 점유가 아니다. 접어서 0 으로 두면 뒤따르는 내용이
/// 그만큼 위로 올라가고(`148738070` 1쪽 중첩 표 −15.9px), 반대로 `lh` 를 쓰면 아래로
/// 내려간다. 측정(`cell_units`)과 배치(`layout_horizontal_cell_paragraphs`)가 이 한
/// 결과를 함께 소비한다.
///
/// 전진이 줄 높이를 넘으면 겹침 걸음이 아니라 평범한 줄이므로 기존 보존 경로가 판정한다.
/// 되감김(전진 ≤ 0)도 이 규칙의 대상이 아니다.
pub(crate) fn stored_overlap_spacer_advance_hu(
    paragraphs: &[crate::model::paragraph::Paragraph],
    para_idx: usize,
) -> Option<i32> {
    let synthetic = |seg: &crate::model::paragraph::LineSeg| {
        seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY != 0
    };
    let para = paragraphs.get(para_idx)?;
    if !para.text.trim().is_empty() || !para.controls.is_empty() {
        return None;
    }
    let seg = match para.line_segs.as_slice() {
        [seg] if !synthetic(seg) && seg.line_height > 0 => seg,
        _ => return None,
    };
    let next = paragraphs.get(para_idx + 1)?.line_segs.first()?;
    if synthetic(next) {
        return None;
    }
    let forward = i64::from(next.vertical_pos) - i64::from(seg.vertical_pos);
    (forward > 0 && forward <= i64::from(seg.line_height)).then_some(forward as i32)
}

/// [#2287] 저장 LINE_SEG 없는 빈 anchor 문단의 TAC(글자처럼) 그림/도형 플로우
/// 줄 메트릭 합성. 컨트롤 폭을 가용 폭에 greedy wrap 하여 줄별
/// (최대 높이, leading) 을 돌려준다.
///
/// 한글은 글자처럼 개체를 줄박스로 취급해 그림 높이만큼 본문 흐름을 전진시키나,
/// rhwp 는 composed lines 가 비면(빈 텍스트 + 컨트롤) 문단 높이가 0 으로 붕괴해
/// 차트/스캔 그림 수십 장이 한 쪽에 응축된다 (미래부 정서분석 88 vs 한글 129쪽,
/// 농촌 S-OJT 꼬리 26쪽 응축 — 10k 서베이 r14 대형 음수 델타 지배 성분).
/// 호출부는 pairs 가 빈 경우(합성 폴백 실패 후)에만 사용한다.
///
/// [#7079] 두 번째 값(leading)은 **개체 높이가 아니라 호스트 문단의 글자모양·줄간격**에서
/// 나온다 — `tac_object_stack_line_leading_px` 를 본다. 문단 전진은 `높이 + leading` 이며,
/// 개체 잉크 위치는 유지하고 leading 을 줄 **뒤** 간격으로 소비한다. 렌더·측정·조판은
/// 같은 높이와 간격의 합으로 다음 줄을 전진시킨다.
pub(crate) fn tac_object_stack_line_metrics(
    para: &crate::model::paragraph::Paragraph,
    dpi: f64,
    available_width_px: Option<f64>,
    styles: &crate::renderer::style_resolver::ResolvedStyleSet,
    para_style: Option<&crate::renderer::style_resolver::ResolvedParaStyle>,
) -> Option<Vec<(f64, f64)>> {
    use crate::model::control::Control;
    if !para_has_no_stored_line_segs(para) {
        return None;
    }
    let objs: Vec<(f64, f64)> = para
        .controls
        .iter()
        .filter_map(|c| {
            let common = match c {
                Control::Picture(pic) if pic.common.treat_as_char => &pic.common,
                Control::Shape(s) if s.common().treat_as_char => s.common(),
                _ => return None,
            };
            let w = hwpunit_to_px(common.width as i32, dpi);
            let h = hwpunit_to_px(common.height as i32, dpi);
            (h > 0.5).then_some((w, h))
        })
        .collect();
    if objs.is_empty() {
        return None;
    }
    let leading = tac_object_stack_line_leading_px(para, styles, para_style);
    let avail = available_width_px.unwrap_or(f64::INFINITY).max(1.0);
    let mut lines: Vec<(f64, f64)> = Vec::new();
    let mut line_w = 0.0f64;
    let mut line_h = 0.0f64;
    for (w, h) in objs {
        if line_w > 0.0 && line_w + w > avail + 0.5 {
            lines.push((line_h, leading));
            line_w = 0.0;
            line_h = 0.0;
        }
        line_w += w;
        line_h = line_h.max(h);
    }
    if line_h > 0.0 {
        lines.push((line_h, leading));
    }
    (!lines.is_empty()).then_some(lines)
}

/// [#7418] 저장 줄 없는 문단의 글자처럼 취급 **표** 줄 — `(표 높이, 줄 뒤 leading)`.
///
/// 조성기는 글자 없이 표 하나만 든 문단에 줄을 만들지 않는다. 표 높이는 표 배치
/// (`place_table_with_text` 의 `table_total_height`, 바깥 여백 포함)가 따로 계상하지만, 그 줄의
/// **줄간격**은 문단 형식 높이에만 실리므로 줄이 없으면 통째로 빠졌다. 한/글 2024 합성 문서
/// (`samples/issue7418/tac_host_line_synthetic`, 글자 10·17pt × 줄간격 100·160·200% × 표 높이
/// 1716·3014)의 저장 줄은 12조합 모두 `vertsize = 표 높이 + 바깥 여백`,
/// `spacing = 글자 크기 × (줄간격 − 100%)` 이다 — 그림·도형 줄(`#7079`)과 같은 leading 이다.
/// 높이는 바깥 여백을 뺀 표 높이다(여백은 `tac_outer_margin_v_px` 가 예산에 더한다).
pub(crate) fn tac_table_host_line_metrics(
    para: &crate::model::paragraph::Paragraph,
    dpi: f64,
    styles: &crate::renderer::style_resolver::ResolvedStyleSet,
    para_style: Option<&crate::renderer::style_resolver::ResolvedParaStyle>,
) -> Option<(f64, f64)> {
    use crate::model::control::Control;
    if !para_has_no_stored_line_segs(para) || !para.text.is_empty() {
        return None;
    }
    let height = para
        .controls
        .iter()
        .filter_map(|c| match c {
            Control::Table(t) if t.common.treat_as_char => {
                Some(hwpunit_to_px(t.common.height as i32, dpi))
            }
            _ => None,
        })
        .fold(None, |acc: Option<f64>, h| {
            Some(acc.map_or(h, |a| a.max(h)))
        })?;
    Some((
        height,
        tac_object_stack_line_leading_px(para, styles, para_style),
    ))
}

/// [#7079] 합성 TAC 줄의 leading — 호스트 문단의 글자 크기와 문단 줄간격에서 나온다.
///
/// 저장 사다리 둘이 그 값을 못박는다. 156060125 2쪽은 `p[11] vpos=30525 lh=600 ls=0`
/// 다음 `p[13] vpos=61874` 라 그림 문단이 30749HU 를 차지하는데 그림은 29997HU 다 —
/// 남는 752HU 는 글자 20.0px · 150% 의 `20.0 * 0.5 = 10.0px(750HU)` 다. 156596828
/// 1쪽은 남는 값이 720HU 이고 글자 16.0px · 160% → `16.0 * 0.6 = 9.6px(720HU)` 로
/// 정확히 같다. 개체 높이는 29997 vs 2023 으로 14배 다른데 이 몫은 글자에서만 나온다.
///
/// 그 몫의 위치는 같은 96dpi 래스터에서 비교한다. 156060125 2쪽 한컴 engine 2020
/// 출력은 앞 본문줄→도해 잉크 84px, 도해→뒤 상자 360px 이다. leading 을 개체 뒤에
/// 두면 86px/360px, 앞에 두면 96px/350px 이므로 개체 잉크는 그대로 두고 뒤 간격에
/// 반영한다. 서로 다른 glyph bbox·TextLine 좌표를 섞은 초기 실측은 사용하지 않는다.
///
/// 빈 문단 폴백(`empty_no_lineseg_paragraph_metrics`)과 같은 `corrected_line_metrics`
/// 계약을 쓰되 줄 높이는 개체가 정하므로 간격 몫만 취한다. 글자모양·문단모양을 못 찾거나
/// Percent 가 아닌 종류(그 계약에서 간격이 0 이거나 줄 높이에 흡수된다)는 0 이다.
pub(crate) fn tac_object_stack_line_leading_px(
    para: &crate::model::paragraph::Paragraph,
    styles: &crate::renderer::style_resolver::ResolvedStyleSet,
    para_style: Option<&crate::renderer::style_resolver::ResolvedParaStyle>,
) -> f64 {
    // 합성 tag(`0x8000_0000`) seg 라도 **저장된 seg 가 있으면** 그 줄의 높이·baseline 이
    // 개체 배치의 근거다 — 거기에 leading 을 얹으면 baseline 정렬 위로 개체가 밀린다
    // (#6708 tac-img-02: 글자 264px → 158px 이동). leading 은 seg 가 아예 없어 줄을
    // 통째로 합성한 문단에서만 나온다. `#2287` 의 높이 합성 범위는 그대로 둔다.
    if !para.line_segs.is_empty() {
        return 0.0;
    }
    let Some(char_shape_id) = para
        .char_shape_id_at(0)
        .or_else(|| para.char_shapes.first().map(|shape| shape.char_shape_id))
    else {
        return 0.0;
    };
    let Some(char_style) = styles.char_styles.get(char_shape_id as usize) else {
        return 0.0;
    };
    let font_size = char_style.font_size;
    if font_size <= 0.0 {
        return 0.0;
    }
    let Some(style) = para_style else {
        return 0.0;
    };
    corrected_line_metrics(
        0.0,
        0.0,
        font_size,
        style.line_spacing_type,
        style.line_spacing,
    )
    .1
}

/// HWPUNIT을 픽셀로 변환
#[inline]
pub fn hwpunit_to_px(hwpunit: i32, dpi: f64) -> f64 {
    hwpunit as f64 * dpi / HWPUNIT_PER_INCH
}

/// 다단 뒤의 단일 단 제목은 저장 한 줄 여백을 온전히 보존한다.
/// 다른 단 전환은 기존 1200HU 간격을 따른다.
pub(crate) fn solo_zone_pad_px(entering_solo: bool, prior_multicol: bool, dpi: f64) -> f64 {
    hwpunit_to_px(
        if entering_solo && prior_multicol {
            1500
        } else {
            1200
        },
        dpi,
    )
}

/// 명시 단나누기가 다단에서 다음 다단 밴드를 시작할 때 저장 한 줄 간격.
pub(crate) fn multicol_band_break_pad_px(dpi: f64) -> f64 {
    hwpunit_to_px(1500, dpi)
}

/// 큰 디자인 간격의 한 줄 표 헤더 앞뒤에 나누어 예약할 직전 제목의 줄간격.
pub(crate) fn solo_header_gap_half_px(
    title: &crate::model::paragraph::Paragraph,
    header: &crate::model::paragraph::Paragraph,
    dpi: f64,
) -> Option<f64> {
    use crate::model::control::Control;
    if title.line_segs.len() != 1
        || title.text.trim().is_empty()
        || header.line_segs.len() != 1
        || !title.controls.iter().any(|control| {
            matches!(control, Control::ColumnDef(cd) if cd.column_count.max(1) <= 1 && cd.spacing <= 283)
        })
        || title.controls.iter().any(|control| matches!(control, Control::Table(_)))
        || !header.controls.iter().any(|control| {
            matches!(control, Control::ColumnDef(cd) if cd.column_count.max(1) <= 1 && cd.spacing > 283)
        })
        || !header.controls.iter().any(|control| {
            matches!(control, Control::Table(table) if table.common.treat_as_char
                && matches!(table.common.text_wrap, crate::model::shape::TextWrap::TopAndBottom))
        })
    {
        return None;
    }
    let spacing = title.line_segs.first()?.line_spacing;
    (spacing > 0).then(|| hwpunit_to_px(spacing, dpi) / 2.0)
}

/// 저장 한 줄 소제목에서 다단 본문으로 넘어갈 때 본문 두 줄 진행을 확보한다.
/// 제목에서 이미 소비한 줄 상자와 별도로 더할 디자인 간격은 예약에서 제외한다.
pub(crate) fn solo_title_exit_pad_px(
    title: &crate::model::paragraph::Paragraph,
    body: &crate::model::paragraph::Paragraph,
    title_design_px: f64,
    body_design_px: f64,
    dpi: f64,
) -> Option<f64> {
    use crate::model::control::Control;
    if title.line_segs.len() != 1
        || !title.text.trim_start().starts_with('<')
        || !title.controls.iter().any(|control| {
            matches!(control, Control::ColumnDef(cd) if cd.column_count.max(1) <= 1 && cd.spacing <= 283)
        })
        || !body.controls.iter().any(|control| {
            matches!(control, Control::ColumnDef(cd) if cd.column_count.max(1) > 1)
        })
    {
        return None;
    }
    let title_line = title.line_segs.first()?;
    let body_line = body.line_segs.first()?;
    let title_advance = title_line
        .line_height
        .saturating_add(title_line.line_spacing);
    let body_advance = body_line.line_height.saturating_add(body_line.line_spacing);
    if title_advance <= 0 || body_advance <= 0 {
        return None;
    }
    Some(
        (2.0 * hwpunit_to_px(body_advance, dpi)
            - hwpunit_to_px(title_advance, dpi)
            - title_design_px / 2.0
            - body_design_px / 2.0)
            .max(0.0),
    )
}

/// 같은 저장 줄을 끝으로 갖는 다단에서 빈 마지막 문단의 추가 줄간격.
/// 글자가 있는 다른 단의 줄 상자는 유지하고, 빈 단의 뒤쪽 여백만 다음 구역에서 제외한다.
pub(crate) fn parallel_blank_tail_spacing_excess_px(
    columns: &[pagination::ColumnContent],
    paragraphs: &[crate::model::paragraph::Paragraph],
    dpi: f64,
) -> f64 {
    let Some(last_col) = columns.last() else {
        return 0.0;
    };
    if last_col
        .zone_layout
        .as_ref()
        .is_none_or(|layout| layout.column_areas.len() < 2)
    {
        return 0.0;
    }
    let mut visible = Vec::new();
    let mut blank = Vec::new();
    for col in columns
        .iter()
        .rev()
        .take_while(|col| (col.zone_y_offset - last_col.zone_y_offset).abs() < 0.1)
    {
        let Some(pagination::PageItem::FullParagraph { para_index }) = col.items.last() else {
            continue;
        };
        let Some(para) = paragraphs.get(*para_index) else {
            continue;
        };
        let Some(line) = para.line_segs.last() else {
            continue;
        };
        let key = (line.vertical_pos, line.line_height);
        if para.text.trim().is_empty() && para.controls.is_empty() {
            blank.push((key, line.line_spacing));
        } else if !para.text.trim().is_empty() {
            visible.push((key, line.line_spacing));
        }
    }
    let excess_hu = blank
        .iter()
        .flat_map(|(blank_key, blank_spacing)| {
            visible
                .iter()
                .filter(move |(visible_key, _)| visible_key == blank_key)
                .map(move |(_, visible_spacing)| blank_spacing - visible_spacing)
        })
        .max()
        .unwrap_or(0)
        .max(0);
    hwpunit_to_px(excess_hu, dpi)
}

/// 한 줄 표 헤더 뒤의 예약 높이. 아래 바깥여백은 저장 줄에서 이미 소비했다.
pub(crate) fn single_tac_header_tail_px(table_height_hu: u32, margin_top_hu: i16, dpi: f64) -> f64 {
    (hwpunit_to_px(table_height_hu.min(i32::MAX as u32) as i32, dpi)
        + hwpunit_to_px(i32::from(margin_top_hu), dpi))
    .max(0.0)
}

/// 저장 줄을 먼저 소비한 헤더 띠 뒤의 잔여 높이.
/// 표 본체와 아래 여백은 남고, 선행 줄의 마지막 줄간격 절반은 이미 소비됐다.
pub(crate) fn partial_tac_header_tail_px(
    table_height_hu: u32,
    margin_bottom_hu: i16,
    line_spacing_hu: i32,
    dpi: f64,
) -> f64 {
    (hwpunit_to_px(table_height_hu.min(i32::MAX as u32) as i32, dpi)
        + hwpunit_to_px(i32::from(margin_bottom_hu), dpi)
        - hwpunit_to_px(line_spacing_hu, dpi) / 2.0)
        .max(0.0)
}

/// 픽셀을 HWPUNIT으로 변환
#[inline]
pub fn px_to_hwpunit(px: f64, dpi: f64) -> i32 {
    (px * HWPUNIT_PER_INCH / dpi) as i32
}

/// TAC(글자처럼 취급) 표 한 칸의 유효 높이 — 저장된 line_seg 높이와 실측 표 높이 중
/// 큰 쪽을 쓴다.
///
/// [#4627] 같은 식(`seg_lh.max(mt_h)`)이 `typeset.rs`(레이아웃 확정)와
/// `pagination/engine.rs`(`RHWP_USE_PAGINATOR=1` 대안 경로)에 각각 따로 있었다 —
/// 표 높이가 페이지 경계를 정하므로 두 사본이 갈리면 쪽수가 움직인다. 두 소비자
/// 모두 이 함수를 불러 사본을 없앤다(행동 변경 없음, 순수 NFC).
#[inline]
pub fn tac_table_effective_height(seg_lh: f64, mt_h: f64) -> f64 {
    seg_lh.max(mt_h)
}

/// [Task #1745] 텍스트 혼합 anchor 문단의 Square wrap 표 우측 wrap 띠 (cs, sw) HU 도출.
///
/// Square wrap(어울림) 표가 텍스트 문단(예: 별표 제목)에 anchor 되면 anchor 문단의
/// 첫 LINE_SEG 는 전폭 텍스트 줄(cs=0)이라 wrap 띠를 인코딩하지 않는다. 이때 표
/// geometry(가로 오프셋 + 바깥여백 좌 + 폭 + 바깥여백 우)로 띠 시작 cs 를 계산하고,
/// 띠 폭은 전폭 줄 너비에서 뺀 나머지로 잡는다 (한글 저장 LINE_SEG 와 정확 일치 —
/// samples/task1745 cs=45568=45002+283×2, sw=2620=48188−45568).
///
/// 기존 케이스(표 단독 anchor — 첫 LINE_SEG 가 이미 띠, cs>0)나 텍스트 없는 anchor,
/// 좌측 정렬이 아닌 표, 띠 폭이 남지 않는 표는 None (기존 경로 유지).
pub(crate) fn text_anchor_square_table_strip(
    para: &crate::model::paragraph::Paragraph,
) -> Option<(i32, i32)> {
    let first = para.line_segs.first()?;
    if first.column_start != 0 {
        return None;
    }
    let full_sw = first.segment_width;
    if full_sw <= 0 {
        return None;
    }
    let has_real_text = para.text.chars().any(|c| c > '\u{001F}' && c != '\u{FFFC}');
    if !has_real_text {
        return None;
    }
    let cm = para.controls.iter().find_map(|c| match c {
        crate::model::control::Control::Table(t)
            if !t.common.treat_as_char
                && matches!(t.common.text_wrap, crate::model::shape::TextWrap::Square)
                && matches!(t.common.horz_align, crate::model::shape::HorzAlign::Left) =>
        {
            Some(&t.common)
        }
        _ => None,
    })?;
    let strip_cs = cm.horizontal_offset as i32
        + cm.margin.left as i32
        + cm.width as i32
        + cm.margin.right as i32;
    let strip_sw = full_sw - strip_cs;
    (strip_cs > 0 && strip_sw > 0).then_some((strip_cs, strip_sw))
}

/// 빈 호스트 문단의 우측 Square 표가 남긴 좌측 본문 띠를 복원한다.
///
/// 한글은 표를 실제 수평 오프셋에 두면서 호스트 문단에는 전폭 LINE_SEG만 저장할 수
/// 있다. 이 경우 다음 문단의 `cs=0, sw=horizontal_offset`가 표 왼쪽 띠를 직접
/// 가리킨다. 호스트에 가시 텍스트가 있으면 기존 `text_anchor_square_table_strip`이
/// 담당하므로, 이 함수는 빈 호스트와 우측으로 밀린 표에만 한정한다.
pub(crate) fn empty_host_square_table_left_strip(
    para: &crate::model::paragraph::Paragraph,
    column_width_hu: i32,
) -> Option<(i32, i32)> {
    let first = para.line_segs.first()?;
    if first.column_start != 0
        || (first.segment_width as i32 - column_width_hu).abs() >= 3000
        || para
            .text
            .chars()
            .any(|ch| ch > '\u{001F}' && ch != '\u{FFFC}' && !ch.is_whitespace())
    {
        return None;
    }

    let left_width = para.controls.iter().find_map(|control| match control {
        crate::model::control::Control::Table(table)
            if !table.common.treat_as_char
                && matches!(
                    table.common.text_wrap,
                    crate::model::shape::TextWrap::Square
                )
                && matches!(
                    table.common.horz_align,
                    crate::model::shape::HorzAlign::Left
                ) =>
        {
            Some(table.common.horizontal_offset as i32)
        }
        _ => None,
    })?;

    (left_width > 0 && left_width < column_width_hu).then_some((0, left_width))
}

/// 저장 LINE_SEG 가 하나도 없고 가시 글자가 있는 문단인지. 저장 줄이 없으면 host 글자의
/// 띠·높이 증거가 없어 표 기하로 판단해야 한다(`no_lineseg_square_table_host_band`).
pub(crate) fn is_no_lineseg_visible_text_host(para: &crate::model::paragraph::Paragraph) -> bool {
    !para
        .line_segs
        .iter()
        .any(|seg| seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0)
        && para
            .text
            .chars()
            .any(|ch| ch > '\u{001F}' && ch != '\u{FFFC}' && !ch.is_whitespace())
}

/// 저장 LINE_SEG 가 없는 host 문단의 Square 표 옆 글자 띠 (cs, sw) HU 도출.
///
/// 저장 줄이 있으면 첫 줄의 `column_start`/`segment_width` 가 한글이 흘린 띠를 그대로
/// 인코딩하지만, 저장 줄이 없는 문서(기계 생성 서식)는 그 증거가 없다. 이때 띠는 표
/// 자신의 기하(가로 기준·정렬·오프셋·폭·바깥여백)와 글자 흐름 방향으로 정해진다.
/// typeset(흐름 전진)과 layout(host 글자 페인트)이 같은 띠를 써야 두 장부가 갈리지
/// 않는다.
///
/// 표 하나만 앵커하고 가시 글자가 있는 host 에 한정한다. 가운데 놓여 양쪽 띠가 모두
/// 넓은 형상이나 쪽/용지 기준 표는 기존 경로에 남긴다(None).
pub(crate) fn no_lineseg_square_table_host_band(
    para: &crate::model::paragraph::Paragraph,
    column_width_hu: i32,
) -> Option<(i32, i32)> {
    use crate::model::shape::{HorzAlign, HorzRelTo, TextFlow, TextWrap};
    const MIN_BAND_HU: i32 = 2000;

    if !is_no_lineseg_visible_text_host(para) || column_width_hu <= 0 {
        return None;
    }

    let is_square_float = |common: &crate::model::shape::CommonObjAttr| {
        !common.treat_as_char && matches!(common.text_wrap, TextWrap::Square)
    };
    let square_float_count = para
        .controls
        .iter()
        .filter(|control| match control {
            crate::model::control::Control::Table(t) => is_square_float(&t.common),
            crate::model::control::Control::Picture(p) => is_square_float(&p.common),
            crate::model::control::Control::Shape(s) => is_square_float(s.common()),
            _ => false,
        })
        .count();
    let common = para.controls.iter().find_map(|control| match control {
        crate::model::control::Control::Table(t) if is_square_float(&t.common) => Some(&t.common),
        _ => None,
    })?;
    if square_float_count != 1 || !matches!(common.horz_rel_to, HorzRelTo::Column | HorzRelTo::Para)
    {
        return None;
    }

    let width = common.width as i32;
    let offset = common.horizontal_offset as i32;
    let left = match common.horz_align {
        HorzAlign::Left => offset,
        HorzAlign::Right => column_width_hu - width - offset,
        _ => return None,
    };
    let obj_left = left - common.margin.left as i32;
    let obj_right = left + width + common.margin.right as i32;
    let left_gap = obj_left.clamp(0, column_width_hu);
    let right_gap = (column_width_hu - obj_right).clamp(0, column_width_hu);
    let left_band = (0, left_gap);
    let right_band = (obj_right.clamp(0, column_width_hu), right_gap);

    let band = match common.text_flow {
        TextFlow::LeftOnly => left_band,
        TextFlow::RightOnly => right_band,
        TextFlow::LargestOnly => {
            if left_gap >= right_gap {
                left_band
            } else {
                right_band
            }
        }
        // 양쪽 흐름은 한쪽 띠가 글자 하나도 못 들어갈 만큼 좁을 때만 한 띠로 본다.
        TextFlow::BothSides => {
            if right_gap < MIN_BAND_HU {
                left_band
            } else if left_gap < MIN_BAND_HU {
                right_band
            } else {
                return None;
            }
        }
    };
    (band.1 >= MIN_BAND_HU).then_some(band)
}

/// [#3314] 요청 face 의 굵기/폭 접미사를 벗긴 base family.
///
/// `"Noto Serif KR Black"` → `Some("Noto Serif KR")`, 접미사가 없으면 `None`.
/// 폴백 체인은 요청 face 바로 뒤에 이 base 를 끼워 넣는다 — 접미사 face 가
/// 미설치일 때 같은 family 의 base face 가 generic 체인(Batang 등)보다 먼저
/// 구제한다(1.hwpx: 한컴 NotoSerifKR vs rhwp Batang, 제목 잉크 −31%).
/// 요청 face 가 실존하면 체인 선두라 무영향. **렌더 경로 전용** — 측정 경로
/// (`text_measurement`)는 쓰지 않아 조판(쪽수)이 불변이다.
pub fn base_family_without_weight_suffix(font_family: &str) -> Option<String> {
    // 뒤에서부터 제거되는 토큰들. "Extra Bold" 처럼 두 토큰으로 쪼개진 경우를
    // 위해 수식 접두 토큰(extra/ultra/semi/demi)도 포함한다.
    const WEIGHT_TOKENS: &[&str] = &[
        "black",
        "heavy",
        "extrabold",
        "ultrabold",
        "semibold",
        "demibold",
        "bold",
        "medium",
        "regular",
        "normal",
        "extralight",
        "ultralight",
        "demilight",
        "light",
        "thin",
        "extra",
        "ultra",
        "semi",
        "demi",
    ];
    let mut tokens: Vec<&str> = font_family.split_whitespace().collect();
    let original_len = tokens.len();
    while tokens.len() > 1 {
        let last = tokens.last().expect("len > 1").to_ascii_lowercase();
        if WEIGHT_TOKENS.contains(&last.as_str()) {
            tokens.pop();
        } else {
            break;
        }
    }
    (tokens.len() < original_len).then(|| tokens.join(" "))
}

/// 현재 설치된 글꼴로 보완 가능한 legacy face 의 대체명.
///
/// HWPX 는 `한양중고딕`이라는 legacy name을 보존하지만 실제 한양 face의 family는
/// `HY중고딕`(fontconfig full name: `HYGothic-Medium`)이다. 두 이름을 모두
/// 체인에 넣어 원 font가 설치된 호스트에서는 해당 glyph를 먼저 선택한다.
/// 원 font가 없는 호스트에서는 `Malgun Gothic`이 종전과 같은 마지막 대체다.
///
/// 다만 이름을 그대로 넣는 것만으로는 Windows(DirectWrite/Chrome)에서 안 잡히는
/// face 가 있다. 아래 중고딕 arm 의 주석을 볼 것.
fn installed_render_font_aliases(font_family: &str) -> &'static [&'static str] {
    match font_family {
        // [#6171] 이름 셋 중 `HYGothic` 만 Windows 에서 해석된다. headless Chrome
        // 통제 실측(`'X',serif` 를 없는 글꼴 기준선과 픽셀 차분):
        // `HY중고딕` 0px · `HYGothic-Medium` 0px · **`HYGothic` 3,287px**.
        // DirectWrite 가 영문 family 끝의 스타일 접미사를 떼어 family 를 구성하기
        // 때문이다 — `-Medium` 은 떼어지므로 원문 이름이 남지 않고, 한국어 이름도 그
        // family 로 이관되지 않아 같이 실패한다. 아래 견고딕/견명조의 `-Extra` 는
        // 스타일 토큰이 아니라 안 떼어져 원문 그대로 잡히는 것이라 이 arm 과 다르다
        // (`H2GTRM`/`H2GTRE` 의 name 테이블 구조는 동일한데 결과만 갈린다).
        // `HYGothic` 이 실제로 `H2GTRM.TTF` 임은 Chrome 렌더 ↔ TTF 직접 렌더의 잉크
        // IoU 0.724 로 확인했다(대조군 `H2GTRE.TTF` 는 0.405).
        // 이 arm 이 없으면 3146683 1쪽 `『별표 7』`의 `『`(중고딕 run)만 Malgun 으로
        // 떨어져 뒤 글자와의 틈이 8.88pt 가 된다 — 한글 오라클 2.50pt, rhwp PDF 2.38pt.
        // (체인에서 이 이름만 뺀 통제 렌더로 잰 값. 이 arm 을 넣으면 2.25pt.)
        "한양중고딕" => &[
            "HY중고딕",
            "HYGothic",
            "HYGothic-Medium",
            "HCR Dotum",
            "함초롬돋움",
        ],
        "HY중고딕" => &[
            "HYGothic",
            "HYGothic-Medium",
            "HCR Dotum",
            "함초롬돋움",
            "Malgun Gothic",
        ],
        // [#6171] 견고딕/견명조도 같은 legacy ↔ 설치 face 짝이다. 이 arm 이 없으면
        // 체인이 `'한양견고딕'` 하나 뒤에 바로 generic(=Malgun Gothic)으로 떨어져,
        // `HY견고딕`이 설치된 호스트에서도 Malgun Regular 로 그려진다 — 3146683 1쪽
        // `『별표 7』`의 `별표` 획이 견고딕(Extra)보다 가늘어지는 원인.
        // Windows 글꼴 레지스트리 실측: `HY견고딕`=H2GTRE.TTF(family `HYGothic-Extra`),
        // `HY견명조`=H2MJRE.TTF(family `HYMyeongJo-Extra`).
        "한양견고딕" => &["HY견고딕", "HYGothic-Extra", "HCR Dotum", "함초롬돋움"],
        "한양견명조" => &["HY견명조", "HYMyeongJo-Extra", "HCR Batang", "함초롬바탕"],
        // 신명조도 같은 짝인데 이 arm 만 빠져 있었다. `svg.rs` 의 local()·embed 두 표는
        // 이미 `한양신명조 → HY신명조 / HYSinMyeongJo-Medium / H2MJSM.TTF` 를 알고 있는데,
        // 정작 체인을 만드는 여기가 몰라서 `'한양신명조','Batang',…` 로 바로 떨어졌다.
        // 156573118 8쪽 실측: 그 쪽 텍스트 런 600개가 이 체인을 쓰고, `HY신명조`가 설치된
        // 호스트에서도 Batang 으로 그려졌다(형제 `한양중고딕` 은 `'한양중고딕','HY중고딕',…`).
        // 이름 순서가 중요하다. `H2MJSM.TTF` 의 name 테이블은 family(ko) `HY신명조`,
        // family(en) `HYSinMyeongJo-Medium` 인데, headless Chrome 실측으로는 **둘 다
        // 매칭되지 않고** 스타일 접미사를 뗀 `HYSinMyeongJo` 만 잡힌다(각각 serif 로
        // 떨어지는 것을 통제 SVG 로 확인). 그래서 실제로 해석되는 이름을 앞에 둔다.
        // 형제 항목과 다른 점이라 주의 — `HY견고딕`·`HYGothic-Extra` 는 둘 다 잡힌다.
        "한양신명조" => &["HYSinMyeongJo", "HY신명조", "HYSinMyeongJo-Medium"],
        // [#6263] 같은 접미사 절단 규칙의 나머지 한컴 face 다. 문서가 한국어 이름을
        // 그대로 들고 있는데 Windows 는 그 이름으로 face 를 못 찾는다. 위 `한양신명조`
        // arm 은 legacy 이름으로 들어오는 경우고, 이 셋은 문서가 `HY…` 이름을 직접
        // 쓰는 경우라 별도 arm 이 필요하다(#6263 신고 7문서 실측).
        //
        // headless Chrome 통제 실측(`'X',serif` 를 없는 글꼴 기준선과 픽셀 차분):
        //   `HY신명조` 0px · `HYSinMyeongJo-Medium` 0px · `HYSinMyeongJo` 3,295px
        //   `HY헤드라인M` 0px · `HYHeadLine-Medium` 0px · `HYHeadLine` 4,785px
        //   `HY그래픽M` 0px · `HYGraphic-Medium` 0px · `HYGraphic` 3,687px
        // 셋 다 한국어 이름과 `-Medium` 원문이 모두 안 잡히고 접미사를 뗀 이름만
        // 잡힌다 — `한양신명조` arm 이 이미 적어 둔 규칙이 그대로 성립한다.
        //
        // name 테이블 실측 — family(ko)/family(en):
        //   H2MJSM.TTF `HY신명조`/`HYSinMyeongJo-Medium`
        //   H2HDRM.TTF `HY헤드라인M`/`HYHeadLine-Medium`
        //   H2GPRM.TTF `HY그래픽M`/`HYGraphic-Medium`
        // 해석되는 이름을 앞에 두고, 원문 en 이름은 다른 매칭 규칙을 쓰는 호스트를
        // 위해 뒤에 남긴다(형제 arm 과 같은 순서 규약).
        "HY신명조" => &[
            "HYSinMyeongJo",
            "HYSinMyeongJo-Medium",
            "HCR Batang",
            "함초롬바탕",
        ],
        "HY헤드라인M" => &["HYHeadLine", "HYHeadLine-Medium", "HCR Dotum", "함초롬돋움"],
        "HY그래픽M" => &["HYGraphic", "HYGraphic-Medium", "HCR Dotum", "함초롬돋움"],
        // #4739: 구형 정부상징 부처명 face가 없을 때 현재 공식 배포 face를 찾는다.
        // 동일 alias가 아니라 availability 기반 successor이므로 exact legacy 뒤에만 둔다.
        "정부상징 부처명_16040911" | "Government_16040911" => &[
            "ROKG",
            "ROKG R",
            "대한민국정부상징체",
            "대한민국정부상징체 R",
            "ROKGR",
        ],
        _ => &[],
    }
}

fn internal_font_family_members(font_family: &str) -> Vec<&str> {
    font_family
        .split(',')
        .map(str::trim)
        .filter(|family| !family.is_empty())
        .collect()
}

fn push_unique_family<'a>(
    families: &mut Vec<std::borrow::Cow<'a, str>>,
    family: impl Into<std::borrow::Cow<'a, str>>,
) {
    let family = family.into();
    if !families.iter().any(|existing| existing == &family) {
        families.push(family);
    }
}

/// SVG/CSS `font-family`에서 쓸 단일 인용 family 이름.
///
/// font name 자체에 작은따옴표나 역슬래시가 들어갈 수 있으므로 단순히 `'{}'`로
/// 감싸면 `Tom's Handwriting` 같은 이름이 중간에서 끝나 잘못된 CSS가 된다.
fn css_single_quoted_font_family(font_family: &str) -> String {
    let escaped = font_family.replace('\\', "\\\\").replace('\'', "\\'");
    format!("'{escaped}'")
}

/// Task #1224 ExtraLight family. regular 본문 획 두께용이며 bold 체인에서는 뺀다 (#3772).
pub(crate) const NOTO_SANS_KR_EXTRALIGHT: &str = "Noto Sans KR ExtraLight";

/// 폴백 체인에서 `Noto Sans KR ExtraLight` 항목만 제거한다.
///
/// ExtraLight 는 별도 family 이름이라 `font-weight="bold"` 가 Bold/Regular 로
/// 넘어가지 않는다. svg2pdf 는 faux-bold 를 합성하지 않으므로 bold run 이
/// ExtraLight(200) 에 떨어지면 PDF 굵기가 사라진다 (#3772).
pub(crate) fn drop_noto_sans_kr_extralight(chain: &str) -> String {
    let quoted = [
        format!("'{NOTO_SANS_KR_EXTRALIGHT}',"),
        format!("&apos;{NOTO_SANS_KR_EXTRALIGHT}&apos;,"),
        format!("\"{NOTO_SANS_KR_EXTRALIGHT}\","),
        format!("'{NOTO_SANS_KR_EXTRALIGHT}'"),
        format!("&apos;{NOTO_SANS_KR_EXTRALIGHT}&apos;"),
        format!("\"{NOTO_SANS_KR_EXTRALIGHT}\""),
    ];
    let mut out = chain.to_string();
    for token in &quoted {
        out = out.replace(token, "");
    }
    if out.trim().is_empty() {
        "'Noto Sans KR'".to_string()
    } else {
        out
    }
}

/// 렌더용 폴백 체인 문자열:
/// `요청 face → 설치 successor/alias → base family → 문서 substFont → generic 체인`.
pub fn render_font_family_chain(font_family: &str) -> String {
    render_font_family_chain_for_weight(font_family, false)
}

/// `bold` 이면 ExtraLight 를 빼서 Noto Sans KR Regular/Bold 가 매칭되게 한다 (#3772).
pub fn render_font_family_chain_for_weight(font_family: &str, bold: bool) -> String {
    let requested = internal_font_family_members(font_family);
    let Some(primary) = requested.first().copied() else {
        return generic_fallback_for_weight("", bold);
    };
    let fb = generic_fallback_for_weight(primary, bold);
    let mut family_names = Vec::new();
    push_unique_family(&mut family_names, primary);
    for alias in installed_render_font_aliases(primary) {
        push_unique_family(&mut family_names, *alias);
    }
    if let Some(base) = base_family_without_weight_suffix(primary) {
        push_unique_family(&mut family_names, base);
    }
    for declared_fallback in requested.into_iter().skip(1) {
        push_unique_family(&mut family_names, declared_fallback);
    }
    let mut families: Vec<String> = family_names
        .iter()
        .map(|family| css_single_quoted_font_family(family))
        .collect();
    families.push(fb);
    families.join(",")
}

/// Canvas 2D 렌더용 인용 font-family 체인.
///
/// [#3314] Canvas API가 요구하는 인용 형식을 유지하면서, 굵기 접미사 face
/// 바로 뒤에 base family를 넣어 generic 폴백보다 먼저 선택되게 한다.
/// 정적 DB 조회의 family key와는 다르다. Canvas 실측은 paint와 이 체인을 공유한다.
pub fn canvas_font_family_chain(font_family: &str) -> String {
    let requested = internal_font_family_members(font_family);
    let Some(primary) = requested.first().copied() else {
        return "sans-serif".to_string();
    };

    let fallback = generic_fallback(primary);
    let mut family_names = Vec::new();
    push_unique_family(&mut family_names, primary);
    for alias in installed_render_font_aliases(primary) {
        push_unique_family(&mut family_names, *alias);
    }
    if let Some(base) = base_family_without_weight_suffix(primary) {
        push_unique_family(&mut family_names, base);
    }
    for declared_fallback in requested.into_iter().skip(1) {
        push_unique_family(&mut family_names, declared_fallback);
    }
    let mut families: Vec<String> = family_names
        .iter()
        .map(|family| format!("\"{}\"", family.replace('"', "\\\"")))
        .collect();
    families.push(fallback.to_string());
    families.join(", ")
}

/// CSS generic fallback 반환 (serif 또는 sans-serif)
///
/// 폰트 이름에 명조/바탕/궁서 등 세리프 계열 키워드가 포함되면 "serif",
/// 그 외에는 "sans-serif"를 반환한다.
pub fn generic_fallback(font_family: &str) -> &'static str {
    // Task #727 (F-1): sans/serif chain 마지막 단계에 함초롬 family 를 끼움.
    // 한컴 자체 PUA (사각 안 숫자 U+F02B1~F02C4 등) 글리프는 표준 한글 폰트
    // (Malgun Gothic, Noto Sans KR 등) 에 없어 .notdef tofu 가 나온다.
    //
    // [#4086] 어느 family 가 그 글리프를 갖는지 cmap 실측 (한글 2022 동봉 8종):
    //
    //   HCR Batang / HCR Dotum (일반)  59,330 자 — 한글·CJK 통합/확장A·BMP PUA
    //                                   **U+F02B1~F02C4 20 자 전부 보유**
    //   HCR Batang ExtB (확장B)        42,799 자 — CJK 확장B(U+20000~) 전담
    //                                   원문자 대역 **미보유**
    //   HCR Batang Ext / Dotum Ext     3,535 자 — 평면 1 희귀 스크립트 전담
    //                                   (U+10000~), PUA 무관
    //
    // 즉 PUA 원문자의 소재는 **일반**이고, 확장·확장B 는 그 목적과 무관하다
    // (원 주석이 확장B 를 PUA 보유자로 적었던 것은 사실과 반대다). 세 family 의
    // 담당 대역은 서로 겹치지 않으므로(일반∩확장 0 자, 일반∩확장B 2 자 —
    // U+0020·U+00A0 뿐) 나열 순서는 무엇이 매칭되는지를 바꾸지 않는다. 목적을
    // 드러내도록 일반 → 확장 → 확장B 순으로 적는다.
    //
    // 한글 본문 영역은 1순위 폰트가 글리프를 가지면 chain 우선순위에 의해 1순위를
    // 쓰므로 영향 0. 글리프 부재 시에만 함초롬이 매칭된다.
    if font_family.is_empty() {
        // Sans-serif: Windows → macOS/iOS → Android → 오픈소스 → 한컴 → generic
        // Task #1224: 시스템 고딕(맑은고딕/Apple) 부재 환경(Linux/CI)에서 폴백되는
        // 'Noto Sans KR'(CJK Regular)의 획이 한컴 돋움보다 +43% 두꺼워 본문이 과도하게
        // 굵게 렌더됨. 한컴 돋움 획 두께(페이지 밀도 0.265)에 근접한
        // 'Noto Sans KR ExtraLight'(rsvg 페이지 밀도 0.277)를 무거운 Noto 직전에 삽입 —
        // 시스템 고딕 렌더는 무영향, Noto 폴백만 가볍게 교체.
        return "'Malgun Gothic','맑은 고딕','Apple SD Gothic Neo','Noto Sans KR ExtraLight','Noto Sans KR','Pretendard','HCR Batang','함초롬바탕','HCR Batang Ext','함초롬바탕 확장','HCR Batang ExtB','함초롬바탕 확장B','Source Han Serif K Old Hangul',sans-serif";
    }
    // 고정폭 키워드
    let lower = font_family.to_ascii_lowercase();
    if (font_family.contains("KoPub돋움체") || lower.contains("kopub dotum"))
        && (font_family.contains("Light") || lower.contains("light"))
    {
        return "'Noto Sans KR ExtraLight','Malgun Gothic','맑은 고딕','Apple SD Gothic Neo','Noto Sans KR','Pretendard','HCR Batang','함초롬바탕','HCR Batang Ext','함초롬바탕 확장','HCR Batang ExtB','함초롬바탕 확장B','Source Han Serif K Old Hangul',sans-serif";
    }
    // BatangChe is fixed-width serif. Its stored glyph advances are replayed
    // independently of the paint fallback; choosing a sans coding face here
    // discards the source's serif appearance without preserving layout better.
    if font_family.contains("바탕체")
        || lower.contains("batangche")
        || lower.contains("kopub batang")
    {
        return "'Batang','바탕','Nanum Myeongjo','AppleMyungjo','Noto Serif KR','Noto Serif CJK KR','HCR Batang','함초롬바탕','HCR Batang Ext','함초롬바탕 확장','HCR Batang ExtB','함초롬바탕 확장B','Source Han Serif K Old Hangul',serif";
    }
    if font_family.contains("굴림체")
        || lower.contains("gulimche")
        || lower.contains("coding")
        || lower.contains("courier")
        || lower.contains("mono")
    {
        // Monospace: Windows → 오픈소스 → generic
        return "'GulimChe','굴림체','D2Coding','Noto Sans Mono',monospace";
    }
    // 세리프 키워드 (한글)
    if font_family.contains("바탕") || font_family.contains("명조") || font_family.contains("궁서")
    {
        // Serif: Windows → macOS(Bold 보유 우선) → macOS 기본 → Android → 오픈소스 → 한컴 → 리눅스 시스템 → generic
        // Nanum Myeongjo 는 macOS 10.9+ 기본 설치이며 Bold variant 보유.
        // AppleMyungjo 보다 앞에 두어야 macOS Chrome 에서 CJK 글리프 bold 매칭 성공.
        // 'Source Han Serif K Old Hangul' (Task #528): @font-face unicode-range 가 옛한글
        // 영역 (U+1100-11FF, U+A960-A97F, U+D7B0-D7FF) 만 매칭하므로 일반 한글에 영향 없음.
        return "'Batang','바탕','Nanum Myeongjo','AppleMyungjo','Noto Serif KR','Noto Serif CJK KR','HCR Batang','함초롬바탕','HCR Batang Ext','함초롬바탕 확장','HCR Batang ExtB','함초롬바탕 확장B','Source Han Serif K Old Hangul',serif";
    }
    // 세리프 키워드 (영문) — "serif" 포함하되 "sans" 부분 문자열을 가진 폰트명 전체 제외
    if lower.contains("times")
        || lower.contains("hymjre")
        || lower.contains("palatino")
        || lower.contains("georgia")
        || lower.contains("batang")
        || lower.contains("gungsuh")
        || (lower.contains("serif") && !lower.contains("sans"))
    {
        return "'Batang','바탕','Nanum Myeongjo','AppleMyungjo','Noto Serif KR','Noto Serif CJK KR','HCR Batang','함초롬바탕','HCR Batang Ext','함초롬바탕 확장','HCR Batang ExtB','함초롬바탕 확장B','Source Han Serif K Old Hangul',serif";
    }
    // Sans-serif: Windows → macOS/iOS → Android → 오픈소스 → 한컴 → generic
    // 'Source Han Serif K Old Hangul' (Task #528): unicode-range 옛한글 자모 영역 한정
    // 'Noto Sans KR ExtraLight' (Task #1224): 무거운 Noto CJK Regular 폴백 직전에 삽입해
    // 한컴 돋움 획 두께에 근접시킴. 시스템 고딕 우선 → 부재 시에만 ExtraLight 매칭.
    "'Malgun Gothic','맑은 고딕','Apple SD Gothic Neo','Noto Sans KR ExtraLight','Noto Sans KR','Pretendard','HCR Batang','함초롬바탕','HCR Batang Ext','함초롬바탕 확장','HCR Batang ExtB','함초롬바탕 확장B','Source Han Serif K Old Hangul',sans-serif"
}

/// `generic_fallback` 에 굵기 힌트를 얹는다. bold 는 ExtraLight 를 제거한다 (#3772).
pub fn generic_fallback_for_weight(font_family: &str, bold: bool) -> String {
    let chain = generic_fallback(font_family);
    if bold {
        drop_noto_sans_kr_extralight(chain)
    } else {
        chain.to_string()
    }
}

pub(crate) fn contains_old_hangul_jamo(text: &str) -> bool {
    text.chars().any(|ch| {
        let code = ch as u32;
        matches!(
            code,
            0x1100..=0x11FF | 0xA960..=0xA97F | 0xD7B0..=0xD7FF
        )
    })
}

/// 한컴 Supplementary PUA-A의 사각 안 숫자 값을 반환한다.
///
/// IR은 원문 PUA를 보존하고, 렌더러는 이 값을 사용해 backend/font와 무관한 사각형+숫자를
/// 합성한다.
pub(crate) fn boxed_pua_number(ch: char) -> Option<u32> {
    let code_point = ch as u32;
    // [#6127] U+F02B0 = 네모 안 0 — 한글 2020 실측(2599643 "②⓪⓪" 신청 번호란).
    (0xF02B0..=0xF02C4)
        .contains(&code_point)
        .then(|| code_point - 0xF02B0)
}

/// 실제 `CharOverlap`에 저장된 한컴 사각 안 숫자의 렌더 의미를 반환한다 (#4158).
///
/// 이 PUA 범위는 문자 자체가 사각형 의미를 포함하므로 raw `border_type=0`이어도 사각형을
/// 그린다. 작성된 명시적 테두리는 보존한다. 다중 문자 겹침은 별도의 자리별 PUA 디코더가
/// 담당하므로 여기서는 의도적으로 제외한다.
pub(crate) fn boxed_pua_char_overlap_semantics(
    chars: &[char],
    raw_border_type: u8,
) -> Option<(u32, u8)> {
    let [ch] = chars else {
        return None;
    };
    let number = boxed_pua_number(*ch)?;
    let effective_border = if raw_border_type == 0 {
        3
    } else {
        raw_border_type
    };
    Some((number, effective_border))
}

// ============================================================
// 자동 번호 매기기 (AutoNumber)
// ============================================================

use crate::model::control::AutoNumberType;

/// 자동 번호 카운터
///
/// 각 번호 종류별로 카운터를 유지하여 순차적인 번호를 생성한다.
#[derive(Debug, Clone, Default)]
pub struct AutoNumberCounter {
    /// 그림 번호
    pub picture: u16,
    /// 표 번호
    pub table: u16,
    /// 수식 번호
    pub equation: u16,
    /// 각주 번호
    pub footnote: u16,
    /// 미주 번호
    pub endnote: u16,
    /// 쪽 번호
    pub page: u16,
}

impl AutoNumberCounter {
    /// 새 카운터 생성
    pub fn new() -> Self {
        Self::default()
    }

    /// 번호 증가 후 현재 값 반환
    pub fn increment(&mut self, number_type: AutoNumberType) -> u16 {
        match number_type {
            AutoNumberType::Picture => {
                self.picture += 1;
                self.picture
            }
            AutoNumberType::Table => {
                self.table += 1;
                self.table
            }
            AutoNumberType::Equation => {
                self.equation += 1;
                self.equation
            }
            AutoNumberType::Footnote => {
                self.footnote += 1;
                self.footnote
            }
            AutoNumberType::Endnote => {
                self.endnote += 1;
                self.endnote
            }
            AutoNumberType::Page => {
                self.page += 1;
                self.page
            }
            // 총 쪽수는 카운터로 증가시키는 값이 아니라 페이지네이션이 끝난 뒤
            // 알려지는 문서 전체 쪽수를 그대로 표시하는 필드라 여기서 처리하지 않는다.
            AutoNumberType::TotalPage => 0,
        }
    }

    /// 현재 번호 조회 (증가 없이)
    pub fn current(&self, number_type: AutoNumberType) -> u16 {
        match number_type {
            AutoNumberType::Picture => self.picture,
            AutoNumberType::Table => self.table,
            AutoNumberType::Equation => self.equation,
            AutoNumberType::Footnote => self.footnote,
            AutoNumberType::Endnote => self.endnote,
            AutoNumberType::Page => self.page,
            AutoNumberType::TotalPage => 0,
        }
    }

    /// 모든 카운터 초기화
    pub fn reset(&mut self) {
        *self = Self::default();
    }
}

/// 번호 형식
#[derive(Debug, Clone, Copy, Default, PartialEq)]
pub enum NumberFormat {
    /// 아라비아 숫자: 1, 2, 3
    #[default]
    Digit,
    /// 원 문자: ①, ②, ③
    CircledDigit,
    /// 로마 숫자 대문자: I, II, III
    RomanUpper,
    /// 로마 숫자 소문자: i, ii, iii
    RomanLower,
    /// 영문 대문자: A, B, C
    LatinUpper,
    /// 영문 소문자: a, b, c
    LatinLower,
    /// 한글 가나다: 가, 나, 다
    HangulGaNaDa,
    /// 한글 자모: ㄱ, ㄴ, ㄷ
    HangulJamo,
    /// 한글 일이삼: 일, 이, 삼
    HangulNumber,
    /// 한자 一二三: 一, 二, 三
    HanjaNumber,
}

impl NumberFormat {
    /// HWP 형식 코드에서 변환
    pub fn from_hwp_format(format: u8) -> Self {
        match format {
            0 => NumberFormat::Digit,
            1 => NumberFormat::CircledDigit,
            2 => NumberFormat::RomanUpper,
            3 => NumberFormat::RomanLower,
            4 => NumberFormat::LatinUpper,
            5 => NumberFormat::LatinLower,
            6 => NumberFormat::HangulGaNaDa,
            7 => NumberFormat::HangulNumber,
            8 => NumberFormat::HanjaNumber,
            _ => NumberFormat::Digit,
        }
    }
}

/// 번호를 문자열로 변환
pub fn format_number(number: u16, format: NumberFormat) -> String {
    match format {
        NumberFormat::Digit => number.to_string(),
        NumberFormat::CircledDigit => format_circled_digit(number),
        NumberFormat::RomanUpper => format_roman(number, true),
        NumberFormat::RomanLower => format_roman(number, false),
        NumberFormat::LatinUpper => format_latin(number, true),
        NumberFormat::LatinLower => format_latin(number, false),
        NumberFormat::HangulGaNaDa => format_hangul_ganada(number),
        NumberFormat::HangulJamo => {
            const JAMO: [char; 14] = [
                'ㄱ', 'ㄴ', 'ㄷ', 'ㄹ', 'ㅁ', 'ㅂ', 'ㅅ', 'ㅇ', 'ㅈ', 'ㅊ', 'ㅋ', 'ㅌ', 'ㅍ', 'ㅎ',
            ];
            number
                .checked_sub(1)
                .and_then(|index| JAMO.get(index as usize))
                .map(char::to_string)
                .unwrap_or_else(|| number.to_string())
        }
        NumberFormat::HangulNumber => format_hangul_number(number),
        NumberFormat::HanjaNumber => format_hanja_number(number),
    }
}

/// 원 문자 변환 (① ~ ⑳, 이후 숫자)
fn format_circled_digit(n: u16) -> String {
    const CIRCLED: [char; 20] = [
        '①', '②', '③', '④', '⑤', '⑥', '⑦', '⑧', '⑨', '⑩', '⑪', '⑫', '⑬', '⑭', '⑮', '⑯', '⑰', '⑱',
        '⑲', '⑳',
    ];
    n.checked_sub(1)
        .and_then(|idx| CIRCLED.get(idx as usize))
        .map(|c| c.to_string())
        .unwrap_or_else(|| n.to_string())
}

/// 로마 숫자 변환
fn format_roman(n: u16, upper: bool) -> String {
    if n == 0 || n > 3999 {
        return n.to_string();
    }

    let values = [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1];
    let symbols_upper = [
        "M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I",
    ];
    let symbols_lower = [
        "m", "cm", "d", "cd", "c", "xc", "l", "xl", "x", "ix", "v", "iv", "i",
    ];

    let symbols = if upper {
        &symbols_upper
    } else {
        &symbols_lower
    };
    let mut result = String::new();
    let mut num = n as i32;

    for (i, &val) in values.iter().enumerate() {
        while num >= val {
            result.push_str(symbols[i]);
            num -= val;
        }
    }
    result
}

/// 영문자 변환 (A-Z, AA-AZ, ...)
fn format_latin(n: u16, upper: bool) -> String {
    if n == 0 {
        return String::new();
    }

    let mut result = String::new();
    let mut num = n;

    while num > 0 {
        num -= 1;
        let c = if upper {
            (b'A' + (num % 26) as u8) as char
        } else {
            (b'a' + (num % 26) as u8) as char
        };
        result.insert(0, c);
        num /= 26;
    }
    result
}

/// 한글 가나다 변환
fn format_hangul_ganada(n: u16) -> String {
    const GANADA: [char; 14] = [
        '가', '나', '다', '라', '마', '바', '사', '아', '자', '차', '카', '타', '파', '하',
    ];
    n.checked_sub(1)
        .and_then(|idx| GANADA.get(idx as usize))
        .map(|c| c.to_string())
        .unwrap_or_else(|| n.to_string())
}

/// 한글 숫자 변환 (일, 이, 삼, ...)
fn format_hangul_number(n: u16) -> String {
    const HANGUL_DIGITS: [&str; 10] = ["", "일", "이", "삼", "사", "오", "육", "칠", "팔", "구"];
    const HANGUL_UNITS: [&str; 4] = ["", "십", "백", "천"];
    const HANGUL_LARGE: [&str; 4] = ["", "만", "억", "조"];

    if n == 0 {
        return "영".to_string();
    }

    let mut result = String::new();
    let mut num = n as u32;
    let mut large_unit = 0;

    while num > 0 {
        let group = (num % 10000) as usize;
        if group > 0 {
            let mut group_str = String::new();
            let mut g = group;
            let mut unit = 0;

            while g > 0 {
                let digit = g % 10;
                if digit > 0 {
                    let digit_str = if digit == 1 && unit > 0 {
                        ""
                    } else {
                        HANGUL_DIGITS[digit]
                    };
                    group_str.insert_str(0, HANGUL_UNITS[unit]);
                    group_str.insert_str(0, digit_str);
                }
                g /= 10;
                unit += 1;
            }
            group_str.push_str(HANGUL_LARGE[large_unit]);
            result.insert_str(0, &group_str);
        }
        num /= 10000;
        large_unit += 1;
    }
    result
}

/// 한자 숫자 변환 (一, 二, 三, ...)
fn format_hanja_number(n: u16) -> String {
    const HANJA_DIGITS: [&str; 10] = ["", "一", "二", "三", "四", "五", "六", "七", "八", "九"];
    const HANJA_UNITS: [&str; 4] = ["", "十", "百", "千"];
    const HANJA_LARGE: [&str; 4] = ["", "萬", "億", "兆"];

    if n == 0 {
        return "零".to_string();
    }

    let mut result = String::new();
    let mut num = n as u32;
    let mut large_unit = 0;

    while num > 0 {
        let group = (num % 10000) as usize;
        if group > 0 {
            let mut group_str = String::new();
            let mut g = group;
            let mut unit = 0;

            while g > 0 {
                let digit = g % 10;
                if digit > 0 {
                    let digit_str = if digit == 1 && unit > 0 {
                        ""
                    } else {
                        HANJA_DIGITS[digit]
                    };
                    group_str.insert_str(0, HANJA_UNITS[unit]);
                    group_str.insert_str(0, digit_str);
                }
                g /= 10;
                unit += 1;
            }
            group_str.push_str(HANJA_LARGE[large_unit]);
            result.insert_str(0, &group_str);
        }
        num /= 10000;
        large_unit += 1;
    }
    result
}

/// [#7470] 빈 host 줄이 문단 기준 자리차지 개체의 **띠 안에 흡수**되는가.
///
/// 한/글은 비TAC · `vert=Para` · TopAndBottom 개체에 줄 폭 전체가 막힌 host 줄을
/// `segment_width = 0` 으로 저장하고, 그 줄의 높이·줄간격을 개체 띠와 별도로 전진하지 않는다
/// (다음 문단 저장 vpos − 현 vpos = 개체 높이). `sw > 0`(개체 옆에 줄 폭이 남음)인 빈 host 는
/// 종전처럼 개체 뒤에 host 한 줄을 더 전진한다(pr-149, Task #683).
///
/// ```text
///   156636617 pi74  그림 h=20409  host lh=1100 ls=772 sw=0      다음 vpos − 현 vpos = 20409
///   memo_field pi331 그림 h=20218 host lh=1200 ls=480 sw=0      다음 vpos − 현 vpos = 20218
///   pr-149          그림 h=15696  host lh=1000 ls=600 sw=42520  host 한 줄 추가 전진
/// ```
///
/// 조판과 배치가 같은 판별을 쓰도록 한 곳에 둔다. 미주 흐름은 별도 조판 경로라 배치도 본문 단에서만
/// 이 판별을 쓴다.
pub(crate) fn empty_host_line_absorbed_by_topbottom_float(
    para: &crate::model::paragraph::Paragraph,
    common: &crate::model::shape::CommonObjAttr,
) -> bool {
    use crate::model::shape::{TextWrap, VertRelTo};

    // 띠가 앵커에서 시작할 때만 host 줄이 띠 안에 든다. 양수 세로 오프셋이면 host 줄은 개체 위에
    // 따로 놓인다(PrEP 3.214: `sw=0` 이지만 오프셋 504HU, 한/글 캡션 위치는 종전 전진과 일치).
    if common.treat_as_char
        || !matches!(common.text_wrap, TextWrap::TopAndBottom)
        || !matches!(common.vert_rel_to, VertRelTo::Para)
        || crate::renderer::float_placement::signed_hwpunit(common.vertical_offset) != 0
    {
        return false;
    }
    let has_visible_text = para.text.chars().any(|c| c > '\u{001F}' && c != '\u{FFFC}');
    if has_visible_text || para.line_segs.len() != 1 {
        return false;
    }
    let seg = &para.line_segs[0];
    seg.tag & crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0
        && seg.segment_width == 0
}

/// [#6888] **자기 앵커보다 아래로 떨어진 자리차지(TopAndBottom) 개체**인가.
///
/// `#409` 는 비-TAC · `vert=Para` · TopAndBottom 개체가 뒤따르는 콘텐츠를 개체 높이만큼
/// 밀어낸다고 보고 조판·배치 양쪽에서 그 높이를 흐름에 계상한다. 그 전제는 밴드가
/// **앵커에서 시작할 때**(`vertOffset == 0`) 참이다. 양수 오프셋이 밴드를 아래로 내려
/// 놓으면 그 사이에 들어갈 콘텐츠는 밀릴 이유가 없다.
///
/// 판별은 문서가 준다 — **다음 문단의 저장 `vpos` 가 이 문단 마지막 줄 바로 뒤**면
/// 한글이 개체 자리를 만들어 주지 않았다는 증언이다.
///
/// ```text
///   156730935 1쪽  도형 h=62.7px  vOff=150.3px (TopAndBottom, vert=Para)
///   p17 마지막 vpos 61789 + lh 1400 + ls 420 = 63609
///   p18 저장 vpos                            63609      ← 틈 0
///   종전: 흐름·배치가 각각 +62.7px  → 담당자 표가 본문을 49.3px 넘어 사라진다
///   정본: 표 945.2..1013.6(본문 안) · 도형 1018.7(표 아래)
/// ```
///
/// 조판(`typeset`)과 배치(`layout`)가 **같은 답**을 써야 `#409` 가 막으려던 desync 가
/// 생기지 않으므로 한 곳에 둔다.
pub(crate) fn topbottom_float_displaced_below_following_flow(
    para: &crate::model::paragraph::Paragraph,
    next_para: Option<&crate::model::paragraph::Paragraph>,
    common: &crate::model::shape::CommonObjAttr,
    dpi: f64,
) -> bool {
    use crate::model::shape::{TextWrap, VertRelTo};

    if common.treat_as_char
        || !matches!(common.text_wrap, TextWrap::TopAndBottom)
        || !matches!(common.vert_rel_to, VertRelTo::Para)
    {
        return false;
    }
    let v_off = hwpunit_to_px(
        crate::renderer::float_placement::signed_hwpunit(common.vertical_offset),
        dpi,
    );
    if v_off <= 0.5 {
        return false;
    }
    // 밴드 상단 = 앵커 문단의 첫 줄 + 세로 오프셋. 저장 사다리와 같은 좌표계다.
    let Some(anchor_vpos) = para.line_segs.first().map(|seg| seg.vertical_pos) else {
        return false;
    };
    let band_top = anchor_vpos.saturating_add(crate::renderer::float_placement::signed_hwpunit(
        common.vertical_offset,
    ));

    next_para
        .and_then(|next| next.line_segs.last())
        .is_some_and(|next_last| {
            // 다음 문단이 사다리에서 차지하는 바닥. 밴드가 **그 아래에서** 시작하면
            // 사이에 들어갈 콘텐츠가 밀릴 이유가 없다. "틈이 없다"보다 강한 조건이다 —
            // 오프셋이 작아 밴드가 다음 콘텐츠와 겹치면 종전대로 밀어낸다.
            let next_bottom = next_last
                .vertical_pos
                .saturating_add(next_last.line_height.max(0));
            next_last.vertical_pos > anchor_vpos && band_top >= next_bottom
        })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_render_backend_from_str() {
        assert_eq!(
            RenderBackend::from_str("canvas"),
            Some(RenderBackend::Canvas)
        );
        assert_eq!(RenderBackend::from_str("svg"), Some(RenderBackend::Svg));
        assert_eq!(RenderBackend::from_str("html"), Some(RenderBackend::Html));
        assert_eq!(RenderBackend::from_str("unknown"), None);
    }

    #[test]
    fn test_hwpunit_to_px() {
        // 1인치 = 7200 HWPUNIT, 96 DPI → 96px
        let px = hwpunit_to_px(7200, 96.0);
        assert!((px - 96.0).abs() < 0.01);
    }

    #[test]
    fn test_script_draw_metrics_matches_shared_contract() {
        // [#2771] SVG/Canvas/HTML/Skia/paint JSON 이 공유하는 첨자 계약:
        // 글꼴 0.7 배 + baseline 위 0.3em / 아래 0.15em.
        let base = TextStyle {
            font_size: 20.0,
            ..Default::default()
        };

        let sup = TextStyle {
            superscript: true,
            ..base.clone()
        };
        let (sup_size, sup_y) = sup.script_draw_metrics(20.0, 100.0);
        assert!(
            (sup_size - 14.0).abs() < 1e-9,
            "위첨자 글꼴은 0.7 배여야 함: {sup_size}"
        );
        assert!(
            (sup_y - 94.0).abs() < 1e-9,
            "위첨자 baseline 은 0.3em 위여야 함: {sup_y}"
        );

        let sub = TextStyle {
            subscript: true,
            ..base.clone()
        };
        let (sub_size, sub_y) = sub.script_draw_metrics(20.0, 100.0);
        assert!(
            (sub_size - 14.0).abs() < 1e-9,
            "아래첨자 글꼴은 0.7 배여야 함: {sub_size}"
        );
        assert!(
            (sub_y - 103.0).abs() < 1e-9,
            "아래첨자 baseline 은 0.15em 아래여야 함: {sub_y}"
        );

        // 비첨자는 인자를 그대로 돌려준다.
        assert_eq!(base.script_draw_metrics(20.0, 100.0), (20.0, 100.0));
    }

    #[test]
    fn positive_distribution_spacing_is_not_part_of_glyph_fit_advance() {
        let positive = TextStyle {
            extra_char_spacing: 12.0,
            ..Default::default()
        };
        assert_eq!(positive.glyph_fit_advance(20.0), Some(8.0));

        let zero = TextStyle::default();
        assert_eq!(zero.glyph_fit_advance(8.0), Some(8.0));

        let negative = TextStyle {
            extra_char_spacing: -3.0,
            ..Default::default()
        };
        assert_eq!(negative.glyph_fit_advance(5.0), Some(5.0));
    }

    #[test]
    fn issue_2809_negative_letter_spacing_does_not_compress_canvas_glyph() {
        let style = TextStyle {
            letter_spacing: -7.5,
            ..Default::default()
        };
        assert_eq!(canvas_cluster_fit_scale(&style, 7.5, 15.0, false), None);
        assert_eq!(canvas_cluster_fit_scale(&style, 7.5, 15.0, true), None);
    }

    #[test]
    fn non_negative_letter_spacing_keeps_existing_canvas_font_fit_policy() {
        let style = TextStyle::default();
        assert_eq!(
            canvas_cluster_fit_scale(&style, 7.5, 15.0, false),
            Some(0.5)
        );
        assert_eq!(canvas_cluster_fit_scale(&style, 7.5, 15.0, true), Some(0.5));
        assert_eq!(canvas_cluster_fit_scale(&style, 15.0, 14.9, false), None);
    }

    #[test]
    fn distribution_spacing_does_not_resize_ascii_canvas_glyph() {
        let positive = TextStyle {
            extra_char_spacing: 12.0,
            ..Default::default()
        };
        assert_eq!(
            canvas_cluster_fit_scale(&positive, 20.0, 8.0, true),
            Some(1.0)
        );

        let negative = TextStyle {
            extra_char_spacing: -3.0,
            ..Default::default()
        };
        assert_eq!(
            canvas_cluster_fit_scale(&negative, 5.0, 8.0, true),
            Some(0.625)
        );
        assert_eq!(
            canvas_cluster_fit_scale(&negative, 5.0, 8.0, false),
            Some(0.625)
        );
    }

    #[test]
    fn test_script_advance_scale_is_exact_identity_for_non_script() {
        // [#2771] 비첨자 배율이 **정확히 1.0** 이어야 기존 golden SVG 의
        // textLength 값이 비트 단위로 보존된다 (`x * 1.0` 은 IEEE-754 상
        // 반올림이 없는 항등 연산).
        let base = TextStyle {
            font_size: 20.0,
            ..Default::default()
        };
        assert_eq!(base.script_advance_scale(), 1.0);
        for advance in [0.0_f64, 6.2133, 1e-300, 1e300, f64::MIN_POSITIVE] {
            assert_eq!(
                (advance * base.script_advance_scale()).to_bits(),
                advance.to_bits(),
                "비첨자 advance 는 비트 단위로 불변이어야 함: {advance}"
            );
        }

        // [#5756] 첨자 run 의 레이아웃 advance 가 그리기 배율(0.7)로 측정되므로
        // fit 배율은 첨자에서도 항등(1.0)이다 — 0.7 을 또 곱하면 이중 축소.
        let sup = TextStyle {
            superscript: true,
            ..base.clone()
        };
        let sub = TextStyle {
            subscript: true,
            ..base.clone()
        };
        for style in [&sup, &sub] {
            assert_eq!(style.script_advance_scale(), 1.0);
            // 그리기 글꼴은 여전히 0.7 배 축소다.
            assert_eq!(style.script_draw_metrics(20.0, 0.0).0, 20.0 * 0.7);
        }
    }

    // [#7079] 합성 TAC 줄의 leading 은 호스트 문단의 글자 크기·문단 줄간격에서 나온다.
    // 글자모양 0번을 `font_size` px, 문단모양을 Percent `percent` 로 세운 스타일 세트.
    fn tac_styles(
        font_size: f64,
        percent: f64,
    ) -> (
        crate::renderer::style_resolver::ResolvedStyleSet,
        crate::renderer::style_resolver::ResolvedParaStyle,
    ) {
        let mut styles = crate::renderer::style_resolver::ResolvedStyleSet::default();
        let char_style = crate::renderer::style_resolver::ResolvedCharStyle {
            font_size,
            ..Default::default()
        };
        styles.char_styles.push(char_style);
        let para_style = crate::renderer::style_resolver::ResolvedParaStyle {
            line_spacing_type: crate::model::style::LineSpacingType::Percent,
            line_spacing: percent,
            ..Default::default()
        };
        (styles, para_style)
    }

    // [#2287] 저장 LINE_SEG 없는 빈 anchor 문단의 TAC 그림 줄 메트릭 합성.
    // [#7079] leading 은 문단의 글자모양에서 나오므로 실제 문서처럼 0번 글자모양을 단다.
    fn tac_picture_para(sizes_hu: &[(i32, i32)]) -> crate::model::paragraph::Paragraph {
        use crate::model::control::Control;
        let mut para = crate::model::paragraph::Paragraph::default();
        para.char_shapes
            .push(crate::model::paragraph::CharShapeRef {
                start_pos: 0,
                char_shape_id: 0,
            });
        for (w, h) in sizes_hu {
            let mut pic = crate::model::image::Picture::default();
            pic.common.treat_as_char = true;
            pic.common.width = *w as u32;
            pic.common.height = *h as u32;
            para.controls.push(Control::Picture(Box::new(pic)));
        }
        para
    }

    #[test]
    fn test_tac_object_stack_single_picture_line() {
        // 590×387px 그림 1장 (미래부 정서분석 pi854 형상) — 1줄, 그림 높이.
        let para = tac_picture_para(&[(44222, 29069)]);
        let (styles, para_style) = tac_styles(20.0, 100.0);
        let lines =
            tac_object_stack_line_metrics(&para, 96.0, Some(661.0), &styles, Some(&para_style))
                .unwrap();
        assert_eq!(lines.len(), 1);
        assert!((lines[0].0 - hwpunit_to_px(29069, 96.0)).abs() < 0.01);
        // 100% 는 여분이 없다.
        assert_eq!(lines[0].1, 0.0);

        // [#7079] leading 은 호스트 문단의 글자·퍼센트에서 나온다.
        // 156060125 2쪽: 글자 20.0px · 150% → 10.0px (저장 사다리 752HU).
        let para_fsc = tac_picture_para(&[(44852, 29997)]);
        let (styles_fsc, ps_fsc) = tac_styles(20.0, 150.0);
        let fsc =
            tac_object_stack_line_metrics(&para_fsc, 96.0, Some(661.0), &styles_fsc, Some(&ps_fsc))
                .unwrap();
        assert!((fsc[0].0 - hwpunit_to_px(29997, 96.0)).abs() < 0.01);
        assert!((fsc[0].1 - 10.0).abs() < 0.01, "{:?}", fsc[0]);

        // 156596828 1쪽: 글자 16.0px · 160% → 9.6px (저장 사다리 720HU). 개체 높이가
        // 14배 작아도 같은 값이다 — leading 은 개체가 아니라 글자에서 나온다.
        let para_mafra = tac_picture_para(&[(10435, 2023)]);
        let (styles_mafra, ps_mafra) = tac_styles(16.0, 160.0);
        let mafra = tac_object_stack_line_metrics(
            &para_mafra,
            96.0,
            Some(661.0),
            &styles_mafra,
            Some(&ps_mafra),
        )
        .unwrap();
        assert!((mafra[0].0 - hwpunit_to_px(2023, 96.0)).abs() < 0.01);
        assert!((mafra[0].1 - 9.6).abs() < 0.01, "{:?}", mafra[0]);

        // 문단모양을 못 찾으면 종전대로 0 이다.
        let no_style =
            tac_object_stack_line_metrics(&para_fsc, 96.0, Some(661.0), &styles_fsc, None).unwrap();
        assert_eq!(no_style[0].1, 0.0);
    }

    #[test]
    fn test_tac_object_stack_wraps_by_width() {
        // 590px 그림 3장, 가용 661px — 줄당 1장씩 3줄 (농촌 S-OJT 스택 형상).
        let para = tac_picture_para(&[(44222, 29069); 3]);
        let (styles, para_style) = tac_styles(20.0, 150.0);
        let lines =
            tac_object_stack_line_metrics(&para, 96.0, Some(661.0), &styles, Some(&para_style))
                .unwrap();
        assert_eq!(lines.len(), 3);
        // leading 은 줄마다 같은 몫이다.
        assert!(lines.iter().all(|(_, ls)| (ls - 10.0).abs() < 0.01));
        // 300px 그림 2장, 가용 661px — 한 줄 수용.
        let para2 = tac_picture_para(&[(22000, 10000), (22000, 12000)]);
        let lines2 =
            tac_object_stack_line_metrics(&para2, 96.0, Some(661.0), &styles, Some(&para_style))
                .unwrap();
        assert_eq!(lines2.len(), 1);
        assert!((lines2[0].0 - hwpunit_to_px(12000, 96.0)).abs() < 0.01);
    }

    #[test]
    fn test_tac_object_stack_rejects_stored_ls_and_non_tac() {
        let (styles, para_style) = tac_styles(20.0, 150.0);
        // 저장 LINE_SEG 보유 문단 제외 (이중 계상 방지).
        let mut para = tac_picture_para(&[(44222, 29069)]);
        para.line_segs
            .push(crate::model::paragraph::LineSeg::default());
        assert!(tac_object_stack_line_metrics(
            &para,
            96.0,
            Some(661.0),
            &styles,
            Some(&para_style)
        )
        .is_none());
        // 비-TAC 그림 제외 (PageItem::Shape 오버레이 경로 유지).
        let mut para2 = tac_picture_para(&[(44222, 29069)]);
        if let crate::model::control::Control::Picture(pic) = &mut para2.controls[0] {
            pic.common.treat_as_char = false;
        }
        assert!(tac_object_stack_line_metrics(
            &para2,
            96.0,
            Some(661.0),
            &styles,
            Some(&para_style)
        )
        .is_none());
        // [#7079] 합성 tag seg 를 가진 문단은 높이 합성은 그대로(#2287) 두되 leading 은
        // 0 이다 — 그 seg 의 baseline 이 개체 배치의 근거라 leading 을 얹으면 개체가
        // 밀린다 (#6708 tac-img-02: 글자 264px → 158px).
        let mut para3 = tac_picture_para(&[(44222, 29069)]);
        para3.line_segs.push(crate::model::paragraph::LineSeg {
            tag: crate::model::paragraph::LineSeg::TAG_IMPLEMENTATION_PROPERTY,
            ..Default::default()
        });
        assert_eq!(
            tac_object_stack_line_leading_px(&para3, &styles, Some(&para_style)),
            0.0
        );
        let synth =
            tac_object_stack_line_metrics(&para3, 96.0, Some(661.0), &styles, Some(&para_style))
                .expect("합성 tag seg 문단도 높이 합성은 유지한다");
        assert!((synth[0].0 - hwpunit_to_px(29069, 96.0)).abs() < 0.01);
        assert_eq!(synth[0].1, 0.0);
    }

    #[test]
    fn test_px_to_hwpunit() {
        let hu = px_to_hwpunit(96.0, 96.0);
        assert_eq!(hu, 7200);
    }

    #[test]
    fn test_source_line_metrics_reflow_when_text_height_is_implausible() {
        let max_fs = hwpunit_to_px(1000, 96.0);
        let raw_h = hwpunit_to_px(68800, 96.0);
        let (line_height, line_spacing) = corrected_line_metrics_for_source(
            raw_h,
            raw_h,
            0.0,
            max_fs,
            LineSpacingType::Percent,
            160.0,
            true,
            true,
        );

        assert!((line_height - max_fs).abs() < 0.01);
        assert!((line_spacing - max_fs * 0.6).abs() < 0.01);
    }

    #[test]
    fn test_source_line_metrics_keep_normal_stored_height() {
        let max_fs = hwpunit_to_px(1000, 96.0);
        let stored_h = hwpunit_to_px(3000, 96.0);
        let (line_height, line_spacing) = corrected_line_metrics_for_source(
            stored_h,
            stored_h,
            0.0,
            max_fs,
            LineSpacingType::Percent,
            160.0,
            true,
            false,
        );

        assert!((line_height - stored_h).abs() < 0.01);
        assert_eq!(line_spacing, 0.0);
    }

    #[test]
    fn test_source_line_metrics_preserve_intentional_tall_section_line() {
        let max_fs = hwpunit_to_px(1000, 96.0);
        let intentional_tall_line = hwpunit_to_px(55000, 96.0);

        assert!(!source_line_metrics_need_reflow(
            intentional_tall_line,
            intentional_tall_line,
            max_fs,
            LineSpacingType::Percent,
            160.0,
            true,
        ));
    }

    #[test]
    fn test_source_line_metrics_reflow_replaces_stale_baseline() {
        let max_fs = hwpunit_to_px(1000, 96.0);
        let stale_baseline = hwpunit_to_px(58480, 96.0);

        let baseline = corrected_line_baseline_for_source(stale_baseline, max_fs, true);

        assert!((baseline - max_fs * 0.85).abs() < 0.01);
        assert!(baseline < stale_baseline / 10.0);
    }

    #[test]
    fn test_structural_controls_mark_section_start() {
        assert!(controls_mark_section_start(&[
            Control::SectionDef(Box::default()),
            Control::ColumnDef(Default::default()),
        ]));
        assert!(!controls_mark_section_start(&[]));
    }

    #[test]
    fn test_a4_page_size_px() {
        // A4: 210mm × 297mm = 59528 × 84188 HWPUNIT
        let w = hwpunit_to_px(59528, 96.0);
        let h = hwpunit_to_px(84188, 96.0);
        // A4 @ 96DPI ≈ 793.7 × 1122.5 px
        assert!((w - 793.7).abs() < 1.0);
        assert!((h - 1122.5).abs() < 1.0);
    }

    /// [Task #1745] 텍스트 혼합 anchor: 표 geometry 로 wrap 띠 도출
    #[test]
    fn test_text_anchor_square_table_strip_derives_from_geometry() {
        use crate::model::control::Control;
        use crate::model::paragraph::{LineSeg, Paragraph};
        use crate::model::shape::TextWrap;
        use crate::model::table::Table;

        let mut table = Table::default();
        table.common.treat_as_char = false;
        table.common.text_wrap = TextWrap::Square;
        table.common.horizontal_offset = 0;
        table.common.width = 45002;
        table.common.margin.left = 283;
        table.common.margin.right = 283;

        let mut para = Paragraph::default();
        para.text = "■ 약사법 시행령 [별표 2]".to_string();
        para.line_segs.push(LineSeg {
            column_start: 0,
            segment_width: 48188,
            ..Default::default()
        });
        para.controls.push(Control::Table(Box::new(table)));

        // samples/task1745: cs=45568(=45002+283×2), sw=2620(=48188−45568)
        assert_eq!(text_anchor_square_table_strip(&para), Some((45568, 2620)));
    }

    /// [Task #1745] 표 단독 anchor(첫 seg 가 이미 wrap 띠) — None (기존 경로 유지)
    #[test]
    fn test_text_anchor_square_table_strip_none_for_table_only_anchor() {
        use crate::model::control::Control;
        use crate::model::paragraph::{LineSeg, Paragraph};
        use crate::model::shape::TextWrap;
        use crate::model::table::Table;

        let mut table = Table::default();
        table.common.treat_as_char = false;
        table.common.text_wrap = TextWrap::Square;
        table.common.width = 20000;

        // 표 단독 anchor: 첫 LINE_SEG 가 이미 띠 (cs>0)
        let mut para = Paragraph::default();
        para.text = " ".to_string();
        para.line_segs.push(LineSeg {
            column_start: 20600,
            segment_width: 27000,
            ..Default::default()
        });
        para.controls.push(Control::Table(Box::new(table.clone())));
        assert_eq!(text_anchor_square_table_strip(&para), None);

        // 텍스트 없는 anchor — None
        let mut para2 = Paragraph::default();
        para2.text = String::new();
        para2.line_segs.push(LineSeg {
            column_start: 0,
            segment_width: 48188,
            ..Default::default()
        });
        para2.controls.push(Control::Table(Box::new(table.clone())));
        assert_eq!(text_anchor_square_table_strip(&para2), None);

        // 띠 폭이 남지 않는 표(전폭) — None
        let mut wide = table.clone();
        wide.common.width = 48188;
        let mut para3 = Paragraph::default();
        para3.text = "제목".to_string();
        para3.line_segs.push(LineSeg {
            column_start: 0,
            segment_width: 48188,
            ..Default::default()
        });
        para3.controls.push(Control::Table(Box::new(wide)));
        assert_eq!(text_anchor_square_table_strip(&para3), None);
    }

    #[test]
    fn test_auto_number_counter() {
        let mut counter = AutoNumberCounter::new();
        assert_eq!(counter.increment(AutoNumberType::Picture), 1);
        assert_eq!(counter.increment(AutoNumberType::Picture), 2);
        assert_eq!(counter.increment(AutoNumberType::Table), 1);
        assert_eq!(counter.current(AutoNumberType::Picture), 2);
        assert_eq!(counter.current(AutoNumberType::Table), 1);
        counter.reset();
        assert_eq!(counter.current(AutoNumberType::Picture), 0);
    }

    #[test]
    fn test_format_number_digit() {
        assert_eq!(format_number(1, NumberFormat::Digit), "1");
        assert_eq!(format_number(123, NumberFormat::Digit), "123");
    }

    #[test]
    fn test_format_number_circled() {
        assert_eq!(format_number(1, NumberFormat::CircledDigit), "①");
        assert_eq!(format_number(10, NumberFormat::CircledDigit), "⑩");
        assert_eq!(format_number(20, NumberFormat::CircledDigit), "⑳");
        assert_eq!(format_number(21, NumberFormat::CircledDigit), "21");
    }

    #[test]
    fn test_format_number_roman() {
        assert_eq!(format_number(1, NumberFormat::RomanUpper), "I");
        assert_eq!(format_number(4, NumberFormat::RomanUpper), "IV");
        assert_eq!(format_number(9, NumberFormat::RomanUpper), "IX");
        assert_eq!(format_number(10, NumberFormat::RomanLower), "x");
        assert_eq!(format_number(14, NumberFormat::RomanLower), "xiv");
    }

    #[test]
    fn test_format_number_latin() {
        assert_eq!(format_number(1, NumberFormat::LatinUpper), "A");
        assert_eq!(format_number(26, NumberFormat::LatinUpper), "Z");
        assert_eq!(format_number(27, NumberFormat::LatinUpper), "AA");
        assert_eq!(format_number(1, NumberFormat::LatinLower), "a");
    }

    /// [#3314] 굵기 접미사 face 의 base family 추출과 렌더 체인 삽입.
    #[test]
    fn test_base_family_without_weight_suffix() {
        assert_eq!(
            base_family_without_weight_suffix("Noto Serif KR Black").as_deref(),
            Some("Noto Serif KR")
        );
        assert_eq!(
            base_family_without_weight_suffix("나눔고딕 Bold").as_deref(),
            Some("나눔고딕")
        );
        assert_eq!(
            base_family_without_weight_suffix("경기천년제목 Light").as_deref(),
            Some("경기천년제목")
        );
        // 두 토큰 접미사 ("Extra Bold")
        assert_eq!(
            base_family_without_weight_suffix("Noto Sans KR Extra Bold").as_deref(),
            Some("Noto Sans KR")
        );
        // 접미사 없음 → None (체인 불변)
        assert_eq!(base_family_without_weight_suffix("맑은 고딕"), None);
        assert_eq!(base_family_without_weight_suffix("HY헤드라인M"), None);
        assert_eq!(base_family_without_weight_suffix("휴먼명조"), None);
        // 전체가 접미사 토큰뿐이면 벗기지 않는다
        assert_eq!(base_family_without_weight_suffix("Light"), None);
        // 렌더 체인: 요청 face → base → generic
        let chain = render_font_family_chain("Noto Serif KR Black");
        assert!(chain.starts_with("'Noto Serif KR Black','Noto Serif KR',"));
        let plain = render_font_family_chain("맑은 고딕");
        assert!(plain.starts_with("'맑은 고딕','Malgun Gothic'"));
        assert!(render_font_family_chain("Tom's Handwriting")
            .starts_with("'Tom\\'s Handwriting','Malgun Gothic'"));
        assert!(
            render_font_family_chain(r"Legacy\Face").starts_with(r"'Legacy\\Face','Malgun Gothic'")
        );

        // [#6171] `HYGothic` 이 빠지면 `『별표 7』`의 `『`(중고딕 run)이 Windows 에서
        // Malgun 으로 떨어진다. `HY중고딕`·`HYGothic-Medium` 은 DirectWrite 가 안 잡고
        // 접미사를 뗀 `HYGothic` 만 잡히므로, 두 이름 뒤에 반드시 와야 한다.
        assert_eq!(
            render_font_family_chain("한양중고딕"),
            format!(
                "'한양중고딕','HY중고딕','HYGothic','HYGothic-Medium','HCR Dotum','함초롬돋움',{}",
                generic_fallback("한양중고딕")
            )
        );
        assert_eq!(
            render_font_family_chain("HY중고딕"),
            format!(
                "'HY중고딕','HYGothic','HYGothic-Medium','HCR Dotum','함초롬돋움','Malgun Gothic',{}",
                generic_fallback("HY중고딕")
            )
        );

        // [#6171] 견고딕/견명조도 legacy name 뒤에 설치 face 이름이 와야 한다. 이 arm 이
        // 없으면 체인이 곧바로 generic 으로 떨어져 `HY견고딕` 설치본이 있어도 Malgun
        // Gothic 이 잡힌다 — 3146683 1쪽 `『별표 7』`의 `별표` 획 굵기 회귀.
        assert_eq!(
            render_font_family_chain("한양견고딕"),
            format!(
                "'한양견고딕','HY견고딕','HYGothic-Extra','HCR Dotum','함초롬돋움',{}",
                generic_fallback("한양견고딕")
            )
        );
        assert_eq!(
            render_font_family_chain("한양견명조"),
            format!(
                "'한양견명조','HY견명조','HYMyeongJo-Extra','HCR Batang','함초롬바탕',{}",
                generic_fallback("한양견명조")
            )
        );
        // 신명조도 같은 짝이다. 이 arm 이 없으면 체인이 `'한양신명조','Batang',…` 로
        // 떨어져 `HY신명조`(H2MJSM.TTF) 설치본을 건너뛴다 — 156573118 8쪽 텍스트 런 600개.
        // [#6263] 문서가 `HY…` 이름을 직접 쓰는 경우도 접미사를 뗀 이름이 앞에 와야
        // 한다. 한국어 이름·`-Medium` 원문은 Windows 에서 둘 다 안 잡힌다(실측 0px).
        assert!(render_font_family_chain("HY신명조").starts_with("'HY신명조','HYSinMyeongJo',"));
        assert!(render_font_family_chain("HY헤드라인M").starts_with("'HY헤드라인M','HYHeadLine',"));
        assert!(render_font_family_chain("HY그래픽M").starts_with("'HY그래픽M','HYGraphic',"));

        assert_eq!(
            render_font_family_chain("한양신명조"),
            format!(
                "'한양신명조','HYSinMyeongJo','HY신명조','HYSinMyeongJo-Medium',{}",
                generic_fallback("한양신명조")
            )
        );

        assert_eq!(
            canvas_font_family_chain("Noto Serif KR Black"),
            format!(
                "\"Noto Serif KR Black\", \"Noto Serif KR\", {}",
                generic_fallback("Noto Serif KR Black")
            )
        );
        // [#6171] studio(canvas) 축도 SVG 와 같은 별칭 표를 쓰므로 `HYGothic` 이 들어간다.
        assert_eq!(
            canvas_font_family_chain("HY중고딕"),
            format!(
                "\"HY중고딕\", \"HYGothic\", \"HYGothic-Medium\", \"HCR Dotum\", \"함초롬돋움\", \"Malgun Gothic\", {}",
                generic_fallback("HY중고딕")
            )
        );
        assert_eq!(
            canvas_font_family_chain("맑은 고딕"),
            format!("\"맑은 고딕\", {}", generic_fallback("맑은 고딕"))
        );

        let government = "정부상징 부처명_16040911,한컴바탕";
        assert!(render_font_family_chain(government).starts_with(
            "'정부상징 부처명_16040911','ROKG','ROKG R','대한민국정부상징체',\
             '대한민국정부상징체 R','ROKGR','한컴바탕',"
        ));
        assert!(canvas_font_family_chain(government).starts_with(
            "\"정부상징 부처명_16040911\", \"ROKG\", \"ROKG R\", \
             \"대한민국정부상징체\", \"대한민국정부상징체 R\", \"ROKGR\", \"한컴바탕\", "
        ));
    }

    #[test]
    fn test_generic_fallback() {
        let serif = "'Batang','바탕','Nanum Myeongjo','AppleMyungjo','Noto Serif KR','Noto Serif CJK KR','HCR Batang','함초롬바탕','HCR Batang Ext','함초롬바탕 확장','HCR Batang ExtB','함초롬바탕 확장B','Source Han Serif K Old Hangul',serif";
        let sans = "'Malgun Gothic','맑은 고딕','Apple SD Gothic Neo','Noto Sans KR ExtraLight','Noto Sans KR','Pretendard','HCR Batang','함초롬바탕','HCR Batang Ext','함초롬바탕 확장','HCR Batang ExtB','함초롬바탕 확장B','Source Han Serif K Old Hangul',sans-serif";
        // Task #1224: ExtraLight 가 무거운 Noto 직전에 위치하는지 명시 검증
        assert!(sans.contains("'Noto Sans KR ExtraLight','Noto Sans KR'"));
        // [#4086] 하이픈 표기는 어떤 폰트와도 매칭되지 않는다 — 실제 패밀리명은
        // `HCR Batang ExtB` (HANBatangExtB.ttf name table nid1/lid0x409 실측).
        for chain in [serif, sans] {
            assert!(
                !chain.contains("Ext-B"),
                "죽은 하이픈 표기가 되살아났다: {chain}"
            );
            assert!(chain.contains("'HCR Batang ExtB'"));
            // PUA 원문자(U+F02B1~F02C4)의 소재는 **일반**이다. 목적이 드러나도록
            // 일반을 확장/확장B 앞에 둔다(담당 대역이 겹치지 않아 매칭 결과는 불변).
            let plain = chain.find("'HCR Batang','함초롬바탕'").expect("일반 항목");
            let ext = chain.find("'HCR Batang Ext'").expect("확장 항목");
            let extb = chain.find("'HCR Batang ExtB'").expect("확장B 항목");
            assert!(
                plain < ext && ext < extb,
                "체인 순서가 일반→확장→확장B 가 아니다"
            );
        }
        let mono = "'GulimChe','굴림체','D2Coding','Noto Sans Mono',monospace";
        // 세리프 계열
        assert_eq!(generic_fallback("함초롬바탕"), serif);
        assert_eq!(generic_fallback("바탕"), serif);
        assert_eq!(generic_fallback("궁서"), serif);
        assert_eq!(generic_fallback("HY견명조"), serif);
        assert_eq!(generic_fallback("Times New Roman"), serif);
        assert_eq!(generic_fallback("Palatino Linotype"), serif);
        // KoPub바탕체는 이름에 "바탕체"가 들어가지만 고정폭 BatangChe가 아니라
        // 비례폭 본문/제목용 세리프 계열이다.
        assert_eq!(generic_fallback("KoPub바탕체 Light"), serif);
        assert_eq!(generic_fallback("KoPub바탕체 Medium"), serif);
        assert_eq!(generic_fallback("KoPub Batang Medium"), serif);
        // 산세리프 계열
        assert_eq!(generic_fallback("함초롬돋움"), sans);
        assert_eq!(generic_fallback("돋움"), sans);
        assert_eq!(generic_fallback("굴림"), sans);
        assert_eq!(generic_fallback("Arial"), sans);
        assert_eq!(generic_fallback("맑은 고딕"), sans);
        assert!(generic_fallback("KoPub돋움체 Light")
            .starts_with("'Noto Sans KR ExtraLight','Malgun Gothic'"));
        assert!(generic_fallback("KoPub Dotum Light")
            .starts_with("'Noto Sans KR ExtraLight','Malgun Gothic'"));
        // 고정폭 계열
        assert_eq!(generic_fallback("굴림체"), mono);
        assert_eq!(generic_fallback("바탕체"), serif);
        assert_eq!(generic_fallback("BatangChe"), serif);
        assert_eq!(generic_fallback("Courier New"), mono);
        assert_eq!(generic_fallback("D2Coding ligature"), mono);
        assert_eq!(generic_fallback("Noto Sans Mono"), mono);
        // 영문 세리프 (issue #616)
        assert_eq!(generic_fallback("Noto Serif CJK SC"), serif);
        assert_eq!(generic_fallback("Liberation Serif"), serif);
        assert_eq!(generic_fallback("Noto Serif KR"), serif);
        // "sans" 포함 폰트는 세리프로 분류되지 않음
        assert_eq!(generic_fallback("Liberation Sans"), sans);
        assert_eq!(generic_fallback("Noto Sans KR"), sans);
        // 빈 문자열
        assert_eq!(generic_fallback(""), sans);
    }

    #[test]
    fn boxed_pua_number_covers_hancom_square_digits() {
        assert_eq!(boxed_pua_number('\u{F02B1}'), Some(1));
        assert_eq!(boxed_pua_number('\u{F02BA}'), Some(10));
        assert_eq!(boxed_pua_number('\u{F02C4}'), Some(20));
        // [#6127] U+F02B0 = 네모 안 0 (2599643 실측 "②⓪⓪").
        assert_eq!(boxed_pua_number('\u{F02B0}'), Some(0));
        assert_eq!(boxed_pua_number('\u{F02AF}'), None);
        assert_eq!(boxed_pua_number('\u{F02C5}'), None);
        assert_eq!(boxed_pua_number('1'), None);
    }

    #[test]
    fn boxed_pua_char_overlap_promotes_only_implicit_square_border() {
        assert_eq!(
            boxed_pua_char_overlap_semantics(&['\u{F02B1}'], 0),
            Some((1, 3))
        );
        assert_eq!(
            boxed_pua_char_overlap_semantics(&['\u{F02C4}'], 0),
            Some((20, 3))
        );
        assert_eq!(
            boxed_pua_char_overlap_semantics(&['\u{F02B1}'], 1),
            Some((1, 1))
        );
        assert_eq!(
            boxed_pua_char_overlap_semantics(&['\u{F02B1}', '\u{F02B2}'], 0),
            None
        );
        assert_eq!(boxed_pua_char_overlap_semantics(&['1'], 0), None);
    }

    #[test]
    fn test_medium_weight_face() {
        use crate::renderer::style_resolver::is_medium_weight_face;
        assert!(is_medium_weight_face("HY중고딕"));
        assert!(is_medium_weight_face("신명 중고딕"));
        assert!(is_medium_weight_face("한양중고딕"));
        assert!(is_medium_weight_face("HY태고딕"));
        assert!(is_medium_weight_face("신명 태고딕"));
        assert!(!is_medium_weight_face("HY헤드라인M"));
        assert!(!is_medium_weight_face("돋움"));
        assert!(!is_medium_weight_face("바탕"));
        assert!(!is_medium_weight_face("맑은 고딕"));
        assert!(!is_medium_weight_face(""));
    }

    #[test]
    fn test_explicit_face_weight_hints() {
        let light = TextStyle {
            font_family: "KoPub돋움체 Light".to_string(),
            ..Default::default()
        };
        assert_eq!(light.css_font_weight(), Some("300"));

        let bold = TextStyle {
            font_family: "KoPub바탕체 Bold".to_string(),
            ..Default::default()
        };
        assert_eq!(bold.css_font_weight(), Some("bold"));
        assert!(bold.is_visually_bold());
    }

    #[test]
    fn test_format_number_hangul() {
        for (number, expected) in [(1, "ㄱ"), (2, "ㄴ"), (4, "ㄹ"), (14, "ㅎ")] {
            assert_eq!(format_number(number, NumberFormat::HangulJamo), expected);
        }
        assert_eq!(format_number(1, NumberFormat::HangulGaNaDa), "가");
        assert_eq!(format_number(2, NumberFormat::HangulGaNaDa), "나");
        assert_eq!(format_number(1, NumberFormat::HangulNumber), "일");
        assert_eq!(format_number(12, NumberFormat::HangulNumber), "십이");
    }
}

pub(crate) mod current_physical_selections;

pub(crate) mod current_frame_rows_plan;

// Current allocator facts only; no export or row permission.
pub mod selected_composition_observer127;

pub(crate) mod current_accepted_composition;

pub(crate) mod current_offset_frame;

pub(crate) mod current_equal_column_prefix;

pub(crate) mod current_empty_body143;

pub(crate) mod current_unequal_column_prefix139;
