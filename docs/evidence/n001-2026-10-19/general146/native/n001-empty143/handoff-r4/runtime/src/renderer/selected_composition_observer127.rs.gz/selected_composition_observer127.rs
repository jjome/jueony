//! Actual selected formatter inputs and accepted allocator facts.
//! These facts alone are NOT freshness, source/row/frame ownership, or export permits.
//! A diagnostic capture only copies finished facts and cannot populate the runtime arena.
use std::cell::{Cell,RefCell};
use serde::Serialize;
use crate::model::{paragraph::Paragraph,provenance::LayoutCompatibilityProfile};
use super::{composer::{ComposedParagraph,ComposedTextRun},pagination::{PageItem,PaginationResult}};

const MAX_FORMATS:usize=4096;
const MAX_COMMITS:usize=16384;
const MAX_BYTES:usize=16*1024*1024;
const MAX_TEXT:usize=2*1024*1024;
#[derive(Debug,Clone,Copy)]
pub(crate) struct SelectedObservationHandle { scope:u64,index:usize,full_empty:bool }
#[derive(Debug,Clone,Serialize)]
pub struct RunFact {
 pub text:String,pub display_text:Option<String>,pub char_style_id:u32,pub language:usize,
 pub overlap:Option<(u8,i8)>,pub footnote_marker:Option<u16>,
 pub supplemental_metrics_blocked:bool,pub inserted_control_text:bool,pub space_metric:&'static str,
 pub scalars:usize,pub utf16_units:usize,
}
#[derive(Debug,Clone,Serialize)]
pub struct LineFact {
 pub scalar_start:usize,pub scalar_end:Option<usize>,
 pub unicode_utf16_start:Option<u32>,pub unicode_utf16_end:Option<u32>,
 pub original_hwp_char_offset:Option<u32>,pub exact_source_text_span:bool,
 pub height_hu:i32,pub baseline_hu:i32,pub width_hu:i32,pub column_start_hu:i32,
 pub spacing_hu:i32,pub has_line_break:bool,pub runs:Vec<RunFact>,
}
#[derive(Debug,Clone,Serialize)]
pub struct SelectedFormatFact {
 pub observation_id:usize,pub paragraph_token:usize,pub actual_input_width_px:Option<f64>,pub dpi:f64,
 pub selected_recomposition:bool,pub definition_context:Option<[u8;32]>,pub profile:String,
 pub source_text:String,pub source_char_offsets:Vec<u32>,pub source_row_count:usize,
 pub paragraph_style:u16,pub lines:Vec<LineFact>,pub actual_heights:Vec<f64>,pub actual_spacings:Vec<f64>,
 pub before:f64,pub after:f64,pub total:f64,pub fit_height:f64,
 pub inline_controls:Vec<(usize,usize,String)>,pub tac_controls:Vec<(usize,i32,usize)>,
 pub footnote_positions:Vec<(usize,u16,usize)>,pub tab_extended:Vec<[u16;7]>,
 pub has_numbering:bool,pub has_horizontal_shaping:bool,pub known_square_band:bool,
 pub observed_not_fresh_or_authorized:bool,
}
#[derive(Debug,Clone,Serialize)]
pub struct CommitFact {
 pub format_id:usize,pub section:usize,pub page:Option<u32>,pub column:u16,pub paragraph:usize,
 pub paragraph_token_matches:bool,pub row_start:usize,pub row_end:usize,
 pub flow_before:f64,pub flow_after:f64,pub advance:f64,
 pub available_for_rows:Option<f64>,pub cumulative_fit:Option<f64>,pub trimmed_before:f64,
 pub actual_column_width_px:f64,pub reused_multicolumn_format:bool,
 pub same_format_reused_after_slot_change:bool,
 pub metrics_still_match_selected_format:bool,pub range_inside_selected_composition:bool,
 pub committed_item_index:Option<usize>,pub final_membership:Option<bool>,
 pub finalization_index:Option<usize>,pub not_physical_y:bool,
}
#[derive(Debug,Clone,Serialize)]
pub struct FinalizationFact {pub section:usize,pub pages:usize,pub commits_checked:usize,pub all_membership_exact:bool}
#[derive(Debug,Clone,Serialize)]
pub struct ResolvedFloatFact {pub flow:String,pub next_flow_y:Option<f64>,pub anchor_y:f64,
 pub stored_host_origin:Option<f64>,pub stored_successor_origin:Option<f64>,pub table_left:Option<f64>,pub table_top:f64,pub occupied_bottom:f64}
#[derive(Debug,Clone,Serialize)]
pub struct TableAcceptedFact {
 pub section:usize,pub page:Option<u32>,pub column:u16,pub paragraph:usize,pub control:usize,pub paragraph_token:usize,
 pub before:f64,pub body_height:f64,pub after_for_fit:f64,pub raw_top:f64,pub reserved_height:f64,
 pub x_start:f64,pub x_end:f64,pub lane_pushed_top:f64,pub paragraph_start:f64,
 pub flow_before:f64,pub flow_after:f64,pub actually_queried_available:Option<f64>,pub resolved:Option<ResolvedFloatFact>,
 pub committed_item_index:Option<usize>,pub final_membership:Option<bool>,pub finalization_index:Option<usize>,
 pub not_a_source_frame_lease:bool,
}
/// The whole block-table path has no empty-float lane/raw-top query. Keep its
/// actual inputs distinct rather than deriving fictitious placement values.
#[derive(Debug,Clone,Serialize)]
pub struct WholeTableAcceptedFact {
 pub section:usize,pub page:Option<u32>,pub column:u16,pub paragraph:usize,pub control:usize,pub paragraph_token:usize,
 pub selected_format_id:Option<usize>,pub table_total_height:f64,pub before:f64,pub body_height:f64,pub after_for_fit:f64,pub full_after:f64,
 pub paragraph_start:f64,pub flow_before:f64,pub flow_after:f64,pub post_page:Option<u32>,pub post_column:u16,
 pub pre_text_height:f64,pub pre_text_end:usize,pub selected_line_count:usize,pub is_first:bool,pub is_last:bool,
 pub strict_following_plain_text_fit:bool,pub resolved:Option<ResolvedFloatFact>,
 pub committed_item_index:usize,pub final_membership:Option<bool>,pub finalization_index:Option<usize>,
 pub not_a_source_frame_lease:bool,
}
#[derive(Debug,Clone,Serialize)]
pub struct SelectedCompositionReport {
 pub cookie:[u8;32],pub formats:Vec<SelectedFormatFact>,pub commits:Vec<CommitFact>,
 pub tables:Vec<TableAcceptedFact>,pub whole_tables:Vec<WholeTableAcceptedFact>,
 pub finalizations:Vec<FinalizationFact>,pub encoded_bytes:usize,
 pub overflowed:bool,pub unsupported_observed:bool,pub nested_rejected:bool,
 pub not_an_export_permission:bool,
}
const MAX_REQUIRED_BYTES:usize=16*1024*1024;
const MAX_REQUIRED_COMMITS:usize=4096;
struct RequiredBuilder {
 full_empty:bool,token:usize,paragraph:usize,formats:Vec<(SelectedFormatFact,std::sync::Arc<ComposedParagraph>)>,commits:Vec<CommitFact>,failed:bool,
}
/// Actual allocator-selected formatter objects needed by a remapped fragment.
/// This is paint data only: it is never installed as the full selected trace,
/// and cannot authorize row serialization, a source cache or an export lease.
#[derive(Debug)]
pub(crate) struct RequiredPlainPaint {
 trace:Option<std::sync::Arc<FinalizedSelectedCompositionTrace>>,
 paragraphs:Vec<(usize,usize)>,full_empty_tokens:Vec<usize>,
}
impl RequiredPlainPaint {
 pub(crate) fn paint_trace(&self)->Option<&std::sync::Arc<FinalizedSelectedCompositionTrace>>{self.trace.as_ref()}
 pub(crate) fn paragraph_bindings(&self)->&[(usize,usize)]{&self.paragraphs}
 pub(crate) fn full_empty_tokens(&self)->&[usize]{&self.full_empty_tokens}
}
struct Active {scope:u64,report:SelectedCompositionReport,compositions:Vec<Option<std::sync::Arc<ComposedParagraph>>>,
 required:Vec<RequiredBuilder>,required_bytes:usize}
thread_local! {
 static ACTIVE:RefCell<Option<Active>>=const {RefCell::new(None)};
 static NEXT_SCOPE:Cell<u64>=const {Cell::new(0)};
 static NEXT_PASS:Cell<u64>=const {Cell::new(0)};
 static RUNTIME_DEPTH:Cell<usize>=const {Cell::new(0)};
}
struct Scope;
impl Drop for Scope {fn drop(&mut self){ACTIVE.with(|a|{if let Ok(mut a)=a.try_borrow_mut(){*a=None;}})}}
pub fn capture_diagnostic_only<T>(cookie:[u8;32],run:impl FnOnce()->T)->Result<(T,SelectedCompositionReport),&'static str>{
 let scope=NEXT_SCOPE.with(|n|n.get().checked_add(1).map(|v|{n.set(v);v})).ok_or("scope sequence exhausted")?;
 let started=ACTIVE.with(|a|{let Ok(mut a)=a.try_borrow_mut()else{return false;};
  if let Some(a)=a.as_mut(){a.report.nested_rejected=true;return false;}
  *a=Some(Active{scope,compositions:vec![],required:vec![],required_bytes:0,report:SelectedCompositionReport{cookie,formats:vec![],commits:vec![],tables:vec![],whole_tables:vec![],finalizations:vec![],encoded_bytes:0,
   overflowed:false,unsupported_observed:false,nested_rejected:false,not_an_export_permission:true}});true});
 if !started{return Err("nested or reentrant observation");}
 let guard=Scope;let result=run();
 let report=ACTIVE.with(|a|a.try_borrow_mut().ok().and_then(|mut a|a.take())).ok_or("observation scope lost")?.report;
 drop(guard);Ok((result,report))
}
fn charge<T:Serialize>(r:&mut SelectedCompositionReport,value:&T)->bool{
 let Ok(bytes)=serde_json::to_vec(value)else{r.unsupported_observed=true;return false;};
 if bytes.len()>MAX_BYTES.saturating_sub(r.encoded_bytes){r.overflowed=true;return false;}
 r.encoded_bytes+=bytes.len();true
}
fn run_fact(run:&ComposedTextRun)->RunFact{
 let ComposedTextRun{text,char_style_id,lang_index,char_overlap,footnote_marker,display_text,
  supplemental_metrics_blocked,inserted_control_text,space_metric}=run;
 RunFact{text:text.clone(),display_text:display_text.clone(),char_style_id:*char_style_id,language:*lang_index,
  overlap:char_overlap.as_ref().map(|v|(v.border_type,v.inner_char_size)),footnote_marker:*footnote_marker,
  supplemental_metrics_blocked:*supplemental_metrics_blocked,inserted_control_text:*inserted_control_text,
  space_metric:match space_metric{super::composer::SpaceMetric::Stored=>"Stored",super::composer::SpaceMetric::HancomRegenerated=>"HancomRegenerated",
   super::composer::SpaceMetric::HalfCell=>"HalfCell",super::composer::SpaceMetric::KoPubJustified=>"KoPubJustified"},
  scalars:text.chars().count(),utf16_units:text.encode_utf16().count()}
}
#[allow(clippy::too_many_arguments)]
pub(crate) fn selected(para:&Paragraph,composition:Option<&ComposedParagraph>,width:Option<f64>,dpi:f64,
 recomposed:bool,context:Option<[u8;32]>,profile:LayoutCompatibilityProfile,heights:&[f64],spacings:&[f64],
 before:f64,after:f64,total:f64,fit:f64,square:bool)->Option<SelectedObservationHandle>{
 if RUNTIME_DEPTH.with(|d|d.get())!=1{return None;}
 ACTIVE.with(|a|{let Ok(mut a)=a.try_borrow_mut()else{return None;};let active=a.as_mut()?;let r=&mut active.report;
  if r.overflowed||r.unsupported_observed{return None;}if r.formats.len()>=MAX_FORMATS{r.overflowed=true;return None;}
  let composition=composition?;
  if para.text.len()>MAX_TEXT || para.char_offsets.len()>MAX_TEXT || composition.lines.len()>4096 || heights.len()>4096 || spacings.len()>4096
   || composition.inline_controls.len()>4096 || composition.tac_controls.len()>4096 || composition.footnote_positions.len()>4096 || composition.tab_extended.len()>4096
   || !dpi.is_finite() || width.is_some_and(|w|!w.is_finite()) || [before,after,total,fit].iter().chain(heights).chain(spacings).any(|v|!v.is_finite()){
   r.unsupported_observed=true;return None;}
  let mut text_budget=MAX_TEXT;let mut run_budget=16384usize;
  for line in &composition.lines {let Some(left)=run_budget.checked_sub(line.runs.len())else{r.overflowed=true;return None;};run_budget=left;if line.runs.len()>256{r.unsupported_observed=true;return None;}
   for run in &line.runs {for text in [Some(&run.text),run.display_text.as_ref()].into_iter().flatten(){
    let Some(next)=text_budget.checked_sub(text.len())else{r.overflowed=true;return None;};text_budget=next;}}}
  let source_chars=para.text.chars().collect::<Vec<_>>();let mut utf16=Vec::with_capacity(source_chars.len()+1);utf16.push(0u32);
  for c in &source_chars {utf16.push(utf16.last().copied()?.checked_add(c.len_utf16() as u32)?);}
  let mut lines=vec![];
  for line in &composition.lines {
   let runs=line.runs.iter().map(run_fact).collect::<Vec<_>>();let count=runs.iter().try_fold(0usize,|n,r|n.checked_add(r.scalars));
   let end=count.and_then(|n|line.char_start.checked_add(n));
   let source_match=end.is_some_and(|end|end<=source_chars.len() && line.runs.iter().all(|r|!r.inserted_control_text)
    && line.runs.iter().flat_map(|r|r.text.chars()).eq(source_chars.get(line.char_start..end).unwrap_or(&[]).iter().copied()));
   lines.push(LineFact{scalar_start:line.char_start,scalar_end:end,unicode_utf16_start:utf16.get(line.char_start).copied(),
    unicode_utf16_end:end.and_then(|i|utf16.get(i).copied()),original_hwp_char_offset:para.char_offsets.get(line.char_start).copied(),
    exact_source_text_span:source_match,height_hu:line.line_height,baseline_hu:line.baseline_distance,width_hu:line.segment_width,
    column_start_hu:line.column_start,spacing_hu:line.line_spacing,has_line_break:line.has_line_break,runs});
  }
  let id=r.formats.len();let fact=SelectedFormatFact{observation_id:id,paragraph_token:para as *const Paragraph as usize,actual_input_width_px:width,dpi,
   selected_recomposition:recomposed,definition_context:context,profile:format!("{profile:?}"),source_text:para.text.clone(),source_char_offsets:para.char_offsets.clone(),
   source_row_count:para.line_segs.len(),paragraph_style:composition.para_style_id,lines,actual_heights:heights.to_vec(),actual_spacings:spacings.to_vec(),
   before,after,total,fit_height:fit,inline_controls:composition.inline_controls.iter().map(|c|(c.line_index,c.control_index,format!("{:?}",c.control_type))).collect(),
   tac_controls:composition.tac_controls.clone(),footnote_positions:composition.footnote_positions.clone(),tab_extended:composition.tab_extended.clone(),
   has_numbering:composition.numbering_text.is_some(),has_horizontal_shaping:composition.horizontal_shaping.is_some(),known_square_band:square,
   observed_not_fresh_or_authorized:true};
  if !charge(r,&fact){return None;}
  // Keep the exact selected object for ordinary plain-body paint. This is not
  // deserialized/rebuilt from report fields and does not issue any row lease.
  let plain=composition.inline_controls.iter().all(|c|matches!(c.control_type,super::composer::InlineControlType::Other)
   &&para.controls.get(c.control_index).is_some_and(|v|matches!(v,crate::model::control::Control::SectionDef(_)|crate::model::control::Control::ColumnDef(_))))&&composition.tac_controls.is_empty()&&composition.footnote_positions.is_empty()
   &&composition.tab_extended.is_empty()&&composition.numbering_text.is_none()&&composition.horizontal_shaping.is_none();
  active.compositions.push(plain.then(||std::sync::Arc::new(composition.clone())));
  r.formats.push(fact);Some(SelectedObservationHandle{scope:active.scope,index:id,full_empty:false})
 })
}
/// Read only the actual selected object in this allocator pass. Diagnostic
/// reports and finalized snapshots cannot populate this arena or mint handles.
pub(crate) fn current_for_flow(handle:SelectedObservationHandle,para:&Paragraph)
 ->Option<(std::sync::Arc<ComposedParagraph>,SelectedFormatFact)>{
 if RUNTIME_DEPTH.with(|d|d.get())!=1{return None;}
 ACTIVE.with(|a|{let a=a.try_borrow().ok()?;let a=a.as_ref()?;
  if a.scope!=handle.scope||a.report.overflowed||a.report.unsupported_observed{return None;}
  let f=a.report.formats.get(handle.index)?;
  if f.paragraph_token!=para as *const Paragraph as usize{return None;}
  Some((std::sync::Arc::clone(a.compositions.get(handle.index)?.as_ref()?),f.clone()))
 })
}
/// Reserve a bounded immutable formatter pair before the allocator changes any
/// row cursor. Only actual current-pass handles can register this dependency.
pub(crate) fn require_plain_paint(old:SelectedObservationHandle,new:SelectedObservationHandle,para:&Paragraph)->bool{
 if RUNTIME_DEPTH.with(|d|d.get())!=1{return false;}
 ACTIVE.with(|a|{let Ok(mut a)=a.try_borrow_mut()else{return false;};let Some(a)=a.as_mut()else{return false;};
  if a.scope!=old.scope||a.scope!=new.scope||a.report.overflowed||a.report.unsupported_observed{return false;}
  let token=para as *const Paragraph as usize;
  let Some(oldf)=a.report.formats.get(old.index)else{return false;};let Some(newf)=a.report.formats.get(new.index)else{return false;};
  if oldf.paragraph_token!=token||newf.paragraph_token!=token||!newf.selected_recomposition||!para.controls.is_empty(){return false;}
  let prior=a.report.commits.iter().filter(|c|a.report.formats.get(c.format_id).is_some_and(|f|f.paragraph_token==token)).cloned().collect::<Vec<_>>();
  let Some(first)=prior.first()else{return false;};let paragraph=first.paragraph;
  if prior.len()>MAX_REQUIRED_COMMITS||prior.iter().any(|c|c.paragraph!=paragraph||!c.paragraph_token_matches
   ||!c.metrics_still_match_selected_format||!c.range_inside_selected_composition){return false;}
  let existing=a.required.iter().position(|b|b.token==token);
  let mut add=vec![];let mut bytes=0usize;
  for id in [old.index,new.index]{
   if existing.is_some_and(|i|a.required[i].formats.iter().any(|(f,_)|f.observation_id==id)){continue;}
   let Some(f)=a.report.formats.get(id)else{return false;};let Some(Some(c))=a.compositions.get(id)else{return false;};
   let Ok(raw)=serde_json::to_vec(f)else{return false;};let Some(n)=bytes.checked_add(raw.len())else{return false;};bytes=n;
   add.push((f.clone(),std::sync::Arc::clone(c)));
  }
  if existing.is_none(){let Some(n)=bytes.checked_add(MAX_REQUIRED_COMMITS*std::mem::size_of::<CommitFact>())else{return false;};bytes=n;}
  if bytes>MAX_REQUIRED_BYTES.saturating_sub(a.required_bytes){if let Some(i)=existing{a.required[i].failed=true;}return false;}
  a.required_bytes+=bytes;
  if let Some(i)=existing{a.required[i].formats.extend(add);}else{a.required.push(RequiredBuilder{full_empty:false,token,paragraph,formats:add,commits:prior,failed:false});}
  true
 })
}
/// A separate single-full-empty requirement, never a suffix/remapped-row claim.
/// Admission only: unsupported initial sources never select a new paint lane.
/// A dependency already accepted before a later budget failure stays mandatory.
pub(crate) fn current_source_available_for_empty()->bool{
 RUNTIME_DEPTH.with(|d|d.get()==1)&&ACTIVE.with(|a|a.try_borrow().ok().is_some_and(|a|a.as_ref().is_some_and(|a|!a.report.overflowed&&!a.report.unsupported_observed)))
}
pub(crate) fn require_full_empty_current(handle:Option<SelectedObservationHandle>,_para:&Paragraph)->Option<SelectedObservationHandle>{
 if RUNTIME_DEPTH.with(|d|d.get())!=1{return handle;}
 ACTIVE.with(|a|{let Ok(a)=a.try_borrow()else{return handle;};let Some(a)=a.as_ref()else{return handle;};
  Some(SelectedObservationHandle{scope:a.scope,index:handle.filter(|h|h.scope==a.scope).map_or(usize::MAX,|h|h.index),full_empty:true})
 })
}
pub(crate) fn invalidate_required_plain(para:&Paragraph){
 if RUNTIME_DEPTH.with(|d|d.get())!=1{return;}
 ACTIVE.with(|a|{if let Ok(mut a)=a.try_borrow_mut(){if let Some(a)=a.as_mut(){if let Some(b)=a.required.iter_mut().find(|b|b.token==para as *const Paragraph as usize){b.failed=true;}}}});
}
#[allow(clippy::too_many_arguments)]
pub(crate) fn commit(handle:Option<SelectedObservationHandle>,para:&Paragraph,section:usize,page:Option<u32>,column:u16,index:usize,
 start:usize,end:usize,flow_before:f64,flow_after:f64,advance:f64,available:Option<f64>,cumulative:Option<f64>,trimmed:f64,
 width:f64,multicol:bool,column_count:u16,heights:&[f64],spacings:&[f64],before:f64,after:f64,total:f64,fit:f64,items:&[PageItem]){
 if RUNTIME_DEPTH.with(|d|d.get())!=1{return;}
 let Some(handle)=handle else{return;};ACTIVE.with(|a|{let Ok(mut a)=a.try_borrow_mut()else{return;};let Some(a)=a.as_mut()else{return;};
  if a.scope!=handle.scope{return;}let r=&mut a.report;
  if r.commits.len()>=MAX_COMMITS{r.overflowed=true;}
  if handle.full_empty && column_count>1 {
   let token=para as *const Paragraph as usize;
   if let Some(existing)=a.required.iter_mut().find(|b|b.token==token){existing.failed=true;}else{
    let value=r.formats.get(handle.index).zip(a.compositions.get(handle.index).and_then(Option::as_ref))
     .filter(|(f,_)|f.paragraph_token==token&&f.selected_recomposition&&f.source_text.is_empty()&&f.lines.len()==1)
     .map(|(f,c)|(f.clone(),std::sync::Arc::clone(c)));
    let bytes=value.as_ref().and_then(|(f,_)|serde_json::to_vec(f).ok()).map(|v|v.len()).unwrap_or(0).checked_add(MAX_REQUIRED_COMMITS*std::mem::size_of::<CommitFact>());
    let allowed=bytes.is_some_and(|n|n<=MAX_REQUIRED_BYTES.saturating_sub(a.required_bytes));let valid=value.is_some();
    if allowed{a.required_bytes+=bytes.unwrap();}
    a.required.push(RequiredBuilder{full_empty:true,token,paragraph:index,formats:if allowed{value.into_iter().collect()}else{vec![]},commits:vec![],
     failed:!allowed||!valid||r.overflowed||r.unsupported_observed});
   }
  }
  let Some(format)=r.formats.get(handle.index)else{r.unsupported_observed=true;return;};
  let indices=items.iter().enumerate().filter_map(|(i,item)|match item{
   PageItem::FullParagraph{para_index}if *para_index==index&&start==0=>Some(i),
   PageItem::PartialParagraph{para_index,start_line,end_line}if *para_index==index&&*start_line==start&&*end_line==end=>Some(i),_=>None}).collect::<Vec<_>>();
  let fact=CommitFact{format_id:handle.index,section,page,column,paragraph:index,paragraph_token_matches:format.paragraph_token==para as *const Paragraph as usize,
   row_start:start,row_end:end,flow_before,flow_after,advance,available_for_rows:available,cumulative_fit:cumulative,trimmed_before:trimmed,
   actual_column_width_px:width,reused_multicolumn_format:multicol,
   same_format_reused_after_slot_change:r.commits.iter().any(|c|c.format_id==handle.index&&(c.page!=page||c.column!=column)),
   metrics_still_match_selected_format:format.actual_heights==heights&&format.actual_spacings==spacings
    &&format.before==before&&format.after==after&&format.total==total&&format.fit_height==fit,
   range_inside_selected_composition:start<end&&end<=format.lines.len(),committed_item_index:(indices.len()==1).then(||indices[0]),
   final_membership:None,finalization_index:None,not_physical_y:true};
  if [flow_before,flow_after,advance,trimmed,width].iter().any(|x|!x.is_finite()) || available.is_some_and(|x|!x.is_finite()) || cumulative.is_some_and(|x|!x.is_finite()){
   r.unsupported_observed=true;return;}
  if let Some(required)=a.required.iter_mut().find(|b|b.token==para as *const Paragraph as usize){
   if required.full_empty&&required.paragraph==usize::MAX{required.paragraph=index;}
   if required.commits.len()>=MAX_REQUIRED_COMMITS||!required.formats.iter().any(|(f,_)|f.observation_id==handle.index){required.failed=true;}
   else{required.commits.push(fact.clone());}
  }
  if !r.overflowed&&charge(r,&fact){r.commits.push(fact);}
 });
}
pub(crate) fn finalize(section:usize,result:&PaginationResult){ACTIVE.with(|a|{
 let Ok(mut a)=a.try_borrow_mut()else{return;};let Some(a)=a.as_mut()else{return;};let r=&mut a.report;if r.overflowed{return;}
 if r.finalizations.len()>=4096{r.overflowed=true;return;}
 let finalization=r.finalizations.len();let mut checked=0usize;let mut exact=true;
 for c in r.commits.iter_mut().filter(|c|c.section==section&&c.finalization_index.is_none()){
  let item=c.page.and_then(|p|result.pages.iter().find(|page|page.page_index==p)).and_then(|page|page.column_contents.iter().find(|cc|cc.column_index==c.column))
   .and_then(|cc|c.committed_item_index.and_then(|i|cc.items.get(i)));
  let matched=item.is_some_and(|item|match item{
   PageItem::FullParagraph{para_index}=>*para_index==c.paragraph&&c.row_start==0,
   PageItem::PartialParagraph{para_index,start_line,end_line}=>*para_index==c.paragraph&&*start_line==c.row_start&&*end_line==c.row_end,_=>false});
  c.final_membership=Some(matched);c.finalization_index=Some(finalization);checked+=1;exact&=matched;
 }
 for c in r.tables.iter_mut().filter(|c|c.section==section&&c.finalization_index.is_none()){
  let item=c.page.and_then(|p|result.pages.iter().find(|page|page.page_index==p)).and_then(|page|page.column_contents.iter().find(|cc|cc.column_index==c.column))
   .and_then(|cc|c.committed_item_index.and_then(|i|cc.items.get(i)));
  let matched=matches!(item,Some(PageItem::Table{para_index,control_index})if *para_index==c.paragraph&&*control_index==c.control);
  c.final_membership=Some(matched);c.finalization_index=Some(finalization);checked+=1;exact&=matched;
 }
 for c in r.whole_tables.iter_mut().filter(|c|c.section==section&&c.finalization_index.is_none()){
  let item=c.page.and_then(|p|result.pages.iter().find(|page|page.page_index==p)).and_then(|page|page.column_contents.iter().find(|cc|cc.column_index==c.column))
   .and_then(|cc|cc.items.get(c.committed_item_index));
  let matched=matches!(item,Some(PageItem::Table{para_index,control_index})if *para_index==c.paragraph&&*control_index==c.control);
  c.final_membership=Some(matched);c.finalization_index=Some(finalization);checked+=1;exact&=matched;
 }
 let fact=FinalizationFact{section,pages:result.pages.len(),commits_checked:checked,all_membership_exact:exact};
 if charge(r,&fact){r.finalizations.push(fact);}
 });}

pub(crate) fn table_commit(mut fact:TableAcceptedFact,items:&[PageItem]){
 if RUNTIME_DEPTH.with(|d|d.get())!=1{return;}
 ACTIVE.with(|a|{let Ok(mut a)=a.try_borrow_mut()else{return;};let Some(a)=a.as_mut()else{return;};let r=&mut a.report;
  if r.overflowed{return;}if r.tables.len()>=MAX_COMMITS{r.overflowed=true;return;}
  let finite=[fact.before,fact.body_height,fact.after_for_fit,fact.raw_top,fact.reserved_height,fact.x_start,fact.x_end,
   fact.lane_pushed_top,fact.paragraph_start,fact.flow_before,fact.flow_after].iter().all(|v|v.is_finite())
   &&fact.actually_queried_available.is_none_or(|v|v.is_finite())
   &&fact.resolved.as_ref().is_none_or(|p|[p.anchor_y,p.table_top,p.occupied_bottom].iter().all(|v|v.is_finite())
    &&[p.next_flow_y,p.stored_host_origin,p.stored_successor_origin,p.table_left].iter().all(|v|v.is_none_or(|v|v.is_finite())));
  if !finite{r.unsupported_observed=true;return;}
  let indices=items.iter().enumerate().filter_map(|(i,item)|matches!(item,PageItem::Table{para_index,control_index}
   if *para_index==fact.paragraph&&*control_index==fact.control).then_some(i)).collect::<Vec<_>>();
  fact.committed_item_index=(indices.len()==1).then(||indices[0]);
  if charge(r,&fact){r.tables.push(fact);}
 });
}

pub(crate) fn whole_table_commit(handle:Option<SelectedObservationHandle>,mut fact:WholeTableAcceptedFact){
 if RUNTIME_DEPTH.with(|d|d.get())!=1{return;}
 ACTIVE.with(|a|{let Ok(mut a)=a.try_borrow_mut()else{return;};let Some(active)=a.as_mut()else{return;};let r=&mut active.report;
  if r.overflowed{return;}if r.whole_tables.len()>=MAX_COMMITS{r.overflowed=true;return;}
  if [fact.table_total_height,fact.before,fact.body_height,fact.after_for_fit,fact.full_after,fact.paragraph_start,fact.flow_before,fact.flow_after,fact.pre_text_height].iter().any(|v|!v.is_finite())
   ||fact.resolved.as_ref().is_some_and(|p|[p.anchor_y,p.table_top,p.occupied_bottom].iter().any(|v|!v.is_finite())
    ||[p.next_flow_y,p.stored_host_origin,p.stored_successor_origin,p.table_left].iter().any(|v|v.is_some_and(|v|!v.is_finite()))){
   r.unsupported_observed=true;return;}
  fact.selected_format_id=handle.filter(|h|h.scope==active.scope).and_then(|h|r.formats.get(h.index).filter(|f|f.paragraph_token==fact.paragraph_token).map(|_|h.index));
  if charge(r,&fact){r.whole_tables.push(fact);}
 });
}

/// Immutable facts produced by one actual allocator pass. No deserializer or
/// public constructor exists. This is not a row lease or export permission:
/// consumers must still prove actual paint, UTF16, metrics and physical frames.
#[derive(Debug,Clone,Copy,PartialEq,Eq)]
enum ActualCompositionPurpose { CompleteAllocation, RequiredPaint }
#[derive(Debug)]
pub(crate) struct FinalizedSelectedCompositionTrace {
 purpose:ActualCompositionPurpose,
 generation:u64,section:usize,resource:[u8;32],source:[u8;32],final_frame:[u8;32],
 formats:Vec<SelectedFormatFact>,commits:Vec<CommitFact>,
 tables:Vec<TableAcceptedFact>,whole_tables:Vec<WholeTableAcceptedFact>,
 compositions:Vec<Option<std::sync::Arc<ComposedParagraph>>>,
}
impl FinalizedSelectedCompositionTrace {
 pub(crate) fn generation(&self)->u64{self.generation}
 pub(crate) fn section(&self)->usize{self.section}
 pub(crate) fn resource(&self)->[u8;32]{self.resource}
 pub(crate) fn formats(&self)->&[SelectedFormatFact]{&self.formats}
 pub(crate) fn commits(&self)->&[CommitFact]{&self.commits}
 pub(crate) fn tables(&self)->&[TableAcceptedFact]{&self.tables}
 pub(crate) fn whole_tables(&self)->&[WholeTableAcceptedFact]{&self.whole_tables}
 pub(crate) fn selected_composition(&self,id:usize)->Option<std::sync::Arc<ComposedParagraph>>{
  self.compositions.get(id)?.as_ref().map(std::sync::Arc::clone)
 }
 pub(crate) fn format(&self,id:usize)->Option<&SelectedFormatFact>{self.formats.iter().find(|f|f.observation_id==id)}
 pub(crate) fn matches_source(&self,paragraphs:&[Paragraph],context:Option<[u8;32]>,profile:LayoutCompatibilityProfile,dpi:f64)->bool{
  self.purpose==ActualCompositionPurpose::CompleteAllocation && self.matches_paint_source(paragraphs,context,profile,dpi)
 }
 /// Exact read-only paint binding; never authorizes standard rows/export.
 pub(crate) fn matches_paint_source(&self,paragraphs:&[Paragraph],context:Option<[u8;32]>,profile:LayoutCompatibilityProfile,dpi:f64)->bool{
  self.resource==crate::model::native_computed_resource::RESOURCE
   && source_key(self.section,paragraphs,context,profile,dpi)==Some(self.source)
 }
 pub(crate) fn matches_finalized_result(&self,result:&PaginationResult)->bool{frame_key(result)==Some(self.final_frame)}
 /// Prove only the actual DocCore cross-section page-number carry. The full
 /// original frame hash remains required after its exact checked inverse.
 /// This does not renew a trace or authorize changed geometry/stories.
 pub(crate) fn matches_finalized_after_page_number_carry(&self,result:&PaginationResult,carry:u32)->bool{
  if self.section==0||carry==0||result.pages.is_empty()||result.pages.len()>256{return false;}
  let mut pages=result.pages.clone();
  for (index,page)in pages.iter_mut().enumerate(){
   if page.section_index!=self.section||page.page_index as usize!=index||page.page_number_restarted{return false;}
   let Some(original)=page.page_number.checked_sub(carry).filter(|n|*n>0)else{return false;};page.page_number=original;
  }
  frame_key_with_pages(result,&pages)==Some(self.final_frame)
 }

}
struct BoundedHash {hash:blake3::Hasher,remaining:usize,depth:usize,quoted:bool,escaped:bool}
impl BoundedHash {fn new()->Self{Self{hash:blake3::Hasher::new(),remaining:MAX_BYTES,depth:0,quoted:false,escaped:false}}}
impl std::io::Write for BoundedHash {
 fn write(&mut self,bytes:&[u8])->std::io::Result<usize>{
  if bytes.len()>self.remaining{return Err(std::io::ErrorKind::InvalidData.into());}
  for &b in bytes {if self.quoted{if self.escaped{self.escaped=false;}else if b==b'\\'{self.escaped=true;}else if b==b'"'{self.quoted=false;}}
   else{match b{b'"'=>self.quoted=true,b'{'|b'['=>{self.depth+=1;if self.depth>64{return Err(std::io::ErrorKind::InvalidData.into());}},b'}'|b']'=>self.depth=self.depth.checked_sub(1).ok_or(std::io::ErrorKind::InvalidData)?,_=>{}}}}
  self.remaining-=bytes.len();self.hash.update(bytes);Ok(bytes.len())
 }
 fn flush(&mut self)->std::io::Result<()>{Ok(())}
}
impl std::fmt::Write for BoundedHash {
 fn write_str(&mut self,s:&str)->std::fmt::Result{
  if s.len()>self.remaining{return Err(std::fmt::Error);}self.remaining-=s.len();self.hash.update(s.as_bytes());Ok(())
 }
}
fn source_key(section:usize,paragraphs:&[Paragraph],context:Option<[u8;32]>,profile:LayoutCompatibilityProfile,dpi:f64)->Option<[u8;32]>{
 let context=context?;if !dpi.is_finite()||dpi<=0.0||paragraphs.len()>4096{return None;}
 let mut h=BoundedHash::new();
 serde_json::to_writer(&mut h,&("actual-selected-composition-input127-1",crate::model::native_computed_resource::RESOURCE,
  section,context,format!("{profile:?}"),dpi,paragraphs)).ok()?;
 source_layout_supplement(paragraphs,&mut h)?;
 (h.depth==0&&!h.quoted).then(||*h.hash.finalize().as_bytes())
}
/// Serde intentionally skips current layout inputs. Bind those explicitly.
/// This narrowly supports body/table-cell stories; other nested story owners
/// require their own complete input traversal and are refused, never guessed.
fn source_layout_supplement(paragraphs:&[Paragraph],h:&mut BoundedHash)->Option<()>{
 use crate::model::{control::Control,paragraph::{NumberingMarker,MarkerHead}};
 use std::fmt::Write;
 let mut pending:Vec<&Paragraph>=paragraphs.iter().rev().collect();let mut count=0usize;
 while let Some(p)=pending.pop(){count=count.checked_add(1)?;if count>4096{return None;}
  // Exhaustive binding ensures new Paragraph fields require an explicit decision.
  let Paragraph{char_count:_,control_mask:_,para_shape_id:_,style_id:_,column_type:_,raw_break_type:_,page_break_synthesized:_,
   text:_,char_offsets:_,char_shapes:_,line_segs:_,layout_space_metrics,hwpx_axis_shift:_,layout_only_fill_lines:_,
   source_line_seg_vertical_pos,native_source_synthetic_seal,native_source_synthetic_context,completed_native_rows,
   native_frame_observation:_,reset_flow_observation,range_tags:_,field_ranges:_,orphan_field_ends:_,controls,
   ctrl_data_records:_,char_count_msb:_,raw_header_extra:_,has_para_text:_,tab_extended:_,title_marks:_,markpen_marks:_,
   numbering_restart:_,stored_text_partition_dirty,cell_format_vpos_dirty,cell_vpos_reset,numbering_marker}=p;
  // native_frame_observation is an allocator OUTPUT, not a formatting input.
  // It is changed by the very pass being observed. It confers no authority here.
  write!(h,"supplement-paragraph:{count}:{layout_space_metrics:?}:{source_line_seg_vertical_pos:?}:{native_source_synthetic_seal:?}:{native_source_synthetic_context:?}:{completed_native_rows:?}:{reset_flow_observation:?}:{stored_text_partition_dirty:?}:{cell_format_vpos_dirty:?}:{cell_vpos_reset:?}").ok()?;
  match numbering_marker{
   NumberingMarker::Unresolved=>write!(h,"marker-unresolved;").ok()?,
   NumberingMarker::Absent=>write!(h,"marker-absent;").ok()?,
   NumberingMarker::Text(text,head)=>{let MarkerHead{attr,width_adjust,text_distance,char_shape_id}=head;
    serde_json::to_writer(&mut *h,&("marker-text",text,attr,width_adjust,text_distance,char_shape_id)).ok()?;}
  }
  if controls.len()>4096{return None;}
  for c in controls.iter().rev(){match c{
   Control::Table(t)=>{
    write!(h,"table-raw-seal:{:?};",t.raw_ctrl_seal).ok()?;
    if t.caption.as_ref().is_some_and(|c|!c.paragraphs.is_empty()){return None;}
    for cell in t.cells.iter().rev(){if cell.paragraphs.len()>4096usize.saturating_sub(pending.len()){return None;}
     pending.extend(cell.paragraphs.iter().rev());}
   },
   Control::SectionDef(d)=>if !d.master_pages.is_empty(){return None;},
   Control::Shape(_)|Control::Picture(_)|Control::Header(_)|Control::Footer(_)|Control::Footnote(_)|Control::Endnote(_)|Control::HiddenComment(_)=>return None,
   Control::Field(f)=>{if !f.memo_paragraphs.is_empty(){return None;}write!(h,"field-layout:{f:?}").ok()?;},
   // These variants contain no nested Paragraph. Debug is derived and retains
   // their Serde-skipped raw seals. NumberingMarker's custom Debug is never used.
   Control::ColumnDef(_)|Control::AutoNumber(_)|Control::NewNumber(_)|Control::PageNumberPos(_)|Control::Bookmark(_)|Control::IndexMark(_)
   |Control::PageNumCtrl(_)|Control::Hyperlink(_)|Control::Ruby(_)|Control::CharOverlap(_)|Control::PageHide(_)|Control::Equation(_)|Control::Form(_)|Control::Unknown(_)=>write!(h,"leaf-control:{c:?}").ok()?,
  }}
 }
 Some(())
}
fn frame_key(result:&PaginationResult)->Option<[u8;32]>{frame_key_with_pages(result,&result.pages)}
fn frame_key_with_pages(result:&PaginationResult,pages:&[crate::renderer::pagination::PageContent])->Option<[u8;32]>{
 // The initial body/table proof does not own inherited or deferred stories.
 // In particular Paragraph's custom NumberingMarker Debug intentionally hides
 // its value, so an endnote aggregate must not enter this exact frame hash.
 if result.pages.len()>256 || !result.endnotes.is_empty() || !result.endnote_paragraphs.is_empty() || !result.endnote_para_sources.is_empty()
  || result.pages.iter().any(|p|p.active_header.is_some()||p.active_footer.is_some()||p.active_master_page.is_some()
   ||!p.extra_master_pages.is_empty()||!p.footnotes.is_empty()){return None;}
 let mut h=BoundedHash::new();use std::fmt::Write;
 // A bounded exact in-process frame snapshot, not a portable serialization.
 // Includes final column items, zones, reservations and page/column geometry.
 // The trace itself is deliberately excluded to avoid recursive self-binding.
 let PaginationResult{selected_composition_trace:_,required_plain_paint:_,pages:_,wrap_around_paras,hidden_empty_paras,pre_emitted_host_paras,
  pre_emitted_host_heights,pre_emitted_host_content_heights,endnotes,endnote_paragraphs,endnote_para_sources,
  endnote_between_notes_hu,endnote_separator_above_hu,endnote_separator_below_hu}=result;
 write!(&mut h,"actual-final-allocation127-1:{:?}",(pages,wrap_around_paras,hidden_empty_paras,pre_emitted_host_paras,
  pre_emitted_host_heights,pre_emitted_host_content_heights,endnotes,endnote_paragraphs,endnote_para_sources,
  endnote_between_notes_hu,endnote_separator_above_hu,endnote_separator_below_hu)).ok()?;
 Some(*h.hash.finalize().as_bytes())
}
pub(crate) struct RuntimePassGuard {
 previous_depth:usize,saved_active:Option<Active>,owns_arena:bool,enabled:bool,generation:Option<u64>,
 section:usize,source:Option<[u8;32]>,first_format:usize,first_commit:usize,
 first_table:usize,
}
impl Drop for RuntimePassGuard {fn drop(&mut self){
 RUNTIME_DEPTH.with(|d|d.set(self.previous_depth));
 if !self.owns_arena{return;}
 ACTIVE.with(|a|{let Ok(mut slot)=a.try_borrow_mut()else{return;};let completed=slot.take();
  // Diagnostics receive copies only after the actual pass has finished. Their
  // prior overflow, cookie and records never participate in runtime admission.
  if let (Some(saved),Some(completed))=(self.saved_active.as_mut(),completed){
   let dst=&mut saved.report;let src=completed.report;
   let format_base=dst.formats.len();let final_base=dst.finalizations.len();
   for mut fact in src.formats{fact.observation_id+=format_base;if charge(dst,&fact){dst.formats.push(fact);}}
   for mut fact in src.commits{fact.format_id+=format_base;fact.finalization_index=fact.finalization_index.map(|i|i+final_base);if charge(dst,&fact){dst.commits.push(fact);}}
   for mut fact in src.tables{fact.finalization_index=fact.finalization_index.map(|i|i+final_base);if charge(dst,&fact){dst.tables.push(fact);}}
   for mut fact in src.whole_tables{fact.selected_format_id=fact.selected_format_id.map(|i|i+format_base);fact.finalization_index=fact.finalization_index.map(|i|i+final_base);if charge(dst,&fact){dst.whole_tables.push(fact);}}
   for fact in src.finalizations{if charge(dst,&fact){dst.finalizations.push(fact);}}
   dst.overflowed|=src.overflowed;dst.unsupported_observed|=src.unsupported_observed;dst.nested_rejected|=src.nested_rejected;
  }
  *slot=self.saved_active.take();
 });
}}
pub(crate) fn begin_runtime_section(section:usize,paragraphs:&[Paragraph],context:Option<[u8;32]>,profile:LayoutCompatibilityProfile,dpi:f64)->RuntimePassGuard{
 let previous_depth=RUNTIME_DEPTH.with(|d|{let n=d.get();d.set(n.saturating_add(1));n});
 let generation=NEXT_PASS.with(|n|n.get().checked_add(1).map(|v|{n.set(v);v}));
 let source=(previous_depth==0).then(||source_key(section,paragraphs,context,profile,dpi)).flatten();
 let (saved_active,owns_arena)=ACTIVE.with(|a|{let Ok(mut a)=a.try_borrow_mut()else{return(None,false);};
  if previous_depth!=0{if let Some(active)=a.as_mut(){active.report.nested_rejected=true;active.report.unsupported_observed=true;}return(None,false);}
  let scope=NEXT_SCOPE.with(|n|n.get().checked_add(1).map(|v|{n.set(v);v}));let Some(scope)=scope else{return(None,false);};
  let saved=a.take();
  *a=Some(Active{scope,compositions:vec![],required:vec![],required_bytes:0,report:SelectedCompositionReport{cookie:[0;32],formats:vec![],commits:vec![],tables:vec![],whole_tables:vec![],finalizations:vec![],encoded_bytes:0,
   overflowed:false,unsupported_observed:source.is_none(),nested_rejected:false,not_an_export_permission:true}});
  (saved,true)
 });
 RuntimePassGuard{previous_depth,saved_active,owns_arena,enabled:previous_depth==0&&owns_arena,generation,section,source,first_format:0,first_commit:0,first_table:0}
}
impl RuntimePassGuard {
 /// Finalize actual paint dependencies independently of the optional fact
 /// report's budget. Any failure remains a PRESENT invalid dependency and is
 /// surfaced as RenderError; a remapped index never falls back to legacy paint.
 pub(crate) fn finish_required(&self,result:&PaginationResult,paragraphs:&[Paragraph],context:Option<[u8;32]>,profile:LayoutCompatibilityProfile,dpi:f64)
  ->Option<std::sync::Arc<RequiredPlainPaint>>{
  if !self.enabled{return None;}
  ACTIVE.with(|a|{
   let invalid=||Some(std::sync::Arc::new(RequiredPlainPaint{trace:None,paragraphs:vec![],full_empty_tokens:vec![]}));
   let Ok(a)=a.try_borrow()else{return invalid();};let Some(active)=a.as_ref()else{return invalid();};
   if active.required.is_empty(){return None;}
   let owned=active.required.iter().map(|b|(b.paragraph,b.token)).collect::<Vec<_>>();
   let trace=(||->Option<std::sync::Arc<FinalizedSelectedCompositionTrace>>{
    if active.report.nested_rejected||active.required.iter().any(|b|b.failed){return None;}
    let source=self.source?;if source_key(self.section,paragraphs,context,profile,dpi)!=Some(source){return None;}
    let frame=frame_key(result)?;let generation=self.generation?;
    let mut formats=vec![];let mut compositions=vec![None;active.compositions.len()];let mut commits=vec![];
    let mut pages=std::collections::HashSet::new();
    for p in &result.pages{if !pages.insert(p.page_index){return None;}let mut cols=std::collections::HashSet::new();for c in &p.column_contents{if !cols.insert(c.column_index){return None;}}}
    for b in &active.required{
     if paragraphs.get(b.paragraph).map(|p|p as *const Paragraph as usize)!=Some(b.token){return None;}
     for(f,c)in &b.formats{if compositions.get(f.observation_id)?.is_some(){return None;}compositions[f.observation_id]=Some(std::sync::Arc::clone(c));formats.push(f.clone());}
     for c in &b.commits{
      let item=c.page.and_then(|n|result.pages.iter().find(|p|p.page_index==n)).and_then(|p|p.column_contents.iter().find(|cc|cc.column_index==c.column))
       .and_then(|cc|c.committed_item_index.and_then(|i|cc.items.get(i)));
      let membership=if b.full_empty{b.commits.len()==1&&matches!(item,Some(PageItem::FullParagraph{para_index})if *para_index==b.paragraph&&c.row_start==0&&c.row_end==1)}else{
       matches!(item,Some(PageItem::PartialParagraph{para_index,start_line,end_line})if *para_index==b.paragraph&&*start_line==c.row_start&&*end_line==c.row_end)};
      if !membership
       ||!c.paragraph_token_matches||!c.metrics_still_match_selected_format||!c.range_inside_selected_composition{return None;}
      let mut c=c.clone();c.final_membership=Some(true);commits.push(c);
     }
    }
    Some(std::sync::Arc::new(FinalizedSelectedCompositionTrace{purpose:ActualCompositionPurpose::RequiredPaint,generation,section:self.section,resource:crate::model::native_computed_resource::RESOURCE,
     source,final_frame:frame,formats,commits,tables:vec![],whole_tables:vec![],compositions}))
   })();
   Some(std::sync::Arc::new(RequiredPlainPaint{trace,paragraphs:owned,full_empty_tokens:active.required.iter().filter(|b|b.full_empty).map(|b|b.token).collect()}))
  })
 }
 pub(crate) fn finish(self,result:&PaginationResult,paragraphs:&[Paragraph],context:Option<[u8;32]>,profile:LayoutCompatibilityProfile,dpi:f64)
  ->Option<std::sync::Arc<FinalizedSelectedCompositionTrace>>{
  if !self.enabled{return None;}finalize(self.section,result);
  let source=self.source?;if source_key(self.section,paragraphs,context,profile,dpi)!=Some(source){return None;}
  // Repeated page/column labels (for example zones) require their own physical
  // ordinal proof; do not guess an item owner from the first matching label.
  let mut pages=std::collections::HashSet::new();
  for page in &result.pages{if !pages.insert(page.page_index){return None;}let mut columns=std::collections::HashSet::new();
   for column in &page.column_contents{if !columns.insert(column.column_index){return None;}}}
  let final_frame=frame_key(result)?;let generation=self.generation?;
  ACTIVE.with(|a|{let Ok(a)=a.try_borrow()else{return None;};let active=a.as_ref()?;let r=&active.report;
   if r.overflowed||r.unsupported_observed||r.nested_rejected{return None;}
   let formats=r.formats.get(self.first_format..)?.to_vec();let commits=r.commits.get(self.first_commit..)?.to_vec();
   let tables=r.tables.get(self.first_table..)?.to_vec();let whole_tables=r.whole_tables.clone();
   if commits.iter().any(|c|!c.paragraph_token_matches||!c.metrics_still_match_selected_format||!c.range_inside_selected_composition||c.final_membership!=Some(true)){return None;}
   if tables.iter().any(|c|c.final_membership!=Some(true))||whole_tables.iter().any(|c|c.final_membership!=Some(true)){return None;}
   Some(std::sync::Arc::new(FinalizedSelectedCompositionTrace{purpose:ActualCompositionPurpose::CompleteAllocation,generation,section:self.section,
    resource:crate::model::native_computed_resource::RESOURCE,source,final_frame,formats,commits,tables,whole_tables,compositions:active.compositions.clone()}))
  })
 }
}
