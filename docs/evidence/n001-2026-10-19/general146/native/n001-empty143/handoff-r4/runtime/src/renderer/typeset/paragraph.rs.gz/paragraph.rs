//! 문단 조판의 책임 경계.
//!
//! 구성된 줄 조회, 문단 구성 결과의 높이 조회, 저장 줄 간격 판정을 소유한다.
//! 문단 구성은 필요한 관측값을 읽고 결과만 반환한다.
//! fit 예산의 읽기 전용 계산은 fit에, 1회성 보정 소비는 state에 있다.
//! 줄 후보 계산은 scan, 그 뒤의 경계 보정은 split에 있다.
//! 진입 예산과 전체/넘침/빈 구성 결과 배치, 분할 진입·페이지 전환을 조정한다.
//! flow는 일반 문단의 최상위 순서를, controls::paragraph_flow는 표 소유 문단을 조정한다.
//! 강제 경계 후보의 우선순위와 전체 fit 선택·호환성 spill을 조정한다.
//! 하위 Query는 원본 IR이나 페이지 상태를 변경하지 않으며, 확정 조각 적용은 state가 맡는다.

pub(super) mod mixed_tac_owner;
pub(super) mod boundary;
mod columns;
mod current_suffix;
pub(super) mod context;
pub(super) mod empty;
mod entry;
pub(super) mod fit;
pub(super) mod flow;
pub(super) mod format;
pub(super) mod line_queries;
pub(super) mod metrics;
pub(super) mod overflow;
pub(super) mod placement;
pub(super) mod scan;
pub(super) mod split;
pub(super) mod split_entry;
pub(super) mod stored_lines;
pub(super) mod whole_fit;

use super::{
    is_synthetic_line_seg, missing_lineseg_trailing_line_break,
    native_hwp5_existing_footnote_reset_overlap_break_line,
    native_hwp5_first_footnote_overlap_break_line,
    native_hwp5_text_reset_before_large_tac_topbottom_picture_break_line, page_item_vpos_base,
    para_has_non_whitespace_text, para_has_visible_text, para_is_treat_as_char_picture_only,
    preceding_stored_vpos, stored_body_reset_fragment_matches_current_flow, stored_vpos_rewinds,
    TypesetState,
};
use crate::model::paragraph::Paragraph;
use crate::renderer::hwpunit_to_px;
use crate::renderer::pagination::PageItem;
use crate::renderer::style_resolver::ResolvedStyleSet;
use metrics::FormattedParagraph;
use stored_lines::{next_boundary_reverts_spacing_trim, spacing_trim_restorable};

/// 진입 fit 판단 뒤의 줄 분할을 조정한다. 쪽 전환 후 후보를 다시 계산하며,
/// 전체 문단 재시도와 조각 배치 후 이월을 구분한다. 진입 시 고정한 기준 예산은 유지한다.
#[allow(clippy::too_many_arguments)]
pub(super) fn place_split_paragraph(
    engine: &super::TypesetEngine,
    styles: &ResolvedStyleSet,
    st: &mut TypesetState,
    para_idx: usize,
    para: &Paragraph,
    fmt: &FormattedParagraph,
    paragraphs: &[Paragraph],
    line_count: usize,
    base_available: f64,
    layout_drift_safety_px: f64,
    forced_page_break_line: Option<usize>,
    native_hwp5_existing_footnote_reset_line: Option<usize>,
    current_page_vpos_base: Option<i32>,
    is_tac_picture_stack: bool,
    dpi: f64,
) {
    let mut current_format=fmt.clone();
    let mut line_count=line_count;
    let mut remapped=false;
    // 줄 단위 분할 루프
    let mut cursor_line = st.take_prefilled_line_prefix(para_idx);
    let mut on_entry_page = true;
    while cursor_line < line_count {
        if forced_page_break_line.is_none() && native_hwp5_existing_footnote_reset_line.is_none() && !is_tac_picture_stack {
            if let Some((fresh,row))=current_suffix::reformat(engine,st,para,&current_format,cursor_line,styles,dpi){
                current_format=fresh;cursor_line=row;line_count=current_format.line_count();remapped=true;
            }
        }
        let fmt=&current_format;
        let page_avail = if cursor_line == 0 || on_entry_page {
            // 저장 HWPX의 실제 FootnoteArea 경계를 진입 fit과 공유한다.
            // 여기서 별도 각주 높이와 40px 여백을 다시 빼면 물리적으로
            // 들어가는 본문 줄이 다음 쪽으로 밀린다. 다른 profile은 기존
            // 분할 예산을 유지한다.
            if st.profile.hwpx_stored_layout()
                && st.deferred_hwpx_note_body
                && st.current_footnote_height > 0.0
            {
                (st.available_height() - st.current_height).max(0.0)
            } else {
                let fn_margin = if st.current_footnote_height > 0.0 {
                    st.footnote_safety_margin
                } else {
                    0.0
                };
                (base_available
                    - st.current_footnote_height
                    - fn_margin
                    - st.current_height
                    - st.current_zone_y_offset)
                    .max(0.0)
            }
        } else {
            base_available
        };

        let sp_b = if cursor_line == 0 {
            fmt.spacing_before
        } else {
            0.0
        };
        // Task #332 Stage 4b: partial split 의 줄 단위 fit 검사에도 layout drift 마진 적용
        let avail_for_lines = (page_avail - sp_b - layout_drift_safety_px).max(0.0);

        let scan::LineScanResult {
            end_line,
            cumulative,
            used_saved_tail_vpos_fit,
        } = if remapped { match current_suffix::scan(fmt,cursor_line,avail_for_lines){Some(scan)=>scan,None=>{
            crate::renderer::selected_composition_observer127::invalidate_required_plain(para);break;
        }} } else { scan::scan_lines(
            para,
            fmt,
            paragraphs,
            para_idx,
            cursor_line,
            line_count,
            avail_for_lines,
            forced_page_break_line,
            native_hwp5_existing_footnote_reset_line,
            current_page_vpos_base,
            is_tac_picture_stack,
            &st.paragraph_line_scan_page(),
            dpi,
        ) };

        let split::SplitBoundary {
            end_line,
            cumulative,
        } = if remapped { split::SplitBoundary {end_line,cumulative} } else { split::refine_split_boundary(
            para,
            fmt,
            paragraphs.get(para_idx + 1),
            cursor_line,
            line_count,
            avail_for_lines,
            st.base_available_height(),
            st.profile.hwp5_stored_pagination_layout(),
            dpi,
            split::SplitBoundary {
                end_line,
                cumulative,
            },
        ) };

        let Some(fragment) = placement::plan_fragment(
            fmt,
            para_idx,
            cursor_line,
            line_count,
            sp_b,
            avail_for_lines,
            split::SplitBoundary {
                end_line,
                cumulative,
            },
            used_saved_tail_vpos_fit,
            &st.current_items,
        ) else {
            st.advance_column_or_new_page();
            on_entry_page = false;
            continue;
        };
        let observed_flow_before=st.current_height;
        let observed_advance=fragment.height;
        st.commit_split_paragraph_fragment(fragment);
        observe_selected_commit127(st,para_idx,para,fmt,cursor_line,end_line,observed_flow_before,observed_advance,
            Some(avail_for_lines),Some(cumulative),0.0,false);


        if end_line >= line_count {
            break;
        }

        // move: 나머지 줄 → 다음 단/페이지
        st.advance_column_or_new_page();
        cursor_line = end_line;
        on_entry_page = false;
    }
}

/// 저장된 다음 문단의 쪽 되감김 앞 줄만 떠 있는 표 위 공간에 선행 배치한다.
/// 줄 끝 컷과 실제 문단 조각을 함께 생산해 다음 쪽에서 이미 소비한 줄을 다시 그리지 않는다.
#[allow(clippy::too_many_arguments)]
pub(super) fn plan_stored_float_text_prefix(
    host: &Paragraph,
    next: &Paragraph,
    fmt: &FormattedParagraph,
    next_idx: usize,
    float: crate::renderer::float_placement::ParagraphFloatPlacement,
    current_height: f64,
    dpi: f64,
) -> Option<placement::ParagraphFragment> {
    if !next.controls.is_empty()
        || next.column_type != crate::model::paragraph::ColumnBreakType::None
        || next.stored_text_partition_is_dirty()
        || next.cell_format_vpos_dirty
        || next.line_segs.len() != fmt.line_count()
        || next.line_segs.iter().any(|line| {
            is_synthetic_line_seg(line) || line.line_height <= 0 || line.vertical_pos < 0
        })
    {
        return None;
    }
    let base = host.line_segs.first()?.vertical_pos;
    let end_line = next
        .line_segs
        .windows(2)
        .position(|pair| pair[1].vertical_pos < pair[0].vertical_pos)?
        + 1;
    let first_top = float.anchor_y
        + hwpunit_to_px(next.line_segs.first()?.vertical_pos.checked_sub(base)?, dpi);
    // 현재 줄 구성의 원점과 저장 프레임이 같은 원본 정수 단위에 있어야 한다.
    // 실제 글줄 높이까지만 fit하며 마지막 줄 뒤 간격은 개체 위 빈 띠와 겹칠 수 있다.
    if (first_top - current_height - fmt.spacing_before).abs() > dpi / 7200.0 {
        return None;
    }
    let mut top = current_height + fmt.spacing_before;
    for (idx, line) in next.line_segs[..end_line].iter().enumerate() {
        let saved_top = float.anchor_y + hwpunit_to_px(line.vertical_pos.checked_sub(base)?, dpi);
        if (saved_top - top).abs() > dpi / 7200.0 || top + fmt.line_heights[idx] > float.table_top {
            return None;
        }
        top += fmt.line_advance(idx);
    }
    placement::plan_fragment(
        fmt,
        next_idx,
        0,
        fmt.line_count(),
        fmt.spacing_before,
        (float.table_top - current_height - fmt.spacing_before).max(0.0),
        split::SplitBoundary {
            end_line,
            cumulative: fmt.line_advances_sum(0..end_line),
        },
        false,
        &[],
    )
}

/// 진입 fit을 통과한 전체 문단을 배치한다. 항목 순서 확정 뒤 흐름 메트릭을 계산한다.
#[allow(clippy::too_many_arguments)]
pub(super) fn place_fitted_paragraph(
    st: &mut TypesetState,
    para_idx: usize,
    para: &Paragraph,
    fmt: &FormattedParagraph,
    paragraphs: &[Paragraph],
    styles: &ResolvedStyleSet,
    trim_spacing_before_for_flow: bool,
    trimmed_sb_gate: f64,
    body_bottom_vpos: Option<i32>,
    dpi: f64,
) {
    let defer_preceding_float =
        placement::defer_preceding_float(&st.current_items, paragraphs, para_idx, para);
    st.insert_fitted_paragraph(para_idx, defer_preceding_float);
    // [Task #391] 다단/단단 분기:
    //   - 단단 (col_count == 1): total_height (k-water-rfp p3 311px drift 차단, #359)
    //   - 다단 (col_count > 1): height_for_fit (exam_eng 8p 정상 단 채움 복원)
    // 다단에서는 layout 이 vpos 기반으로 항목을 단별로 stacking 하므로
    // typeset 누적 시 trailing_ls 인플레이션이 단을 조기 종료시킴.
    let advance = fmt.flow_advance_height(
        para,
        st.col_count,
        trim_spacing_before_for_flow,
        st.vpos_ladder_dirty
                || source_spacing_trim_changes_next_origin(
                    st, para_idx, para, fmt, paragraphs, styles,
                    trim_spacing_before_for_flow, st.vpos_page_base.is_none() && st.vpos_lazy_base.is_some(), dpi,
                )
            || !spacing_trim_restorable(paragraphs, para_idx)
            || next_boundary_reverts_spacing_trim(
                st.profile.hwpx_stored_layout() && !st.profile.hwp3_layout(),
                paragraphs,
                styles,
                para_idx,
                dpi,
            ),
        st.vpos_page_base.is_none() && st.vpos_lazy_base.is_some(),
    );
    if std::env::var("RHWP_DIAG_ADV").is_ok() {
        eprintln!(
            "DIAG_ADV pi={} adv={:.1} total={:.1} h4f={:.1} sb={:.1} sa={:.1} cur={:.1}",
            para_idx,
            advance,
            fmt.total_height,
            fmt.height_for_fit,
            fmt.spacing_before,
            fmt.spacing_after,
            st.current_height,
        );
    }
    let trimmed_spacing_before = trimmed_sb_gate
        * fmt.flow_trimmed_spacing_before(
            para,
            st.col_count,
            trim_spacing_before_for_flow,
            st.vpos_ladder_dirty
                || source_spacing_trim_changes_next_origin(
                    st, para_idx, para, fmt, paragraphs, styles,
                    trim_spacing_before_for_flow, st.vpos_page_base.is_none() && st.vpos_lazy_base.is_some(), dpi,
                )
                || !spacing_trim_restorable(paragraphs, para_idx)
                || next_boundary_reverts_spacing_trim(
                    st.profile.hwpx_stored_layout() && !st.profile.hwp3_layout(),
                    paragraphs,
                    styles,
                    para_idx,
                    dpi,
                ),
            st.vpos_page_base.is_none() && st.vpos_lazy_base.is_some(),
        );
    // 다음 저장 표가 이 문단의 후행 간격을 사용할 수는 있어도
    // 실제 글줄 안으로 들어오면 안 된다. 수용에 쓴 구성 높이를 공유한다.
    if para.controls.is_empty() && para_has_non_whitespace_text(para) && fmt.line_count() > 0 {
        st.record_paragraph_content_bottom(
            (para_idx, fmt.line_count()),
            (fmt.height_for_fit - fmt.spacing_after - trimmed_spacing_before).max(0.0),
        );
    }
    let observed_flow_before=st.current_height;
    st.apply_full_paragraph_flow(
        advance,
        fmt.total_height,
        trimmed_spacing_before,
        body_bottom_vpos,
    );
    observe_selected_commit127(st,para_idx,para,fmt,0,fmt.line_count(),observed_flow_before,advance,None,None,trimmed_spacing_before,false);
    // 위의 KoPub 양쪽 정렬 재조판만 의도적으로 저장 줄 위치 관계를 무효화한다.
    // HWP3에서 변환한 HWPX를 포함한 다른 문서는 별도 이유로 조판 줄 수가 줄 수 있다.
    // 그 저장 높이를 모든 뒤 vpos에서 빼면
    // 내용이 물리 쪽 경계를 넘어 당겨진다.
    let compacted_kopub_justified = st.profile.hwpx_stored_layout()
        && para.controls.iter().any(|control| {
            matches!(control, crate::model::control::Control::Picture(picture)
                if picture.common.treat_as_char)
        })
        && styles
            .para_styles
            .get(para.para_shape_id as usize)
            .is_some_and(|style| style.alignment == crate::model::style::Alignment::Justify)
        && para.char_shapes.iter().any(|reference| {
            styles
                .char_styles
                .get(reference.char_shape_id as usize)
                .is_some_and(|style| {
                    style.font_families.iter().any(|face| {
                        face.contains("KoPub돋움체")
                            || face.contains("KoPub바탕체")
                            || face.to_lowercase().contains("kopub dotum")
                            || face.to_lowercase().contains("kopub batang")
                    })
                })
        });
    if compacted_kopub_justified
        && para.line_segs.len() > fmt.line_heights.len()
        && para
            .line_segs
            .iter()
            .all(|seg| !super::is_synthetic_line_seg(seg))
    {
        let stored_lines_height: f64 = para
            .line_segs
            .iter()
            .map(|seg| hwpunit_to_px(seg.line_height.saturating_add(seg.line_spacing), dpi))
            .sum();
        let compacted_lines_height = fmt.line_advances_sum(0..fmt.line_heights.len());
        st.record_compacted_stored_rows(stored_lines_height - compacted_lines_height);
    }
}

/// 일반 fit 실패 뒤 atomic → tail 순서로 시도한다. 성공 시 호출자는 즉시 반환한다.
#[allow(clippy::too_many_arguments)]
pub(super) fn try_place_overflow_paragraph(
    st: &mut TypesetState,
    para_idx: usize,
    para: &Paragraph,
    fmt: &FormattedParagraph,
    paragraphs: &[Paragraph],
    styles: &ResolvedStyleSet,
    trim_spacing_before_for_flow: bool,
    body_bottom_vpos: Option<i32>,
    available: f64,
    forced_page_break_line: Option<usize>,
    dpi: f64,
) -> bool {
    let page = st.paragraph_overflow_page();
    if overflow::atomic_overflow_fits(para, fmt, paragraphs, para_idx, &page, available, dpi) {
        st.begin_atomic_overflow_paragraph(para_idx);
        let advance = fmt.flow_advance_height(
            para,
            st.col_count,
            trim_spacing_before_for_flow,
            st.vpos_ladder_dirty
                || source_spacing_trim_changes_next_origin(
                    st, para_idx, para, fmt, paragraphs, styles,
                    trim_spacing_before_for_flow, false, dpi,
                )
                || !spacing_trim_restorable(paragraphs, para_idx)
                || next_boundary_reverts_spacing_trim(
                    st.profile.hwpx_stored_layout() && !st.profile.hwp3_layout(),
                    paragraphs,
                    styles,
                    para_idx,
                    dpi,
                ),
            false,
        );
        st.advance_atomic_overflow_paragraph(advance, fmt.total_height, body_bottom_vpos);
        return true;
    }
    let tail_allowance = overflow::tail_overflow_candidate(
        para,
        fmt,
        paragraphs,
        para_idx,
        &page,
        forced_page_break_line,
        dpi,
    );
    if tail_allowance.allowed {
        let first_line_advance = fmt.line_advance(0);
        // 다음 문단이 어차피 쪽나누기로 페이지를 끝내므로, 다음 페이지 layout clamp 를
        // 막으려던 LAYOUT_DRIFT_SAFETY_PX(현재 페이지 한정) 여유는 이 경우 의미가 없다.
        // 따라서 safety 를 뺀 `available` 이 아니라 진짜 본문 하단(각주/존 차감 포함)인
        // available_height() 를 기준으로 초과량을 잰다.
        let true_available = st.available_height();
        // 초과량이 한 줄 미만(폰트 drift)일 때만 통째 배치.
        // (full-place 체크를 이미 통과 못 했으므로 overflow > -safety. 진짜 본문 하단
        //  기준으로 한 줄 미만 초과면 마지막 줄 spill 대신 통째 배치.)
        let overflow = st.current_height + fmt.height_for_fit - true_available;
        // [#7429] 문서 근거 없는 잉크 없는 꼬리는 줄이 **온전히** 들어가야 한다 — 한/글은
        // +100 HWPUNIT(1.3px)만 넘쳐도 다음 쪽으로 넘긴다. drift 안전마진을 뺀 `available`
        // 대신 진짜 본문 하단으로 재는 것은 그대로 두어, 줄이 들어가는 빈 꼬리는 마진 때문에
        // 밀리지 않는다.
        let within_limit = if tail_allowance.requires_whole_line {
            overflow <= 0.0
        } else {
            overflow < first_line_advance
        };
        if within_limit {
            st.commit_tail_overflow_paragraph(para_idx, fmt.total_height, body_bottom_vpos);
            return true;
        }
    }
    false
}

/// 일반 fit/넘침 허용 실패 뒤 빈 구성 결과 또는 분할 진입을 조정한다.
#[allow(clippy::too_many_arguments)]
pub(super) fn place_after_failed_fit(
    engine: &super::TypesetEngine,
    st: &mut TypesetState,
    para_idx: usize,
    para: &Paragraph,
    fmt: &FormattedParagraph,
    paragraphs: &[Paragraph],
    styles: &ResolvedStyleSet,
    trim_spacing_before_for_flow: bool,
    trimmed_sb_gate: f64,
    body_bottom_vpos: Option<i32>,
    available: f64,
    layout_drift_safety_px: f64,
    stored_vpos_rewind_break: bool,
    stored_vpos_rewind_overflow_break: bool,
    forced_page_break_line: Option<usize>,
    native_hwp5_existing_footnote_reset_line: Option<usize>,
    current_page_vpos_base: Option<i32>,
    dpi: f64,
) {
    // split: 줄 단위 분할
    let line_count = fmt.line_heights.len();
    // [#2004] tac(글자처럼) 전면 그림이 줄마다 하나씩 쌓인 "이미지 스택" 문단은 저장
    // LINE_SEG 가 각 줄 vpos=0(각자 쪽 상단)으로 인코딩되어, 아래 hwp_authoritative
    // (다음 줄 vpos==0 이고 현재 줄 bottom 이 본문 안이면 현재 쪽 유지) 가 모든 줄을 한
    // 쪽에 쌓아 버린다. 이 문단만 hwp_authoritative 를 끄고 줄별 fit 분할(쪽당 1장)로
    // 되돌린다. 게이트는 formatter 의 stacked_tac_picture_heights 와 동일 의미.
    let tac_picture_only_para = para_is_treat_as_char_picture_only(para);
    let is_tac_picture_stack = tac_picture_only_para
        && line_count >= 2
        && fmt
            .line_heights
            .iter()
            .all(|h| *h > st.base_available_height() * 0.5);
    if line_count == 0 {
        st.begin_empty_line_paragraph(para_idx);
        // [Task #391] 다단/단단 분기:
        //   - 단단 (col_count == 1): total_height (k-water-rfp p3 311px drift 차단, #359)
        //   - 다단 (col_count > 1): height_for_fit (exam_eng 8p 정상 단 채움 복원)
        // 다단에서는 layout 이 vpos 기반으로 항목을 단별로 stacking 하므로
        // typeset 누적 시 trailing_ls 인플레이션이 단을 조기 종료시킴.
        let advance = fmt.flow_advance_height(
            para,
            st.col_count,
            trim_spacing_before_for_flow,
            st.vpos_ladder_dirty
                || source_spacing_trim_changes_next_origin(
                    st, para_idx, para, fmt, paragraphs, styles,
                    trim_spacing_before_for_flow, false, dpi,
                )
                || !spacing_trim_restorable(paragraphs, para_idx)
                || next_boundary_reverts_spacing_trim(
                    st.profile.hwpx_stored_layout() && !st.profile.hwp3_layout(),
                    paragraphs,
                    styles,
                    para_idx,
                    dpi,
                ),
            false,
        );
        let trimmed_spacing_before = trimmed_sb_gate
            * fmt.flow_trimmed_spacing_before(
                para,
                st.col_count,
                trim_spacing_before_for_flow,
                st.vpos_ladder_dirty
                || source_spacing_trim_changes_next_origin(
                    st, para_idx, para, fmt, paragraphs, styles,
                    trim_spacing_before_for_flow, false, dpi,
                )
                    || !spacing_trim_restorable(paragraphs, para_idx)
                    || next_boundary_reverts_spacing_trim(
                        st.profile.hwpx_stored_layout() && !st.profile.hwp3_layout(),
                        paragraphs,
                        styles,
                        para_idx,
                        dpi,
                    ),
                false,
            );
        st.apply_full_paragraph_flow(
            advance,
            fmt.total_height,
            trimmed_spacing_before,
            body_bottom_vpos,
        );
        return;
    }

    // Task #332 Stage 4a: partial split 시에도 동일 마진 적용
    let base_available = (st.base_available_height() - layout_drift_safety_px).max(0.0);

    let entry_fit = split_entry::inspect_entry(
        para,
        fmt,
        paragraphs,
        styles,
        para_idx,
        line_count,
        available,
        &st.paragraph_split_entry_page(),
        dpi,
    );
    if entry_fit.hangul2024_split_refit && !para_has_visible_text(para) && para.controls.is_empty()
    {
        st.mark_blank_paragraph_spill(para_idx);
    }
    if split_entry::should_advance(
        para,
        &entry_fit,
        available,
        stored_vpos_rewind_break,
        stored_vpos_rewind_overflow_break,
        &st.paragraph_split_entry_page(),
        dpi,
    ) {
        st.advance_column_or_new_page();
    }

    place_split_paragraph(
        engine, styles,
        st,
        para_idx,
        para,
        fmt,
        paragraphs,
        line_count,
        base_available,
        layout_drift_safety_px,
        forced_page_break_line,
        native_hwp5_existing_footnote_reset_line,
        current_page_vpos_base,
        is_tac_picture_stack,
        dpi,
    );
}

/// 문단 진입 조정과 1회성 fit 예산 소비 결과. 실제 분할 경계는 이후에 계산한다.
pub(super) struct FitBudget {
    pub strict_after_empty_host_float: bool,
    pub layout_drift_safety_px: f64,
    pub prev_is_partial_table: bool,
    pub available: f64,
}

/// 저장 꼬리 → 진단 → 편집 그림 이월 → 보정 소비 → float 배제 → 예산 순서를 보존한다.
pub(super) fn prepare_fit_budget(
    st: &mut TypesetState,
    para_idx: usize,
    para: &Paragraph,
    fmt: &FormattedParagraph,
    paragraphs: &[Paragraph],
    session_edited: bool,
    dpi: f64,
) -> FitBudget {
    if entry::stored_tail_fills_page(
        para_idx,
        para,
        paragraphs,
        st.profile.hwp5_stored_pagination_layout(),
        st.current_height,
        dpi,
        || st.available_height(),
    ) {
        st.fill_paragraph_entry_page_tail();
    }

    // [#2243 진단] 문단 진입 시 누적 높이 — 항목별 실소비 델타 추적용. 동작 불변.
    if std::env::var("RHWP_DIAG_FLOW").is_ok() {
        eprintln!(
            "DIAG_FLOW pi={} cur_h={:.1} page={} items={} ct={:?}",
            para_idx,
            st.current_height,
            st.pages.len(),
            st.current_items.len(),
            para.column_type,
        );
    }

    if entry::edited_picture_requires_transition(
        para,
        fmt,
        session_edited,
        !st.current_items.is_empty(),
        st.current_height,
        dpi,
        || st.available_height(),
    ) {
        st.advance_column_or_new_page();
    }

    let strict_after_empty_host_float = st.take_strict_paragraph_fit(para);
    let layout_drift_safety_px = fit::layout_drift_safety_px(paragraphs);
    let prev_is_partial_table =
        matches!(st.current_items.last(), Some(PageItem::PartialTable { .. }));
    let safety = st.take_paragraph_safety_margin(
        strict_after_empty_host_float,
        prev_is_partial_table,
        layout_drift_safety_px,
    );
    let exclusion_probe_height = fit::exclusion_probe_height(fmt, st.profile.hwpx_stored_layout());
    st.apply_visible_float_exclusions(exclusion_probe_height);
    let footnote_margin_addback =
        st.take_paragraph_footnote_margin_addback(strict_after_empty_host_float);
    let tail_overflow =
        st.take_paragraph_tail_overflow(strict_after_empty_host_float, fmt.height_for_fit);
    let available =
        (st.available_height() - safety + footnote_margin_addback + tail_overflow).max(0.0);

    FitBudget {
        strict_after_empty_host_float,
        layout_drift_safety_px,
        prev_is_partial_table,
        available,
    }
}

/// 다단 분기 전에만 검사한다. 흡수 시 항목이나 숨김 횟수를 추가하지 않는다.
pub(super) fn try_absorb_rowbreak_guide(
    st: &mut TypesetState,
    prev_is_partial_table: bool,
    para: &Paragraph,
    paragraphs: &[Paragraph],
    para_idx: usize,
) -> bool {
    if empty::hide_rowbreak_guide(prev_is_partial_table, para, paragraphs, para_idx) {
        st.hide_empty_paragraph(para_idx);
        return true;
    }
    false
}

/// 저장 줄 상자가 본문 높이를 넘으면 빈 꼬리 흡수와 끝 쪽 제거 모두에서 보존한다.
/// Enter 재조판은 쪽 경계에서 vpos를 되감지 않으므로 이 줄은 실제 흐름을 점유한다.
pub(super) fn stored_line_overflows_body(para: &Paragraph, body_height: f64, dpi: f64) -> bool {
    let body_height_hu = crate::renderer::px_to_hwpunit(body_height, dpi);
    para.line_segs
        .first()
        .is_some_and(|ls| ls.vertical_pos.saturating_add(ls.line_height) > body_height_hu)
}

/// 다단 조판의 조기 반환 뒤에서만 실행한다. 숨김 옵션의 페이지 수명과 구역 끝 처리를 구분한다.
#[allow(clippy::too_many_arguments)]
pub(super) fn try_absorb_empty_paragraph(
    st: &mut TypesetState,
    para_idx: usize,
    para: &Paragraph,
    fmt: &FormattedParagraph,
    paragraphs: &[Paragraph],
    is_last_in_section: bool,
    available: f64,
    layout_drift_safety_px: f64,
) -> bool {
    // [Task #362] 한컴 빈 줄 감추기 (SectionDef bit 19, hide_empty_line):
    // 빈 paragraph 가 현재 공간을 overflow 시키면 height=0 으로 처리 (페이지 당 최대 2개).
    // Paginator (engine.rs:85-106) 와 동일 시멘틱.
    // (kps-ai p67~70 case: PartialTable 후속 빈 paragraphs 가 다수 발생, 한컴은 표시 안 함.)
    if st.hide_empty_line {
        st.begin_empty_paragraph_page();
        if empty::hide_overflowing_empty(
            para,
            fmt,
            !st.current_items.is_empty(),
            st.current_height,
            available,
            st.hidden_empty_lines,
        ) {
            st.commit_counted_hidden_paragraph(para_idx);
            return true;
        }
    }
    // 마지막 빈 문단도 유효한 줄 상자를 소유한다. 저장 줄이 이미 본문 밖에
    // 있으면 미세 drift용 Hidden/Unadvanced 처리로 그 소유를 없애지 않는다.
    if stored_line_overflows_body(para, st.layout.body_area.height, st.layout.dpi) {
        return false;
    }
    match empty::trailing_disposition(
        para,
        fmt,
        paragraphs,
        is_last_in_section,
        available,
        layout_drift_safety_px,
        &st.paragraph_empty_tail_page(),
    ) {
        empty::TailDisposition::Continue => false,
        empty::TailDisposition::Hidden => {
            st.hide_empty_paragraph(para_idx);
            true
        }
        empty::TailDisposition::Unadvanced => {
            st.place_unadvanced_empty_paragraph(para_idx);
            true
        }
    }
}

pub(super) struct WholeFitDecision {
    pub fits: bool,
    pub stored_vpos_rewind_break: bool,
    pub stored_vpos_rewind_overflow_break: bool,
}

/// 저장 근거 조회 → 진단 → 빈 문단 spill 기록 → 전체 fit 선택 순서를 보존한다.
#[allow(clippy::too_many_arguments)]
pub(super) fn decide_whole_fit(
    st: &mut TypesetState,
    para_idx: usize,
    para: &Paragraph,
    fmt: &FormattedParagraph,
    paragraphs: &[Paragraph],
    strict_after_empty_host_float: bool,
    forced_page_break_line: Option<usize>,
    current_page_vpos_base: Option<i32>,
    available: f64,
    dpi: f64,
) -> WholeFitDecision {
    let whole_fit::WholeFitEvidence {
        saved_single_line_bottom_fits,
        saved_list_tail_body_vpos_fits,
        page_end_fit_height,
        stored_vpos_rewind_break,
        stored_vpos_rewind_overflow_break,
        hangul2024_rewind_override,
    } = whole_fit::inspect(
        para_idx,
        para,
        fmt,
        paragraphs,
        strict_after_empty_host_float,
        forced_page_break_line,
        current_page_vpos_base,
        available,
        &st.paragraph_whole_fit_page(),
        dpi,
        || st.available_height(),
    );
    if std::env::var("RHWP_DIAG_COMPAT24").is_ok()
        && stored_vpos_rewinds(preceding_stored_vpos(paragraphs, para_idx), para)
    {
        eprintln!(
            "DIAG_COMPAT24 rewind-site pi={para_idx} break={stored_vpos_rewind_break} \
             cur={:.1} fit_h={page_end_fit_height:.1} avail={available:.1} \
             reclaimed={:.1} items={} forced={:?}",
            st.current_height,
            st.hangul2024_reclaimed,
            st.current_items.len(),
            forced_page_break_line,
        );
    }
    // [compat 2024] 저장 신호를 덮은 그 빈 문단만 한글 2024 처럼 쪽 하단
    // 여백으로 흘린다(place 적합 우회). 이웃 빈 문단까지 흘리면 2024 보다
    // 한 문단 과적재된다(idx22 실측). 되감김 덮음도 같은 자격을 준다.
    if hangul2024_rewind_override && !para_has_visible_text(para) && para.controls.is_empty() {
        st.mark_blank_paragraph_spill(para_idx);
    }
    let hangul2024_blank_spill = st.profile.hangul2024_layout()
        && st.hangul2024_spill_para == Some(para_idx)
        && !st.current_items.is_empty();
    if std::env::var("RHWP_DIAG_6031").is_ok()
        && st.current_height + page_end_fit_height > available
    {
        eprintln!(
            "DIAG_6031 pi={para_idx} cur={:.1} fit_h={page_end_fit_height:.1} avail={available:.1} single={saved_single_line_bottom_fits} list_tail={saved_list_tail_body_vpos_fits} base={:?}",
            st.current_height, current_page_vpos_base,
        );
    }
    WholeFitDecision {
        fits: forced_page_break_line.is_none()
            && !stored_vpos_rewind_break
            && (hangul2024_blank_spill
                || st.current_height + page_end_fit_height <= available
                || saved_single_line_bottom_fits
                || saved_list_tail_body_vpos_fits),
        stored_vpos_rewind_break,
        stored_vpos_rewind_overflow_break,
    }
}

/// 기존 각주 경계는 선택된 강제 경계와 별도로 후속 줄 스캔에서도 소비한다.
pub(super) struct ForcedPageBoundary {
    pub native_hwp5_existing_footnote_reset_line: Option<usize>,
    pub current_page_vpos_base: Option<i32>,
    pub forced_page_break_line: Option<usize>,
}

/// 기존 각주 경계를 먼저 조회하고, 저장/각주/그림 후보를 원래 단락 순서로 선택한다.
/// 이 조정자는 읽기 전용이다. 각주 측정 helper의 좁은 관측 경계 분리는 R4에 남긴다.
pub(super) fn prepare_forced_page_boundary(
    st: &TypesetState,
    para_idx: usize,
    para: &Paragraph,
    fmt: &FormattedParagraph,
    paragraphs: &[Paragraph],
    available: f64,
    dpi: f64,
) -> ForcedPageBoundary {
    // native HWP5 본문은 기존 각주가 있는 page tail에서도 `vpos=0` reset으로
    // 다음 physical page를 기록할 수 있다. 일반 reset은 과분할 위험이 있으므로,
    // 실제 FootnoteArea 경계와 source/flow가 함께 맞을 때만 강제 경계로 쓴다.
    let native_hwp5_existing_footnote_reset_line =
        native_hwp5_existing_footnote_reset_overlap_break_line(st, para, fmt, paragraphs, dpi);
    // 흐름 스냅이 이미 확정한 지연 기준은 마지막 줄·내부 쪽 경계도 함께 소비한다.
    // 첫 빈 개체 호스트의 저장 위치는 표 밴드 뒤의 줄일 수 있어 쪽 원점으로 다시 쓰지 않는다.
    let current_page_vpos_base = st.vpos_page_base.or(st.vpos_lazy_base).or_else(|| {
        st.current_items
            .first()
            .and_then(|item| page_item_vpos_base(item, paragraphs))
    });
    // 쪽 소유가 저장 앵커와 현재 흐름으로 입증된 일반 본문은 시작 높이의
    // 비율로 다시 거절하지 않는다. 기존 세션 편집 플래그와 구성 줄 수,
    // 유효 저장 앵커를 확인하고 실제 재조판으로 사라진 reset은 재사용하지 않는다.
    // 같은 원본 줄 사다리와 실제 흐름은 컨테이너 형식과 무관하게 같은 쪽을 소유한다.
    let anchored_stored_body_reset_line = ((st.profile.hwpx_stored_layout()
        || st.profile.hwp5_stored_pagination_layout())
        && (!st.profile.session_edited()
            || native_edited_reset_witness(st,para,fmt,current_page_vpos_base,available,dpi))
        && para_has_visible_text(para)
        && fmt.line_heights.len() == para.line_segs.len())
    .then(|| {
        (1..para.line_segs.len()).find(|&break_line| {
            para.line_segs[break_line].vertical_pos < para.line_segs[break_line - 1].vertical_pos
                && stored_body_reset_fragment_matches_current_flow(
                    st,
                    para,
                    0,
                    break_line,
                    current_page_vpos_base.unwrap_or(0),
                    fmt.spacing_before,
                    dpi,
                )
        })
    })
    .flatten();
    let hwp3_converted_hwp5 = st.profile.hwp3_layout()
        && !st.profile.hwp3_native_layout()
        && !st.profile.hwpx_container();
    let internal_forced_page_break_line = boundary::internal_vpos_page_break_line(
        para,
        fmt.line_heights.len(),
        st.layout.body_area.height,
        dpi,
        st.profile.hwpx_stored_layout() || st.profile.hwp3_native_layout() || hwp3_converted_hwp5,
        st.profile.hwp5_stored_pagination_layout(),
        hwp3_converted_hwp5,
    )
    .filter(|break_line| {
        // HWPX의 reset은 local writer cursor도 재사용한다. 현재 flow와
        // anchor가 맞지 않는 reset은 physical page 경계로 승격하지 않는다.
        !st.profile.hwpx_stored_layout()
            || st.current_items.is_empty()
            || stored_body_reset_fragment_matches_current_flow(
                st,
                para,
                0,
                *break_line,
                current_page_vpos_base.unwrap_or(0),
                fmt.spacing_before,
                dpi,
            )
    });
    let forced_page_break_line = anchored_stored_body_reset_line
        .or(internal_forced_page_break_line)
        .or_else(|| {
            st.profile.hwpx_stored_layout().then(|| {
                boundary::hwpx_explicit_page_break_tail_line(
                    para,
                    paragraphs.get(para_idx + 1),
                    fmt.line_heights.len(),
                    st.layout.body_area.height,
                    dpi,
                )
            })?
        })
        .or_else(|| {
            native_hwp5_first_footnote_overlap_break_line(st, para, fmt, dpi)
                .map(|footnote_break| footnote_break.body_break_line)
        })
        .or_else(|| {
            missing_lineseg_trailing_line_break(
                para,
                fmt.line_heights.len(),
                st.current_height,
                available,
                fmt.line_spacings.last().copied().unwrap_or(0.0),
                st.profile.hwpx_stored_layout() || hwp3_converted_hwp5,
                hwp3_converted_hwp5,
            )
        })
        .or_else(|| {
            native_hwp5_text_reset_before_large_tac_topbottom_picture_break_line(
                st, para, fmt, paragraphs, para_idx, dpi,
            )
        })
        // full-fit early return보다 앞의 같은 chain에 넣어야 reset tail을 통째로
        // 배치해 separator와 겹치는 우회가 없다.
        .or(native_hwp5_existing_footnote_reset_line);
    ForcedPageBoundary {
        native_hwp5_existing_footnote_reset_line,
        current_page_vpos_base,
        forced_page_break_line,
    }
}

/// 일반 줄 분할과 구분되는 저장 다단 경로. 선택된 경계가 있으면 기존처럼 이 경로가
/// 문단을 소비한다. 유효 조각이 없어 루프를 종료해도 일반 fit 경로로 재진입하지 않는다.
pub(super) fn try_place_multicolumn_paragraph(
    st: &mut TypesetState,
    para_idx: usize,
    para: &Paragraph,
    fmt: &FormattedParagraph,
    dpi: f64,
) -> bool {
    let col_breaks = columns::detect_breaks(
        para,
        st.col_count,
        st.current_column,
        st.current_endnote_flow,
        st.layout.available_body_height(),
        dpi,
    );
    if col_breaks.len() <= 1 {
        return false;
    }
    let line_count = fmt.line_heights.len();
    for (bi, &break_start) in col_breaks.iter().enumerate() {
        let break_end = if bi + 1 < col_breaks.len() {
            col_breaks[bi + 1]
        } else {
            line_count
        };
        let Some(fragment) =
            columns::plan_fragment(para_idx, fmt, break_start, break_end, line_count)
        else {
            break;
        };
        let observed_flow_before=st.current_height;
        let observed_advance=fragment.height;
        st.commit_multicolumn_paragraph_fragment(fragment);
        observe_selected_commit127(st,para_idx,para,fmt,break_start,break_end,observed_flow_before,observed_advance,None,None,0.0,true);

        // 마지막 조각이 아니면 다음 단으로 진행.
        if bi + 1 < col_breaks.len() {
            st.advance_after_multicolumn_fragment();
        }
    }
    true
}

/// Unchanged ordinary native rows have no control/story/formatting owner outside
/// this paragraph. A runtime recomposition, stale source projection or local edit
/// cannot use this saved partition as a pagination witness.
pub(super) fn unchanged_native_plain_rows(para: &Paragraph) -> bool {
    use crate::model::paragraph::ColumnBreakType;
    if para.char_offsets.len()!=para.text.chars().count(){return false;}
    let mut utf16=0u32;
    for(i,c)in para.text.chars().enumerate(){
        if para.char_offsets.get(i)!=Some(&utf16){return false;}
        let Some(next)=utf16.checked_add(c.len_utf16() as u32)else{return false;};utf16=next;
    }
    if para.char_count!=utf16 && utf16.checked_add(1)!=Some(para.char_count){return false;}
    !para.stored_text_partition_is_dirty() && !para.cell_format_vpos_dirty
        && para.controls.is_empty() && para.field_ranges.is_empty()
        && para.orphan_field_ends.is_empty() && para.range_tags.is_empty()
        && para.ctrl_data_records.iter().all(Option::is_none)
        && para.tab_extended.is_empty() && para.title_marks.is_empty() && para.markpen_marks.is_empty()
        && para.numbering_restart.is_none()
        && para.column_type == ColumnBreakType::None && para.hwpx_axis_shift == 0
        && para.layout_only_fill_lines == 0 && !para.line_segs.is_empty()
        && para_has_visible_text(para) && !para.text.chars().any(|c| c < ' ' || c == '\u{fffc}')
        && para.line_segs.first().is_some_and(|s| s.text_start == 0)
        && para.line_segs.iter().all(|r| !is_synthetic_line_seg(r)
            && r.vertical_pos >= 0 && r.line_height > 0 && r.text_height > 0
            && r.baseline_distance >= 0 && r.baseline_distance <= r.line_height
            && r.line_spacing >= 0 && r.column_start >= 0 && r.segment_width > 0
            && r.column_start.checked_add(r.segment_width).is_some()
            && r.vertical_pos.checked_add(r.line_height).and_then(|v| v.checked_add(r.line_spacing)).is_some()
            && (r.text_start == 0 || para.char_offsets.binary_search(&r.text_start).is_ok()))
        && para.line_segs.windows(2).all(|w| w[0].text_start < w[1].text_start)
        && para.source_line_seg_vertical_pos.as_ref().is_none_or(|v|
            v.len() == para.line_segs.len() && v.iter().zip(&para.line_segs).all(|(a,b)| *a == b.vertical_pos))
}
/// Issued by the format owner after it has selected the actual current
/// composition. Equal row heights alone do not prove the saved partition.
pub(super) fn actual_composition_matches_saved(para:&Paragraph, composed:Option<&crate::renderer::composer::ComposedParagraph>)->bool {
    if !unchanged_native_plain_rows(para){return false;}
    let Some(comp)=composed else{return false;};
    if comp.para_style_id!=para.para_shape_id || comp.lines.len()!=para.line_segs.len()
        || !comp.inline_controls.is_empty() || comp.numbering_text.is_some()
        || !comp.tac_controls.is_empty() || !comp.footnote_positions.is_empty()
        || !comp.tab_extended.is_empty() || comp.horizontal_shaping.is_some()
        || para.char_shapes.windows(2).any(|w|w[0].start_pos>=w[1].start_pos)
    {return false;}
    let chars:Vec<char>=para.text.chars().collect();
    for(i,(line,row))in comp.lines.iter().zip(&para.line_segs).enumerate(){
        let Ok(start)=para.char_offsets.binary_search(&row.text_start)else{return false;};
        let end=if let Some(next)=para.line_segs.get(i+1){let Ok(end)=para.char_offsets.binary_search(&next.text_start)else{return false;};end}else{chars.len()};
        if line.char_start!=start || line.line_height!=row.line_height || line.line_spacing!=row.line_spacing
            || line.baseline_distance!=row.baseline_distance || line.column_start!=row.column_start
            || line.segment_width!=row.segment_width || line.has_line_break || start>=end
        {return false;}
        let mut at=start;
        for run in &line.runs {
            if run.char_overlap.is_some() || run.footnote_marker.is_some() || run.inserted_control_text || run.display_text.is_some(){return false;}
            for c in run.text.chars(){
                if at>=end || chars[at]!=c {return false;}
                let index=para.char_shapes.partition_point(|s|s.start_pos<=para.char_offsets[at]);
                let expected=index.checked_sub(1).map_or(0,|i|para.char_shapes[i].char_shape_id);
                if run.char_style_id!=expected{return false;}at+=1;
            }
        }
        if at!=end{return false;}
    }
    true
}
pub(super) fn composed_rows_equal_saved(para: &Paragraph, fmt: &metrics::FormattedParagraph, dpi:f64) -> bool {
    fmt.source_rows_match_current_format && dpi.is_finite() && dpi > 0.0 && fmt.line_count() == para.line_segs.len()
        && para.line_segs.iter().enumerate().all(|(i,r)|
            fmt.line_heights[i] == crate::renderer::hwpunit_to_px(r.line_height,dpi)
            && fmt.line_spacings[i] == crate::renderer::hwpunit_to_px(r.line_spacing,dpi))
}
/// A saved prefix only owns visible rows inside this actual available frame.
/// Trailing line spacing is not ink, so its page-tail trimming remains separate.
pub(super) fn native_reset_prefix_fits(para:&Paragraph, break_line:usize, base:i32, available:f64, dpi:f64)->bool {
    if !available.is_finite() || available<=0.0 || !dpi.is_finite() || dpi<=0.0
        || break_line==0 || break_line>=para.line_segs.len(){return false;}
    para.line_segs[..break_line].iter().all(|r| {
        if r.line_height<=0 || r.text_height<=0 || r.text_height>r.line_height {return false;}
        let Some(top)=r.vertical_pos.checked_sub(base).filter(|v|*v>=0)else{return false;};
        let Some(end)=top.checked_add(r.line_height)else{return false;};
        crate::renderer::hwpunit_to_px(end,dpi)<=available
    })
}
fn native_edited_reset_witness(st:&TypesetState, para:&Paragraph, fmt:&metrics::FormattedParagraph, base:Option<i32>, available:f64, dpi:f64)->bool {
    if !st.profile.hwp5_stored_pagination_layout() || !st.profile.session_edited()
        || st.col_count != 1 || !unchanged_native_plain_rows(para)
        || !composed_rows_equal_saved(para,fmt,dpi) { return false; }
    let Some(base)=base else{return false;};
    let Some(first)=para.line_segs.first() else{return false;};
    let Some(delta)=first.vertical_pos.checked_sub(base) else{return false;};
    if crate::renderer::px_to_hwpunit(st.current_height+fmt.spacing_before,dpi)!=delta {return false;}
    let resets=para.line_segs.windows(2).filter(|w|w[1].vertical_pos<w[0].vertical_pos).count();
    let Some(break_line)=para.line_segs.windows(2).position(|w|w[1].vertical_pos<w[0].vertical_pos).map(|i|i+1)else{return false;};
    resets==1 && native_reset_prefix_fits(para,break_line,base,available,dpi) && para.line_segs.windows(2).all(|w| w[1].vertical_pos==0
        || w[0].vertical_pos.checked_add(w[0].line_height).and_then(|v|v.checked_add(w[0].line_spacing))==Some(w[1].vertical_pos))
}

/// A changed source-vpos snapshot identifies a reconstructed ordinary body, but
/// is not itself a failed snap. Compare the actual HeightCursor decisions at
/// trimmed and full consumption; retain trimming only if both reach exactly
/// the same position and the same future page/lazy origin.
#[allow(clippy::too_many_arguments)]
pub(super) fn source_spacing_trim_changes_next_origin(
    st: &TypesetState, para_idx: usize, para: &Paragraph, fmt: &FormattedParagraph,
    paragraphs: &[Paragraph], styles: &ResolvedStyleSet,
    trim_before: bool, lazy_base: bool, dpi: f64,
) -> bool {
    let native_edited = st.profile.hwp5_stored_pagination_layout() && st.profile.session_edited();
    if st.col_count != 1 || !(st.profile.hwpx_stored_layout() || native_edited)
        || (st.profile.session_edited() && !native_edited) || para.stored_text_partition_is_dirty()
        || para.cell_format_vpos_dirty || !para.controls.is_empty()
        || !para.field_ranges.is_empty() || !para.orphan_field_ends.is_empty()
        || para.text.contains('\t')
    { return false; }
    let current_rows:Vec<i32>;
    let source = if native_edited {
        if !unchanged_native_plain_rows(para) || !composed_rows_equal_saved(para,fmt,dpi) {return false;}
        current_rows=para.line_segs.iter().map(|r|r.vertical_pos).collect(); &current_rows
    } else {let Some(source)=para.source_line_seg_vertical_pos.as_ref() else{return false;}; source};
    if source.len() != para.line_segs.len() || source.is_empty()
        || !source.iter().any(|&v| v > 0) || source.iter().any(|&v| v < 0)
        || source.windows(2).any(|w| w[1] < w[0])
        || para.line_segs.iter().any(is_synthetic_line_seg)
        || (!native_edited && source.iter().zip(&para.line_segs).all(|(&v, line)| v == line.vertical_pos))
    { return false; }
    let Some(next) = paragraphs.get(para_idx + 1) else { return false; };
    if !next.controls.is_empty() || !next.field_ranges.is_empty()
        || !next.orphan_field_ends.is_empty() || next.stored_text_partition_is_dirty()
        || next.cell_format_vpos_dirty || next.line_segs.is_empty()
        || next.line_segs.iter().any(is_synthetic_line_seg)
    { return false; }
    // The existing uniform-filler cursor is a whole-section predicate. A local
    // multi-row paragraph disproves its necessary one-row condition without
    // rescanning an arbitrarily large section for every body paragraph.
    let local_nonuniform = paragraphs.len() < 8
        || paragraphs[para_idx.saturating_sub(1)..(para_idx + 2).min(paragraphs.len())]
            .iter().any(|p| p.line_segs.len() != 1);
    if !local_nonuniform { return false; }
    if native_edited {
        if !unchanged_native_plain_rows(next)
            || next.line_segs.windows(2).filter(|w|w[1].vertical_pos<w[0].vertical_pos).count()>1
            || next.line_segs.windows(2).any(|w|w[1].vertical_pos!=0 && w[0].vertical_pos.checked_add(w[0].line_height).and_then(|v|v.checked_add(w[0].line_spacing))!=Some(w[1].vertical_pos)) {return false;}
        let Some(base)=st.vpos_page_base.or(st.vpos_lazy_base) else{return false;};
        let Some(delta)=para.line_segs[0].vertical_pos.checked_sub(base) else{return false;};
        if crate::renderer::px_to_hwpunit(st.current_height+fmt.spacing_before,dpi)!=delta{return false;}
    }
    let trimmed = fmt.flow_advance_height(para, 1, trim_before, false, lazy_base);
    if trimmed >= fmt.total_height { return false; }
    let mut a = super::shared_body_height_cursor(st, dpi, false, st.profile.session_edited());
    a.prev_layout_para = Some(para_idx);
    a.prev_item_was_partial_table = false;
    a.trimmed_prev_spacing_before_px = if st.profile.hwp5_stored_pagination_layout() {
        fmt.flow_trimmed_spacing_before(para, 1, trim_before, false, lazy_base)
    } else { 0.0 };
    let mut b = super::shared_body_height_cursor(st, dpi, false, st.profile.session_edited());
    b.prev_layout_para = Some(para_idx);
    b.prev_item_was_partial_table = false;
    b.trimmed_prev_spacing_before_px = 0.0;
    let from_trim = a.vpos_adjust(st.current_height + trimmed, para_idx + 1, paragraphs, styles);
    let from_full = b.vpos_adjust(st.current_height + fmt.total_height, para_idx + 1, paragraphs, styles);
    if native_edited {
        let Some(base)=st.vpos_page_base.or(st.vpos_lazy_base) else{return false;};
        let Some(delta)=next.line_segs[0].vertical_pos.checked_sub(base) else{return false;};
        let Some(next_style)=styles.para_styles.get(next.para_shape_id as usize) else{return false;};
        if crate::renderer::px_to_hwpunit(from_full+next_style.spacing_before,dpi)!=delta || b.vpos_page_base!=st.vpos_page_base || b.vpos_lazy_base!=st.vpos_lazy_base {return false;}
    }
    from_trim != from_full || a.vpos_page_base != b.vpos_page_base
        || a.vpos_lazy_base != b.vpos_lazy_base
}

#[cfg(test)]
mod native_current_body_boundary_tests {
use crate::model::{paragraph::{Paragraph,LineSeg,RangeTag,FieldRange},control::{Control,UnknownControl}};
use serde_json::{Value,json};
fn cases()->Vec<Value>{let row=|text_start,v|LineSeg{text_start,vertical_pos:v,line_height:100,text_height:100,baseline_distance:75,line_spacing:60,column_start:0,segment_width:1000,tag:0x60000};let p=Paragraph{text:"A😀B".into(),char_count:5,char_offsets:vec![0,1,3],line_segs:vec![row(0,100),row(3,0)],..Default::default()};let mut cases=vec![("positive-plain-emoji",p.clone(),true)];macro_rules! bad{($name:expr,$change:expr)=>{{let mut q=p.clone();($change)(&mut q);cases.push(($name,q,false));}};}bad!("dirty",|q:&mut Paragraph|q.stored_text_partition_dirty=true);bad!("cell-dirty",|q:&mut Paragraph|q.cell_format_vpos_dirty=true);bad!("synthetic",|q:&mut Paragraph|q.line_segs[0].tag|=LineSeg::TAG_IMPLEMENTATION_PROPERTY);bad!("hidden-utf16-slot",|q:&mut Paragraph|q.char_offsets[2]=11);bad!("char-count",|q:&mut Paragraph|q.char_count+=8);bad!("unknown-control",|q:&mut Paragraph|q.controls.push(Control::Unknown(UnknownControl{ctrl_id:0x11223344})));bad!("range-tag",|q:&mut Paragraph|q.range_tags.push(RangeTag::default()));bad!("field",|q:&mut Paragraph|q.field_ranges.push(FieldRange::default()));bad!("stale-source-vpos",|q:&mut Paragraph|q.source_line_seg_vertical_pos=Some(vec![100,1]));bad!("row-end-overflow",|q:&mut Paragraph|q.line_segs[0].vertical_pos=i32::MAX);bad!("raw-control-payload",|q:&mut Paragraph|q.ctrl_data_records.push(Some(vec![0])));bad!("literal-tab",|q:&mut Paragraph|q.text="A\tB".into());cases.into_iter().map(|(name,p,expected)|json!({"name":name,"expected":expected,"actual":super::unchanged_native_plain_rows(&p)})).collect()}

fn composed_cases()->Vec<Value>{use crate::renderer::composer::{ComposedParagraph,ComposedLine,ComposedTextRun};let row=|text_start,v|LineSeg{text_start,vertical_pos:v,line_height:100,text_height:100,baseline_distance:75,line_spacing:60,column_start:0,segment_width:1000,tag:0x60000};let p=Paragraph{text:"A😀B".into(),char_count:5,char_offsets:vec![0,1,3],line_segs:vec![row(0,100),row(3,0)],..Default::default()};let line=|start,text:&str|ComposedLine{runs:vec![ComposedTextRun{text:text.into(),..Default::default()}],line_height:100,baseline_distance:75,segment_width:1000,column_start:0,line_spacing:60,has_line_break:false,char_start:start};let c=ComposedParagraph{lines:vec![line(0,"A😀"),line(2,"B")],para_style_id:0,inline_controls:vec![],numbering_text:None,tac_controls:vec![],footnote_positions:vec![],tab_extended:vec![],horizontal_shaping:None};let mut cases=vec![("actual-full-row-exact",c.clone(),true)];macro_rules! bad{($name:expr,$change:expr)=>{{let mut q=c.clone();($change)(&mut q);cases.push(($name,q,false));}};}bad!("fresh-same-height-start-changed",|q:&mut ComposedParagraph|q.lines[1].char_start=1);bad!("fresh-same-height-width-changed",|q:&mut ComposedParagraph|q.lines[0].segment_width=999);bad!("fresh-same-height-baseline-changed",|q:&mut ComposedParagraph|q.lines[0].baseline_distance=74);bad!("fresh-same-height-column-changed",|q:&mut ComposedParagraph|q.lines[0].column_start=1);bad!("partition-text-loss",|q:&mut ComposedParagraph|q.lines[0].runs[0].text="A".into());bad!("same-text-style-ID-changed",|q:&mut ComposedParagraph|q.lines[0].runs[0].char_style_id=1);bad!("hidden-note-owner",|q:&mut ComposedParagraph|q.lines[0].runs[0].footnote_marker=Some(1));cases.into_iter().map(|(name,c,expected)|json!({"name":name,"expected":expected,"actual":super::actual_composition_matches_saved(&p,Some(&c))})).collect()}

fn prefix_cases()->Vec<Value>{let row=|v|LineSeg{text_start:0,vertical_pos:v,line_height:100,text_height:100,baseline_distance:75,line_spacing:60,column_start:0,segment_width:1000,tag:0x60000};let p=Paragraph{line_segs:vec![row(100),row(0)],..Default::default()};let mut cases=vec![("prefix-visible-end-inside",p.clone(),0,200.0/75.0,true),("prefix-visible-end-outside",p.clone(),0,199.0/75.0,false),("prefix-before-frame-origin",p.clone(),101,200.0/75.0,false),("nonfinite-budget",p.clone(),0,f64::NAN,false)];let mut overflow=p.clone();overflow.line_segs[0].vertical_pos=i32::MAX;cases.push(("prefix-checked-end-overflow",overflow,0,200.0/75.0,false));let mut zero=p.clone();zero.line_segs[0].line_height=0;cases.push(("prefix-zero-height",zero,0,200.0/75.0,false));cases.into_iter().map(|(name,p,base,available,expected)|json!({"name":name,"expected":expected,"actual":super::native_reset_prefix_fits(&p,1,base,available,96.0)})).collect()}

fn check(cases:Vec<Value>,expected:usize){assert_eq!(cases.len(),expected);for case in cases{assert_eq!(case["actual"],case["expected"],"{}",case["name"]);}}
#[test]fn source_owner_13(){check(cases(),13);}
#[test]fn actual_format_8(){check(composed_cases(),8);}
#[test]fn visible_prefix_6(){check(prefix_cases(),6);}
}

/// Diagnostic connection of an actual selected format to an actually committed
/// body item. It neither recomposes the paragraph nor grants export permission.
#[allow(clippy::too_many_arguments)]
fn observe_selected_commit127(st:&TypesetState,index:usize,para:&Paragraph,fmt:&FormattedParagraph,start:usize,end:usize,
 before:f64,advance:f64,available:Option<f64>,cumulative:Option<f64>,trimmed:f64,multicol:bool){
 crate::renderer::selected_composition_observer127::commit(fmt.selected_observation127,para,st.section_index,
  st.pages.last().map(|p|p.page_index),st.current_column,index,start,end,before,st.current_height,advance,
  available,cumulative,trimmed,st.following_wrap_column_width(),multicol,st.col_count,&fmt.line_heights,&fmt.line_spacings,
  fmt.spacing_before,fmt.spacing_after,fmt.total_height,fmt.height_for_fit,&st.current_items);
}
