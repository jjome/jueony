from pathlib import Path
import json,hashlib
stage=Path('build/n001-visible-host142');p=stage/'source/src/renderer/current_visible_host142_tests.rs';saved=stage/'positive-tests-final.rs'
assert not saved.exists();saved.write_bytes(p.read_bytes());p.write_bytes((stage/'known-full84-tests.rs').read_bytes())
files=[]
for f in sorted((stage/'source/src').rglob('*.rs')):
 files.append({'path':f.relative_to(stage/'source').as_posix(),'rawSha256':hashlib.sha256(f.read_bytes()).hexdigest()})
(stage/'known-full84-compiled-source.json').write_text(json.dumps({'purpose':'Known unresolved Native/mixed expected-success matrix; expected failure is preserved, never counted as a feature PASS. Only the test child differs from the final runtime; source and raw guards unchanged.','files':files},indent=2)+'\n')
s=(stage/'native-first-public.sh').read_text().replace('actual_visible_table_host_first_public_export142','actual_visible_hosts_public_storage_history_and_mixed_reopens')
(stage/'native-known-full84.sh').write_text(s,newline='\n')
