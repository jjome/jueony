//! Export-only current HWPX visible T&B host proof. Its paint plan is receipt-only:
//! no table origin or body layout is overridden in the source or reopened file.
use super::*;
use crate::model::{control::Control,paragraph::{ColumnBreakType,Paragraph}};
use super::super::{pagination::PageItem,current_physical_selections::CurrentPhysicalSelections};
struct VisibleTable{paragraph:usize,incoming:f64,border:f64,left:f64,width:f64,body:f64,before:f64,visible:bool}
struct VisibleFrame<'doc>{source:&'doc Document,paint:CurrentFramePaintPlan,bodies:Vec<CandidateBody>,tables:Vec<VisibleTable>,rows:Vec<CurrentFrameParagraphRows>}
pub(crate) struct CurrentVisibleHostCandidate<'doc>{frames:Vec<VisibleFrame<'doc>>}
fn visible_fresh(p:&Paragraph,styles:&super::super::style_resolver::ResolvedStyleSet,width:f64,dpi:f64)->Option<FreshBodyRows>{
 if p.text.is_empty()||!p.text.chars().any(|c|!c.is_whitespace())||!matches!(p.controls.as_slice(),[Control::Table(_)])
  ||p.ctrl_data_records.iter().any(Option::is_some){return None;}
 let mut text=p.clone();text.controls.clear();text.ctrl_data_records.clear();text.char_count=text.char_count.checked_sub(8)?;
 let fresh=fresh_body_rows(&text,styles,width,dpi)?;
 // The table's sole eight-unit control follows the actual scalar/UTF16 text.
 // Keep it in the independent generic reflow; stripping it was validation only.
 let mut whole=p.clone();clear_fresh_input(&mut whole);
 super::super::composer::reflow_line_segs(&mut whole,super::super::composer::ParagraphBox::body_for_style(width,styles.para_styles.get(usize::from(p.para_shape_id)),dpi),styles,dpi);
 let actual=super::super::composer::compose_paragraph_in_context(&whole,styles);
 if whole.line_segs.len()!=fresh.rows.len()||actual.lines.len()!=fresh.composition.lines.len()
  ||!actual.inline_controls.is_empty()||!actual.tac_controls.is_empty()||!actual.footnote_positions.is_empty()
  ||actual.numbering_text.is_some()||actual.horizontal_shaping.is_some()||!actual.tab_extended.is_empty()
  ||!actual.lines.iter().zip(&fresh.composition.lines).all(|(a,b)|same_selected_line(a,b))
  ||!whole.line_segs.iter().zip(&fresh.rows).all(|(a,b)|a.text_start==b.text_start&&a.vertical_pos==b.vertical_pos&&a.line_height==b.line_height
   &&a.text_height==b.text_height&&a.baseline_distance==b.baseline_distance&&a.line_spacing==b.line_spacing&&a.column_start==b.column_start&&a.segment_width==b.segment_width&&a.tag==b.tag){return None;}
 Some(fresh)
}
impl<'doc> CurrentVisibleHostCandidate<'doc>{
 pub(crate) fn from_core(core:&crate::DocumentCore,source:&'doc Document)->Option<Self>{
  if !std::ptr::eq(source,core.document())||!core.computed_row_resources_supported()||core.batch_mode||core.pending_pagination_job.is_some()
   ||core.deferred_pagination_descriptor.is_some()||core.dirty_sections.iter().any(|d|*d)||source.sections.is_empty()||source.sections.len()>16||source.sections.len()!=core.pagination.len()
   ||source.sections.len()!=core.measured_tables.len()||source.provenance.hwp3_lineage||!source.bin_data_content.is_empty()
   ||core.dpi!=super::super::DEFAULT_DPI{return None;}
  match core.source_format{crate::parser::FileFormat::Hwpx if core.effective_layout_profile().hwp5_origin_hwpx()=>{},_=>return None}
  let contexts=source.reset_flow_contexts();let mut frames=vec![];let mut carry=0u32;let mut count=0usize;let mut cells=0usize;let mut text_bytes=0usize;let mut output_rows=0usize;let mut visible_count=0usize;
  for(si,section)in source.sections.iter().enumerate(){let result=&core.pagination[si];let ps=&section.paragraphs;count=count.checked_add(ps.len())?;if count>128||ps.is_empty(){return None;}
   if result.pages.len()!=1||!result.hidden_empty_paras.is_empty()||!result.pre_emitted_host_paras.is_empty()||!result.wrap_around_paras.is_empty()
    ||!result.endnotes.is_empty()||!result.endnote_paragraphs.is_empty()||section.section_def.line_grid!=0||section.section_def.char_grid!=0
    ||section.section_def.text_direction!=0||!section.section_def.master_pages.is_empty()||!section.section_def.extra_child_records.is_empty(){return None;}
   let [Control::SectionDef(_),Control::ColumnDef(columns)]=ps.first()?.controls.as_slice()else{return None;};
   if columns.column_count!=1||!columns.same_width||!columns.widths.is_empty()||!columns.gaps.is_empty()||columns.column_type!=crate::model::page::ColumnType::Normal
    ||columns.direction!=crate::model::page::ColumnDirection::LeftToRight||columns.raw_attr!=0{return None;}
   let context=*contexts.get(si)?.as_ref()?;let styles=core.resolve_render_styles_for_section(si);
   if styles.reset_flow_contexts.get(si).copied().flatten()!=Some(context){return None;}
   let trace=result.selected_composition_trace.as_ref()?;if trace.section()!=si||trace.resource()!=crate::model::native_computed_resource::RESOURCE
    ||!trace.matches_source(ps,Some(context),core.effective_layout_profile(),core.dpi)
    ||!(trace.matches_finalized_result(result)||(carry>0&&trace.matches_finalized_after_page_number_carry(result,carry)))||!trace.tables().is_empty(){return None;}
   let page=&result.pages[0];if page.page_index!=0||page.section_index!=si||page.column_contents.len()!=1||page.layout.column_areas.len()!=1||!page.footnotes.is_empty()
    ||page.active_header.is_some()||page.active_footer.is_some()||page.active_master_page.is_some()||!page.extra_master_pages.is_empty(){return None;}
   carry=page.page_number;let col=&page.column_contents[0];let rect=page.layout.column_areas[0];
   if col.column_index!=0||col.start_height!=0.0||col.endnote_flow||col.zone_layout.is_some()||col.zone_y_offset!=0.0||rect.width!=page.layout.body_area.width
    ||!col.wrap_anchors.is_empty()||!col.wrap_around_paras.is_empty()||!col.inline_placements.is_empty()||!col.inline_flow_plans.is_empty()
    ||!col.overlay_continuations.is_empty()||!col.overlay_cuts.is_empty()||!col.paragraph_float_placements.is_empty(){return None;}
   let mut slot=0usize;let mut flow=0.0;let mut unpainted=0.0;let mut bodies=vec![];let mut tables=vec![];let mut rows=vec![];
   for(pi,p)in ps.iter().enumerate(){text_bytes=text_bytes.checked_add(p.text.len())?;if text_bytes>2*1024*1024||p.completed_native_rows.is_some(){return None;}
    if p.column_type!=if pi==0{ColumnBreakType::Section}else{ColumnBreakType::None}{return None;}
    if let [Control::Table(table)]=p.controls.as_slice(){
     if !matches!(col.items.get(slot),Some(PageItem::Table{para_index,control_index:0})if *para_index==pi)
      ||p.stored_text_partition_is_dirty()||p.cell_format_vpos_dirty||!p.field_ranges.is_empty()||!p.range_tags.is_empty()||!p.tab_extended.is_empty()
      ||!crate::renderer::generated_column_stack::plain_table(table,|q|q.controls.is_empty()&&q.field_ranges.is_empty()&&q.range_tags.is_empty()&&q.tab_extended.is_empty())
      ||!table.common.raw_extra.is_empty()||table.raw_table_record_extra.iter().any(|b|*b!=0)
      ||i32::try_from(table.common.width).ok()?.checked_add(i32::from(table.outer_margin_left))?.checked_add(i32::from(table.outer_margin_right))?!=integer_hu(rect.width,core.dpi)?{return None;}
     if !table.raw_ctrl_data.is_empty(){return None;}
     cells=cells.checked_add(table.cells.len())?;if cells>4096{return None;}for cell in &table.cells{cells=cells.checked_add(cell.paragraphs.len())?;if cells>4096{return None;}for q in &cell.paragraphs{text_bytes=text_bytes.checked_add(q.text.len())?;if text_bytes>2*1024*1024{return None;}}}
     if cells>4096||text_bytes>2*1024*1024{return None;}
     let mut ms=core.measured_tables[si].iter().filter(|m|m.para_index==pi&&m.control_index==0);let m=ms.next()?;
     if ms.next().is_some()||m.caption_height!=0.0||m.total_height<=0.0||integer_hu(m.total_height,core.dpi)?!=i32::try_from(table.common.height).ok()?{return None;}
     let mut facts=trace.whole_tables().iter().filter(|t|t.paragraph==pi&&t.control==0);let t=facts.next()?;let visible=!p.text.is_empty();
     if facts.next().is_some()||t.page!=Some(0)||t.column!=0||t.post_page!=Some(0)||t.post_column!=0||t.committed_item_index!=slot||t.final_membership!=Some(true)
      ||t.pre_text_height!=0.0||t.pre_text_end!=0||!t.is_first||!t.is_last||t.resolved.is_some()||!arithmetic_equal(t.paragraph_start,flow)||!arithmetic_equal(t.flow_before,flow)
      ||t.body_height!=m.total_height||integer_hu(t.before,core.dpi)?!=i32::from(table.outer_margin_top)||t.full_after<0.0||t.after_for_fit<0.0{return None;}
     let selected=trace.format(t.selected_format_id?)?;let incoming=rect.y+flow-unpainted;let border=incoming+t.before;
     if border<rect.y||border+t.body_height>rect.y+rect.height{return None;}
     if visible{
      // This vertical slice closes the complete final visible host: there is no
      // unobserved successor whose keep/float/frame placement could be affected.
      if pi+1!=ps.len(){return None;}let fresh=visible_fresh(p,&styles,rect.width,core.dpi)?;
      if !matches!(col.items.get(slot+1),Some(PageItem::PartialParagraph{para_index,start_line:0,end_line})if *para_index==pi&&*end_line==fresh.rows.len())
       ||selected.actual_input_width_px!=Some(rect.width)||selected.source_text!=p.text||selected.source_char_offsets!=p.char_offsets
       ||selected.paragraph_style!=fresh.composition.para_style_id||selected.known_square_band||selected.has_numbering||selected.has_horizontal_shaping
       ||!selected.inline_controls.is_empty()||!selected.tac_controls.is_empty()||!selected.footnote_positions.is_empty()||!selected.tab_extended.is_empty()
       ||selected.lines.len()!=fresh.rows.len()||t.selected_line_count!=fresh.rows.len()||selected.before!=0.0||selected.after!=0.0
       ||!selected.lines.iter().zip(&fresh.composition.lines).all(|(a,b)|fact_line_matches(a,b,false))||t.table_total_height!=t.body_height{return None;}
      let advance:f64=fresh.rows.iter().map(|r|super::super::hwpunit_to_px(r.line_height+r.line_spacing,core.dpi)).sum();
      let bottom=super::super::hwpunit_to_px(i32::from(table.outer_margin_bottom),core.dpi);
      let spacing=super::super::hwpunit_to_px(fresh.rows.last()?.line_spacing,core.dpi);
      if !arithmetic_equal(t.full_after,bottom+spacing)||!arithmetic_equal(t.after_for_fit,t.full_after)
       ||!arithmetic_equal(t.flow_after,flow+t.before+t.body_height+bottom+advance){return None;}
      let y=border+t.body_height+bottom;let mut projected=fresh.rows.clone();let mut offset=0.0;
      for row in &mut projected{row.vertical_pos=integer_hu(y-rect.y+offset,core.dpi)?;offset+=super::super::hwpunit_to_px(row.line_height+row.line_spacing,core.dpi);}
      rows.push(CurrentFrameParagraphRows{kind:CurrentFrameRowKind::FreshBody,section:si,paragraph:pi,rows:projected});bodies.push(CandidateBody{paragraph:pi,physical_y:y,fresh,allow_empty_unused_width:false});visible_count+=1;slot+=2;
     }else{
      if p.char_count!=9||!p.char_offsets.is_empty()||!arithmetic_equal(t.table_total_height,t.before+t.body_height+t.after_for_fit)
       ||!arithmetic_equal(t.flow_after,flow+t.table_total_height)||integer_hu(t.full_after-t.after_for_fit,core.dpi)?!=i32::from(table.outer_margin_bottom){return None;}
      let mut plain=p.clone();plain.controls.clear();plain.char_count=1;fresh_body_rows(&plain,&styles,rect.width,core.dpi)?;
      let mut host=p.clone();clear_fresh_input(&mut host);super::super::composer::reflow_line_segs(&mut host,super::super::composer::ParagraphBox::body_for_style(rect.width,styles.para_styles.get(usize::from(p.para_shape_id)),core.dpi),&styles,core.dpi);
      let composition=super::super::composer::compose_paragraph_in_context(&host,&styles);if host.line_segs.len()!=1||composition.lines.len()!=1||selected.lines.len()!=1
       ||selected.source_text!=p.text||selected.source_char_offsets!=p.char_offsets||selected.paragraph_style!=composition.para_style_id||selected.known_square_band||selected.has_numbering||selected.has_horizontal_shaping
       ||!selected.inline_controls.is_empty()||!selected.tac_controls.is_empty()||!selected.footnote_positions.is_empty()||!selected.tab_extended.is_empty()
       ||!fact_line_matches(&selected.lines[0],&composition.lines[0],true){return None;}
      host.line_segs[0].vertical_pos=integer_hu(border-rect.y-t.before,core.dpi)?;
      rows.push(CurrentFrameParagraphRows{kind:CurrentFrameRowKind::FreshBody,section:si,paragraph:pi,rows:host.line_segs});unpainted+=t.before;slot+=1;
     }
     tables.push(VisibleTable{paragraph:pi,incoming,border,left:rect.x+super::super::hwpunit_to_px(i32::from(table.outer_margin_left),core.dpi),width:super::super::hwpunit_to_px(i32::try_from(table.common.width).ok()?,core.dpi),body:t.body_height,before:t.before,visible});flow=t.flow_after;
    }else{
     if !matches!(col.items.get(slot),Some(PageItem::FullParagraph{para_index})if *para_index==pi){return None;}let fresh=fresh_body_rows(p,&styles,rect.width,core.dpi)?;
     let mut cs=trace.commits().iter().filter(|c|c.paragraph==pi);let c=cs.next()?;let f=trace.format(c.format_id)?;let empty=p.text.is_empty()&&p.controls.is_empty();
     if cs.next().is_some()||c.page!=Some(0)||c.column!=0||c.committed_item_index!=Some(slot)||c.final_membership!=Some(true)||c.row_start!=0||c.row_end!=fresh.rows.len()
      ||c.reused_multicolumn_format||c.same_format_reused_after_slot_change||c.trimmed_before!=0.0||c.actual_column_width_px!=rect.width||!c.metrics_still_match_selected_format||!c.range_inside_selected_composition
      ||!arithmetic_equal(c.flow_before,flow)||f.source_text!=p.text||f.source_char_offsets!=p.char_offsets||f.paragraph_style!=fresh.composition.para_style_id
      ||(!empty&&f.actual_input_width_px!=Some(rect.width))||f.known_square_band||f.has_numbering||f.has_horizontal_shaping||!f.tac_controls.is_empty()||!f.footnote_positions.is_empty()||!f.tab_extended.is_empty()
      ||f.inline_controls.len()!=fresh.composition.inline_controls.len()||!f.inline_controls.iter().zip(&fresh.composition.inline_controls).all(|((line,index,kind),c)|*line==c.line_index&&*index==c.control_index&&*kind==format!("{:?}",c.control_type))
      ||f.before!=0.0||f.after!=0.0||f.lines.len()!=fresh.rows.len()||!f.lines.iter().zip(&fresh.composition.lines).all(|(a,b)|fact_line_matches(a,b,empty)){return None;}
     let total:f64=fresh.rows.iter().map(|r|super::super::hwpunit_to_px(r.line_height+r.line_spacing,core.dpi)).sum();if !arithmetic_equal(c.advance,total)||!arithmetic_equal(c.flow_after,flow+total){return None;}
     let y=rect.y+flow-unpainted;let mut projected=fresh.rows.clone();let mut offset=0.0;for row in &mut projected{row.vertical_pos=integer_hu(y-rect.y+offset,core.dpi)?;offset+=super::super::hwpunit_to_px(row.line_height+row.line_spacing,core.dpi);}
     rows.push(CurrentFrameParagraphRows{kind:CurrentFrameRowKind::FreshBody,section:si,paragraph:pi,rows:projected});bodies.push(CandidateBody{paragraph:pi,physical_y:y,fresh,allow_empty_unused_width:empty});flow=c.flow_after;slot+=1;
    }
    if flow>rect.height{return None;}
   }
   if slot!=col.items.len()||!arithmetic_equal(flow,col.used_height)||trace.commits().len()+trace.whole_tables().len()!=ps.len()||core.measured_tables[si].len()!=tables.len(){return None;}
   for p in &rows{output_rows=output_rows.checked_add(p.rows.len())?;}if output_rows>4096{return None;}
   let mut h=blake3::Hasher::new();h.update(b"current-visible-host-receipt-only142-1\0");h.update(&trace.resource());h.update(&trace.generation().to_le_bytes());h.update(&context);h.update(&(si as u64).to_le_bytes());
   let paint=CurrentFramePaintPlan{source_paragraphs:ps.as_ptr()as usize,generation:*h.finalize().as_bytes(),section:si,page:0,column:0,rect,tables:Vec::new(),additional_frames:Vec::new()};
   frames.push(VisibleFrame{source,paint,bodies,tables,rows});
  }
  if visible_count==0{return None;}Some(Self{frames})
 }
 pub(crate) fn paint_plan(&self,section:usize,page:usize)->Option<CurrentFramePaintPlan>{if page!=0{return None;}Some(self.frames.get(section)?.paint.clone())}
 pub(crate) fn finalize(self,physical:&[CurrentPhysicalSelections])->Option<CurrentFrameRowsPlan<'doc>>{
  if self.frames.len()!=physical.len(){return None;}let source=self.frames.first()?.source;let mut rows=vec![];let mut generation=blake3::Hasher::new();generation.update(b"current-visible-host-final142-1\0");
  for(capture,frame)in physical.iter().zip(self.frames){
   if !capture.matches_current_plan(&frame.paint){return None;}let [owner]=capture.frames()? else{return None;};
   if owner.section!=frame.paint.section||owner.page!=0||owner.column!=0||owner.column_ordinal!=0||owner.has_zone||owner.zone_y!=0.0
    ||owner.rect.x!=frame.paint.rect.x||owner.rect.y!=frame.paint.rect.y||owner.rect.width!=frame.paint.rect.width||owner.rect.height!=frame.paint.rect.height{return None;}
   let selected=capture.rows()?;let tables=capture.tables()?;if selected.len()!=frame.bodies.iter().map(|b|b.fresh.rows.len()).sum::<usize>()||tables.len()!=frame.tables.len(){return None;}
   for body in &frame.bodies{let actual=selected.iter().filter(|r|r.frame.paragraph==body.paragraph).collect::<Vec<_>>();
    if actual.len()!=body.fresh.rows.len(){return None;}let mut offset=0.0;
    for(i,(fresh,row))in body.fresh.composition.lines.iter().zip(actual).enumerate(){let f=&row.frame;if f.node!=owner.node||f.line!=i||f.equation_adjusted||f.has_wrap_anchor||f.physical_frame_rows||f.stored_horizontal_span_used
     ||f.effective_column_x!=owner.rect.x||f.effective_column_width!=owner.rect.width||f.available_width!=owner.rect.width||f.margin_left!=0.0||f.margin_right!=0.0||f.inline_offset!=0.0||f.numbering_offset!=0.0
     ||!arithmetic_equal(f.physical_text_y,body.physical_y+offset)||f.final_line_box_height!=super::super::hwpunit_to_px(fresh.line_height,super::super::DEFAULT_DPI)
     ||(!same_selected_line(fresh,&row.selected)&&!(body.allow_empty_unused_width&&same_empty_line_ignoring_unused_width(fresh,&row.selected))){return None;}offset+=super::super::hwpunit_to_px(fresh.line_height+fresh.line_spacing,super::super::DEFAULT_DPI);}}
   for t in &frame.tables{let mut matches=tables.iter().filter(|a|a.paragraph==t.paragraph&&a.control==0);let a=matches.next()?;let border=a.emitted_border?;
    if matches.next().is_some()||a.node!=owner.node||a.typed_float||a.inline||a.treat_as_char||a.selected_outer_inset!=0.0||!arithmetic_equal(a.incoming_y,t.incoming)||!arithmetic_equal(a.paragraph_y,t.incoming)
     ||a.visual_height!=t.body||!arithmetic_equal(border[0],t.left)||!arithmetic_equal(border[1],t.border)||border[2]!=t.width||border[3]!=t.body{return None;}
    let selected_top=if t.visible{if a.lane_input.is_some(){return None;}t.incoming}else{let lane=a.lane_input?;if !arithmetic_equal(lane[2],t.border)||!arithmetic_equal(lane[3],t.border)||!arithmetic_equal(lane[4],t.incoming)||lane[5]!=0.0{return None;}t.border};
    if !arithmetic_equal(a.selected_y,selected_top)||!arithmetic_equal(a.visual_end,t.border+t.body)||!arithmetic_equal(a.flow_end,t.border+t.body)||!arithmetic_equal(t.border,t.incoming+t.before){return None;}
   }
   generation.update(&frame.paint.generation);rows.extend(frame.rows);
  }
  Some(CurrentFrameRowsPlan{source,resource:crate::model::native_computed_resource::RESOURCE,allocation_generation:*generation.finalize().as_bytes(),paragraphs:rows})
 }
}
