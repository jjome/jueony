from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parents[1];area=r/'build/n001-split-prefix145/handoff-test-fixture-v2';base=r/'build/n001-split-prefix145/handoff-final/runtime';sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
for e in json.loads((area/'source-proof.json').read_bytes())['files']:
 path=e['path'];before=(base/path).read_bytes();after=(area/'runtime'/path).read_bytes();assert sha(before)==e['beforeRawSha256'];assert sha(after)==e['afterRawSha256'];assert sha(after.replace(b'\r\n',b'\n'))==e['afterCanonicalSha256']
 if path.endswith('current_synthetic_tac145.rs'):assert before.replace(b'\r\n',b'\n').split(b'#[cfg(test)]')[0]==after.replace(b'\r\n',b'\n').split(b'#[cfg(test)]')[0]
 rows.append({'path':path,'rawSha256':sha(after),'canonicalSha256':e['afterCanonicalSha256'],'baseCanonicalSha256':sha(before.replace(b'\r\n',b'\n'))})
out=r/'build/n001-fixture151-input';out.mkdir(exist_ok=True);(out/'root-merge-input.json').write_text(json.dumps({'files':rows,'productionPredicateByteExact':True},indent=2)+'\n',encoding='utf8')
