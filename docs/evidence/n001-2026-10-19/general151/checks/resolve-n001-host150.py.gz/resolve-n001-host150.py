from pathlib import Path
import re,json
r=Path(__file__).resolve().parents[1];stage=r/'build/n001-host150-merged';pattern=r'<<<<<<<[^\n]*\n(.*?)\|\|\|\|\|\|\|[^\n]*\n.*?=======\n(.*?)>>>>>>>[^\n]*\n'
p=stage/'src/renderer/current_frame_rows_plan.rs';s=p.read_text(encoding='utf8');s,n=re.subn(pattern,lambda m:m[1]+m[2],s,flags=re.S);assert n==1;p.write_text(s,encoding='utf8',newline='\n')
p=stage/'src/renderer/selected_composition_observer127.rs';s=p.read_text(encoding='utf8')
def resolve(m):
 current=m[1];assert 'purpose:ActualCompositionPurpose::CompleteAllocation'in current
 return current.replace('source,final_frame,formats','source,final_frame,actual_profile:profile,formats')
s,n=re.subn(pattern,resolve,s,flags=re.S);assert n==1
old='source,final_frame:frame,formats,commits,tables:vec![]';assert s.count(old)==1;s=s.replace(old,'source,final_frame:frame,actual_profile:profile,formats,commits,tables:vec![]')
p.write_text(s,encoding='utf8',newline='\n')
p=stage/'src/renderer/current_visible_host142.rs';s=p.read_text(encoding='utf8');old='CandidateTable{paragraph:t.paragraph,control:0,top:t.incoming,before:t.before,body:t.body,after:0.0,object_anchor:None}';assert s.count(old)==1
s=s.replace(old,'CandidateTable{paragraph:t.paragraph,control:0,incoming:t.incoming,top:t.incoming,before:t.before,body:t.body,after:0.0,object_anchor:None,standard_anchor:None}');p.write_text(s,encoding='utf8',newline='\n')
(stage/'resolution.json').write_text(json.dumps({'modules':'retain split prefix and add declared XML origin helper','profile':'actual finish profile retained on both trace purposes; Core invalidation consumes only selected complete trace; no relabel/key removal','paint':'typed incoming/table_top both actual t.incoming; no standard_anchor override','prerequisite':'existing issuer137 file untouched','requiredPaint':'all required/full-empty fields, purpose distinction and explicit errors retained'},indent=2)+'\n',encoding='utf8')
