from pathlib import Path
import re,json
r=Path(__file__).resolve().parents[1];stage=r/'build/n001-origin147-merged'
pattern=r'<<<<<<<[^\n]*\n(.*?)\|\|\|\|\|\|\|[^\n]*\n.*?=======\n(.*?)>>>>>>>[^\n]*\n'
p=stage/'src/renderer/current_accepted_composition.rs';s=p.read_text(encoding='utf8');ordinal=0
def resolve_view(m):
 global ordinal
 ordinal+=1;current,incoming=m[1],m[2]
 if ordinal==1:
  assert current.endswith('empty_frames:Vec<(u32,u16,super::page_layout::LayoutRect)>}\n')
  current=current[:-2]+',definition_context:Option<[u8;32]>,origin_measurements:Vec<(usize,usize,usize)>,origin_slots:Option<Vec<OriginPaintSlot>>}\n'
  helpers=incoming[incoming.index('#[derive(Debug,Clone)]'):]
  return current+helpers
 assert ordinal==2
 init='Some(Self{trace:Some(Arc::clone(trace)),required:None,required_tokens:vec![],full_empty_tokens:vec![],empty_frames:vec![]})'
 assert current.count(init)==1
 current=current.replace(init,init[:-2]+',definition_context:styles.reset_flow_context,origin_measurements:vec![],origin_slots:origin_slots(result)})')
 empty='Self{trace:None,required:None,required_tokens:vec![],full_empty_tokens:vec![],empty_frames:vec![]}'
 assert current.count(empty)==1;current=current.replace(empty,empty[:-1]+',definition_context:None,origin_measurements:vec![],origin_slots:None}')
 methods=incoming[incoming.index(' /// Bind the actual Core measurement arena'):]
 assert methods.count('section!=self.trace.section()')==1
 methods=methods.replace('  let input=para.native_origin_paint_input.as_ref()?;','  let trace=self.trace.as_ref()?;\n  let input=para.native_origin_paint_input.as_ref()?;').replace('section!=self.trace.section()','section!=trace.section()').replace('  let trace=self.trace.as_ref();let Control::Table(table)','  let Control::Table(table)')
 return current+' }\n'+methods
s,n=re.subn(pattern,resolve_view,s,flags=re.S);assert n==2;p.write_text(s,encoding='utf8',newline='\n')
p=stage/'src/document_core/queries/rendering.rs';s=p.read_text(encoding='utf8');ordinal=0
def resolve_render(m):
 global ordinal
 ordinal+=1;current,incoming=m[1],m[2]
 if ordinal==2:return current+incoming
 assert ordinal==1
 needle='.map_err(|message|HwpError::RenderError(message.into()))?';assert current.count(needle)==1
 return current.replace(needle,needle+'.map(|view|view.bind_origin_measurements(sec_measured))')
s,n=re.subn(pattern,resolve_render,s,flags=re.S);assert n==2;p.write_text(s,encoding='utf8',newline='\n')
p=stage/'src/renderer/render_tree.rs';s=p.read_text(encoding='utf8');s,n=re.subn(pattern,lambda m:m[1]+m[2],s,flags=re.S);assert n==1;p.write_text(s,encoding='utf8',newline='\n')
(stage/'resolution.json').write_text(json.dumps({'trace':'origin policy requires existing CompleteAllocation trace Option::Some; RequiredPaint cannot grant origin policy','source':'preserve all required suffix/full-empty tokens and fail-closed RenderErrors','binding':'Core measurement arena attaches after current required-paint validation','struct':'independent origin context/slots and required-paint fields both retained','flags':'both paint invalidation flags retained','allocationOrExportAuthorityAdded':False},indent=2)+'\n',encoding='utf8')
