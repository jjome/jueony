from pathlib import Path
import re,json
r=Path(__file__).resolve().parents[1];stage=r/'build/n001-split149-merged';pattern=r'<<<<<<<[^\n]*\n(.*?)\|\|\|\|\|\|\|[^\n]*\n.*?=======\n(.*?)>>>>>>>[^\n]*\n'
for name in ['src/document_core/queries/rendering.rs','src/renderer/current_frame_rows_plan.rs','src/renderer/mod.rs']:
 p=stage/name;s=p.read_text(encoding='utf8');s,n=re.subn(pattern,lambda m:m[1]+m[2],s,flags=re.S);assert n==1,name;p.write_text(s,encoding='utf8',newline='\n')
p=stage/'src/document_core/commands/document.rs';s=p.read_text(encoding='utf8')
replacement='''            }else if let Some(candidate)=self.pagination.first().and_then(|result|crate::renderer::current_frame_rows_plan::CurrentUnequalPrefixFrameCandidate::from_current(
                document,result,&styles,self.effective_layout_profile(),self.dpi)){
             let physical=self.build_page_tree_with_unequal_prefix_capture(0,&candidate)?;
             let Some(plan)=candidate.finalize(&physical.frame.current_physical_selections)else{return Ok(None);};plan
            }else{
             let Some(candidate)=self.pagination.first().and_then(|result|crate::renderer::current_frame_rows_plan::CurrentSplitPrefixFrameCandidate::from_current(
              document,result,&styles,self.effective_layout_profile(),self.dpi))else{return Ok(None);};
             let mut physical=Vec::new();for page in 0..candidate.pages(){physical.push(self.build_page_tree_with_split_prefix_capture(page as u32,&candidate)?.frame.current_physical_selections.clone());}
             let Some(plan)=candidate.finalize(&physical)else{return Ok(None);};plan
            }
'''
s,n=re.subn(pattern,lambda m:replacement,s,flags=re.S);assert n==1;p.write_text(s,encoding='utf8',newline='\n')
(stage/'resolution.json').write_text(json.dumps({'independentModules':'retain empty/unequal/visible and append split','candidateOrdering':'existing single-frame then unequal whole-prefix then distinct split-prefix; final binding failure still hard error','nativePrerequisite':'Native cfg execution pending; no promotion before final result','newSerializerKind':'FreshSplitBody only; original FreshBody checks unchanged'},indent=2)+'\n',encoding='utf8')
