from pathlib import Path
import time,os,json,hashlib,subprocess
r=Path(__file__).resolve().parents[1];pkg=r/'build/rhwp-engine/source-9df387f1a8b85d06/pkg';mirror=r/'build/n001-review132-clean';deadline=time.monotonic()+900
while not(pkg/'jueony-engine-build.json').is_file():
 assert time.monotonic()<deadline;time.sleep(3)
guards=['preservation.ts','document-stored-information.ts','document-save-layout.ts','overlap-save-layout.ts'];proof=[]
for name in guards:
 p=r/'build/n001-clean-review123/apps/editor/src/adapters/rhwp'/name;q=mirror/'apps/editor/src/adapters/rhwp'/name;assert p.read_bytes()==q.read_bytes(),name
 proof.append({'path':name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'identicalClean123And132':True})
(r/'build/n001-final151-expanded-boundary.json').write_text(json.dumps({'files':proof,'noWorkingApplicationImports':True},indent=2)+'\n',encoding='utf8')
node='C:/Users/jjome/AppData/Local/Volta/tools/image/node/22.22.2/node.exe';codes=[]
for name,script in [('split8',r/'build/n001-split-prefix145/verify-wasm145.mjs'),('visible24',mirror/'apps/editor/scripts/verify-visible-host-storage146.mjs')]:
 env=dict(os.environ,JUEONY_ENGINE_PACKAGE=str(pkg),JUEONY_TEST_OUTPUT=str(r/('build/n001-final151-'+name)))
 with(r/('build/n001-final151-'+name+'.log')).open('w',encoding='utf8')as log:p=subprocess.run([node,'--experimental-strip-types',str(script)],cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
 codes.append(p.returncode);print(json.dumps({'mode':name,'exit':p.returncode}),flush=True)
raise SystemExit(int(any(codes)))
