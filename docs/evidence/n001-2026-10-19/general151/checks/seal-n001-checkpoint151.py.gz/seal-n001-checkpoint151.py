from pathlib import Path
import json,hashlib,gzip,re,shutil
r=Path(__file__).resolve().parents[1];a=r/'build';out=r/'docs/evidence/n001-2026-10-19/general151';mirror=a/'n001-review132-clean';pkg=a/'rhwp-engine/source-9df387f1a8b85d06/pkg'
read=lambda p:json.loads(p.read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest()
engine=read(pkg/'jueony-engine-build.json');assert engine['sourceId']=='9df387f1a8b85d06'and len(engine['patches'])==144
w=read(a/'n001-final151-established-workflows/result.json');assert w['passedCases']==w['totalCases']==501 and not w['failures']and len(w['suites'])==41
results={k:read(a/('n001-final151-'+k)/'result.json')for k in ['public','corpus','general-ui','visible24','split8','whole-body','unequal','budget','live-audit','composition']}
p,c,ui,expanded,split=[results[k]for k in ['public','corpus','general-ui','visible24','split8']]
assert len(p['results'])==56 and not p['failures'];assert len(c['results'])==88 and len(c['failures'])==2
assert len(ui['results'])==29 and all(x['status']=='PASS'for x in ui['results'])and not ui['failures']and ui['fullMatrix']
assert not ui['pageErrors']and not ui['externalRequests']and not ui['consoleErrors']
assert len(expanded['results'])==24 and not expanded['failures'];assert len(split['results'])==8 and not split['failures']and len(split['observations'])==56
unit=(a/'n001-final151-unit.log').read_text(encoding='utf8');assert '# pass 1036'in unit and '# fail 0'in unit and '# skipped 0'in unit
assert not(a/'n001-final151-typecheck.log').read_text().strip();assert read(a/'n001-final151-boundaries.log')['diagnostics']==[]
native=(a/'n001-final151-native.log').read_text(encoding='utf8');assert re.findall(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored',native)==['35','2','1','1']
whole,unequal,budget,audit=[results[k]for k in ['whole-body','unequal','budget','live-audit']]
assert whole['pass']==14 and whole['fail']==0
assert len(unequal['results'])==16 and not unequal['failures']and len(unequal['observations'])==64 and unequal['histories']==16 and unequal['passwordRefusals']==32
assert budget['status']=='PASS'and budget['pages']==128 and budget['sourceAndEventsUnchanged']
assert len(audit['observations'])==93 and not audit['failures']and sum(x['stableGeometryRequired']for x in audit['observations'])==37
profile=read(a/'n001-profile151-clean-final/result.json');beforeProfile=read(a/'n001-profile151-clean-before146/result.json');profileProof=read(a/'n001-visible-origin145/profile151-before-after-proof.json')
assert len(profile['results'])==12 and not profile['failures']and all(x['status']=='PASS'for x in profile['results'])
assert profileProof['sameVerifierBytes']and profileProof['sameCleanGuardHashes']and profileProof['baselineFailed']==12 and profileProof['finalPassed']==12 and profileProof['guardedDiskExports']==66
extras=read(a/'n001-extra151/summary.json');assert len(extras['results'])==5 and not extras['failures']and all(x['status']=='PASS'for x in extras['results'])
bundle=read(a/'n001-final151-bundle-check/result.json');assert bundle['passed']==7 and bundle['failed']==0 and bundle['build']['engineWasmSha256']==engine['wasmSha256']
for d in [w.get('engine'),p.get('engine'),c.get('engine'),expanded.get('engine'),split.get('engine'),profile.get('engine'),unequal.get('engine'),whole.get('metadata'),budget.get('metadata')]:assert d['sourceId']==engine['sourceId']
preserved=[]
for name,expected in read(a/'n001-general125-unrelated-initial.json').items():
 if name=='README.md':continue
 assert sha((r/name).read_bytes())==expected,name;preserved.append({'path':name,'sha256':expected})
assert len(preserved)==45;assert not out.exists();out.mkdir(parents=True);aliases=[]
def copy(src,target,compress=True):
 src=Path(src);b=src.read_bytes();original=target+'.gz'if compress else target;dest=out/original
 if len(str(dest))>240:
  short='long-paths/'+sha(original.encode())+('.gz'if compress else '.bin');aliases.append({'original':original,'stored':short});dest=out/short
 dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gzip.compress(b,mtime=0)if compress else b)
copy(pkg/'jueony-engine-build.json','source/engine-build.json',False)
copy(a/'n001-final151-established-workflows/result.json','workflows/result.json',False)
for suite in w['suites']:
 name=suite['name'];script=mirror/'apps/editor/scripts'/('verify-'+name+'.mjs');assert sha(script.read_bytes())==suite['verifierSHA256']
 copy(a/'n001-final151-established-workflows'/name/'result.json','workflows/'+name+'/result.json');copy(a/'n001-final151-established-workflows/logs'/(name+'.log'),'workflows/logs/'+name+'.log');copy(script,'verifiers/'+script.name)
for mode in results:
 copy(a/('n001-final151-'+mode)/'result.json','general/'+mode+'/result.json');log=a/('n001-final151-'+mode+'.log')
 if log.is_file():copy(log,'checks/'+mode+'.log')
for mode in ['build','unit','typecheck','boundaries','official-build','native','bundle-build','bundle-check','established','expanded','additional','pipeline','extras']:
 copy(a/('n001-final151-'+mode+'.log'),'checks/'+mode+'.log')
for name in ['verify-unequal-storage144.mjs','verify-visible-host-storage146.mjs','verify-whole-body-composition142.mjs','verify-current-suffix-budget142.mjs']:copy(r/'apps/editor/scripts'/name,'verifiers/'+name)
copy(a/'n001-split-prefix145/verify-wasm145.mjs','verifiers/verify-wasm145.mjs')
copy(mirror/'build/n001-profile151-verifier/verify-native-reopen-other-section145.mjs','verifiers/verify-native-reopen-other-section145.mjs')
for e in engine['patches'][140:]:
 src=r/'engine/patches'/e['name'];assert sha(src.read_bytes())==e['sha256'];copy(src,'patches/'+e['name'])
for folder in ['n001-origin147-merged','n001-split149-merged','n001-host150-merged','n001-fixture151-merged']:
 for name in ['merge-proof.json','initial-merge-proof.json','resolution.json']:
  if(a/folder/name).is_file():copy(a/folder/name,'source/'+folder+'/'+name)
for folder in ['n001-xml-native139/handoff-final','n001-split-prefix145/handoff-final','n001-split-prefix145/handoff-test-fixture-v2','n001-visible-origin145/handoff-final']:
 for f in(a/folder).rglob('*'):
  if f.is_file():copy(f,'peer/'+folder+'/'+f.relative_to(a/folder).as_posix())
copy(a/'n001-final151-native/preparation.json','source/native-identical-source.json')
copy(a/'n001-general132-clean-source-proof.json','source/application-archive.json');copy(mirror/'apps/editor/evidence/dist-n001-final151/build-evidence.json','source/application-build.json')
copy(a/'n001-final151-expanded-boundary.json','source/expanded-clean-boundary.json')
for name in ['profile151-before-after-proof.json','profile151-clean-boundary-proof.json','root150-merge-read-review.json']:
 copy(a/'n001-visible-origin145'/name,'profile/'+name)
for name,folder in [('final151','n001-profile151-clean-final'),('baseline146','n001-profile151-clean-before146')]:copy(a/folder/'result.json','profile/'+name+'/result.json')
copy(a/'n001-split-prefix145/wasm143-before/result.json','before/split8-baseline143.json')
for name in ['native-tac-exact-v2.log','native-normal-encoder145-v2.log','native-resource145-v2.log']:
 if(a/'n001-split-prefix145'/name).is_file():copy(a/'n001-split-prefix145'/name,'peer/'+name)
copy(a/'n001-extra151/summary.json','extras/summary.json',False)
for e in extras['results']:
 copy(a/'n001-extra151'/e['name']/'result.json','extras/'+e['name']+'/result.json');copy(a/'n001-extra151'/(e['name']+'.log'),'extras/'+e['name']+'/run.log')
copy(a/'n001-final151-bundle-check/result.json','bundle/result.json',False)
for name in ['seal-n001-checkpoint151.py','run-n001-final151-checks.py','run-n001-final151-pipeline.py','run-n001-final151-additional.py','run-n001-final151-expanded.py','prepare-n001-final151-native.py','n001-final151-native.sh','merge-n001-scoped-delta.py','finish-n001-scoped-merge.py','resolve-n001-origin147.py','resolve-n001-split149.py','resolve-n001-host150.py','prepare-n001-fixture151-input.py']:
 if(a/name).is_file():copy(a/name,'checks/'+name)
summary={'engine':engine,'workflowCases':501,'workflowSuites':41,'unitTests':1036,'unitSkipped':0,'nativeTests':39,'resourceInputs':272,'public':{'passed':56,'total':56,'failed':0},'corpus':{'passed':86,'total':88,'failed':2},'app':{'passed':29,'total':29,'failed':0,'browserExceptions':0,'externalRequests':0,'consoleErrors':0},'expandedVisibleHost':{'passed':24,'total':24,'failed':0},'splitPrefixLifecycle':{'passed':8,'total':8,'diskExports':56},'profileTransition':profileProof,'wholeBody':{'passed':14,'total':14,'bothFormatDiskReopens':28},'unequalLifecycle':{'passed':16,'total':16,'diskReopens':64,'historyPairs':16,'wrongPasswordRefusals':32},'actualBudget':{'pages':128,'explicitRefusal':True,'sourceEventsUnchanged':True,'largeDocumentSupport':False},'independentReaders':{'observations':93,'requiredStable':37,'requiredStableDifferences':0},'bundleChecks':7,'extras':extras['results'],'unrelated45Unchanged':preserved,'remainingCorpus':c['failures'],'complete':False,'parentEvidence':'../general146/SHA256-MANIFEST.json','scope':'N001 only; Rust runtime, Hancom deferred; no providers, credentials, user documents or user windows'}
(out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(out/'README.md').write_text('''# N001 checkpoint151: measured table hosts and complete current split rows

Exact official Rust source9df387f1a8b85d06,144 patches,272 resource inputs.
Existing41-suite501 cases,1036 unit tests,39 Native tests, separate75 checks
and7 packaged checks pass. Same fixed inputs: public56/56, fixed86/88,
full headless app29/29. Visible-host24/24, split-prefix8/8 with56 disk exports,
and same-instance later-section edits12/12 with66 guarded disk exports pass.
Same clean verifier on146 gave0/12; root WIP application imports are excluded.

Two unequal-three-column positioned-table HWPX exports still FAIL. This is
not N001 completion. Their unchanged reports are retained, never relabeled.
Hancom comparison is deferred. All existing source, budget, selected-frame,
source-immutability and production0.2 geometry checks remain in force.
The128-page test remains an explicit refusal, not large-document support.

Fresh split rows and actual table measurement consume real immutable current
composition. A document-wide profile transition triggers actual recomposition,
never trace relabeling. The corrected TAC unit fixture uses the public builder;
the prior failed fixture and peer failures remain in parent/peer proof.
No GUI/Hancom, user files/windows, credentials or model calls.45 unrelated
working files stayed exact. Original44 fixed inputs were never regenerated.
Parent146 evidence remains immutable. Run python verify.py for hashes.
''',encoding='utf8')
(out/'LONG_PATH_MAP.json').write_text(json.dumps({'files':aliases},indent=2)+'\n',encoding='utf8')
shutil.copy2(r/'docs/evidence/n001-2026-10-19/general146/verify.py',out/'verify.py')
files=[{'path':f.relative_to(out).as_posix(),'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())}for f in sorted(out.rglob('*'))if f.is_file()]
(out/'SHA256-MANIFEST.json').write_text(json.dumps({'files':files},indent=2)+'\n',encoding='utf8');print('sealed',len(files),'files')
