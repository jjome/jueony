//! Standard frame-local row encoding for a current ordinary plain paragraph.
//! Pure output representation, not row freshness or a source/lease authority.
use crate::model::paragraph::LineSeg;
#[derive(Clone,Copy,Debug)]
pub(crate) struct PlainFramePartition{pub(crate) page:u32,pub(crate) column:u16,pub(crate) start:usize,pub(crate) end:usize}
pub(crate) fn encode_current_plain_frame_rows(canonical:&[LineSeg],frames:&[PlainFramePartition])->Option<Vec<LineSeg>>{
 if canonical.len()<2||canonical.len()>4096||frames.len()<2||frames.len()>48{return None;}
 let mut pen=0i32;let mut prior_text=0;
 for (i,row)in canonical.iter().enumerate(){
  if row.tag!=(LineSeg::TAG_SINGLE_SEGMENT_LINE|LineSeg::TAG_IMPLEMENTATION_PROPERTY)||row.vertical_pos!=pen||row.line_height<=0
   ||row.text_height!=row.line_height||row.line_spacing<0||row.segment_width<=0||row.column_start!=0
   ||row.baseline_distance<0||row.baseline_distance>row.line_height||(i>0&&row.text_start<=prior_text)||(i==0&&row.text_start!=0){return None;}
  pen=pen.checked_add(row.line_height)?.checked_add(row.line_spacing)?;prior_text=row.text_start;
 }
 let mut output=canonical.to_vec();let mut consumed=0usize;let mut previous:Option<(u32,u16)>=None;
 for frame in frames {
  if frame.start!=consumed||frame.end<=frame.start||frame.end>canonical.len(){return None;}
  if let Some((page,column))=previous{
   if !((frame.page==page&&Some(frame.column)==column.checked_add(1))||(Some(frame.page)==page.checked_add(1)&&frame.column==0)){return None;}
  }else if frame.page!=0||frame.column!=0{return None;}
  let base=canonical[frame.start].vertical_pos;
  for row in &mut output[frame.start..frame.end]{row.vertical_pos=row.vertical_pos.checked_sub(base)?;}
  if let Some((page,_))=previous{let first=&mut output[frame.start];first.tag|=LineSeg::TAG_FIRST_LINE_OF_COLUMN;if frame.page!=page{first.tag|=LineSeg::TAG_FIRST_LINE_OF_PAGE;}}
  consumed=frame.end;previous=Some((frame.page,frame.column));
 }
 (consumed==canonical.len()).then_some(output)
}

#[cfg(test)]mod tests{
 use super::*;
 fn rows()->Vec<LineSeg>{(0..4).map(|i|LineSeg{text_start:[0,1,3,4][i],vertical_pos:i as i32*160,line_height:100,text_height:100,baseline_distance:80,line_spacing:60,column_start:0,segment_width:1000,tag:0x80060000}).collect()}
 #[test]fn plain_current_standard_frame_encoder145(){let r=rows();let f=[PlainFramePartition{page:0,column:0,start:0,end:2},PlainFramePartition{page:0,column:1,start:2,end:3},PlainFramePartition{page:1,column:0,start:3,end:4}];let q=encode_current_plain_frame_rows(&r,&f).unwrap();assert_eq!(q.iter().map(|r|r.text_start).collect::<Vec<_>>(),vec![0,1,3,4]);assert_eq!(q.iter().map(|r|r.vertical_pos).collect::<Vec<_>>(),vec![0,160,0,0]);assert_eq!(q.iter().map(|r|r.tag).collect::<Vec<_>>(),vec![0x80060000,0x80060000,0x80060002,0x80060003]);assert_eq!(r,rows());
 for case in 0..9{let mut bad=f;match case{0=>bad[0].page=1,1=>bad[0].column=1,2=>bad[1].start=1,3=>bad[1].end=5,4=>bad[2].end=3,5=>bad[1].column=2,6=>bad[2].page=2,7=>bad[2].column=1,_=>bad[2].end=3}assert!(encode_current_plain_frame_rows(&r,&bad).is_none(),"partition {case}");}
 for case in 0..5{let mut bad=r.clone();match case{0=>bad[0].tag=0x60000,1=>bad[2].vertical_pos+=1,2=>bad[0].line_height=i32::MAX,3=>bad[1].text_start=0, _=>bad[0].line_spacing=-1}if case==3{bad[2].text_start=0;}assert!(encode_current_plain_frame_rows(&bad,&f).is_none(),"row {case}");}
 }
}
