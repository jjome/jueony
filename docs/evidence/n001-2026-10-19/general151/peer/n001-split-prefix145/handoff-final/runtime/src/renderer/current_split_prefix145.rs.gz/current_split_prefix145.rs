//! Fresh standard prefix rows from the actual current accepted split formatter.
//! This provisional candidate is NOT an export plan or a physical paint receipt.
//! Only a consumer that independently closes the real captured prefix paint may
//! turn these rows into the existing source-bound output representation.
use std::sync::Arc;
use crate::model::{document::Document,paragraph::LineSeg,control::Control,provenance::LayoutCompatibilityProfile};
use super::{composer::{ComposedParagraph,ComposedLine,ComposedTextRun,ParagraphBox,compose_paragraph_in_context,reflow_line_segs},
 pagination::{PaginationResult,PageItem},style_resolver::ResolvedStyleSet,selected_composition_observer127::FinalizedSelectedCompositionTrace,page_layout::LayoutRect};
#[derive(Clone)]
pub(crate) struct PrefixFragment {pub(crate) page:u32,pub(crate) column:u16,pub(crate) item:usize,pub(crate) start:usize,pub(crate) end:usize,pub(crate) rect:LayoutRect,pub(crate) flow_after:f64}
pub(crate) struct CurrentSplitPrefixCandidate<'doc>{
 source:&'doc Document, trace:Arc<FinalizedSelectedCompositionTrace>, rect:LayoutRect,
 composition:ComposedParagraph, canonical:Vec<LineSeg>, rows:Vec<LineSeg>, fragments:Vec<PrefixFragment>,
}
impl<'doc> CurrentSplitPrefixCandidate<'doc>{
 pub(crate) fn from_current(source:&'doc Document,result:&PaginationResult,styles:&ResolvedStyleSet,profile:LayoutCompatibilityProfile,dpi:f64)->Option<Self>{
  if source.sections.len()!=1||dpi!=super::DEFAULT_DPI||result.pages.len()<2||result.pages.len()>16
   ||styles.supplemental_metrics.is_some()||styles.kerning_measurement_context.is_some()||styles.horizontal_shaping_context.is_some(){return None;}
  let paragraphs=&source.sections[0].paragraphs;let p=paragraphs.first()?;
  let [Control::SectionDef(_),Control::ColumnDef(columns)]=p.controls.as_slice() else{return None;};
  if !matches!(columns.column_count,2|3)||!columns.same_width||columns.proportional_widths
   ||!columns.widths.is_empty()||!columns.gaps.is_empty()||!matches!(columns.column_type,crate::model::page::ColumnType::Normal)
   ||!matches!(columns.direction,crate::model::page::ColumnDirection::LeftToRight){return None;}
  if p.text.is_empty()||p.text.len()>64*1024||p.char_shapes.is_empty()||p.char_shapes.len()>128
   ||p.char_shapes.windows(2).any(|w|w[0].start_pos>=w[1].start_pos)
   ||p.text.contains(['\t','\n','\r','\u{fffc}'])||!p.field_ranges.is_empty()||!p.range_tags.is_empty()
   ||!p.orphan_field_ends.is_empty()||!p.tab_extended.is_empty()||p.numbering_restart.is_some()
   ||!p.title_marks.is_empty()||!p.markpen_marks.is_empty()||p.cell_format_vpos_dirty||p.layout_only_fill_lines!=0
   ||p.ctrl_data_records.iter().any(Option::is_some){return None;}
  let mut utf16=16u32;if p.char_offsets.len()!=p.text.chars().count(){return None;}
  for(ch,offset)in p.text.chars().zip(&p.char_offsets){if *offset!=utf16{return None;}utf16=utf16.checked_add(ch.len_utf16() as u32)?;}
  if p.char_count!=utf16.checked_add(1)?{return None;}
  let trace=result.selected_composition_trace.as_ref()?;
  if !trace.matches_source(paragraphs,styles.reset_flow_context,profile,dpi)||!trace.matches_finalized_result(result){return None;}
  let page=&result.pages[0];let count=usize::from(columns.column_count);let rect=*page.layout.column_areas.first()?;
  if [rect.x,rect.y,rect.width,rect.height].iter().any(|v|!v.is_finite())||rect.width<=0.0||rect.height<=0.0{return None;}
  for(pi,page)in result.pages.iter().enumerate(){
   if page.page_index as usize!=pi||page.section_index!=0||page.column_contents.is_empty()||page.column_contents.len()>count||page.layout.column_areas.len()!=count{return None;}
   if page.layout.column_areas.iter().zip(&result.pages[0].layout.column_areas).any(|(a,b)|a.x!=b.x||a.y!=b.y||a.width!=b.width||a.height!=b.height){return None;}
   for(i,column)in page.column_contents.iter().enumerate(){let area=page.layout.column_areas[i];
    if usize::from(column.column_index)!=i||column.endnote_flow||column.zone_layout.is_some()||column.zone_y_offset!=0.0
     ||column.start_height!=0.0||!column.wrap_anchors.is_empty()||!column.wrap_around_paras.is_empty()
     ||area.width!=rect.width||area.height!=rect.height||area.y!=rect.y{return None;}}
  }
  let commits=trace.commits().iter().filter(|c|c.paragraph==0).collect::<Vec<_>>();if commits.len()<2||commits.len()>48{return None;}
  let first=commits[0];let fact=trace.format(first.format_id)?;let selected=trace.selected_composition(first.format_id)?;
  if fact.paragraph_token!=p as *const _ as usize||fact.source_text!=p.text||fact.source_char_offsets!=p.char_offsets
   ||fact.actual_input_width_px!=Some(rect.width)||fact.before!=0.0||fact.after!=0.0||fact.has_numbering||fact.has_horizontal_shaping||fact.known_square_band{return None;}
  let mut fragments=Vec::new();let mut end=0;let mut expected_slot=0;
  for c in commits {
   let page_index=usize::try_from(c.page?).ok()?;let pg=result.pages.get(page_index)?;let column=pg.column_contents.get(usize::from(c.column))?;
   let item=c.committed_item_index?;let area=pg.layout.column_areas[usize::from(c.column)];
   if c.section!=0||c.format_id!=first.format_id||page_index*count+usize::from(c.column)!=expected_slot||item!=0
    ||c.row_start!=end||c.row_end<=end||c.row_end>selected.lines.len()||c.final_membership!=Some(true)||!c.paragraph_token_matches
    ||!c.metrics_still_match_selected_format||!c.range_inside_selected_composition||c.flow_before!=0.0||c.trimmed_before!=0.0
    ||c.actual_column_width_px!=area.width||!matches!(column.items.get(item),Some(PageItem::PartialParagraph{para_index:0,start_line,end_line})if *start_line==c.row_start&&*end_line==c.row_end){return None;}
   fragments.push(PrefixFragment{page:page_index as u32,column:c.column,item,start:c.row_start,end:c.row_end,rect:area,flow_after:c.flow_after});end=c.row_end;expected_slot+=1;
  }
  if end!=selected.lines.len(){return None;}
  let actual_p0_items=result.pages.iter().flat_map(|p|&p.column_contents).flat_map(|c|&c.items).filter(|i|matches!(i,PageItem::FullParagraph{para_index:0}|PageItem::PartialParagraph{para_index:0,..})).count();
  if actual_p0_items!=fragments.len(){return None;}
  let style=styles.para_styles.get(usize::from(p.para_shape_id))?;
  if style.margin_left!=0.0||style.margin_right!=0.0||style.indent!=0.0||style.spacing_before!=0.0||style.spacing_after!=0.0
   ||style.keep_lines||style.keep_with_next||style.page_break_before||!matches!(style.head_type,crate::model::style::HeadType::None)
   ||style.border_connect||style.border_spacing.iter().any(|v|*v!=0.0)
   ||!style.line_spacing.is_finite()||style.line_spacing<0.0{return None;}
  // A referenced empty border definition does not add paint or reservations.
  // Check its actual resolved fields; its numeric ID alone is not geometry.
  if style.border_fill_id!=0{let border=styles.border_styles.get(usize::from(style.border_fill_id.checked_sub(1)?))?;
   if border.borders.iter().any(|b|!matches!(b.line_type,crate::model::style::BorderLineType::None))
    ||border.fill_color.is_some()||border.pattern.is_some()||border.gradient.is_some()||border.image_fill.is_some()
    ||border.diagonal_attr!=0||!matches!(border.center_line,crate::model::style::CenterLine::None){return None;}}
  // Bound the existing generic breaker's integer metric arithmetic before use.
  for shape in &p.char_shapes{let cs=styles.char_styles.get(shape.char_shape_id as usize)?;let hu=cs.font_size*7200.0/dpi;
   let upper=hu*(2.0+style.line_spacing.abs())+style.line_spacing.abs()*7200.0/dpi;
   if !hu.is_finite()||hu<=0.0||!upper.is_finite()||upper*utf16.max(1) as f64>f64::from(i32::MAX)/4.0{return None;}}
  let mut fresh=p.clone();fresh.line_segs.clear();fresh.layout_space_metrics.clear();fresh.source_line_seg_vertical_pos=None;
  fresh.hwpx_axis_shift=0;fresh.native_source_synthetic_seal=None;fresh.native_source_synthetic_context=None;
  fresh.completed_native_rows=None;fresh.native_frame_observation.set(None);
  // Exactly the formatter's existing body box, including its column solver's
  // established quantization. Do not substitute a content box or alter width.
  reflow_line_segs(&mut fresh,ParagraphBox::body_for_style(rect.width,Some(style),dpi),styles,dpi);
  let composition=compose_paragraph_in_context(&fresh,styles);
  if !same_composition(&composition,&selected)||fresh.line_segs.is_empty()||fresh.line_segs.len()>4096{return None;}
  let mut end=0i32;let mut scalar=0usize;let chars=p.text.chars().collect::<Vec<_>>();
  for(row,line)in fresh.line_segs.iter().zip(&composition.lines){
   if row.vertical_pos!=end||row.line_height<=0||row.text_height!=row.line_height||row.line_spacing<0
    ||row.baseline_distance<0||row.baseline_distance>row.line_height||row.column_start!=0||row.segment_width<=0
    ||row.tag!=(LineSeg::TAG_SINGLE_SEGMENT_LINE|LineSeg::TAG_IMPLEMENTATION_PROPERTY)||line.char_start!=scalar{return None;}
   for run in &line.runs{for ch in run.text.chars(){if chars.get(scalar)!=Some(&ch){return None;}scalar+=1;}}
   end=end.checked_add(row.line_height)?.checked_add(row.line_spacing)?;
  }
  if scalar!=chars.len()||fact.actual_heights.len()!=composition.lines.len()||fact.actual_spacings.len()!=composition.lines.len()
   ||composition.lines.iter().enumerate().any(|(i,l)|fact.actual_heights[i]!=super::hwpunit_to_px(l.line_height,dpi)||fact.actual_spacings[i]!=super::hwpunit_to_px(l.line_spacing,dpi)){return None;}
  let partitions=fragments.iter().map(|f|super::composer::PlainFramePartition{page:f.page,column:f.column,start:f.start,end:f.end}).collect::<Vec<_>>();
  let rows=super::composer::encode_current_plain_frame_rows(&fresh.line_segs,&partitions)?;
  for fragment in &fragments{let mut end=0i32;for row in &rows[fragment.start..fragment.end]{if row.vertical_pos!=end{return None;}end=end.checked_add(row.line_height)?.checked_add(row.line_spacing)?;}
   if !arithmetic_equal(super::hwpunit_to_px(end,dpi),fragment.flow_after)||fragment.flow_after>fragment.rect.height{return None;}}
  Some(Self{source,trace:Arc::clone(trace),rect,composition,canonical:fresh.line_segs,rows,fragments})
 }
 pub(crate) fn matches_current(&self,source:&Document,result:&PaginationResult,styles:&ResolvedStyleSet,profile:LayoutCompatibilityProfile,dpi:f64)->bool{
  std::ptr::eq(source,self.source)&&dpi==super::DEFAULT_DPI
   &&result.selected_composition_trace.as_ref().is_some_and(|trace|Arc::ptr_eq(trace,&self.trace))
   &&self.trace.resource()==crate::model::native_computed_resource::RESOURCE
   &&self.trace.matches_source(&source.sections[0].paragraphs,styles.reset_flow_context,profile,dpi)
   &&self.trace.matches_finalized_result(result)
 }
 pub(crate) fn source(&self)->&'doc Document{self.source}
 pub(crate) fn generation(&self)->u64{self.trace.generation()}
 pub(crate) fn frame(&self)->LayoutRect{self.rect}
 pub(crate) fn fragments(&self)->&[PrefixFragment]{&self.fragments}
 pub(crate) fn fresh_rows(&self)->&[LineSeg]{&self.rows}
 pub(crate) fn matches_standard_rows(&self,rows:&[LineSeg])->bool{
  let partitions=self.fragments.iter().map(|f|super::composer::PlainFramePartition{page:f.page,column:f.column,start:f.start,end:f.end}).collect::<Vec<_>>();
  super::composer::encode_current_plain_frame_rows(&self.canonical,&partitions).is_some_and(|expected|expected==rows)
 }
 pub(crate) fn matches_selected_line(&self,index:usize,line:&ComposedLine)->bool{self.composition.lines.get(index).is_some_and(|l|same_line(l,line))}
}
fn arithmetic_equal(a:f64,b:f64)->bool{a.is_finite()&&b.is_finite()&&(a-b).abs()<=f64::EPSILON*a.abs().max(b.abs()).max(1.0)*16.0}
fn same_composition(a:&ComposedParagraph,b:&ComposedParagraph)->bool{
 let ComposedParagraph{lines:al,para_style_id:ap,inline_controls:ai,numbering_text:an,tac_controls:at,footnote_positions:af,tab_extended:ae,horizontal_shaping:ah}=a;
 let ComposedParagraph{lines:bl,para_style_id:bp,inline_controls:bi,numbering_text:bn,tac_controls:bt,footnote_positions:bf,tab_extended:be,horizontal_shaping:bh}=b;
 ap==bp&&an.is_none()&&bn.is_none()&&at.is_empty()&&bt.is_empty()&&af.is_empty()&&bf.is_empty()&&ae.is_empty()&&be.is_empty()&&ah.is_none()&&bh.is_none()
 &&ai.len()==bi.len()&&ai.iter().zip(bi).all(|(a,b)|a.line_index==b.line_index&&a.control_index==b.control_index&&a.control_type==b.control_type)
 &&al.len()==bl.len()&&al.iter().zip(bl).all(|(a,b)|same_line(a,b))
}
fn same_line(a:&ComposedLine,b:&ComposedLine)->bool{
 let ComposedLine{runs:ar,line_height:ah,baseline_distance:ab,segment_width:aw,column_start:ac,line_spacing:aspace,has_line_break:abr,char_start:astart}=a;
 let ComposedLine{runs:br,line_height:bh,baseline_distance:bb,segment_width:bw,column_start:bc,line_spacing:bspace,has_line_break:bbr,char_start:bstart}=b;
 ah==bh&&ab==bb&&aw==bw&&ac==bc&&aspace==bspace&&!*abr&&!*bbr&&astart==bstart&&ar.len()==br.len()&&ar.iter().zip(br).all(|(a,b)|same_run(a,b))
}
fn same_run(a:&ComposedTextRun,b:&ComposedTextRun)->bool{
 let ComposedTextRun{text:at,char_style_id:as_,lang_index:al,char_overlap:ao,footnote_marker:af,display_text:ad,supplemental_metrics_blocked:ab,inserted_control_text:ai,space_metric:asp}=a;
 let ComposedTextRun{text:bt,char_style_id:bs,lang_index:bl,char_overlap:bo,footnote_marker:bf,display_text:bd,supplemental_metrics_blocked:bb,inserted_control_text:bi,space_metric:bsp}=b;
 at==bt&&as_==bs&&al==bl&&ao.is_none()&&bo.is_none()&&af.is_none()&&bf.is_none()&&ad.is_none()&&bd.is_none()&&ab==bb&&!*ai&&!*bi&&asp==bsp
}
