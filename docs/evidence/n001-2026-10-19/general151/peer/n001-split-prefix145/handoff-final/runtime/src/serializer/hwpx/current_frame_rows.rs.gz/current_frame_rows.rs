//! Exact serialization-clone binding for an opaque, current physical/fresh plan.
//! No imported descriptor, arbitrary row list, source lease or diagnostic report
//! can construct this projection. It never changes source model/cache state.
use std::collections::{HashMap,HashSet};
use serde::Serialize;
use crate::model::{document::{Document,DocInfo,Section,FileHeader,HwpVersion,Preview,PreviewImage,PreviewImageFormat},paragraph::{Paragraph,LineSeg,SpaceMetric,NumberingMarker}};
use crate::renderer::current_frame_rows_plan::CurrentFrameRowsPlan;
#[derive(Clone,Copy)]
pub(crate) enum CurrentFrameExportRepresentation{Original,NativeHwp5Lowering}

const MAX_BYTES:usize=16*1024*1024;
const MAX_ROWS:usize=65536;
const MAX_PARAGRAPHS:usize=4096;
struct BoundedDigest{hash:blake3::Hasher,bytes:usize,limit:usize,depth:usize,quoted:bool,escaped:bool}
impl std::io::Write for BoundedDigest{
 fn write(&mut self,bytes:&[u8])->std::io::Result<usize>{
  if bytes.len()>self.limit-self.bytes{return Err(std::io::ErrorKind::InvalidData.into());}
  for &b in bytes {if self.quoted {if self.escaped{self.escaped=false;}else if b==b'\\'{self.escaped=true;}else if b==b'"'{self.quoted=false;}}
   else{match b{b'"'=>self.quoted=true,b'{'|b'['=>{self.depth+=1;if self.depth>64{return Err(std::io::ErrorKind::InvalidData.into());}},b'}'|b']'=>self.depth=self.depth.checked_sub(1).ok_or(std::io::ErrorKind::InvalidData)?,_=>{}}}}
  self.bytes+=bytes.len();self.hash.update(bytes);Ok(bytes.len())
 }
 fn flush(&mut self)->std::io::Result<()>{Ok(())}
}
fn digest_with_limit<T:Serialize>(value:&T,limit:usize)->Option<([u8;32],usize)>{
 let mut writer=BoundedDigest{hash:blake3::Hasher::new(),bytes:0,limit,depth:0,quoted:false,escaped:false};
 serde_json::to_writer(&mut writer,value).ok()?;(writer.depth==0&&!writer.quoted).then(||(*writer.hash.finalize().as_bytes(),writer.bytes))
}
fn digest<T:Serialize>(value:&T)->Option<[u8;32]>{Some(digest_with_limit(value,MAX_BYTES)?.0)}
fn image_format(format:&PreviewImageFormat)->u8{match format{PreviewImageFormat::Png=>0,PreviewImageFormat::Bmp=>1,PreviewImageFormat::Gif=>2,PreviewImageFormat::Unknown=>3}}
// Paragraph::Serialize intentionally excludes serializer-driving runtime input.
// Bind those values separately; never treat an opaque observation as permission.
// Initial proof only supports plain/structural/table stories, no completed-row
// package emission, captions, lazy binary, or unhandled nested story kinds.
fn paragraph_supplements(p:&Paragraph,depth:usize,budget:&mut usize,out:&mut Vec<[u8;32]>)->Option<()>{
 if depth>32||out.len()>=MAX_ROWS{return None;}
 let Paragraph{char_count:_,control_mask:_,para_shape_id:_,style_id:_,column_type:_,raw_break_type:_,page_break_synthesized:_,
  text:_,char_offsets:_,char_shapes:_,line_segs:_,layout_space_metrics,hwpx_axis_shift:_,layout_only_fill_lines:_,
  source_line_seg_vertical_pos,native_source_synthetic_seal,native_source_synthetic_context,completed_native_rows,
  native_frame_observation,reset_flow_observation:_,range_tags:_,field_ranges:_,orphan_field_ends:_,controls,ctrl_data_records:_,
  char_count_msb:_,raw_header_extra:_,has_para_text:_,tab_extended:_,title_marks:_,markpen_marks:_,numbering_restart:_,
  stored_text_partition_dirty,cell_format_vpos_dirty,cell_vpos_reset,numbering_marker}=p;
 if controls.len()>4096||completed_native_rows.is_some()||layout_space_metrics.len()>MAX_ROWS
  ||source_line_seg_vertical_pos.as_ref().is_some_and(|v|v.len()>MAX_ROWS){return None;}
 let metrics:Vec<_>=layout_space_metrics.iter().map(|(start,metric)|(*start,match metric{
  SpaceMetric::Stored=>0u8,SpaceMetric::HancomRegenerated=>1,SpaceMetric::HalfCell=>2,SpaceMetric::KoPubJustified=>3})).collect();
 let marker=match numbering_marker{NumberingMarker::Unresolved=>(0u8,None),NumberingMarker::Absent=>(1,None),
  NumberingMarker::Text(text,head)=>(2,Some((text,(head.attr,head.width_adjust,head.text_distance,head.char_shape_id))))};
 let frame=native_frame_observation.get();
 if frame.is_some_and(|f|![f.raw_top,f.reserved_bottom,f.before,f.body_height,f.after].iter().all(|v|v.is_finite())){return None;}
 let table_seals:Vec<_>=controls.iter().filter_map(|c|match c{crate::model::control::Control::Table(t)=>Some(t.raw_ctrl_seal),_=>None}).collect();
 let (hash,used)=digest_with_limit(&(source_line_seg_vertical_pos,metrics,native_source_synthetic_seal,native_source_synthetic_context,
  stored_text_partition_dirty,cell_format_vpos_dirty,cell_vpos_reset,marker,frame,table_seals),*budget)?;
 *budget=budget.checked_sub(used)?;out.push(hash);
 for c in controls{match c{
  crate::model::control::Control::SectionDef(s)=>{if !s.master_pages.is_empty(){return None;}},
  crate::model::control::Control::ColumnDef(_)=>{},
  crate::model::control::Control::Table(t)=>{if t.caption.is_some(){return None;}for cell in &t.cells{for p in &cell.paragraphs{paragraph_supplements(p,depth+1,budget,out)?;}}},
  _=>return None,
 }}
 Some(())
}
/// Exhaustive original and target content binding, including unknown raw data.
/// Runtime seals/observers are deliberately not transformed into raw authority.
/// Initial frame proof does not load opaque/lazy binary resources: they refuse.
fn document_digest(doc:&Document,resource:[u8;32],generation:[u8;32])->Option<[u8;32]>{
 let Document{header,doc_properties,doc_info,sections,preview,bin_data_content,extra_streams,hwpx_aux_entries,
  is_hwp3_variant,is_hwpx_variant,provenance}=doc;
 if !bin_data_content.is_empty()||sections.is_empty()||sections.len()>256{return None;}
 let mut supplements=Vec::new();let mut supplement_budget=MAX_BYTES;
 for section in sections{
  if !section.section_def.master_pages.is_empty(){return None;}
  for p in &section.paragraphs{paragraph_supplements(p,0,&mut supplement_budget,&mut supplements)?;}
 }
 let FileHeader{version,flags,compressed,encrypted,distribution,raw_data}=header;
 let HwpVersion{major,minor,build,revision}=version;
 let DocInfo{bin_data_list,font_faces,border_fills,char_shapes,tab_defs,numberings,bullets,para_shapes,styles,
  extra_records,print_method,raw_stream,bullet_count,memo_shape_count,memo_properties_xml,
  distribute_doc_data_removed,raw_stream_dirty,hwpx_head_tail,hwpml_version,raw_provenance:_}=doc_info;
 let sections:Vec<_>=sections.iter().map(|Section{section_def,paragraphs,raw_stream,raw_provenance:_}|
  (section_def,paragraphs,raw_stream)).collect();
 let preview=preview.as_ref().map(|Preview{image,text}|(text,image.as_ref().map(|PreviewImage{format,data}|(image_format(format),data))));
 let crate::model::provenance::SourceProvenance{format,hwp3_lineage,hwpx_lineage,hft_ascii_halfwidth_witnessed}=provenance;
 let format=match format{crate::model::provenance::SourceFormat::Hwp5=>0u8,crate::model::provenance::SourceFormat::Hwpx=>1,
  crate::model::provenance::SourceFormat::Hwp3=>2,crate::model::provenance::SourceFormat::Hml=>3};
 digest(&(("current-frame-standard-rows-130",resource,generation),
  ((major,minor,build,revision),flags,compressed,encrypted,distribution,raw_data),doc_properties,
  ((bin_data_list,font_faces,border_fills,char_shapes,tab_defs,numberings,bullets,para_shapes,styles,extra_records),
   (print_method,raw_stream,bullet_count,memo_shape_count,memo_properties_xml,distribute_doc_data_removed,raw_stream_dirty,hwpx_head_tail,hwpml_version)),
  (sections,preview,extra_streams,hwpx_aux_entries,supplements),(is_hwp3_variant,is_hwpx_variant,format,hwp3_lineage,hwpx_lineage,hft_ascii_halfwidth_witnessed)))
}

/// Candidate admission uses exactly the binder's whole-source support and
/// bounded digest. This issues no plan, rows, lease, or target binding. The
/// completed plan still requires the unchanged full source/target binder.
pub(crate) fn current_source_is_admissible(source:&Document)->bool{
 document_digest(source,crate::model::native_computed_resource::RESOURCE,[0;32]).is_some()
}

struct ParagraphRows{section:usize,paragraph:usize,rows:Vec<LineSeg>}
fn expected_target_digest(source:&Document,representation:CurrentFrameExportRepresentation,resource:[u8;32],generation:[u8;32])->Option<[u8;32]>{
 match representation{
  CurrentFrameExportRepresentation::Original=>document_digest(source,resource,generation),
  CurrentFrameExportRepresentation::NativeHwp5Lowering=>{
   if source.is_hwp3_variant||source.provenance.hwp3_lineage
    ||matches!(source.provenance.format,crate::model::provenance::SourceFormat::Hwp3){return None;}
   // Bound the source before cloning or traversing the production lowerer.
   document_digest(source,resource,generation)?;
   let mut target=source.clone();let path=crate::model::document::HWP5_ORIGIN_HWPX_MARKER_PATH;
   if target.hwpx_aux_entries.iter().filter(|(p,_)|p==path).count()>1{return None;}
   let value=crate::model::document::HWP5_ORIGIN_HWPX_PARAGRAPH_AXIS.to_vec();
   if let Some((_,v))=target.hwpx_aux_entries.iter_mut().find(|(p,_)|p==path){*v=value;}
   else{target.hwpx_aux_entries.push((path.to_owned(),value));}
   crate::document_core::DocumentCore::materialize_hwp5_missing_linesegs_for_hwpx_export(&mut target);
   document_digest(&target,resource,generation)
  }
 }
}
pub(crate) struct CurrentFrameRowsProjection<'doc>{
 source:&'doc Document,
 source_digest:[u8;32],
 target_digest:[u8;32],
 resource:[u8;32],
 generation:[u8;32],
 paragraphs:Vec<ParagraphRows>,
}
impl<'doc> CurrentFrameRowsProjection<'doc>{
 pub(crate) fn from_current_frame(source:&'doc Document,plan:&CurrentFrameRowsPlan<'doc>,
  representation:CurrentFrameExportRepresentation)->Option<Self>{
  let resource=crate::model::native_computed_resource::RESOURCE;
  if !plan.owns_document(source)||plan.resource()!=resource{return None;}
  let generation=plan.allocation_generation();
  let source_digest=document_digest(source,resource,generation)?;
  let planned=plan.paragraph_rows();
  if planned.is_empty()||planned.len()>MAX_PARAGRAPHS{return None;}
  let mut seen=HashSet::new();let mut total_rows=0usize;let mut paragraphs=Vec::with_capacity(planned.len());
  for item in planned{
   let section=item.section_index();let paragraph=item.paragraph_index();
   if !seen.insert((section,paragraph)){return None;}
   let source_paragraph=source.sections.get(section)?.paragraphs.get(paragraph)?;
   if source_paragraph.stored_text_partition_is_dirty()||source_paragraph.cell_format_vpos_dirty
    ||source_paragraph.layout_only_fill_lines!=0{return None;}
   // Preserve the actual source-free formatter's distinct text/object kind.
   // Freshness belongs to the opaque allocator/formatter plan, never a tag bit.
   let rows=item.rows();total_rows=total_rows.checked_add(rows.len())?;
   if rows.is_empty()||total_rows>MAX_ROWS||match item.row_kind(){
    crate::renderer::current_frame_rows_plan::CurrentFrameRowKind::FreshBody=>rows.iter().any(|r|r.tag!=0x8006_0000),
    crate::renderer::current_frame_rows_plan::CurrentFrameRowKind::FreshSplitBody=>!valid_fresh_split_rows(rows),
    crate::renderer::current_frame_rows_plan::CurrentFrameRowKind::StructuralObjectAnchor=>rows.len()!=1||!crate::model::object_anchor::is_canonical_structural_table_anchor(&rows[0]),
   }
    ||rows.windows(2).any(|r|r[0].text_start>r[1].text_start){return None;}
   paragraphs.push(ParagraphRows{section,paragraph,rows:rows.to_vec()});
  }
  // One selected representation, generated from the original, never an OR of
  // caller-provided candidate clones. Reuse the actual production lowerer.
  let target_digest=expected_target_digest(source,representation,resource,generation)?;
  Some(Self{source,source_digest,target_digest,resource,generation,paragraphs})
 }
 pub(crate) fn bind_for_export(&self,target:&Document)->Option<HashMap<usize,Vec<LineSeg>>>{
  if self.resource!=crate::model::native_computed_resource::RESOURCE
   ||document_digest(self.source,self.resource,self.generation)?!=self.source_digest
   ||document_digest(target,self.resource,self.generation)?!=self.target_digest
   ||self.paragraphs.is_empty()||self.paragraphs.len()>MAX_PARAGRAPHS{return None;}
  let mut bound=HashMap::new();let mut total=0usize;
  for item in &self.paragraphs{
   let p=target.sections.get(item.section)?.paragraphs.get(item.paragraph)?;
   total=total.checked_add(item.rows.len())?;
   if item.rows.is_empty()||total>MAX_ROWS{return None;}
   if bound.insert(p as *const _ as usize,item.rows.clone()).is_some(){return None;}
  }
  Some(bound)
 }
}

#[cfg(test)]mod tests{
 use super::*;
 fn source()->Document{let mut d=Document::default();d.sections.push(Default::default());d.sections[0].paragraphs=(0..3).map(|i|{let mut p=crate::model::paragraph::Paragraph::default();p.text=format!("own input {i}");p}).collect();d}
 fn projection(d:&Document)->CurrentFrameRowsProjection<'_>{let resource=crate::model::native_computed_resource::RESOURCE;let generation=[7;32];let input=document_digest(d,resource,generation).unwrap();CurrentFrameRowsProjection{source:d,source_digest:input,target_digest:input,resource,generation,paragraphs:vec![ParagraphRows{section:0,paragraph:0,rows:vec![LineSeg::default()]}]}}
 #[test]fn exact_whole_source_and_clone_binding(){let d=source();let p=projection(&d);let clone=d.clone();let map=p.bind_for_export(&clone).unwrap();assert!(map.contains_key(&(&clone.sections[0].paragraphs[0]as*const _ as usize)));assert!(!map.contains_key(&(&d.sections[0].paragraphs[0]as*const _ as usize)));}
 #[test]fn unprojected_unknown_context_or_order_change_rejects(){let d=source();let p=projection(&d);for case in 0..8{let mut c=d.clone();match case{
  0=>c.sections[0].paragraphs[2].text.push('x'),1=>c.sections[0].paragraphs[2].raw_header_extra.push(1),2=>c.sections[0].paragraphs.swap(1,2),
  3=>c.sections[0].section_def.raw_ctrl_extra.push(7),4=>c.doc_info.font_faces.push(vec![]),5=>c.extra_streams.push(("unknown".into(),vec![1,2])),
  6=>c.hwpx_aux_entries.push(("unknown".into(),vec![2,3])),7=>c.header.raw_data=Some(vec![9]),_=>unreachable!()};assert!(p.bind_for_export(&c).is_none(),"case {case}");}}
 #[test]fn other_section_context_and_membership_are_bound(){let mut d=source();d.sections.push(Default::default());d.sections[1].paragraphs.push(Default::default());let p=projection(&d);let mut c=d.clone();c.sections[1].paragraphs[0].text.push('x');assert!(p.bind_for_export(&c).is_none());let mut c=d.clone();c.sections.swap(0,1);assert!(p.bind_for_export(&c).is_none());}
 #[test]fn target_duplicate_or_outside_body_pointer_is_rejected(){let d=source();let mut p=projection(&d);p.paragraphs.push(ParagraphRows{section:0,paragraph:0,rows:vec![Default::default()]});assert!(p.bind_for_export(&d).is_none());p.paragraphs.pop();p.paragraphs[0].paragraph=3;assert!(p.bind_for_export(&d).is_none());p.paragraphs[0].paragraph=0;p.paragraphs[0].section=1;assert!(p.bind_for_export(&d).is_none());}
 #[test]fn resource_and_generation_mismatch_rejects(){let d=source();let mut p=projection(&d);p.resource[0]^=1;assert!(p.bind_for_export(&d).is_none());let mut p=projection(&d);p.generation[0]^=1;assert!(p.bind_for_export(&d).is_none());}
 #[test]fn bounded_streaming_digest_and_depth_refuse_large_input(){assert!(digest(&"escaped \\\"[]{} é 한글").is_some());assert!(digest(&"x".repeat(MAX_BYTES)).is_none());let mut v=serde_json::Value::Null;for _ in 0..65{v=serde_json::json!([v]);}assert!(digest(&v).is_none());}
 #[test]fn unprojected_output_driving_runtime_changes_cannot_bind(){let d=source();let p=projection(&d);for case in 0..7{let mut c=d.clone();let tail=&mut c.sections[0].paragraphs[2];match case{
  0=>tail.source_line_seg_vertical_pos=Some(vec![5000]),1=>tail.layout_space_metrics.push((0,SpaceMetric::HalfCell)),
  2=>tail.stored_text_partition_dirty=true,3=>tail.cell_format_vpos_dirty=true,4=>tail.cell_vpos_reset=Some(true),
  5=>tail.native_source_synthetic_context=Some([1;32]),6=>tail.numbering_marker=NumberingMarker::Absent,_=>unreachable!()};assert!(p.bind_for_export(&c).is_none(),"output metadata {case}");}}
 #[test]fn nested_cell_output_driving_runtime_and_raw_seal_changes_cannot_bind(){let mut d=source();let mut t=crate::model::table::Table::default();let mut cell=crate::model::table::Cell::default();cell.paragraphs.push(Default::default());t.cells.push(cell);d.sections[0].paragraphs[2].controls.push(crate::model::control::Control::Table(Box::new(t)));let p=projection(&d);let mut c=d.clone();let crate::model::control::Control::Table(t)=&mut c.sections[0].paragraphs[2].controls[0]else{unreachable!()};t.cells[0].paragraphs[0].source_line_seg_vertical_pos=Some(vec![5000]);assert!(p.bind_for_export(&c).is_none());let mut c=d.clone();let crate::model::control::Control::Table(t)=&mut c.sections[0].paragraphs[2].controls[0]else{unreachable!()};t.raw_ctrl_seal=Some([2;32]);assert!(p.bind_for_export(&c).is_none());}
 #[test]fn representation_selects_only_exact_actual_native_lowering(){let d=source();let mut p=projection(&d);p.target_digest=expected_target_digest(&d,CurrentFrameExportRepresentation::NativeHwp5Lowering,p.resource,p.generation).unwrap();let mut target=d.clone();target.hwpx_aux_entries.push((crate::model::document::HWP5_ORIGIN_HWPX_MARKER_PATH.into(),b"2:paragraph-utf16".to_vec()));crate::document_core::DocumentCore::materialize_hwp5_missing_linesegs_for_hwpx_export(&mut target);assert!(p.bind_for_export(&target).is_some());assert!(p.bind_for_export(&d).is_none());assert!(projection(&d).bind_for_export(&target).is_none());target.sections[0].paragraphs[2].line_segs[0].tag^=1;assert!(p.bind_for_export(&target).is_none());}
 #[test]fn initial_scope_refuses_unhandled_story_and_completed_row_authority(){let d=source();let mut c=d.clone();c.sections[0].paragraphs[1].controls.push(crate::model::control::Control::Unknown(Default::default()));assert!(document_digest(&c,[0;32],[1;32]).is_none());let mut c=d.clone();c.sections[0].paragraphs[1].completed_native_rows=Some(crate::model::native_computed_rows::CompletedRows{local:[0;32],plan:[0;32],frame:[0;32],resource:[0;32],bases:vec![],native_frame:None,export_authorized:false});assert!(document_digest(&c,[0;32],[1;32]).is_none());}
}

#[cfg(test)]
#[path="current_frame_rows_writer_tests131.rs"]
mod writer_facade_tests;

// A distinct output schema for exact current allocator/paint frame boundaries.
// Ordinary FreshBody remains unchanged. These bits do not authorize input rows.
fn valid_fresh_split_rows(rows:&[LineSeg])->bool{
 if rows.len()<2||rows[0].tag!=0x8006_0000||rows[0].vertical_pos!=0{return false;}
 let mut end=0i32;let mut boundaries=0;
 for(i,row)in rows.iter().enumerate(){
  if !matches!(row.tag,0x8006_0000|0x8006_0002|0x8006_0003)||row.line_height<=0||row.text_height!=row.line_height||row.line_spacing<0
   ||row.vertical_pos<0||row.column_start!=0||row.segment_width<=0||row.baseline_distance<0||row.baseline_distance>row.line_height{return false;}
  if row.tag!=0x8006_0000{if i==0||row.vertical_pos!=0{return false;}boundaries+=1;end=0;}
  if row.vertical_pos!=end{return false;}let Some(next)=end.checked_add(row.line_height).and_then(|n|n.checked_add(row.line_spacing))else{return false;};end=next;
 }
 boundaries>0
}
