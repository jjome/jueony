# Test fixture correction only — pending Native exact test

Apply `known-public-reflow-unit-fixture145-v2.patch` after frozen d00a053c patch. Production helper predicate/call-site code is unchanged. Only cfg(test) fixture and selection change, plus the required resource rekey retaining all 266 inputs.

The old fixture opened an unedited stored host (tag 0x60000, width 0); the guard correctly refused it. The corrected own builder follows the already validated fixed positive: three interleaved TAC tables, short two-column page, ordinary serialization/reopen and a public prefix edit. It selects the last actual current synthetic host (tag 0x80060000, width 20900). It never creates private rows/leases/flags.

Old failure and unrelated issue1452 missing-sample preparation failures remain in native-boundaries-final-second.log. Exact new TAC test is running in native-tac-exact-v2.log. No exact-final-byte PASS or official WASM success is claimed until the pending log completes.

Final Native release/LTO exact tests: TAC positive + 29 negatives PASS; normal frame encoder positive + 14 invalid inputs PASS; all 266 current resource inputs witness PASS. Three actual tests, failed 0, ignored 0. Logs and SHA256 are in native-final-result.json. Official merged WASM verification is parent-owned and remains separate.
