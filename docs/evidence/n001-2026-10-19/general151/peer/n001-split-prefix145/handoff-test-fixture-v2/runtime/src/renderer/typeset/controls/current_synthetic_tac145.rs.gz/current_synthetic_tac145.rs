//! Current measured lower bound for a known empty synthetic TAC host.
//! This reserves actual current body ink only. It grants no stored row, source
//! origin, reset, serialization or completed-row authority.
use crate::model::{control::Control,paragraph::{Paragraph,LineSeg},table::TablePageBreak};
use crate::renderer::{height_measurer::MeasuredTable,style_resolver::ResolvedStyleSet,hwpunit_to_px};
use super::super::paragraph::metrics::FormattedParagraph;
pub(in crate::renderer::typeset) fn measured_band(index:usize,para:&Paragraph,fmt:&FormattedParagraph,measurements:&[MeasuredTable],styles:&ResolvedStyleSet,dpi:f64)->Option<f64>{
 if dpi!=crate::renderer::DEFAULT_DPI||!para.text.is_empty()||para.char_count!=9||!para.char_offsets.is_empty()
  ||!para.field_ranges.is_empty()||!para.range_tags.is_empty()||!para.orphan_field_ends.is_empty()||!para.tab_extended.is_empty()
  ||!para.title_marks.is_empty()||!para.markpen_marks.is_empty()||para.numbering_restart.is_some()||!matches!(para.numbering_marker,crate::model::paragraph::NumberingMarker::Absent|crate::model::paragraph::NumberingMarker::Unresolved)
  ||para.layout_only_fill_lines!=0||para.hwpx_axis_shift!=0||para.source_line_seg_vertical_pos.is_some()
  ||para.cell_format_vpos_dirty||para.stored_text_partition_is_dirty()||para.ctrl_data_records.iter().any(Option::is_some)
  ||styles.supplemental_metrics.is_some()||styles.kerning_measurement_context.is_some()||styles.horizontal_shaping_context.is_some()
  ||fmt.square_host_plan.is_some()||fmt.computed_host_lines.is_some()||fmt.source_mixed_tac_row.is_some()
  ||fmt.line_heights.len()!=1||fmt.line_spacings.len()!=1{return None;}
 let style=styles.para_styles.get(usize::from(para.para_shape_id))?;if !matches!(style.head_type,crate::model::style::HeadType::None)||style.spacing_before!=0.0||style.spacing_after!=0.0{return None;}
 let [row]=para.line_segs.as_slice()else{return None;};
 if row.tag!=(LineSeg::TAG_SINGLE_SEGMENT_LINE|LineSeg::TAG_IMPLEMENTATION_PROPERTY)||row.text_start!=0||row.column_start!=0||row.segment_width<=0
  ||row.vertical_pos<0||row.line_height<=0||row.text_height!=row.line_height||row.line_spacing<0||row.baseline_distance<0||row.baseline_distance>row.line_height{return None;}
 row.vertical_pos.checked_add(row.line_height)?.checked_add(row.line_spacing)?;
 let [Control::Table(t)]=para.controls.as_slice()else{return None;};
 if !t.common.treat_as_char||t.common.allow_overlap||t.common.vertical_offset!=0||t.common.horizontal_offset!=0
  ||t.common.width==0||t.common.width>=0x80000000||t.common.height==0||t.common.height>=0x80000000
  ||t.caption.is_some()||t.repeat_header||t.page_break!=TablePageBreak::None||!t.zones.is_empty()||t.cell_spacing!=0
  ||t.row_count==0||t.row_count>128||t.col_count==0||t.col_count>32||t.cells.len()!=usize::from(t.row_count)*usize::from(t.col_count)
  ||t.cells.iter().enumerate().any(|(i,c)|c.row_span!=1||c.col_span!=1||usize::from(c.row)!=i/usize::from(t.col_count)||usize::from(c.col)!=i%usize::from(t.col_count)
   ||c.width==0||c.height==0||c.field_name.is_some()||c.text_direction!=0||c.line_wrap!=0||c.paragraphs.is_empty()||c.paragraphs.len()>128
   ||c.paragraphs.iter().any(|p|!p.controls.is_empty()||!p.field_ranges.is_empty()||!p.range_tags.is_empty()||!p.orphan_field_ends.is_empty()||!p.tab_extended.is_empty())){return None;}
 let mut owners=measurements.iter().filter(|m|m.para_index==index&&m.control_index==0);let mt=owners.next()?;if owners.next().is_some(){return None;}
 if mt.caption_height!=0.0||mt.row_heights.len()!=usize::from(t.row_count)||mt.cumulative_heights.len()!=mt.row_heights.len()+1
  ||mt.cumulative_heights.first()!=Some(&0.0)||mt.cell_spacing!=0.0||!mt.total_height.is_finite()||mt.total_height<=0.0
  ||!exact(mt.total_height,hwpunit_to_px(t.common.height as i32,dpi)){return None;}
 let mut end=0.0;for(i,h)in mt.row_heights.iter().enumerate(){if !h.is_finite()||*h<=0.0{return None;}end+=*h;if !end.is_finite()||!exact(mt.cumulative_heights[i+1],end){return None;}}
 if !exact(end,mt.total_height)||fmt.line_heights[0]!=hwpunit_to_px(row.line_height,dpi)||fmt.line_spacings[0]!=hwpunit_to_px(row.line_spacing,dpi)
  ||!fmt.total_height.is_finite()||!fmt.height_for_fit.is_finite()||fmt.height_for_fit<=0.0||fmt.height_for_fit>=mt.total_height{return None;}
 Some(mt.total_height)
}
fn exact(a:f64,b:f64)->bool{a.is_finite()&&b.is_finite()&&(a-b).abs()<=f64::EPSILON*a.abs().max(b.abs()).max(1.0)*8.0}

#[cfg(test)]mod tests{
 use super::*;
 fn fixture()->crate::DocumentCore{
  let mut c=crate::DocumentCore::new_empty();c.create_blank_document_native().unwrap();c.insert_text_native(0,0,0,&"Own general-layout prefix. ".repeat(4)).unwrap();
  for n in 0..3{let last=c.document.sections[0].paragraphs.len()-1;let end=c.document.sections[0].paragraphs[last].text.chars().count();c.create_table_native(0,last,end,2,1).unwrap();let pi=c.document.sections[0].paragraphs.iter().rposition(|p|matches!(p.controls.as_slice(),[Control::Table(_)])).unwrap();c.insert_text_in_cell_native(0,pi,0,0,0,0,&format!("Own table {n} first cell. ")).unwrap();c.insert_text_in_cell_native(0,pi,0,1,0,0,&format!("Own table {n} second cell. ")).unwrap();let tail=c.document.sections[0].paragraphs.len()-1;c.insert_text_native(0,tail,0,&format!("Interleaved body {n}. ")).unwrap();}
  let tail=c.document.sections[0].paragraphs.len()-1;let end=c.document.sections[0].paragraphs[tail].text.chars().count();c.insert_text_native(0,tail,end,&"Own trailing paragraph. ".repeat(18)).unwrap();c.set_column_def_native(0,2,0,true,720).unwrap();
  let mut d=c.document.clone();let page=&mut d.sections[0].section_def.page_def;page.height=23000;page.margin_header=1000;page.margin_top=1000;page.margin_bottom=1000;page.margin_footer=1000;
  for p in &mut d.sections[0].paragraphs{for ctrl in &mut p.controls{match ctrl{Control::Table(t)=>{t.common.treat_as_char=true;t.raw_ctrl_data.clear();t.raw_ctrl_seal=None;},Control::SectionDef(s)=>{let page=&mut s.page_def;page.height=23000;page.margin_header=1000;page.margin_top=1000;page.margin_bottom=1000;page.margin_footer=1000;},_=>{}}}}for s in &mut d.sections{s.raw_stream=None;}
  let bytes=crate::serializer::serialize_hwp_with_report(&d).unwrap();let mut c=crate::DocumentCore::from_bytes(bytes.bytes()).unwrap();let end=c.document.sections[0].paragraphs[0].text.chars().count();c.insert_text_native(0,0,end,&"Retained current prefix editing causes line reflow. ".repeat(15)).unwrap();c
 }
 #[test]fn current_measured_band_positive_and_negative_scope145(){
  let c=fixture();let index=c.document.sections[0].paragraphs.iter().rposition(|p|matches!(p.controls.as_slice(),[Control::Table(_)])).unwrap();let p=&c.document.sections[0].paragraphs[index];let styles=c.resolve_render_styles_for_section(0);
  let e=super::super::super::TypesetEngine::new(c.dpi);e.profile.set(c.effective_layout_profile());let fmt=e.format_paragraph(p,c.composed[0].get(index),&styles,Some(c.pagination[0].pages[0].layout.column_areas[0].width));let m=&c.measured_tables[0];
  assert!(measured_band(index,p,&fmt,m,&styles,c.dpi).is_some(),"known empty measured base");
  for case in 0..23{let mut q=p.clone();match case{
   0=>q.line_segs[0].tag&=!LineSeg::TAG_IMPLEMENTATION_PROPERTY,1=>q.line_segs[0].tag|=4,2=>q.line_segs[0].vertical_pos=-1,3=>q.line_segs[0].vertical_pos=i32::MAX,
   4=>q.text.push('x'),5=>q.char_count=8,6=>q.stored_text_partition_dirty=true,7=>q.cell_format_vpos_dirty=true,8=>q.hwpx_axis_shift=1,9=>q.source_line_seg_vertical_pos=Some(vec![0]),
   10=>q.field_ranges.push(Default::default()),11=>q.range_tags.push(Default::default()),12=>q.tab_extended.push([0;7]),13=>q.controls.push(Control::Unknown(Default::default())),
   14=>q.line_segs[0].line_spacing=-1,15=>q.line_segs[0].text_height+=1,
   n=>{let Control::Table(t)=&mut q.controls[0]else{unreachable!()};match n{16=>t.common.treat_as_char=false,17=>t.common.allow_overlap=true,18=>t.common.vertical_offset=1,19=>t.common.horizontal_offset=1,20=>t.repeat_header=true,21=>t.row_count=129,_=>t.cells[0].paragraphs[0].controls.push(Control::Unknown(Default::default()))}}}
   assert!(measured_band(index,&q,&fmt,m,&styles,c.dpi).is_none(),"source case {case}");
  }
  let owner=m.iter().find(|m|m.para_index==index&&m.control_index==0).unwrap();for case in 0..6{let mut bad=m.clone();match case{0=>bad.push(owner.clone()),1=>bad.retain(|m|m.para_index!=index||m.control_index!=0),n=>{let o=bad.iter_mut().find(|m|m.para_index==index&&m.control_index==0).unwrap();match n{2=>o.total_height=f64::NAN,3=>o.cumulative_heights[0]=1.0,4=>o.cumulative_heights[1]+=1.0,_=>o.row_heights[0]=0.0}}}assert!(measured_band(index,p,&fmt,&bad,&styles,c.dpi).is_none(),"measure case {case}");}
 }
}
