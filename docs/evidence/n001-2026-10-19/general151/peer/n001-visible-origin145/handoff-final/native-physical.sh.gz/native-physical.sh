#!/usr/bin/env bash
set -euo pipefail
repo=/mnt/c/Users/jjome/Documents/work/jueony
export RUSTUP_HOME="$repo/.tools/linux-rustup"
export CARGO_HOME="$repo/.tools/linux-cargo"
export PATH="$CARGO_HOME/bin:$PATH"
export CARGO_TARGET_DIR=/tmp/jueony-n001-physical129-private-target
export N001_ROOT="$repo"
cd "$repo/build/n001-visible-origin145/source"
cargo test --offline --locked -p rhwp --lib current_physical_selections::tests -j2 -- --nocapture --test-threads=1
