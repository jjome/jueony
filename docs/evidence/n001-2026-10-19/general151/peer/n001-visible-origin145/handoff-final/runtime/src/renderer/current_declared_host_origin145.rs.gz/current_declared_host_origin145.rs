//! Read-only interpretation of a current standard XML empty-host anchor.
//! This proves a conventional coordinate equation inside the complete fresh
//! visible-host frame proof. It grants no source row/cache/lease authority.
use super::*;
use crate::model::paragraph::{Paragraph,LineSeg,ColumnBreakType};
pub(super) fn current_declared_border(p:&Paragraph,fresh:&LineSeg,body_y:f64,incoming:f64,before:f64,dpi:f64)->Option<f64>{
 if !p.text.is_empty()||p.column_type!=ColumnBreakType::None||p.raw_break_type!=0||p.source_line_seg_vertical_pos.is_some()
  ||p.hwpx_axis_shift!=0||p.stored_text_partition_is_dirty()||p.cell_format_vpos_dirty
  ||p.completed_native_rows.is_some()||fresh.vertical_pos!=0||fresh.tag!=0x80060000
  ||fresh.text_start!=0||fresh.column_start!=0||fresh.segment_width<=0||fresh.line_height<=0
  ||fresh.text_height!=fresh.line_height||fresh.line_spacing<0||fresh.baseline_distance<0
  ||fresh.baseline_distance>fresh.line_height{return None;}
 let [declared]=p.line_segs.as_slice()else{return None;};
 let mut exact=fresh.clone();exact.vertical_pos=declared.vertical_pos;
 if declared!=&exact||declared.vertical_pos<0{return None;}
 let before_hu=integer_hu(before,dpi)?;if before_hu<=0{return None;}
 let current=integer_hu(incoming-body_y,dpi)?;
 if declared.vertical_pos.checked_add(before_hu)?!=current{return None;}
 let border=body_y+super::super::hwpunit_to_px(current,dpi);
 arithmetic_equal(border,incoming).then_some(border)
}
