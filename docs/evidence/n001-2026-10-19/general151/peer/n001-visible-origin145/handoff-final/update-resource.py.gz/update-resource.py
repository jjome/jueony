import pathlib,re,hashlib,json
r=pathlib.Path('build/n001-visible-origin145/source');p=r/'src/model/native_computed_resource.rs';s=p.read_text(encoding='utf8');paths=re.findall(r'\("([^"]+)",include_bytes!',s);h=hashlib.sha256(b'rhwp-portable-native-text-edit-frame-1;source-text-lf\0');files=[]
for f in paths:
 b=(r/f).read_bytes();c=b.replace(b'\r\n',b'\n');h.update(f.encode());h.update(b'\0');h.update(len(c).to_bytes(8,'little'));h.update(c);files.append({'path':f,'sha256':hashlib.sha256(b).hexdigest()})
s=re.sub(r'pub\(crate\) const RESOURCE:\[u8;32\]=\[[^]]*\];','pub(crate) const RESOURCE:[u8;32]=['+', '.join(map(str,h.digest()))+'];',s);p.write_text(s,encoding='utf8');pathlib.Path('build/n001-visible-origin145/resource261-proof.json').write_text(json.dumps({'resource':h.hexdigest(),'files':files},indent=2)+'\n');print(len(paths),h.hexdigest())
