//! Known native-origin outer-box input carried across actual edit reflow.
//! Never a row, source-cache, serializer, completed-frame or export authority.
use super::{paragraph::{Paragraph,LineSeg,ColumnBreakType,NumberingMarker},control::Control};
use serde::Serialize;
#[derive(Debug,Clone,Serialize)]
pub(crate) struct OriginPaintInput {context:[u8;32],resource:[u8;32],post:[u8;32],before_row:LineSeg,after_row:LineSeg}
pub(crate) struct Before {context:[u8;32],other:[u8;32],origin:LineSeg,row:LineSeg}
fn closed(p:&Paragraph)->bool{
 if let [Control::Table(t)]=p.controls.as_slice(){
  let mut nodes=0usize;let mut metrics=0usize;let mut text=0usize;
  for c in &t.cells{for p in &c.paragraphs{
   nodes=nodes.checked_add(1).unwrap_or(usize::MAX);
   metrics=metrics.checked_add(p.layout_space_metrics.len()).unwrap_or(usize::MAX);
   text=text.checked_add(p.text.len()).unwrap_or(usize::MAX);
   if nodes>4096||metrics>32768||text>16*1024*1024||p.char_offsets.len()>2_000_000||p.line_segs.len()>4096{return false;}
  }}
 }

 p.controls.len()==1&&matches!(&p.controls[0],Control::Table(t) if t.caption.is_none()&&!t.common.treat_as_char
 &&matches!(t.common.text_wrap,super::shape::TextWrap::TopAndBottom)&&matches!(t.page_break,super::table::TablePageBreak::None)
 &&t.common.width>0&&t.common.height>0&&t.outer_margin_top>0&&t.cells.len()<=4096
 &&t.cells.iter().all(|c|c.paragraphs.len()<=4096&&c.paragraphs.iter().all(|p|p.controls.is_empty()&&p.completed_native_rows.is_none()
 &&p.native_origin_paint_input.is_none()&&p.field_ranges.is_empty()&&p.orphan_field_ends.is_empty()&&p.range_tags.is_empty())))
 &&p.text.chars().all(|c|c=='\u{fffc}'||c.is_whitespace())&&p.line_segs.len()==1
 &&p.column_type==ColumnBreakType::None&&p.raw_break_type==0&&p.hwpx_axis_shift==0&&p.layout_only_fill_lines==0
 &&p.source_line_seg_vertical_pos.is_none()&&!p.stored_text_partition_dirty&&!p.cell_format_vpos_dirty
 &&p.completed_native_rows.is_none()&&p.field_ranges.is_empty()&&p.orphan_field_ends.is_empty()&&p.range_tags.is_empty()
 &&p.tab_extended.is_empty()&&p.title_marks.is_empty()&&p.markpen_marks.is_empty()&&p.numbering_restart.is_none()
}
// Rows are a separate typed operand, not an ignored coordinate. Completion
// compares the entire actual row against the literal row this producer wrote.
fn other(p:&Paragraph)->Option<[u8;32]>{
 let Paragraph{char_count,control_mask,para_shape_id,style_id,column_type,raw_break_type,page_break_synthesized,
 text,char_offsets,char_shapes,line_segs:_,layout_space_metrics,hwpx_axis_shift,layout_only_fill_lines,
 source_line_seg_vertical_pos,native_source_synthetic_seal,native_source_synthetic_context,completed_native_rows:_,
 native_origin_paint_input:_,native_frame_observation:_,reset_flow_observation:_,range_tags,field_ranges,orphan_field_ends,controls,
 ctrl_data_records,char_count_msb,raw_header_extra,has_para_text,tab_extended,title_marks,markpen_marks,
 numbering_restart,stored_text_partition_dirty,cell_format_vpos_dirty,cell_vpos_reset,numbering_marker}=p;
 let marker=match numbering_marker{NumberingMarker::Unresolved=>0u8,NumberingMarker::Absent=>1,NumberingMarker::Text(..)=>return None};
 let table_seals=controls.iter().filter_map(|c|if let Control::Table(t)=c{Some(t.raw_ctrl_seal)}else{None}).collect::<Vec<_>>();
 let mut children=vec![];
 for c in controls{let Control::Table(t)=c else{return None;};for cell in &t.cells{for p in &cell.paragraphs{
  let child_marker=match &p.numbering_marker{NumberingMarker::Unresolved=>0u8,NumberingMarker::Absent=>1,NumberingMarker::Text(..)=>return None};
  children.push((&p.source_line_seg_vertical_pos,format!("{:?}",p.layout_space_metrics),p.stored_text_partition_dirty,p.cell_format_vpos_dirty,p.cell_vpos_reset,
   p.native_source_synthetic_seal,p.native_source_synthetic_context,child_marker));
 }}}
 digest(&((char_count,control_mask,para_shape_id,style_id,column_type,raw_break_type,page_break_synthesized),
 (text,char_offsets,char_shapes,format!("{layout_space_metrics:?}"),hwpx_axis_shift,layout_only_fill_lines,source_line_seg_vertical_pos),
 (native_source_synthetic_seal,native_source_synthetic_context,range_tags,field_ranges,orphan_field_ends,controls),
 (ctrl_data_records,char_count_msb,raw_header_extra,has_para_text,tab_extended,title_marks,markpen_marks),
 (numbering_restart,stored_text_partition_dirty,cell_format_vpos_dirty,cell_vpos_reset,marker,children,table_seals)))
}
fn full(p:&Paragraph)->Option<[u8;32]>{digest(&(other(p)?,&p.line_segs))}
/// Only the actual known reflow call site can obtain this transient input.
pub(crate) fn begin(p:&Paragraph,context:[u8;32])->Option<Before>{
 if !closed(p){return None;}
 let origin=if p.owns_native_source_synthetic_rows(context){p.line_segs[0].clone()}
 else {let previous=p.native_origin_paint_input.as_ref()?;if !previous.matches_current_inputs(p,context){return None;}previous.before_row.clone()};
 Some(Before{context,other:other(p)?,origin,row:p.line_segs[0].clone()})
}
/// The mutator supplies its computed running_vpos; every other field and the
/// complete actual row must still equal the exact typed producer transition.
pub(crate) fn complete(before:Before,p:&Paragraph,running_vpos:i32)->Option<OriginPaintInput>{
 if !closed(p)||before.origin.vertical_pos!=0||running_vpos<=0||other(p)?!=before.other{return None;}
 let mut expected=before.row.clone();expected.vertical_pos=running_vpos;
 if p.line_segs[0]!=expected{return None;}
 Some(OriginPaintInput{context:before.context,resource:super::native_computed_resource::RESOURCE,post:full(p)?,before_row:before.origin,after_row:expected})
}
impl OriginPaintInput{
 pub(crate) fn matches_current_inputs(&self,p:&Paragraph,context:[u8;32])->bool{
  self.resource==super::native_computed_resource::RESOURCE&&self.context==context&&closed(p)
  &&p.line_segs[0]==self.after_row&&full(p)==Some(self.post)
 }
}

struct HashWriter{hash:blake3::Hasher,left:usize}
impl std::io::Write for HashWriter{
 fn write(&mut self,b:&[u8])->std::io::Result<usize>{
  if b.len()>self.left{return Err(std::io::Error::other("native origin input budget"));}
  self.left-=b.len();self.hash.update(b);Ok(b.len())
 }
 fn flush(&mut self)->std::io::Result<()>{Ok(())}
}
fn digest(value:&impl Serialize)->Option<[u8;32]>{
 let mut w=HashWriter{hash:blake3::Hasher::new(),left:16*1024*1024};
 serde_json::to_writer(&mut w,value).ok()?;Some(*w.hash.finalize().as_bytes())
}
