//! Read-only parsed input for Native's pre-existing half-spacing rule only.
//! Absolute root vpos is not an input of that rule. All other root row fields,
//! complete nested payloads and exact definitions remain bound. No row, origin,
//! reset, raw reuse, serializer or CompletedRows permission is issued here.
use super::*;
use crate::model::{paragraph::{Paragraph,LineSeg,ColumnBreakType},control::Control};
pub(super) fn input(index:usize,paragraph:&Paragraph,next:Option<&Paragraph>,context:[u8;32],budget:&mut usize)->Option<[u8;32]>{
    let next=next?;let next_index=index.checked_add(1)?;let next_tag=next.line_segs.first().map(|row|row.tag);
    // NoStoredFirstRow is a spacing-policy equivalence class: either there
    // is no first row, or its implementation bit is present. Both source and
    // current inputs then make the existing full-spacing predicate false,
    // before vpos/text/style can affect it. This binds the immediate slot,
    // NOT next-paragraph identity, row values, or None/present transitions.
    // A missing next paragraph is rejected above; stored first rows reject.
    if next_tag.is_some_and(|tag|tag&LineSeg::TAG_IMPLEMENTATION_PROPERTY==0){return None;}
    if paragraph.controls.len()!=1 || !matches!(&paragraph.controls[0],Control::Table(t)if t.common.treat_as_char)
      || !paragraph.text.is_empty() || paragraph.char_count!=9 || !paragraph.char_offsets.is_empty()
      || paragraph.line_segs.len()!=1 || paragraph.column_type!=ColumnBreakType::None
      || paragraph.raw_break_type!=0 || paragraph.page_break_synthesized
      || paragraph.stored_text_partition_is_dirty() || paragraph.cell_format_vpos_dirty
      || paragraph.hwpx_axis_shift!=0 || paragraph.layout_only_fill_lines!=0
      || paragraph.source_line_seg_vertical_pos.is_some(){return None;}
    let row=&paragraph.line_segs[0];
    if row.tag&LineSeg::TAG_IMPLEMENTATION_PROPERTY!=0 || row.text_start!=0 || row.vertical_pos<0
      || row.line_height<=0 || row.text_height<=0 || row.text_height>row.line_height
      || row.baseline_distance<0 || row.baseline_distance>row.line_height || row.line_spacing<=0
      || row.vertical_pos.checked_add(row.line_height)?.checked_add(row.line_spacing).is_none(){return None;}
    // Exhaustive destructuring forces review of future Paragraph fields. Only
    // root vpos is omitted from serialized content; existing derived/private
    // cache fields are not content and are never turned into this observation.
    let Paragraph{char_count,control_mask,para_shape_id,style_id,column_type,raw_break_type,page_break_synthesized,
      text,char_offsets,char_shapes,line_segs:_,layout_space_metrics:_,hwpx_axis_shift,layout_only_fill_lines,
      source_line_seg_vertical_pos:_,native_source_synthetic_seal:_,native_source_synthetic_context:_,native_origin_paint_input:_,completed_native_rows:_,
      native_frame_observation:_,reset_flow_observation:_,range_tags,field_ranges,orphan_field_ends,controls,
      ctrl_data_records,char_count_msb,raw_header_extra,has_para_text,tab_extended,title_marks,markpen_marks,
      numbering_restart,stored_text_partition_dirty:_,cell_format_vpos_dirty:_,cell_vpos_reset:_,numbering_marker:_}=paragraph;
    bounded_reset_digest(&(("rhwp-native-tac-half-spacing-policy-2",context,index,next_index,"NoStoredFirstRow"),
      (char_count,control_mask,para_shape_id,style_id,column_type,raw_break_type,page_break_synthesized,text,char_offsets,char_shapes),
      (hwpx_axis_shift,layout_only_fill_lines,range_tags,field_ranges,orphan_field_ends,controls,ctrl_data_records),
      (char_count_msb,raw_header_extra,has_para_text,tab_extended,title_marks,markpen_marks,numbering_restart),
      (row.text_start,row.line_height,row.text_height,row.baseline_distance,row.line_spacing,row.column_start,row.segment_width,row.tag)),budget)
}
