//! 줄 나눔 엔진 (Line Breaking Engine)
//!
//! 문단 텍스트를 토큰화하고 줄 나눔을 수행한다.
//! 한글 어절/글자, 영어 단어/하이픈, CJK 개별 분할을 지원한다.

use super::supplemental_clusters::ParagraphMetricScope;
use super::{char_lang_slot, find_active_char_shape, is_lang_neutral, ComposedParagraph};
use crate::model::control::{Control, CTRL_CHAR_CODE_UNITS};
use crate::model::paragraph::{CharShapeRef, ColumnBreakType, LineSeg, Paragraph, SpaceMetric};
use crate::model::style::{Alignment, HeadType, LineSpacingType};
use crate::renderer::layout::{
    estimate_text_width, estimate_text_width_unrounded, hancom_regenerated_space_width,
    is_cjk_char, kopub_space_advance_em, resolved_letter_spacing,
};
use crate::renderer::layout_frame::{FrameRowMetrics, LayoutFrame, ParagraphBox, RowSegment};
use crate::renderer::style_resolver::{detect_lang_category, ResolvedParaStyle, ResolvedStyleSet};
use crate::renderer::{hwpunit_to_px, px_to_hwpunit};
use std::ops::Range;

struct PreparedParagraphKerning {
    context: std::sync::Arc<crate::renderer::kerning::KerningMeasurementContext>,
    scalar_styles: Vec<crate::renderer::kerning::KerningParagraphScalarStyle>,
    hard_boundaries: Vec<bool>,
    measurement: std::sync::Arc<crate::renderer::kerning::KerningParagraphMeasurement>,
}

struct PreparedParagraphProjection {
    base_positions: Vec<f64>,
    kerning_scalar_styles: Vec<crate::renderer::kerning::KerningParagraphScalarStyle>,
    shaping_scalar_styles:
        Vec<crate::renderer::shaping_paragraph::HorizontalShapingParagraphScalarStyle>,
    hard_boundaries: Vec<bool>,
}

/// A complete, source-independent projection of one supported Picture wrap
/// band. The document layer owns the one-shot publication of every paragraph
/// in this range.
#[derive(Debug, Clone)]
pub(crate) struct PictureBandLayout {
    pub(crate) paragraph_range: Range<usize>,
    pub(crate) line_segs: Vec<Vec<LineSeg>>,
    pub(crate) space_metrics: Vec<Vec<(u32, SpaceMetric)>>,
}

/// How the frame resolved a paragraph's stored rows.
///
/// Stored rows are a cache of a prior frame computation. Reuse is therefore
/// allowed only after the current frame reproduces their physical-row key:
/// interval count plus exact `column_start`/`segment_width` for every slot.
#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) enum StoredRowResolution {
    /// The current frame admitted every stored physical row exactly.
    ///
    /// This is the right answer rather than a placeholder, and the reason is
    /// worth stating because "the frame owns both routes" makes it sound wrong.
    /// The frame is licensed to write two lanes, and on this arm neither one
    /// has anything to say:
    ///
    /// - **Geometry** (`column_start`, `segment_width`). Publishing is a no-op
    ///   by construction: exact equality is the admission test.
    /// - **Row metrics** (`line_height`, `baseline_distance`, `line_spacing`).
    ///   Deliberately not published: §1.4.1's accept-arm write-back is not
    ///   implemented. [`LayoutFrame::try_admit_stored_rows`] records the
    ///   measurement that settled it — publishing them took the suite from
    ///   5983 passed / 2 failed to 5979 / 6.
    ///
    /// So the stored partition may stand only after the frame has checked it.
    Stored,
    /// The stored rows were stale or their physical-row key did not match the
    /// current frame, so strict reflow carved replacement rows. The rows live in
    /// the frame; take them with `project_line_segs()`.
    Reflowed,
}

/// What a caller may conclude from an exact stored-row geometry miss.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum StoredRowMissPolicy {
    /// The caller knows its Frame inputs are current and may publish fresh rows.
    Reflow,
    /// Imported geometry is not derivable from this Frame. A dirty text/style
    /// partition still reflows; a clean geometry miss stays with its source owner.
    UnmodelledUnlessStale,
}

/// 줄 나눔 토큰
#[derive(Debug, Clone)]
pub(crate) enum BreakToken {
    /// 분할 불가 텍스트 조각 (어절/단어/글자)
    /// char_widths: 글자별 px 폭 (char_level_break용, 단일 글자 토큰은 비어있음)
    Text {
        start_idx: usize,
        end_idx: usize,
        /// K0 scalar pen width. Dynamic space/tab accounting and boundary
        /// pair correction are applied against this invariant base.
        base_width: f64,
        /// Owned paragraph-position token total. K0에서는 base_width와 같다.
        width: f64,
        max_font_size: f64,
        base_char_widths: Vec<f64>,
        char_widths: Vec<f64>,
    },
    /// 공백 (줄 바꿈 가능 지점, 줄 끝에서 흡수)
    Space {
        idx: usize,
        width: f64,
        /// [#7418] 자간을 적용하기 **전**의 공백 폭(px). 공백 최소값(condense)은 이 폭의
        /// c% 만큼 줄인다 — 한/글 2024 합성 실험(자간 −20·−12·−6·+10% × condense 0~75,
        /// 777줄)에서 자간 적용 후 폭을 기준으로 하면 음수 자간 문단이 한 줄에 덜 담았다.
        condense_base: f64,
        max_font_size: f64,
        /// A visible object sharing this offset cannot hang beyond the row.
        has_inline_control: bool,
    },
    /// 탭 (줄 바꿈 가능 지점, 폭은 줄 위치에 따라 동적)
    Tab { idx: usize, max_font_size: f64 },
    /// 강제 줄 바꿈 (\n)
    LineBreak { idx: usize },
}

/// 글자처럼 취급되는 인라인 제어문의 문단 내 위치와 물리 크기.
///
/// HWP `PARA_TEXT`에는 수식·그림 본문이 보이지 않는 8 UTF-16 단위 제어문자로
/// 들어가므로, visible text만 토큰화하면 제어문이 차지한 폭이 사라진다. 재조판은
/// 그 폭과 높이를 별도로 들고 줄나눔과 line box에 반영해야 한다 (#3211).
#[derive(Debug, Clone, Copy)]
struct FlowInlineControl {
    char_position: usize,
    width_hwp: i32,
    height_hwp: i32,
    /// Equation supplies an object-owned baseline for the physical row. Other
    /// inline objects keep the text metrics already selected by the caller.
    baseline_distance_hwp: Option<i32>,
}

/// 줄 채움 결과
#[derive(Debug, Clone, PartialEq)]
struct LineBreakResult {
    start_idx: usize,
    end_idx: usize, // exclusive
    max_font_size: f64,
    has_line_break: bool, // 강제 줄 바꿈 여부
}

/// Why one carved interval stopped receiving text.
///
/// A false `has_line_break` alone is ambiguous: a segment can stop because it
/// reached its interval, or because it finished the paragraph. Frame layout
/// needs the distinction to decide whether the next horizontal interval is
/// part of the same physical row.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum FillTermination {
    IntervalFull,
    ForcedBreak,
    ParagraphEnd,
}

#[derive(Debug, Clone, PartialEq)]
struct FilledInterval {
    line: LineBreakResult,
    termination: FillTermination,
}

/// 줄 머리 금칙: 줄 시작에 올 수 없는 문자
pub(crate) fn is_line_start_forbidden(ch: char) -> bool {
    matches!(
        ch,
        ')' | ']'
            | '}'
            | ','
            | '.'
            | '!'
            | '?'
            | ';'
            | ':'
            | '\''
            | '"'
            | '\u{3001}'
            | '\u{3002}'
            | '\u{2026}'
            | '\u{00B7}'
            // ‧ HYPHENATION POINT — 한컴 저장 조판 실측: 줄머리 0건 · 줄끝 2건.
            // `·`(U+00B7)는 이미 있는데 이것만 빠져 있어 줄 머리로 내려갔다.
            | '\u{2027}'
            | '\u{2015}'
            | '\u{30FC}'
            | '\u{300B}'
            | '\u{300D}'
            | '\u{300F}'
            | '\u{3011}'
            | '\u{FF09}'
            | '\u{FF5D}'
            | '\u{3015}'
            | '\u{3009}'
            | '\u{FF1E}'
            | '\u{226B}'
            | '\u{FF3D}'
            | '\u{FE5E}'
            | '\u{301E}'
            | '\u{2019}'
            | '\u{201D}'
            | '\u{FF0C}'
            | '\u{FF0E}'
            | '\u{FF01}'
            | '\u{FF1F}'
            | '\u{FF1B}'
            | '\u{FF1A}'
            | '%'
            | '\u{2030}'
            | '\u{2103}'
            | '\u{00B0}'
            | '\u{FF05}'
    )
}

/// 줄 꼬리 금칙: 줄 끝에 올 수 없는 문자
/// [#7418] 글자 단위 한글 문단에서 `start_idx` 의 한글 글자 **앞**이 줄 끝 자리인가.
///
/// 글자 단위 모드는 한글 글자마다 그 **뒤**를 줄 끝 후보로 등록한다. 그래서 한글 앞에
/// 라틴·숫자 토큰이 공백 없이 붙으면(`3,588만원`) 그 경계를 끊을 수 없었고, `만` 이 넘치면
/// 줄이 앞 공백으로 되감겨 `3,588` 까지 다음 줄로 내려갔다. 한/글은 그 경계에서 끊는다 —
/// 말뭉치 `pdf/` 에서 같은 문단의 이어진 줄이 라틴·숫자로 끝나고 한글로 시작하는 경계가
/// 809곳이다(`제37조제1|항` · `CBTA|훈련체계` · `Annex 1|의` · `연간 10|시간`).
///
/// 직전 글자가 공백이면 이미 공백 토큰이 줄 끝 후보이고, 줄 끝 금칙 문자(`(`·`「` 등)면
/// 줄 끝에 둘 수 없다. 직전이 한글이면 그 글자 뒤로 이미 등록된 같은 자리다.
fn break_before_hangul_char(
    text_chars: &[char],
    start_idx: usize,
    line_start_idx: usize,
    korean_break_unit: u8,
) -> bool {
    // [#2185] bit7=1 = 글자 단위
    korean_break_unit == 1
        && start_idx > line_start_idx
        && text_chars.get(start_idx).is_some_and(|c| is_hangul(*c))
        && text_chars
            .get(start_idx - 1)
            .is_some_and(|prev| !prev.is_whitespace() && !is_line_end_forbidden(*prev))
}

pub(crate) fn is_line_end_forbidden(ch: char) -> bool {
    matches!(
        ch,
        '(' | '['
            | '{'
            | '\''
            | '"'
            | '\u{300A}'
            | '\u{300C}'
            | '\u{300E}'
            | '\u{3010}'
            | '\u{FF08}'
            | '\u{FF5B}'
            | '\u{3014}'
            | '\u{3008}'
            | '\u{FF1C}'
            | '\u{226A}'
            | '\u{FF3B}'
            | '\u{301D}'
            | '\u{2018}'
            | '\u{201C}'
            | '$'
            | '\u{20A9}'
            | '\u{00A3}'
            | '\u{20AC}'
            | '\u{00A5}'
            | '\u{FF04}'
            | '\u{FFE5}'
    )
}

/// 한글 음절/자모 여부 (옛한글 확장 자모 포함)
fn is_hangul(ch: char) -> bool {
    ('\u{AC00}'..='\u{D7A3}').contains(&ch)       // 한글 음절
        || ('\u{1100}'..='\u{11FF}').contains(&ch) // 한글 자모
        || ('\u{3130}'..='\u{318F}').contains(&ch) // 한글 호환 자모 (ㆍ U+318D 포함)
        || ('\u{A960}'..='\u{A97F}').contains(&ch) // 한글 자모 확장-A (옛한글 초성)
        || ('\u{D7B0}'..='\u{D7FF}').contains(&ch) // 한글 자모 확장-B (옛한글 중/종성)
}

/// 라틴 문자 여부 (영문+숫자)
fn is_latin(ch: char) -> bool {
    let lang = detect_lang_category(ch);
    lang == 1 // English/Latin
}

/// CJK 문자 여부 (한자/일본어 — 개별 분할 대상)
fn is_cjk_ideograph(ch: char) -> bool {
    let lang = detect_lang_category(ch);
    lang == 2 || lang == 3 // Chinese or Japanese
}

/// 문단 텍스트를 줄 나눔 토큰으로 분할한다.
pub(crate) fn tokenize_paragraph(
    text_chars: &[char],
    char_offsets: &[u32],
    char_shapes: &[CharShapeRef],
    styles: &ResolvedStyleSet,
    english_break_unit: u8,
    korean_break_unit: u8,
) -> Vec<BreakToken> {
    tokenize_paragraph_with_regenerated_space_metric(
        text_chars,
        char_offsets,
        char_shapes,
        styles,
        english_break_unit,
        korean_break_unit,
        SpaceMetric::Stored,
        &[],
    )
}

impl SpaceMetric {
    /// 줄 채움과 실제 run 배치가 소비하는 동일한 공백 규칙.
    pub(crate) fn apply_to_style(self, style: &mut crate::renderer::TextStyle) {
        match self {
            Self::Stored => {}
            Self::HancomRegenerated => {
                if hancom_regenerated_space_width(style).is_some() {
                    style.layout_half_space = true;
                }
            }
            Self::HalfCell => {
                style.layout_half_space = true;
            }
            Self::KoPubJustified => {
                if let Some(em) = kopub_space_advance_em(style) {
                    style.font_space_em = Some(em);
                }
            }
        }
    }

    fn space_advance(self, style: &crate::renderer::TextStyle) -> f64 {
        let mut selected = style.clone();
        self.apply_to_style(&mut selected);
        estimate_text_width_unrounded(" ", &selected)
    }
}

/// `space_metric` 은 공백 advance 규칙이다. 일반 HWP/HWPX tokenization 은 저장
/// `LINE_SEG` 호환성을 위해 [`SpaceMetric::Stored`] 를 쓴다.
/// 상대 크기는 글리프 폭과 표시 크기이며 기본 줄 상자를 바꾸지 않는다.
/// 원본 LineSeg도 상대 크기 95%(줄이기)·106%(키우기, #7398 `exam_eng.hwp`
/// 라틴 문단 `lh = th = 1150`) 모두 기준 크기의 textheight를 보존한다.
fn token_line_font_size(styles: &ResolvedStyleSet, style_id: u32) -> f64 {
    styles
        .char_styles
        .get(style_id as usize)
        .map(|s| s.font_size)
        .filter(|size| *size > 0.0)
        .unwrap_or(12.0)
}

/// Lexical text units shared with physical TAC row placement. Inline control
/// boundaries remain owned by the caller, rather than joined into a word.
pub(crate) fn text_word_ranges(para: &Paragraph, styles: &ResolvedStyleSet) -> Vec<Range<usize>> {
    let chars: Vec<_> = para.text.chars().collect();
    let style = styles.para_styles.get(para.para_shape_id as usize);
    tokenize_paragraph_with_regenerated_space_metric(
        &chars,
        &para.char_offsets,
        &para.char_shapes,
        styles,
        style.map_or(0, |s| s.english_break_unit),
        style.map_or(0, |s| s.korean_break_unit),
        SpaceMetric::Stored,
        &[],
    )
    .into_iter()
    .filter_map(|token| match token {
        BreakToken::Text {
            start_idx, end_idx, ..
        } => Some(start_idx..end_idx),
        _ => None,
    })
    .collect()
}

fn tokenize_paragraph_with_regenerated_space_metric(
    text_chars: &[char],
    char_offsets: &[u32],
    char_shapes: &[CharShapeRef],
    styles: &ResolvedStyleSet,
    english_break_unit: u8,
    korean_break_unit: u8,
    space_metric: SpaceMetric,
    inline_controls: &[FlowInlineControl],
) -> Vec<BreakToken> {
    let text_len = text_chars.len();
    if text_len == 0 {
        return Vec::new();
    }

    let mut tokens = Vec::new();
    let mut i = 0;
    let metric_scope = ParagraphMetricScope::new(text_chars, styles)
        .with_reflow_slots(text_chars)
        .with_space_metric(space_metric);
    let mut current_lang: usize = 0;

    while i < text_len {
        let ch = text_chars[i];

        // 강제 줄 바꿈
        if ch == '\n' {
            tokens.push(BreakToken::LineBreak { idx: i });
            i += 1;
            continue;
        }

        // 탭
        if ch == '\t' {
            let utf16_pos = if i < char_offsets.len() {
                char_offsets[i]
            } else {
                i as u32
            };
            let style_id = find_active_char_shape(char_shapes, utf16_pos);
            let ts = metric_scope.style(styles, style_id, current_lang, i);
            let font_size = token_line_font_size(styles, style_id);
            tokens.push(BreakToken::Tab {
                idx: i,
                max_font_size: font_size,
            });
            i += 1;
            continue;
        }

        // 공백 (줄 바꿈 지점) — NonBreakingSpace(\u{00A0})는 제외
        if ch == ' ' {
            let utf16_pos = if i < char_offsets.len() {
                char_offsets[i]
            } else {
                i as u32
            };
            let style_id = find_active_char_shape(char_shapes, utf16_pos);
            let ts = metric_scope.style(styles, style_id, current_lang, i);
            let font_size = token_line_font_size(styles, style_id);
            let inline_width = inline_width_px_at(inline_controls, i);
            let unspaced = crate::renderer::TextStyle {
                letter_spacing: 0.0,
                ..ts.clone()
            };
            tokens.push(BreakToken::Space {
                idx: i,
                width: space_metric.space_advance(&ts) + inline_width,
                condense_base: space_metric.space_advance(&unspaced),
                max_font_size: font_size,
                has_inline_control: inline_width > 0.0,
            });
            i += 1;
            continue;
        }

        // 한글 어절 또는 글자.
        // [#2185] bit7=1(KEEP_WORD)이 **글자 단위**, bit7=0(BREAK_WORD)이
        // 어절 단위 — 스키마 명목과 반대 (한컴 통제 실측 3중 확증: #2169
        // kbu 사다리, 80168 r10, #2185 giant-cell LINE_SEG [0,44,84,122]
        // 보존 대조). 종전 == 1 어절 분기는 역해석 (0da18bbc 회귀).
        if is_hangul(ch) {
            if korean_break_unit == 0 {
                // 어절 모드: 연속 한글 + 후행 금칙 문자를 하나의 토큰으로
                let start = i;
                let mut max_fs = 0.0f64;
                let mut token_text = String::new();
                let mut token_lang = current_lang;

                while i < text_len {
                    let c = text_chars[i];
                    if c == ' ' || c == '\n' || c == '\t' {
                        break;
                    }
                    // 한글이 아니고 라틴이면 다른 토큰으로 분리
                    if !is_hangul(c) && is_latin(c) {
                        break;
                    }
                    // CJK 한자/일본어는 개별 토큰
                    if is_cjk_ideograph(c) {
                        break;
                    }

                    let utf16_pos = if i < char_offsets.len() {
                        char_offsets[i]
                    } else {
                        i as u32
                    };
                    let style_id = find_active_char_shape(char_shapes, utf16_pos);
                    let lang = if is_lang_neutral(c) {
                        token_lang
                    } else {
                        let detected = detect_lang_category(c);
                        token_lang = detected;
                        current_lang = detected;
                        detected
                    };
                    let ts = metric_scope.style(styles, style_id, lang, i);
                    let fs = token_line_font_size(styles, style_id);
                    if fs > max_fs {
                        max_fs = fs;
                    }
                    token_text.push(c);
                    i += 1;
                }

                // 후행 금칙 문자 (줄 머리 금칙) 흡수
                while i < text_len
                    && is_line_start_forbidden(text_chars[i])
                    && text_chars[i] != '\n'
                    && text_chars[i] != '\t'
                {
                    let c = text_chars[i];
                    let utf16_pos = if i < char_offsets.len() {
                        char_offsets[i]
                    } else {
                        i as u32
                    };
                    let style_id = find_active_char_shape(char_shapes, utf16_pos);
                    let lang = if is_lang_neutral(c) {
                        current_lang
                    } else {
                        let detected = detect_lang_category(c);
                        current_lang = detected;
                        detected
                    };
                    let ts = metric_scope.style(styles, style_id, lang, i);
                    let fs = token_line_font_size(styles, style_id);
                    if fs > max_fs {
                        max_fs = fs;
                    }
                    token_text.push(c);
                    i += 1;
                }

                if !token_text.is_empty() {
                    // 토큰 폭과 **그 합을 이루는 글자별 폭**을 한 번에 받는다.
                    //
                    // 종전에는 글자별 폭을 inline control 이 있는 토큰에만 채웠다.
                    // 그러면 한 줄에 안 들어가는 보통의 한글 토큰이 글자 단위 폴백으로
                    // 내려갔을 때 `base_char_widths` 가 비어, 폴백이 측정과 무관한 상수
                    // (`line_max_fs.max(12.0)`) 로 글자를 잘랐다 — 같은 토큰을 재는 자가
                    // 둘이 된다. `#7407` 대상 셀(연속 줄 38208 HWPUNIT, 9pt 장평 95%)에서
                    // 실제 전진폭은 11.400px 인데 폴백은 12.000px 로 세어 줄마다 42자만
                    // 담았다 — 43번째 글자는 19px 을 남기고 들어가는데도 거부됐다.
                    // 한/글 출력은 같은 줄에 44자를 담는다.
                    let (width, char_widths) = measure_token_char_widths(
                        &metric_scope,
                        &token_text,
                        start,
                        char_offsets,
                        char_shapes,
                        styles,
                        current_lang,
                        inline_controls,
                    );
                    tokens.push(BreakToken::Text {
                        start_idx: start,
                        end_idx: i,
                        base_width: width,
                        width,
                        max_font_size: max_fs,
                        base_char_widths: char_widths.clone(),
                        char_widths,
                    });
                }
                continue;
            } else {
                // 글자 모드: 한글 개별 분할
                let utf16_pos = if i < char_offsets.len() {
                    char_offsets[i]
                } else {
                    i as u32
                };
                let style_id = find_active_char_shape(char_shapes, utf16_pos);
                current_lang = detect_lang_category(ch);
                let ts = metric_scope.style(styles, style_id, current_lang, i);
                let fs = token_line_font_size(styles, style_id);
                let mut w = estimate_text_width_unrounded(&ch.to_string(), &ts)
                    + inline_width_px_at(inline_controls, i);
                // 글자 모드에서도 **줄 머리 금칙**을 지킨다.
                //
                // 어절 모드(위 분기)만 후행 금칙 문자를 앞 토큰에 흡수하고 있어, 글자 모드
                // 문단은 쉼표·가운뎃점이 다음 줄 첫 글자로 내려갔다. 한글은 같은 문단 설정에서도
                // 그렇게 조판하지 않는다 — 실측: 원본 파일 284줄 중 줄머리 금칙 0건,
                // 우리 재조판 291줄 중 6건(", 생산성 정체를…" · "·경쟁하면서…").
                // 저장된 사다리가 있는 문서는 그 값을 쓰므로 영향이 없고, 편집·붙여넣기처럼
                // 다시 조판하는 경우에만 달라진다.
                let start = i;
                i += 1;
                while i < text_len
                    && is_line_start_forbidden(text_chars[i])
                    && text_chars[i] != '\n'
                    && text_chars[i] != '\t'
                    // 🔴 금칙 문자 바로 뒤에 라틴/숫자 낱말이 이어지면 앞 글자에 붙이지 않는다.
                    // 한컴은 `한다.111…` 에서 `.` 을 앞의 `다` 가 아니라 뒤의 숫자 낱말에 붙여
                    // 통째로 다음 줄로 내린다(#2214 핀: 줄 시작 129 = `.`). 뒤가 공백·한글·끝이면
                    // 종전대로 앞 글자에 흡수한다(`, 생산성`·`‧기업` — 정답지 284줄 줄머리 금칙 0건).
                    && !text_chars
                        .get(i + 1)
                        .is_some_and(|next| next.is_ascii_alphanumeric())
                {
                    let follow_pos = if i < char_offsets.len() {
                        char_offsets[i]
                    } else {
                        i as u32
                    };
                    let follow_style = find_active_char_shape(char_shapes, follow_pos);
                    let follow_ts = metric_scope.style(styles, follow_style, current_lang, i);
                    w += estimate_text_width_unrounded(&text_chars[i].to_string(), &follow_ts)
                        + inline_width_px_at(inline_controls, i);
                    i += 1;
                }
                tokens.push(BreakToken::Text {
                    start_idx: start,
                    end_idx: i,
                    base_width: w,
                    width: w,
                    max_font_size: fs,
                    base_char_widths: vec![],
                    char_widths: vec![],
                });
                continue;
            }
        }

        // 라틴 단어 또는 글자
        if is_latin(ch) {
            if english_break_unit == 0 || english_break_unit == 1 {
                // 단어/하이픈 모드: 연속 라틴 문자를 하나의 토큰으로
                let start = i;
                let mut max_fs = 0.0f64;
                let mut token_text = String::new();

                while i < text_len {
                    let c = text_chars[i];
                    if c == ' ' || c == '\n' || c == '\t' {
                        break;
                    }
                    if !is_latin(c) && !is_lang_neutral(c) {
                        break;
                    }
                    // 하이픈 모드: 하이픈에서 분할 (하이픈 포함 후 분리)
                    if english_break_unit == 1 && c == '-' && !token_text.is_empty() {
                        let utf16_pos = if i < char_offsets.len() {
                            char_offsets[i]
                        } else {
                            i as u32
                        };
                        let style_id = find_active_char_shape(char_shapes, utf16_pos);
                        let lang = 1usize; // English
                        let ts = metric_scope.style(styles, style_id, lang, i);
                        let fs = token_line_font_size(styles, style_id);
                        if fs > max_fs {
                            max_fs = fs;
                        }
                        token_text.push(c);
                        i += 1;
                        break; // 하이픈 뒤에서 분할
                    }

                    let utf16_pos = if i < char_offsets.len() {
                        char_offsets[i]
                    } else {
                        i as u32
                    };
                    let style_id = find_active_char_shape(char_shapes, utf16_pos);
                    let lang = if is_lang_neutral(c) {
                        current_lang
                    } else {
                        current_lang = 1; // English
                        1
                    };
                    let ts = metric_scope.style(styles, style_id, lang, i);
                    let fs = token_line_font_size(styles, style_id);
                    if fs > max_fs {
                        max_fs = fs;
                    }
                    token_text.push(c);
                    i += 1;
                }

                if !token_text.is_empty() {
                    let width = measure_token_width(
                        &metric_scope,
                        &token_text,
                        start,
                        char_offsets,
                        char_shapes,
                        styles,
                        current_lang,
                        inline_controls,
                    );
                    // 개별 글자 폭 수집 (char_level_break용)
                    let cw: Vec<f64> = (start..i)
                        .map(|ci| {
                            let c = text_chars[ci];
                            let u16p = if ci < char_offsets.len() {
                                char_offsets[ci]
                            } else {
                                ci as u32
                            };
                            let sid = find_active_char_shape(char_shapes, u16p);
                            let lang = if is_lang_neutral(c) { current_lang } else { 1 };
                            let ts = metric_scope.style(styles, sid, lang, ci);
                            estimate_text_width_unrounded(&c.to_string(), &ts)
                                + inline_width_px_at(inline_controls, ci)
                        })
                        .collect();
                    tokens.push(BreakToken::Text {
                        start_idx: start,
                        end_idx: i,
                        base_width: width,
                        width,
                        max_font_size: max_fs,
                        base_char_widths: cw.clone(),
                        char_widths: cw,
                    });
                }
                continue;
            } else {
                // 글자 모드
                let utf16_pos = if i < char_offsets.len() {
                    char_offsets[i]
                } else {
                    i as u32
                };
                let style_id = find_active_char_shape(char_shapes, utf16_pos);
                current_lang = 1;
                let ts = metric_scope.style(styles, style_id, current_lang, i);
                let fs = token_line_font_size(styles, style_id);
                let w = estimate_text_width_unrounded(&ch.to_string(), &ts)
                    + inline_width_px_at(inline_controls, i);
                tokens.push(BreakToken::Text {
                    start_idx: i,
                    end_idx: i + 1,
                    base_width: w,
                    width: w,
                    max_font_size: fs,
                    base_char_widths: vec![],
                    char_widths: vec![],
                });
                i += 1;
                continue;
            }
        }

        // CJK 한자/일본어: 항상 개별 토큰
        if is_cjk_ideograph(ch) {
            let utf16_pos = if i < char_offsets.len() {
                char_offsets[i]
            } else {
                i as u32
            };
            let style_id = find_active_char_shape(char_shapes, utf16_pos);
            current_lang = detect_lang_category(ch);
            let ts = metric_scope.style(styles, style_id, current_lang, i);
            let fs = token_line_font_size(styles, style_id);
            let w = estimate_text_width_unrounded(&ch.to_string(), &ts)
                + inline_width_px_at(inline_controls, i);
            tokens.push(BreakToken::Text {
                start_idx: i,
                end_idx: i + 1,
                base_width: w,
                width: w,
                max_font_size: fs,
                base_char_widths: vec![],
                char_widths: vec![],
            });
            i += 1;
            continue;
        }

        // 기타 문자 (기호, NonBreakingSpace 등): 개별 Text 토큰
        {
            let utf16_pos = if i < char_offsets.len() {
                char_offsets[i]
            } else {
                i as u32
            };
            let style_id = find_active_char_shape(char_shapes, utf16_pos);
            let lang = if is_lang_neutral(ch) {
                current_lang
            } else {
                let detected = detect_lang_category(ch);
                current_lang = detected;
                detected
            };
            let ts = metric_scope.style(styles, style_id, lang, i);
            let fs = token_line_font_size(styles, style_id);
            let w = estimate_text_width_unrounded(&ch.to_string(), &ts)
                + inline_width_px_at(inline_controls, i);
            tokens.push(BreakToken::Text {
                start_idx: i,
                end_idx: i + 1,
                base_width: w,
                width: w,
                max_font_size: fs,
                base_char_widths: vec![],
                char_widths: vec![],
            });
            i += 1;
        }
    }

    tokens
}

/// 토큰 텍스트의 폭을 글자별 언어 인식 측정으로 합산한다.
fn measure_token_width(
    metric_scope: &ParagraphMetricScope,
    text: &str,
    start_char_idx: usize,
    char_offsets: &[u32],
    char_shapes: &[CharShapeRef],
    styles: &ResolvedStyleSet,
    default_lang: usize,
    inline_controls: &[FlowInlineControl],
) -> f64 {
    measure_token_char_widths(
        metric_scope,
        text,
        start_char_idx,
        char_offsets,
        char_shapes,
        styles,
        default_lang,
        inline_controls,
    )
    .0
}

/// 토큰 전체 폭과, **그 합을 이루는 글자별 폭**을 함께 낸다.
///
/// 줄 나눔은 토큰이 통째로 들어갈 때는 합만 쓰고, 안 들어갈 때는 글자 단위 폴백에서
/// 개별 폭을 쓴다. 두 값이 같은 순회에서 나와야 한 토큰을 두 잣대로 재지 않는다.
/// 합은 종전 `measure_token_width` 와 같은 순서로 누적하므로 값이 바뀌지 않는다.
fn measure_token_char_widths(
    metric_scope: &ParagraphMetricScope,
    text: &str,
    start_char_idx: usize,
    char_offsets: &[u32],
    char_shapes: &[CharShapeRef],
    styles: &ResolvedStyleSet,
    default_lang: usize,
    inline_controls: &[FlowInlineControl],
) -> (f64, Vec<f64>) {
    let mut total = 0.0;
    let mut char_widths = Vec::with_capacity(text.len());
    let mut current_lang = default_lang;
    for (offset, ch) in text.chars().enumerate() {
        let idx = start_char_idx + offset;
        let utf16_pos = if idx < char_offsets.len() {
            char_offsets[idx]
        } else {
            idx as u32
        };
        let style_id = find_active_char_shape(char_shapes, utf16_pos);
        let lang = if is_lang_neutral(ch) {
            current_lang
        } else {
            let detected = detect_lang_category(ch);
            current_lang = detected;
            detected
        };
        let ts = metric_scope.style(styles, style_id, lang, idx);
        let width = estimate_text_width_unrounded(&ch.to_string(), &ts)
            + inline_width_px_at(inline_controls, idx);
        total += width;
        char_widths.push(width);
    }
    (total, char_widths)
}

fn inline_width_px_at(inline_controls: &[FlowInlineControl], char_idx: usize) -> f64 {
    inline_controls
        .iter()
        .filter(|control| control.char_position == char_idx)
        .map(|control| control.width_hwp as f64 / 75.0)
        .sum()
}

/// 기존 scalar tokenization과 같은 문자별 base pen을 만든 뒤, 그 입력 전체를
/// transaction-shared paragraph measurement cache에 건넨다.
fn prepare_paragraph_projection(
    para: &Paragraph,
    text_chars: &[char],
    styles: &ResolvedStyleSet,
    space_metric: SpaceMetric,
    inline_controls: &[FlowInlineControl],
    composed: Option<&ComposedParagraph>,
) -> Option<PreparedParagraphProjection> {
    if text_chars.is_empty() {
        return None;
    }
    let mut current_lang = 0usize;
    let mut base_positions = Vec::with_capacity(text_chars.len().saturating_add(1));
    let metric_scope = ParagraphMetricScope::new(text_chars, styles)
        .with_reflow_slots(text_chars)
        .with_space_metric(space_metric);
    let metric_scope = if let Some(composed) = composed {
        ParagraphMetricScope::new(text_chars, styles)
            .with_composed_slots(text_chars, composed)
            .with_space_metric(space_metric)
    } else {
        metric_scope
    };
    let mut kerning_scalar_styles = Vec::with_capacity(text_chars.len());
    let mut shaping_scalar_styles = Vec::with_capacity(text_chars.len());
    let mut hard_boundaries = vec![false; text_chars.len().saturating_add(1)];
    let mut pen = 0.0f64;
    base_positions.push(pen);

    for (index, character) in text_chars.iter().copied().enumerate() {
        let language_index = if is_lang_neutral(character) {
            current_lang
        } else {
            let detected = detect_lang_category(character);
            current_lang = detected;
            detected
        };
        let utf16_pos = para
            .char_offsets
            .get(index)
            .copied()
            .unwrap_or(index as u32);
        let char_shape_id = find_active_char_shape(&para.char_shapes, utf16_pos);
        let text_style = metric_scope.style(styles, char_shape_id, language_index, index);
        let base_font_size = if text_style.font_size > 0.0 {
            text_style.font_size
        } else {
            12.0
        };
        let effective_font_size_px = if text_style.superscript || text_style.subscript {
            base_font_size * crate::renderer::SCRIPT_FONT_SCALE
        } else {
            base_font_size
        };
        let width_ratio = if text_style.ratio > 0.0 {
            text_style.ratio
        } else {
            1.0
        };
        let language_index = metric_scope.scalar_slot(styles, char_shape_id, language_index, index);
        let slot = crate::renderer::kerning::ExactFontSlot::new(char_shape_id, language_index);
        kerning_scalar_styles.push(crate::renderer::kerning::KerningParagraphScalarStyle {
            slot,
            requested: text_style.kerning,
            effective_font_size_px,
            width_ratio,
        });
        shaping_scalar_styles.push(
            crate::renderer::shaping_paragraph::HorizontalShapingParagraphScalarStyle {
                slot,
                effective_font_size_px,
                width_ratio,
                letter_spacing_px: text_style.letter_spacing,
                kerning: text_style.kerning,
                bold: text_style.bold,
                italic: text_style.italic,
                superscript: text_style.superscript,
                subscript: text_style.subscript,
            },
        );

        let scalar_width = match character {
            '\t' | '\n' | '\r' => 0.0,
            ' ' => space_metric.space_advance(&text_style),
            _ => estimate_text_width_unrounded(&character.to_string(), &text_style),
        } + inline_width_px_at(inline_controls, index);
        pen += scalar_width.max(0.0);
        base_positions.push(pen);
    }

    for control in inline_controls {
        let boundary = control.char_position.min(text_chars.len());
        hard_boundaries[boundary] = true;
        if boundary < text_chars.len() {
            hard_boundaries[boundary + 1] = true;
        }
    }
    Some(PreparedParagraphProjection {
        base_positions,
        kerning_scalar_styles,
        shaping_scalar_styles,
        hard_boundaries,
    })
}

fn prepare_paragraph_kerning(
    para: &Paragraph,
    text_chars: &[char],
    styles: &ResolvedStyleSet,
    space_metric: SpaceMetric,
    inline_controls: &[FlowInlineControl],
) -> Option<PreparedParagraphKerning> {
    let paragraph_requests_kerning = if para.char_shapes.is_empty() {
        styles
            .char_styles
            .first()
            .is_some_and(|style| style.kerning)
    } else {
        para.char_shapes.iter().any(|shape| {
            styles
                .char_styles
                .get(shape.char_shape_id as usize)
                .is_some_and(|style| style.kerning)
        })
    };
    if !paragraph_requests_kerning {
        return None;
    }
    let context = styles.kerning_measurement_context.as_ref()?.clone();
    let projection = prepare_paragraph_projection(
        para,
        text_chars,
        styles,
        space_metric,
        inline_controls,
        None,
    )?;
    if !projection
        .kerning_scalar_styles
        .iter()
        .any(|style| style.requested)
    {
        return None;
    }
    let measurement = context.paragraph_measurement(
        &para.text,
        projection.base_positions,
        &projection.kerning_scalar_styles,
        &projection.hard_boundaries,
    );
    if measurement.disposition
        != crate::renderer::kerning::KerningParagraphMeasurementDisposition::PairAdjusted
    {
        return None;
    }

    Some(PreparedParagraphKerning {
        context,
        scalar_styles: projection.kerning_scalar_styles,
        hard_boundaries: projection.hard_boundaries,
        measurement,
    })
}

fn has_rtl_or_bidi_control(text: &str) -> bool {
    text.chars().any(|character| {
        matches!(
            character as u32,
            0x0590..=0x08FF
                | 0xFB1D..=0xFDFF
                | 0xFE70..=0xFEFF
                | 0x10800..=0x10FFF
                | 0x1E800..=0x1EEFF
                | 0x200E..=0x200F
                | 0x202A..=0x202E
                | 0x2066..=0x2069
        )
    })
}

/// Run Q2-C only at the opt-in composition boundary and retain the exact Arc
/// returned by the transaction.  Every malformed or unsupported input maps to
/// `None`; the legacy `ComposedParagraph` fields are never rewritten here.
pub(super) fn compose_horizontal_shaping_handoff(
    para: &Paragraph,
    composed: &ComposedParagraph,
    styles: &ResolvedStyleSet,
) -> Option<std::sync::Arc<crate::renderer::shaping_paragraph::HorizontalShapingLineOutcome>> {
    let kerning_context = styles.kerning_measurement_context.as_ref()?;
    let shaping_context = styles.horizontal_shaping_context.as_ref()?;
    if kerning_context.registry_generation() != shaping_context.registry_generation() {
        return None;
    }
    let q2_candidate =
        crate::renderer::shaping_paragraph::is_bounded_horizontal_shaping_candidate_text(
            &para.text,
        );
    if !q2_candidate && shaping_context.instance_request_count() == 0 {
        return None;
    }

    let text_chars = para.text.chars().collect::<Vec<_>>();
    let inline_controls = flow_inline_controls(para);
    let projection = prepare_paragraph_projection(
        para,
        &text_chars,
        styles,
        SpaceMetric::Stored,
        &inline_controls,
        Some(composed),
    )?;
    let kerning_measurement = kerning_context.paragraph_measurement(
        &para.text,
        projection.base_positions.clone(),
        &projection.kerning_scalar_styles,
        &projection.hard_boundaries,
    );
    let (fallback_positions, fallback_owner) = if kerning_measurement.disposition
        == crate::renderer::kerning::KerningParagraphMeasurementDisposition::PairAdjusted
    {
        (
            kerning_measurement.positions(),
            crate::renderer::shaping_paragraph::HorizontalShapingFallbackOwner::W9K1,
        )
    } else {
        (
            projection.base_positions.as_slice(),
            crate::renderer::shaping_paragraph::HorizontalShapingFallbackOwner::ExistingK0,
        )
    };

    let code_point_count = text_chars.len();
    let mut candidate_boundaries = composed
        .lines
        .iter()
        .map(|line| line.char_start)
        .chain(std::iter::once(code_point_count))
        .collect::<Vec<_>>();
    candidate_boundaries.sort_unstable();
    candidate_boundaries.dedup();
    if candidate_boundaries
        .iter()
        .any(|index| *index > code_point_count)
    {
        return None;
    }
    let available_widths_px = composed
        .lines
        .iter()
        .map(|line| hwpunit_to_px(line.segment_width, 96.0))
        .collect::<Vec<_>>();
    if available_widths_px.is_empty()
        || available_widths_px
            .iter()
            .any(|width| !width.is_finite() || *width <= 0.0)
    {
        return None;
    }

    let composed_text = composed
        .lines
        .iter()
        .flat_map(|line| line.runs.iter())
        .map(|run| run.text.as_str())
        .collect::<String>();
    let has_char_overlap = composed
        .lines
        .iter()
        .flat_map(|line| line.runs.iter())
        .any(|run| run.char_overlap.is_some());
    let para_style = styles.para_styles.get(para.para_shape_id as usize);
    let paragraph = crate::renderer::shaping_paragraph::HorizontalShapingParagraphRequest {
        attempt_id_base: 1,
        text: &para.text,
        fallback_positions,
        scalar_styles: &projection.shaping_scalar_styles,
        hard_boundaries: &projection.hard_boundaries,
        fallback_owner,
        model_text_matches_shaping_text: composed_text == para.text,
        horizontal_ltr_bidi0: !has_rtl_or_bidi_control(&para.text),
        condense_min_space: para_style
            .map(|style| style.condense_min_space)
            .unwrap_or(0),
        has_inline_controls: !para.controls.is_empty(),
        has_tabs: para.text.contains('\t'),
        has_rotation: false,
        has_char_overlap,
    };
    let request = crate::renderer::shaping_paragraph::HorizontalShapingLineRequest {
        paragraph,
        candidate_boundaries: &candidate_boundaries,
        available_widths_px: &available_widths_px,
    };
    let outcome = if q2_candidate {
        let mut transaction = shaping_context.transaction();
        std::sync::Arc::new(
            crate::renderer::shaping_paragraph::run_horizontal_shaping_line_transaction(
                &mut transaction,
                &request,
            ),
        )
    } else {
        let line = composed.lines.first()?;
        let run = line.runs.first()?;
        if composed.lines.len() != 1
            || line.runs.len() != 1
            || line.has_line_break
            || line.char_start != 0
            || run.text != para.text
            || run.display_text.is_some()
        {
            return None;
        }
        let slot = projection.shaping_scalar_styles.first()?.slot;
        let mut transaction = shaping_context.explicit_instance_transaction(slot).ok()?;
        // An explicit default remains distinct in the request registry and
        // shaping cache, but must not widen the product activation surface.
        // Returning to the existing composer here preserves Q2 pixels and
        // geometry; only a canonical non-default instance may publish the
        // Q3-E portable pair.
        if transaction.is_default_instance() {
            return None;
        }
        if !crate::renderer::shaping_paragraph::is_bounded_explicit_instance_candidate_text(
            &para.text,
        ) {
            return None;
        }
        std::sync::Arc::new(
            crate::renderer::shaping_paragraph::run_bounded_explicit_instance_line_transaction(
                &mut transaction,
                &request,
            ),
        )
    };
    crate::renderer::shaping_composition::retain_qualified_horizontal_shaping_outcome(outcome)
}

fn apply_paragraph_kerning_to_tokens(
    tokens: &mut [BreakToken],
    measurement: &crate::renderer::kerning::KerningParagraphMeasurement,
) -> Option<()> {
    for token in tokens {
        let BreakToken::Text {
            start_idx,
            end_idx,
            width,
            char_widths,
            ..
        } = token
        else {
            continue;
        };
        *width = measurement.range_width(*start_idx, *end_idx)?;
        *char_widths = (*start_idx..*end_idx)
            .map(|index| measurement.range_width(index, index + 1))
            .collect::<Option<Vec<_>>>()?;
    }
    Some(())
}

/// px를 HWPUNIT(i32)로 변환 (내림, DPI=96 기준: px * 75)
///
#[inline]
fn to_hwp(px: f64) -> i32 {
    (px * 75.0) as i32
}

/// [#7418] 이 공백 앞에 같은 줄의 글자가 하나도 없는가 — 줄 맨 앞 공백.
///
/// 한/글은 줄 맨 앞 공백을 condense 로 줄이지 않는다. 문단 첫 줄의 들여 쓴 공백
/// 0·2·4·6 개를 condense 50·75 로 바꾼 합성 문단 8개의 줄 끊음을 한/글 2024 가
/// 저장한 줄과 맞대면, 맨 앞 공백을 줄이지 않는 모형만 8/8 로 맞는다(줄이는 모형 2/8).
fn space_is_line_leading(text_chars: &[char], line_start: usize, space_idx: usize) -> bool {
    text_chars
        .get(line_start..space_idx)
        .is_none_or(|before| before.iter().all(|c| *c == ' '))
}

/// 공백 하나를 condense 로 줄일 수 있는 폭. `space_width_hwp` 는 자간 **적용 전** 폭이다
/// (`BreakToken::Space::condense_base`).
fn condense_space_savings_hwp(space_width_hwp: i32, condense_min_space: u8) -> i32 {
    if condense_min_space == 0 || space_width_hwp <= 0 {
        return 0;
    }
    let shrink_percent = condense_min_space.min(75) as i32;
    space_width_hwp * shrink_percent / 100
}

fn condensed_line_width_hwp(width_hwp: i32, space_savings_hwp: i32) -> i32 {
    width_hwp - space_savings_hwp
}

/// Hancom absorbs the first overflowing blank at the end of the row, then
/// continues the remaining blanks on the next row (#7168). A visible inline
/// object at that offset must instead move with its space. Both fill paths use
/// this cut so ownership is not guessed separately during projection.
fn overflowing_space_cut(
    line_start: usize,
    space_idx: usize,
    width_hwp: i32,
    savings_hwp: i32,
    available_hwp: i32,
    has_inline_control: bool,
) -> Option<usize> {
    if condensed_line_width_hwp(width_hwp, savings_hwp) <= available_hwp {
        None
    } else if !has_inline_control {
        Some(space_idx + 1)
    } else if space_idx > line_start {
        Some(space_idx)
    } else {
        // Oversized first objects still belong to the object overflow policy.
        None
    }
}

// 한컴은 HWPUNIT 정수 양자화 시 미세한 반올림 차이를 허용한다.
// 이 값 이내의 초과는 줄에 포함한다.
//
// 15 는 실측보다 작았다. 한컴이 저장한 조판을 우리 폭 지표로 되재면, 한컴이 **받아들인**
// 줄들이 상자를 38·113·188 HWPUNIT 씩 넘는다(간격 75 HU = 1px — 줄 안 run 수에 따른
// 추정 오차 누적으로 보인다). 줄바꿈은 실제 글꼴이 아니라 엔진의 폭 **추정**으로 정해지므로
// 이 여유가 그 추정 오차를 흡수하는 자리다. 15 에서는 한컴이 담은 줄을 우리가 잘라
// 줄마다 마지막 글자가 밀렸다.
// 실측 스윕(재조판 ↔ 한컴 저장 조판 줄 단위 일치율): 15·40 → 65.0% / **50 → 82.3%** /
// 60~100 → 81.6% / 150 → 79.7% / 300 → 74.4%. 너무 키우면 반대로 과하게 담는다.
//
// 🔴 그 50 은 **본문 폭 38,640 HWPUNIT 짜리 줄에서 잰 값**이다. 오차가 줄 안 run 수를 따라
// 쌓이는 것이므로 여유도 상자 폭에 비례해야 한다. 상수로 두면 폭이 14배 좁은 표 칸
// (2,720 HU)에서 글자 폭의 5.5% 나 되는 **진짜 초과**까지 삼켜, 한컴이 두 줄로 쪼개는 문단이
// 한 줄로 남는다(셀 안 여백을 키운 뒤 재조판). 하한 15 는 종전 상수값이라 어떤 상자도
// 그보다 빡빡해지지 않는다.
const LINE_BREAK_TOLERANCE_MIN_HWP: i32 = 15;
const LINE_BREAK_TOLERANCE_MAX_HWP: i32 = 50;
/// 여유 1 HWPUNIT 당 상자 폭 — 38,640 / 50 ≈ 760.
const LINE_BREAK_TOLERANCE_WIDTH_PER_HWP: i32 = 760;

/// 상자 폭에 비례하는 줄바꿈 여유(HWPUNIT).
#[inline]
fn line_break_tolerance_hwp(box_width_hwp: i32) -> i32 {
    (box_width_hwp.max(0) / LINE_BREAK_TOLERANCE_WIDTH_PER_HWP)
        .clamp(LINE_BREAK_TOLERANCE_MIN_HWP, LINE_BREAK_TOLERANCE_MAX_HWP)
}

/// 이 토큰이 줄 안에서 **새 낱말을 시작**하면, 그 앞 공백들 직전까지의 자연폭.
///
/// 바로 앞 토큰이 이 줄의 공백이 아니면 이어지는 글자이므로 `None` 이다.
/// 이월(#3822) 재확인처럼 채움 상태가 없는 자리에서 토큰으로 다시 계산한다.
fn new_word_natural_before_hwp(
    tokens: &[BreakToken],
    token_idx: usize,
    line_start: usize,
) -> Option<i32> {
    new_word_natural_before_with_units_hwp(tokens, token_idx, line_start, false)
}

fn new_word_natural_before_with_units_hwp(
    tokens: &[BreakToken], token_idx: usize, line_start: usize, integral: bool,
) -> Option<i32> {
    let mut k = token_idx;
    while k > 0 {
        match &tokens[k - 1] {
            BreakToken::Space { idx, .. } if *idx >= line_start => k -= 1,
            _ => break,
        }
    }
    if k == token_idx {
        return None;
    }
    let width = recalc_width_with_units_hwp(tokens, k, line_start, integral);
    (width > 0).then_some(width)
}

/// Letter spacing is excluded from the fit test and included in the pen.
///
/// The pen already carries every earlier glyph's letter spacing. The fit
/// comparison omits only the candidate token's trailing letter space—one per
/// candidate, not one per character.
///
/// Dropping it from every character instead — the reading a summary of this
/// divergence invites — is arithmetically the single-shape blindness of
/// `compose_lines`' NO_LS fallback, which measures a paragraph with
/// `char_shapes[0]`'s spacing throughout. Measured, it reproduced the retired
/// cell wrap character for character against Hancom's own PDF and cost 12 tests
/// across six unrelated fixture families. At this stage the suite is unchanged.
///
/// Negative spacing is legal, so the sign is not fixed. For non-negative 자간
/// the candidate becomes narrower; under compressed 자간 the omission makes
/// the candidate wider and the fit stricter (`76076_regulatory_analysis` runs
/// `-0.16…-1.76` px).
/// Forced to 0 under an active character grid, which is inert here: every
/// corpus section has `char_grid == 0`.
/// [#7418] 이 글자 모양의 ASCII 구두점을 영문 슬롯으로 재는가
/// ([`ResolvedCharStyle::ascii_punct_latin_slot`]).
///
/// [`ResolvedCharStyle::ascii_punct_latin_slot`]: crate::renderer::style_resolver::ResolvedCharStyle::ascii_punct_latin_slot
fn punct_latin_slot(styles: &ResolvedStyleSet, style_id: u32) -> bool {
    styles
        .char_styles
        .get(style_id as usize)
        .is_some_and(|style| style.ascii_punct_latin_slot)
}

fn fit_test_letter_spacing_trim_hwp(letter_spacing_px: &[f64], token_end_idx: usize) -> i32 {
    if token_end_idx == 0 {
        return 0;
    }
    letter_spacing_px
        .get(token_end_idx - 1)
        .map(|spacing| to_hwp(*spacing))
        .unwrap_or(0)
}

/// Resolved per-character letter spacing in px, indexed by character position.
///
/// The fill needs the candidate glyph's own spacing at the moment it tests a
/// token, and the token carries only a total width, so it is resolved once for
/// the paragraph rather than re-derived per test.
fn resolved_letter_spacing_px(
    text_chars: &[char],
    char_offsets: &[u32],
    char_shapes: &[CharShapeRef],
    styles: &ResolvedStyleSet,
) -> Vec<f64> {
    let mut lang = 0usize;
    text_chars
        .iter()
        .enumerate()
        .map(|(idx, ch)| {
            let utf16_pos = char_offsets.get(idx).copied().unwrap_or(idx as u32);
            let style_id = find_active_char_shape(char_shapes, utf16_pos);
            // [#7418] 영문 슬롯으로 재는 구두점은 자간도 영문 슬롯 값이다(`char_width_decision`).
            let char_lang = char_lang_slot(*ch, &mut lang, punct_latin_slot(styles, style_id));
            // [#5678] `TextStyle` 을 통째로 만들지 않고 자간만 읽는다.
            resolved_letter_spacing(styles, style_id, char_lang)
        })
        .collect()
}

/// fit test 에 쓰는 후보 폭. 펜이 전진하는 폭과 **다른 값**이다.
///
/// [#5678] 종전에는 두 값이 다 `i32` 라 호출부가 아무거나 넘길 수 있었고, 실제로
/// 한 자리만 자간을 뺀 값을 넘겼다. 자간이 0 인 문단에서는 두 값이 같아 어떤 테스트도
/// 차이를 잡지 못했다. 이제 원시 정수는 이 함수에 들어가지 못하고, 호출부는 생성자
/// 이름으로 어느 쪽인지 밝혀야 한다.
///
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct FitWidthHwp(i32);

impl FitWidthHwp {
    /// 후보 토큰의 마지막 글자 뒤 자간을 뺀 폭. 실사용 fill 이 쓰는 값이다.
    ///
    /// 줄 끝에 오는 글자의 뒤 자간은 그려지지 않으므로 들어가는지 따질 때 빼고 잰다.
    /// 펜은 전체 폭만큼 전진한다.
    fn trimmed(token_width_hwp: i32, letter_spacing_px: &[f64], token_end_idx: usize) -> Self {
        Self(token_width_hwp - fit_test_letter_spacing_trim_hwp(letter_spacing_px, token_end_idx))
    }

    /// 커닝 경계쌍 보정을 fit 판정 폭에 더한다 (#4439 커닝 세션과의 병합점).
    /// 펜 전진 폭에는 더하지 않는다 — fit 판정 전용 축이다.
    fn with_pair_adjustment(self, adjustment_hwp: i32) -> Self {
        Self(self.0 + adjustment_hwp)
    }
}

/// [#7418] 목록 마커를 얹은 줄 나눔 상자: `(가용폭에서 뺄 양, 들여쓰기)`.
/// 마커가 없으면 문단 들여쓰기 그대로다.
fn list_marker_breaker_box(
    para: &Paragraph,
    styles: &ResolvedStyleSet,
    indent_px: f64,
) -> (f64, f64) {
    crate::renderer::layout::list_marker_geometry(para, styles)
        .map_or((0.0, indent_px), |geometry| geometry.breaker_box(indent_px))
}

/// 토큰이 줄에 들어가는가 — 문단 `condense`(공백 최소값) 규칙 포함.
///
/// [#7418] 한/글은 공백을 condense% 까지 줄여 **이미 시작한 낱말**의 글자를 더 담는다.
/// 그러나 **새 낱말은 앞 줄이 자연폭으로 상자보다 좁을 때만** 시작한다 — 이미 공백을
/// 줄여야 하거나 자연폭으로 꽉 찬 줄에는 새 낱말을 들이지 않는다.
/// `new_word_natural_before_hwp` 는 이 토큰이 새 낱말을 시작할 때 그 앞 공백 직전까지의
/// 자연폭이다(이어지는 글자면 `None`).
///
/// 독립 근거는 한/글 2024 출력이다. condense 0·15·30·50·75, 낱말 길이, 글자/낱말 단위,
/// 글꼴(맑은 고딕·함초롬바탕·한양신명조), 본문/표 칸을 바꾼 합성 문단의 줄 끊음을 이 규칙이
/// 전부 재현한다(본문 208/208, 칸 211/211). 앞 줄이 상자를 **꼭 채운** 경우를 허용하면(≤)
/// 칸 문단이 148/211 로 떨어진다. 종전의 "남은 틈 2.5em 이상일 때만 condense" 문턱은
/// 68/208 줄만 맞았다.
fn text_token_fits_line_hwp(
    current_width_hwp: i32,
    token_width: FitWidthHwp,
    space_savings_hwp: i32,
    effective_width_hwp: i32,
    new_word_natural_before_hwp: Option<i32>,
) -> bool {
    text_token_fits_in_line_with_tolerance_hwp(
        current_width_hwp,
        token_width,
        space_savings_hwp,
        effective_width_hwp,
        new_word_natural_before_hwp,
        line_break_tolerance_hwp(effective_width_hwp),
    )
}

fn text_token_fits_in_line_with_tolerance_hwp(
    current_width_hwp: i32,
    token_width: FitWidthHwp,
    space_savings_hwp: i32,
    effective_width_hwp: i32,
    new_word_natural_before_hwp: Option<i32>,
    tolerance_hwp: i32,
) -> bool {
    let natural_candidate = current_width_hwp + token_width.0;
    let condensed_candidate = condensed_line_width_hwp(natural_candidate, space_savings_hwp);
    let limit_hwp = effective_width_hwp + tolerance_hwp;
    if natural_candidate <= limit_hwp {
        return true;
    }
    // 공백을 줄여야 들어가는 경우 — 줄바꿈 여유(자연폭 추정 오차 흡수용)를 얹지 않는다.
    // 한/글은 줄인 폭이 상자를 넘으면 받지 않는다: 합성 문단에서 상자를 5·30 HWPUNIT
    // 넘는 줄(여유 50 안)과 80168 49쪽 `…투자ㆍ운` + `용`(여유 31 안)을 모두 거절한다.
    if condensed_candidate > effective_width_hwp {
        return false;
    }
    !new_word_natural_before_hwp.is_some_and(|w| w >= effective_width_hwp)
}

/// Greedy line-fill continuation.
///
/// A visible-text boundary does not always identify the next token: a long
/// `Text` token can continue after an emitted row. Keep the complete state so
/// callers can fill one interval at a time without rediscovering a boundary.
#[derive(Debug, Clone)]
struct FillCursor {
    token_index: usize,
    fallback_char_idx: Option<usize>,
    initial_start_idx: usize,
    line_start_idx: usize,
    lw: i32,
    line_space_savings: i32,
    line_max_fs: f64,
    is_first_line: bool,
    last_break_token_idx: Option<usize>,
    last_break_char_idx: usize,
    width_at_last_break: i32,
    space_savings_at_last_break: i32,
    fs_at_last_break: f64,
    /// [#7418] 마지막으로 소비한 토큰이 이 줄의 공백이면, 그 공백 묶음 직전까지의 자연폭.
    /// 다음 글자 토큰이 새 낱말을 시작하는지와 그때 줄이 자연폭 안인지를 판정한다.
    word_gap_natural_hwp: Option<i32>,
    /// 물리 프레임의 폭이 확정되면 추정 메트릭의 초과 허용을 얹지 않는다.
    allow_metric_tolerance: bool,
    integral_advances: bool,
    integral_interval_hwp: Option<i32>,
    finished: bool,
    emitted_any: bool,
}

impl FillCursor {
    fn new(initial_start_idx: usize, initial_is_first_line: bool) -> Self {
        Self {
            token_index: 0,
            fallback_char_idx: None,
            initial_start_idx,
            line_start_idx: initial_start_idx,
            lw: 0,
            line_space_savings: 0,
            line_max_fs: 0.0,
            is_first_line: initial_is_first_line,
            last_break_token_idx: None,
            last_break_char_idx: 0,
            width_at_last_break: 0,
            space_savings_at_last_break: 0,
            fs_at_last_break: 0.0,
            word_gap_natural_hwp: None,
            allow_metric_tolerance: true,
            integral_advances: false,
            integral_interval_hwp: None,
            finished: false,
            emitted_any: false,
        }
    }

    fn replay_from_boundary(tokens: &[BreakToken], boundary: usize, first_line: bool) -> Self {
        let mut cursor = Self::new(boundary, first_line);
        cursor.token_index = tokens.partition_point(|token| match token {
            BreakToken::Text { end_idx, .. } => *end_idx <= boundary,
            BreakToken::Space { idx, .. }
            | BreakToken::Tab { idx, .. }
            | BreakToken::LineBreak { idx } => *idx < boundary,
        });
        if let Some(BreakToken::Text { start_idx, .. }) = tokens.get(cursor.token_index) {
            if boundary > *start_idx {
                cursor.fallback_char_idx = Some(boundary);
            }
        }
        cursor
    }
}


/// Integer TTF advances may be consumed without the estimated-font allowance.
/// This is a measurement proof for every scalar, not a font-name shortcut.
/// Controls, authored condense, markers and any unproved scalar keep their
/// established fill owner and conversion rules.
fn paragraph_has_integral_gulimche_advances(
    para: &Paragraph,
    styles: &ResolvedStyleSet,
    space_metric: SpaceMetric,
) -> bool {
    if para.text.is_empty() || !para.controls.is_empty()
        || !styles.para_styles.get(para.para_shape_id as usize).is_some_and(|p|
            p.condense_min_space == 0 && p.head_type == HeadType::None
                && p.numbering_id == 0 && p.indent == 0.0)
    {
        return false;
    }
    let chars: Vec<_> = para.text.chars().collect();
    let metric_scope = ParagraphMetricScope::new(&chars, styles)
        .with_reflow_slots(&chars).with_space_metric(space_metric);
    let mut lang = 0;
    chars.iter().enumerate().all(|(index, &ch)| {
        let offset = para.char_offsets.get(index).copied().unwrap_or(index as u32);
        let id = find_active_char_shape(&para.char_shapes, offset);
        let slot = char_lang_slot(ch, &mut lang, punct_latin_slot(styles, id));
        let style = metric_scope.style(styles, id, slot, index);
        crate::renderer::layout::trace_char_width_decisions(&ch.to_string(), &style)
            .first().is_some_and(|d| d.integral_advance_hwp.is_some())
    })
}

/// Exact overflow proof for a horizontal BREAK cell. Unlike estimated-width
/// import heuristics, every scalar must have a positive owned integer advance.
/// Written line breaks, unknown glyphs, authored compression and alternate
/// wrap/fit policies cannot enter this lane. Trailing spaces do not prove an
/// overflow: the normal breaker may leave them outside the physical interval.
/// The caller supplies the current paragraph box, not a cached width guess.
pub(crate) fn owned_break_cell_row_overflows(
    para: &Paragraph,
    paragraph_box: &ParagraphBox,
    styles: &ResolvedStyleSet,
) -> bool {
    if !paragraph_box.is_usable() || para.line_segs.len() < 2
        || para.hwpx_axis_shift != 0
        || !para.range_tags.is_empty() || !para.field_ranges.is_empty()
        || !para.orphan_field_ends.is_empty() || !para.tab_extended.is_empty()
        || !paragraph_has_integral_gulimche_advances(para, styles, SpaceMetric::Stored)
        || !styles.para_styles.get(para.para_shape_id as usize).is_some_and(|p|
            p.cached_scalar_fit_supported && p.alignment == Alignment::Justify && p.korean_break_unit == 1
                && p.margin_left == 0.0 && p.margin_right == 0.0)
    { return false; }
    let chars: Vec<_> = para.text.chars().collect();
    // Manual clipped leaders have their own existing paint policy. Their
    // repeated dots are not evidence that an ordinary source row is stale.
    if !super::leader_fill_spans(&chars).is_empty() { return false; }
    // This measurement contract owns BMP scalar intervals only. A malformed
    // native/raw offset table must not be silently converted into another axis.
    if para.char_offsets.len() != chars.len()
        || para.char_offsets.iter().enumerate().any(|(i, &offset)| offset != i as u32)
        || chars.iter().any(|c| c.is_control() || *c == '\u{fffc}')
        || para.line_segs[0].text_start != 0
        || para.line_segs.windows(2).any(|r| r[0].text_start >= r[1].text_start
            || r[1].text_start as usize >= chars.len() || r[0].vertical_pos >= r[1].vertical_pos)
        || para.line_segs.iter().any(|row|
            row.segment_width != paragraph_box.width_hwp() || row.column_start != 0
                || row.line_height <= 0 || row.text_height <= 0
                || row.tag & LineSeg::TAG_IMPLEMENTATION_PROPERTY != 0)
    { return false; }
    let scope = ParagraphMetricScope::new(&chars, styles)
        .with_reflow_slots(&chars).with_space_metric(SpaceMetric::Stored);
    let mut lang = 0;
    let mut widths = Vec::with_capacity(chars.len());
    for (i, &ch) in chars.iter().enumerate() {
        let id = find_active_char_shape(&para.char_shapes, i as u32);
        let slot = char_lang_slot(ch, &mut lang, punct_latin_slot(styles, id));
        let style = scope.style(styles, id, slot, i);
        let Some(width) = crate::renderer::layout::trace_char_width_decisions(&ch.to_string(), &style)
            .first().and_then(|d| d.integral_advance_hwp).filter(|&w| w > 0)
        else { return false; };
        widths.push(i64::from(width));
    }
    para.line_segs.windows(2).any(|pair| {
        let start = pair[0].text_start as usize;
        let end = pair[1].text_start as usize;
        if start >= end || end > chars.len() { return false; }
        let trimmed = (start..end).rev().find(|&i| chars[i] != ' ').map(|i| i + 1).unwrap_or(start);
        // BREAK mode uses the ordinary token fit policy: closing punctuation
        // is part of the fit token, not an unbounded hanging-glyph exception.
        widths[start..trimmed].iter().sum::<i64>() > i64::from(pair[0].segment_width)
    })
}

/// Restore the integer sum of proven glyph advances transported through px.
/// The interval budget is never recovered from a float: ParagraphBox / Frame
/// supply their original integer extent separately.
fn fill_units_hwp(px: f64, integral: bool) -> i32 {
    if integral { (px * 75.0).round() as i32 } else { to_hwp(px) }
}

/// Fill all scalar intervals through the resumable greedy continuation.
fn fill_lines(
    tokens: &[BreakToken],
    text_chars: &[char],
    available_width_px: f64,
    indent_px: f64,
    default_tab_width: f64,
    korean_break_unit: u8,
    condense_min_space: u8,
    letter_spacing_px: &[f64],
    initial_start_idx: usize,
    initial_is_first_line: bool,
    integral_width_hwp: Option<i32>,
    mut kerning: Option<&mut crate::renderer::kerning::KerningParagraphBreakSession<'_, '_, '_>>,
) -> Vec<LineBreakResult> {
    let mut cursor = FillCursor::new(initial_start_idx, initial_is_first_line);
    cursor.integral_advances = integral_width_hwp.is_some();
    cursor.integral_interval_hwp = integral_width_hwp;
    cursor.allow_metric_tolerance = !cursor.integral_advances;
    let mut results = Vec::new();

    while let Some(interval) = fill_one_interval(
        tokens,
        text_chars,
        available_width_px,
        indent_px,
        default_tab_width,
        korean_break_unit,
        condense_min_space,
        letter_spacing_px,
        &mut cursor,
        kerning.as_deref_mut(),
    ) {
        results.push(interval.line);
    }

    results
}

/// Fill at most one logical row and retain the greedy continuation state.
fn fill_one_interval(
    tokens: &[BreakToken],
    text_chars: &[char],
    available_width_px: f64,
    indent_px: f64,
    default_tab_width: f64,
    korean_break_unit: u8,
    condense_min_space: u8,
    letter_spacing_px: &[f64],
    cursor: &mut FillCursor,
    mut kerning: Option<&mut crate::renderer::kerning::KerningParagraphBreakSession<'_, '_, '_>>,
) -> Option<FilledInterval> {
    let allow_metric_tolerance = cursor.allow_metric_tolerance;
    let integral = cursor.integral_advances;
    let to_fill_hwp = |px| fill_units_hwp(px, integral);
    let fits_physical_line = |current, token, savings, width, word| {
        text_token_fits_in_line_with_tolerance_hwp(
            current,
            token,
            savings,
            width,
            word,
            if allow_metric_tolerance {
                line_break_tolerance_hwp(width)
            } else {
                0
            },
        )
    };
    if cursor.finished {
        return None;
    }

    if tokens.is_empty() {
        cursor.finished = true;
        cursor.emitted_any = true;
        return Some(FilledInterval {
            line: LineBreakResult {
                start_idx: cursor.initial_start_idx,
                end_idx: cursor.initial_start_idx,
                max_font_size: 0.0,
                has_line_break: false,
            },
            termination: FillTermination::ParagraphEnd,
        });
    }

    let tab_w_px = if default_tab_width > 0.0 {
        default_tab_width
    } else {
        48.0
    };
    let eff_w = |first: bool| -> i32 {
        if integral {
            // The proof excludes paragraph indentation and list markers.
            // Use the very interval extent the frame / edit box owns.
            if let Some(width) = cursor.integral_interval_hwp {
                return width;
            }
        }
        if indent_px > 0.0 {
            if first {
                to_fill_hwp((available_width_px - indent_px).max(1.0))
            } else {
                to_fill_hwp(available_width_px)
            }
        } else if indent_px < 0.0 {
            if first {
                to_fill_hwp(available_width_px)
            } else {
                to_fill_hwp((available_width_px + indent_px).max(1.0))
            }
        } else {
            to_fill_hwp(available_width_px)
        }
    };

    loop {
        if cursor.token_index >= tokens.len() {
            cursor.finished = true;
            let last_end = tokens
                .last()
                .map(|token| match token {
                    BreakToken::Text { end_idx, .. } => *end_idx,
                    BreakToken::Space { idx, .. }
                    | BreakToken::Tab { idx, .. }
                    | BreakToken::LineBreak { idx } => *idx + 1,
                })
                .unwrap_or(text_chars.len());

            if cursor.line_start_idx <= last_end {
                cursor.emitted_any = true;
                return Some(FilledInterval {
                    line: LineBreakResult {
                        start_idx: cursor.line_start_idx,
                        end_idx: last_end,
                        max_font_size: cursor.line_max_fs,
                        has_line_break: false,
                    },
                    termination: FillTermination::ParagraphEnd,
                });
            }

            if !cursor.emitted_any {
                cursor.emitted_any = true;
                return Some(FilledInterval {
                    line: LineBreakResult {
                        start_idx: cursor.initial_start_idx,
                        end_idx: text_chars.len(),
                        max_font_size: 0.0,
                        has_line_break: false,
                    },
                    termination: FillTermination::ParagraphEnd,
                });
            }
            return None;
        }

        let ti = cursor.token_index;
        match &tokens[ti] {
            BreakToken::LineBreak { idx } => {
                let result = LineBreakResult {
                    start_idx: cursor.line_start_idx,
                    end_idx: *idx + 1,
                    max_font_size: cursor.line_max_fs,
                    has_line_break: true,
                };
                cursor.line_start_idx = *idx + 1;
                cursor.lw = 0;
                cursor.line_space_savings = 0;
                cursor.line_max_fs = 0.0;
                cursor.is_first_line = false;
                cursor.last_break_token_idx = None;
                cursor.token_index += 1;
                cursor.emitted_any = true;
                return Some(FilledInterval {
                    line: result,
                    termination: FillTermination::ForcedBreak,
                });
            }
            BreakToken::Tab { idx, max_font_size } => {
                cursor.word_gap_natural_hwp = None;
                // 탭 계산은 px로 수행 후 HWPUNIT 변환 (정밀도 유지)
                let lw_px = cursor.lw as f64 / 75.0;
                let next_tab_px = ((lw_px / tab_w_px).floor() + 1.0) * tab_w_px;
                let next_tab_hwp = to_fill_hwp(next_tab_px);
                if *max_font_size > cursor.line_max_fs {
                    cursor.line_max_fs = *max_font_size;
                }

                if next_tab_hwp > eff_w(cursor.is_first_line) && cursor.line_start_idx < *idx {
                    let result = if cursor.last_break_token_idx.is_some() {
                        let result = LineBreakResult {
                            start_idx: cursor.line_start_idx,
                            end_idx: cursor.last_break_char_idx,
                            max_font_size: cursor.fs_at_last_break,
                            has_line_break: false,
                        };
                        cursor.line_start_idx = cursor.last_break_char_idx;
                        cursor.lw -= cursor.width_at_last_break;
                        cursor.line_space_savings -= cursor.space_savings_at_last_break;
                        result
                    } else {
                        let result = LineBreakResult {
                            start_idx: cursor.line_start_idx,
                            end_idx: *idx,
                            max_font_size: cursor.line_max_fs,
                            has_line_break: false,
                        };
                        cursor.line_start_idx = *idx;
                        cursor.lw = 0;
                        cursor.line_space_savings = 0;
                        cursor.line_max_fs = *max_font_size;
                        result
                    };
                    cursor.is_first_line = false;
                    cursor.last_break_token_idx = None;
                    let lw_px2 = cursor.lw as f64 / 75.0;
                    let next_tab2 = ((lw_px2 / tab_w_px).floor() + 1.0) * tab_w_px;
                    cursor.lw = to_fill_hwp(next_tab2);
                    cursor.token_index += 1;
                    cursor.emitted_any = true;
                    return Some(FilledInterval {
                        line: result,
                        termination: FillTermination::IntervalFull,
                    });
                }

                cursor.last_break_token_idx = Some(ti);
                cursor.last_break_char_idx = *idx;
                cursor.width_at_last_break = cursor.lw;
                cursor.space_savings_at_last_break = cursor.line_space_savings;
                cursor.fs_at_last_break = cursor.line_max_fs;
                cursor.lw = next_tab_hwp;
                cursor.token_index += 1;
            }
            BreakToken::Space {
                idx,
                width,
                condense_base,
                max_font_size,
                has_inline_control,
            } => {
                let previous_line_max_fs = cursor.line_max_fs;
                if *max_font_size > cursor.line_max_fs {
                    cursor.line_max_fs = *max_font_size;
                }
                let space_hwp = to_fill_hwp(*width);
                // [#7418] 줄 맨 앞 공백은 condense 로 줄지 않는다.
                let leading = space_is_line_leading(text_chars, cursor.line_start_idx, *idx);
                let space_savings = if leading {
                    0
                } else {
                    condense_space_savings_hwp(to_fill_hwp(*condense_base), condense_min_space)
                };
                if let Some(cut) = overflowing_space_cut(
                    cursor.line_start_idx,
                    *idx,
                    cursor.lw + space_hwp,
                    cursor.line_space_savings + space_savings,
                    eff_w(cursor.is_first_line),
                    *has_inline_control,
                ) {
                    let absorbed = cut > *idx;
                    // [#7418] 줄 끝에 건 공백이 문단의 마지막 글자면 문단이 여기서 끝난다 —
                    // 종전에는 글자 없는 빈 행을 하나 더 게시했다. 한/글은 넘친 공백 **하나**만
                    // 줄 끝에 걸고 그 뒤 공백은 새 줄로 넘긴다(42자+공백 2 → 1줄, 공백 3 → 2줄;
                    // `trailing_space_synthetic`). 그래서 뒤에 공백이 더 남은 경우는 종전대로 끊는다.
                    if absorbed && ti + 1 == tokens.len() {
                        cursor.finished = true;
                        cursor.emitted_any = true;
                        cursor.token_index = tokens.len();
                        return Some(FilledInterval {
                            line: LineBreakResult {
                                start_idx: cursor.line_start_idx,
                                end_idx: cut,
                                max_font_size: cursor.line_max_fs,
                                has_line_break: false,
                            },
                            termination: FillTermination::ParagraphEnd,
                        });
                    }
                    let line = LineBreakResult {
                        start_idx: cursor.line_start_idx,
                        end_idx: cut,
                        max_font_size: if absorbed {
                            cursor.line_max_fs
                        } else {
                            previous_line_max_fs
                        },
                        has_line_break: false,
                    };
                    cursor.line_start_idx = cut;
                    cursor.lw = if absorbed { 0 } else { space_hwp };
                    // 넘어간 공백은 새 줄의 맨 앞 공백이다.
                    cursor.line_space_savings = 0;
                    cursor.line_max_fs = if absorbed { 0.0 } else { *max_font_size };
                    cursor.is_first_line = false;
                    cursor.last_break_token_idx = None;
                    cursor.word_gap_natural_hwp = None;
                    cursor.token_index += 1;
                    cursor.emitted_any = true;
                    // The terminal separator was consumed by this row. The
                    // cursor is at paragraph end, not at a new empty line.
                    // An authored final LineBreak follows its separate path.
                    let at_end = absorbed && cursor.token_index == tokens.len();
                    cursor.finished = at_end;
                    return Some(FilledInterval {
                        line,
                        termination: if at_end {
                            FillTermination::ParagraphEnd
                        } else {
                            FillTermination::IntervalFull
                        },
                    });
                }
                cursor.last_break_token_idx = Some(ti);
                cursor.last_break_char_idx = *idx;
                cursor.width_at_last_break = cursor.lw;
                cursor.space_savings_at_last_break = cursor.line_space_savings;
                cursor.fs_at_last_break = cursor.line_max_fs;
                if cursor.word_gap_natural_hwp.is_none() && !leading {
                    cursor.word_gap_natural_hwp = Some(cursor.lw);
                }
                cursor.lw += space_hwp;
                cursor.line_space_savings += space_savings;
                cursor.token_index += 1;
            }
            BreakToken::Text {
                start_idx,
                end_idx,
                base_width,
                max_font_size,
                base_char_widths,
                ..
            } => {
                // [#7418] 바로 앞이 이 줄의 공백이었으면 이 토큰이 새 낱말을 시작한다.
                let new_word_natural = cursor
                    .word_gap_natural_hwp
                    .take()
                    .filter(|_| *start_idx > cursor.line_start_idx);
                if let Some(next_char_idx) = cursor.fallback_char_idx {
                    debug_assert!(*start_idx <= next_char_idx && next_char_idx <= *end_idx);
                    let mut ci = next_char_idx;
                    while ci < *end_idx {
                        let rel_idx = ci - *start_idx;
                        let char_w = base_char_widths
                            .get(rel_idx)
                            .map(|width| to_fill_hwp(*width))
                            .unwrap_or_else(|| {
                                let ch = text_chars[ci];
                                let char_w_px = if is_cjk_char(ch) {
                                    cursor.line_max_fs.max(12.0)
                                } else {
                                    cursor.line_max_fs.max(12.0) * 0.5
                                };
                                to_fill_hwp(char_w_px)
                            });
                        let current_width = eff_w(cursor.is_first_line);
                        let candidate_base = cursor.lw + char_w;
                        let candidate_width = if let Some(session) = kerning.as_deref_mut() {
                            candidate_base
                                + to_fill_hwp(
                                    session
                                        .boundary_pair_adjustment(cursor.line_start_idx, ci + 1)?,
                                )
                        } else {
                            candidate_base
                        };
                        if candidate_width > current_width && ci > cursor.line_start_idx {
                            let result = LineBreakResult {
                                start_idx: cursor.line_start_idx,
                                end_idx: ci,
                                max_font_size: cursor.line_max_fs,
                                has_line_break: false,
                            };
                            cursor.line_start_idx = ci;
                            cursor.lw = char_w;
                            cursor.is_first_line = false;
                            cursor.fallback_char_idx = Some(ci + 1);
                            cursor.emitted_any = true;
                            return Some(FilledInterval {
                                line: result,
                                termination: FillTermination::IntervalFull,
                            });
                        }
                        cursor.lw += char_w;
                        ci += 1;
                    }
                    cursor.fallback_char_idx = None;
                    cursor.token_index += 1;
                    continue;
                }

                if break_before_hangul_char(
                    text_chars,
                    *start_idx,
                    cursor.line_start_idx,
                    korean_break_unit,
                ) {
                    cursor.last_break_token_idx = Some(ti - 1);
                    cursor.last_break_char_idx = *start_idx;
                    cursor.width_at_last_break = cursor.lw;
                    cursor.space_savings_at_last_break = cursor.line_space_savings;
                    cursor.fs_at_last_break = cursor.line_max_fs;
                }
                if *max_font_size > cursor.line_max_fs {
                    cursor.line_max_fs = *max_font_size;
                }

                let w_hwp = to_fill_hwp(*base_width);
                let effective_width = eff_w(cursor.is_first_line);
                // 전진폭은 유지하며 일반 자동 줄 경계 비교에서만 후보의 끝 자간을 뺀다.
                // 작성된 줄바꿈 또는 문단 끝의 압축 자간은 전진폭으로 판정한다.
                // 음수 자간을 되돌리면 이미 상자 안에 담긴 마지막 글자만 다음 줄로
                // 밀리고 작성된 줄바꿈 앞에 빈약한 추가 줄이 생긴다. 실제 전진폭
                // 초과와 일반 자동 줄바꿈의 마지막 자간 판정은 그대로 검사한다.
                let at_written_line_end = matches!(
                    tokens.get(ti + 1),
                    None | Some(BreakToken::LineBreak { .. })
                );
                let w_hwp_fit = if at_written_line_end
                    && fit_test_letter_spacing_trim_hwp(letter_spacing_px, *end_idx) < 0
                {
                    FitWidthHwp(w_hwp)
                } else {
                    FitWidthHwp::trimmed(w_hwp, letter_spacing_px, *end_idx)
                };
                let pair_adjustment_hwp = if let Some(session) = kerning.as_deref_mut() {
                    to_fill_hwp(session.boundary_pair_adjustment(cursor.line_start_idx, *end_idx)?)
                } else {
                    0
                };
                let token_fits = fits_physical_line(
                    cursor.lw,
                    w_hwp_fit.with_pair_adjustment(pair_adjustment_hwp),
                    cursor.line_space_savings,
                    effective_width,
                    new_word_natural,
                );

                // 단일 문자 CJK/한글 토큰의 줄바꿈 가능 지점 처리
                // 이 글자를 포함한 후 break point 갱신 (end_idx 사용)
                // → 초과 시 이 글자까지 L0에 포함하고 다음 토큰부터 다음 줄
                //
                // **One predicate governs.** This used to ask its own question —
                // the condensed width against the box, without
                // `condense_pull_allowed` — so a glyph the fit test refused could
                // still be registered as a legal line end, and the emitted row
                // runs to the registered point, which put the refused glyph on
                // the line anyway. Measured on `76076_regulatory_analysis` p81
                // (`직접비용 근거설명`, box 36572 HWPUNIT): the fit test refuses
                // at pen 35566 + 1400 = 36966 > 36572, while the recorder
                // admitted the same glyph on 36966 − 980 = 35708 ≤ 36587. Sharing
                // `text_token_fits_line_hwp` makes all six rows of that cell
                // character-identical to the HWP 2024 PDF.
                let tail_all_line_start_forbidden = text_chars[*start_idx + 1..*end_idx]
                    .iter()
                    .all(|c| is_line_start_forbidden(*c));
                if tail_all_line_start_forbidden && *start_idx > cursor.line_start_idx && token_fits
                {
                    // 글자 모드의 후행 금칙 흡수분도 같은 "줄 끝 자리"로 본다.
                    //
                    // 한컴은 줄 끝 금칙 문자를 상자 밖에 매달지 않고 **그 줄 안에** 넣는다
                    // (실측: 정렬줄 중 금칙으로 끝나는 21줄 전부가 상자 안, 줄머리 금칙 0건).
                    // 종전 `== 1` 가드는 흡수가 만든 2글자 묶음(`력·`)을 폭 판정에 통과하고도
                    // 줄 끝 후보에서 배제해, 줄이 묶음 **앞** 한 글자로 되감겼다 — 원본이
                    // `…상호 협력·` 로 끝내는 자리에서 우리는 `…상호 협` 으로 끝나 두 글자를 잃었다.
                    // 1글자 토큰은 아래 슬라이스가 비어 `all()` 이 참이라 종전 동작 그대로다.
                    let c = text_chars[*start_idx];
                    let allow_break = if is_hangul(c) {
                        // [#2185] bit7=1 = 글자 단위 break 허용 (위 주석 참조)
                        korean_break_unit == 1
                    } else {
                        is_cjk_ideograph(c)
                    };
                    if allow_break {
                        cursor.last_break_token_idx = Some(ti);
                        cursor.last_break_char_idx = *end_idx; // 이 글자 다음 (이 글자 포함)
                        cursor.width_at_last_break = cursor.lw + w_hwp; // 이 글자 폭 포함
                        cursor.space_savings_at_last_break = cursor.line_space_savings;
                        cursor.fs_at_last_break = cursor.line_max_fs;
                    }
                }
                if !token_fits {
                    if *start_idx > cursor.line_start_idx {
                        if let Some(break_token_idx) = cursor.last_break_token_idx {
                            let result = LineBreakResult {
                                start_idx: cursor.line_start_idx,
                                end_idx: cursor.last_break_char_idx,
                                max_font_size: cursor.fs_at_last_break,
                                has_line_break: false,
                            };
                            let mut next_start = cursor.last_break_char_idx;
                            while next_start < text_chars.len() && text_chars[next_start] == ' ' {
                                next_start += 1;
                            }
                            cursor.line_start_idx = next_start;
                            cursor.lw = recalc_width_with_units_hwp(tokens, ti, next_start, integral);
                            cursor.line_space_savings = recalc_space_savings_hwp(
                                tokens,
                                ti,
                                next_start,
                                condense_min_space,
                            );
                            cursor.line_max_fs = *max_font_size;
                            cursor.is_first_line = false;
                            cursor.last_break_token_idx = None;

                            // 현재 단일 CJK/한글 토큰 자체가 break point였던 기존 경로는
                            // 이미 위 결과에 포함됐으므로 동작을 바꾸지 않는다.
                            if break_token_idx == ti {
                                cursor.lw += w_hwp;
                                cursor.token_index += 1;
                                cursor.emitted_any = true;
                                return Some(FilledInterval {
                                    line: result,
                                    termination: FillTermination::IntervalFull,
                                });
                            }

                            // [#3822] 이전 break 뒤로 옮긴 현재 토큰이 새 줄에도
                            // 들어가는지 다시 확인한다. 종전에는 토큰 전체 폭을 무조건
                            // 더하고 continue하여, 긴 영문·숫자 토큰의 글자 단위 fallback을
                            // 건너뛰었다.
                            // [#5678] 주 판정과 같은 피연산자(`w_hwp_fit`)를 쓴다. 종전에는
                            // 이 자리만 `w_hwp` 를 넘겨, 같은 토큰이 한 반복 안에서 두 방식으로
                            // 측정됐다 — 자간이 0 이 아닌 문단에서만 갈리므로 어떤 테스트도
                            // 이 차이를 잡지 못했다. 펜은 여기서도 전체 폭을 그대로 전진한다.
                            if fits_physical_line(
                                cursor.lw,
                                w_hwp_fit.with_pair_adjustment(
                                    if let Some(session) = kerning.as_deref_mut() {
                                        to_fill_hwp(session.boundary_pair_adjustment(
                                            cursor.line_start_idx,
                                            *end_idx,
                                        )?)
                                    } else {
                                        0
                                    },
                                ),
                                cursor.line_space_savings,
                                eff_w(false),
                                new_word_natural_before_with_units_hwp(tokens, ti, cursor.line_start_idx, integral),
                            ) {
                                cursor.lw += w_hwp;
                                cursor.token_index += 1;
                                cursor.emitted_any = true;
                                return Some(FilledInterval {
                                    line: result,
                                    termination: FillTermination::IntervalFull,
                                });
                            }

                            cursor.line_space_savings = 0;
                            cursor.last_break_token_idx = None;
                            cursor.fallback_char_idx = Some(*start_idx);
                            cursor.emitted_any = true;
                            return Some(FilledInterval {
                                line: result,
                                termination: FillTermination::IntervalFull,
                            });
                        }
                    }

                    // 토큰에 저장된 개별 글자 폭을 HWPUNIT로 변환
                    cursor.line_space_savings = 0;
                    cursor.last_break_token_idx = None;
                    cursor.fallback_char_idx = Some(*start_idx);
                    continue;
                }

                cursor.lw += w_hwp;
                cursor.token_index += 1;
            }
        }
    }
}

/// Frozen scalar implementation used only to prove cursor equivalence.
#[cfg(test)]
fn fill_lines_before_cursor(
    tokens: &[BreakToken],
    text_chars: &[char],
    available_width_px: f64,
    indent_px: f64,
    default_tab_width: f64,
    korean_break_unit: u8,
    condense_min_space: u8,
    initial_start_idx: usize,
    initial_is_first_line: bool,
) -> Vec<LineBreakResult> {
    if tokens.is_empty() {
        return vec![LineBreakResult {
            start_idx: initial_start_idx,
            end_idx: initial_start_idx,
            max_font_size: 0.0,
            has_line_break: false,
        }];
    }

    let tab_w_hwp = to_hwp(if default_tab_width > 0.0 {
        default_tab_width
    } else {
        48.0
    });
    let tab_w_px = if default_tab_width > 0.0 {
        default_tab_width
    } else {
        48.0
    };
    let mut results = Vec::new();
    let mut line_start_idx = initial_start_idx;
    let mut lw = 0i32; // HWPUNIT 정수 누적
    let mut line_space_savings = 0i32;
    let mut line_max_fs = 0.0f64;
    let mut is_first_line = initial_is_first_line;

    let mut last_break_token_idx: Option<usize> = None;
    let mut last_break_char_idx: usize = 0;
    let mut width_at_last_break = 0i32;
    let mut space_savings_at_last_break = 0i32;
    let mut fs_at_last_break = 0.0f64;

    let eff_w = |first: bool| -> i32 {
        if indent_px > 0.0 {
            if first {
                to_hwp((available_width_px - indent_px).max(1.0))
            } else {
                to_hwp(available_width_px)
            }
        } else if indent_px < 0.0 {
            if first {
                to_hwp(available_width_px)
            } else {
                to_hwp((available_width_px + indent_px).max(1.0))
            }
        } else {
            to_hwp(available_width_px)
        }
    };

    for (ti, token) in tokens.iter().enumerate() {
        match token {
            BreakToken::LineBreak { idx } => {
                results.push(LineBreakResult {
                    start_idx: line_start_idx,
                    end_idx: *idx + 1,
                    max_font_size: line_max_fs,
                    has_line_break: true,
                });
                line_start_idx = *idx + 1;
                lw = 0;
                line_space_savings = 0;
                line_max_fs = 0.0;
                is_first_line = false;
                last_break_token_idx = None;
            }
            BreakToken::Tab { idx, max_font_size } => {
                // 탭 계산은 px로 수행 후 HWPUNIT 변환 (정밀도 유지)
                let lw_px = lw as f64 / 75.0;
                let next_tab_px = ((lw_px / tab_w_px).floor() + 1.0) * tab_w_px;
                let next_tab_hwp = to_hwp(next_tab_px);
                if *max_font_size > line_max_fs {
                    line_max_fs = *max_font_size;
                }

                if next_tab_hwp > eff_w(is_first_line) && line_start_idx < *idx {
                    if let Some(_) = last_break_token_idx {
                        results.push(LineBreakResult {
                            start_idx: line_start_idx,
                            end_idx: last_break_char_idx,
                            max_font_size: fs_at_last_break,
                            has_line_break: false,
                        });
                        line_start_idx = last_break_char_idx;
                        lw = lw - width_at_last_break;
                        line_space_savings -= space_savings_at_last_break;
                    } else {
                        results.push(LineBreakResult {
                            start_idx: line_start_idx,
                            end_idx: *idx,
                            max_font_size: line_max_fs,
                            has_line_break: false,
                        });
                        line_start_idx = *idx;
                        lw = 0;
                        line_space_savings = 0;
                        line_max_fs = *max_font_size;
                    }
                    is_first_line = false;
                    last_break_token_idx = None;
                    let lw_px2 = lw as f64 / 75.0;
                    let next_tab2 = ((lw_px2 / tab_w_px).floor() + 1.0) * tab_w_px;
                    lw = to_hwp(next_tab2);
                } else {
                    last_break_token_idx = Some(ti);
                    last_break_char_idx = *idx;
                    width_at_last_break = lw;
                    space_savings_at_last_break = line_space_savings;
                    fs_at_last_break = line_max_fs;
                    lw = next_tab_hwp;
                }
            }
            BreakToken::Space {
                idx,
                width,
                condense_base,
                max_font_size,
                ..
            } => {
                if *max_font_size > line_max_fs {
                    line_max_fs = *max_font_size;
                }
                last_break_token_idx = Some(ti);
                last_break_char_idx = *idx;
                width_at_last_break = lw;
                space_savings_at_last_break = line_space_savings;
                fs_at_last_break = line_max_fs;
                let space_hwp = to_hwp(*width);
                lw += space_hwp;
                if !space_is_line_leading(text_chars, line_start_idx, *idx) {
                    line_space_savings +=
                        condense_space_savings_hwp(to_hwp(*condense_base), condense_min_space);
                }
            }
            BreakToken::Text {
                start_idx,
                end_idx,
                width,
                max_font_size,
                ref char_widths,
                ..
            } => {
                if break_before_hangul_char(
                    text_chars,
                    *start_idx,
                    line_start_idx,
                    korean_break_unit,
                ) {
                    last_break_token_idx = Some(ti - 1);
                    last_break_char_idx = *start_idx;
                    width_at_last_break = lw;
                    space_savings_at_last_break = line_space_savings;
                    fs_at_last_break = line_max_fs;
                }
                if *max_font_size > line_max_fs {
                    line_max_fs = *max_font_size;
                }

                let w_hwp = to_hwp(*width);

                // 단일 문자 CJK/한글 토큰의 줄바꿈 가능 지점 처리
                // 이 글자를 포함한 후 break point 갱신 (end_idx 사용)
                // → 초과 시 이 글자까지 L0에 포함하고 다음 토큰부터 다음 줄
                let effective_width = eff_w(is_first_line);
                let new_word_natural = new_word_natural_before_hwp(tokens, ti, line_start_idx);
                let token_fits = text_token_fits_line_hwp(
                    lw,
                    FitWidthHwp(w_hwp),
                    line_space_savings,
                    effective_width,
                    new_word_natural,
                );
                // Same single predicate as the live fill — see the note there.
                let tail_all_line_start_forbidden = text_chars[*start_idx + 1..*end_idx]
                    .iter()
                    .all(|c| is_line_start_forbidden(*c));
                // 위 `fill_one_interval` 과 같은 계약(흡수 묶음도 줄 끝 후보).
                if tail_all_line_start_forbidden && *start_idx > line_start_idx && token_fits {
                    let c = text_chars[*start_idx];
                    let allow_break = if is_hangul(c) {
                        // [#2185] bit7=1 = 글자 단위 break 허용 (위 주석 참조)
                        korean_break_unit == 1
                    } else {
                        is_cjk_ideograph(c)
                    };
                    if allow_break {
                        last_break_token_idx = Some(ti);
                        last_break_char_idx = *end_idx; // 이 글자 다음 (이 글자 포함)
                        width_at_last_break = lw + w_hwp; // 이 글자 폭 포함
                        space_savings_at_last_break = line_space_savings;
                        fs_at_last_break = line_max_fs;
                    }
                }
                if !text_token_fits_line_hwp(
                    lw,
                    FitWidthHwp(w_hwp),
                    line_space_savings,
                    effective_width,
                    new_word_natural,
                ) {
                    if *start_idx > line_start_idx {
                        if let Some(break_token_idx) = last_break_token_idx {
                            results.push(LineBreakResult {
                                start_idx: line_start_idx,
                                end_idx: last_break_char_idx,
                                max_font_size: fs_at_last_break,
                                has_line_break: false,
                            });
                            let mut next_start = last_break_char_idx;
                            while next_start < text_chars.len() && text_chars[next_start] == ' ' {
                                next_start += 1;
                            }
                            line_start_idx = next_start;
                            lw = recalc_width_hwp(tokens, ti, next_start);
                            line_space_savings = recalc_space_savings_hwp(
                                tokens,
                                ti,
                                next_start,
                                condense_min_space,
                            );
                            line_max_fs = *max_font_size;
                            is_first_line = false;
                            last_break_token_idx = None;

                            // 현재 단일 CJK/한글 토큰 자체가 break point였던 기존 경로는
                            // 이미 위 결과에 포함됐으므로 동작을 바꾸지 않는다.
                            if break_token_idx == ti {
                                lw += w_hwp;
                                continue;
                            }

                            // [#3822] 이전 break 뒤로 옮긴 현재 토큰이 새 줄에도
                            // 들어가는지 다시 확인한다. 종전에는 토큰 전체 폭을 무조건
                            // 더하고 continue하여, 긴 영문·숫자 토큰의 글자 단위 fallback을
                            // 건너뛰었다.
                            if text_token_fits_line_hwp(
                                lw,
                                FitWidthHwp(w_hwp),
                                line_space_savings,
                                eff_w(false),
                                new_word_natural_before_hwp(tokens, ti, line_start_idx),
                            ) {
                                lw += w_hwp;
                                continue;
                            }
                        }
                    }
                    // 토큰에 저장된 개별 글자 폭을 HWPUNIT로 변환
                    let cw_hwp: Vec<i32> = char_widths.iter().map(|w| to_hwp(*w)).collect();
                    let (results_part, remaining_w, remaining_fs) = char_level_break_hwp(
                        text_chars,
                        *start_idx,
                        *end_idx,
                        &mut line_start_idx,
                        lw,
                        line_max_fs,
                        eff_w(is_first_line),
                        eff_w(false),
                        is_first_line,
                        &cw_hwp,
                    );
                    for r in results_part {
                        results.push(r);
                        is_first_line = false;
                    }
                    lw = remaining_w;
                    line_space_savings = 0;
                    line_max_fs = remaining_fs;
                    last_break_token_idx = None;
                    continue;
                } else {
                    lw += w_hwp;
                }
            }
        }
    }

    let last_end = tokens
        .last()
        .map(|t| match t {
            BreakToken::Text { end_idx, .. } => *end_idx,
            BreakToken::Space { idx, .. }
            | BreakToken::Tab { idx, .. }
            | BreakToken::LineBreak { idx } => *idx + 1,
        })
        .unwrap_or(text_chars.len());

    if line_start_idx <= last_end {
        results.push(LineBreakResult {
            start_idx: line_start_idx,
            end_idx: last_end,
            max_font_size: line_max_fs,
            has_line_break: false,
        });
    }

    if results.is_empty() {
        results.push(LineBreakResult {
            start_idx: initial_start_idx,
            end_idx: text_chars.len(),
            max_font_size: 0.0,
            has_line_break: false,
        });
    }

    results
}

/// 줄 바꿈 지점 이후 토큰의 누적 폭 재계산 (HWPUNIT)
fn recalc_width_hwp(tokens: &[BreakToken], current_token_idx: usize, new_line_start: usize) -> i32 {
    recalc_width_with_units_hwp(tokens, current_token_idx, new_line_start, false)
}

fn recalc_width_with_units_hwp(
    tokens: &[BreakToken], current_token_idx: usize, new_line_start: usize, integral: bool,
) -> i32 {
    let mut w = 0i32;
    for t in &tokens[..current_token_idx] {
        match t {
            BreakToken::Text {
                start_idx,
                base_width,
                ..
            } if *start_idx >= new_line_start => {
                w += fill_units_hwp(*base_width, integral);
            }
            BreakToken::Space { idx, width, .. } if *idx >= new_line_start => {
                w += fill_units_hwp(*width, integral);
            }
            _ => {}
        }
    }
    w
}

/// 줄 바꿈 지점 이후 공백 압축 가능 폭 재계산 (HWPUNIT)
fn recalc_space_savings_hwp(
    tokens: &[BreakToken],
    current_token_idx: usize,
    new_line_start: usize,
    condense_min_space: u8,
) -> i32 {
    let mut w = 0i32;
    // [#7418] 줄 맨 앞 공백(첫 글자 토큰 앞)은 줄지 않는다.
    let mut line_has_text = false;
    for t in &tokens[..current_token_idx] {
        match t {
            BreakToken::Space {
                idx, condense_base, ..
            } if *idx >= new_line_start && line_has_text => {
                w += condense_space_savings_hwp(to_hwp(*condense_base), condense_min_space);
            }
            BreakToken::Text { start_idx, .. } if *start_idx >= new_line_start => {
                line_has_text = true;
            }
            _ => {}
        }
    }
    w
}

/// 긴 단어 폴백: 글자 단위 분할 (HWPUNIT)
/// char_widths_hwp: 토큰 내 각 글자의 HWPUNIT 폭 (None이면 휴리스틱)
#[cfg(test)]
fn char_level_break_hwp(
    text_chars: &[char],
    token_start: usize,
    token_end: usize,
    line_start_idx: &mut usize,
    mut lw: i32,
    line_max_fs: f64,
    first_line_w: i32,
    normal_w: i32,
    mut is_first_line: bool,
    char_widths_hwp: &[i32], // 토큰 내 글자별 HWPUNIT 폭
) -> (Vec<LineBreakResult>, i32, f64) {
    let mut results = Vec::new();
    let mut current_w = if is_first_line {
        first_line_w
    } else {
        normal_w
    };

    for ci in token_start..token_end {
        let rel_idx = ci - token_start;
        let char_w = if rel_idx < char_widths_hwp.len() {
            char_widths_hwp[rel_idx]
        } else {
            let ch = text_chars[ci];
            let char_w_px = if is_cjk_char(ch) {
                line_max_fs.max(12.0)
            } else {
                line_max_fs.max(12.0) * 0.5
            };
            to_hwp(char_w_px)
        };

        if lw + char_w > current_w && ci > *line_start_idx {
            results.push(LineBreakResult {
                start_idx: *line_start_idx,
                end_idx: ci,
                max_font_size: line_max_fs,
                has_line_break: false,
            });
            *line_start_idx = ci;
            lw = char_w;
            is_first_line = false;
            current_w = normal_w;
        } else {
            lw += char_w;
        }
    }

    (results, lw, line_max_fs)
}

/// 문단이 참조하는 글자모양 중 가장 큰 글꼴 크기(px). 글자모양이 없으면 None.
///
/// 글자가 없는 문단(글자처럼 취급되는 표·그림만 든 문단)은 줄에 글자 폭이 없어 `max_font_size` 가
/// 0 으로 떨어지고, 그러면 줄간격 기준이 12px 하드코딩으로 내려간다. 한컴은 그 문단의
/// 글자모양 높이를 그대로 줄간격 기준으로 쓴다(실측: 14pt 문단 표 줄 spacing 912 HU, 12px 폴백은 585).
fn paragraph_font_size_px(para: &Paragraph, styles: &ResolvedStyleSet) -> Option<f64> {
    para.char_shapes
        .iter()
        .filter_map(|cs| styles.char_styles.get(cs.char_shape_id as usize))
        .map(|style| style.font_size)
        .filter(|fs| *fs > 0.0)
        .fold(None, |acc: Option<f64>, fs| {
            Some(acc.map_or(fs, |a| a.max(fs)))
        })
}

/// 비-글자취급 개체(표·그림·도형)의 기준 문자 위치(텍스트 문자 인덱스)와 그 문자의 글꼴 크기(px).
///
/// 개체가 글자처럼 흐르지 않아도 기준 문자는 문단 텍스트의 한 글자이고, 한컴은 그 글자의
/// 글자모양을 줄 높이에 넣는다. 한컴 저장본에서 첫 줄의 개체 기준 문자 글자모양이 그 줄의
/// 다른 글자보다 클 때 저장 줄 높이는 언제나 기준 문자 쪽 크기다(`samples/`·10k 코퍼스 HWP
/// 표본 스캔 11/11, 반례 0 — 예: 1600/1200 → 1600, 2000/1400 → 2000). 기준 문자가 더 작으면
/// 텍스트 크기가 남는다(71건). 글자처럼 취급하는 개체는 개체 높이로 줄을 만드는 별도 경로가
/// 소유한다.
fn floating_anchor_char_font_sizes(
    para: &Paragraph,
    styles: &ResolvedStyleSet,
) -> Vec<(usize, f64)> {
    if para.controls.is_empty() || para.char_shapes.is_empty() {
        return Vec::new();
    }
    let text_positions = para.control_text_positions();
    let utf16_positions = para.control_utf16_positions();
    para.controls
        .iter()
        .zip(text_positions)
        .zip(utf16_positions)
        .filter(|((ctrl, _), _)| match ctrl {
            Control::Table(table) => !table.common.treat_as_char,
            Control::Picture(pic) => !pic.common.treat_as_char,
            Control::Shape(shape) => !shape.common().treat_as_char,
            _ => false,
        })
        .filter_map(|((_, text_pos), utf16_pos)| {
            let id = find_active_char_shape(&para.char_shapes, utf16_pos);
            styles
                .char_styles
                .get(id as usize)
                .map(|style| style.font_size)
                .filter(|fs| *fs > 0.0)
                .map(|fs| (text_pos, fs))
        })
        .collect()
}

/// `range` 줄에 놓인 개체 기준 문자의 가장 큰 글꼴 크기(px). 문단 끝 기준 문자는 마지막 줄 소속이다.
fn floating_anchor_font_size_px(
    anchors: &[(usize, f64)],
    range: Range<usize>,
    is_last_line: bool,
    text_len: usize,
) -> f64 {
    anchors
        .iter()
        .filter(|(pos, _)| range.contains(pos) || (is_last_line && *pos == text_len))
        .map(|(_, fs)| *fs)
        .fold(0.0, f64::max)
}

fn inline_control_line_height_hwp(para: &Paragraph) -> Option<i32> {
    para.controls
        .iter()
        .filter_map(|ctrl| match ctrl {
            Control::Picture(pic) if pic.common.treat_as_char => Some(pic.common.height as i32),
            Control::Shape(shape) if shape.common().treat_as_char => Some(shape.flow_height_hu()),
            Control::Table(table) if table.common.treat_as_char => Some(table.common.height as i32),
            Control::Equation(eq) if eq.common.treat_as_char => {
                Some(crate::renderer::equation::flow_height_hwp(eq) as i32)
            }
            Control::Form(form) if form.common.treat_as_char => Some(form.height as i32),
            _ => None,
        })
        .filter(|height| *height > 0)
        .max()
}

fn inline_control_size_hwp(ctrl: &Control) -> Option<(i32, i32)> {
    let (width, height) = match ctrl {
        Control::Picture(pic) if pic.common.treat_as_char => {
            (pic.common.width as i32, pic.common.height as i32)
        }
        Control::Shape(shape) if shape.common().treat_as_char => (
            (shape.common().width as i32).max(shape.shape_attr().current_width as i32),
            shape.flow_height_hu(),
        ),
        Control::Table(table) if table.common.treat_as_char => {
            // [#5785 후속] 선언 폭 우선 — 원시 열 합은 행별 구획이 다른 표에서 과대집계된다.
            let width = table.flow_width_hu() as i32;
            (width, table.common.height as i32)
        }
        Control::Equation(eq) if eq.common.treat_as_char => (
            crate::renderer::equation::flow_width_hwp(eq) as i32,
            crate::renderer::equation::flow_height_hwp(eq) as i32,
        ),
        Control::Form(form) if form.common.treat_as_char => (form.width as i32, form.height as i32),
        _ => return None,
    };

    if width > 0 && height > 0 {
        Some((width, height))
    } else {
        None
    }
}

/// 줄의 점유 상자는 표 본체와 바깥 여백을 함께 포함한다.
/// 별도 줄의 너비 판정과 같은 줄의 높이 발행이 동일한 메트릭을 소비한다.
fn inline_control_occupied_size_hwp(
    control: &Control,
    styles: &ResolvedStyleSet,
    dpi: f64,
) -> Option<(i32, i32)> {
    let (mut width, mut height) = inline_control_size_hwp(control)?;
    if let Control::Table(table) = control {
        // 편집으로 셀 내용이 선언 높이를 넘으면 실제 표 배치도 행 높이를 키운다.
        // 같은 측정기를 소비하여 작은 선언값으로 본문 줄 높이를 과소 발행하지 않는다.
        let measured = crate::renderer::height_measurer::HeightMeasurer::new(dpi)
            .with_session_edited(true)
            .measure_table(table, 0, 0, styles);
        height = height.max(px_to_hwpunit(
            measured.total_height - measured.caption_height,
            dpi,
        ));
        width = width
            .saturating_add(i32::from(table.outer_margin_left))
            .saturating_add(i32::from(table.outer_margin_right));
        height = height
            .saturating_add(i32::from(table.outer_margin_top))
            .saturating_add(i32::from(table.outer_margin_bottom));
    }
    Some((width, height))
}

/// [#7160] 프레임 채움 전용 — **글자처럼 취급 표**도 인라인 토큰으로 싣는다.
///
/// 일반 경로는 표를 `control 배치 경로`에 두려고 제외하지만(#3211), 저장 줄이 없는 host 는
/// 이 채움이 줄 경계의 유일한 소유자다. 표 폭을 안 실으면 줄에 남은 폭보다 넓은 표가
/// 줄바꿈 없이 앞 글자 뒤에 붙는다(`distribution_doc.hwpx` 3쪽 — 표가 본문 오른쪽 밖으로 나간다).
fn flow_inline_controls_with_tac_tables(para: &Paragraph) -> Vec<FlowInlineControl> {
    let text_len = para.text.chars().count();
    let mut controls = flow_inline_controls(para);
    for (control, char_position) in para.controls.iter().zip(para.control_text_positions()) {
        let Control::Table(table) = control else {
            continue;
        };
        if !table.common.treat_as_char || char_position >= text_len {
            continue;
        }
        let Some((width_hwp, height_hwp)) = inline_control_size_hwp(control) else {
            continue;
        };
        controls.push(FlowInlineControl {
            char_position,
            width_hwp,
            height_hwp,
            baseline_distance_hwp: None,
        });
    }
    controls.sort_by_key(|control| control.char_position);
    controls
}

fn flow_inline_controls(para: &Paragraph) -> Vec<FlowInlineControl> {
    let text_len = para.text.chars().count();
    para.controls
        .iter()
        .zip(para.control_text_positions())
        .filter_map(|(control, char_position)| {
            // 글자처럼 취급되는 표는 renderer가 control 위치를 기준으로 별도
            // TextRun/Table 경계를 만든다. 보이지 않는 PARA_TEXT 위치의 다음
            // 글자 폭에 표 전체 폭을 더하면 HML의 `abc + table + efg`처럼
            // 기존 경계를 잃는다. #3211의 HWP oracle은 수식·그림 계열의
            // 재조판 폭을 대상으로 하므로 표는 기존 control 배치 경로에 둔다.
            if matches!(control, Control::Table(_)) {
                return None;
            }
            let (width_hwp, height_hwp) = inline_control_size_hwp(control)?;
            let baseline_distance_hwp = match control {
                Control::Equation(equation) if equation.baseline > 0 => {
                    Some(crate::renderer::equation::flow_metrics_hwp(equation).2)
                }
                _ => None,
            };
            (char_position < text_len).then_some(FlowInlineControl {
                char_position,
                width_hwp,
                height_hwp,
                baseline_distance_hwp,
            })
        })
        .collect()
}

/// Controls that claim no inline advance and own no layout box of their own.
///
/// Structural section/column markers qualify because the caller's current
/// Frame already embodies their resolved page/column geometry. A field
/// (`ClickHere` and friends) qualifies for a different reason that reaches the
/// same place: it is a *marker pair* around ordinary paragraph text.
/// `inline_control_size_hwp` returns `None` for it, so `flow_inline_controls`
/// never emits a token for it and the fill measures it as nothing.
///
/// Fields have to be in this set, because the alternative is that a body
/// paragraph carrying one has **no layout owner at all**. That is the state
/// `hwp_doc_fill_fields` leaves behind: `set_field_text_at`
/// (`queries/field_query.rs`) replaces the field's text and shifts the stored
/// `LineSeg` offsets, but never calls `reflow_line_segs`, so a paragraph that
/// went from 9 bytes to 5,109 still carries the one record that described the
/// empty form. Nothing downstream re-wraps it if the frame declines to look.
/// **A property, not a list.** This used to enumerate three variants, and the
/// enumeration was the defect: `Bookmark`, `PageNumberPos`, `PageHide`,
/// `HiddenComment` and HWP3's `Hyperlink` are every bit as width-neutral as a
/// `Field`, and a body paragraph carrying one had no layout owner at all — it
/// fell to `compose_lines`' 45-character heuristic with no stored record, or
/// got no repair with a stale one. HWP5/HWPX hyperlinks escaped only by an
/// accident of parsing: `%hlk` becomes a `Control::Field` through a prefix
/// test. Fields were added to the list for exactly this reason once already;
/// the class was the thing to fix.
///
/// The property is: **contributes no inline width, and owns no layout box.**
///
/// - No inline width is `inline_control_size_hwp` returning `None` — the same
///   oracle `flow_inline_controls` uses, so a control the fill would measure as
///   nothing is a control the frame may ignore. That is one source of truth
///   rather than two lists that must be kept in step.
/// - No layout box of its own is the closed set below. It cannot come from the
///   width oracle, because a *floating* Picture, Shape or Table also returns
///   `None` there — they contribute no inline width precisely because they are
///   laid out elsewhere. A body frame carries no exclusion for them
///   (`models_exclusions()` is false), so it must decline and leave them with
///   their established owner; that is what `layout_picture_band` exists for.
///
/// Enumerating the controls that *have* geometry rather than the ones that do
/// not also fails in the safer direction. A control variant nobody has
/// classified is laid out as ordinary text by the frame, which is at worst the
/// same treatment its text would get anyway — where the previous shape left the
/// whole paragraph unowned.
pub(crate) fn control_is_width_neutral_marker(control: &Control) -> bool {
    inline_control_size_hwp(control).is_none() && !control_owns_a_layout_box(control)
}

/// Controls that resolve their own geometry, inline or floating, and therefore
/// have a layout owner that is not this frame.
///
/// `Header`/`Footer`/`Footnote`/`Endnote` are nested flows with their own
/// frames; the rest carry a `CommonObjAttr` box. `Footnote`/`Endnote` also
/// occupy a flow slot (`Control::is_logical_inline`).
fn control_owns_a_layout_box(control: &Control) -> bool {
    matches!(
        control,
        Control::Table(_)
            | Control::Shape(_)
            | Control::Picture(_)
            | Control::Equation(_)
            | Control::Form(_)
            | Control::Header(_)
            | Control::Footer(_)
            | Control::Footnote(_)
            | Control::Endnote(_)
    )
}

/// [#6102] 자리차지(TopAndBottom) 비-TAC 표는 자기 레이아웃 상자를 갖지만
/// **줄 폭**은 소비하지 않는다 — 세로 밴드를 예약할 뿐 본문 프레임의 가로
/// 줄바꿈에는 폭-중립이다. 결재문서본문 계열(구역 첫 문단 + 자리차지 표
/// host)의 저장 `textpos` 가 실폭보다 길게 적혀 있을 때, 프레임이 표 컨트롤
/// 때문에 사양하면 검증(admission)조차 못 해 본문 첫 줄이 우단 밖까지
/// 그려진다(36360328 +75px — 한글 2020 은 재래핑한다). 어울림(Square)은
/// 배제 밴드가 줄 폭을 바꾸므로, 그림/도형 float 는 별도 계보
/// (`layout_picture_band`)가 소유하므로 계속 사양한다.
fn control_is_line_width_neutral_float_table(control: &Control) -> bool {
    matches!(control, Control::Table(t)
        if !t.common.treat_as_char
            && matches!(t.common.text_wrap, crate::model::shape::TextWrap::TopAndBottom))
}

/// 대체 메트릭으로 폭이 바뀐 수식의 첫 소유 줄만 저장 캐시 경계로 삼는다.
/// 앞쪽의 정상 줄과 각주 앵커까지 함께 재조판하면 무관한 문단 배치가 바뀐다.
pub(super) fn remeasured_equation_start_row(para: &Paragraph) -> Option<usize> {
    let positions = super::find_render_inline_control_positions(para);
    para.controls
        .iter()
        .enumerate()
        .filter_map(|(index, control)| {
            let Control::Equation(equation) = control else {
                return None;
            };
            if !equation.common.treat_as_char
                || crate::renderer::equation::flow_width_hwp(equation) == equation.common.width
            {
                return None;
            }
            let position = *positions.get(index)?;
            let chars = para.text.chars().count();
            para.line_segs
                .iter()
                .enumerate()
                .rev()
                .find_map(|(row, _)| {
                    let (start, _) = super::utf16_range_to_text_range(
                        &para.char_offsets,
                        para.line_seg_text_start(row),
                        u32::MAX,
                        chars,
                    );
                    (start <= position).then_some(row)
                })
        })
        .min()
}

pub(super) fn supports_cached_body_frame_controls(para: &Paragraph) -> bool {
    let remeasured = remeasured_equation_start_row(para).is_some();
    para.controls.iter().all(|control| {
        control_is_width_neutral_marker(control)
            || control_is_line_width_neutral_float_table(control)
            || (remeasured && matches!(control, Control::Equation(eq) if eq.common.treat_as_char))
            || (remeasured && matches!(control, Control::Footnote(_)))
    })
}

/// The picture-band frame intentionally admits only its floating host, the
/// already-supported treat-as-character Equation flow, and width-neutral
/// markers. Other controls have their own layout owners and must leave this
/// transaction untouched.
/// [#7160] NO_LS 문단의 **글자처럼 취급 표** host 도 프레임이 받는다.
///
/// 배포용(ViewText) 문서는 저장 `LINE_SEG` 가 없어 45자 합성 줄바꿈이 유일한 소유자가 된다.
/// 표를 사양하면 그 합성 줄이 그대로 남아 `(단위 : 천원)` 한 줄이 세 줄로 쪼개지고, 표가
/// 자기 줄을 못 얻어 앞 글자 뒤에 붙는다(`distribution_doc.hwpx` 3쪽). TAC 표는 fill 이
/// 인라인 토큰으로 폭을 계상하므로 그림과 같은 축이다.
pub(super) fn supports_tac_table_band_frame_controls(para: &Paragraph) -> bool {
    let mut tac_tables = 0usize;
    for control in &para.controls {
        match control {
            Control::Table(table) if table.common.treat_as_char => tac_tables += 1,
            Control::Picture(picture) if picture.common.treat_as_char => {}
            Control::Equation(equation) if equation.common.treat_as_char => {}
            other if control_is_width_neutral_marker(other) => {}
            _ => return false,
        }
    }
    tac_tables == 1
}

pub(super) fn supports_picture_band_frame_controls(para: &Paragraph) -> bool {
    let mut non_tac_pictures = 0usize;
    for control in &para.controls {
        match control {
            Control::Picture(picture) if !picture.common.treat_as_char => {
                non_tac_pictures += 1;
            }
            // 글자처럼 취급 그림은 fill 이 인라인 토큰으로 폭을 계상한다
            // (`inline_control_size_hwp`) — 사양하면 NO_LS 문단에서 인라인
            // 아이콘 폭이 통째로 빠져 후속 텍스트가 아이콘 위에 겹친다.
            Control::Picture(picture) if picture.common.treat_as_char => {}
            Control::Equation(equation) if equation.common.treat_as_char => {}
            other if control_is_width_neutral_marker(other) => {}
            _ => return false,
        }
    }
    non_tac_pictures <= 1
}

/// 본문 뒤 남은 폭에 놓이지 않는 inline control은 별도 physical line을 가진다.
///
/// 종전 cell reflow는 text token만 줄바꿈한 뒤 첫 LineSeg를 표 높이만큼 키웠다.
/// 그 결과 분할로 폭이 좁아진 셀에서 `text + inline object`가 한 줄로 합쳐졌다.
/// 한컴은 control 위치부터 object 전용 LineSeg를 만들어 다음 physical line으로 보낸다
/// (#4138: 1×2 split 뒤 nested table/picture host). control 자체가 셀 폭을 넘거나,
/// control 앞의 실제 text 폭과 합쳐 현재 줄의 폭을 넘는 경우만 대상으로 한다.
/// 같은 줄에 들어가는 작은 object와 복수 control 문단의 기존 reflow는 건드리지 않는다.
fn inline_control_requires_own_line(
    para: &Paragraph,
    occupied_controls: &[(usize, i32, i32)],
    text_chars: &[char],
    line_breaks: &[LineBreakResult],
    available_width_px: f64,
    indent_px: f64,
    reflow_is_first_line: bool,
    styles: &ResolvedStyleSet,
    space_metric: SpaceMetric,
) -> Option<(usize, i32)> {
    let text_len = para.text.chars().count();
    let mut candidates = occupied_controls
        .iter()
        .copied()
        .filter(|(position, _, _)| *position > 0 && *position <= text_len);
    let (position, control_width, height) = candidates.next()?;
    // 여러 inline control은 일반 placement가 순서를 보존해야 하므로 이 좁은
    // single-control 계약 밖이다.
    if candidates.next().is_some() {
        return None;
    }

    // 같은 text offset에서 새 줄이 시작되면 control은 그 줄의 선두에 놓인다.
    // 그렇지 않으면 control 직전 text가 실제로 속한 줄을 선택한다. 마지막 글자
    // 뒤의 control은 마지막 text line에 속한다.
    let (line_idx, line) = line_breaks
        .iter()
        .enumerate()
        .find(|(_, line)| line.start_idx == position)
        .or_else(|| {
            line_breaks
                .iter()
                .enumerate()
                .rfind(|(_, line)| line.start_idx < position && position <= line.end_idx)
        })?;
    let is_first_line = reflow_is_first_line && line_idx == 0;
    let available_hwp = if indent_px > 0.0 && is_first_line {
        to_hwp((available_width_px - indent_px).max(1.0))
    } else if indent_px < 0.0 && !is_first_line {
        to_hwp((available_width_px + indent_px).max(1.0))
    } else {
        to_hwp(available_width_px)
    };
    let prefix: String = text_chars[line.start_idx..position].iter().collect();
    let prefix_width = to_hwp(measure_token_width(
        &ParagraphMetricScope::new(text_chars, styles)
            .with_reflow_slots(text_chars)
            .with_space_metric(space_metric),
        &prefix,
        line.start_idx,
        &para.char_offsets,
        &para.char_shapes,
        styles,
        0,
        &[],
    ));

    let tolerance_hwp = line_break_tolerance_hwp(available_hwp);
    (control_width > available_hwp + tolerance_hwp
        || prefix_width + control_width > available_hwp + tolerance_hwp)
        .then_some((position, height))
}

fn char_index_to_utf16_offset(para: &Paragraph, char_index: usize) -> u32 {
    if let Some(offset) = para.char_offsets.get(char_index) {
        return *offset;
    }

    // char_offsets에는 visible text 앞의 control stream gap도 반영된다. 따라서
    // 끝의 빈 physical line(예: trailing Shift+Enter)을 단순 text 길이로 매핑하면
    // SectionDef/ColumnDef가 앞선 문단에서 21이어야 할 start가 5로 되돌아간다.
    // 마지막 visible char의 실제 stream offset을 기준으로 종단을 계산한다.
    para.char_offsets
        .last()
        .zip(para.text.chars().last())
        .map(|(offset, ch)| *offset + ch.len_utf16() as u32)
        .unwrap_or_else(|| {
            // 합성 문단처럼 char_offsets가 비어 있으면 char_index(Unicode scalar
            // index)를 UTF-16 code-unit 위치로 직접 환산한다. 단순 `as u32`는
            // 보충 평면 문자를 1 unit으로 세어 후행 줄의 start를 당긴다.
            para.text
                .chars()
                .take(char_index)
                .map(|ch| ch.len_utf16() as u32)
                .sum()
        })
}

/// `baseline_distance` from a row's height — the one expression, so the frame
/// and the edit path cannot publish different baselines for the same paragraph.
///
/// They did: `frame_metrics_for_line` rounded while `make_line_seg` truncated,
/// and `make_line_seg`'s output is written to the file. Any half-point font
/// size split them — 10.5pt gives `1050 * 0.85 = 892.5`, so one published 893
/// and the other 892.
fn baseline_distance_hwp(line_height_hwp: i32) -> i32 {
    (line_height_hwp as f64 * 0.85).round() as i32
}

fn apply_inline_control_line_height(seg: &mut LineSeg, height_hwp: i32) {
    if height_hwp > seg.line_height {
        seg.line_height = height_hwp;
        seg.text_height = height_hwp;
        seg.baseline_distance = baseline_distance_hwp(height_hwp);
    }
}

fn apply_inline_control_frame_height(metrics: &mut FrameRowMetrics, height_hwp: i32) {
    if height_hwp > metrics.line_height {
        metrics.line_height = height_hwp;
        metrics.text_height = height_hwp;
        metrics.baseline_distance = baseline_distance_hwp(height_hwp);
    }
}

pub(crate) fn frame_metrics_for_line(
    max_font_size: f64,
    fallback_font_size: f64,
    line_spacing_type: LineSpacingType,
    line_spacing_value: f64,
    dpi: f64,
) -> FrameRowMetrics {
    let font_size = if max_font_size > 0.0 {
        max_font_size
    } else {
        fallback_font_size
    };
    let line_height = font_size_to_line_height(font_size, dpi).max(1);
    FrameRowMetrics {
        vertical_pos: 0,
        line_height,
        text_height: line_height,
        baseline_distance: baseline_distance_hwp(line_height),
        line_spacing: compute_line_spacing_hwp(
            line_spacing_type,
            line_spacing_value,
            line_height,
            dpi,
        ),
    }
}

/// [#7490] 새로 조판한 줄에 한글처럼 `TAG_INDENTATION`(bit 20)을 단다.
///
/// 들여쓰기는 첫 줄에, 내어쓰기는 둘째 줄부터 적용된다(한글 저장본의 줄별 기록과
/// 같다). 렌더러는 이 비트가 꺼진 저장 줄에 들여쓰기를 얹지 않으므로(#6190), 비운 채
/// 발행하면 편집한 문단의 들여쓰기·내어쓰기가 그려지지 않는다.
///
/// 기준은 문단 모양의 `indent` 다. 렌더러가 비트를 보고 얹는 값이 이것이므로, 조판용
/// 지역 `indent_px` 를 넘겨받지 않는다. 한글 기록(`stored`, 조판 전 저장 줄)이 이 규칙과
/// 다르면 기록을 따른다.
/// - 들여쓰기가 있는데 저장 줄의 비트가 모두 꺼져 있으면, 한글이 이 문단에 들여쓰기를
///   적용하지 않은 것이다(#6190 표본). 새 줄도 끈다. 내어쓰기는 둘째 줄이 있어야 이
///   기록을 읽는다. 들여쓰기를 바꾼 문단은 [`restamp_indentation`] 이 기록을 먼저 고친다.
/// - 들여쓰기가 0 인 문단 머리(글머리표·번호·개요) 문단은 한글이 둘째 줄부터 비트를
///   켠다. 저장 줄의 둘째 줄 이후 비트를 잇는다.
fn mark_indented_lines(
    lines: &mut [LineSeg],
    first_line_index: usize,
    para_style: Option<&ResolvedParaStyle>,
    stored: &[LineSeg],
) {
    stamp_indentation(
        lines,
        first_line_index,
        reflow_indentation_pattern(para_style, stored),
    );
}

/// 재조판이 발행할 줄별 들여쓰기 기록. 개체의 줄 폭 판정도 같은 기록을 소비한다.
fn reflow_indentation_pattern(
    para_style: Option<&ResolvedParaStyle>,
    stored: &[LineSeg],
) -> (bool, bool) {
    let indent = para_style.map_or(0.0, |style| style.indent);
    let indented = |line: &LineSeg| line.tag & LineSeg::TAG_INDENTATION != 0;
    let hancom_record = !stored.is_empty()
        && stored
            .iter()
            .all(|line| line.tag & LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0);
    if hancom_record
        && (indent > 0.0 || (indent < 0.0 && stored.len() > 1))
        && !stored.iter().any(indented)
    {
        (false, false)
    } else if indent == 0.0 && para_style.is_some_and(|style| style.head_type != HeadType::None) {
        (false, hancom_record && stored.iter().skip(1).any(indented))
    } else {
        (indent > 0.0, indent < 0.0)
    }
}

/// [#7490] 문단 모양이 바뀌어 들여쓰기가 달라졌으면 저장 줄의 bit 20 을 새 들여쓰기로
/// 다시 단다.
///
/// 저장 줄의 비트는 그 줄을 조판할 때의 들여쓰기 기록이다. 옛 기록(모두 꺼짐)을 두면
/// 다음 재조판이 이를 "들여쓰기를 적용하지 않은 문단"으로 읽어 새 들여쓰기를 버린다.
pub(crate) fn restamp_indentation(lines: &mut [LineSeg], old_indent: i32, new_indent: i32) {
    if old_indent != new_indent {
        stamp_indentation(lines, 0, (new_indent > 0, new_indent < 0));
    }
}

/// 첫 줄과 둘째 줄 이후에 각각 bit 20 을 켜거나 끈다.
fn stamp_indentation(lines: &mut [LineSeg], first_line_index: usize, (first, rest): (bool, bool)) {
    for (line_index, line) in (first_line_index..).zip(lines.iter_mut()) {
        if (line_index == 0 && first) || (line_index > 0 && rest) {
            line.tag |= LineSeg::TAG_INDENTATION;
        } else {
            line.tag &= !LineSeg::TAG_INDENTATION;
        }
    }
}

/// Lay out the small scalar/Picture-band paragraph subset through a
/// caller-owned physical frame.
///
/// Every interval returned by one carve belongs to the same physical row. The
/// cursor continues from left to right and the frame does not advance until
/// that complete row has been committed.
pub(crate) fn layout_paragraph_in_frame(
    para: &Paragraph,
    frame: &mut LayoutFrame,
    styles: &ResolvedStyleSet,
    dpi: f64,
) -> Option<Vec<LineSeg>> {
    layout_paragraph_in_frame_impl(para, frame, styles, dpi, true, 0)
}

fn layout_paragraph_in_frame_impl(
    para: &Paragraph,
    frame: &mut LayoutFrame,
    styles: &ResolvedStyleSet,
    dpi: f64,
    allow_kerning: bool,
    start_char: usize,
) -> Option<Vec<LineSeg>> {
    // [#6102] 폭-중립 자리차지 표 host 도 fill 대상 — 표는 줄 폭을 소비하지
    // 않으므로(자기 레이아웃 소유자가 따로 배치) 텍스트만 재래핑하면 된다.
    // [#7160] 저장 줄이 없는 글자처럼 취급 표 host 는 이 채움이 유일한 소유자다.
    if !supports_picture_band_frame_controls(para)
        && !supports_cached_body_frame_controls(para)
        && !(para.line_segs.is_empty() && supports_tac_table_band_frame_controls(para))
    {
        return None;
    }

    let text_chars = para.text.chars().collect::<Vec<_>>();
    let para_style = styles.para_styles.get(para.para_shape_id as usize);
    // [#7418·#7436] 목록 마커(글머리표·번호)는 줄 앞을 차지한다. 배치가 마커 기하만큼
    // 줄 시작을 옮기고 가용폭을 줄이므로 채움도 각 행의 첫 구간에서 같은 상자로 줄을 나눈다
    // (`ListMarkerGeometry::breaker_box`). 게시하는 행 기하(구간)는 마커를 포함한 그대로다 —
    // 한/글 저장 행도 마커 자리부터 시작한다.
    let indent_px = if reflow_indentation_pattern(para_style, &para.line_segs) == (false, false) {
        0.0
    } else {
        para_style.map_or(0.0, |style| style.indent)
    };
    // 저장 기록이 끄는 것은 문단 들여쓰기뿐이다. 마커의 첫/후속 줄 차이는 유지한다.
    let (marker_hang_px, indent_px) = list_marker_breaker_box(para, styles, indent_px);
    let english_break_unit = para_style
        .map(|style| style.english_break_unit)
        .unwrap_or(0);
    let korean_break_unit = para_style.map(|style| style.korean_break_unit).unwrap_or(0);
    let condense_min_space = para_style
        .map(|style| style.condense_min_space)
        .unwrap_or(0);
    let default_tab_width = para_style
        .map(|style| style.default_tab_width)
        .unwrap_or(0.0);
    let line_spacing_type = para_style
        .map(|style| style.line_spacing_type)
        .unwrap_or(LineSpacingType::Percent);
    let line_spacing_value = para_style.map(|style| style.line_spacing).unwrap_or(160.0);
    // Keep Equation width and height ownership with the current scalar
    // `FlowInlineControl` path. A non-TAC Picture deliberately contributes no
    // inline token: it is represented by the caller's exclusion instead.
    let inline_controls =
        if para.line_segs.is_empty() && supports_tac_table_band_frame_controls(para) {
            // [#7160] 저장 줄이 없는 TAC 표 host 는 표 폭까지 줄 경계 판정에 넣는다.
            flow_inline_controls_with_tac_tables(para)
        } else {
            flow_inline_controls(para)
        };
    // [#3128] 프레임이 들여쓰기 추적을 잃던 자리. 종전에는 여기서 `false` 를 박아
    // 두어, 저장 `LINE_SEG` 가 없는 들여쓴 셀 문단도 글꼴 고유 공백 폭으로 쟀다.
    // 실측: `76076_regulatory_analysis.hwp` 에서 이 술어를 만족하는 문단이 74 개고,
    // 그 전부가 이 경로로 들어온다.
    let space_metric =
        if super::missing_lineseg_indented_cell_has_uniform_metrics_with_tracking(para, styles) {
            SpaceMetric::HalfCell
        } else if frame.kopub_justified_space
            && para_style.is_some_and(|style| style.alignment == Alignment::Justify)
        {
            SpaceMetric::KoPubJustified
        } else {
            SpaceMetric::Stored
        };
    let mut tokens = tokenize_paragraph_with_regenerated_space_metric(
        &text_chars,
        &para.char_offsets,
        &para.char_shapes,
        styles,
        english_break_unit,
        korean_break_unit,
        space_metric,
        &inline_controls,
    );
    let prepared_kerning = allow_kerning
        .then(|| {
            prepare_paragraph_kerning(para, &text_chars, styles, space_metric, &inline_controls)
        })
        .flatten()
        .and_then(|prepared| {
            apply_paragraph_kerning_to_tokens(&mut tokens, &prepared.measurement).map(|_| prepared)
        });
    let mut kerning_transaction = prepared_kerning
        .as_ref()
        .map(|prepared| prepared.context.layout_session());
    let mut kerning_break_session = prepared_kerning.as_ref().and_then(|prepared| {
        crate::renderer::kerning::KerningParagraphBreakSession::new(
            &para.text,
            &prepared.scalar_styles,
            &prepared.hard_boundaries,
            &prepared.measurement,
            kerning_transaction.as_mut()?,
        )
        .ok()
    });
    // 양쪽정렬의 마지막 가시 줄은 공백 분배 대상이 아니다. 들여쓴 셀의
    // 중간 줄은 기존 반각 채움을 유지하고, 남은 문단 전체가 현재 구간에
    // 들어가는 마지막 줄만 글꼴 공백으로 확정한다. 첫 줄에만 한정하면
    // 다줄 문단 끝의 불필요한 줄바꿈과 다음 페이지 밀림이 남는다.
    // 커닝은 별도 paragraph transaction이 폭을 소유하므로 그 경로는 유지한다.
    let terminal_tokens = (space_metric == SpaceMetric::HalfCell
        && prepared_kerning.is_none()
        && para_style
            .is_some_and(|style| style.alignment == crate::model::style::Alignment::Justify))
    .then(|| {
        tokenize_paragraph_with_regenerated_space_metric(
            &text_chars,
            &para.char_offsets,
            &para.char_shapes,
            styles,
            english_break_unit,
            korean_break_unit,
            SpaceMetric::Stored,
            &inline_controls,
        )
    });
    let letter_spacing_px =
        resolved_letter_spacing_px(&text_chars, &para.char_offsets, &para.char_shapes, styles);
    let fallback_font_size = if para.text.is_empty() {
        para.char_shapes
            .first()
            .and_then(|char_shape| styles.char_styles.get(char_shape.char_shape_id as usize))
            .map(|style| style.font_size)
            .unwrap_or(12.0)
    } else {
        12.0
    };
    // This matches the scalar path's terminal-control behavior: controls not
    // admitted to `FlowInlineControl` because they sit after the last visible
    // character enlarge the first line box without inventing a second width
    // accounting path.
    let terminal_inline_metrics = inline_controls
        .is_empty()
        .then(|| {
            let height_hwp = inline_control_line_height_hwp(para)?;
            let baseline_distance_hwp = para
                .controls
                .iter()
                .filter_map(|control| match control {
                    Control::Equation(equation)
                        if equation.common.treat_as_char
                            && crate::renderer::equation::flow_height_hwp(equation) as i32
                                == height_hwp
                            && equation.baseline > 0 =>
                    {
                        Some(crate::renderer::equation::flow_metrics_hwp(equation).2)
                    }
                    _ => None,
                })
                .max();
            Some((height_hwp, baseline_distance_hwp))
        })
        .flatten();
    // Fresh rows inherit only provenance. Page/column-first, empty, indent,
    // paragraph-head, and FIRST/LAST are properties of the newly projected
    // physical row and must not leak from the cached first row.
    let source_tag = para
        .line_segs
        .first()
        .map(|segment| segment.tag & LineSeg::TAG_IMPLEMENTATION_PROPERTY)
        .unwrap_or(LineSeg::TAG_IMPLEMENTATION_PROPERTY);
    let first_row = frame.row_count();
    let frame_checkpoint = frame.clone();
    let mut cursor = FillCursor::replay_from_boundary(&tokens, start_char, start_char == 0);
    // 확정된 물리 구간은 원본 격자 폭 자체가 경계다. 추정 여유를 더하면
    // 4 HU 격자로 내린 칸에도 26 HU 초과 글자가 들어가 격자 계약이 무효화된다.
    cursor.allow_metric_tolerance = false;
    cursor.integral_advances = !frame.models_exclusions()
        && paragraph_has_integral_gulimche_advances(para, styles, space_metric);

    let result = (|| {
        while !cursor.finished {
            let row_frame_checkpoint = frame.clone();
            let cursor_checkpoint = cursor.clone();
            let mut candidate_height = frame_metrics_for_line(
                fallback_font_size,
                fallback_font_size,
                line_spacing_type,
                line_spacing_value,
                dpi,
            )
            .line_height;
            const MAX_ROW_HEIGHT_TRIALS: usize = 8;
            let mut attempted_trials = Vec::with_capacity(MAX_ROW_HEIGHT_TRIALS);

            loop {
                frame.restore_checkpoint(row_frame_checkpoint.clone());
                cursor = cursor_checkpoint.clone();
                let intervals = frame.carve(candidate_height).to_vec();
                // Asked before filling so a degenerate carve costs no
                // tokenization, but it is the same question
                // `commit_carved_row` asks — one rule, not two.
                if !frame.carved_row_is_usable() {
                    return None;
                }
                let trial = (frame.top, candidate_height, intervals.clone());
                if attempted_trials.contains(&trial)
                    || attempted_trials.len() == MAX_ROW_HEIGHT_TRIALS
                {
                    return None;
                }
                attempted_trials.push(trial);

                let mut segments = Vec::with_capacity(intervals.len());
                let mut maximum_font_size = 0.0f64;
                let mut inline_metrics = (frame.row_count() == first_row)
                    .then_some(terminal_inline_metrics)
                    .flatten();
                let mut row_terminated = false;
                let interval_width = |index: usize, interval: &std::ops::Range<i32>| {
                    let width = crate::renderer::hwpunit_to_px(
                        interval.end.saturating_sub(interval.start),
                        dpi,
                    );
                    if index == 0 {
                        (width - marker_hang_px).max(1.0)
                    } else {
                        width
                    }
                };
                // 마커는 첫 구간만 소유한다. 낱말 회피도 같은 실제 가용 폭을 비교한다.
                let widest_available_px = intervals
                    .iter()
                    .enumerate()
                    .map(|(index, interval)| interval_width(index, interval))
                    .fold(0.0, f64::max);
                for (interval_index, interval) in intervals.into_iter().enumerate() {
                    let available_width_px = interval_width(interval_index, &interval);
                    cursor.integral_interval_hwp = cursor.integral_advances.then_some(
                        if interval_index == 0 {
                            interval.end.saturating_sub(interval.start).max(75)
                        } else {
                            interval.end.saturating_sub(interval.start)
                        });
                    // 같은 물리 줄의 다른 구간에 온전한 낱말이 들어가면 그대로 보존한다.
                    // 넓은 구간을 채운 뒤 좁은 옆 구간 때문에 글자 단위로 쪼개지 않는다.
                    if cursor.fallback_char_idx.is_none() {
                        if let Some(BreakToken::Text {
                            base_width,
                            end_idx,
                            ..
                        }) = tokens.get(cursor.token_index)
                        {
                            let word = FitWidthHwp::trimmed(
                                to_hwp(*base_width),
                                &letter_spacing_px,
                                *end_idx,
                            );
                            let fits = |width| {
                                text_token_fits_in_line_with_tolerance_hwp(
                                    0, word, 0, width, None, 0,
                                )
                            };
                            let widest_available = to_hwp(widest_available_px);
                            if available_width_px < widest_available_px
                                && !fits(to_hwp(available_width_px))
                                && fits(widest_available)
                            {
                                let boundary =
                                    char_index_to_utf16_offset(para, cursor.line_start_idx);
                                segments.push(RowSegment::new(
                                    boundary..boundary,
                                    interval,
                                    source_tag | LineSeg::TAG_EMPTY_SEGMENT,
                                ));
                                continue;
                            }
                        }
                    }
                    let terminal = terminal_tokens.as_ref().and_then(|terminal_tokens| {
                        let mut replay = FillCursor::replay_from_boundary(
                            terminal_tokens,
                            cursor.line_start_idx,
                            cursor.is_first_line,
                        );
                        replay.allow_metric_tolerance = false;
                        replay.integral_advances = cursor.integral_advances;
                        replay.integral_interval_hwp = cursor.integral_interval_hwp;
                        let filled = fill_one_interval(
                            terminal_tokens,
                            &text_chars,
                            available_width_px,
                            indent_px,
                            default_tab_width,
                            korean_break_unit,
                            condense_min_space,
                            &letter_spacing_px,
                            &mut replay,
                            None,
                        )?;
                        (filled.termination == FillTermination::ParagraphEnd)
                            .then_some((filled, replay))
                    });
                    let selected_space_metric = if terminal.is_some() {
                        SpaceMetric::Stored
                    } else {
                        space_metric
                    };
                    let filled = if let Some((filled, replay)) = terminal {
                        cursor = replay;
                        filled
                    } else {
                        fill_one_interval(
                            &tokens,
                            &text_chars,
                            available_width_px,
                            indent_px,
                            default_tab_width,
                            korean_break_unit,
                            condense_min_space,
                            &letter_spacing_px,
                            &mut cursor,
                            kerning_break_session.as_mut(),
                        )?
                    };
                    let line = &filled.line;
                    maximum_font_size = maximum_font_size.max(line.max_font_size);
                    for control in inline_controls.iter().filter(|control| {
                        (line.start_idx..line.end_idx).contains(&control.char_position)
                            || (line.end_idx == text_chars.len()
                                && control.char_position == text_chars.len())
                    }) {
                        inline_metrics = match inline_metrics {
                            Some((height_hwp, baseline_distance_hwp))
                                if height_hwp > control.height_hwp =>
                            {
                                Some((height_hwp, baseline_distance_hwp))
                            }
                            Some((height_hwp, baseline_distance_hwp))
                                if height_hwp == control.height_hwp =>
                            {
                                Some((
                                    height_hwp,
                                    baseline_distance_hwp.max(control.baseline_distance_hwp),
                                ))
                            }
                            _ => Some((control.height_hwp, control.baseline_distance_hwp)),
                        };
                    }
                    let text_start =
                        if start_char == 0 && frame.row_count() == first_row && segments.is_empty()
                        {
                            0
                        } else {
                            char_index_to_utf16_offset(para, line.start_idx)
                        };
                    let text_end = char_index_to_utf16_offset(para, line.end_idx).max(text_start);
                    let mut segment = RowSegment::new(text_start..text_end, interval, source_tag);
                    segment.space_metric = selected_space_metric;
                    segments.push(segment);

                    if filled.termination != FillTermination::IntervalFull {
                        row_terminated = true;
                        break;
                    }
                }

                let mut metrics = frame_metrics_for_line(
                    maximum_font_size,
                    fallback_font_size,
                    line_spacing_type,
                    line_spacing_value,
                    dpi,
                );
                if let Some((height_hwp, baseline_distance_hwp)) = inline_metrics {
                    let inline_owns_row_height = height_hwp > metrics.line_height;
                    apply_inline_control_frame_height(&mut metrics, height_hwp);
                    if inline_owns_row_height {
                        if let Some(baseline_distance_hwp) = baseline_distance_hwp {
                            metrics.baseline_distance = baseline_distance_hwp;
                        }
                    }
                }
                if metrics.line_height != candidate_height {
                    candidate_height = metrics.line_height;
                    continue;
                }

                if row_terminated && segments.len() < frame.current_intervals.len() {
                    let text_start = segments
                        .last()
                        .map(|segment| segment.text_range.end)
                        .unwrap_or(0);
                    for interval in frame.current_intervals[segments.len()..].iter().cloned() {
                        segments.push(RowSegment::new(
                            text_start..text_start,
                            interval,
                            source_tag | LineSeg::TAG_EMPTY_SEGMENT,
                        ));
                    }
                }

                frame.commit_carved_row(metrics, segments)?;
                break;
            }
        }
        // [#7160] 저장 줄이 없는 TAC 표 host 에서만 말미 공백 줄을 앞 줄이 흡수한다 —
        // 표가 자기 줄을 얻으면서 그 앞에 남던 공백 줄이 한/글에는 없다.
        if para.line_segs.is_empty() && supports_tac_table_band_frame_controls(para) {
            frame.absorb_whitespace_only_rows(&para.text, first_row);
        }
        let mut lines = frame.project_line_segs_since(first_row);
        mark_indented_lines(&mut lines, 0, para_style, &para.line_segs);
        Some(lines)
    })();

    let kerning_failed = kerning_break_session
        .as_ref()
        .and_then(|session| session.failed_reason())
        .is_some();
    if result.is_none() {
        frame.restore_checkpoint(frame_checkpoint);
    }
    drop(kerning_break_session);
    drop(kerning_transaction);
    if kerning_failed {
        // 한 boundary라도 예산/범위 검증에 실패하면 일부 K1 row를 게시하지
        // 않고 문단 전체를 원래 scalar transaction으로 다시 실행한다.
        return layout_paragraph_in_frame_impl(para, frame, styles, dpi, false, start_char);
    }
    result
}

/// The metrics for one stored physical row, computed — never read off the
/// record.
///
/// §1.4.1 recomputes `vertical_pos`, `line_height`, `text_height`,
/// `baseline_distance` and `line_spacing` on both arms and writes them back
/// over the stored values, so the frame must never take them from the file.
/// The row's span is its own `text_start` to the next row's, and its size is
/// the largest char shape active over that span.
///
/// `line_spacing` agrees with HWP's stored value on 98.53% of rows
/// (1,133,166 measured); the residual is §2.14's metricCtx settlement — three
/// independent ceilings — and is characterised, not modelled.
pub(crate) fn stored_row_metrics(
    para: &Paragraph,
    styles: &ResolvedStyleSet,
    dpi: f64,
    row: &[LineSeg],
) -> Option<FrameRowMetrics> {
    let para_style = styles.para_styles.get(para.para_shape_id as usize);
    let line_spacing_type = para_style
        .map(|style| style.line_spacing_type)
        .unwrap_or(LineSpacingType::Percent);
    let line_spacing_value = para_style.map(|style| style.line_spacing).unwrap_or(160.0);
    let fallback_font_size = para
        .char_shapes
        .first()
        .and_then(|shape| styles.char_styles.get(shape.char_shape_id as usize))
        .map(|style| style.font_size)
        .unwrap_or(12.0);

    let span_start = row.first()?.text_start;
    let row_end = row.last()?.text_start;
    let span_end = para
        .line_segs
        .iter()
        .map(|segment| segment.text_start)
        .filter(|start| *start > row_end)
        .min()
        .unwrap_or(u32::MAX);
    let active = para
        .char_shapes
        .iter()
        .filter(|shape| shape.start_pos <= span_start)
        .map(|shape| shape.start_pos)
        .max();
    let max_font_size = para
        .char_shapes
        .iter()
        .filter(|shape| {
            (shape.start_pos >= span_start && shape.start_pos < span_end)
                || Some(shape.start_pos) == active
        })
        .filter_map(|shape| styles.char_styles.get(shape.char_shape_id as usize))
        .map(|style| style.font_size)
        .fold(0.0f64, f64::max);

    Some(frame_metrics_for_line(
        max_font_size,
        fallback_font_size,
        line_spacing_type,
        line_spacing_value,
        dpi,
    ))
}

/// Resolve a paragraph's stored rows through the caller's frame.
///
/// The stored records are a cache, not frame inputs. The frame always computes
/// the physical-row key `(count, column_start, segment_width)` first and admits
/// the cache only on exact equality. Staleness is an additional invalidator: a
/// geometrically matching record that describes obsolete text is still rebuilt.
pub(crate) fn resolve_stored_line_segs_in_frame(
    para: &Paragraph,
    frame: &mut LayoutFrame,
    styles: &ResolvedStyleSet,
    dpi: f64,
    legacy_hwp3_stored_geometry: bool,
    miss_policy: StoredRowMissPolicy,
    stale: bool,
    // [#6175] 같은 세로 band의 용지/쪽 기준 어울림 개체 증거(HWPUNIT).
    // 저장 행의 결손 폭과 세로 위치가 함께 맞으면 좁음의 출처가 외부 기하다.
    float_carve_evidence: &[crate::renderer::float_placement::FloatCarveEvidence],
    known_square_band: bool,
) -> Option<StoredRowResolution> {
    // [#6102] 폭-중립 float 표 host 는 본문 프레임 게이트가 이미 통과시킨
    // 문단이다 — picture-band 게이트만으로 사양하면 저장 textpos 의
    // admission 검증이 통째로 빠져 결재문서본문 계열의 첫 줄이 우단 밖으로
    // 넘친다(36360328 +75px, 한글 2020 은 재래핑). 단, 이 계보는 **stale
    // (물리 위반) 증거가 있을 때만** 개입한다 — 증거 없이 admission 불일치
    // 만으로 재래핑하면 종전 무소유였던 float-host 문단의 확정 핀이 흔들린다.
    // 저장 줄이 아예 없으면 보호할 저장 기하가 없다. 폭-중립 표 호스트도
    // 아래 NO_LS fill로 보내 현재 frame의 줄 경계를 계산한다 (#6950).
    // [#7160] 글자처럼 취급 표 host 도 같은 축이다 — 저장 줄이 없으면 아래 NO_LS fill 이
    // 유일한 소유자이고, `inline_control_size_hwp` 가 그 표의 폭을 인라인 토큰으로 계상한다.
    // 거절하면 45자 합성 줄이 그대로 남아 표가 자기 줄을 못 얻는다(distribution_doc 3쪽).
    let tac_table_host_fill =
        para.line_segs.is_empty() && supports_tac_table_band_frame_controls(para);
    if !supports_picture_band_frame_controls(para) && !tac_table_host_fill {
        if !supports_cached_body_frame_controls(para) || (!stale && !para.line_segs.is_empty()) {
            return None;
        }
    }

    // NO_LS: there is no stored record to compare, so this is the rebuild case
    // outright and belongs to the frame's fill. The fill tokenizes through
    // `para.char_shapes`, which is the char-shape re-splitting #2632 needed —
    // a mixed-char-shape paragraph must measure the way it renders.
    if para.line_segs.is_empty() {
        let mut fill_input = para.clone();
        fill_input.line_segs.clear();
        // [#7160] 문단 **끝**에 앵커된 글자처럼 취급 표는 글자 슬롯이 없어 폭 판정에서
        // 빠진다. 자리 문자를 하나 붙여 그 표가 줄에 들어가는지 묻게 한다 — 안 들어가면
        // 채움이 다음 줄로 넘긴다(한/글 정본 `distribution_doc-2024.pdf` 3쪽과 같은 자리).
        let text_len = fill_input.text.chars().count();
        if supports_tac_table_band_frame_controls(&fill_input)
            && fill_input
                .control_text_positions()
                .iter()
                .any(|position| *position >= text_len)
        {
            fill_input.text.push('\u{FFFC}');
        }
        return layout_paragraph_in_frame(&fill_input, frame, styles, dpi)
            .map(|_| StoredRowResolution::Reflowed);
    }

    // HWP3-lineage stored rows use a legacy horizontal-origin lane that the
    // common ParaShape does not carry. The first sample16 mismatch is a
    // non-stale row stored at 2500..50024 while the common style resolves a
    // 5000..50024 Frame (margin 5000, hanging indent -2500). HWP3→HWP5 keeps
    // that stored origin too (#1892 round-trip: stored 0..42520 versus Frame
    // 1200..42520), so provenance — not the current container — owns the gate.
    // This is not a cache-key mismatch the common Frame can repair; it lacks
    // jurisdiction. Edited/stale text still takes the fresh fill below, and
    // NO_LS already took the Frame-owned branch above.
    if legacy_hwp3_stored_geometry && !stale {
        return None;
    }

    // #4755 §1 recomputes a FIRST..LAST split row as one physical row, and the
    // picture-band frame does exactly that because it holds the exclusion that
    // split it. A frame with no exclusions cannot: it carves one full-width
    // interval, so reflowing a split row there flattens it and destroys the
    // stored fragment geometry (#4690 `30098` p3 pi=48 stores `0..3402` and
    // `45305..48188` around a float; a full-width recompute loses the right
    // fragment entirely).
    //
    // An exclusion need not split one physical row into multiple slots. It can
    // leave one narrowed slot for several rows and then end, returning later
    // rows to the full frame width. #4090 pi=45 is exactly that shape: six
    // `0+26319` rows beside a Square table, followed by one `0+48188` row below
    // it. Different single-slot row extents therefore prove the same missing
    // per-band geometry as FIRST..LAST splitting. That is a limit of
    // jurisdiction, not a comparison tolerance — the frame declines rather
    // than claiming rows whose geometry it cannot compute, and the paragraph
    // stays with its established owner.
    //
    // This guard is live and load-bearing: it keeps cache admission and strict
    // reflow from flattening a split row when this frame lacks the exclusion
    // geometry that originally produced it. The multi-slot comparison becomes
    // live when a caller supplies those exclusions.
    if !frame.models_exclusions()
        && stored_rows_require_external_geometry(
            para,
            frame,
            float_carve_evidence,
            known_square_band,
        )
    {
        return None;
    }

    // 수식 대체 폭이 달라진 곳부터만 채운다. 앞행은 같은 프레임의 수용 검사와
    // 저장 줄 출처를 통과해야 하며, 실패하면 이 부분 경로는 결과를 남기지 않는다.
    if let Some(start_row) = remeasured_equation_start_row(para) {
        let checkpoint = frame.clone();
        if !para.stored_text_partition_is_dirty()
            && !stored_rows_require_external_geometry(
                para,
                frame,
                float_carve_evidence,
                known_square_band,
            )
            && (start_row == 0
                || frame.try_admit_stored_rows(&para.line_segs[..start_row], |row| {
                    stored_row_metrics(para, styles, dpi, row)
                }))
        {
            let (start_char, _) = super::utf16_range_to_text_range(
                &para.char_offsets,
                para.line_seg_text_start(start_row),
                u32::MAX,
                para.text.chars().count(),
            );
            if layout_paragraph_in_frame_impl(para, frame, styles, dpi, true, start_char).is_some()
            {
                return Some(StoredRowResolution::Reflowed);
            }
        }
        frame.restore_checkpoint(checkpoint);
        return None;
    }

    let entry_checkpoint = frame.clone();
    let cache_geometry_matches = stored_rows_reproduce_frame_expectation(para, frame, styles, dpi);
    if cache_geometry_matches && !stale {
        return Some(StoredRowResolution::Stored);
    }

    // Admission commits recomputed rows into the frame. A stale cache must not
    // leave those rows behind before the fresh fill starts. Rejection already
    // restores internally, so this is deliberately idempotent on that arm.
    frame.restore_checkpoint(entry_checkpoint);
    if !cache_geometry_matches
        && !stale
        && miss_policy == StoredRowMissPolicy::UnmodelledUnlessStale
    {
        return None;
    }
    if !cache_geometry_matches {
        report_stored_row_key_mismatch(para, frame, styles, dpi);
    }

    let mut reflow_input = para.clone();
    // A rejected row cannot remain the provenance template for fresh rows:
    // placement/empty flags describe the stored physical rows, not this
    // frame's newly carved projection.
    reflow_input.line_segs.clear();
    layout_paragraph_in_frame(&reflow_input, frame, styles, dpi)
        .map(|_| StoredRowResolution::Reflowed)
}

/// [#6175] 저장 행의 결손 폭이 어울림 개체의 흐름 폭과 같다고 볼 허용 오차(HWPUNIT).
///
/// 개체와 본문 사이의 간격(한컴이 넣는 여백)이 이 안에 든다 — 156655489 실측 284,
/// 156647303 실측 도 같은 자릿수다. 1200HU ≈ 16px 로, 글자 한 칸(약 1000HU)보다
/// 크지 않게 잡아 서로 다른 폭의 개체를 우연히 맞추지 않는다.
const FLOAT_CARVE_MATCH_TOLERANCE_HU: i32 = 1200;

/// A one-unit layout quantum is enough to distinguish a real narrowed lane
/// from a full-width row after integer projection. Keep this local to stored
/// row provenance rather than exposing layout-frame internals.
const UNIFORM_INSET_MIN_DELTA_HU: i32 = 4;

/// Whether stored physical rows prove that their frame changed by vertical
/// band and therefore required exclusion geometry.
///
/// A multi-slot FIRST..LAST row is direct evidence. A sequence of complete
/// single-slot rows with different horizontal extents is equivalent evidence:
/// a scalar frame has one immutable horizontal range, so it cannot produce the
/// transition without an exclusion entering or leaving the row band.
fn stored_rows_require_external_geometry(
    para: &Paragraph,
    frame: &LayoutFrame,
    float_carve_evidence: &[crate::renderer::float_placement::FloatCarveEvidence],
    known_square_band: bool,
) -> bool {
    let line_segs = &para.line_segs;
    let split_or_varying = line_segs
        .iter()
        .any(|segment| !segment.is_first_segment() || !segment.is_last_segment())
        || line_segs.windows(2).any(|pair| {
            pair[0].column_start != pair[1].column_start
                || pair[0].segment_width != pair[1].segment_width
        });
    if split_or_varying {
        return true;
    }

    // [#6175] 문단 전체가 개체 옆에 들어가면 폭 변화가 사라져 위 증거가
    // 소멸한다. 그때는 문서에 실재하는 어울림 개체가 증거다 — 저장 행이 남긴
    // 결손 폭을 그 개체의 흐름 폭이 설명하면, 좁음의 출처는 이 문단 자신이
    // 아니라 외부 기하다.
    //
    // ⚠ 이 판별자는 개체 폭과 **같은 세로 band**의 대조여야 한다. 균일하게 좁다는 것만으로는 문단
    // 테두리 박스의 inset 과 구별되지 않아 #547·#1440 핀이 깨진다(#6129 에서
    // 국소 판별자 2종이 그렇게 반증됐다). 셀에서는 #5818 이 같은 혼동을 "같은
    // 셀에 Square float 실재"로 이미 갈랐고, 이것은 그 계약의 본문 판이다.
    //
    // 156655489 1쪽 실측: 본문 폭 48188, 저장 cs=0·sw=26692 → 결손 21496.
    // 용지 기준 Square 그림 폭 21212 (offset 32361 → 프레임 좌표 26692) 로,
    // 저장 사다리의 끝이 개체 왼쪽 변과 단위까지 맞는다.
    if !float_carve_evidence.is_empty() && !line_segs.is_empty() {
        let uniform_narrow = line_segs.iter().all(|segment| {
            segment.column_start == frame.horizontal.start && segment.segment_width > 0
        }) && line_segs
            .windows(2)
            .all(|pair| pair[0].segment_width == pair[1].segment_width);
        if uniform_narrow {
            let occupied = line_segs[0]
                .column_start
                .saturating_add(line_segs[0].segment_width);
            let missing = frame.horizontal.end.saturating_sub(occupied);
            if missing > FLOAT_CARVE_MATCH_TOLERANCE_HU
                && float_carve_evidence.iter().any(|evidence| {
                    evidence.matches_stored_rows(missing, line_segs, FLOAT_CARVE_MATCH_TOLERANCE_HU)
                })
            {
                return true;
            }
        }
    }

    // Empty carrier rows can hold a narrowed origin supplied by a surrounding
    // legacy/wrap owner even when every physical row is one complete slot.
    // With no text and no control, this paragraph provides no local geometry
    // from which a scalar Frame could derive that inset. Reflowing it full
    // width destroys the carrier contract; leave it with the external owner.
    let differs_from_frame = |segment: &crate::model::paragraph::LineSeg| {
        segment.column_start != frame.horizontal.start
            || segment.column_start.checked_add(segment.segment_width) != Some(frame.horizontal.end)
    };
    let empty_carrier = para.controls.is_empty()
        && para
            .text
            .chars()
            .all(|ch| ch.is_whitespace() || ch == '\r' || ch == '\n');
    if empty_carrier {
        return line_segs.iter().any(differs_from_frame);
    }

    // A uniform inset by itself is not proof of an unmodelled exclusion: it
    // can also be ordinary paragraph indentation. Preserve it only when the
    // caller carries a real non-TAC Square Picture/Shape anchor. #6175's
    // GroupShape path validates the anchor and lane width before it sets this
    // flag; every ordinary body frame leaves the rows eligible for reflow.
    let inset_inside_frame = |segment: &crate::model::paragraph::LineSeg| {
        let end = match segment.column_start.checked_add(segment.segment_width) {
            Some(end) => end,
            None => return false,
        };
        segment.column_start >= frame.horizontal.start
            && end <= frame.horizontal.end
            && (frame.horizontal.end - frame.horizontal.start) - segment.segment_width
                > UNIFORM_INSET_MIN_DELTA_HU
    };
    known_square_band
        && line_segs.iter().any(differs_from_frame)
        && line_segs.iter().all(inset_inside_frame)
}

/// Whether the frame's own carve reproduces every stored row — §1.4.1's
/// `(count, horzpos, horzsize)` cache key, computed before reuse.
///
/// Takes the frame by `&mut` and leaves an admitted paragraph's rows committed
/// in it, because that is what makes the answer checkable — a caller that wants
/// the frame's version of an admitted paragraph can `project_line_segs()` it.
/// A rejection restores the entry checkpoint, so the frame is exactly as it was
/// handed in.
///
/// **One reachability limit, stated rather than implied.** The multi-slot
/// FIRST..LAST comparison inside `try_admit_stored_rows` has no production
/// caller and cannot acquire one until float exclusions are wired through:
/// `ParagraphBox::frame` builds every body frame with an empty exclusion list,
/// so `models_exclusions()` is false at the only production call site and the
/// guard above turns split rows away before the comparison sees them. The
/// picture-band frame does hold exclusions, but it clears `line_segs` and
/// reflows rather than comparing. Until a float set reaches a body frame, the
/// multi-slot path is exercised by unit tests only.
pub(crate) fn stored_rows_reproduce_frame_expectation(
    para: &Paragraph,
    frame: &mut LayoutFrame,
    styles: &ResolvedStyleSet,
    dpi: f64,
) -> bool {
    frame.try_admit_stored_rows(&para.line_segs, |row| {
        stored_row_metrics(para, styles, dpi, row)
    })
}

/// Report a cache-key mismatch already found by the production admission gate.
///
/// Off unless `RHWP_DIAG_STORED_ROW_KEY` is set, so the production path pays
/// one `var_os` and no allocation. Probes a clone: a report must not be able to
/// move the frame it is reporting on.
fn report_stored_row_key_mismatch(
    para: &Paragraph,
    frame: &LayoutFrame,
    styles: &ResolvedStyleSet,
    dpi: f64,
) {
    if std::env::var_os("RHWP_DIAG_STORED_ROW_KEY").is_none() {
        return;
    }
    let mut probe = frame.clone();
    if !stored_rows_reproduce_frame_expectation(para, &mut probe, styles, dpi) {
        eprintln!(
            "DIAG_STORED_ROW_KEY mismatch rows={} stored=[{}]",
            para.line_segs.len(),
            para.line_segs
                .iter()
                .map(|segment| format!("{}+{}", segment.column_start, segment.segment_width))
                .collect::<Vec<_>>()
                .join(" "),
        );
    }
}

/// This mirrors `float_placement::horizontal_range`'s `HorzRelTo::Para`
/// rule: the host's left paragraph margin shifts the object reference, but
/// the right text margin does not shrink it.
fn picture_band_paragraph_reference(
    column_horizontal: &Range<i32>,
    host_margin_left: i32,
) -> Option<Range<i32>> {
    let start = column_horizontal.start.saturating_add(host_margin_left);
    (start < column_horizontal.end).then_some(start..column_horizontal.end)
}

/// Lay out one proven non-TAC Picture/Square band without reading stored
/// `LineSeg` geometry. One `LayoutFrame` remains live from the Picture's
/// source anchor through the first full-width paragraph boundary.
///
/// This is intentionally a fail-closed transaction. It accepts one host
/// Picture, treats only TAC Equations as inline flow, and rejects any
/// paragraph boundary that would require another layout owner.
///
/// Takes the column width in **pixels**, because that is what makes the
/// paragraph box here the same object the body path builds. It used to take
/// HWPUNIT and derive its own horizontal range as
/// `column_width_hwp - px_to_hwpunit(margin_right)`, where `ParagraphBox::body`
/// computes `px_to_hwpunit(column_width_px - margin_right_px)` — one truncation
/// against two. Those disagree by one HWPUNIT often enough to matter, and the
/// geometry pitch turns a one-unit disagreement into **four** whenever it
/// straddles a multiple of the pitch, because flooring `x - 1` where `x ≡ 0`
/// gives `x - 4`. Both routes publish `line_segs` that are persisted, so the
/// same paragraph could be written to disk with two different
/// `segment_width`s depending on whether a float was in its band.
///
/// The *column* box stays a local range rather than becoming a `ParagraphBox`:
/// float placement needs the column's own edges, unindented by paragraph
/// margins ([`picture_band_paragraph_reference`],
/// `float_placement::resolve_picture_exclusion`), and that is not what
/// `ParagraphBox` models. Stretching the type to cover both would put the
/// two coordinate systems back into one object, which is the confusion it
/// exists to prevent.
pub(crate) fn layout_picture_band(
    paragraphs: &[Paragraph],
    host_index: usize,
    column_width_px: f64,
    styles: &ResolvedStyleSet,
    dpi: f64,
    // [#6202] 용지 기준(`Paper`/`Page`) 어울림 개체를 재는 데 필요한 본문 상자의 용지 원점.
    paper_origin_px: (f64, f64),
) -> Option<PictureBandLayout> {
    let host = paragraphs.get(host_index)?;
    let column_horizontal = 0..px_to_hwpunit(column_width_px, dpi);
    let margins_for = |paragraph: &Paragraph| {
        let style = styles.para_styles.get(paragraph.para_shape_id as usize);
        (
            style.map(|value| value.margin_left).unwrap_or(0.0),
            style.map(|value| value.margin_right).unwrap_or(0.0),
        )
    };
    // `body_for_style`, like every other body route. An earlier revision used
    // bare `body` here on the argument that the list-origin blocker was a
    // separate decision — that was scope deferral, not a reason, and it left
    // this route publishing a different origin from the edit route for the same
    // list paragraph.
    let box_for = |paragraph: &Paragraph| {
        let paragraph_box = ParagraphBox::body_for_style(
            column_width_px,
            styles.para_styles.get(paragraph.para_shape_id as usize),
            dpi,
        );
        // Supersedes the old `(start < end)` test, and is strictly stronger:
        // that one ran before the geometry pitch, so a base of width 1..3 with
        // a misaligned left edge passed it and then inverted.
        paragraph_box.is_usable().then_some(paragraph_box)
    };
    let host_box = box_for(host)?;
    let host_horizontal = host_box.effective();
    let host_margin_left = px_to_hwpunit(margins_for(host).0, dpi);
    let host_paragraph_horizontal =
        picture_band_paragraph_reference(&column_horizontal, host_margin_left)?;

    let mut host_pictures = host
        .controls
        .iter()
        .enumerate()
        .filter_map(|(index, control)| match control {
            Control::Picture(picture) if !picture.common.treat_as_char => {
                Some((index, picture.as_ref()))
            }
            _ => None,
        });
    let (picture_control_index, picture) = host_pictures.next()?;
    if host_pictures.next().is_some() {
        return None;
    }

    // A paragraph-relative Picture starts at its control's raw UTF-16 stream
    // position, not necessarily at the first visible character. Lay out a
    // clean, full-width host first so the anchor row has no stored-LineSeg
    // dependency.
    let picture_raw_start = host
        .control_utf16_positions()
        .get(picture_control_index)
        .copied()?;
    let mut anchor_input = host.clone();
    anchor_input.line_segs.clear();
    let mut anchor_frame = host_box.frame(0);
    let anchor_rows = layout_paragraph_in_frame(&anchor_input, &mut anchor_frame, styles, dpi)?;
    let anchor_top = anchor_rows
        .iter()
        .rfind(|row| row.text_start <= picture_raw_start)
        .map(|row| row.vertical_pos)?;

    let exclusion = crate::renderer::float_placement::resolve_picture_exclusion(
        picture,
        column_horizontal.clone(),
        host_paragraph_horizontal,
        anchor_top,
        crate::renderer::float_placement::PaperOrigin {
            body_left: px_to_hwpunit(paper_origin_px.0, dpi),
            body_top: px_to_hwpunit(paper_origin_px.1, dpi),
            // 밴드는 host 문단에서 시작한다 — 그 문단의 저장 절대 위치가 로컬 원점이다.
            band_abs_top: host
                .line_segs
                .iter()
                .find(|seg| seg.tag & 0x8000_0000 == 0)
                .map(|seg| seg.vertical_pos)
                .unwrap_or(0),
        },
    )?;
    let exclusion_end = exclusion.vertical.end;
    let mut frame = host_box.frame_with(0, vec![exclusion]);
    let mut line_segs = Vec::new();
    let mut space_metrics = Vec::new();

    for (paragraph_index, paragraph) in paragraphs.iter().enumerate().skip(host_index) {
        if frame.top >= exclusion_end {
            break;
        }

        let paragraph_style = styles.para_styles.get(paragraph.para_shape_id as usize);
        if paragraph.column_type != ColumnBreakType::None
            || paragraph_style.is_some_and(|style| {
                style.spacing_before.abs() > f64::EPSILON
                    || style.spacing_after.abs() > f64::EPSILON
                    || style.page_break_before
            })
            || box_for(paragraph)?.effective() != host_horizontal
            || (paragraph_index != host_index
                && paragraph.controls.iter().any(|control| {
                    matches!(control, Control::Picture(picture) if !picture.common.treat_as_char)
                }))
        {
            return None;
        }

        let mut input = paragraph.clone();
        // A picture-band projection is freshly computed implementation state,
        // even when the source paragraph had authentic cached rows. Clearing
        // the cache prevents row-local flags from leaking and keeps vpos ladder
        // repair from treating the fresh zero-origin row as a saved reset.
        input.line_segs.clear();
        let first_row = frame.row_count();
        let paragraph_lines = layout_paragraph_in_frame(&input, &mut frame, styles, dpi)?;
        space_metrics.push(frame.project_space_metrics_since(first_row));
        line_segs.push(paragraph_lines);
    }

    (!line_segs.is_empty() && frame.top >= exclusion_end).then_some(PictureBandLayout {
        paragraph_range: host_index..host_index + line_segs.len(),
        line_segs,
        space_metrics,
    })
}

/// 문단의 line_segs를 텍스트 내용과 **문단 상자**에 맞게 재계산한다.
///
/// 텍스트 편집(삽입/삭제) 후 호출하여 줄 바꿈을 재배치한다.
///
/// 인자는 폭이 아니라 [`ParagraphBox`] 다 — 호출자가 자기 좌표계를 말해야 한다.
/// 폭만 받던 종전 계약은 원점을 잃었고, 그 결과 본문 편집이 `column_start=0`,
/// `segment_width=가용폭` 을 발행해 HWP 의 저장 기록(열 기준 `column_start=여백`)
/// 과도, 렌더 프레임이 깎는 상자와도 어긋났다.
pub(crate) fn reflow_line_segs(
    para: &mut Paragraph,
    paragraph_box: ParagraphBox,
    styles: &ResolvedStyleSet,
    dpi: f64,
) {
    let _ = reflow_line_segs_impl(para, paragraph_box, styles, dpi, None, false, true);
}

/// 셀 분할로 저장 폭이 stale해진 문단을 다시 조판한다.
///
/// 한컴은 좁아진 셀에서만 본문 뒤의 inline control을 별도 source line으로 저장한다.
/// 이 규칙을 일반 reflow에 적용하면 원본 문서의 이미 권위적인 control host line까지
/// 분리되어 pagination이 달라진다 (#4138/#2424). 호출자는 split 직후 stale-cell
/// 복구 경로로 한정한다.
pub(crate) fn reflow_line_segs_after_cell_split(
    para: &mut Paragraph,
    paragraph_box: ParagraphBox,
    styles: &ResolvedStyleSet,
    dpi: f64,
) {
    let _ = reflow_line_segs_impl(para, paragraph_box, styles, dpi, None, true, true);
}

/// 저장 LINE_SEG가 유효한 셀 텍스트 편집은 수정된 줄 이전의 경계를 그대로 둔다.
///
/// 한컴은 중간 줄의 짧은 edit에서 문단 전체를 다시 나누지 않는다. prefix 경계를 다시
/// 계산하면 뒤 줄의 가용 폭이 인위적으로 커져 실제 HWP 저장본과 다른 다음 줄 전환을 만들 수
/// 있다. 단, prefix가 유효한 token 경계일 때만 보존하며, 합성 문단·첫 줄 edit·inline control은
/// 기존 full reflow로 안전하게 폴백한다.
pub(crate) fn reflow_line_segs_after_cell_text_edit(
    para: &mut Paragraph,
    paragraph_box: ParagraphBox,
    styles: &ResolvedStyleSet,
    dpi: f64,
    edit_char_offset: usize,
    natural_break_cell: bool,
) -> bool {
    // An explicit edit may retain a valid native prefix, never a prefix whose
    // own exact advances contradict the current BREAK frame. This is a real
    // mutation boundary; the read-only renderer does not publish source rows.
    let preserve_prefix = !(natural_break_cell
        && owned_break_cell_row_overflows(para, &paragraph_box, styles));
    reflow_line_segs_impl(
        para,
        paragraph_box,
        styles,
        dpi,
        preserve_prefix.then_some(edit_char_offset),
        false,
        true,
    )
}

/// 저장 `LINE_SEG` 사다리가 배치 권위를 갖는 구역의 합성 문단을 재조판한다.
///
/// 익명화·부분 편집으로 저장 줄이 빠졌어도 새 개체 줄의 간격 기준은
/// 호스트 글자모양이다. 저장 좌표와의 혼합은 소비 경로에서 구분하며,
/// 쪽수 핀을 맞추기 위해 글자 크기를 고정 기본값으로 낮추지 않는다.
/// 전면 합성 문서는 `reflow_line_segs` 를 쓴다.
pub(crate) fn reflow_line_segs_in_stored_section(
    para: &mut Paragraph,
    paragraph_box: ParagraphBox,
    styles: &ResolvedStyleSet,
    dpi: f64,
) {
    let _ = reflow_line_segs_impl(para, paragraph_box, styles, dpi, None, false, true);
}

fn reflow_line_segs_impl(
    para: &mut Paragraph,
    paragraph_box: ParagraphBox,
    styles: &ResolvedStyleSet,
    dpi: f64,
    preserve_prefix_for_edit: Option<usize>,
    split_stale_cell_reflow: bool,
    object_line_font_basis: bool,
) -> bool {
    // An impossible box publishes nothing, and this must be the first thing
    // that happens — before the memo invalidation below, which is already a
    // mutation.
    //
    // The render path has refused since it had a box to refuse
    // (`recompose_stored_lines_in_frame`); the edit path never did, so a
    // paragraph whose margins exceed its column reached `make_line_seg` with a
    // negative `seg_width_hwp` and published `segment_width < 0` on every row.
    // That is not a rendering artifact: `segment_width` goes to disk through
    // `serializer::body_text`'s `write_i32` and raw into the HWPX
    // `linesegarray`, so the corrupt extent is written to the file. Both paths
    // now ask `ParagraphBox::is_usable()`, which is where the reasoning for
    // refusing rather than flooring lives.
    //
    // `false` is the right return: it is the "prefix was not preserved" value,
    // so the one consumer that reads it (`reflow_cell_paragraph`) takes its
    // conservative branch.
    if !paragraph_box.is_usable() {
        return false;
    }
    // [#4677] 줄을 다시 계산하면 이전에 붙여 둔 조판 전용 보강 줄은 사라진다 — 표식을
    // 남겨 두면 실제 줄을 저장에서 잘라 내게 된다.
    para.layout_only_fill_lines = 0;
    let orig = para.line_segs.first().cloned();
    // 상자 하나가 발행 기록과 프레임 둘 다의 출처다 — 종전엔 `segment_width` 를
    // 폭에서, 프레임 상자를 또 폭에서 따로 만들어 둘이 어긋날 수 있었다.
    let published_horizontal = paragraph_box.effective();
    let seg_width_hwp = paragraph_box.width_hwp();
    // [#7418·#7436] 판정 폭에서만 목록 마커 폭을 뺀다 — 프레임 채움
    // (`layout_paragraph_in_frame`)과 같은 계약이다. 게시 폭(`seg_width_hwp`)은 마커 자리를 포함한다.
    let para_style = styles.para_styles.get(para.para_shape_id as usize);
    let indent_px = if reflow_indentation_pattern(para_style, &para.line_segs) == (false, false) {
        0.0
    } else {
        para_style.map_or(0.0, |style| style.indent)
    };
    let (marker_hang_px, indent_px) = list_marker_breaker_box(para, styles, indent_px);
    let available_width_px = (paragraph_box.width_px(dpi) - marker_hang_px).max(1.0);

    // ParaPr의 줄간격 설정 (합성 LineSeg에서 line_spacing 계산에 사용)
    let para_style = styles.para_styles.get(para.para_shape_id as usize);
    let ls_type = para_style
        .map(|s| s.line_spacing_type)
        .unwrap_or(LineSpacingType::Percent);
    let ls_value = para_style.map(|s| s.line_spacing).unwrap_or(160.0);

    // 줄별 max_font_size에 따라 line_height/text_height/baseline_distance를 계산
    // 한컴은 줄마다 최대 폰트 크기에 맞게 다른 치수를 사용
    let make_line_seg = |utf16_start: u32, max_font_size: f64| -> LineSeg {
        let fs = if max_font_size > 0.0 {
            max_font_size
        } else {
            12.0
        };
        let line_height_hwp = font_size_to_line_height(fs, dpi);
        let text_height_hwp = line_height_hwp;
        let baseline_distance_hwp = baseline_distance_hwp(line_height_hwp);
        let line_spacing_hwp = compute_line_spacing_hwp(ls_type, ls_value, line_height_hwp, dpi);
        // [Task #1811] 원본 linesegarray 부재(orig=None) 시 합성 seg 에 구현속성
        // 태그를 부여 — vpos 보정 등에서 실제 저장 증거와 구분한다 (컨버터의
        // 합성 lineseg flags=0x8000_0000 관례와 정합).
        let orig_tag = orig
            .as_ref()
            .map(|ls| ls.tag)
            .unwrap_or(LineSeg::TAG_SINGLE_SEGMENT_LINE | LineSeg::TAG_IMPLEMENTATION_PROPERTY);
        LineSeg {
            text_start: utf16_start,
            line_height: line_height_hwp,
            text_height: text_height_hwp,
            baseline_distance: baseline_distance_hwp,
            line_spacing: line_spacing_hwp,
            column_start: published_horizontal.start,
            segment_width: seg_width_hwp,
            tag: if orig_tag != 0 {
                orig_tag
            } else {
                LineSeg::TAG_SINGLE_SEGMENT_LINE
            },
            ..Default::default()
        }
    };

    if para.text.is_empty() {
        // [#4677] 각 인라인 개체의 **UTF-16 오프셋**을 함께 들고 다닌다. lineseg 의
        // `text_start` 는 PARA_TEXT 안의 코드유닛 위치이고 확장 제어문자 하나가 8 유닛을
        // 차지하므로, 컨트롤 인덱스를 그대로 쓰면 둘째 줄이 첫 제어문자 블록 한가운데(=1)를
        // 가리킨다. 한글 2022 는 그런 문서를 열 때 본문을 통째로 버리고 빈 1쪽으로 연다
        // (10k 전수 스윕의 x2h 본문 소실군 — 저장본은 rhwp 재파싱만 통과하는 함정).
        let inline_sizes = para
            .controls
            .iter()
            .scan(0u32, |utf16_pos, ctrl| {
                let start = *utf16_pos;
                if ctrl.occupies_ctrl_char_slot() {
                    *utf16_pos += CTRL_CHAR_CODE_UNITS;
                }
                Some((start, ctrl))
            })
            .filter_map(|(start, ctrl)| {
                inline_control_size_hwp(ctrl).map(|(width, height)| {
                    let height = match ctrl {
                        Control::Table(table) => height
                            .saturating_add(i32::from(table.outer_margin_top))
                            .saturating_add(i32::from(table.outer_margin_bottom)),
                        _ => height,
                    };
                    (start, (width, height))
                })
            })
            .collect::<Vec<_>>();
        if !inline_sizes.is_empty() {
            let max_line_width = seg_width_hwp.max(1);
            let mut line_specs: Vec<(u32, i32, i32)> = Vec::new();
            let mut line_start = 0u32;
            let mut line_width = 0i32;
            let mut line_height = 0i32;

            for (utf16_start, (ctrl_width, ctrl_height)) in inline_sizes.iter().copied() {
                if line_width > 0 && line_width + ctrl_width > max_line_width {
                    line_specs.push((line_start, line_width, line_height));
                    line_start = utf16_start;
                    line_width = 0;
                    line_height = 0;
                }
                line_width += ctrl_width;
                line_height = line_height.max(ctrl_height);
            }
            line_specs.push((line_start, line_width, line_height));

            let orig_line_segs = para.line_segs.clone();
            let mut new_line_segs = Vec::with_capacity(line_specs.len());
            // 개체만 있는 줄도 줄간격 기준은 **그 문단의 글자모양 크기**다. 한컴은 개체 높이를
            // line_height 에만 반영하고 spacing 은 글자 높이로 계산한다(정답지 개체 줄 18/18:
            // 165%·14pt 문단의 표 줄 spacing 912 = 1400×0.65, 160%·10pt 문단의 그림 줄 600 = 1000×0.6).
            // 0.0 을 넘기면 내부 기본 12px(900 HU)로 떨어져 585 가 되고, 쪽마다 327 HU 씩 덜 쌓인다.
            //
            // 음수 Percent 간격은 글자 크기에 대한 줄 전진 감소량이다.
            // 저장 줄 사이의 보충 줄에서도 실제 글자 크기로 환산해야 한다.
            // 양수 간격의 저장-사다리 호환 경로는 이번 압축 간격 보정과 분리한다.
            let negative_percent_spacing =
                matches!(ls_type, LineSpacingType::Percent) && ls_value < 100.0;
            let paragraph_font_px = if object_line_font_basis || negative_percent_spacing {
                paragraph_font_size_px(para, styles).unwrap_or(12.0)
            } else {
                0.0
            };
            for (line_idx, (start_pos, _line_width, height_hwp)) in
                line_specs.into_iter().enumerate()
            {
                let mut seg = make_line_seg(start_pos, paragraph_font_px);
                if let Some(template) = orig_line_segs
                    .get(line_idx)
                    .or_else(|| orig_line_segs.first())
                {
                    seg.line_spacing = template.line_spacing;
                    seg.segment_width = if template.segment_width > 0 {
                        template.segment_width
                    } else {
                        seg_width_hwp
                    };
                    seg.tag = if template.tag != 0 {
                        template.tag
                    } else {
                        seg.tag
                    };
                }
                apply_inline_control_line_height(&mut seg, height_hwp);
                new_line_segs.push(seg);
            }

            let mut vpos = orig.as_ref().map(|ls| ls.vertical_pos).unwrap_or(0);
            for seg in &mut new_line_segs {
                seg.vertical_pos = vpos;
                vpos += seg.line_height.saturating_add(seg.line_spacing);
            }
            para.replace_line_segs(new_line_segs);
        } else {
            // 빈 문단도 활성 글자 모양의 크기로 줄을 만든다. 앞 문단 LINE_SEG의
            // 치수를 복사하면 TAC 그림 높이까지 상속되므로 vpos 원점만 보존한다.
            let font_size = paragraph_font_size_px(para, styles).unwrap_or(12.0);
            let mut seg = make_line_seg(0, font_size);
            if let Some(template) = orig.as_ref() {
                seg.vertical_pos = template.vertical_pos;
                // 폭0인 빈 floating table 호스트는 개체 앵커다. 본문 글줄의
                // 가용 폭으로 바꾸면 저장 후 바깥 여백의 소유가 사라진다.
                // TAC와 글자가 있는 호스트는 위의 실제 글줄 경로를 따른다.
                if template.segment_width == 0
                    && matches!(para.controls.as_slice(), [Control::Table(table)]
                        if !table.common.treat_as_char)
                {
                    seg.segment_width = 0;
                }
            }
            if let Some(height_hwp) = inline_control_line_height_hwp(para) {
                apply_inline_control_line_height(&mut seg, height_hwp);
            }
            mark_indented_lines(
                std::slice::from_mut(&mut seg),
                0,
                para_style,
                &para.line_segs,
            );
            para.replace_line_segs(vec![seg]);
        }
        return false;
    }

    let text_chars: Vec<char> = para.text.chars().collect();
    let text_len = text_chars.len();
    let inline_controls = flow_inline_controls(para);

    // 문단 스타일에서 들여쓰기 및 줄 나눔 설정 조회 (들여쓰기는 목록 마커를 얹은 값)
    let para_style = styles.para_styles.get(para.para_shape_id as usize);
    let english_break_unit = para_style.map(|s| s.english_break_unit).unwrap_or(0);
    let korean_break_unit = para_style.map(|s| s.korean_break_unit).unwrap_or(0);
    let condense_min_space = para_style.map(|s| s.condense_min_space).unwrap_or(0);
    let tab_width = para_style.map(|s| s.default_tab_width).unwrap_or(0.0);

    // 토큰화 → 줄 채움 → LineSeg 생성
    let reflow_space_metric = if split_stale_cell_reflow {
        SpaceMetric::HancomRegenerated
    } else {
        SpaceMetric::Stored
    };
    let mut tokens = tokenize_paragraph_with_regenerated_space_metric(
        &text_chars,
        &para.char_offsets,
        &para.char_shapes,
        styles,
        english_break_unit,
        korean_break_unit,
        // 종전 동작 보존: 이 인자가 곧 공백 규칙이었다.
        reflow_space_metric,
        &inline_controls,
    );
    let prepared_kerning = prepare_paragraph_kerning(
        para,
        &text_chars,
        styles,
        reflow_space_metric,
        &inline_controls,
    )
    .and_then(|prepared| {
        apply_paragraph_kerning_to_tokens(&mut tokens, &prepared.measurement).map(|_| prepared)
    });
    // 저장 LINE_SEG 기반 incremental edit는 앞선 줄을 유지한다. LINE_SEG start가 현재
    // char_offsets와 token 경계 모두에 정확히 대응할 때만 suffix reflow를 허용한다.
    // 그렇지 않으면 (HWPX 합성 boundary, inline control, token 내부 boundary 등) full
    // reflow가 보수적인 경로다.
    let original_line_segs = para.line_segs.clone();
    let token_start_idx = |token: &BreakToken| match token {
        BreakToken::Text { start_idx, .. } => *start_idx,
        BreakToken::Space { idx, .. }
        | BreakToken::Tab { idx, .. }
        | BreakToken::LineBreak { idx } => *idx,
    };
    let mut preserved_prefix = Vec::new();
    let mut reflow_start_idx = 0usize;
    let mut reflow_is_first_line = true;
    let mut token_start = 0usize;
    // `DocumentCore::new_empty()`의 기본 source_format도 Hwp이므로 형식만으로는
    // 합성 test/new-document LineSeg를 native 저장 경계로 오인할 수 없다. 실제 HWP
    // LINE_SEG가 가진 line-height와, 0에서 시작해 엄격히 증가하는 start가 모두
    // 있어야 prefix를 권위 경계로 채택한다. 범위 삭제는 삭제된 여러 줄을 같은
    // start로 접을 수 있으므로 duplicate/역행 경계는 full reflow가 안전하다.
    let has_valid_orig = original_line_segs
        .iter()
        .all(|seg| seg.tag & LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0);
    let authoritative_line_seg_prefix = has_valid_orig
        && original_line_segs
            .first()
            .is_some_and(|seg| seg.text_start == 0)
        && original_line_segs
            .windows(2)
            .all(|pair| pair[0].text_start < pair[1].text_start);
    if para.controls.is_empty() && authoritative_line_seg_prefix {
        if let Some(edit_char_offset) = preserve_prefix_for_edit {
            // Delete-at-end는 삭제 뒤 `char_offsets`에 caret 위치가 없지만, 텍스트
            // UTF-16 끝은 정확한 token boundary다. 삭제된 마지막 글자가 있던 줄의
            // 앞줄부터 다시 채워야 5→4 shrink도 표현할 수 있다.
            let edit_is_document_end = edit_char_offset == text_len;
            let edit_utf16 = para
                .char_offsets
                .get(edit_char_offset)
                .copied()
                .or_else(|| edit_is_document_end.then(|| para.text.encode_utf16().count() as u32));
            let affected_line = edit_utf16.and_then(|offset| {
                let line = original_line_segs
                    .iter()
                    .rposition(|seg| seg.text_start <= offset)?;
                if edit_is_document_end && original_line_segs[line].text_start < offset {
                    // 삭제 대상이 들어 있던 마지막 줄도 다시 채워야 직전 줄에
                    // 합쳐질 수 있다. line=0이면 prefix 없이 full reflow한다.
                    line.checked_sub(1)
                } else {
                    Some(line)
                }
            });
            if let Some(affected_line) = affected_line.filter(|line| *line > 0) {
                let reflow_utf16 = original_line_segs[affected_line].text_start;
                let reflow_char_idx = para
                    .char_offsets
                    .iter()
                    .position(|offset| *offset == reflow_utf16);
                let suffix_token_start = reflow_char_idx.and_then(|char_idx| {
                    tokens
                        .iter()
                        .position(|token| token_start_idx(token) == char_idx)
                        .map(|token_idx| (char_idx, token_idx))
                });
                if let Some((char_idx, token_idx)) = suffix_token_start {
                    preserved_prefix = original_line_segs[..affected_line].to_vec();
                    reflow_start_idx = char_idx;
                    reflow_is_first_line = false;
                    token_start = token_idx;
                }
            }
        }
    }

    // The frame owns physical-row recurrence only for an ordinary scalar
    // reflow. Stored-prefix edits, split-cell recovery, empty paragraphs, and
    // inline controls retain their established specialized paths below.
    let frame_eligible = !split_stale_cell_reflow
        && preserve_prefix_for_edit.is_none()
        && !para.text.is_empty()
        // Section/column definitions have no inline width. Their geometry is
        // already resolved by paragraph_box, exactly as on NO_LS import.
        // Sending only these markers to the old tolerant scalar path made a
        // fresh first paragraph change its partition when reopened as HWPX.
        // Objects, fields and other marker classes keep their existing owners.
        && para.controls.iter().all(|control| matches!(control,
            Control::SectionDef(_) | Control::ColumnDef(_)))
        && preserved_prefix.is_empty();
    if frame_eligible {
        // 편집 프레임과 렌더 프레임이 이제 같은 상자에서 나온다 — 종전엔 이쪽만
        // `0..seg_width_hwp`(문단 기준, 미스냅)라 열 기준 렌더 프레임과 어긋났다.
        let mut frame =
            paragraph_box.frame(orig.as_ref().map(|line| line.vertical_pos).unwrap_or(0));
        if let Some(projected) = layout_paragraph_in_frame(para, &mut frame, styles, dpi) {
            para.replace_line_segs_with_space_metrics(projected, frame.project_space_metrics());
            return false;
        }
    }

    let mut kerning_transaction = prepared_kerning
        .as_ref()
        .map(|prepared| prepared.context.layout_session());
    let mut kerning_break_session = prepared_kerning.as_ref().and_then(|prepared| {
        crate::renderer::kerning::KerningParagraphBreakSession::new(
            &para.text,
            &prepared.scalar_styles,
            &prepared.hard_boundaries,
            &prepared.measurement,
            kerning_transaction.as_mut()?,
        )
        .ok()
    });
    let mut line_breaks = fill_lines(
        &tokens[token_start..],
        &text_chars,
        available_width_px,
        indent_px,
        tab_width,
        korean_break_unit,
        condense_min_space,
        &resolved_letter_spacing_px(&text_chars, &para.char_offsets, &para.char_shapes, styles),
        reflow_start_idx,
        reflow_is_first_line,
        paragraph_has_integral_gulimche_advances(para, styles, reflow_space_metric)
            .then_some(seg_width_hwp.max(75)),
        kerning_break_session.as_mut(),
    );
    let kerning_failed = kerning_break_session
        .as_ref()
        .and_then(|session| session.failed_reason())
        .is_some();
    drop(kerning_break_session);
    drop(kerning_transaction);
    if kerning_failed {
        line_breaks = fill_lines(
            &tokens[token_start..],
            &text_chars,
            available_width_px,
            indent_px,
            tab_width,
            korean_break_unit,
            condense_min_space,
            &resolved_letter_spacing_px(&text_chars, &para.char_offsets, &para.char_shapes, styles),
            reflow_start_idx,
            reflow_is_first_line,
            paragraph_has_integral_gulimche_advances(para, styles, reflow_space_metric)
                .then_some(seg_width_hwp.max(75)),
            None,
        );
    }
    // TAC 표의 호스트를 편집하면 이전 줄 경계는 더 이상 권위가 없다.
    // 표 앞의 실제 텍스트와 표가 남은 폭에 함께 들어가는지 판정하고, 실패하면
    // 표 앵커에서 물리 줄을 발행한다. 배치도 그 줄을 소유 줄로 사용한다 (#7491).
    // 기존 셀 분할 경로와 달리 저장본에서 들여쓰지 않은 본문 표 호스트는 새로
    // 발행할 bit20 기록과 같은 폭을 사용한다 (#6190 편집 후 한컴 PDF).
    let edited_tac_table = supports_tac_table_band_frame_controls(para);
    let table_indent_px = if edited_tac_table
        && reflow_indentation_pattern(para_style, &original_line_segs) == (false, false)
    {
        0.0
    } else {
        indent_px
    };
    // 실제 측정한 표 본체와 바깥 여백을 줄 폭과 줄 높이에서 함께 사용한다.
    let occupied_controls: Vec<_> =
        if split_stale_cell_reflow || edited_tac_table || inline_controls.is_empty() {
            para.controls
                .iter()
                .zip(para.control_text_positions())
                .filter_map(|(control, position)| {
                    let (width, height) = inline_control_occupied_size_hwp(control, styles, dpi)?;
                    Some((position, width, height))
                })
                .collect()
        } else {
            Vec::new()
        };
    let forced_inline_line = (split_stale_cell_reflow || edited_tac_table)
        .then(|| {
            inline_control_requires_own_line(
                para,
                &occupied_controls,
                &text_chars,
                &line_breaks,
                available_width_px,
                table_indent_px,
                reflow_is_first_line,
                styles,
                reflow_space_metric,
            )
        })
        .flatten();
    let floating_anchors = floating_anchor_char_font_sizes(para, styles);
    let preserved_prefix_len = preserved_prefix.len();
    let mut new_line_segs: Vec<LineSeg> = preserved_prefix;
    for (line_idx, lb) in line_breaks.iter().enumerate() {
        let utf16_start = if new_line_segs.is_empty() {
            0 // 첫 번째 줄의 text_start는 항상 0 (문단 시작)
        } else {
            char_index_to_utf16_offset(para, lb.start_idx)
        };
        let fs = if lb.max_font_size > 0.0 {
            lb.max_font_size
        } else {
            paragraph_font_size_px(para, styles).unwrap_or(12.0)
        };
        // 줄 안에 놓인 비-글자취급 개체의 기준 문자도 그 줄의 글자다.
        let fs = fs.max(floating_anchor_font_size_px(
            &floating_anchors,
            lb.start_idx..lb.end_idx,
            lb.end_idx == text_len,
            text_len,
        ));
        let mut text_seg = make_line_seg(utf16_start, fs);
        if forced_inline_line.is_some_and(|(position, _)| position == lb.start_idx) {
            let (_, height_hwp) = forced_inline_line.expect("checked inline control");
            apply_inline_control_line_height(&mut text_seg, height_hwp);
        }
        if let Some(height_hwp) = inline_controls
            .iter()
            .filter(|control| {
                (lb.start_idx..lb.end_idx).contains(&control.char_position)
                    || (lb.end_idx == text_len && control.char_position == text_len)
            })
            .map(|control| control.height_hwp)
            .max()
        {
            apply_inline_control_line_height(&mut text_seg, height_hwp);
        }
        new_line_segs.push(text_seg);

        // control이 text line 한가운데/끝에 있으면 먼저 text prefix를 확정하고,
        // control offset에서 다음 LineSeg를 삽입한다. 단순히 vector 끝에 붙이면
        // 중간 nested table 뒤의 text가 control보다 앞에서 그려진다.
        let control_after_text = forced_inline_line.is_some_and(|(position, _)| {
            position > lb.start_idx
                && (position < lb.end_idx
                    || (position == lb.end_idx && line_idx + 1 == line_breaks.len()))
        });
        if control_after_text {
            let (position, height_hwp) = forced_inline_line.expect("checked inline control");
            let mut control_seg = make_line_seg(char_index_to_utf16_offset(para, position), fs);
            apply_inline_control_line_height(&mut control_seg, height_hwp);
            new_line_segs.push(control_seg);
        }
    }

    if new_line_segs.is_empty() {
        new_line_segs.push(make_line_seg(
            0,
            paragraph_font_size_px(para, styles).unwrap_or(12.0),
        ));
    }

    if forced_inline_line.is_none() && inline_controls.is_empty() {
        for &(position, _, height_hwp) in &occupied_controls {
            // 명시적 개행으로 정해진 개체 줄에 높이를 싣는다. 최초 줄에 일괄
            // 적용하면 표 앞 제목이 표 줄로 오인되어 표 뒤로 재배치된다.
            let line_index = line_breaks
                .iter()
                .rposition(|line| line.start_idx <= position)
                .unwrap_or(0);
            if let Some(seg) = new_line_segs.get_mut(preserved_prefix_len + line_index) {
                apply_inline_control_line_height(seg, height_hwp);
            }
        }
    }

    // vertical_pos 누적 계산 (각 줄의 문단 내 Y 오프셋)
    // 원본 첫 LineSeg의 vertical_pos를 보존하여 vpos 체계 연속성 유지
    // (layout.rs의 vpos 보정이 문단 간 vpos 연속성을 가정하므로)
    let mut vpos = if preserved_prefix_len > 0 {
        let last = &new_line_segs[preserved_prefix_len - 1];
        last.vertical_pos
            .saturating_add(last.line_height)
            .saturating_add(last.line_spacing)
    } else {
        orig.as_ref().map(|ls| ls.vertical_pos).unwrap_or(0)
    };
    for i in preserved_prefix_len..new_line_segs.len() {
        new_line_segs[i].vertical_pos = vpos;
        vpos += new_line_segs[i].line_height + new_line_segs[i].line_spacing;
    }
    mark_indented_lines(
        &mut new_line_segs[preserved_prefix_len..],
        preserved_prefix_len,
        para_style,
        &original_line_segs,
    );

    let space_metrics = new_line_segs
        .iter()
        .enumerate()
        .map(|(index, line)| {
            let rule = if index < preserved_prefix_len {
                para.line_space_metric(index)
            } else {
                reflow_space_metric
            };
            (line.text_start, rule)
        })
        .collect();
    para.replace_line_segs_with_space_metrics(new_line_segs, space_metrics);
    preserved_prefix_len > 0
}

/// 구역 내 문단들의 vertical_pos를 순차적으로 재계산한다.
///
/// `start_para`부터 구역 끝까지 각 문단의 vpos를 이전 문단의 vpos_end 기준으로 재계산.
/// 표 등 특수 문단의 line_height는 보존하고 vpos만 갱신한다.
///
/// [Task #2299] 저장 vpos 리셋(단/쪽 경계 인코딩) 보존: 편집발 재계산이 구역 전체를
/// 선형 누적 좌표로 이어붙이면 다단 zone 의 단-상대 리셋(급감)이 소멸해
/// typeset(#321/#470/#702)·pagination 의 단/쪽 진행 신호가 무력화된다
/// (shortcut.hwp 앞문단 편집 시 col=[0,1]→[0], 7→9쪽). 현재 문단의 저장 first 가
/// 직전 문단의 "이동 전(저장)" end 보다 감소하면 경계 인코딩으로 보고 delta=0 으로
/// 보존한다. 저장 좌표는 밴드 내 정상 흐름에서 단조 증가하므로 감소 감지에 임계가
/// 필요 없다.
///
/// 좌표 갱신은 경계 성격별로 셋으로 나뉜다.
///
/// - **리셋 경계**: delta=0 보존.
/// - **변조 인접 경계**(현재 문단이 편집 대상 `start_para` 이거나 신규
///   문단(`ignore_reset_range`)이거나, 직전 문단이 그중 하나): 직전 이동 후 end 에
///   문단 여백 gap(spacing_after + spacing_before, 셀 recalc `boundary_gaps` 동일
///   산식)을 더해 다시 잇는다. reflow/신규 생성으로 저장 gap 이 소실된 경계라
///   스타일에서 재유도한다. gap 없는 abutment 는 문단 간격을 압축해 near-top
///   리셋(#1086/#1921)의 `prev_vpos_end > 60000` 임계를 무너뜨렸다
///   (SO-SUEOP.hwpx 46→44).
/// - **미변조 연속 경계**: 직전 문단의 delta 를 그대로 캐리해 저장(또는 로드 합성
///   #927) 문단 간격을 정확히 보존한다. 스타일 gap 재유도는 저장 gap 과의
///   오차(px 왕복 절삭 ±1HU, 스타일-저장 불일치)를 밴드 전체에 누적시키고 로드
///   합성 gap-less 체인과도 어긋나므로 쓰지 않는다. delta==0 이면 순수 no-op.
///
/// 리셋 감지는 저장 좌표끼리의 비교여야 한다. 직전 문단이 변조 대상이면 그 end 는
/// 저장 좌표가 아니므로(성장 편집이 다음 문단을 가짜 리셋으로 동결시키고,
/// placeholder 는 기준을 붕괴시킨다) reflow 가 보존하는 **first** 로 비교한다.
/// 미변조 경계는 end 기준을 유지한다(연속 0-first 밴드 감지에 필요).
///
/// placeholder 저지선 2종: ① split/insert/paste 가 방금 만든 신규 문단의 vpos=0 은
/// 경계 인코딩이 아니다 — 보존하면 문단마다 가짜 쪽나눔이 생긴다
/// (test_page_boundary_with_incremental_spacing_increase 핀). 호출자가 신규 구간을
/// `ignore_reset_range` 로 지정하면 보존 없이 흐름에 연결한다(셀 경로
/// `recalculate_cell_paragraph_vpos` 의 ignore_reset_at 과 동일 취지, 다중 삽입을
/// 위해 범위형). ② lineseg 부재였다가 on-demand reflow(#177/#927)로 합성된
/// seg(TAG_IMPLEMENTATION_PROPERTY, #1811)도 보존하지 않는다.
///
/// 줄 전진량은 로드 경로(document.rs 의 vpos 체인)와 동일하게 TAC 호스트
/// 줄(lh>th)을 th 기준으로 센다 — lh 기준이면 인라인 개체 호스트의 end 가 저장
/// 후속 first 를 넘어서 가짜 리셋을 만든다.
pub(crate) fn recalculate_section_vpos(
    paragraphs: &mut [Paragraph],
    start_para: usize,
    ignore_reset_range: Option<std::ops::Range<usize>>,
    start_stored_end: Option<i32>,
    styles: &ResolvedStyleSet,
    dpi: f64,
    is_hwp3_variant: bool,
) {
 recalculate_section_vpos_with_origin(paragraphs,start_para,ignore_reset_range,start_stored_end,styles,dpi,is_hwp3_variant,None);
}
pub(crate) fn recalculate_section_vpos_with_origin(
    paragraphs: &mut [Paragraph],
    start_para: usize,
    ignore_reset_range: Option<std::ops::Range<usize>>,
    start_stored_end: Option<i32>,
    styles: &ResolvedStyleSet,
    dpi: f64,
    is_hwp3_variant: bool,
    origin_context: Option<[u8;32]>,
) {
    if paragraphs.is_empty() || start_para >= paragraphs.len() {
        return;
    }

    // 문단 경계 gap (HWPUNIT) = 앞 문단 spacing_after + 뒤 문단 spacing_before.
    // recalculate_cell_paragraph_vpos 의 boundary_gaps 와 동일 산식.
    let boundary_gap = |prev: &Paragraph, curr: &Paragraph| -> i32 {
        let spacing_after = styles
            .para_styles
            .get(prev.para_shape_id as usize)
            .map(|style| style.spacing_after)
            .unwrap_or(0.0);
        let spacing_before = styles
            .para_styles
            .get(curr.para_shape_id as usize)
            .map(|style| style.spacing_before)
            .unwrap_or(0.0);
        let spacing_before =
            crate::renderer::hwp3_variant_flow_spacing_before(spacing_before, is_hwp3_variant);
        px_to_hwpunit(spacing_after + spacing_before, dpi)
    };

    // 줄 전진량 — 로드 경로와 동일한 TAC th-관례. saturating: 조작 파일의 극단
    // spacing/좌표로 i32 가 넘치지 않게 한다 (release wasm 은 overflow-check 가
    // 없어 무음 랩 → 전 문단 오판으로 이어진다).
    let seg_advance = |ls: &LineSeg| -> i32 {
        let height = if ls.line_height > ls.text_height && ls.text_height > 0 {
            ls.text_height
        } else {
            ls.line_height
        };
        height.saturating_add(ls.line_spacing)
    };
    let seg_end = |p: &Paragraph| -> Option<i32> {
        p.line_segs
            .last()
            .map(|ls| ls.vertical_pos.saturating_add(seg_advance(ls)))
    };
    let is_ignored = |pi: usize| {
        ignore_reset_range
            .as_ref()
            .is_some_and(|range| range.contains(&pi))
    };

    // 직전 문단(마지막 비어있지 않은 lineseg 보유 문단) 인덱스.
    // start_para 이전 문단들은 이 호출에서 이동하지 않으므로 현재 좌표가 곧 저장 좌표다.
    let mut prev_idx: Option<usize> = paragraphs[..start_para]
        .iter()
        .rposition(|p| !p.line_segs.is_empty());
    let mut next_vpos = match prev_idx {
        Some(pp) => seg_end(&paragraphs[pp]).unwrap_or(0),
        // 첫 문단: 기존 vpos 유지
        None => paragraphs[start_para]
            .line_segs
            .first()
            .map(|ls| ls.vertical_pos)
            .unwrap_or(0),
    };
    // 리셋 감지 기준 — 직전 문단의 "이동 전(저장)" first/end.
    let mut orig_prev_first: Option<i32> = prev_idx
        .and_then(|pp| paragraphs[pp].line_segs.first())
        .map(|ls| ls.vertical_pos);
    let mut orig_prev_end: Option<i32> = prev_idx.and_then(|pp| seg_end(&paragraphs[pp]));
    // 직전 문단이 이번 편집의 변조 대상이었는가 + 직전 문단에 적용된 delta.
    let mut prev_modified = false;
    let mut prev_delta: i32 = 0;

    for pi in start_para..paragraphs.len() {
        if paragraphs[pi].line_segs.is_empty() {
            continue;
        }

        let para_modified = pi == start_para || is_ignored(pi);
        let current_start = paragraphs[pi].line_segs[0].vertical_pos;
        let is_original_lineseg =
            paragraphs[pi].line_segs[0].tag & LineSeg::TAG_IMPLEMENTATION_PROPERTY == 0;

        // 리셋 감지: 신규 문단(placeholder)·합성 seg 는 제외. 기준은 직전 문단의
        // "저장" 좌표여야 한다 — 직전이 편집 문단(start_para)이면 reflow 로 end 가
        // 이미 변조됐으므로 호출자가 캡처해 준 reflow 이전 저장 end 를 쓰고(성장
        // 편집의 가짜 리셋과 저장-겹침 문서의 정당한 리셋을 모두 정확히 판별),
        // 없으면 reflow 가 보존하는 first 로 보수적으로 비교한다. 신규 문단이
        // 직전이면 placeholder 라 first(=0) 기준. 미변조 경계는 end 기준을
        // 유지한다(연속 0-first 밴드 감지에 필요).
        let prev_stored_bound = if prev_idx == Some(start_para) && !is_ignored(start_para) {
            start_stored_end.or(orig_prev_first)
        } else if prev_modified {
            orig_prev_first
        } else {
            orig_prev_end
        };
        let is_reset = is_original_lineseg
            && !is_ignored(pi)
            && prev_stored_bound.is_some_and(|bound| current_start < bound);

        let delta = if is_reset {
            // 단/쪽 리셋 경계 — 저장 좌표 유지.
            0
        } else if para_modified || prev_modified {
            // 변조 인접 경계 — 이동 후 흐름에 스타일 여백 gap 으로 다시 잇는다.
            let gap = prev_idx
                .map(|pp| boundary_gap(&paragraphs[pp], &paragraphs[pi]))
                .unwrap_or(0);
            next_vpos.saturating_add(gap) - current_start
        } else {
            // 미변조 연속 경계 — 직전 delta 캐리로 기존 간격을 정확히 보존.
            prev_delta
        };

        // 다음 문단의 리셋 감지 기준은 "이동 전(저장)" first/end 로 기록한다.
        let orig_first = current_start;
        let orig_end = seg_end(&paragraphs[pi]);

        let origin_before=if delta!=0&&!para_modified{origin_context.and_then(|context|
            crate::model::native_origin_paint139::begin(&paragraphs[pi],context))}else{None};
        let expected_origin=current_start.saturating_add(delta);
        if delta != 0 {
            // 모든 LineSeg의 vpos를 delta만큼 이동
            for seg in &mut paragraphs[pi].line_segs {
                seg.vertical_pos = seg.vertical_pos.saturating_add(delta);
            }
        }

        if let Some(before)=origin_before{
            paragraphs[pi].native_origin_paint_input=crate::model::native_origin_paint139::complete(before,&paragraphs[pi],expected_origin);
        }
        // 다음 문단의 시작 vpos 계산 (이동 후 end = 저장 end + delta)
        if let Some(end) = orig_end {
            next_vpos = end.saturating_add(delta);
        }
        orig_prev_first = Some(orig_first);
        orig_prev_end = orig_end;
        prev_modified = para_modified;
        prev_delta = delta;
        prev_idx = Some(pi);
    }
}

/// [Task #2299] 문단의 흐름 end (마지막 LineSeg 의 vpos + 전진량, TAC th-관례).
/// 편집 호출자가 reflow 이전에 캡처해 `recalculate_section_vpos` 의
/// `start_stored_end` 로 전달하기 위한 헬퍼 — reflow 가 end 를 덮은 뒤에는 저장
/// 좌표를 복원할 수 없다.
pub(crate) fn paragraph_flow_end(para: &Paragraph) -> Option<i32> {
    para.line_segs.last().map(|ls| {
        let height = if ls.line_height > ls.text_height && ls.text_height > 0 {
            ls.text_height
        } else {
            ls.line_height
        };
        ls.vertical_pos
            .saturating_add(height.saturating_add(ls.line_spacing))
    })
}

/// font_size(px)를 LineSeg의 line_height(HWPUNIT)로 변환한다.
/// HWP의 LineSeg.line_height = 폰트 크기 (HWPUNIT).
/// 실증 데이터: 10pt → lh=1000, 12pt → lh=1200, 25pt → lh=2500
fn font_size_to_line_height(font_size_px: f64, dpi: f64) -> i32 {
    // Round, don't truncate. `px_to_hwpunit` is `(px * 7200 / dpi) as i32`,
    // which floors toward zero, and the px it is handed came from a HWPUNIT
    // font size in the first place — so the round trip loses a unit whenever
    // the division is inexact. Measured over 1,133,228 admitted rows, that
    // truncation is 5,012 of the 5,215 `line_height` disagreements against
    // HWP's stored records, every one of them exactly -1.
    round_px_to_hwpunit(font_size_px, dpi)
}

/// `px_to_hwpunit` with round-half-away-from-zero instead of truncation.
fn round_px_to_hwpunit(px: f64, dpi: f64) -> i32 {
    (px * 7_200.0 / dpi).round() as i32
}

/// ParaPr의 줄간격 설정으로부터 LineSeg.line_spacing(HWPUNIT)을 계산한다.
///
/// line_spacing = 현재 줄 하단 → 다음 줄 상단 사이의 추가 간격.
/// Y advance = line_height + line_spacing.
fn compute_line_spacing_hwp(
    ls_type: LineSpacingType,
    ls_value: f64,
    line_height_hwp: i32,
    dpi: f64,
) -> i32 {
    match ls_type {
        LineSpacingType::Percent => {
            // ls_value = 비율값 (예: 160 = 160%)
            // 전체 줄 피치 = line_height * percent / 100
            // line_spacing = 전체 줄 피치 - line_height
            // [#2279] sub-100% 퍼센트는 음수 gap(압축)으로 존중 — 한글은
            // line=60% 를 advance 13.6px(=lh×0.6)로 렌더한다 (36398700 pi20
            // 한글 재저장 anchor 1020HU 실측). 종전 .max(0) 클램프는 fresh
            // 합성을 lh 그대로(+9px/문단) 팽창시켰다.
            // **0% 는 한컴이 실제로 쓰는 값이다.** `secPr`·`colPr`·`pageNum`
            // 만 든 구역정의 첫 문단에 `PERCENT 0` 을 주어 advance 0(높이 없음)으로 만든다.
            // 한글 저장본도 `spacing = -vertsize` 로 같은 값을 적는다(실측 26/26 일치,
            // 본 문서 paraPr 43: vertsize 1500 · spacing −1500 · 다음 문단 vertpos 0).
            // 종전 `> 0.0` 가드가 이를 결손으로 보고 0 으로 깎아 **재조판 시 본문이 20px
            // 내려갔다**(원본 130.8 ↔ 재조판 150.8px, 변형 4종으로 잔차 0.000 확인).
            // 결손 판정은 음수로 좁힌다 — 미지정 0 은 파서에서 160% 로 채운다.
            if ls_value >= 0.0 {
                // 한컴은 퍼센트 줄간격을 **4 HWPUNIT 배수로** 반올림한다(half away from zero).
                // 165%×1400 → 910 이 아니라 912, 145%×600 → 272, 145%×500 → 224.
                // 코퍼스 101,321줄(개체 없는 문단): 현재식 75.2% ↔ 4배수 스냅 98.9% 일치.
                // 160·140·130·100·200% 는 원래 4 배수라 무변화 — 바뀌는 것은 145·165·105·110·115% 계열뿐.
                let raw = line_height_hwp as f64 * (ls_value - 100.0) / 100.0;
                ((raw.abs() / 4.0 + 0.5).floor() * 4.0 * raw.signum()) as i32
            } else {
                0
            }
        }
        LineSpacingType::Fixed => {
            // ls_value = 고정 줄 피치 (px, resolver가 HWPUNIT→px 변환 완료)
            // line_spacing = 고정값 - line_height
            let fixed_hwp = round_px_to_hwpunit(ls_value, dpi);
            (fixed_hwp - line_height_hwp).max(0)
        }
        LineSpacingType::SpaceOnly => {
            // ls_value = 줄 사이 추가 간격만 (px)
            round_px_to_hwpunit(ls_value, dpi)
        }
        LineSpacingType::Minimum => {
            // 최소값: 콘텐츠가 최소값보다 크면 추가 간격 없음
            let min_hwp = round_px_to_hwpunit(ls_value, dpi);
            (min_hwp - line_height_hwp).max(0)
        }
    }
}

#[cfg(test)]
mod fill_cursor_tests {
    use super::*;

    fn collect_one_interval_at_a_time(
        tokens: &[BreakToken],
        text_chars: &[char],
        available_width_px: f64,
        indent_px: f64,
        default_tab_width: f64,
        korean_break_unit: u8,
        condense_min_space: u8,
        initial_start_idx: usize,
        initial_is_first_line: bool,
    ) -> Vec<LineBreakResult> {
        let mut cursor = FillCursor::new(initial_start_idx, initial_is_first_line);
        let mut results = Vec::new();
        while let Some(result) = fill_one_interval(
            tokens,
            text_chars,
            available_width_px,
            indent_px,
            default_tab_width,
            korean_break_unit,
            condense_min_space,
            &[],
            &mut cursor,
            None,
        ) {
            results.push(result.line);
        }
        results
    }

    fn assert_cursor_matches_frozen_scalar(
        tokens: &[BreakToken],
        text_chars: &[char],
        available_width_px: f64,
        indent_px: f64,
        default_tab_width: f64,
        korean_break_unit: u8,
        condense_min_space: u8,
        initial_start_idx: usize,
        initial_is_first_line: bool,
    ) -> Vec<LineBreakResult> {
        let frozen = fill_lines_before_cursor(
            tokens,
            text_chars,
            available_width_px,
            indent_px,
            default_tab_width,
            korean_break_unit,
            condense_min_space,
            initial_start_idx,
            initial_is_first_line,
        );
        let scalar = fill_lines(
            tokens,
            text_chars,
            available_width_px,
            indent_px,
            default_tab_width,
            korean_break_unit,
            condense_min_space,
            &[],
            initial_start_idx,
            initial_is_first_line,
            None,
            None,
        );
        let resumed = collect_one_interval_at_a_time(
            tokens,
            text_chars,
            available_width_px,
            indent_px,
            default_tab_width,
            korean_break_unit,
            condense_min_space,
            initial_start_idx,
            initial_is_first_line,
        );

        assert_eq!(scalar, frozen);
        assert_eq!(resumed, frozen);
        frozen
    }

    fn assert_overflowing_object_space_moves_with_its_visible_object() {
        let chars = ['a', ' ', 'b'];
        let text = |start_idx, end_idx| BreakToken::Text {
            start_idx,
            end_idx,
            base_width: 10.0,
            width: 10.0,
            max_font_size: 12.0,
            base_char_widths: vec![10.0],
            char_widths: vec![10.0],
        };
        let tokens = [
            text(0, 1),
            BreakToken::Space {
                idx: 1,
                width: 20.0,
                condense_base: 20.0,
                max_font_size: 12.0,
                has_inline_control: true,
            },
            text(2, 3),
        ];
        let lines = collect_one_interval_at_a_time(&tokens, &chars, 25.0, 0.0, 48.0, 0, 0, 0, true);
        assert_eq!(
            lines
                .iter()
                .map(|l| (l.start_idx, l.end_idx))
                .collect::<Vec<_>>(),
            vec![(0, 1), (1, 2), (2, 3)]
        );
    }

    #[test]
    fn cursor_resumes_a_long_text_token_at_each_interval() {
        let text_chars = "abcdefghij".chars().collect::<Vec<_>>();
        let tokens = vec![BreakToken::Text {
            start_idx: 0,
            end_idx: text_chars.len(),
            base_width: 100.0,
            width: 100.0,
            max_font_size: 12.0,
            base_char_widths: vec![10.0; text_chars.len()],
            char_widths: vec![10.0; text_chars.len()],
        }];

        let results = assert_cursor_matches_frozen_scalar(
            &tokens,
            &text_chars,
            25.0,
            0.0,
            48.0,
            0,
            0,
            0,
            true,
        );

        assert_eq!(
            results
                .iter()
                .map(|result| (result.start_idx, result.end_idx, result.has_line_break))
                .collect::<Vec<_>>(),
            vec![
                (0, 2, false),
                (2, 4, false),
                (4, 6, false),
                (6, 8, false),
                (8, 10, false),
            ]
        );
    }

    #[test]
    fn cursor_preserves_scalar_space_tab_and_forced_break_results() {
        // Exercise both ownership cases in the existing space-boundary contract:
        // an overflowing blank can hang, but a visible inline object cannot.
        assert_overflowing_object_space_moves_with_its_visible_object();
        let text_chars = "ab c\td\nxy".chars().collect::<Vec<_>>();
        let tokens = vec![
            BreakToken::Text {
                start_idx: 0,
                end_idx: 2,
                base_width: 20.0,
                width: 20.0,
                max_font_size: 12.0,
                base_char_widths: vec![10.0, 10.0],
                char_widths: vec![10.0, 10.0],
            },
            BreakToken::Space {
                idx: 2,
                width: 5.0,
                condense_base: 5.0,
                max_font_size: 12.0,
                has_inline_control: false,
            },
            BreakToken::Text {
                start_idx: 3,
                end_idx: 4,
                base_width: 10.0,
                width: 10.0,
                max_font_size: 12.0,
                base_char_widths: vec![10.0],
                char_widths: vec![10.0],
            },
            BreakToken::Tab {
                idx: 4,
                max_font_size: 12.0,
            },
            BreakToken::Text {
                start_idx: 5,
                end_idx: 6,
                base_width: 10.0,
                width: 10.0,
                max_font_size: 12.0,
                base_char_widths: vec![10.0],
                char_widths: vec![10.0],
            },
            BreakToken::LineBreak { idx: 6 },
            BreakToken::Text {
                start_idx: 7,
                end_idx: 9,
                base_width: 20.0,
                width: 20.0,
                max_font_size: 12.0,
                base_char_widths: vec![10.0, 10.0],
                char_widths: vec![10.0, 10.0],
            },
        ];

        let actual =
            collect_one_interval_at_a_time(&tokens, &text_chars, 24.0, 0.0, 48.0, 0, 0, 0, true);
        assert_eq!(
            actual
                .iter()
                .map(|l| (l.start_idx, l.end_idx, l.has_line_break))
                .collect::<Vec<_>>(),
            vec![
                (0, 3, false),
                (3, 4, false),
                (4, 5, false),
                (5, 7, true),
                (7, 9, false)
            ]
        );
        let before = fill_lines_before_cursor(&tokens, &text_chars, 24.0, 0.0, 48.0, 0, 0, 0, true);
        assert_ne!(
            actual, before,
            "the frozen filler deferred the overflowing space"
        );
    }
}

#[cfg(test)]
mod frame_reflow_tests {
    use super::*;
    use crate::renderer::layout_frame::{FrameExclusion, FrameExclusionPolicy};
    use crate::renderer::style_resolver::{ResolvedCharStyle, ResolvedParaStyle};

    fn styles(font_sizes: &[f64]) -> ResolvedStyleSet {
        ResolvedStyleSet {
            section_tab_widths: Vec::new(),
            char_styles: font_sizes
                .iter()
                .map(|font_size| ResolvedCharStyle {
                    font_size: *font_size,
                    ratio: 1.0,
                    ..Default::default()
                })
                .collect(),
            para_styles: vec![ResolvedParaStyle::default()],
            ..Default::default()
        }
    }

    fn paragraph(text: &str, char_shapes: Vec<CharShapeRef>) -> Paragraph {
        Paragraph {
            text: text.to_string(),
            char_offsets: text
                .chars()
                .scan(0u32, |offset, character| {
                    let current = *offset;
                    *offset += character.len_utf16() as u32;
                    Some(current)
                })
                .collect(),
            char_count: text.encode_utf16().count() as u32 + 1,
            char_shapes,
            ..Default::default()
        }
    }

    fn shared_metrics(lines: &[LineSeg]) -> Vec<(i32, i32, i32, i32, i32)> {
        lines
            .iter()
            .map(|line| {
                (
                    line.vertical_pos,
                    line.line_height,
                    line.text_height,
                    line.baseline_distance,
                    line.line_spacing,
                )
            })
            .collect()
    }

    fn line_fields(lines: &[LineSeg]) -> Vec<(u32, i32, i32, i32, i32, i32, i32, i32, u32)> {
        lines
            .iter()
            .map(|line| {
                (
                    line.text_start,
                    line.vertical_pos,
                    line.line_height,
                    line.text_height,
                    line.baseline_distance,
                    line.line_spacing,
                    line.column_start,
                    line.segment_width,
                    line.tag,
                )
            })
            .collect()
    }

    fn frozen_scalar_projection(
        para: &Paragraph,
        available_width_px: f64,
        styles: &ResolvedStyleSet,
        dpi: f64,
    ) -> Vec<LineSeg> {
        let text_chars = para.text.chars().collect::<Vec<_>>();
        let style = styles.para_styles.get(para.para_shape_id as usize);
        let indent_px = style.map(|value| value.indent).unwrap_or(0.0);
        let english_break_unit = style.map(|value| value.english_break_unit).unwrap_or(0);
        let korean_break_unit = style.map(|value| value.korean_break_unit).unwrap_or(0);
        let condense_min_space = style.map(|value| value.condense_min_space).unwrap_or(0);
        let default_tab_width = style.map(|value| value.default_tab_width).unwrap_or(0.0);
        let line_spacing_type = style
            .map(|value| value.line_spacing_type)
            .unwrap_or(LineSpacingType::Percent);
        let line_spacing_value = style.map(|value| value.line_spacing).unwrap_or(160.0);
        let tokens = tokenize_paragraph_with_regenerated_space_metric(
            &text_chars,
            &para.char_offsets,
            &para.char_shapes,
            styles,
            english_break_unit,
            korean_break_unit,
            SpaceMetric::Stored,
            &[],
        );
        let line_breaks = fill_lines_before_cursor(
            &tokens,
            &text_chars,
            available_width_px,
            indent_px,
            default_tab_width,
            korean_break_unit,
            condense_min_space,
            0,
            true,
        );
        let segment_width = px_to_hwpunit(available_width_px, dpi);
        let source_tag = para
            .line_segs
            .first()
            .map(|line| line.tag)
            .unwrap_or(LineSeg::TAG_SINGLE_SEGMENT_LINE | LineSeg::TAG_IMPLEMENTATION_PROPERTY);
        let mut vertical_pos = para
            .line_segs
            .first()
            .map(|line| line.vertical_pos)
            .unwrap_or(0);

        line_breaks
            .iter()
            .enumerate()
            .map(|(index, line)| {
                let font_size = if line.max_font_size > 0.0 {
                    line.max_font_size
                } else {
                    12.0
                };
                let line_height = font_size_to_line_height(font_size, dpi);
                let line_spacing = compute_line_spacing_hwp(
                    line_spacing_type,
                    line_spacing_value,
                    line_height,
                    dpi,
                );
                let projected = LineSeg {
                    text_start: if index == 0 {
                        0
                    } else {
                        char_index_to_utf16_offset(para, line.start_idx)
                    },
                    vertical_pos,
                    line_height,
                    text_height: line_height,
                    baseline_distance: baseline_distance_hwp(line_height),
                    line_spacing,
                    column_start: 0,
                    segment_width,
                    tag: if source_tag == 0 {
                        LineSeg::TAG_SINGLE_SEGMENT_LINE
                    } else {
                        source_tag
                    },
                };
                vertical_pos += line_height + line_spacing;
                projected
            })
            .collect()
    }

    #[test]
    fn frame_reflow_projects_two_intervals_as_one_physical_row() {
        let styles = styles(&[12.0]);
        let para = paragraph(
            "abcdef ghijkl",
            vec![CharShapeRef {
                start_pos: 0,
                char_shape_id: 0,
            }],
        );
        let mut frame = LayoutFrame::new(
            0..9_000,
            100,
            vec![FrameExclusion {
                horizontal: 3_000..5_000,
                vertical: 0..10_000,
                policy: FrameExclusionPolicy::BothSides,
            }],
        );

        let lines = layout_paragraph_in_frame(&para, &mut frame, &styles, 96.0)
            .expect("two usable intervals accept scalar text");

        assert_eq!(lines.len(), 2);
        assert_eq!(
            lines.iter().map(|line| line.text_start).collect::<Vec<_>>(),
            vec![0, 7]
        );
        assert_eq!(
            lines
                .iter()
                .map(|line| (line.column_start, line.segment_width))
                .collect::<Vec<_>>(),
            vec![(0, 3_000), (5_000, 4_000)]
        );
        assert_eq!(shared_metrics(&lines), vec![(100, 900, 900, 765, 540); 2]);
        assert!(lines[0].is_first_segment());
        assert!(!lines[0].is_last_segment());
        assert!(!lines[1].is_first_segment());
        assert!(lines[1].is_last_segment());
        assert_eq!(frame.row_count(), 1);
        assert_eq!(frame.top, 1_540);
    }

    #[test]
    fn frame_reflow_retries_a_taller_row_without_consuming_the_cursor() {
        a_frame_that_expects_the_stored_rows_admits_them_and_skips_the_reflow();
        width_neutrality_is_a_property_of_geometry_not_a_list_of_variants();
        body_stored_route_admits_only_width_neutral_structural_controls();
        hwp3_formatting_rebuild_preserves_legacy_stored_geometry_jurisdiction();
        frame_rejected_rows_reflow_without_propagating_cached_source_flags();
        picture_band_frame_fill_inherits_provenance_not_cached_row_state();
        let styles = styles(&[12.0, 20.0]);
        let para = paragraph(
            "abcdef ghijk",
            vec![
                CharShapeRef {
                    start_pos: 0,
                    char_shape_id: 0,
                },
                CharShapeRef {
                    start_pos: 7,
                    char_shape_id: 1,
                },
            ],
        );
        let mut frame = LayoutFrame::new(
            0..9_000,
            0,
            vec![FrameExclusion {
                horizontal: 4_000..5_000,
                vertical: 1_000..5_000,
                policy: FrameExclusionPolicy::BothSides,
            }],
        );

        let lines = layout_paragraph_in_frame(&para, &mut frame, &styles, 96.0)
            .expect("the taller retry restores the first interval's cursor");

        // The 12px trial has one full-width interval below the exclusion. The
        // 20px row reaches it, so retrying from the same cursor must produce
        // the two carved segments rather than an exhausted paragraph.
        assert_eq!(lines.len(), 2);
        assert_eq!(
            lines.iter().map(|line| line.text_start).collect::<Vec<_>>(),
            vec![0, 7]
        );
        assert_eq!(
            lines
                .iter()
                .map(|line| (line.column_start, line.segment_width))
                .collect::<Vec<_>>(),
            vec![(0, 4_000), (5_000, 4_000)]
        );
        assert_eq!(
            shared_metrics(&lines),
            vec![(0, 1_500, 1_500, 1_275, 900); 2]
        );
        assert_eq!(frame.row_count(), 1);
        assert_eq!(frame.top, 2_400);
    }

    fn a_frame_that_expects_the_stored_rows_admits_them_and_skips_the_reflow() {
        let styles = styles(&[12.0]);
        let mut para = paragraph(
            "alpha beta gamma delta",
            vec![CharShapeRef {
                start_pos: 0,
                char_shape_id: 0,
            }],
        );
        para.line_segs = vec![
            LineSeg {
                text_start: 0,
                vertical_pos: 700,
                line_height: 321,
                text_height: 300,
                baseline_distance: 250,
                line_spacing: 17,
                column_start: 1_000,
                segment_width: 4_000,
                tag: LineSeg::TAG_SINGLE_SEGMENT_LINE,
            },
            LineSeg {
                // This deliberately is not a fresh word boundary. A matching
                // Frame must preserve the cached text partition verbatim.
                text_start: 2,
                vertical_pos: 1_038,
                line_height: 654,
                text_height: 600,
                baseline_distance: 500,
                line_spacing: 23,
                column_start: 1_000,
                segment_width: 4_000,
                tag: LineSeg::TAG_SINGLE_SEGMENT_LINE,
            },
        ];
        let mut frame = LayoutFrame::new(1_000..5_000, 700, Vec::new());

        // Reuse requires the current frame to reproduce the stored physical-row
        // key exactly. Only then may the cached text partition stand.
        let resolution = resolve_stored_line_segs_in_frame(
            &para,
            &mut frame,
            &styles,
            96.0,
            false,
            StoredRowMissPolicy::Reflow,
            false,
            &[],
            false,
        )
        .expect("a scalar cached paragraph is frame-resolvable");
        assert_eq!(resolution, StoredRowResolution::Stored);
        assert_eq!(frame.row_count(), 2);

        // Geometry is preserved because the carve reproduced it — that is the
        // admission test. Vertical metrics are **not**: §1.4.1 recomputes them
        // on both arms and writes them back over the stored record, so the
        // frame publishes what it computed, not what the file carried. The
        // stored heights here (321/654) are fixture values with no relation to
        // the 12pt char shape the provider measures.
        let projected = frame.project_line_segs();
        assert_eq!(projected.len(), 2);
        assert!(projected
            .iter()
            .zip(&para.line_segs)
            .all(|(row, stored)| row.text_start == stored.text_start
                && row.column_start == stored.column_start
                && row.segment_width == stored.segment_width));
        let computed = frame_metrics_for_line(12.0, 12.0, LineSpacingType::Percent, 160.0, 96.0);
        assert!(projected
            .iter()
            .all(|row| row.line_height == computed.line_height
                && row.line_spacing == computed.line_spacing));
        assert_eq!(
            frame.top,
            700 + 2 * (computed.line_height + computed.line_spacing)
        );
    }

    fn width_neutrality_is_a_property_of_geometry_not_a_list_of_variants() {
        // Every one of these contributes no inline width and owns no layout
        // box, so the frame owns their paragraph. Only `SectionDef`,
        // `ColumnDef` and `Field` used to qualify; a body paragraph carrying
        // any of the others had no layout owner at all.
        for control in [
            Control::SectionDef(Box::default()),
            Control::ColumnDef(Default::default()),
            Control::Field(Default::default()),
            Control::Bookmark(Default::default()),
            Control::PageNumberPos(Default::default()),
            Control::PageHide(Default::default()),
            Control::HiddenComment(Box::default()),
            // HWP3 keeps hyperlinks as their own control. HWP5/HWPX turn `%hlk`
            // into a `Control::Field` by a prefix test, which is the only
            // reason those ever reached the frame.
            Control::Hyperlink(Default::default()),
            Control::AutoNumber(Default::default()),
            Control::NewNumber(Default::default()),
            Control::Unknown(Default::default()),
        ] {
            assert!(
                control_is_width_neutral_marker(&control),
                "{control:?} has no geometry, so the frame must own its paragraph"
            );
        }

        // These resolve their own geometry — inline or floating — so the frame
        // must decline and leave them with their established owner. A body
        // frame carries no exclusion, so claiming a floating object's paragraph
        // would flatten the wrap it cannot see.
        for control in [
            Control::Table(Box::default()),
            Control::Shape(Box::new(crate::model::shape::ShapeObject::Rectangle(
                Default::default(),
            ))),
            Control::Picture(Box::default()),
            Control::Equation(Box::default()),
            Control::Form(Box::default()),
            Control::Header(Box::default()),
            Control::Footer(Box::default()),
            Control::Footnote(Box::default()),
            Control::Endnote(Box::default()),
        ] {
            assert!(
                !control_is_width_neutral_marker(&control),
                "{control:?} owns its own layout box"
            );
        }
    }

    fn body_stored_route_admits_only_width_neutral_structural_controls() {
        let styles = styles(&[12.0]);
        let mut structural = paragraph(
            "section body",
            vec![CharShapeRef {
                start_pos: 0,
                char_shape_id: 0,
            }],
        );
        structural.line_segs = vec![LineSeg {
            vertical_pos: 100,
            line_height: 900,
            text_height: 900,
            baseline_distance: 765,
            line_spacing: 540,
            column_start: 0,
            segment_width: 9_000,
            tag: LineSeg::TAG_SINGLE_SEGMENT_LINE,
            ..Default::default()
        }];
        structural.controls = vec![
            Control::SectionDef(Box::default()),
            Control::ColumnDef(Default::default()),
        ];
        assert!(supports_cached_body_frame_controls(&structural));
        let mut structural_frame = LayoutFrame::new(0..9_000, 100, Vec::new());
        assert!(matches!(
            resolve_stored_line_segs_in_frame(
                &structural,
                &mut structural_frame,
                &styles,
                96.0,
                false,
                StoredRowMissPolicy::Reflow,
                false,
                &[],
                false,
            ),
            Some(StoredRowResolution::Stored)
        ));
        // Width-neutral markers do not move the carve, so production admission
        // has committed the matching cached row into the frame.
        assert_eq!(structural_frame.row_count(), 1);
        assert_eq!(
            structural_frame
                .project_line_segs()
                .iter()
                .map(|line| (line.column_start, line.segment_width))
                .collect::<Vec<_>>(),
            vec![(0, 9_000)]
        );

        let mut specialized = structural.clone();
        specialized.controls = vec![Control::Table(Box::default())];
        assert!(!supports_cached_body_frame_controls(&specialized));
        let mut specialized_frame = LayoutFrame::new(0..9_000, 100, Vec::new());
        let checkpoint = specialized_frame.clone();
        assert!(resolve_stored_line_segs_in_frame(
            &specialized,
            &mut specialized_frame,
            &styles,
            96.0,
            false,
            StoredRowMissPolicy::Reflow,
            true,
            &[],
            false,
        )
        .is_none());
        assert_eq!(specialized_frame, checkpoint);

        // A Square exclusion can leave one slot per row and still change that
        // slot when the band ends. An exclusion-less body frame cannot infer
        // the missing band from these cached outputs, so varying single-slot
        // geometry is unmodelled rather than a reason to flatten and reflow.
        let mut varying_single_slot = structural.clone();
        varying_single_slot.controls.clear();
        varying_single_slot.line_segs = vec![
            LineSeg {
                text_start: 0,
                column_start: 0,
                segment_width: 4_000,
                tag: LineSeg::TAG_SINGLE_SEGMENT_LINE,
                ..structural.line_segs[0].clone()
            },
            LineSeg {
                text_start: 4,
                column_start: 0,
                segment_width: 9_000,
                tag: LineSeg::TAG_SINGLE_SEGMENT_LINE,
                ..structural.line_segs[0].clone()
            },
        ];
        let mut scalar_frame = LayoutFrame::new(0..9_000, 100, Vec::new());
        let scalar_checkpoint = scalar_frame.clone();
        assert!(resolve_stored_line_segs_in_frame(
            &varying_single_slot,
            &mut scalar_frame,
            &styles,
            96.0,
            false,
            StoredRowMissPolicy::Reflow,
            false,
            &[],
            false,
        )
        .is_none());
        assert_eq!(scalar_frame, scalar_checkpoint);

        let mut empty_external_carrier = structural.clone();
        empty_external_carrier.text.clear();
        empty_external_carrier.char_offsets.clear();
        empty_external_carrier.char_count = 1;
        empty_external_carrier.controls.clear();
        empty_external_carrier.line_segs = vec![LineSeg {
            text_start: 0,
            column_start: 4_000,
            segment_width: 5_000,
            tag: LineSeg::TAG_SINGLE_SEGMENT_LINE,
            ..structural.line_segs[0].clone()
        }];
        let mut carrier_frame = LayoutFrame::new(0..9_000, 100, Vec::new());
        let carrier_checkpoint = carrier_frame.clone();
        assert!(resolve_stored_line_segs_in_frame(
            &empty_external_carrier,
            &mut carrier_frame,
            &styles,
            96.0,
            false,
            StoredRowMissPolicy::Reflow,
            false,
            &[],
            false,
        )
        .is_none());
        assert_eq!(carrier_frame, carrier_checkpoint);
    }

    fn hwp3_formatting_rebuild_preserves_legacy_stored_geometry_jurisdiction() {
        use crate::document_core::DocumentCore;
        use std::fs;
        use std::path::Path;

        let path = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("samples/issue1892_hwp3_drawing_group_roundtrip.hwp");
        let bytes = fs::read(&path).unwrap_or_else(|error| panic!("read {path:?}: {error}"));
        let mut core = DocumentCore::from_bytes(&bytes).expect("load HWP3 formatting fixture");
        assert!(
            core.document.layout_profile().legacy_hwp3_stored_geometry(),
            "the HWP3 fixture must retain legacy stored-geometry jurisdiction"
        );

        // Choose a plain, nonempty single-row paragraph. With no controls and
        // no varying slots, only HWP3 lineage can make this mismatching Frame
        // unmodelled; clearing the lineage flag below proves the reversal.
        let (section_index, paragraph_index) = core
            .document
            .sections
            .iter()
            .enumerate()
            .find_map(|(section_index, section)| {
                section
                    .paragraphs
                    .iter()
                    .enumerate()
                    .find(|(_, paragraph)| {
                        !paragraph.text.trim().is_empty()
                            && paragraph.controls.is_empty()
                            && paragraph.line_segs.len() == 1
                            && paragraph.line_segs[0].is_first_segment()
                            && paragraph.line_segs[0].is_last_segment()
                            && paragraph.line_segs[0].segment_width > 2_400
                    })
                    .map(|(paragraph_index, _)| (section_index, paragraph_index))
            })
            .expect("fixture has a plain legacy stored row");
        let stored_before = line_fields(
            &core.document.sections[section_index].paragraphs[paragraph_index].line_segs,
        );

        // Underline is paint-only, but the public formatting lifecycle still
        // calls rebuild_section(). The legacy row itself must remain untouched.
        core.apply_char_format_native(
            section_index,
            paragraph_index,
            0,
            1,
            r#"{"underline":true}"#,
        )
        .expect("apply paint-only format");
        assert_eq!(
            line_fields(
                &core.document.sections[section_index].paragraphs[paragraph_index].line_segs,
            ),
            stored_before
        );
        assert!(core.document.layout_profile().legacy_hwp3_stored_geometry());

        let paragraph = &core.document.sections[section_index].paragraphs[paragraph_index];
        let stored = &paragraph.line_segs[0];
        let frame_horizontal = stored.column_start.saturating_add(1_200)
            ..stored.column_start.saturating_add(stored.segment_width);

        let mut ordinary_frame =
            LayoutFrame::new(frame_horizontal.clone(), stored.vertical_pos, Vec::new());
        assert!(matches!(
            resolve_stored_line_segs_in_frame(
                paragraph,
                &mut ordinary_frame,
                &core.styles,
                96.0,
                false,
                StoredRowMissPolicy::Reflow,
                false,
                &[],
                false,
            ),
            Some(StoredRowResolution::Reflowed)
        ));

        let mut legacy_frame = LayoutFrame::new(frame_horizontal, stored.vertical_pos, Vec::new());
        assert!(
            resolve_stored_line_segs_in_frame(
                paragraph,
                &mut legacy_frame,
                &core.styles,
                96.0,
                true,
                StoredRowMissPolicy::Reflow,
                false,
                &[],
                false,
            )
            .is_none(),
            "untouched HWP3 stored origin remains outside the common Frame's jurisdiction"
        );
    }

    fn frame_rejected_rows_reflow_without_propagating_cached_source_flags() {
        let styles = styles(&[12.0]);
        let mut para = paragraph(
            "abcdef ghijkl",
            vec![CharShapeRef {
                start_pos: 0,
                char_shape_id: 0,
            }],
        );
        para.line_segs = vec![LineSeg {
            text_start: 0,
            vertical_pos: 100,
            line_height: 900,
            text_height: 900,
            baseline_distance: 765,
            line_spacing: 540,
            column_start: 0,
            segment_width: 9_000,
            tag: LineSeg::TAG_SINGLE_SEGMENT_LINE
                | LineSeg::TAG_FIRST_LINE_OF_PAGE
                | LineSeg::TAG_FIRST_LINE_OF_COLUMN
                | LineSeg::TAG_EMPTY_SEGMENT,
        }];
        let mut frame = LayoutFrame::new(
            0..9_000,
            100,
            vec![FrameExclusion {
                horizontal: 3_000..5_000,
                vertical: 0..10_000,
                policy: FrameExclusionPolicy::BothSides,
            }],
        );

        let resolution = resolve_stored_line_segs_in_frame(
            &para,
            &mut frame,
            &styles,
            96.0,
            false,
            StoredRowMissPolicy::Reflow,
            false,
            &[],
            false,
        )
        .expect("a scalar cached paragraph is frame-resolvable");

        let StoredRowResolution::Reflowed = resolution else {
            panic!("rows differing from the frame expectation must reflow");
        };
        // The frame holds the rows now; projecting is the only way out.
        let lines = frame.project_line_segs();
        assert_eq!(
            lines
                .iter()
                .map(|line| (line.text_start, line.column_start, line.segment_width))
                .collect::<Vec<_>>(),
            vec![(0, 0, 3_000), (7, 5_000, 4_000)]
        );
        assert_eq!(frame.row_count(), 1);
        assert_eq!(frame.top, 1_540);
        let rejected_cache_flags = LineSeg::TAG_FIRST_LINE_OF_PAGE
            | LineSeg::TAG_FIRST_LINE_OF_COLUMN
            | LineSeg::TAG_EMPTY_SEGMENT;
        assert!(lines
            .iter()
            .all(|line| line.tag & rejected_cache_flags == 0));
        assert!(lines
            .iter()
            .all(|line| line.tag & LineSeg::TAG_IMPLEMENTATION_PROPERTY != 0));
    }

    fn picture_band_frame_fill_inherits_provenance_not_cached_row_state() {
        let styles = styles(&[12.0]);
        let mut para = paragraph(
            "alpha beta gamma delta epsilon zeta eta theta iota kappa",
            vec![CharShapeRef {
                start_pos: 0,
                char_shape_id: 0,
            }],
        );
        let cached_row_flags = LineSeg::TAG_FIRST_LINE_OF_PAGE
            | LineSeg::TAG_FIRST_LINE_OF_COLUMN
            | LineSeg::TAG_EMPTY_SEGMENT
            | LineSeg::TAG_AUTO_HYPHENATION
            | LineSeg::TAG_INDENTATION
            | LineSeg::TAG_PARAGRAPH_HEAD;
        para.line_segs = vec![LineSeg {
            tag: LineSeg::TAG_SINGLE_SEGMENT_LINE | cached_row_flags,
            ..Default::default()
        }];

        let fill = |paragraph: &Paragraph| {
            let mut frame = LayoutFrame::new(0..3_000, 0, Vec::new());
            layout_paragraph_in_frame(paragraph, &mut frame, &styles, 96.0)
                .expect("Picture-band fill must produce fresh rows")
        };
        let mut picture_band_input = para;
        picture_band_input.line_segs.clear();
        let synthetic = fill(&picture_band_input);
        assert!(synthetic.len() > 1, "fixture must exercise later rows");
        assert!(synthetic
            .iter()
            .all(|line| line.tag & cached_row_flags == 0));
        assert!(synthetic
            .iter()
            .all(|line| line.tag & LineSeg::TAG_IMPLEMENTATION_PROPERTY != 0));
    }

    #[test]
    fn eligible_scalar_reflow_projects_the_frozen_scalar_oracle() {
        let styles = styles(&[12.0]);
        let mut para = paragraph(
            "alpha beta gamma delta epsilon",
            vec![CharShapeRef {
                start_pos: 0,
                char_shape_id: 0,
            }],
        );
        para.line_segs = vec![LineSeg {
            vertical_pos: 321,
            tag: LineSeg::TAG_SINGLE_SEGMENT_LINE | LineSeg::TAG_IMPLEMENTATION_PROPERTY,
            ..Default::default()
        }];
        let mut expected = frozen_scalar_projection(&para, 50.0, &styles, 96.0);
        assert!(expected.len() > 1, "fixture must exercise row recurrence");
        // [#7412] 셀 내용 상자는 한/글 저장본처럼 4 HWPUNIT 격자로 내린 폭(3750 → 3748)을
        // 발행한다. 줄 나눔은 동결 오라클과 같아야 하므로 폭 필드만 격자 값으로 맞춘다.
        for line in &mut expected {
            line.segment_width -= line.segment_width.rem_euclid(4);
        }

        reflow_line_segs(
            &mut para,
            ParagraphBox::content_width_px(50.0, 96.0),
            &styles,
            96.0,
        );

        assert_eq!(line_fields(&para.line_segs), line_fields(&expected));
        assert!(para
            .line_segs
            .iter()
            .all(|line| line.segment_width == 3_748 && line.column_start == 0));
        assert_eq!(para.line_segs[0].vertical_pos, 321);
    }

    #[test]
    fn picture_band_uses_para_reference_not_text_frame_for_right_aligned_picture() {
        use crate::model::image::Picture;
        use crate::model::shape::{HorzAlign, HorzRelTo, TextFlow, TextWrap, VertAlign, VertRelTo};

        const DPI: f64 = 96.0;
        const COLUMN_WIDTH: i32 = 15_000;
        const MARGIN_LEFT: i32 = 1_500;
        const MARGIN_RIGHT: i32 = 3_000;
        const PICTURE_WIDTH: u32 = 3_000;

        let mut styles = styles(&[12.0]);
        styles.para_styles[0].margin_left = crate::renderer::hwpunit_to_px(MARGIN_LEFT, DPI);
        styles.para_styles[0].margin_right = crate::renderer::hwpunit_to_px(MARGIN_RIGHT, DPI);
        let text_frame = MARGIN_LEFT..COLUMN_WIDTH - MARGIN_RIGHT;
        let paragraph_reference = picture_band_paragraph_reference(&(0..COLUMN_WIDTH), MARGIN_LEFT)
            .expect("host left margin leaves a usable Paragraph reference");
        assert_eq!(paragraph_reference, MARGIN_LEFT..COLUMN_WIDTH);
        assert_ne!(text_frame, paragraph_reference);

        let picture = Picture {
            common: crate::model::shape::CommonObjAttr {
                width: PICTURE_WIDTH,
                height: 600,
                text_wrap: TextWrap::Square,
                text_flow: TextFlow::BothSides,
                vert_rel_to: VertRelTo::Para,
                vert_align: VertAlign::Top,
                horz_rel_to: HorzRelTo::Para,
                horz_align: HorzAlign::Right,
                ..Default::default()
            },
            ..Default::default()
        };
        let expected_exclusion = crate::renderer::float_placement::resolve_picture_exclusion(
            &picture,
            0..COLUMN_WIDTH,
            paragraph_reference.clone(),
            0,
            crate::renderer::float_placement::PaperOrigin::default(),
        )
        .expect("supported Paragraph-relative Picture");
        assert_eq!(expected_exclusion.horizontal, 12_000..15_000);

        let mut host = paragraph(
            "x",
            vec![CharShapeRef {
                start_pos: 0,
                char_shape_id: 0,
            }],
        );
        host.controls.push(Control::Picture(Box::new(picture)));

        let band = layout_picture_band(
            &[host],
            0,
            crate::renderer::hwpunit_to_px(COLUMN_WIDTH, DPI),
            &styles,
            DPI,
            (0.0, 0.0),
        )
        .expect("the one-row Paragraph-relative Picture band");

        assert_eq!(band.paragraph_range, 0..1);
        assert_eq!(band.line_segs[0].len(), 1);
        assert_eq!(band.line_segs[0][0].column_start, text_frame.start);
        assert_eq!(
            band.line_segs[0][0].segment_width,
            text_frame.end - text_frame.start,
            "the right-aligned Para exclusion begins at the text frame's end"
        );
    }

    #[test]
    fn real_p325_picture_band_matches_the_stored_seven_paragraph_geometry() {
        use crate::model::page::ColumnDef;
        use crate::renderer::page_layout::PageLayoutInfo;

        const DPI: f64 = 96.0;
        let bytes = std::fs::read(
            std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
                .join("samples/3-09월_교육_통합_2022.hwp"),
        )
        .expect("p325 corpus fixture");
        let document = crate::parse_document(&bytes).expect("parse p325 corpus fixture");
        let section = &document.sections[0];
        let column_def = section.paragraphs[..=325]
            .iter()
            .flat_map(|paragraph| &paragraph.controls)
            .filter_map(|control| match control {
                Control::ColumnDef(column) => Some(column.clone()),
                _ => None,
            })
            .next_back()
            .unwrap_or_else(ColumnDef::default);
        let page_layout =
            PageLayoutInfo::from_page_def(&section.section_def.page_def, &column_def, DPI);
        let column_width = page_layout.column_areas[0].width;
        let styles = crate::renderer::style_resolver::resolve_styles(&document.doc_info, DPI);

        let band = layout_picture_band(
            &section.paragraphs,
            325,
            column_width,
            &styles,
            DPI,
            (0.0, 0.0),
        )
        .expect("one Picture + trailing TAC Equation p325 band");

        assert_eq!(band.paragraph_range, 325..332);
        assert_eq!(band.line_segs.len(), 7);
        for (paragraph_index, generated) in band.paragraph_range.clone().zip(&band.line_segs) {
            let stored = &section.paragraphs[paragraph_index].line_segs;
            assert_eq!(generated.len(), 1, "p{paragraph_index}");
            assert_eq!(
                generated[0].text_start, stored[0].text_start,
                "p{paragraph_index}"
            );
            assert_eq!(
                generated[0].column_start, stored[0].column_start,
                "p{paragraph_index}"
            );
            assert_eq!(
                generated[0].segment_width, stored[0].segment_width,
                "p{paragraph_index}"
            );
            assert!(
                generated[0].line_height.abs_diff(stored[0].line_height) <= 1,
                "p{paragraph_index}"
            );
            assert!(
                generated[0].text_height.abs_diff(stored[0].text_height) <= 1,
                "p{paragraph_index}"
            );
            assert!(
                generated[0]
                    .baseline_distance
                    .abs_diff(stored[0].baseline_distance)
                    <= 1,
                "p{paragraph_index}: generated={} stored={}",
                generated[0].baseline_distance,
                stored[0].baseline_distance,
            );
            assert!(
                generated[0].line_spacing.abs_diff(stored[0].line_spacing) <= 3,
                "p{paragraph_index}"
            );
        }
        assert!(
            band.line_segs[0][0].line_height > 900,
            "the host's trailing TAC Equation must enlarge the retried first row"
        );
        assert_eq!(
            band.line_segs[0][0].baseline_distance,
            section.paragraphs[325].line_segs[0].baseline_distance,
            "p325 retains the TAC Equation's object-owned baseline"
        );
        assert_ne!(
            band.line_segs.last().expect("band tail")[0].segment_width,
            section.paragraphs[332].line_segs[0].segment_width,
            "p332 is the first full-width paragraph after the exclusion"
        );
    }

    #[test]
    fn picture_band_rejects_a_truncated_p325_before_any_projection() {
        use crate::model::page::ColumnDef;
        use crate::renderer::page_layout::PageLayoutInfo;

        const DPI: f64 = 96.0;
        let bytes = std::fs::read(
            std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
                .join("samples/3-09월_교육_통합_2022.hwp"),
        )
        .expect("p325 corpus fixture");
        let document = crate::parse_document(&bytes).expect("parse p325 corpus fixture");
        let section = &document.sections[0];
        let column_def = section.paragraphs[..=325]
            .iter()
            .flat_map(|paragraph| &paragraph.controls)
            .filter_map(|control| match control {
                Control::ColumnDef(column) => Some(column.clone()),
                _ => None,
            })
            .next_back()
            .unwrap_or_else(ColumnDef::default);
        let page_layout =
            PageLayoutInfo::from_page_def(&section.section_def.page_def, &column_def, DPI);
        let column_width = page_layout.column_areas[0].width;
        let styles = crate::renderer::style_resolver::resolve_styles(&document.doc_info, DPI);

        assert!(
            layout_picture_band(
                &section.paragraphs[325..329],
                0,
                column_width,
                &styles,
                DPI,
                (0.0, 0.0)
            )
            .is_none(),
            "a subset ending before the exclusion clears cannot be published"
        );
    }

    #[test]
    fn pic2_two_picture_host_is_explicitly_outside_the_one_picture_band_contract() {
        use crate::model::page::ColumnDef;
        use crate::renderer::page_layout::PageLayoutInfo;

        const DPI: f64 = 96.0;
        let bytes = std::fs::read(
            std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("samples/pic2.hwp"),
        )
        .expect("pic2 fixture");
        let document = crate::parse_document(&bytes).expect("parse pic2 fixture");
        let section = &document.sections[0];
        let column_def = section.paragraphs[..=0]
            .iter()
            .flat_map(|paragraph| &paragraph.controls)
            .filter_map(|control| match control {
                Control::ColumnDef(column) => Some(column.clone()),
                _ => None,
            })
            .next_back()
            .unwrap_or_else(ColumnDef::default);
        let page_layout =
            PageLayoutInfo::from_page_def(&section.section_def.page_def, &column_def, DPI);
        let column_width = page_layout.column_areas[0].width;
        let styles = crate::renderer::style_resolver::resolve_styles(&document.doc_info, DPI);

        assert_eq!(
            section.paragraphs[0]
                .controls
                .iter()
                .filter(|control| {
                    matches!(control, Control::Picture(picture) if !picture.common.treat_as_char)
                })
                .count(),
            2,
            "fixture premise: pic2's first paragraph has two floating pictures"
        );
        assert!(
            layout_picture_band(
                &section.paragraphs,
                0,
                column_width,
                &styles,
                DPI,
                (0.0, 0.0)
            )
            .is_none(),
            "two floating pictures are deliberately not a one-picture band"
        );
    }
}

#[cfg(test)]
mod utf16_offset_tests {
    use super::*;

    #[test]
    fn trailing_physical_line_preserves_control_stream_end_offset() {
        let mut para = Paragraph {
            text: "가\n".to_string(),
            // visible text 앞에 16 UTF-16 unit의 control stream gap이 있다.
            char_offsets: vec![16, 17],
            ..Default::default()
        };

        reflow_line_segs(
            &mut para,
            ParagraphBox::content_width_px(500.0, 96.0),
            &ResolvedStyleSet::default(),
            96.0,
        );

        assert_eq!(para.line_segs.len(), 2);
        assert_eq!(para.line_segs[1].text_start, 18);
    }

    #[test]
    fn missing_char_offsets_count_supplementary_unicode_as_utf16_units() {
        let para = Paragraph {
            text: "😀\n".to_string(),
            ..Default::default()
        };

        assert_eq!(char_index_to_utf16_offset(&para, 2), 3);
    }
}
