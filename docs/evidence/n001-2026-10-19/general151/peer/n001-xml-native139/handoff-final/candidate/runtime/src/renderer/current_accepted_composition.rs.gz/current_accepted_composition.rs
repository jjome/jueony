//! Consume the exact plain-body composition accepted by the current allocator.
//! No source/cache rows are reconstructed and no lease/export authority is issued.
use std::sync::Arc;
use crate::model::{paragraph::Paragraph,provenance::LayoutCompatibilityProfile,control::Control};
use super::{composer::ComposedParagraph,pagination::PaginationResult,selected_composition_observer127::FinalizedSelectedCompositionTrace,
 style_resolver::ResolvedStyleSet};
#[derive(Debug,Clone)]
pub(crate) struct CurrentAcceptedCompositionView {
 trace:Arc<FinalizedSelectedCompositionTrace>,
 definition_context:Option<[u8;32]>,
 // These are current renderer inputs, not a source row or physical origin permit.
 origin_measurements:Vec<(usize,usize,usize)>,
 origin_slots:Option<Vec<OriginPaintSlot>>,
}
#[derive(Debug,Clone)]
struct OriginPaintSlot {section:usize,page:u32,column:u16,paragraph:usize,control:Option<usize>,whole_table:bool,item_token:usize,rect:[f64;4]}
// Separate from a WholeTableAcceptedFact: the deferred path never fabricated one.
struct DeferredPaintPolicy;
enum OriginPaintSelection { Whole, Deferred(DeferredPaintPolicy) }
fn origin_slots(result:&PaginationResult)->Option<Vec<OriginPaintSlot>> {
 use super::pagination::PageItem;
 let mut slots=vec![];let mut budget=16384usize;
 for p in &result.pages {for c in &p.column_contents {
  let rect=c.zone_layout.as_ref().unwrap_or(&p.layout).column_areas.get(usize::from(c.column_index))?;
  let rect=[rect.x,rect.y,rect.width,rect.height];
  if rect.iter().any(|v|!v.is_finite())||rect[2]<=0.0||rect[3]<=0.0{return None;}
  for item in &c.items {budget=budget.checked_sub(1)?;
   let (paragraph,control,whole_table)=match item {
    PageItem::Table{para_index,control_index}=>(*para_index,Some(*control_index),true),
    PageItem::PartialTable{para_index,control_index,..}=>(*para_index,Some(*control_index),false),
    PageItem::FullParagraph{para_index}|PageItem::PartialParagraph{para_index,..}=>(*para_index,None,false),
    _=>continue,
   };
   slots.push(OriginPaintSlot{section:p.section_index,page:p.page_index,column:c.column_index,paragraph,control,whole_table,item_token:item as *const _ as usize,rect});
  }
 }}Some(slots)
}
pub(crate) struct AcceptedPlainPaint {pub composition:Arc<ComposedParagraph>,pub line_box_width:f64}
impl CurrentAcceptedCompositionView {
 pub(crate) fn from_current(result:&PaginationResult,paras:&[Paragraph],styles:&ResolvedStyleSet,profile:LayoutCompatibilityProfile,dpi:f64)->Option<Self>{
  if dpi!=super::DEFAULT_DPI||styles.supplemental_metrics.is_some()||styles.kerning_measurement_context.is_some()||styles.horizontal_shaping_context.is_some(){return None;}
  let trace=result.selected_composition_trace.as_ref()?;
  if !trace.matches_source(paras,styles.reset_flow_context,profile,dpi)||!trace.matches_finalized_result(result){return None;}
  Some(Self{trace:Arc::clone(trace),definition_context:styles.reset_flow_context,origin_measurements:vec![],origin_slots:origin_slots(result)})
 }
 /// Bind the actual Core measurement arena after current source/frame checking.
 /// A cloned document or a receipt alone cannot manufacture this association.
 pub(crate) fn bind_origin_measurements(mut self,tables:&[super::height_measurer::MeasuredTable])->Self {
  if tables.len()<=4096 {
   self.origin_measurements=tables.iter().map(|t|(t.para_index,t.control_index,t as *const _ as usize)).collect();
  }self
 }
 /// Policy selection only: no placement, row, cache, lease or export authority.
 pub(crate) fn known_native_preinset(&self,para:&Paragraph,section:usize,page:u32,column:u16,index:usize,control:usize,
 measured:&super::height_measurer::MeasuredTable,physical_rect:[f64;4],item_token:usize,context:[u8;32],dpi:f64)->bool{
  self.origin_paint_selection(para,section,page,column,index,control,measured,physical_rect,item_token,context,dpi).is_some()
 }
 fn origin_paint_selection(&self,para:&Paragraph,section:usize,page:u32,column:u16,index:usize,control:usize,
 measured:&super::height_measurer::MeasuredTable,physical_rect:[f64;4],item_token:usize,context:[u8;32],dpi:f64)->Option<OriginPaintSelection>{
  let input=para.native_origin_paint_input.as_ref()?;
  if dpi!=super::DEFAULT_DPI||section!=self.trace.section()||!input.matches_current_inputs(para,context){return None;}
  let trace=self.trace.as_ref();let Control::Table(table)=para.controls.get(control)? else{return None;};
  let mut measurements=self.origin_measurements.iter().filter(|(p,c,_)|*p==index&&*c==control);
  if measurements.next()?.2!=measured as *const _ as usize||measurements.next().is_some(){return None;}
  if measured.para_index!=index||measured.control_index!=control||!measured.total_height.is_finite()
   ||measured.total_height<=0.0||measured.caption_height!=0.0||!measured.cell_spacing.is_finite()||measured.cell_spacing<0.0
   ||measured.row_heights.len()!=usize::from(table.row_count)||measured.row_heights.is_empty()
   ||measured.cumulative_heights.len()!=measured.row_heights.len()+1||measured.cumulative_heights[0]!=0.0{return None;}
  let mut sum=0.0;
  for (i,h) in measured.row_heights.iter().enumerate(){if !h.is_finite()||*h<=0.0{return None;}
   sum+=*h+if i>0{measured.cell_spacing}else{0.0};if measured.cumulative_heights[i+1]!=sum{return None;}
  }
  if !sum.is_finite()||sum!=measured.total_height||table.common.height>i32::MAX as u32
   ||measured.total_height!=super::hwpunit_to_px(table.common.height as i32,dpi){return None;}
  let mut slots=self.origin_slots.as_ref()?.iter().filter(|s|s.paragraph==index);
  let slot=slots.next()?;
  if slots.next().is_some()||!slot.whole_table||slot.section!=section||slot.page!=page||slot.column!=column
   ||slot.control!=Some(control)||slot.rect!=physical_rect||slot.item_token!=item_token{return None;}
  let token=para as *const Paragraph as usize;
  let mut whole=trace.whole_tables().iter().filter(|f|f.paragraph==index&&f.control==control);
  if let Some(f)=whole.next(){
   // Existing-but-invalid actual allocation NEVER falls back to deferred.
   if whole.next().is_some(){return None;}
   let format=f.selected_format_id.and_then(|id|trace.format(id))?;
   let ok=f.section==section&&f.page==Some(page)&&f.column==column&&f.paragraph_token==token&&format.paragraph_token==token
    &&format.source_text==para.text&&format.source_char_offsets==para.char_offsets
    &&f.final_membership==Some(true)&&f.resolved.is_none()&&f.is_first&&f.is_last
    &&f.post_page==f.page&&f.post_column==column&&f.pre_text_height==0.0&&f.pre_text_end==0
    &&f.selected_line_count==1&&f.before==super::hwpunit_to_px(i32::from(table.outer_margin_top),dpi)
    &&f.full_after-f.after_for_fit==super::hwpunit_to_px(i32::from(table.outer_margin_bottom),dpi)
    &&f.body_height==measured.total_height&&f.table_total_height==f.before+f.body_height+f.after_for_fit;
   return ok.then_some(OriginPaintSelection::Whole);
  }
  // A lane-allocated Table fact also cannot be relabelled as deferred.
  if trace.tables().iter().any(|f|f.paragraph==index&&f.control==control){return None;}
  let mut formats=trace.formats().iter().filter(|f|f.paragraph_token==token);
  let f=formats.next()?;if formats.next().is_some(){return None;}
  let [row]=para.line_segs.as_slice()else{return None;};
  let [line]=f.lines.as_slice()else{return None;};
  let width=f.actual_input_width_px?;
  if !para.text.is_empty()||!para.char_offsets.is_empty()||f.source_text!=para.text||f.source_char_offsets!=para.char_offsets
   ||f.source_row_count!=1||f.paragraph_style!=para.para_shape_id||f.dpi!=dpi||f.definition_context!=self.definition_context
   ||!width.is_finite()||width<=0.0||f.before!=0.0||f.after!=0.0||f.has_numbering||f.has_horizontal_shaping||f.known_square_band
   ||!f.inline_controls.is_empty()||!f.tac_controls.is_empty()||!f.footnote_positions.is_empty()||!f.tab_extended.is_empty()
   ||line.scalar_start!=0||line.scalar_end!=Some(0)||line.unicode_utf16_start!=Some(0)||line.unicode_utf16_end!=Some(0)
   ||!line.exact_source_text_span||line.has_line_break||line.runs.iter().any(|r|!r.text.is_empty()||r.display_text.is_some()||r.inserted_control_text||r.footnote_marker.is_some())
   ||line.height_hu!=row.line_height||line.baseline_hu!=row.baseline_distance||line.width_hu!=row.segment_width
   ||line.column_start_hu!=row.column_start||line.spacing_hu!=row.line_spacing
   ||f.actual_heights.as_slice()!=[super::hwpunit_to_px(row.line_height,dpi)]
   ||f.actual_spacings.as_slice()!=[super::hwpunit_to_px(row.line_spacing,dpi)]{return None;}
  Some(OriginPaintSelection::Deferred(DeferredPaintPolicy))
 }
 pub(crate) fn plain_paint(&self,para:&Paragraph,section:usize,page:u32,column:u16,start:usize,end:usize,physical_width:f64,styles:&ResolvedStyleSet,dpi:f64)->Option<AcceptedPlainPaint>{
  if section!=self.trace.section()||!physical_width.is_finite()||physical_width<=0.0||dpi!=super::DEFAULT_DPI
   ||!para.field_ranges.is_empty()||!para.range_tags.is_empty()||!para.orphan_field_ends.is_empty()||!para.tab_extended.is_empty()
   ||para.numbering_restart.is_some()||!para.title_marks.is_empty()||!para.markpen_marks.is_empty()
   ||para.text.contains(['\t','\n','\r','\u{fffc}'])||para.controls.iter().any(|c|!matches!(c,Control::SectionDef(_)|Control::ColumnDef(_))){return None;}
  // Source char_offsets are HWP UTF16 units, while ComposedLine.char_start and
  // published charStart are Unicode scalar indices. Structural controls occupy
  // their own 16-unit prefix and must never be counted as source characters.
  let mut source_offset=match para.controls.as_slice(){[]=>0u32,[Control::SectionDef(_),Control::ColumnDef(_)]=>16u32,_=>return None};
  if para.char_offsets.len()!=para.text.chars().count(){return None;}
  for (ch,at) in para.text.chars().zip(&para.char_offsets){if *at!=source_offset{return None;}source_offset=source_offset.checked_add(ch.len_utf16() as u32)?;}
  if para.char_count!=source_offset.checked_add(1)?{return None;}
  let token=para as *const Paragraph as usize;
  let mut candidates=self.trace.commits().iter().filter(|c|c.section==section&&c.page==Some(page)&&c.column==column&&c.row_start==start&&c.row_end==end&&c.paragraph_token_matches);
  let commit=candidates.find(|c|self.trace.format(c.format_id).is_some_and(|f|f.paragraph_token==token))?;
  if candidates.any(|c|self.trace.format(c.format_id).is_some_and(|f|f.paragraph_token==token)){return None;}
  let format=self.trace.format(commit.format_id)?;
  if format.source_text!=para.text||format.source_char_offsets!=para.char_offsets{return None;}
  if format.has_numbering||format.has_horizontal_shaping||format.known_square_band
   ||format.before!=0.0||format.after!=0.0||format.lines.is_empty()||format.lines.len()>4096
   ||start>=end||end>format.lines.len(){return None;}
  let style=styles.para_styles.get(usize::from(para.para_shape_id))?;
  if style.margin_left!=0.0||style.margin_right!=0.0||style.indent!=0.0||style.spacing_before!=0.0||style.spacing_after!=0.0
   ||!matches!(style.head_type,crate::model::style::HeadType::None){return None;}
  let input_width=format.actual_input_width_px?;if !input_width.is_finite()||input_width<=0.0{return None;}
  // Both global-current reuse and local recomposition are actual formatter
  // selections. This does not relabel either selection as freshly recomposed.
  // This corrects only actual reuse across different physical column widths.
  // A narrow row remains the exact accepted row in a wider frame. It is NOT a
  // claim that this composition was recomputed at that later physical width.
  let commits=self.trace.commits().iter().filter(|c|c.paragraph==commit.paragraph).collect::<Vec<_>>();
  if commits.len()<2||!commits.iter().any(|c|c.actual_column_width_px!=input_width){return None;}
  let mut next=0usize;
  for c in &commits{
   if c.format_id!=commit.format_id||c.row_start!=next||c.row_end<=next||c.final_membership!=Some(true)
    ||!c.metrics_still_match_selected_format||!c.range_inside_selected_composition{return None;}
   next=c.row_end;
  }
  if next!=format.lines.len(){return None;}
  if format.actual_heights.len()!=format.lines.len()||format.actual_spacings.len()!=format.lines.len()
   ||format.lines.iter().enumerate().any(|(i,l)|format.actual_heights[i]!=super::hwpunit_to_px(l.height_hu,dpi)
    ||format.actual_spacings[i]!=super::hwpunit_to_px(l.spacing_hu,dpi)){return None;}
  let mut scalar=0usize;let mut utf16=0u32;
  for line in &format.lines{
   if line.scalar_start!=scalar||line.unicode_utf16_start!=Some(utf16)||!line.exact_source_text_span||line.has_line_break||line.height_hu<=0||line.spacing_hu<0
    ||line.baseline_hu<0||line.baseline_hu>line.height_hu||line.column_start_hu!=0{return None;}
   let next=line.scalar_end?;
   for run in &line.runs{utf16=utf16.checked_add(u32::try_from(run.utf16_units).ok()?)?;}
   if line.unicode_utf16_end!=Some(utf16)||line.original_hwp_char_offset!=para.char_offsets.get(scalar).copied(){return None;}
   scalar=next;
  }
  if scalar!=para.text.chars().count(){return None;}
  let line_box_width=input_width.min(physical_width);let bound=super::px_to_hwpunit(line_box_width,dpi);
  if bound<=0||format.lines[start..end].iter().any(|l|l.width_hu<=0||l.width_hu>bound){return None;}
  let composition=self.trace.selected_composition(commit.format_id)?;
  Some(AcceptedPlainPaint{composition,line_box_width})
 }
}
