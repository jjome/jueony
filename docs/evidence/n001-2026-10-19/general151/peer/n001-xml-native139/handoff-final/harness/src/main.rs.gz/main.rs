#![allow(dead_code)]
use rhwp::DocumentCore;
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::path::PathBuf;
fn hash(b: &[u8]) -> String {
    Sha256::digest(b)
        .iter()
        .map(|v| format!("{v:02x}"))
        .collect()
}
fn layout(d: &DocumentCore) -> Value {
    json!({"pages":d.page_count(),"layout":(0..d.page_count()).map(|p|json!({"text":serde_json::from_str::<Value>(&d.get_page_text_layout_native(p).unwrap()).unwrap(),"controls":serde_json::from_str::<Value>(&d.get_page_control_layout_native(p).unwrap()).unwrap()})).collect::<Vec<_>>()})
}
fn coverage(d: &DocumentCore) -> Value {
    let mut all = vec![];
    for (si, s) in d.document().sections.iter().enumerate() {
        for (pi, p) in s.paragraphs.iter().enumerate() {
            let chars = p.text.chars().collect::<Vec<_>>();
            let mut counts = vec![0usize; chars.len()];
            let mut cursor = 0usize;
            let mut errors = vec![];
            for page in 0..d.page_count() {
                let v: Value =
                    serde_json::from_str(&d.get_page_text_layout_native(page).unwrap()).unwrap();
                for run in v["runs"].as_array().unwrap() {
                    if run.get("cellPath").is_some() || run.get("parentParaIdx").is_some() {
                        continue;
                    }
                    if run["secIdx"] != si || run["paraIdx"] != pi {
                        continue;
                    }
                    let text = run["text"].as_str().unwrap().chars().collect::<Vec<_>>();
                    let start = run["charStart"].as_u64().unwrap() as usize;
                    let end = start + text.len();
                    if start != cursor
                        || end > chars.len()
                        || chars.get(start..end) != Some(text.as_slice())
                    {
                        errors.push(json!({"kind":"partition","page":page,"expected":cursor,"start":start,"end":end}));
                    }
                    if run["charX"].as_array().map(|x| x.len()) != Some(text.len() + 1) {
                        errors.push(json!({"kind":"charX"}));
                    }
                    for n in counts.iter_mut().take(end).skip(start) {
                        *n += 1;
                    }
                    cursor = end;
                }
            }
            let missing = counts.iter().filter(|&&v| v == 0).count();
            let duplicate = counts.iter().filter(|&&v| v > 1).count();
            if missing > 0 || duplicate > 0 || cursor != chars.len() {
                errors.push(json!({"kind":"coverage","missing":missing,"duplicate":duplicate,"end":cursor,"source":chars.len()}));
            }
            if !errors.is_empty() {
                all.push(json!({"section":si,"paragraph":pi,"errors":errors}));
            }
        }
    }
    json!({"passed":all.is_empty(),"errors":all})
}
fn diff(a: &Value, b: &Value, n: &mut usize) {
    match (a, b) {
        (Value::Object(a), Value::Object(b)) => {
            for k in a
                .keys()
                .chain(b.keys())
                .collect::<std::collections::BTreeSet<_>>()
            {
                match (a.get(k), b.get(k)) {
                    (Some(a), Some(b)) => diff(a, b, n),
                    _ => *n += 1,
                }
            }
        }
        (Value::Array(a), Value::Array(b)) => {
            if a.len() != b.len() {
                *n += 1;
            }
            for (a, b) in a.iter().zip(b) {
                diff(a, b, n)
            }
        }
        (Value::Number(a), Value::Number(b)) => {
            if (a.as_f64().unwrap() - b.as_f64().unwrap()).abs() > 0.2 {
                *n += 1
            }
        }
        _ => {
            if a != b {
                *n += 1
            }
        }
    }
}
fn details(d: &DocumentCore) -> Value {
    json!({"flow":rhwp::private_flow139(d),"paintInputs":rhwp::private_input139(d),"docInfo":format!("{:?}",d.document().doc_info),"docProperties":d.document().doc_properties,"paragraphs":d.document().sections[0].paragraphs.iter().enumerate().map(|(i,p)|json!({"i":i,"rows":p.line_segs,"sourceRows":p.source_line_seg_vertical_pos,"dirty":p.stored_text_partition_dirty,"frameFields":{"rawHeaderExtra":p.raw_header_extra,"charShapes":p.char_shapes,"paraShape":p.para_shape_id,"style":p.style_id,"columnType":p.column_type,"rawBreak":p.raw_break_type},"controls":p.controls})).collect::<Vec<_>>()})
}
fn differences(a: &Value, b: &Value, path: &str, out: &mut Vec<Value>) {
    match (a, b) {
        (Value::Object(a), Value::Object(b)) => {
            for k in a
                .keys()
                .chain(b.keys())
                .collect::<std::collections::BTreeSet<_>>()
            {
                match (a.get(k), b.get(k)) {
                    (Some(a), Some(b)) => differences(a, b, &format!("{path}/{k}"), out),
                    _ => out.push(json!({"path":format!("{path}/{k}"),"type":"key"})),
                }
            }
        }
        (Value::Array(a), Value::Array(b)) => {
            if a.len() != b.len() {
                out.push(json!({"path":path,"length":[a.len(),b.len()]}));
            }
            for (i, (a, b)) in a.iter().zip(b).enumerate() {
                differences(a, b, &format!("{path}/{i}"), out)
            }
        }
        (Value::Number(a), Value::Number(b)) => {
            if (a.as_f64().unwrap() - b.as_f64().unwrap()).abs() > 0.2 {
                out.push(json!({"path":path,"before":a,"after":b}))
            }
        }
        _ => {
            if a != b {
                out.push(json!({"path":path,"type":"value"}))
            }
        }
    }
}

fn disk(d: &DocumentCore, format: &str) -> Value {
    let before = layout(d);
    let source = hash(format!("{:?}", d.document()).as_bytes());
    let events = d.serialize_event_log();
    let artifact = if format == "hwp" {
        d.export_hwp_with_adapter_snapshot_with_report().unwrap()
    } else {
        d.export_hwpx_native_with_report().unwrap()
    };
    let next = DocumentCore::from_bytes(artifact.bytes()).unwrap();
    let mut differences_full=vec![]; differences(&before,&layout(&next),"$",&mut differences_full);
    let mut n = 0;
    diff(&before, &layout(&next), &mut n);
    assert_eq!(source, hash(format!("{:?}", d.document()).as_bytes()));
    assert_eq!(events, d.serialize_event_log());
    json!({"format":format,"geometryCount":n,"differences":differences_full,"loss":artifact.content_loss().len(),"sourceUnchanged":true,"readbackSha256":hash(artifact.bytes())})
}
fn main() {
 let compiled_resource=rhwp::private_resource139();println!("RESOURCE139 {}",compiled_resource);
    let root = PathBuf::from(std::env::var("N001_ROOT").unwrap());
    let out = PathBuf::from(std::env::var("N001_OUT").unwrap());
    std::fs::create_dir_all(&out).unwrap();
    let bytes = std::fs::read(
        root.join("apps/editor/tests/fixtures/n001-general125-own/unequal-three-offset.hwpx"),
    )
    .unwrap();
    let native = DocumentCore::from_bytes(&bytes)
        .unwrap()
        .export_hwp_with_adapter_snapshot_with_report()
        .unwrap()
        .bytes()
        .to_vec();
    let mut results = vec![];
    for (kind, bytes) in [("xml", bytes), ("native", native)] {
        for edits in [7usize, 15] {
            let mut d = DocumentCore::from_bytes(&bytes).unwrap();
            let base_layout = layout(&d);
            let base = d.save_snapshot_native();
            let at = d.document().sections[0].paragraphs[0].text.chars().count();
            d.insert_text_native(
                0,
                0,
                at,
                &"Retained current prefix editing causes line reflow. ".repeat(edits),
            )
            .unwrap();
            let edited = layout(&d);
            let edited_id = d.save_snapshot_native();
            let mut observations = vec![];
            for f in ["hwp", "hwpx"] {
                observations.push(disk(&d, f));
            }
            let checks = if kind == "xml" {
                Some(rhwp::private_origin_checks139(&d))
            } else {
                None
            };
            d.restore_snapshot_native(base).unwrap();
            let undo = layout(&d) == base_layout;
            d.restore_snapshot_native(edited_id).unwrap();
            let redo = layout(&d) == edited;
            for f in ["hwp", "hwpx"] {
                observations.push(disk(&d, f));
            }
            for cycle in 0..3 {
                let at = d.document().sections[0].paragraphs[0].text.chars().count();
                let text = "Current repeat prefix. ".repeat(2);
                d.insert_text_native(0, 0, at, &text).unwrap();
                for f in ["hwp", "hwpx"] {
                    observations.push(disk(&d, f));
                }
                d.delete_text_native(0, 0, at, text.chars().count())
                    .unwrap();
                for f in ["hwp", "hwpx"] {
                    observations.push(disk(&d, f));
                }
                std::fs::write(
                    out.join(format!("{kind}-{edits}-{cycle}.json")),
                    serde_json::to_vec_pretty(&observations).unwrap(),
                )
                .unwrap();
            }
            let r = json!({"kind":kind,"edits":edits,"inputSha256":hash(&bytes),"undoExact":undo,"redoExact":redo,"observations":observations,"policyChecks":checks});
            std::fs::write(
                out.join(format!("{kind}-{edits}-final.json")),
                serde_json::to_vec_pretty(&r).unwrap(),
            )
            .unwrap();
            results.push(r);
        }
    }
    std::fs::write(
        out.join("result.json"),
        serde_json::to_vec_pretty(&json!({"compiledResource":compiled_resource,"cases":results})).unwrap(),
    )
    .unwrap();
}
