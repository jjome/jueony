//! rhwp — Rust HWP 뷰어/에디터
//!
//! 본 제품은 한글과컴퓨터의 한글 문서 파일(.hwp) 공개 문서를 참고하여 개발하였습니다.

use wasm_bindgen::prelude::*;

pub mod hwt_leaf115;
pub mod agent;
pub mod agent_seal;
pub mod capabilities_schema;
pub mod diagnostics;
pub mod docdiff;
pub mod doclang;
pub mod document_core;
pub mod emf;
pub mod eps;
pub mod error;
pub use rhwp_contracts::ir_schema;
pub mod model;
pub mod ole_chart;
pub use rhwp_contracts::ontology;
pub use rhwp_ooxml_chart as ooxml_chart;
pub mod paint;
pub mod parser;
pub use rhwp_password_crypto as password_crypto;
pub mod plan_schema;
pub mod pq_sign;
pub use rhwp_contracts::provenance;
pub mod rag;
pub mod render_backend;
pub mod renderer;
pub mod scaffold;
pub mod schema_registry;
pub mod security_trailer;
pub mod serializer;
pub mod service;
/// 핫패치 벤더(Dioxus subsecond) 어댑터. **rhwp 의 API 가 아니다** (#4580).
///
/// `pub` 인 이유는 `tools/rhwp-subsecond` 가 `link_wasm_exports()` 를 불러 wasm export 를 살려
/// 둬야 하기 때문이지, 이 안의 함수들을 밖에서 쓰라는 뜻이 아니다. 격리 자체는 feature 가 이미
/// 지킨다 — `subsecond-dev` 없이는 모듈이 존재하지 않으므로 릴리스 표면에는 처음부터 나오지
/// 않는다. `#[doc(hidden)]` 은 그 사실을 문서에도 적는 것이다.
#[doc(hidden)]
#[cfg(feature = "subsecond-dev")]
pub mod subsecond_dev;
pub mod wasm_api;
pub mod wmf;

pub use document_core::DocumentCore;
pub use error::HwpError;
pub use model::event::DocumentEvent;
pub use parser::{parse_document, parse_document_with_password, DocumentParser};
pub use serializer::{serialize_document, DocumentSerializer};

/// WASM panic hook 초기화 (한 번만 실행)
#[wasm_bindgen(start)]
pub fn init_panic_hook() {
    #[cfg(feature = "console_error_panic_hook")]
    console_error_panic_hook::set_once();
}

#[wasm_bindgen]
pub fn version() -> String {
    env!("CARGO_PKG_VERSION").to_string()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_version() {
        assert_eq!(version(), env!("CARGO_PKG_VERSION"));
    }
}

#[cfg(not(target_arch="wasm32"))]
pub fn private_flow139(d:&DocumentCore)->serde_json::Value{serde_json::json!({"profile":format!("{:?}",d.effective_layout_profile()),"pagination":format!("{:?}",d.pagination),"measured":format!("{:?}",d.measured_sections),"currentView":d.pagination.iter().enumerate().map(|(i,r)|crate::renderer::current_accepted_composition::CurrentAcceptedCompositionView::from_current(r,&d.document.sections[i].paragraphs,&d.styles.for_section(i),d.effective_layout_profile(),d.dpi).is_some()).collect::<Vec<_>>()})}

#[cfg(not(target_arch="wasm32"))]
pub fn private_input139(d:&DocumentCore)->serde_json::Value{let c=d.document.native_source_synthetic_context_digest();serde_json::Value::Array(d.document.sections[0].paragraphs.iter().enumerate().map(|(i,p)|serde_json::json!({"i":i,"input":p.native_origin_paint_input.is_some(),"matches":p.native_origin_paint_input.as_ref().map(|x|x.matches_current_inputs(p,c)),"complete":p.completed_native_rows.is_some(),"source":p.owns_native_source_synthetic_rows(c),"rawBreak":p.raw_break_type,"axis":p.hwpx_axis_shift,"layoutOnly":p.layout_only_fill_lines,"textCodes":p.text.chars().map(|c|c as u32).take(12).collect::<Vec<_>>()})).collect())}
// Private harness only. Never part of the production runtime patch.
#[cfg(not(target_arch="wasm32"))]
pub fn private_origin_checks139(d:&DocumentCore)->serde_json::Value {
 use crate::renderer::{current_accepted_composition::CurrentAcceptedCompositionView as View,pagination::PageItem};
 use crate::model::{control::Control,paragraph::NumberingMarker};
 let section=0;let index=1;let control=0;
 let para=&d.document.sections[section].paragraphs[index];
 let context=d.document.native_source_synthetic_context_digest();
 let profile=d.effective_layout_profile();let result=&d.pagination[section];let styles=d.styles.for_section(section);
 let tables=&d.measured_sections[section].tables;
 let measured=tables.iter().find(|t|t.para_index==index&&t.control_index==control).unwrap();
 let (page,column,rect,item_token)=result.pages.iter().find_map(|p|p.column_contents.iter().find_map(|c|{
  c.items.iter().any(|i|matches!(i,PageItem::Table{para_index,control_index}if *para_index==index&&*control_index==control)).then(||{
   let r=c.zone_layout.as_ref().unwrap_or(&p.layout).column_areas[usize::from(c.column_index)];(p.page_index,c.column_index,[r.x,r.y,r.width,r.height],c.items.iter().find(|i|matches!(i,PageItem::Table{para_index,control_index}if *para_index==index&&*control_index==control)).unwrap() as *const _ as usize)})
 })).unwrap();
 let plain=View::from_current(result,&d.document.sections[section].paragraphs,&styles,profile,d.dpi).unwrap();
 let view=plain.clone().bind_origin_measurements(tables);
 let test=|v:&View,p:&crate::model::paragraph::Paragraph,m:&crate::renderer::height_measurer::MeasuredTable,r:[f64;4],ctx:[u8;32]|v.known_native_preinset(p,section,page,column,index,control,m,r,item_token,ctx,d.dpi);
 let mut cases=vec![];cases.push(serde_json::json!({"name":"actual_current_deferred","passed":test(&view,para,measured,rect,context)}));
 cases.push(serde_json::json!({"name":"no_core_measurement_binding","passed":!test(&plain,para,measured,rect,context)}));
 cases.push(serde_json::json!({"name":"cloned_source_owner","passed":!test(&view,&para.clone(),measured,rect,context)}));
 cases.push(serde_json::json!({"name":"cloned_measurement_owner","passed":!test(&view,para,&measured.clone(),rect,context)}));
 let mut wrong=rect;wrong[3]+=1.0;cases.push(serde_json::json!({"name":"wrong_physical_frame","passed":!test(&view,para,measured,wrong,context)}));
 let mut wrong_context=context;wrong_context[0]^=1;cases.push(serde_json::json!({"name":"wrong_source_context","passed":!test(&view,para,measured,rect,wrong_context)}));
 let input=para.native_origin_paint_input.as_ref().unwrap();
 let mut changed=para.clone();changed.line_segs[0].vertical_pos+=1;
 cases.push(serde_json::json!({"name":"unobserved_vpos_change","passed":!input.matches_current_inputs(&changed,context)}));
 let mut changed=para.clone();changed.line_segs[0].segment_width+=1;
 cases.push(serde_json::json!({"name":"row_width_change","passed":!input.matches_current_inputs(&changed,context)}));
 let mut changed=para.clone();changed.stored_text_partition_dirty=true;
 cases.push(serde_json::json!({"name":"host_dirty","passed":!input.matches_current_inputs(&changed,context)}));
 let mut changed=para.clone();let Control::Table(t)=&mut changed.controls[0]else{unreachable!()};t.raw_ctrl_seal=None;
 // Source may already have no raw seal. Use a distinct actual value either way.
 t.raw_ctrl_seal=Some([231;32]);
 cases.push(serde_json::json!({"name":"raw_table_seal_change","passed":!input.matches_current_inputs(&changed,context)}));
 let mut changed=para.clone();let Control::Table(t)=&mut changed.controls[0]else{unreachable!()};
 t.cells[0].paragraphs[0].numbering_marker=match t.cells[0].paragraphs[0].numbering_marker{NumberingMarker::Unresolved=>NumberingMarker::Absent,_=>NumberingMarker::Unresolved};
 cases.push(serde_json::json!({"name":"child_numbering_marker_change","passed":!input.matches_current_inputs(&changed,context)}));
 let mut changed=para.clone();let Control::Table(t)=&mut changed.controls[0]else{unreachable!()};t.cells[0].paragraphs[0].cell_vpos_reset=Some(true);
 cases.push(serde_json::json!({"name":"child_vpos_reset_change","passed":!input.matches_current_inputs(&changed,context)}));
 let mut changed=crate::renderer::pagination::PaginationResult {
 selected_composition_trace:result.selected_composition_trace.clone(),pages:result.pages.clone(),wrap_around_paras:result.wrap_around_paras.clone(),
 hidden_empty_paras:result.hidden_empty_paras.clone(),pre_emitted_host_paras:result.pre_emitted_host_paras.clone(),pre_emitted_host_heights:result.pre_emitted_host_heights.clone(),pre_emitted_host_content_heights:result.pre_emitted_host_content_heights.clone(),
 endnotes:result.endnotes.clone(),endnote_paragraphs:result.endnote_paragraphs.clone(),endnote_para_sources:result.endnote_para_sources.clone(),endnote_between_notes_hu:result.endnote_between_notes_hu,endnote_separator_above_hu:result.endnote_separator_above_hu,endnote_separator_below_hu:result.endnote_separator_below_hu,
 };let c=&mut changed.pages.iter_mut().find(|p|p.page_index==page).unwrap().column_contents.iter_mut().find(|c|c.column_index==column).unwrap();c.items.push(PageItem::Table{para_index:index,control_index:control});
 cases.push(serde_json::json!({"name":"duplicate_final_item","passed":View::from_current(&changed,&d.document.sections[section].paragraphs,&styles,profile,d.dpi).is_none()}));
 serde_json::json!({"cases":cases,"definitionContext":styles.reset_flow_context,"nativeSourceContext":context,"sourceSealRemainsFalse":!para.owns_native_source_synthetic_rows(context),"allPassed":cases.iter().all(|v|v["passed"]==true)})
}

// Excluded Native-only compiled resource witness.
#[cfg(not(target_arch="wasm32"))]
pub fn private_resource139()->String {
use sha2::{Digest,Sha256};
let inputs:&[(&str,&[u8])]=&[
("Cargo.lock",include_bytes!("../Cargo.lock").as_slice()),
("Cargo.toml",include_bytes!("../Cargo.toml").as_slice()),
("src/document_core/commands/document.rs",include_bytes!("document_core/commands/document.rs").as_slice()),
("src/document_core/native_computed_rows.rs",include_bytes!("document_core/native_computed_rows.rs").as_slice()),
("src/model/native_computed_rows.rs",include_bytes!("model/native_computed_rows.rs").as_slice()),
("src/renderer/canvas.rs",include_bytes!("renderer/canvas.rs").as_slice()),
("src/renderer/canvas_text_font.rs",include_bytes!("renderer/canvas_text_font.rs").as_slice()),
("src/renderer/canvaskit_m07_pack_contract.rs",include_bytes!("renderer/canvaskit_m07_pack_contract.rs").as_slice()),
("src/renderer/canvaskit_policy.rs",include_bytes!("renderer/canvaskit_policy.rs").as_slice()),
("src/renderer/composer.rs",include_bytes!("renderer/composer.rs").as_slice()),
("src/renderer/composer/line_breaking.rs",include_bytes!("renderer/composer/line_breaking.rs").as_slice()),
("src/renderer/composer/lineseg_compare.rs",include_bytes!("renderer/composer/lineseg_compare.rs").as_slice()),
("src/renderer/composer/lineseg_compare_tests.rs",include_bytes!("renderer/composer/lineseg_compare_tests.rs").as_slice()),
("src/renderer/composer/re_sample_gen.rs",include_bytes!("renderer/composer/re_sample_gen.rs").as_slice()),
("src/renderer/composer/supplemental_clusters.rs",include_bytes!("renderer/composer/supplemental_clusters.rs").as_slice()),
("src/renderer/composer/tests.rs",include_bytes!("renderer/composer/tests.rs").as_slice()),
("src/renderer/equation/ast.rs",include_bytes!("renderer/equation/ast.rs").as_slice()),
("src/renderer/equation/canvas_render.rs",include_bytes!("renderer/equation/canvas_render.rs").as_slice()),
("src/renderer/equation/dispatch.rs",include_bytes!("renderer/equation/dispatch.rs").as_slice()),
("src/renderer/equation/layout.rs",include_bytes!("renderer/equation/layout.rs").as_slice()),
("src/renderer/equation/legacy_hwpeq.rs",include_bytes!("renderer/equation/legacy_hwpeq.rs").as_slice()),
("src/renderer/equation/mod.rs",include_bytes!("renderer/equation/mod.rs").as_slice()),
("src/renderer/equation/parser.rs",include_bytes!("renderer/equation/parser.rs").as_slice()),
("src/renderer/equation/svg_render.rs",include_bytes!("renderer/equation/svg_render.rs").as_slice()),
("src/renderer/equation/symbols.rs",include_bytes!("renderer/equation/symbols.rs").as_slice()),
("src/renderer/equation/tokenizer.rs",include_bytes!("renderer/equation/tokenizer.rs").as_slice()),
("src/renderer/equation_tac_flow.rs",include_bytes!("renderer/equation_tac_flow.rs").as_slice()),
("src/renderer/float_placement.rs",include_bytes!("renderer/float_placement.rs").as_slice()),
("src/renderer/font_decision.rs",include_bytes!("renderer/font_decision.rs").as_slice()),
("src/renderer/font_environment.rs",include_bytes!("renderer/font_environment.rs").as_slice()),
("src/renderer/font_metrics_data.rs",include_bytes!("renderer/font_metrics_data.rs").as_slice()),
("src/renderer/font_metrics_generated.rs",include_bytes!("renderer/font_metrics_generated.rs").as_slice()),
("src/renderer/font_metrics_overlays.rs",include_bytes!("renderer/font_metrics_overlays.rs").as_slice()),
("src/renderer/font_paths.rs",include_bytes!("renderer/font_paths.rs").as_slice()),
("src/renderer/font_rule_projections/layout_metric.rs",include_bytes!("renderer/font_rule_projections/layout_metric.rs").as_slice()),
("src/renderer/font_rule_projections/layout_name.rs",include_bytes!("renderer/font_rule_projections/layout_name.rs").as_slice()),
("src/renderer/form_appearance.rs",include_bytes!("renderer/form_appearance.rs").as_slice()),
("src/renderer/form_caption.rs",include_bytes!("renderer/form_caption.rs").as_slice()),
("src/renderer/generated_column_stack.rs",include_bytes!("renderer/generated_column_stack.rs").as_slice()),
("src/renderer/gpu.rs",include_bytes!("renderer/gpu.rs").as_slice()),
("src/renderer/hancom_pua.rs",include_bytes!("renderer/hancom_pua.rs").as_slice()),
("src/renderer/height_cursor.rs",include_bytes!("renderer/height_cursor.rs").as_slice()),
("src/renderer/height_cursor_lazy_base.rs",include_bytes!("renderer/height_cursor_lazy_base.rs").as_slice()),
("src/renderer/height_measurer.rs",include_bytes!("renderer/height_measurer.rs").as_slice()),
("src/renderer/hft_ascii_evidence.rs",include_bytes!("renderer/hft_ascii_evidence.rs").as_slice()),
("src/renderer/html.rs",include_bytes!("renderer/html.rs").as_slice()),
("src/renderer/hyperlinks.rs",include_bytes!("renderer/hyperlinks.rs").as_slice()),
("src/renderer/image_header.rs",include_bytes!("renderer/image_header.rs").as_slice()),
("src/renderer/image_resolver.rs",include_bytes!("renderer/image_resolver.rs").as_slice()),
("src/renderer/inline_flow.rs",include_bytes!("renderer/inline_flow.rs").as_slice()),
("src/renderer/kerning.rs",include_bytes!("renderer/kerning.rs").as_slice()),
("src/renderer/layer_renderer.rs",include_bytes!("renderer/layer_renderer.rs").as_slice()),
("src/renderer/layout.rs",include_bytes!("renderer/layout.rs").as_slice()),
("src/renderer/layout/anchor_box_flow.rs",include_bytes!("renderer/layout/anchor_box_flow.rs").as_slice()),
("src/renderer/layout/border_rendering.rs",include_bytes!("renderer/layout/border_rendering.rs").as_slice()),
("src/renderer/layout/fixed_textbox_flow.rs",include_bytes!("renderer/layout/fixed_textbox_flow.rs").as_slice()),
("src/renderer/layout/integration_tests.rs",include_bytes!("renderer/layout/integration_tests.rs").as_slice()),
("src/renderer/layout/paragraph_layout.rs",include_bytes!("renderer/layout/paragraph_layout.rs").as_slice()),
("src/renderer/layout/paragraph_layout/issue_2439_lineseg_indent_tests.rs",include_bytes!("renderer/layout/paragraph_layout/issue_2439_lineseg_indent_tests.rs").as_slice()),
("src/renderer/layout/picture_footnote.rs",include_bytes!("renderer/layout/picture_footnote.rs").as_slice()),
("src/renderer/layout/shape_layout.rs",include_bytes!("renderer/layout/shape_layout.rs").as_slice()),
("src/renderer/layout/table_cell_content.rs",include_bytes!("renderer/layout/table_cell_content.rs").as_slice()),
("src/renderer/layout/table_layout.rs",include_bytes!("renderer/layout/table_layout.rs").as_slice()),
("src/renderer/layout/table_partial.rs",include_bytes!("renderer/layout/table_partial.rs").as_slice()),
("src/renderer/layout/tests.rs",include_bytes!("renderer/layout/tests.rs").as_slice()),
("src/renderer/layout/text_measurement.rs",include_bytes!("renderer/layout/text_measurement.rs").as_slice()),
("src/renderer/layout/utils.rs",include_bytes!("renderer/layout/utils.rs").as_slice()),
("src/renderer/layout_frame.rs",include_bytes!("renderer/layout_frame.rs").as_slice()),
("src/renderer/mod.rs",include_bytes!("renderer/mod.rs").as_slice()),
("src/renderer/page_layout.rs",include_bytes!("renderer/page_layout.rs").as_slice()),
("src/renderer/page_number.rs",include_bytes!("renderer/page_number.rs").as_slice()),
("src/renderer/pagination.rs",include_bytes!("renderer/pagination.rs").as_slice()),
("src/renderer/pagination/engine.rs",include_bytes!("renderer/pagination/engine.rs").as_slice()),
("src/renderer/pagination/state.rs",include_bytes!("renderer/pagination/state.rs").as_slice()),
("src/renderer/pagination/tests.rs",include_bytes!("renderer/pagination/tests.rs").as_slice()),
("src/renderer/partial_replay.rs",include_bytes!("renderer/partial_replay.rs").as_slice()),
("src/renderer/pdf.rs",include_bytes!("renderer/pdf.rs").as_slice()),
("src/renderer/pdf_raster_fidelity/catalog.rs",include_bytes!("renderer/pdf_raster_fidelity/catalog.rs").as_slice()),
("src/renderer/pdf_raster_fidelity/classify.rs",include_bytes!("renderer/pdf_raster_fidelity/classify.rs").as_slice()),
("src/renderer/pdf_raster_fidelity/contract.rs",include_bytes!("renderer/pdf_raster_fidelity/contract.rs").as_slice()),
("src/renderer/pdf_raster_fidelity/fingerprint.rs",include_bytes!("renderer/pdf_raster_fidelity/fingerprint.rs").as_slice()),
("src/renderer/pdf_raster_fidelity/isolate.rs",include_bytes!("renderer/pdf_raster_fidelity/isolate.rs").as_slice()),
("src/renderer/pdf_raster_fidelity/mod.rs",include_bytes!("renderer/pdf_raster_fidelity/mod.rs").as_slice()),
("src/renderer/pdf_raster_fidelity/pdf_page.rs",include_bytes!("renderer/pdf_raster_fidelity/pdf_page.rs").as_slice()),
("src/renderer/pdf_raster_fidelity/report.rs",include_bytes!("renderer/pdf_raster_fidelity/report.rs").as_slice()),
("src/renderer/pdf_raster_fidelity/wrap.rs",include_bytes!("renderer/pdf_raster_fidelity/wrap.rs").as_slice()),
("src/renderer/pdf_synthetic_bold.rs",include_bytes!("renderer/pdf_synthetic_bold.rs").as_slice()),
("src/renderer/pdf_synthetic_italic.rs",include_bytes!("renderer/pdf_synthetic_italic.rs").as_slice()),
("src/renderer/pua_oldhangul.rs",include_bytes!("renderer/pua_oldhangul.rs").as_slice()),
("src/renderer/render_normalization.rs",include_bytes!("renderer/render_normalization.rs").as_slice()),
("src/renderer/render_tree.rs",include_bytes!("renderer/render_tree.rs").as_slice()),
("src/renderer/scheduler.rs",include_bytes!("renderer/scheduler.rs").as_slice()),
("src/renderer/shaping.rs",include_bytes!("renderer/shaping.rs").as_slice()),
("src/renderer/shaping_composition.rs",include_bytes!("renderer/shaping_composition.rs").as_slice()),
("src/renderer/shaping_context.rs",include_bytes!("renderer/shaping_context.rs").as_slice()),
("src/renderer/shaping_paragraph.rs",include_bytes!("renderer/shaping_paragraph.rs").as_slice()),
("src/renderer/shaping_publication.rs",include_bytes!("renderer/shaping_publication.rs").as_slice()),
("src/renderer/shaping_vertical.rs",include_bytes!("renderer/shaping_vertical.rs").as_slice()),
("src/renderer/skia/equation_conv.rs",include_bytes!("renderer/skia/equation_conv.rs").as_slice()),
("src/renderer/skia/font_lookup.rs",include_bytes!("renderer/skia/font_lookup.rs").as_slice()),
("src/renderer/skia/glyph_replay.rs",include_bytes!("renderer/skia/glyph_replay.rs").as_slice()),
("src/renderer/skia/image_conv.rs",include_bytes!("renderer/skia/image_conv.rs").as_slice()),
("src/renderer/skia/mod.rs",include_bytes!("renderer/skia/mod.rs").as_slice()),
("src/renderer/skia/renderer.rs",include_bytes!("renderer/skia/renderer.rs").as_slice()),
("src/renderer/skia/text_replay.rs",include_bytes!("renderer/skia/text_replay.rs").as_slice()),
("src/renderer/static_svg.rs",include_bytes!("renderer/static_svg.rs").as_slice()),
("src/renderer/stored_float_anchor.rs",include_bytes!("renderer/stored_float_anchor.rs").as_slice()),
("src/renderer/style_resolver.rs",include_bytes!("renderer/style_resolver.rs").as_slice()),
("src/renderer/supplemental_metrics.rs",include_bytes!("renderer/supplemental_metrics.rs").as_slice()),
("src/renderer/svg.rs",include_bytes!("renderer/svg.rs").as_slice()),
("src/renderer/svg/tests.rs",include_bytes!("renderer/svg/tests.rs").as_slice()),
("src/renderer/svg_fragment.rs",include_bytes!("renderer/svg_fragment.rs").as_slice()),
("src/renderer/svg_layer.rs",include_bytes!("renderer/svg_layer.rs").as_slice()),
("src/renderer/text_decoration.rs",include_bytes!("renderer/text_decoration.rs").as_slice()),
("src/renderer/typeset.rs",include_bytes!("renderer/typeset.rs").as_slice()),
("src/renderer/typeset/controls.rs",include_bytes!("renderer/typeset/controls.rs").as_slice()),
("src/renderer/typeset/controls/decoration_host.rs",include_bytes!("renderer/typeset/controls/decoration_host.rs").as_slice()),
("src/renderer/typeset/controls/decoration_table.rs",include_bytes!("renderer/typeset/controls/decoration_table.rs").as_slice()),
("src/renderer/typeset/controls/deferred.rs",include_bytes!("renderer/typeset/controls/deferred.rs").as_slice()),
("src/renderer/typeset/controls/deferred_picture.rs",include_bytes!("renderer/typeset/controls/deferred_picture.rs").as_slice()),
("src/renderer/typeset/controls/deferred_placement.rs",include_bytes!("renderer/typeset/controls/deferred_placement.rs").as_slice()),
("src/renderer/typeset/controls/empty_float.rs",include_bytes!("renderer/typeset/controls/empty_float.rs").as_slice()),
("src/renderer/typeset/controls/flow_table.rs",include_bytes!("renderer/typeset/controls/flow_table.rs").as_slice()),
("src/renderer/typeset/controls/host_wrap.rs",include_bytes!("renderer/typeset/controls/host_wrap.rs").as_slice()),
("src/renderer/typeset/controls/order.rs",include_bytes!("renderer/typeset/controls/order.rs").as_slice()),
("src/renderer/typeset/controls/paragraph_flow.rs",include_bytes!("renderer/typeset/controls/paragraph_flow.rs").as_slice()),
("src/renderer/typeset/controls/shape_flow.rs",include_bytes!("renderer/typeset/controls/shape_flow.rs").as_slice()),
("src/renderer/typeset/controls/stored_tac.rs",include_bytes!("renderer/typeset/controls/stored_tac.rs").as_slice()),
("src/renderer/typeset/controls/table_entry.rs",include_bytes!("renderer/typeset/controls/table_entry.rs").as_slice()),
("src/renderer/typeset/controls/tac_fit.rs",include_bytes!("renderer/typeset/controls/tac_fit.rs").as_slice()),
("src/renderer/typeset/controls/tac_flow.rs",include_bytes!("renderer/typeset/controls/tac_flow.rs").as_slice()),
("src/renderer/typeset/controls/tac_reconcile.rs",include_bytes!("renderer/typeset/controls/tac_reconcile.rs").as_slice()),
("src/renderer/typeset/controls/wrap_absorption.rs",include_bytes!("renderer/typeset/controls/wrap_absorption.rs").as_slice()),
("src/renderer/typeset/controls/wrap_flow.rs",include_bytes!("renderer/typeset/controls/wrap_flow.rs").as_slice()),
("src/renderer/typeset/controls/wrap_match.rs",include_bytes!("renderer/typeset/controls/wrap_match.rs").as_slice()),
("src/renderer/typeset/controls/wrap_tail.rs",include_bytes!("renderer/typeset/controls/wrap_tail.rs").as_slice()),
("src/renderer/typeset/inline_flow.rs",include_bytes!("renderer/typeset/inline_flow.rs").as_slice()),
("src/renderer/typeset/inline_flow/plan.rs",include_bytes!("renderer/typeset/inline_flow/plan.rs").as_slice()),
("src/renderer/typeset/notes.rs",include_bytes!("renderer/typeset/notes.rs").as_slice()),
("src/renderer/typeset/notes/endnotes.rs",include_bytes!("renderer/typeset/notes/endnotes.rs").as_slice()),
("src/renderer/typeset/notes/endnotes/content.rs",include_bytes!("renderer/typeset/notes/endnotes/content.rs").as_slice()),
("src/renderer/typeset/notes/endnotes/debug.rs",include_bytes!("renderer/typeset/notes/endnotes/debug.rs").as_slice()),
("src/renderer/typeset/notes/endnotes/emit.rs",include_bytes!("renderer/typeset/notes/endnotes/emit.rs").as_slice()),
("src/renderer/typeset/notes/endnotes/fit.rs",include_bytes!("renderer/typeset/notes/endnotes/fit.rs").as_slice()),
("src/renderer/typeset/notes/endnotes/format.rs",include_bytes!("renderer/typeset/notes/endnotes/format.rs").as_slice()),
("src/renderer/typeset/notes/endnotes/measure.rs",include_bytes!("renderer/typeset/notes/endnotes/measure.rs").as_slice()),
("src/renderer/typeset/notes/endnotes/metrics.rs",include_bytes!("renderer/typeset/notes/endnotes/metrics.rs").as_slice()),
("src/renderer/typeset/notes/endnotes/paragraph.rs",include_bytes!("renderer/typeset/notes/endnotes/paragraph.rs").as_slice()),
("src/renderer/typeset/notes/endnotes/paragraph/initial_fit.rs",include_bytes!("renderer/typeset/notes/endnotes/paragraph/initial_fit.rs").as_slice()),
("src/renderer/typeset/notes/endnotes/paragraph/new_note_fit.rs",include_bytes!("renderer/typeset/notes/endnotes/paragraph/new_note_fit.rs").as_slice()),
("src/renderer/typeset/notes/endnotes/paragraph/rewind_tail.rs",include_bytes!("renderer/typeset/notes/endnotes/paragraph/rewind_tail.rs").as_slice()),
("src/renderer/typeset/notes/endnotes/paragraph/tail_fit.rs",include_bytes!("renderer/typeset/notes/endnotes/paragraph/tail_fit.rs").as_slice()),
("src/renderer/typeset/notes/endnotes/prepare.rs",include_bytes!("renderer/typeset/notes/endnotes/prepare.rs").as_slice()),
("src/renderer/typeset/notes/endnotes/profile.rs",include_bytes!("renderer/typeset/notes/endnotes/profile.rs").as_slice()),
("src/renderer/typeset/notes/endnotes/types.rs",include_bytes!("renderer/typeset/notes/endnotes/types.rs").as_slice()),
("src/renderer/typeset/notes/footnotes.rs",include_bytes!("renderer/typeset/notes/footnotes.rs").as_slice()),
("src/renderer/typeset/notes/footnotes/body.rs",include_bytes!("renderer/typeset/notes/footnotes/body.rs").as_slice()),
("src/renderer/typeset/notes/footnotes/boundary.rs",include_bytes!("renderer/typeset/notes/footnotes/boundary.rs").as_slice()),
("src/renderer/typeset/notes/footnotes/measure.rs",include_bytes!("renderer/typeset/notes/footnotes/measure.rs").as_slice()),
("src/renderer/typeset/paragraph.rs",include_bytes!("renderer/typeset/paragraph.rs").as_slice()),
("src/renderer/typeset/paragraph/boundary.rs",include_bytes!("renderer/typeset/paragraph/boundary.rs").as_slice()),
("src/renderer/typeset/paragraph/columns.rs",include_bytes!("renderer/typeset/paragraph/columns.rs").as_slice()),
("src/renderer/typeset/paragraph/context.rs",include_bytes!("renderer/typeset/paragraph/context.rs").as_slice()),
("src/renderer/typeset/paragraph/empty.rs",include_bytes!("renderer/typeset/paragraph/empty.rs").as_slice()),
("src/renderer/typeset/paragraph/entry.rs",include_bytes!("renderer/typeset/paragraph/entry.rs").as_slice()),
("src/renderer/typeset/paragraph/fit.rs",include_bytes!("renderer/typeset/paragraph/fit.rs").as_slice()),
("src/renderer/typeset/paragraph/flow.rs",include_bytes!("renderer/typeset/paragraph/flow.rs").as_slice()),
("src/renderer/typeset/paragraph/format.rs",include_bytes!("renderer/typeset/paragraph/format.rs").as_slice()),
("src/renderer/typeset/paragraph/line_queries.rs",include_bytes!("renderer/typeset/paragraph/line_queries.rs").as_slice()),
("src/renderer/typeset/paragraph/metrics.rs",include_bytes!("renderer/typeset/paragraph/metrics.rs").as_slice()),
("src/renderer/typeset/paragraph/mixed_tac_owner.rs",include_bytes!("renderer/typeset/paragraph/mixed_tac_owner.rs").as_slice()),
("src/renderer/typeset/paragraph/overflow.rs",include_bytes!("renderer/typeset/paragraph/overflow.rs").as_slice()),
("src/renderer/typeset/paragraph/placement.rs",include_bytes!("renderer/typeset/paragraph/placement.rs").as_slice()),
("src/renderer/typeset/paragraph/scan.rs",include_bytes!("renderer/typeset/paragraph/scan.rs").as_slice()),
("src/renderer/typeset/paragraph/split.rs",include_bytes!("renderer/typeset/paragraph/split.rs").as_slice()),
("src/renderer/typeset/paragraph/split_entry.rs",include_bytes!("renderer/typeset/paragraph/split_entry.rs").as_slice()),
("src/renderer/typeset/paragraph/stored_lines.rs",include_bytes!("renderer/typeset/paragraph/stored_lines.rs").as_slice()),
("src/renderer/typeset/paragraph/whole_fit.rs",include_bytes!("renderer/typeset/paragraph/whole_fit.rs").as_slice()),
("src/renderer/typeset/section.rs",include_bytes!("renderer/typeset/section.rs").as_slice()),
("src/renderer/typeset/section/boundary.rs",include_bytes!("renderer/typeset/section/boundary.rs").as_slice()),
("src/renderer/typeset/section/columns.rs",include_bytes!("renderer/typeset/section/columns.rs").as_slice()),
("src/renderer/typeset/section/controls.rs",include_bytes!("renderer/typeset/section/controls.rs").as_slice()),
("src/renderer/typeset/section/entry.rs",include_bytes!("renderer/typeset/section/entry.rs").as_slice()),
("src/renderer/typeset/section/finalize.rs",include_bytes!("renderer/typeset/section/finalize.rs").as_slice()),
("src/renderer/typeset/section/flow.rs",include_bytes!("renderer/typeset/section/flow.rs").as_slice()),
("src/renderer/typeset/section/heading.rs",include_bytes!("renderer/typeset/section/heading.rs").as_slice()),
("src/renderer/typeset/section/post_flow.rs",include_bytes!("renderer/typeset/section/post_flow.rs").as_slice()),
("src/renderer/typeset/section/stored_reset.rs",include_bytes!("renderer/typeset/section/stored_reset.rs").as_slice()),
("src/renderer/typeset/section/tail.rs",include_bytes!("renderer/typeset/section/tail.rs").as_slice()),
("src/renderer/typeset/section/vpos.rs",include_bytes!("renderer/typeset/section/vpos.rs").as_slice()),
("src/renderer/typeset/state.rs",include_bytes!("renderer/typeset/state.rs").as_slice()),
("src/renderer/typeset/state/commands.rs",include_bytes!("renderer/typeset/state/commands.rs").as_slice()),
("src/renderer/typeset/state/data.rs",include_bytes!("renderer/typeset/state/data.rs").as_slice()),
("src/renderer/typeset/state/finalize.rs",include_bytes!("renderer/typeset/state/finalize.rs").as_slice()),
("src/renderer/typeset/state/notes.rs",include_bytes!("renderer/typeset/state/notes.rs").as_slice()),
("src/renderer/typeset/state/transition.rs",include_bytes!("renderer/typeset/state/transition.rs").as_slice()),
("src/renderer/typeset/table.rs",include_bytes!("renderer/typeset/table.rs").as_slice()),
("src/renderer/typeset/table/block.rs",include_bytes!("renderer/typeset/table/block.rs").as_slice()),
("src/renderer/typeset/table/block/entry.rs",include_bytes!("renderer/typeset/table/block/entry.rs").as_slice()),
("src/renderer/typeset/table/block/host_placement.rs",include_bytes!("renderer/typeset/table/block/host_placement.rs").as_slice()),
("src/renderer/typeset/table/block/prepare.rs",include_bytes!("renderer/typeset/table/block/prepare.rs").as_slice()),
("src/renderer/typeset/table/block/whole_fit.rs",include_bytes!("renderer/typeset/table/block/whole_fit.rs").as_slice()),
("src/renderer/typeset/table/continuation.rs",include_bytes!("renderer/typeset/table/continuation.rs").as_slice()),
("src/renderer/typeset/table/continuation/fragment.rs",include_bytes!("renderer/typeset/table/continuation/fragment.rs").as_slice()),
("src/renderer/typeset/table/continuation/fragment/budget.rs",include_bytes!("renderer/typeset/table/continuation/fragment/budget.rs").as_slice()),
("src/renderer/typeset/table/continuation/fragment/emit.rs",include_bytes!("renderer/typeset/table/continuation/fragment/emit.rs").as_slice()),
("src/renderer/typeset/table/continuation/fragment/scan.rs",include_bytes!("renderer/typeset/table/continuation/fragment/scan.rs").as_slice()),
("src/renderer/typeset/table/continuation/job.rs",include_bytes!("renderer/typeset/table/continuation/job.rs").as_slice()),
("src/renderer/typeset/table/continuation/step.rs",include_bytes!("renderer/typeset/table/continuation/step.rs").as_slice()),
("src/renderer/typeset/table/footnotes.rs",include_bytes!("renderer/typeset/table/footnotes.rs").as_slice()),
("src/renderer/typeset/table/host_spacing.rs",include_bytes!("renderer/typeset/table/host_spacing.rs").as_slice()),
("src/renderer/typeset/table/scan.rs",include_bytes!("renderer/typeset/table/scan.rs").as_slice()),
("src/renderer/typeset/table/scan/block_fit.rs",include_bytes!("renderer/typeset/table/scan/block_fit.rs").as_slice()),
("src/renderer/typeset/table/scan/block_fragment.rs",include_bytes!("renderer/typeset/table/scan/block_fragment.rs").as_slice()),
("src/renderer/typeset/table/scan/landscape.rs",include_bytes!("renderer/typeset/table/scan/landscape.rs").as_slice()),
("src/renderer/typeset/table/scan/row.rs",include_bytes!("renderer/typeset/table/scan/row.rs").as_slice()),
("src/renderer/typeset/table/scan/row_entry.rs",include_bytes!("renderer/typeset/table/scan/row_entry.rs").as_slice()),
("src/renderer/typeset/table/scan/runner.rs",include_bytes!("renderer/typeset/table/scan/runner.rs").as_slice()),
("src/renderer/typeset/table/scan/runner/block_step.rs",include_bytes!("renderer/typeset/table/scan/runner/block_step.rs").as_slice()),
("src/renderer/typeset/table/scan/runner/row_step.rs",include_bytes!("renderer/typeset/table/scan/runner/row_step.rs").as_slice()),
("src/renderer/typeset/table/scan/source_frame.rs",include_bytes!("renderer/typeset/table/scan/source_frame.rs").as_slice()),
("src/renderer/typeset/table/scan/source_tail.rs",include_bytes!("renderer/typeset/table/scan/source_tail.rs").as_slice()),
("src/renderer/typeset/table/scan/source_tail/extension.rs",include_bytes!("renderer/typeset/table/scan/source_tail/extension.rs").as_slice()),
("src/renderer/typeset/table/scan/types.rs",include_bytes!("renderer/typeset/table/scan/types.rs").as_slice()),
("src/renderer/web_canvas.rs",include_bytes!("renderer/web_canvas.rs").as_slice()),
("src/diagnostics/ir_field_sweep.rs",include_bytes!("diagnostics/ir_field_sweep.rs").as_slice()),
("src/document_core/mod.rs",include_bytes!("document_core/mod.rs").as_slice()),
("src/document_core/queries/rendering.rs",include_bytes!("document_core/queries/rendering.rs").as_slice()),
("src/model/paragraph.rs",include_bytes!("model/paragraph.rs").as_slice()),
("src/model/raw_provenance.rs",include_bytes!("model/raw_provenance.rs").as_slice()),
("src/renderer/layout/current_body_stack.rs",include_bytes!("renderer/layout/current_body_stack.rs").as_slice()),
("src/serializer/hwpx/standard_rows.rs",include_bytes!("serializer/hwpx/standard_rows.rs").as_slice()),
("src/serializer/hwpx/mod.rs",include_bytes!("serializer/hwpx/mod.rs").as_slice()),
("src/serializer/hwpx/context.rs",include_bytes!("serializer/hwpx/context.rs").as_slice()),
("src/serializer/hwpx/section.rs",include_bytes!("serializer/hwpx/section.rs").as_slice()),
("src/serializer/control.rs",include_bytes!("serializer/control.rs").as_slice()),
("src/document_core/document_metadata_stamped_export.rs",include_bytes!("document_core/document_metadata_stamped_export.rs").as_slice()),
("src/parser/mod.rs",include_bytes!("parser/mod.rs").as_slice()),
("src/parser/native_computed_rows.rs",include_bytes!("parser/native_computed_rows.rs").as_slice()),
("src/serializer/cfb_writer.rs",include_bytes!("serializer/cfb_writer.rs").as_slice()),
("src/serializer/native_computed_rows.rs",include_bytes!("serializer/native_computed_rows.rs").as_slice()),
("crates/rhwp-password-crypto/Cargo.toml",include_bytes!("../crates/rhwp-password-crypto/Cargo.toml").as_slice()),
("crates/rhwp-password-crypto/src/lib.rs",include_bytes!("../crates/rhwp-password-crypto/src/lib.rs").as_slice()),
("src/model/opaque_native_row_archive.rs",include_bytes!("model/opaque_native_row_archive.rs").as_slice()),
("src/model/mod.rs",include_bytes!("model/mod.rs").as_slice()),
("src/parser/hwpx/mod.rs",include_bytes!("parser/hwpx/mod.rs").as_slice()),
("src/parser/hwpx/reader.rs",include_bytes!("parser/hwpx/reader.rs").as_slice()),
("src/parser/hwpx/raw_zip_authority.rs",include_bytes!("parser/hwpx/raw_zip_authority.rs").as_slice()),
("src/renderer/composer/unchanged_native_tac.rs",include_bytes!("renderer/composer/unchanged_native_tac.rs").as_slice()),
("src/model/native_tac_spacing_input126.rs",include_bytes!("model/native_tac_spacing_input126.rs").as_slice()),
("src/renderer/current_frame_rows_plan.rs",include_bytes!("renderer/current_frame_rows_plan.rs").as_slice()),
("src/renderer/current_physical_selections.rs",include_bytes!("renderer/current_physical_selections.rs").as_slice()),
("src/renderer/selected_composition_observer127.rs",include_bytes!("renderer/selected_composition_observer127.rs").as_slice()),
("src/serializer/hwpx/current_frame_rows.rs",include_bytes!("serializer/hwpx/current_frame_rows.rs").as_slice()),
("src/renderer/current_accepted_composition.rs",include_bytes!("renderer/current_accepted_composition.rs").as_slice()),
("src/model/object_anchor.rs",include_bytes!("model/object_anchor.rs").as_slice()),
("src/document_core/commands/object_ops/table.rs",include_bytes!("document_core/commands/object_ops/table.rs").as_slice()),
("src/renderer/current_offset_frame.rs",include_bytes!("renderer/current_offset_frame.rs").as_slice()),
("src/renderer/current_equal_column_prefix.rs",include_bytes!("renderer/current_equal_column_prefix.rs").as_slice()),
("src/model/native_origin_paint139.rs",include_bytes!("model/native_origin_paint139.rs").as_slice()),
("src/document_core/commands/text_editing.rs",include_bytes!("document_core/commands/text_editing.rs").as_slice()),
];let mut h=Sha256::new();h.update(b"rhwp-portable-native-text-edit-frame-1;source-text-lf\0");
for (name,b) in inputs {let c=b.windows(2).enumerate().filter_map(|(i,x)|if x==b"\r\n"{None}else{Some(b[i])}).chain(b.last().copied()).collect::<Vec<_>>();
h.update(name.as_bytes());h.update([0]);h.update((c.len() as u64).to_le_bytes());h.update(c);}
let value:[u8;32]=h.finalize().into();assert_eq!(value,crate::model::native_computed_resource::RESOURCE);
value.iter().map(|v|format!("{v:02x}")).collect() }
