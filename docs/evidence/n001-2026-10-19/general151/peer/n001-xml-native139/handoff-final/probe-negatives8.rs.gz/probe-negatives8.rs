// Private harness only. Never part of the production runtime patch.
#[cfg(not(target_arch="wasm32"))]
pub fn private_origin_checks139(d:&DocumentCore)->serde_json::Value {
 use crate::renderer::{current_accepted_composition::CurrentAcceptedCompositionView as View,pagination::PageItem};
 use crate::model::{control::Control,paragraph::NumberingMarker};
 let section=0;let index=1;let control=0;
 let para=&d.document.sections[section].paragraphs[index];
 let context=d.document.native_source_synthetic_context_digest();
 let profile=d.effective_layout_profile();let result=&d.pagination[section];let styles=d.styles.for_section(section);
 let tables=&d.measured_sections[section].tables;
 let measured=tables.iter().find(|t|t.para_index==index&&t.control_index==control).unwrap();
 let (page,column,rect,item_token)=result.pages.iter().find_map(|p|p.column_contents.iter().find_map(|c|{
  c.items.iter().any(|i|matches!(i,PageItem::Table{para_index,control_index}if *para_index==index&&*control_index==control)).then(||{
   let r=c.zone_layout.as_ref().unwrap_or(&p.layout).column_areas[usize::from(c.column_index)];(p.page_index,c.column_index,[r.x,r.y,r.width,r.height],c.items.iter().find(|i|matches!(i,PageItem::Table{para_index,control_index}if *para_index==index&&*control_index==control)).unwrap() as *const _ as usize)})
 })).unwrap();
 let plain=View::from_current(result,&d.document.sections[section].paragraphs,&styles,profile,d.dpi).unwrap();
 let view=plain.clone().bind_origin_measurements(tables);
 let test=|v:&View,p:&crate::model::paragraph::Paragraph,m:&crate::renderer::height_measurer::MeasuredTable,r:[f64;4],ctx:[u8;32]|v.known_native_preinset(p,section,page,column,index,control,m,r,item_token,ctx,d.dpi);
 let mut cases=vec![];cases.push(serde_json::json!({"name":"actual_current_deferred","passed":test(&view,para,measured,rect,context)}));
 cases.push(serde_json::json!({"name":"no_core_measurement_binding","passed":!test(&plain,para,measured,rect,context)}));
 cases.push(serde_json::json!({"name":"cloned_source_owner","passed":!test(&view,&para.clone(),measured,rect,context)}));
 cases.push(serde_json::json!({"name":"cloned_measurement_owner","passed":!test(&view,para,&measured.clone(),rect,context)}));
 let mut wrong=rect;wrong[3]+=1.0;cases.push(serde_json::json!({"name":"wrong_physical_frame","passed":!test(&view,para,measured,wrong,context)}));
 let mut wrong_context=context;wrong_context[0]^=1;cases.push(serde_json::json!({"name":"wrong_source_context","passed":!test(&view,para,measured,rect,wrong_context)}));
 let input=para.native_origin_paint_input.as_ref().unwrap();
 let mut changed=para.clone();changed.line_segs[0].vertical_pos+=1;
 cases.push(serde_json::json!({"name":"unobserved_vpos_change","passed":!input.matches_current_inputs(&changed,context)}));
 let mut changed=para.clone();changed.line_segs[0].segment_width+=1;
 cases.push(serde_json::json!({"name":"row_width_change","passed":!input.matches_current_inputs(&changed,context)}));
 let mut changed=para.clone();changed.stored_text_partition_dirty=true;
 cases.push(serde_json::json!({"name":"host_dirty","passed":!input.matches_current_inputs(&changed,context)}));
 let mut changed=para.clone();let Control::Table(t)=&mut changed.controls[0]else{unreachable!()};t.raw_ctrl_seal=None;
 // Source may already have no raw seal. Use a distinct actual value either way.
 t.raw_ctrl_seal=Some([231;32]);
 cases.push(serde_json::json!({"name":"raw_table_seal_change","passed":!input.matches_current_inputs(&changed,context)}));
 let mut changed=para.clone();let Control::Table(t)=&mut changed.controls[0]else{unreachable!()};
 t.cells[0].paragraphs[0].numbering_marker=match t.cells[0].paragraphs[0].numbering_marker{NumberingMarker::Unresolved=>NumberingMarker::Absent,_=>NumberingMarker::Unresolved};
 cases.push(serde_json::json!({"name":"child_numbering_marker_change","passed":!input.matches_current_inputs(&changed,context)}));
 let mut changed=para.clone();let Control::Table(t)=&mut changed.controls[0]else{unreachable!()};t.cells[0].paragraphs[0].cell_vpos_reset=Some(true);
 cases.push(serde_json::json!({"name":"child_vpos_reset_change","passed":!input.matches_current_inputs(&changed,context)}));
 let mut changed=crate::renderer::pagination::PaginationResult {
 selected_composition_trace:result.selected_composition_trace.clone(),pages:result.pages.clone(),wrap_around_paras:result.wrap_around_paras.clone(),
 hidden_empty_paras:result.hidden_empty_paras.clone(),pre_emitted_host_paras:result.pre_emitted_host_paras.clone(),pre_emitted_host_heights:result.pre_emitted_host_heights.clone(),pre_emitted_host_content_heights:result.pre_emitted_host_content_heights.clone(),
 endnotes:result.endnotes.clone(),endnote_paragraphs:result.endnote_paragraphs.clone(),endnote_para_sources:result.endnote_para_sources.clone(),endnote_between_notes_hu:result.endnote_between_notes_hu,endnote_separator_above_hu:result.endnote_separator_above_hu,endnote_separator_below_hu:result.endnote_separator_below_hu,
 };let c=&mut changed.pages.iter_mut().find(|p|p.page_index==page).unwrap().column_contents.iter_mut().find(|c|c.column_index==column).unwrap();c.items.push(PageItem::Table{para_index:index,control_index:control});
 cases.push(serde_json::json!({"name":"duplicate_final_item","passed":View::from_current(&changed,&d.document.sections[section].paragraphs,&styles,profile,d.dpi).is_none()}));
 serde_json::json!({"cases":cases,"definitionContext":styles.reset_flow_context,"nativeSourceContext":context,"sourceSealRemainsFalse":!para.owns_native_source_synthetic_rows(context),"allPassed":cases.iter().all(|v|v["passed"]==true)})
}
