#!/usr/bin/env bash
set -euo pipefail
repo=/mnt/c/Users/jjome/Documents/work/jueony
export RUSTUP_HOME="$repo/.tools/linux-rustup"
export CARGO_HOME="$repo/.tools/linux-cargo"
export PATH="$CARGO_HOME/bin:$PATH"
export CARGO_TARGET_DIR=/tmp/jueony-n001-xml-native139-ONLY
export N001_ROOT="$repo"
export N001_OUT="$repo/build/n001-xml-native139/${1:?stage}"
cd "$repo/build/n001-xml-native139/harness"
cargo run --release --offline --locked
