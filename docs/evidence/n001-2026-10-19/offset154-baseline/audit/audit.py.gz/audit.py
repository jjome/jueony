"""Read-only static verifier audit; writes evidence only in this directory."""
from pathlib import Path
from hashlib import sha256
from collections import Counter
from datetime import datetime, timezone
import json

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
def digest(data): return sha256(data).hexdigest()
def file_info(path):
    path = Path(path)
    data = path.read_bytes()
    return {"path": str(path.resolve()), "bytes": len(data), "sha256": digest(data),
            "canonicalLfSha256": digest(data.replace(b"\r\n", b"\n"))}
def read(path): return json.loads(Path(path).read_text(encoding="utf-8"))

verifier = root / 'apps/editor/scripts/verify-offset-three-storage154.mjs'
helper = root / 'apps/editor/scripts/lib/hancom-review.mjs'
baseline_dir = root / 'build/n001-offset154-before151-r3'
baseline = read(baseline_dir / 'result.json')
manifest_path = root / 'apps/editor/tests/fixtures/n001-general125-own/manifest.json'
manifest = read(manifest_path)
fixture = next(x for x in manifest['fixtures'] if x['file'] == 'unequal-three-offset.hwp')
assert file_info(verifier)['sha256'] == baseline['verifierSha256']
assert file_info(manifest_path)['sha256'] == baseline['manifestSha256']
inputs = []
for kind, name, key in [('native', fixture['file'], 'sha256'), ('xml', fixture['xmlFile'], 'xmlSha256')]:
    entry = {"origin": kind, **file_info(manifest_path.parent / name)}
    assert entry['sha256'] == fixture[key]
    inputs.append(entry)

guards = []
for source in baseline['sourceHashes']:
    relative = Path('apps/editor/src/adapters/rhwp') / source['path']
    mirror = file_info(root / 'build/n001-clean-review123' / relative)
    current = file_info(root / relative)
    assert mirror['sha256'] == source['sha256']
    guards.append({"relativePath": str(relative).replace('\\', '/'),
                   "baselineSha256": source['sha256'], "cleanMirror": mirror,
                   "workspace": current,
                   "workspaceRawEqualsBaseline": current['sha256'] == source['sha256'],
                   "workspaceCanonicalLfEqualsMirror": current['canonicalLfSha256'] == mirror['canonicalLfSha256']})

engine_dir = root / 'build/rhwp-engine/source-9df387f1a8b85d06/pkg'
engine_artifacts = [file_info(engine_dir / name) for name in ['rhwp.js', 'rhwp_bg.wasm', 'jueony-engine-build.json']]
assert engine_artifacts[0]['sha256'] == baseline['engine']['jsSha256']
assert engine_artifacts[1]['sha256'] == baseline['engine']['wasmSha256']

disks = []
for item in baseline['observations']:
    actual = file_info(baseline_dir / (item['label'] + '.' + item['format']))
    assert actual['sha256'] == item['sha256']
    disks.append({"label": item['label'], "format": item['format'], "encrypted": item['encrypted'], **actual})
assert len(disks) == 12
assert len(baseline['results']) == 16 and len(baseline['failures']) == 16
assert all(x['status'] == 'FAIL' for x in baseline['results'])

wip_evidence_path = root / 'docs/evidence/n001-2026-10-19/general151/summary.json'
wip_initial_path = root / 'build/n001-general125-unrelated-initial.json'
wip_entries = read(wip_evidence_path)['unrelated45Unchanged']
wip_initial = read(wip_initial_path)
assert len(wip_entries) == 45
wip_checked = []
for entry in wip_entries:
    actual = file_info(root / entry['path'])
    assert actual['sha256'] == entry['sha256'] == wip_initial[entry['path']]
    wip_checked.append({"path": entry['path'], "sha256": actual['sha256']})

checks = [
 {"id":"pinned-originals", "status":"CONFIRMED", "detail":"Both original fixed Native/XML byte hashes are asserted before every case; no source regeneration or descriptor/line-segment modification occurs."},
 {"id":"actual-public-edit", "status":"CONFIRMED", "detail":"Public insertText is followed by exact original+payload equality. Retained tail insert is separately asserted, including supplementary Unicode."},
 {"id":"body-source-coverage", "status":"CONFIRMED_WITH_LIMIT", "detail":"Every top-level body paragraph's complete scalar text is reconstructed exactly once and in source order from published runs; charStart and scalar+1 charX length are strict, UTF-16 lengths recorded. Zero-ink row existence and nonbody/cell story coverage are not independently proved by this scalar test."},
 {"id":"retained-disk-reopens", "status":"CONFIRMED", "detail":"Five mixed saves use the actual disk-reopened instance for the next cycle, followed by separate HWP/HWPX tail exports. Written bytes must exactly equal exporter bytes; correct-password/plain reopening is mandatory."},
 {"id":"history", "status":"CONFIRMED", "detail":"Exact published snapshots are restored for both initial/edit and retained-tail Undo/Redo pairs. No history check is conditionally skipped on PASS."},
 {"id":"whole-geometry", "status":"CONFIRMED", "detail":"Mandatory production verifyPreservedExport must return checked, including whole published controls/text. Production measured coordinates and charX use established 0.2; all other fields, keys, lengths, counts, IDs and owners are exact. Supplemental compareSnapshots also checks all published fields, with its broader numeric0.2 comparator; this does not replace the stricter mandatory production guard."},
 {"id":"semantic-loss", "status":"CONFIRMED", "detail":"Exporter contentLoss.count must be zero; unchanged production semantic capture/comparison remains mandatory and unreadable/blocked does not become PASS."},
 {"id":"source-events", "status":"CONFIRMED_WITH_LIMIT", "detail":"Each save checks the source published snapshot, native event log and ordinary HWP export bytes remain exact. This does not independently prove every hidden IR/opaque stream; those require separate native/opaque preservation evidence."},
 {"id":"password-negative", "status":"CONFIRMED", "detail":"Each successful encrypted artifact must reject an incorrect password and independently reopen with the correct password before layout/source coverage validation."},
 {"id":"fail-closed-results", "status":"CONFIRMED", "detail":"All fixed16 cases run; exceptions produce FAIL with phase and cause nonzero process exit. PASS is reached only after all seven exports and both history pairs. There are no skipped cases, row repairs, private model/lease creation or failure filters."},
 {"id":"baseline-provenance", "status":"CONFIRMED", "detail":"Current verifier and fixed manifest match r3 exactly. Baseline engine JS/WASM hashes and all12 recorded disk artifact hashes independently match actual files. Baseline remains16FAIL."},
 {"id":"clean-mirror-condition", "status":"REQUIRED_FOR_FINAL_RUN", "detail":"Parent confirmed final execution will use the approved clean mirror and assert verifier plus all4 baseline raw guard hashes before running. Workspace stored-information WIP differs from that baseline and must be preserved, not substituted or reset."},
 {"id":"unrelated-wip45", "status":"CONFIRMED", "detail":"All45 preserved files match initial manifest, official151 evidence and current raw bytes. README is intentionally excluded from this cohort so user README edits remain untouched."}
]
report = {
 "schemaVersion": 1, "scope":"N001 offset154 verifier read-only static audit plus existing artifact/hash verification; no engine/verifier execution, production edits, GUI or source-row/lease mutation",
 "auditedAtUtc": datetime.now(timezone.utc).isoformat(),
 "verdict":"NO_CONFIRMED_STATIC_BLOCKER; final runtime acceptance remains pending",
 "findings": [], "checks":checks,
 "verifier":file_info(verifier), "reviewHelper":file_info(helper), "manifest":file_info(manifest_path), "fixedInputs":inputs,
 "baseline":{"result":file_info(baseline_dir/'result.json'), "engine":baseline['engine'], "engineArtifacts":engine_artifacts,
             "cases":16,"passed":0,"failed":16,"failurePhases":dict(Counter(x['phase'] for x in baseline['failures'])),
             "successfulDiskObservations":12,"historyPairs":16,"wrongPasswordRefusals":6,
             "note":"Two XML initial cases reached retained-tail-edit after five mixed cycles and one HWP tail export; HWPX tail failed. Remaining14 failed first disk cycle. None are marked complete.","diskArtifactsVerified":disks},
 "productionGuardProvenance":guards,
 "finalRuntimeAcceptance":{"requiredCases":16,"requiredPassed":16,"requiredFailed":0,"requiredDiskObservations":112,"requiredHistoryPairs":32,"requiredWrongPasswordRefusals":56,
   "preconditions":["Approved clean mirror; verifier raw SHA identical to this audit and baseline r3", "All4 guard raw hashes identical to baseline r3 before execution and unchanged afterward", "Fixed input bytes unchanged; output result directory fresh", "Real candidate engine JS/WASM bytes match recorded metadata; retain full source/runtime hash provenance", "No removed compare fields, tolerance expansion, ignored failures or source-row repairs"],
   "note":"Counts112/32/56 follow structurally from all16 PASS; assert externally in the final report. A static audit is not a substitute for this actual runtime execution."},
 "unrelated45":{"initialManifest":file_info(wip_initial_path),"officialEvidence":file_info(wip_evidence_path),"checked":45,"matched":45,"mismatches":[],"files":wip_checked,"READMEExcludedToPreserveUserEdits":True},
 "limitations":["Own fixed offset scenario only; no claim of arbitrary layout or Hancom screen/print equality.","Scalar coverage does not establish zero-ink empty-row presence or all nonbody stories; separate producer/mandatory owner/native tests remain necessary.","Public source snapshot/export/event immutability is not an exhaustive private-IR byte comparison.","No final candidate engine was run for this audit; original baseline failures are deliberately preserved."]
}
(out/'review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({"path":str((out/'review.json').resolve()),"sha256":file_info(out/'review.json')['sha256'],"findings":0,"wip45Matched":45,"baselineFailures":16},ensure_ascii=False))
