# N001 initial Native separator fitting153

Apply current-whole-section-wrap-spacing153.patch after the frozen stage8 11-runtime overlay on official151. Three runtime files only; reference RESOURCE275 is supplied separately, and the combined merger must reissue its own exact inventory/digest including actual new dependencies.

Initial Native→HWPX published geometry6 becomes0. XML initial stays0. Source-free full replay was already exactly equal to actual current composition on both sides, but normal whole structural p0 missed the transient spacing policy used by the selected-fragment path. The new module limits the policy to actual normal recomposition, index0 structural SectionDef+ColumnDef and the whole rendered composition. It neither writes source rows/tags nor grants allocation/origin/export permission. The token is immediately consumed by the same immutable paragraph and locally owned current composition reference.

Native release verification: 29 policy conditions; 28 actual mixed/plain/password disk exports including exact tail154 edit, source/events/semantics invariant, 14 wrong-password refusals and four tail Undo/Redo pairs; all44 original inputs initial HWPX disk-reopen geometry0/loss0. Fixed44 initial+edited differential88 is preserved and classified separately:78 unchanged,10 combined changes with two overlapping categories (spacing153 initial8, coordinate148 initial/edited4). No ignored fields or tolerance changes.

Original six differences and setup failures are preserved. Native-only diagnostic seam is explicitly excluded from production. Official combined WASM/public guard/browser verification is still required. Edited prefix/tail failures owned by148/152 are not claimed complete here.
