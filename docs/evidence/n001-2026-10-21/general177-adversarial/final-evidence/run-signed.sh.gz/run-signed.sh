#!/usr/bin/env bash
set -euo pipefail
repo=/mnt/c/Users/jjome/Documents/work/jueony
export RUSTUP_HOME="$repo/.tools/linux-rustup"
export CARGO_HOME="$repo/.tools/linux-cargo"
export PATH="$CARGO_HOME/bin:$PATH"
export CARGO_TARGET_DIR=/tmp/jueony-n001-absolute159-ONLY
export N001_ROOT="$repo"
export N001_OUT="$repo/build/n001-fit-regression174/${1:?stage}"
export N001_MODE="${2:-verify}"
export N001_MANIFEST="$repo/build/n001-negative157/authored/manifest.json"
cd "$repo/build/n001-fit-regression174/signed-harness"
cargo run --release --offline --locked
