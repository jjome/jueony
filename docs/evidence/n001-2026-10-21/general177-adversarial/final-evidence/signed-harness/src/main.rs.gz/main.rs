use rhwp::{DocumentCore,model::control::Control};
use sha2::{Digest,Sha256};
use serde_json::{Value,json};
use std::path::{Path,PathBuf};
#[derive(Clone,Copy)]struct Case{name:&'static str,tables:usize,interleave:bool,columns:u16,unequal:bool,short_page:bool,offset:i32,tac:bool,overlap:bool,oversize:bool}
fn cases()->Vec<Case>{[
 ("single-negative-control",1,false,-300,true,false,false),
 ("equal2-minus1",2,false,-1,false,false,false),
 ("equal2-minus300-overlap",2,false,-300,true,false,false),
 ("equal3-minus300",3,false,-300,false,false,false),
 ("equal3-minus1200-overlap",3,false,-1200,true,false,false),
 ("unequal2-minus1",2,true,-1,false,false,false),
 ("unequal2-minus300-overlap",2,true,-300,true,false,false),
 ("unequal3-minus300",3,true,-300,false,false,false),
 ("unequal3-minus1200-overlap",3,true,-1200,true,false,false),
 ("unequal3-minus300-short",3,true,-300,false,true,false),
 ("equal3-minus1200-short",3,false,-1200,false,true,false),
 ("unequal3-negative-oversize",3,true,-300,false,true,true),
 ].into_iter().map(|(name,columns,unequal,offset,overlap,short_page,oversize)|Case{name,columns,unequal,offset,overlap,short_page,oversize,tables:if oversize{1}else{3},interleave:true,tac:false}).collect()}
fn hash(b:&[u8])->String{Sha256::digest(b).iter().map(|b|format!("{b:02x}")).collect()}
fn author(c:Case)->Vec<u8>{
 let mut d=DocumentCore::new_empty();d.create_blank_document_native().unwrap();d.insert_text_native(0,0,0,&"Own general-layout prefix. ".repeat(4)).unwrap();
 for n in 0..c.tables {let last=d.document().sections[0].paragraphs.len()-1;let end=d.document().sections[0].paragraphs[last].text.chars().count();d.create_table_native(0,last,end,2,1).unwrap();let host=d.document().sections[0].paragraphs.iter().rposition(|p|p.controls.iter().any(|c|matches!(c,Control::Table(_)))).unwrap();let ci=d.document().sections[0].paragraphs[host].controls.iter().position(|c|matches!(c,Control::Table(_))).unwrap();d.insert_text_in_cell_native(0,host,ci,0,0,0,&format!("Own table {n} first cell. ")).unwrap();d.insert_text_in_cell_native(0,host,ci,1,0,0,&format!("Own table {n} second cell. ")).unwrap();if c.interleave{let tail=d.document().sections[0].paragraphs.len()-1;d.insert_text_native(0,tail,0,&format!("Interleaved body {n}. ")).unwrap();}}
 let tail=d.document().sections[0].paragraphs.len()-1;let end=d.document().sections[0].paragraphs[tail].text.chars().count();d.insert_text_native(0,tail,end,&"Own trailing paragraph. ".repeat(if c.short_page{18}else{2})).unwrap();
 if c.columns>1 {d.set_column_def_native(0,c.columns,0,true,720).unwrap();}
 // This is fixture authoring only, before serialization/reopen/public edit.
 // No descriptor, CompletedRows, source seal, or implementation flag is authored.
 let mut doc=d.document().clone();
 if c.short_page{let page=&mut doc.sections[0].section_def.page_def;page.height=23000;page.margin_header=1000;page.margin_top=1000;page.margin_bottom=1000;page.margin_footer=1000;}
 for p in &mut doc.sections[0].paragraphs {for ctrl in &mut p.controls {match ctrl{
  Control::Table(t)=>{t.common.treat_as_char=c.tac;t.common.allow_overlap=c.overlap;t.common.horizontal_offset=0;t.common.vertical_offset=c.offset as u32;
    if c.oversize{t.common.height=80000;for cell in &mut t.cells{cell.height=80000/u32::from(t.row_count);}}t.raw_ctrl_data.clear();t.raw_ctrl_seal=None;},
  Control::SectionDef(s)=>if c.short_page{let page=&mut s.page_def;page.height=23000;page.margin_header=1000;page.margin_top=1000;page.margin_bottom=1000;page.margin_footer=1000;},
  Control::ColumnDef(cd)=>if c.unequal{cd.same_width=false;cd.proportional_widths=true;cd.widths=if c.columns==2{vec![11000,20568]}else{vec![7000,11000,12368]};cd.gaps=vec![1200;c.columns.saturating_sub(1)as usize];cd.raw_attr=0;},_=>{}}}}
 for s in &mut doc.sections{s.raw_stream=None;}
 let a=rhwp::serializer::serialize_hwp_with_report(&doc).unwrap();assert_eq!(a.content_loss().len(),0,"authoring {} {}",c.name,a.content_loss().to_json());a.bytes().to_vec()
}
fn layout(d:&DocumentCore)->Value{json!({"pages":d.page_count(),"layout":(0..d.page_count()).map(|p|json!({"text":serde_json::from_str::<Value>(&d.get_page_text_layout_native(p).unwrap()).unwrap(),"controls":serde_json::from_str::<Value>(&d.get_page_control_layout_native(p).unwrap()).unwrap()})).collect::<Vec<_>>()})}
fn diffs(a:&Value,b:&Value,path:&str,out:&mut Vec<Value>){match(a,b){(Value::Object(a),Value::Object(b))=>for k in a.keys().chain(b.keys()).collect::<std::collections::BTreeSet<_>>(){if a.contains_key(k)&&!b.contains_key(k)||!a.contains_key(k){out.push(json!({"path":format!("{path}/{k}"),"type":"key"}));}else{diffs(&a[k],&b[k],&format!("{path}/{k}"),out)}},(Value::Array(a),Value::Array(b))=>{if a.len()!=b.len(){out.push(json!({"path":path,"beforeLength":a.len(),"afterLength":b.len()}));}for(i,(a,b))in a.iter().zip(b).enumerate(){diffs(a,b,&format!("{path}/{i}"),out)}},(Value::Number(a),Value::Number(b))=>if(a.as_f64().unwrap()-b.as_f64().unwrap()).abs()>0.2{out.push(json!({"path":path,"before":a,"after":b}))},_=>if a!=b{out.push(json!({"path":path,"type":"value"}))}}}
fn semantics(d:&DocumentCore)->Value{json!(d.document().sections.iter().map(|s|s.paragraphs.iter().map(|p|json!({"text":p.text,"tables":p.controls.iter().filter_map(|c|if let Control::Table(t)=c{Some(json!({"offset":t.common.vertical_offset as i32,"horizontal":t.common.horizontal_offset as i32,"overlap":t.common.allow_overlap,"width":t.common.width,"height":t.common.height,"cells":t.cells.iter().map(|c|json!({"row":c.row,"col":c.col,"span":[c.row_span,c.col_span],"text":c.paragraphs.iter().map(|p|p.text.clone()).collect::<Vec<_>>()})).collect::<Vec<_>>()}))}else{None}).collect::<Vec<_>>()})).collect::<Vec<_>>()).collect::<Vec<_>>())}
fn artifact(d:&DocumentCore,format:&str,pwd:&[u8])->Result<(Vec<u8>,usize),String>{let a=match(format,pwd.is_empty()){
 ("hwp",true)=>d.export_hwp_with_adapter_snapshot_with_report(),("hwp",false)=>d.export_hwp_with_adapter_snapshot_with_password_and_report(pwd),
 ("hwpx",true)=>d.export_hwpx_native_with_report(),("hwpx",false)=>d.export_hwpx_native_with_password_and_report(pwd),_=>unreachable!()}.map_err(|e|e.to_string())?;Ok((a.bytes().to_vec(),a.content_loss().len()))}
fn save(d:&DocumentCore,format:&str,pwd:&[u8],out:&Path,label:&str,results:&mut Vec<Value>)->Option<DocumentCore>{
 let before=layout(d);let sem=semantics(d);let model=hash(format!("{:?}",d.document()).as_bytes());let events=d.serialize_event_log();
 let result=(||->Result<(DocumentCore,Value),String>{let(bytes,loss)=artifact(d,format,pwd)?;
 let path=out.join(format!("{label}.{format}"));std::fs::write(&path,&bytes).map_err(|e|e.to_string())?;let actual=std::fs::read(&path).map_err(|e|e.to_string())?;if actual!=bytes{return Err("disk readback".into());}
 if !pwd.is_empty()&&DocumentCore::from_bytes_with_password(&actual,b"wrong-signed-negative").is_ok(){return Err("wrong password accepted".into());}
 let next=if pwd.is_empty(){DocumentCore::from_bytes(&actual)}else{DocumentCore::from_bytes_with_password(&actual,pwd)}.map_err(|e|e.to_string())?;
 let after=layout(&next);let mut diff=vec![];diffs(&before,&after,"$",&mut diff);let semantic=sem==semantics(&next);
 let unchanged=model==hash(format!("{:?}",d.document()).as_bytes())&&events==d.serialize_event_log();
 let pass=loss==0&&diff.is_empty()&&semantic&&unchanged;
 if !pass{for(suffix,data)in[("before",before.clone()),("after",after),("differences",json!(diff)),("current-before",rhwp::private_absolute159(d)),("current-after",rhwp::private_absolute159(&next))]{std::fs::write(out.join(format!("{label}-{format}-{suffix}.json")),serde_json::to_vec_pretty(&data).unwrap()).map_err(|e|e.to_string())?;}}
 Ok((next,json!({"label":label,"format":format,"password":!pwd.is_empty(),"pass":pass,"geometryDifferences":diff.len(),"semanticEqual":semantic,"sourceEventsUnchanged":unchanged,"loss":loss,"sha256":hash(&bytes)})))})();
 match result{Ok((next,r))=>{let pass=r["pass"]==true;results.push(r);pass.then_some(next)},Err(e)=>{results.push(json!({"label":label,"format":format,"password":!pwd.is_empty(),"pass":false,"error":e}));None}}
}
fn generate(out:&Path){let dir=out.join("fixtures");std::fs::create_dir_all(&dir).unwrap();let mut manifest=vec![];
 for c in cases(){let bytes=author(c);let p=dir.join(format!("{}.hwp",c.name));std::fs::write(&p,&bytes).unwrap();let d=DocumentCore::from_bytes(&bytes).unwrap();
 for para in &d.document().sections[0].paragraphs{for ctrl in &para.controls{if let Control::Table(t)=ctrl{assert_eq!(t.common.vertical_offset as i32,c.offset);}}}
 let(x,loss)=artifact(&d,"hwpx",b"").unwrap();assert_eq!(loss,0);let xp=dir.join(format!("{}.hwpx",c.name));std::fs::write(&xp,&x).unwrap();
 manifest.push(json!({"name":c.name,"native":p,"nativeSha256":hash(&bytes),"xml":xp,"xmlSha256":hash(&x),"declaredNegative":c.offset,"allowOverlap":c.overlap,"columns":c.columns,"unequal":c.unequal,"oversizeAuthored":c.oversize,"shortPage":c.short_page}));println!("AUTHORED {}",c.name);}
 std::fs::write(out.join("manifest.json"),serde_json::to_vec_pretty(&json!({"authoringOnly":"public create/table/text then explicit typed negative/column geometry before ordinary serialize and read; no source row/tag/descriptor repair","fixtures":manifest})).unwrap()).unwrap();}
fn regression44(out:&Path){
 let root=PathBuf::from(std::env::var("N001_ROOT").unwrap());let dir=root.join("apps/editor/tests/fixtures/n001-general125-own");
 let bytes=std::fs::read(dir.join("manifest.json")).unwrap();let manifest:Value=serde_json::from_slice(&bytes).unwrap();let mut observations=vec![];
 for fixture in manifest["fixtures"].as_array().unwrap(){for(file_key,sha_key)in[("file","sha256"),("xmlFile","xmlSha256")]{
  let name=fixture[file_key].as_str().unwrap();let bytes=std::fs::read(dir.join(name)).unwrap();assert_eq!(hash(&bytes),fixture[sha_key]);
  let mut d=DocumentCore::from_bytes(&bytes).unwrap();let initial=layout(&d);
  let end=d.document().sections[0].paragraphs[0].text.chars().count();let before=d.document().sections[0].paragraphs[0].text.clone();
  let payload=if std::env::var("N001_MODE").as_deref()==Ok("regression44-liveaudit"){ "현재 문맥으로 복합 배치를 다시 조판하는 자체 시험 문장입니다. ".repeat(25)}else{"Retained current prefix editing causes line reflow. ".repeat(if fixture["shortPage"]==true{15}else{7})};
  d.insert_text_native(0,0,end,&payload).unwrap();assert_eq!(d.document().sections[0].paragraphs[0].text,format!("{before}{payload}"));
  let edited=layout(&d);let path=out.join(format!("{name}.json"));std::fs::write(&path,serde_json::to_vec_pretty(&json!({"initial":initial,"edited":edited})).unwrap()).unwrap();
  observations.push(json!({"fixture":name,"sha256":hash(&bytes),"snapshot":path}));
 }}assert_eq!(observations.len(),44);std::fs::write(out.join("result.json"),serde_json::to_vec_pretty(&json!({"manifestSha256":hash(&std::fs::read(dir.join("manifest.json")).unwrap()),"observations":observations,"scope":"Current Native fixed44 initial and exact same public prefix as original125 corpus. Compare to official156 snapshot AFTER fields independently. No source regeneration or export override."})).unwrap()).unwrap();
}
fn main(){let out=PathBuf::from(std::env::var("N001_OUT").unwrap());std::fs::create_dir_all(&out).unwrap();
 let resource="official172-source-434b32d5f6aff786";std::fs::write(out.join("compiled-resource.json"),serde_json::to_vec_pretty(&json!({"resource":resource})).unwrap()).unwrap();
 if matches!(std::env::var("N001_MODE").as_deref(),Ok("regression44"|"regression44-liveaudit")){regression44(&out);return;}

 if std::env::var("N001_MODE").as_deref()==Ok("generate"){generate(&out);return;}
 let manifest=PathBuf::from(std::env::var("N001_MANIFEST").unwrap());let m:Value=serde_json::from_slice(&std::fs::read(manifest).unwrap()).unwrap();let mut results=vec![];let mut histories=vec![];
 for f in m["fixtures"].as_array().unwrap(){if !matches!(f["name"].as_str(),Some("unequal3-minus300"|"unequal3-minus1200-overlap")){continue;}for origin in["native","xml"]{let bytes=std::fs::read(f[origin].as_str().unwrap()).unwrap();assert_eq!(hash(&bytes),f[format!("{origin}Sha256")]);
 for encrypted in[false,true]{let name=format!("{}-{origin}-{}",f["name"].as_str().unwrap(),if encrypted{"password"}else{"plain"});let pwd=if encrypted{b"SignedNegative157".as_slice()}else{b"".as_slice()};let mut d=DocumentCore::from_bytes(&bytes).unwrap();let initial=layout(&d);let undo=d.save_snapshot_native();let original=d.document().sections[0].paragraphs[0].text.clone();let payload="Signed negative current prefix reflows across columns. ".repeat(8);d.insert_text_native(0,0,original.chars().count(),&payload).unwrap();assert_eq!(d.document().sections[0].paragraphs[0].text,format!("{original}{payload}"));
 let edited=layout(&d);
 let redo=d.save_snapshot_native();d.restore_snapshot_native(undo).unwrap();assert_eq!(layout(&d),initial);d.restore_snapshot_native(redo).unwrap();assert_eq!(layout(&d),edited);histories.push(json!({"case":name,"undoRedoExact":true}));
 std::fs::write(out.join(format!("{name}-live.json")),serde_json::to_vec_pretty(&edited).unwrap()).unwrap();std::fs::write(out.join(format!("{name}-current.json")),serde_json::to_vec_pretty(&rhwp::private_absolute159(&d)).unwrap()).unwrap();
 if std::env::var("N001_MODE").as_deref()==Ok("adversarial177"){let proof=rhwp::private_signed_partial177_adversarial(&mut d);results.push(json!({"label":name,"pass":true,"proof":proof}));continue;}
 for format in["hwp","hwpx"]{if let Some(mut reopened)=save(&d,format,pwd,&out,&format!("{name}-edit"),&mut results){let tail=reopened.document().sections[0].paragraphs.len()-1;reopened.insert_text_native(0,tail,0,"후속 😀 negative tail157 ").unwrap();for ff in["hwp","hwpx"]{let _=save(&reopened,ff,pwd,&out,&format!("{name}-after-{format}-followup"),&mut results);}}}
 println!("CASE {name}");
 }}}
 let pass=results.iter().filter(|r|r["pass"]==true).count();std::fs::write(out.join("result.json"),serde_json::to_vec_pretty(&json!({"mode":"ordinary Native public report artifacts + disk readback + unchanged full-published0.2 geometry/semantics/source/events policy; final actualWASM clean production guard still required","observations":results,"passed":pass,"failed":results.len()-pass,"history":histories})).unwrap()).unwrap();
}
