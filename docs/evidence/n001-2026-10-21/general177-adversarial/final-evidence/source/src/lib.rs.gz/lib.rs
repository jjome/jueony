//! rhwp — Rust HWP 뷰어/에디터
//!
//! 본 제품은 한글과컴퓨터의 한글 문서 파일(.hwp) 공개 문서를 참고하여 개발하였습니다.

use wasm_bindgen::prelude::*;

pub mod hwt_leaf115;
pub mod agent;
pub mod agent_seal;
pub mod capabilities_schema;
pub mod diagnostics;
pub mod docdiff;
pub mod doclang;
pub mod document_core;
pub mod emf;
pub mod eps;
pub mod error;
pub use rhwp_contracts::ir_schema;
pub mod model;
pub mod ole_chart;
pub use rhwp_contracts::ontology;
pub use rhwp_ooxml_chart as ooxml_chart;
pub mod paint;
pub mod parser;
pub use rhwp_password_crypto as password_crypto;
pub mod plan_schema;
pub mod pq_sign;
pub use rhwp_contracts::provenance;
pub mod rag;
pub mod render_backend;
pub mod renderer;
pub mod scaffold;
pub mod schema_registry;
pub mod security_trailer;
pub mod serializer;
pub mod service;
/// 핫패치 벤더(Dioxus subsecond) 어댑터. **rhwp 의 API 가 아니다** (#4580).
///
/// `pub` 인 이유는 `tools/rhwp-subsecond` 가 `link_wasm_exports()` 를 불러 wasm export 를 살려
/// 둬야 하기 때문이지, 이 안의 함수들을 밖에서 쓰라는 뜻이 아니다. 격리 자체는 feature 가 이미
/// 지킨다 — `subsecond-dev` 없이는 모듈이 존재하지 않으므로 릴리스 표면에는 처음부터 나오지
/// 않는다. `#[doc(hidden)]` 은 그 사실을 문서에도 적는 것이다.
#[doc(hidden)]
#[cfg(feature = "subsecond-dev")]
pub mod subsecond_dev;
pub mod wasm_api;
pub mod wmf;

pub use document_core::DocumentCore;
pub use error::HwpError;
pub use model::event::DocumentEvent;
pub use parser::{parse_document, parse_document_with_password, DocumentParser};
pub use serializer::{serialize_document, DocumentSerializer};

/// WASM panic hook 초기화 (한 번만 실행)
#[wasm_bindgen(start)]
pub fn init_panic_hook() {
    #[cfg(feature = "console_error_panic_hook")]
    console_error_panic_hook::set_once();
}

#[wasm_bindgen]
pub fn version() -> String {
    env!("CARGO_PKG_VERSION").to_string()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_version() {
        assert_eq!(version(), env!("CARGO_PKG_VERSION"));
    }
}

// Excluded immutable native diagnostic, never a product API.
pub fn private_absolute159(d:&DocumentCore)->serde_json::Value {
 use serde_json::{json,Value};
 let mut sections=vec![];
 for (section,result)in d.pagination.iter().enumerate(){let styles=d.resolve_render_styles_for_section(section);
  let source=&d.document.sections[section].paragraphs;
  let trace=result.selected_composition_trace.as_ref();
  let facts=trace.map(|t|json!({"generation":t.generation(),"resource":t.resource(),"sourceMatches":t.matches_source(source,styles.reset_flow_context,d.effective_layout_profile(),d.dpi),"frameMatches":t.matches_finalized_result(result),"formats":t.formats(),"commits":t.commits(),"tables":t.tables(),"wholeTables":t.whole_tables(),"fullFragments148":t.full_fragments148(),"measurementTokens":d.measured_tables[section].iter().map(|m|json!({"paragraph":m.para_index,"token":m as *const _ as usize})).collect::<Vec<_>>(),"measurementKeys":d.measured_tables[section].iter().map(|m|json!({"paragraph":m.para_index,"key":renderer::selected_composition_observer127::full_fragment_measurement_key148(m)})).collect::<Vec<_>>()}));
  let mut pages=vec![];
  for page in &result.pages {
   if std::env::var("N001_FACTS_ONLY").is_ok(){break;}
   let tree=match d.build_page_tree_with_current_selections(page.page_index){Ok(t)=>t,Err(e)=>{pages.push(json!({"page":page.page_index,"paintError":e.to_string()}));continue;}};let selections=&tree.frame.current_physical_selections;
   let physical=selections.frames().map(|frames|{
    let rows=selections.rows().unwrap().iter().map(|r|json!({"node":r.frame.node,"paragraph":r.frame.paragraph,"line":r.frame.line,
     "effectiveColumnX":r.frame.effective_column_x,"effectiveColumnWidth":r.frame.effective_column_width,"availableWidth":r.frame.available_width,
     "marginLeft":r.frame.margin_left,"marginRight":r.frame.margin_right,"inlineOffset":r.frame.inline_offset,"numberingOffset":r.frame.numbering_offset,
     "physicalTextY":r.frame.physical_text_y,"lineBoxHeight":r.frame.final_line_box_height,"baseline":r.frame.baseline,"physicalFrameRows":r.frame.physical_frame_rows,
     "storedSpan":r.frame.stored_horizontal_span_used,"wrap":r.frame.has_wrap_anchor,"equation":r.frame.equation_adjusted,"selectedDebug":format!("{:?}",r.selected)})).collect::<Vec<_>>();
    json!({"frames":frames.iter().map(|f|json!({"node":f.node,"section":f.section,"page":f.page,"ordinal":f.column_ordinal,"column":f.column,"rect":[f.rect.x,f.rect.y,f.rect.width,f.rect.height],"items":format!("{:?}",f.items),"hasZone":f.has_zone,"zoneY":f.zone_y})).collect::<Vec<_>>(),"rows":rows,"tables":format!("{:?}",selections.tables())})
   });pages.push(json!({"page":page.page_index,"layout":format!("{:?}",page.layout),"columns":page.column_contents.iter().map(|c|json!({"column":c.column_index,"startHeight":c.start_height,"items":format!("{:?}",c.items)})).collect::<Vec<_>>(),"physical":physical}));
  }
  sections.push(json!({"section":section,"facts":facts,"pages":pages,"source":source.iter().enumerate().map(|(i,p)|json!({"paragraph":i,"text":p.text,"charCount":p.char_count,"offsets":p.char_offsets,"rows":p.line_segs,"controls":p.controls,"column":p.column_type,"rawBreak":p.raw_break_type})).collect::<Vec<_>>() }));
 }
 Value::Array(sections)
}

// Excluded Native-only immutable diagnostics.
pub fn private_absolute_host160(d:&DocumentCore)->serde_json::Value{
 use serde_json::json;let profile=d.effective_layout_profile();let styles=d.resolve_render_styles_for_section(0);
 let eligible=renderer::current_frame_rows_plan::current_absolute_multicol_host_rows160(d,&d.document).is_some();
 let mut measurements=vec![];
 for (pi,p)in d.document.sections[0].paragraphs.iter().enumerate(){for c in &p.controls{let model::control::Control::Table(t)=c else{continue;};
  let fresh=renderer::height_measurer::HeightMeasurer::new(d.dpi).with_hwp3_variant(profile.hwp3_layout()).with_legacy_hwp3_stored_geometry(profile.legacy_hwp3_stored_geometry())
   .with_native_hwp5(profile.native_hwp5_layout()).with_hwpx_stored_layout(profile.hwpx_stored_layout()).with_session_edited(profile.session_edited()).with_hwp3_origin_flow_spacing_before(false).measure_table(t,pi,0,&styles);
  measurements.push(json!({"paragraph":pi,"sourceCommon":t.common,"fresh":format!("{fresh:?}"),"actual":d.measured_tables[0].iter().find(|m|m.para_index==pi&&m.control_index==0).map(|m|format!("{m:?}")),"hostRows":p.line_segs}));
 }}json!({"eligible":eligible,"measurements":measurements})
}

// Excluded native-only adversarial probe. No production API.
pub fn private_signed_partial177_adversarial(d:&mut DocumentCore)->serde_json::Value{
 use serde_json::json;
 fn admitted(d:&DocumentCore)->bool{
  let s=d.resolve_render_styles_for_section(0);
  renderer::current_frame_rows_plan::CurrentSignedPartialFrames177::from_current(&d.document,d.source_format,&d.pagination[0],&s,&d.measured_tables[0],d.effective_layout_profile(),d.dpi).is_some()
 }
 let original=format!("{:?}",d.document);let source_bytes=serde_json::to_vec(&d.document.sections[0].paragraphs).unwrap();
 assert!(admitted(d));
 let pi=d.pagination[0].pages.iter().flat_map(|p|&p.column_contents).flat_map(|c|&c.items).find_map(|i|match i{renderer::pagination::PageItem::PartialParagraph{para_index,..}=>Some(*para_index),_=>None}).unwrap();
 let mut checks=vec![];
 for case in 0..8{
  match case{
   0=>{d.document.sections[0].paragraphs[pi].text.push('x');assert!(!admitted(d));d.document.sections[0].paragraphs[pi].text.pop();},
   1=>{let old=d.document.sections[0].paragraphs[pi].char_count;d.document.sections[0].paragraphs[pi].char_count=old+1;assert!(!admitted(d));d.document.sections[0].paragraphs[pi].char_count=old;},
   2=>{let old=d.document.sections[0].paragraphs[pi].char_shapes[0].char_shape_id;d.document.sections[0].paragraphs[pi].char_shapes[0].char_shape_id=u32::MAX;assert!(!admitted(d));d.document.sections[0].paragraphs[pi].char_shapes[0].char_shape_id=old;},
   3=>{let old=d.document.sections[0].paragraphs[pi].line_segs[0].line_height;d.document.sections[0].paragraphs[pi].line_segs[0].line_height=old+1;assert!(!admitted(d));d.document.sections[0].paragraphs[pi].line_segs[0].line_height=old;},
   4=>{let old=d.document.sections[0].paragraphs[pi].char_offsets[0];d.document.sections[0].paragraphs[pi].char_offsets[0]=old+1;assert!(!admitted(d));d.document.sections[0].paragraphs[pi].char_offsets[0]=old;},
   5=>{d.document.sections[0].paragraphs[pi].raw_header_extra.push(73);assert!(!admitted(d));d.document.sections[0].paragraphs[pi].raw_header_extra.pop();},
   6=>{let old=d.pagination[0].pages[0].layout.column_areas[0].width;d.pagination[0].pages[0].layout.column_areas[0].width=f64::NAN;assert!(!admitted(d));d.pagination[0].pages[0].layout.column_areas[0].width=old;},
   _=>{let old=d.measured_tables[0][0].total_height;d.measured_tables[0][0].total_height=old+1.0/75.0;assert!(!admitted(d));d.measured_tables[0][0].total_height=old;},
  }
  assert!(admitted(d),"restore case {case}");checks.push(json!({"case":case,"rejected":true,"exactRestoreAdmitted":true}));
 }
 let s=d.resolve_render_styles_for_section(0);let profile=d.effective_layout_profile();let result=&d.pagination[0];let m=&d.measured_tables[0];
 let clone=d.document.clone();assert!(renderer::current_frame_rows_plan::CurrentSignedPartialFrames177::from_current(&clone,d.source_format,result,&s,m,profile,d.dpi).is_none());
 let mut changed=s.clone();changed.char_styles[0].font_size+=1.0;assert!(renderer::current_frame_rows_plan::CurrentSignedPartialFrames177::from_current(&d.document,d.source_format,result,&changed,m,profile,d.dpi).is_none());
 changed=s.clone();changed.reset_flow_context=Some([99;32]);assert!(renderer::current_frame_rows_plan::CurrentSignedPartialFrames177::from_current(&d.document,d.source_format,result,&changed,m,profile,d.dpi).is_none());
 assert!(renderer::current_frame_rows_plan::CurrentSignedPartialFrames177::from_current(&d.document,d.source_format,result,&s,m,profile,d.dpi+1.0).is_none());
 assert_eq!(original,format!("{:?}",d.document));assert_eq!(source_bytes,serde_json::to_vec(&d.document.sections[0].paragraphs).unwrap());assert!(admitted(d));
 json!({"negativeCount":12,"mutationCases":checks,"cloneSource":true,"styleChangedWithoutContextUpdate":true,"contextMismatch":true,"dpiMismatch":true,"sourceExactRestored":true})
}
