//! Current plain paragraph fragments, independently replayed and partitioned.
//! Actual formatter row indices and canonical output row indices stay distinct.
use super::*;
use crate::renderer::{composer::{ComposedParagraph,PlainFramePartition},pagination::{PaginationResult,PageItem},
 selected_composition_observer127::FinalizedSelectedCompositionTrace,style_resolver::ResolvedStyleSet,
 height_measurer::MeasuredTable,page_layout::LayoutRect};
use crate::model::provenance::LayoutCompatibilityProfile;
pub(super) struct FragmentBody177{pub fresh:FreshBodyRows,pub source_lines:Vec<usize>,pub input_width:f64,pub last:bool,pub y:f64}
struct Part177{page:u32,column:u16,item:usize,start:usize,end:usize,source_start:usize,source_end:usize,width:f64,flow_before:f64,flow_after:f64}
pub(super) struct CurrentBodyFragments177{paragraph:usize,canonical:Vec<LineSeg>,composition:ComposedParagraph,source_lines:Vec<usize>,parts:Vec<Part177>,consumed:usize,first_offset:Option<i32>}
impl CurrentBodyFragments177{
 pub(super) fn from_current(source:&Document,result:&PaginationResult,trace:&FinalizedSelectedCompositionTrace,
  styles:&ResolvedStyleSet,profile:LayoutCompatibilityProfile,dpi:f64,index:usize,measured:&[MeasuredTable])->Option<Self>{
  let p=source.sections.first()?.paragraphs.get(index)?;
  if p.text.is_empty()||p.text.len()>64*1024{return None;}
  let cs=trace.commits().iter().filter(|c|c.paragraph==index).collect::<Vec<_>>();
  if cs.len()<2||cs.len()>48{return None;}
  let first=cs[0];let actual=trace.selected_composition(first.format_id)?;
  let mixed=cs.iter().any(|c|c.format_id!=first.format_id)||actual.lines.windows(2).any(|w|w[0].segment_width!=w[1].segment_width);
  let (canonical,composition,source_lines,parts)=if mixed{
   // A different actual formatter or mixed imported composition is not a
   // successful single-width replay. Select the existing immutable tail view.
   if index.checked_add(1)?!=source.sections[0].paragraphs.len(){return None;}
   let view=super::unequal_split148::CurrentFreshTailReplayView177::from_current(source,result,styles,profile,dpi,measured)?;
   if view.index()!=index||!view.matches_current(source,result,styles,profile,dpi){return None;}
   let parts=view.fragments().iter().map(|f|Part177{page:f.page,column:f.column,item:f.item,start:f.start,end:f.end,
    source_start:f.source_start,source_end:f.source_end,width:f.input_width,flow_before:f.flow_before,flow_after:f.flow_after}).collect::<Vec<_>>();
   (view.canonical_rows().to_vec(),view.composition().clone(),view.source_lines().to_vec(),parts)
  }else{
   let fact=trace.format(first.format_id)?;let width=fact.actual_input_width_px?;
   let fresh=super::current_signed_column157::fresh_signed_body_rows(p,styles,width,dpi)?;
   if fact.paragraph_token!=p as *const _ as usize||fact.definition_context!=styles.reset_flow_context||fact.dpi!=dpi
    ||fact.profile!=format!("{profile:?}")||fact.source_text!=p.text||fact.source_char_offsets!=p.char_offsets
    ||fact.before!=0.0||fact.after!=0.0||fact.has_numbering||fact.has_horizontal_shaping||fact.known_square_band
    ||fact.lines.len()!=fresh.rows.len()||fact.actual_heights.len()!=fresh.rows.len()||fact.actual_spacings.len()!=fresh.rows.len()
    ||!same_composition(&fresh.composition,&actual){return None;}
   for(i,l)in fresh.composition.lines.iter().enumerate(){if !fact_line_matches(&fact.lines[i],l,false)
    ||fact.actual_heights[i]!=crate::renderer::hwpunit_to_px(l.line_height,dpi)||fact.actual_spacings[i]!=crate::renderer::hwpunit_to_px(l.line_spacing,dpi){return None;}}
   let mut parts=Vec::new();let mut end=0usize;
   for c in cs{
    let page=c.page?;let pg=result.pages.get(page as usize)?;let col=pg.column_contents.get(usize::from(c.column))?;let slot=c.committed_item_index?;
    if c.section!=0||c.row_start!=end||c.row_end<=end||c.row_end>fresh.rows.len()||c.final_membership!=Some(true)
     ||!c.paragraph_token_matches||!c.metrics_still_match_selected_format||!c.range_inside_selected_composition||c.trimmed_before!=0.0
     ||!matches!(col.items.get(slot),Some(PageItem::PartialParagraph{para_index,start_line,end_line})if *para_index==index&&*start_line==c.row_start&&*end_line==c.row_end)
     ||c.actual_column_width_px!=pg.layout.column_areas.get(usize::from(c.column))?.width{return None;}
    parts.push(Part177{page,column:c.column,item:slot,start:c.row_start,end:c.row_end,source_start:c.row_start,source_end:c.row_end,width,
     flow_before:c.flow_before,flow_after:c.flow_after});end=c.row_end;
   }
   if end!=fresh.rows.len(){return None;}
   let source_lines=(0..fresh.rows.len()).collect();(fresh.rows,fresh.composition,source_lines,parts)
  };
  if canonical.is_empty()||canonical.len()>4096||canonical.len()!=composition.lines.len()||source_lines.len()!=canonical.len(){return None;}
  let mut previous:Option<(u32,usize)>=None;let mut end=0usize;let columns=result.pages.first()?.layout.column_areas.len();
  for p in &parts{
   if p.start!=end||p.end<=p.start||p.end>canonical.len()||p.source_end.checked_sub(p.source_start)?!=p.end-p.start
    ||!p.width.is_finite()||p.width<=0.0||!p.flow_before.is_finite()||p.flow_before<0.0{return None;}
   if let Some((page,column))=previous{if !((p.page==page&&usize::from(p.column)==column+1)
    ||p.page==page.checked_add(1)?&&p.column==0&&column+1==columns)||p.flow_before!=0.0{return None;}}
   previous=Some((p.page,usize::from(p.column)));end=p.end;
  }
  if end!=canonical.len(){return None;}
  Some(Self{paragraph:index,canonical,composition,source_lines,parts,consumed:0,first_offset:None})
 }
 pub(super) fn consume(&mut self,page:u32,column:u16,item:usize,start:usize,end:usize,rect:&LayoutRect,flow:f64,unpainted:f64,dpi:f64)->Option<FragmentBody177>{
  let p=self.parts.get(self.consumed)?;
  if (p.page,p.column,p.item,p.source_start,p.source_end)!=(page,column,item,start,end)||!arithmetic_equal(flow,p.flow_before)
   ||!unpainted.is_finite()||unpainted<0.0{return None;}
  let y=rect.y+flow-unpainted;let base=integer_hu(y-rect.y,dpi)?;
  if self.consumed==0{self.first_offset=Some(base);}else if base!=0{return None;}
  let mut fresh=FreshBodyRows{rows:self.canonical[p.start..p.end].to_vec(),composition:self.composition.clone()};
  fresh.composition.lines=self.composition.lines[p.start..p.end].to_vec();let mut advance=0.0;
  for (r,l) in fresh.rows.iter().zip(&fresh.composition.lines){
   let h=crate::renderer::hwpunit_to_px(r.line_height,dpi);
   if r.line_height<=0||r.line_spacing<0||l.segment_width<=0||l.segment_width>crate::renderer::px_to_hwpunit(p.width.min(rect.width),dpi)
    ||y+advance<rect.y||y+advance+h>rect.y+rect.height{return None;}
   advance+=h+crate::renderer::hwpunit_to_px(r.line_spacing,dpi);
  }
  if !arithmetic_equal(p.flow_after,flow+advance){return None;}
  let source_lines=self.source_lines[p.start..p.end].to_vec();self.consumed+=1;
  Some(FragmentBody177{fresh,source_lines,input_width:p.width,last:self.consumed==self.parts.len(),y})
 }
 pub(super) fn finish(self)->Option<CurrentFrameParagraphRows>{
  if self.consumed!=self.parts.len(){return None;}let first=self.parts.first()?;
  let parts=self.parts.iter().map(|p|Some(PlainFramePartition{page:p.page.checked_sub(first.page)?,column:if p.page==first.page{p.column.checked_sub(first.column)?}else{p.column},start:p.start,end:p.end})).collect::<Option<Vec<_>>>()?;
  let mut rows=crate::renderer::composer::encode_current_plain_frame_rows(&self.canonical,&parts)?;let offset=self.first_offset?;
  for row in rows.get_mut(first.start..first.end)?{row.vertical_pos=row.vertical_pos.checked_add(offset)?;}
  Some(CurrentFrameParagraphRows{kind:if offset==0{CurrentFrameRowKind::FreshSplitBody}else{CurrentFrameRowKind::FreshOffsetSplitBody148},section:0,paragraph:self.paragraph,rows})
 }
}
fn same_composition(a:&ComposedParagraph,b:&ComposedParagraph)->bool{
 a.para_style_id==b.para_style_id&&a.numbering_text.is_none()&&b.numbering_text.is_none()&&a.horizontal_shaping.is_none()&&b.horizontal_shaping.is_none()
 &&a.tac_controls.is_empty()&&b.tac_controls.is_empty()&&a.footnote_positions.is_empty()&&b.footnote_positions.is_empty()
 &&a.tab_extended.is_empty()&&b.tab_extended.is_empty()&&a.inline_controls.len()==b.inline_controls.len()
 &&a.inline_controls.iter().zip(&b.inline_controls).all(|(a,b)|a.line_index==b.line_index&&a.control_index==b.control_index&&a.control_type==b.control_type)
 &&a.lines.len()==b.lines.len()&&a.lines.iter().zip(&b.lines).all(|(a,b)|same_selected_line(a,b))
}

#[cfg(test)]
mod signed_partial177_tests {
 use super::*;
 use crate::model::paragraph::{Paragraph,CharShapeRef};
 use crate::renderer::style_resolver::{ResolvedCharStyle,ResolvedParaStyle};
 fn ledger()->CurrentBodyFragments177{
  let styles=ResolvedStyleSet{char_styles:vec![ResolvedCharStyle::default()],para_styles:vec![ResolvedParaStyle::default()],..Default::default()};
  let mut p=Paragraph::default();p.text="A😀".into();p.char_count=4;p.char_offsets=vec![0,1];p.char_shapes=vec![CharShapeRef::default()];
  let row=LineSeg{text_start:0,vertical_pos:0,line_height:1000,text_height:1000,baseline_distance:850,line_spacing:600,column_start:0,segment_width:7500,tag:0x80060000};
  let mut second=row.clone();second.text_start=1;second.vertical_pos=1600;p.line_segs=vec![row,second];
  let composition=crate::renderer::composer::compose_paragraph_in_context(&p,&styles);
  assert_eq!(composition.lines.len(),2);
  CurrentBodyFragments177{paragraph:7,canonical:p.line_segs,composition,source_lines:vec![35,36],
   parts:vec![Part177{page:0,column:1,item:3,start:0,end:1,source_start:35,source_end:36,width:100.0,flow_before:10.0,flow_after:10.0+1600.0/75.0},
   Part177{page:1,column:0,item:0,start:1,end:2,source_start:36,source_end:37,width:100.0,flow_before:0.0,flow_after:1600.0/75.0}],consumed:0,first_offset:None}
 }
 fn rect()->LayoutRect{LayoutRect{x:0.0,y:20.0,width:100.0,height:80.0}}
 #[test]fn signed_partial177_actual_indices_stay_separate_from_output_and_utf16(){
  let mut l=ledger();let a=l.consume(0,1,3,35,36,&rect(),10.0,0.0,96.0).unwrap();assert_eq!(a.source_lines,vec![35]);assert!(!a.last);
  let b=l.consume(1,0,0,36,37,&rect(),0.0,0.0,96.0).unwrap();assert_eq!(b.source_lines,vec![36]);assert!(b.last);
  assert_eq!(a.fresh.composition.lines[0].runs.iter().map(|r|r.text.as_str()).collect::<String>(),"A");
  assert_eq!(b.fresh.composition.lines[0].runs.iter().map(|r|r.text.as_str()).collect::<String>(),"😀");
  let rows=l.finish().unwrap();assert_eq!(rows.row_kind(),CurrentFrameRowKind::FreshOffsetSplitBody148);
  assert_eq!(rows.rows().iter().map(|r|r.text_start).collect::<Vec<_>>(),vec![0,1]);
  assert_eq!((rows.rows()[0].vertical_pos,rows.rows()[1].vertical_pos),(750,0));assert_eq!(rows.rows()[1].tag,0x80060003);
 }
 #[test]fn signed_partial177_wrong_actual_slot_range_flow_and_unconsumed_refuse(){
  for c in 0..6{let mut l=ledger();let mut args=(0,1,3,35,36,10.0,0.0);match c{0=>args.0=1,1=>args.1=0,2=>args.2=4,3=>args.3=34,4=>args.4=37,_=>args.5+=1.0/75.0};
   assert!(l.consume(args.0,args.1,args.2,args.3,args.4,&rect(),args.5,args.6,96.0).is_none());assert_eq!(l.consumed,0);}
  assert!(ledger().finish().is_none());let mut l=ledger();l.consume(0,1,3,35,36,&rect(),10.0,0.0,96.0).unwrap();assert!(l.finish().is_none());
 }
 #[test]fn signed_partial177_physical_glyph_width_and_nonfinite_refuse(){
  for c in 0..5{let mut l=ledger();let mut r=rect();let mut unpainted=0.0;match c{0=>r.width-=1.0/75.0,1=>r.height=10.0+1000.0/75.0-1.0/75.0,2=>r.y=f64::NAN,3=>r.width=0.0,_=>unpainted=f64::NAN};
   assert!(l.consume(0,1,3,35,36,&r,10.0,unpainted,96.0).is_none(),"case {c}");}
 }
}
