#!/usr/bin/env bash
set -euo pipefail
repo=/mnt/c/Users/jjome/Documents/work/jueony
export RUSTUP_HOME="$repo/.tools/linux-rustup"
export CARGO_HOME="$repo/.tools/linux-cargo"
export PATH="$CARGO_HOME/bin:$PATH"
export CARGO_TARGET_DIR=/tmp/jueony-n001-output130-target
export N001_ROOT="$repo/build/n001-storage177-native/evidence"
cd "$repo/build/n001-storage177-native/source"
cargo test --offline --locked -p rhwp --lib current_frame_rows -j2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib current_physical_selections -j2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib native_computed_resource_matches_the_actual_pipeline_sources -j2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib current_measured_band_positive_and_negative_scope145 -j2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib allocated_empty_ -j2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib measurement_tests148 -j2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib current_middle_ -j2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib actual_plain_suffix148_tests -j2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib actual_suffix_observer148_tests -j2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib signed -j2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib current_caption_rows157 -j2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib current_plain_row_footprint160 -j2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib current_signed -j2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib known_absolute_noink168 -j2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib caption161_ -j2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib caption_float_flow161 -j2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib stamped_rows163_tests -j2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib current_plain_reflow_fit170 -j2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib merged171_ -j2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib rowspan173 -j2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib noink_fit_prefix175 -j2 -- --nocapture --test-threads=1
cargo test --offline --locked -p rhwp --lib current_merged_row_footprint171_actual_and_refusals -j2 -- --nocapture --test-threads=1
